//! Rheoli cof â llaw trwy awgrymiadau amrwd.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Mae llawer o swyddogaethau yn y modiwl hwn yn cymryd awgrymiadau amrwd fel dadleuon ac yn darllen ohonynt neu'n ysgrifennu atynt.Er mwyn i hyn fod yn ddiogel, rhaid i'r awgrymiadau hyn fod yn *ddilys*.
//! Mae p'un a yw pwyntydd yn ddilys yn dibynnu ar y llawdriniaeth y mae'n cael ei defnyddio ar ei gyfer (darllen neu ysgrifennu), a maint y cof sy'n cael ei gyrchu (hy, faint o bytes sy'n read/written).
//! Mae'r rhan fwyaf o swyddogaethau'n defnyddio `*mut T` a `* const T` i gael mynediad at un gwerth yn unig, ac os felly mae'r ddogfennaeth yn hepgor y maint ac yn cymryd yn ganiataol mai beitiau `size_of::<T>()` ydyw.
//!
//! Nid yw'r union reolau ar gyfer dilysrwydd wedi'u pennu eto.Mae'r gwarantau a ddarperir ar y pwynt hwn yn fach iawn:
//!
//! * Nid yw pwyntydd [null]*byth* yn ddilys, nid hyd yn oed ar gyfer mynediad [size zero][zst].
//! * Er mwyn i bwyntydd fod yn ddilys, mae'n angenrheidiol, ond nid bob amser yn ddigonol, bod y pwyntydd yn *ddiffuant*: rhaid i ystod cof y maint penodol sy'n cychwyn wrth y pwyntydd fod i gyd o fewn ffiniau un gwrthrych a ddyrannwyd.
//!
//! Sylwch, yn Rust, bod pob newidyn (stack-allocated) yn cael ei ystyried yn wrthrych a ddyrannwyd ar wahân.
//! * Hyd yn oed ar gyfer gweithrediadau [size zero][zst], rhaid i'r pwyntydd beidio â bod yn pwyntio at gof deallocated, hy, mae deallocation yn gwneud awgrymiadau yn annilys hyd yn oed ar gyfer gweithrediadau maint sero.
//! Fodd bynnag, mae castio unrhyw gyfanrif nad yw'n llythrennol *llythrennol* i bwyntydd yn ddilys ar gyfer mynediad maint sero, hyd yn oed os yw rhywfaint o gof yn digwydd bod yn y cyfeiriad hwnnw ac yn cael ei ddeallocated.
//! Mae hyn yn cyfateb i ysgrifennu eich dyrannwr eich hun: nid yw'n anodd iawn dyrannu gwrthrychau maint sero.
//! Y ffordd ganonaidd i gael pwyntydd sy'n ddilys ar gyfer mynedfeydd maint sero yw [`NonNull::dangling`].
//! * Mae'r holl fynediad a gyflawnir gan swyddogaethau yn y modiwl hwn yn *an-atomig* yn yr ystyr [atomic operations] a ddefnyddir i gydamseru rhwng edafedd.
//! Mae hyn yn golygu ei fod yn ymddygiad heb ei ddiffinio i berfformio dau fynediad cydamserol i'r un lleoliad o wahanol edafedd oni bai bod y ddau fynediad yn darllen o'r cof yn unig.
//! Sylwch fod hyn yn cynnwys [`read_volatile`] a [`write_volatile`] yn benodol: Ni ellir defnyddio mynedfeydd anweddol ar gyfer cydamseru rhyng-edau.
//! * Mae canlyniad castio cyfeiriad at bwyntydd yn ddilys cyhyd â bod y gwrthrych sylfaenol yn fyw ac na ddefnyddir unrhyw gyfeirnod (dim ond awgrymiadau amrwd) i gael mynediad i'r un cof.
//!
//! Mae'r axiomau hyn, ynghyd â defnydd gofalus o [`offset`] ar gyfer rhifyddeg pwyntydd, yn ddigon i weithredu llawer o bethau defnyddiol mewn cod anniogel yn gywir.
//! Darperir gwarantau cryfach yn y pen draw, wrth i'r rheolau [aliasing] gael eu penderfynu.
//! Am ragor o wybodaeth, gweler yr [book] yn ogystal â'r adran yn y cyfeirnod sydd wedi'i neilltuo i [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Nid yw awgrymiadau amrwd dilys fel y'u diffinnir uchod o reidrwydd wedi'u halinio'n iawn (lle mae aliniad "proper" wedi'i ddiffinio gan y math pwynt, hy, rhaid alinio `*const T` ag `mem::align_of::<T>()`).
//! Fodd bynnag, mae'r rhan fwyaf o swyddogaethau'n ei gwneud yn ofynnol i'w dadleuon gael eu halinio'n iawn, a byddant yn nodi'r gofyniad hwn yn benodol yn eu dogfennaeth.
//! Eithriadau nodedig i hyn yw [`read_unaligned`] a [`write_unaligned`].
//!
//! Pan fydd angen alinio swyddogaeth yn iawn, mae'n gwneud hynny hyd yn oed os oes gan y fynedfa faint 0, hy, hyd yn oed os nad yw'r cof yn cael ei gyffwrdd mewn gwirionedd.Ystyriwch ddefnyddio [`NonNull::dangling`] mewn achosion o'r fath.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Yn cyflawni dinistriwr (os oes un) y gwerth pwyntiedig.
///
/// Mae hyn yn cyfateb yn semantig i ffonio [`ptr::read`] a thaflu'r canlyniad, ond mae ganddo'r manteision canlynol:
///
/// * Mae'n ofynnol * defnyddio `drop_in_place` i ollwng mathau heb eu maint fel gwrthrychau trait, oherwydd ni ellir eu darllen allan ar y pentwr a'u gollwng yn normal.
///
/// * Mae'n fwy cyfeillgar i'r optimizer wneud hyn dros [`ptr::read`] wrth ollwng cof a ddyrannwyd â llaw (ee, wrth weithredu `Box`/`Rc`/`Vec`), gan nad oes angen i'r casglwr brofi ei bod yn gadarn i ddileu'r copi.
///
///
/// * Gellir ei ddefnyddio i ollwng data [pinned] pan nad yw `T` yn `repr(packed)` (rhaid peidio â symud data pinned cyn iddo gael ei ollwng).
///
/// Ni ellir gollwng gwerthoedd heb eu llofnodi yn eu lle, rhaid eu copïo i leoliad wedi'i alinio yn gyntaf gan ddefnyddio [`ptr::read_unaligned`].Ar gyfer strwythurau wedi'u pacio, mae'r crynhoydd yn gwneud y symudiad hwn yn awtomatig.
/// Mae hyn yn golygu nad yw caeau strwythurau wedi'u pacio yn cael eu gollwng yn eu lle.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `to_drop` rhaid iddo fod yn [valid] ar gyfer darllen ac ysgrifennu.
///
/// * `to_drop` rhaid ei alinio'n iawn.
///
/// * Rhaid i'r gwerth pwyntiau `to_drop` fod yn ddilys ar gyfer gollwng, a allai olygu bod yn rhaid iddo gynnal invariants ychwanegol, mae hyn yn dibynnu ar fath.
///
/// Yn ogystal, os nad yw `T` yn [`Copy`], gall defnyddio'r gwerth pwyntio ar ôl galw `drop_in_place` achosi ymddygiad heb ei ddiffinio.Sylwch fod `*to_drop = foo` yn cyfrif fel defnydd oherwydd bydd yn achosi i'r gwerth gael ei ollwng eto.
/// [`write()`] gellir ei ddefnyddio i drosysgrifennu data heb beri iddo gael ei ollwng.
///
/// Sylwch, hyd yn oed os oes gan `T` faint `0`, rhaid i'r pwyntydd fod yn ddi-NULL ac wedi'i alinio'n iawn.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Tynnwch yr eitem olaf â llaw o vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Sicrhewch bwyntydd amrwd i'r elfen olaf yn `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Byrhau `v` i atal yr eitem olaf rhag cael ei gollwng.
///     // Rydym yn gwneud hynny yn gyntaf, i atal materion os yw'r `drop_in_place` islaw panics.
///     v.set_len(1);
///     // Heb alwad `drop_in_place`, ni fyddai'r eitem olaf byth yn cael ei gollwng, a byddai'r cof y mae'n ei reoli yn cael ei ollwng.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Sicrhewch fod yr eitem olaf wedi'i gollwng.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Sylwch fod y casglwr yn perfformio'r copi hwn yn awtomatig wrth ollwng strwythurau wedi'u pacio, hy, fel rheol nid oes rhaid i chi boeni am faterion o'r fath oni bai eich bod yn ffonio `drop_in_place` â llaw.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Nid oes ots am god yma, disodlir hyn gan y glud gollwng go iawn gan y casglwr.
    //

    // DIOGELWCH: gweler y sylw uchod
    unsafe { drop_in_place(to_drop) }
}

/// Yn creu pwyntydd amrwd null.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Yn creu pwyntydd amrwd null.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Mae angen impl â llaw i osgoi rhwymo `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Mae angen impl â llaw i osgoi rhwymo `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Yn ffurfio sleisen amrwd o bwyntydd a hyd.
///
/// Dadl `len` yw nifer yr **elfennau**, nid nifer y bytes.
///
/// Mae'r swyddogaeth hon yn ddiogel, ond mewn gwirionedd mae defnyddio'r gwerth dychwelyd yn anniogel.
/// Gweler dogfennaeth [`slice::from_raw_parts`] i gael gofynion diogelwch tafell.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // creu pwyntydd tafell wrth ddechrau gyda phwyntydd i'r elfen gyntaf
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // DIOGELWCH: Mae cyrchu'r gwerth o'r undeb `Repr` yn ddiogel ers * const [T]
        //
        // ac mae gan FatPtr yr un cynlluniau cof.Dim ond std all wneud y warant hon.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Yn perfformio'r un swyddogaeth â [`slice_from_raw_parts`], heblaw bod sleisen symudol amrwd yn cael ei dychwelyd, yn hytrach na sleisen na ellir ei symud amrwd.
///
///
/// Gweler dogfennaeth [`slice_from_raw_parts`] i gael mwy o fanylion.
///
/// Mae'r swyddogaeth hon yn ddiogel, ond mewn gwirionedd mae defnyddio'r gwerth dychwelyd yn anniogel.
/// Gweler dogfennaeth [`slice::from_raw_parts_mut`] i gael gofynion diogelwch tafell.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // aseinio gwerth ar fynegai yn y sleisen
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // DIOGELWCH: Mae cyrchu'r gwerth o'r undeb `Repr` yn ddiogel ers * mut [T]
        // ac mae gan FatPtr yr un cynlluniau cof
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Yn cyfnewid y gwerthoedd mewn dau leoliad symudol o'r un math, heb ddad-ddyneiddio'r naill na'r llall.
///
/// Ond ar gyfer y ddau eithriad canlynol, mae'r swyddogaeth hon yn cyfateb yn semantig i [`mem::swap`]:
///
///
/// * Mae'n gweithredu ar awgrymiadau amrwd yn lle cyfeiriadau.
/// Pan fydd tystlythyrau ar gael, dylid ffafrio [`mem::swap`].
///
/// * Gall y ddau werth pwyntiedig orgyffwrdd.
/// Os yw'r gwerthoedd yn gorgyffwrdd, yna defnyddir y rhanbarth cof sy'n gorgyffwrdd o `x`.
/// Dangosir hyn yn yr ail enghraifft isod.
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * Rhaid i `x` a `y` fod yn [valid] ar gyfer darllen ac ysgrifennu.
///
/// * Rhaid i `x` a `y` gael eu halinio'n iawn.
///
/// Sylwch, hyd yn oed os oes gan `T` faint `0`, rhaid i'r awgrymiadau fod yn rhai nad ydynt yn NULL ac wedi'u halinio'n iawn.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Cyfnewid dau ranbarth nad ydynt yn gorgyffwrdd:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // dyma `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // dyma `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Cyfnewid dau ranbarth sy'n gorgyffwrdd:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // dyma `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // dyma `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Mae mynegeion `1..3` y sleisen yn gorgyffwrdd rhwng `x` a `y`.
///     // Byddai canlyniadau rhesymol iddynt fod yn `[2, 3]`, fel bod mynegeion `0..3` yn `[1, 2, 3]` (yn cyfateb i `y` cyn yr `swap`);neu iddynt fod yn `[0, 1]` fel bod mynegeion `1..4` yn `[0, 1, 2]` (yn cyfateb i `x` cyn yr `swap`).
/////
///     // Diffinnir y gweithrediad hwn i wneud y dewis olaf.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Rhowch ychydig o le i ni weithio gyda ni.
    // Nid oes raid i ni boeni am ddiferion: nid yw `MaybeUninit` yn gwneud dim wrth gael ei ollwng.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Perfformiwch y cyfnewid DIOGELWCH: rhaid i'r galwr warantu bod `x` a `y` yn ddilys ar gyfer ysgrifennu ac wedi'u halinio'n iawn.
    // `tmp` ni all fod yn gorgyffwrdd naill ai `x` neu `y` oherwydd bod `tmp` wedi'i ddyrannu ar y pentwr fel gwrthrych a ddyrannwyd ar wahân.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` a gall `y` orgyffwrdd
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Yn cyfnewid beitiau `count * size_of::<T>()` rhwng dau ranbarth y cof gan ddechrau yn `x` a `y`.
/// Rhaid i'r ddau ranbarth *beidio* gorgyffwrdd.
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * Rhaid i `x` a `y` fod yn [valid] ar gyfer darllen ac ysgrifennu am `gyfrif *
///   maint_of: :<T>() `beit.
///
/// * Rhaid i `x` a `y` gael eu halinio'n iawn.
///
/// * Rhanbarth y cof yn dechrau yn `x` gyda maint o `gyfrif *
///   maint_of: :<T>() Rhaid i `beit *beidio* gorgyffwrdd â rhanbarth y cof sy'n dechrau yn `y` gyda'r un maint.
///
/// Sylwch, hyd yn oed os yw'r maint a gopïwyd yn effeithiol (`count * size_of: :<T>()`) yw `0`, rhaid i'r awgrymiadau fod yn rhai nad ydynt yn NULL ac wedi'u halinio'n iawn.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // DIOGELWCH: rhaid i'r galwr warantu bod `x` a `y`
    // yn ddilys ar gyfer ysgrifennu ac wedi'i alinio'n iawn.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Ar gyfer mathau sy'n llai na'r optimeiddio bloc isod, dim ond cyfnewid yn uniongyrchol er mwyn osgoi pesimio codegen.
    //
    if mem::size_of::<T>() < 32 {
        // DIOGELWCH: rhaid i'r galwr warantu bod `x` a `y` yn ddilys
        // ar gyfer ysgrifennu, wedi'u halinio'n iawn, a heb fod yn gorgyffwrdd.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Y dull yma yw defnyddio simd i gyfnewid x&y yn effeithlon.
    // Mae profion yn datgelu bod cyfnewid naill ai 32 beit neu 64 beit ar y tro yn fwyaf effeithlon i broseswyr Intel Haswell E.
    // Mae LLVM yn fwy abl i wneud y gorau os ydym yn rhoi #[repr(simd)] i strwythur, hyd yn oed os nad ydym yn defnyddio'r strwythur hwn yn uniongyrchol.
    //
    //
    // FIXME repr(simd) wedi'i dorri ar emscripten a redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Dolen trwy x&y, gan eu copïo `Block` ar y tro Dylai'r optimizer ddadlwytho'r ddolen yn llawn ar gyfer y mwyafrif o fathau DS
    // Ni allwn ddefnyddio dolen ddolen gan fod yr impl `range` yn galw `mem::swap` yn gylchol
    //
    let mut i = 0;
    while i + block_size <= len {
        // Creu rhywfaint o gof heb ei ddynodi gan fod gofod crafu Mae datgan `t` yma yn osgoi alinio'r pentwr pan nad yw'r ddolen hon yn cael ei defnyddio
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // DIOGELWCH: Fel `i < len`, ac fel y mae'n rhaid i'r galwr warantu bod `x` a `y` yn ddilys
        // ar gyfer beitiau `len`, rhaid i `x + i` a `y + i` fod yn gyfeiriadau dilys, sy'n cyflawni'r contract diogelwch ar gyfer `add`.
        //
        // Hefyd, rhaid i'r galwr warantu bod `x` a `y` yn ddilys ar gyfer ysgrifeniadau, wedi'u halinio'n iawn, ac nad ydynt yn gorgyffwrdd, sy'n cyflawni'r contract diogelwch ar gyfer `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Cyfnewid bloc o bytes o x&y, gan ddefnyddio t fel byffer dros dro Dylid optimeiddio hyn i weithrediadau SIMD effeithlon pan fydd ar gael
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Cyfnewid unrhyw beit sy'n weddill
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // DIOGELWCH: gweler y sylw diogelwch blaenorol.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Symud `src` i'r `dst` pigfain, gan ddychwelyd y gwerth `dst` blaenorol.
///
/// Nid yw'r naill werth na'r llall yn cael ei ollwng.
///
/// Mae'r swyddogaeth hon yn cyfateb yn semantig i [`mem::replace`] ac eithrio ei bod yn gweithredu ar awgrymiadau amrwd yn lle cyfeiriadau.
/// Pan fydd tystlythyrau ar gael, dylid ffafrio [`mem::replace`].
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `dst` rhaid iddo fod yn [valid] ar gyfer darllen ac ysgrifennu.
///
/// * `dst` rhaid ei alinio'n iawn.
///
/// * `dst` rhaid pwyntio at werth cychwynnol cychwynnol math `T`.
///
/// Sylwch, hyd yn oed os oes gan `T` faint `0`, rhaid i'r pwyntydd fod yn ddi-NULL ac wedi'i alinio'n iawn.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` yn cael yr un effaith heb fod angen y bloc anniogel.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // DIOGELWCH: rhaid i'r galwr warantu bod `dst` yn ddilys i fod
    // cast i gyfeirnod symudol (dilys ar gyfer ysgrifennu, alinio, ymgychwyn), ac ni all orgyffwrdd `src` gan fod yn rhaid i `dst` bwyntio at wrthrych penodol a ddyrannwyd.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ni all orgyffwrdd
    }
    src
}

/// Yn darllen y gwerth o `src` heb ei symud.Mae hyn yn gadael y cof yn `src` yn ddigyfnewid.
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `src` rhaid iddo fod yn [valid] ar gyfer darlleniadau.
///
/// * `src` rhaid ei alinio'n iawn.Defnyddiwch [`read_unaligned`] os nad yw hyn yn wir.
///
/// * `src` rhaid pwyntio at werth cychwynnol cychwynnol math `T`.
///
/// Sylwch, hyd yn oed os oes gan `T` faint `0`, rhaid i'r pwyntydd fod yn ddi-NULL ac wedi'i alinio'n iawn.
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Gweithredu [`mem::swap`] â llaw:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Creu copi bitwise o'r gwerth yn `a` yn `tmp`.
///         let tmp = ptr::read(a);
///
///         // Byddai gadael ar y pwynt hwn (naill ai trwy ddychwelyd yn benodol neu drwy ffonio swyddogaeth y mae panics) yn achosi i'r gwerth yn `tmp` gael ei ollwng tra bod `a` yn dal i gyfeirio'r un gwerth.
///         // Gallai hyn sbarduno ymddygiad heb ei ddiffinio os nad `T` yw `Copy`.
/////
/////
///
///         // Creu copi bitwise o'r gwerth yn `b` yn `a`.
///         // Mae hyn yn ddiogel oherwydd ni all cyfeiriadau treiddgar alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Fel uchod, gallai gadael yma ysgogi ymddygiad heb ei ddiffinio oherwydd cyfeirir at yr un gwerth gan `a` a `b`.
/////
///
///         // Symud `tmp` i mewn i `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` wedi'i symud (mae `write` yn cymryd perchnogaeth o'i ail ddadl), felly nid oes unrhyw beth yn cael ei ollwng yn ymhlyg yma.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Perchnogaeth y Gwerth a ddychwelwyd
///
/// `read` yn creu copi bitwise o `T`, ni waeth a yw `T` yn [`Copy`].
/// Os nad yw `T` yn [`Copy`], gall defnyddio'r gwerth a ddychwelwyd a'r gwerth yn `*src` dorri diogelwch cof.
/// Sylwch fod aseinio i `*src` yn cyfrif fel defnydd oherwydd bydd yn ceisio gollwng y gwerth yn `* src`.
///
/// [`write()`] gellir ei ddefnyddio i drosysgrifennu data heb beri iddo gael ei ollwng.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` bellach yn pwyntio at yr un cof sylfaenol â `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Mae aseinio i `s2` yn achosi i'w werth gwreiddiol gael ei ollwng.
///     // Y tu hwnt i'r pwynt hwn, rhaid peidio â defnyddio `s` mwyach, gan fod y cof sylfaenol wedi'i ryddhau.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Byddai aseinio i `s` yn achosi i'r hen werth gael ei ollwng eto, gan arwain at ymddygiad heb ei ddiffinio.
/////
///     // s= String::from("bar");//GWALL
///
///     // `ptr::write` gellir ei ddefnyddio i drosysgrifennu gwerth heb ei ollwng.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // DIOGELWCH: rhaid i'r galwr warantu bod `src` yn ddilys ar gyfer darlleniadau.
    // `src` ni all orgyffwrdd `tmp` oherwydd dyrannwyd `tmp` ar y pentwr fel gwrthrych a ddyrannwyd ar wahân.
    //
    //
    // Hefyd, ers i ni ysgrifennu gwerth dilys i mewn i `tmp`, mae'n sicr y bydd yn cael ei gychwyn yn iawn.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Yn darllen y gwerth o `src` heb ei symud.Mae hyn yn gadael y cof yn `src` yn ddigyfnewid.
///
/// Yn wahanol i [`read`], mae `read_unaligned` yn gweithio gydag awgrymiadau heb eu llofnodi.
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `src` rhaid iddo fod yn [valid] ar gyfer darlleniadau.
///
/// * `src` rhaid pwyntio at werth cychwynnol cychwynnol math `T`.
///
/// Fel [`read`], mae `read_unaligned` yn creu copi bitwise o `T`, ni waeth a yw `T` yn [`Copy`].
/// Os nad yw `T` yn [`Copy`], gall defnyddio'r gwerth a ddychwelwyd a'r gwerth yn `*src` [violate memory safety][read-ownership].
///
/// Sylwch, hyd yn oed os oes gan `T` faint `0`, rhaid i'r pwyntydd fod yn ddi-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Ar strwythurau `packed`
///
/// Ar hyn o bryd mae'n amhosibl creu awgrymiadau amrwd i gaeau heb eu llofnodi o strwythur wedi'i bacio.
///
/// Mae ceisio creu pwyntydd amrwd i gae strwythuredig `unaligned` gyda mynegiad fel `&packed.unaligned as *const FieldType` yn creu cyfeirnod canolradd heb ei lofnodi cyn trosi hwnnw i bwyntydd amrwd.
///
/// Bod y cyfeirnod hwn dros dro a'i gastio ar unwaith yn amherthnasol gan fod y casglwr bob amser yn disgwyl i gyfeiriadau gael eu halinio'n iawn.
/// O ganlyniad, mae defnyddio `&packed.unaligned as *const FieldType` yn achosi* ymddygiad heb ei ddiffinio * ar unwaith yn eich rhaglen.
///
/// Enghraifft o'r hyn i beidio â'i wneud a sut mae hyn yn berthnasol i `read_unaligned` yw:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Yma rydym yn ceisio cymryd cyfeiriad cyfanrif 32-did nad yw wedi'i alinio.
///     let unaligned =
///         // Mae cyfeirnod dros dro heb ei lofnodi yn cael ei greu yma sy'n arwain at ymddygiad heb ei ddiffinio p'un a yw'r cyfeirnod yn cael ei ddefnyddio ai peidio.
/////
///         &packed.unaligned
///         // Nid yw castio i bwyntydd amrwd yn helpu;digwyddodd y camgymeriad eisoes.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Fodd bynnag, mae'n ddiogel cyrchu caeau heb eu llofnodi yn uniongyrchol ag ee `packed.unaligned`.
///
///
///
///
///
///
// FIXME: Diweddaru docs yn seiliedig ar ganlyniad RFC #2582 a'i ffrindiau.
/// # Examples
///
/// Darllenwch werth usize o byffer beit:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // DIOGELWCH: rhaid i'r galwr warantu bod `src` yn ddilys ar gyfer darlleniadau.
    // `src` ni all orgyffwrdd `tmp` oherwydd dyrannwyd `tmp` ar y pentwr fel gwrthrych a ddyrannwyd ar wahân.
    //
    //
    // Hefyd, ers i ni ysgrifennu gwerth dilys i mewn i `tmp`, mae'n sicr y bydd yn cael ei gychwyn yn iawn.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Yn trosysgrifo lleoliad cof gyda'r gwerth a roddir heb ddarllen na gollwng yr hen werth.
///
/// `write` ddim yn gollwng cynnwys `dst`.
/// Mae hyn yn ddiogel, ond gallai ollwng dyraniadau neu adnoddau, felly dylid cymryd gofal i beidio â throsysgrifo gwrthrych y dylid ei ollwng.
///
///
/// Yn ogystal, nid yw'n gollwng `src`.Yn semantig, mae `src` yn cael ei symud i'r lleoliad y mae `dst` yn cyfeirio ato.
///
/// Mae hyn yn briodol ar gyfer cychwyn cof anfwriadol, neu drosysgrifennu cof y bu [`read`] ohono o'r blaen.
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `dst` rhaid iddo fod yn [valid] ar gyfer ysgrifennu.
///
/// * `dst` rhaid ei alinio'n iawn.Defnyddiwch [`write_unaligned`] os nad yw hyn yn wir.
///
/// Sylwch, hyd yn oed os oes gan `T` faint `0`, rhaid i'r pwyntydd fod yn ddi-NULL ac wedi'i alinio'n iawn.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Gweithredu [`mem::swap`] â llaw:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Creu copi bitwise o'r gwerth yn `a` yn `tmp`.
///         let tmp = ptr::read(a);
///
///         // Byddai gadael ar y pwynt hwn (naill ai trwy ddychwelyd yn benodol neu drwy ffonio swyddogaeth y mae panics) yn achosi i'r gwerth yn `tmp` gael ei ollwng tra bod `a` yn dal i gyfeirio'r un gwerth.
///         // Gallai hyn sbarduno ymddygiad heb ei ddiffinio os nad `T` yw `Copy`.
/////
/////
///
///         // Creu copi bitwise o'r gwerth yn `b` yn `a`.
///         // Mae hyn yn ddiogel oherwydd ni all cyfeiriadau treiddgar alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Fel uchod, gallai gadael yma ysgogi ymddygiad heb ei ddiffinio oherwydd cyfeirir at yr un gwerth gan `a` a `b`.
/////
///
///         // Symud `tmp` i mewn i `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` wedi'i symud (mae `write` yn cymryd perchnogaeth o'i ail ddadl), felly nid oes unrhyw beth yn cael ei ollwng yn ymhlyg yma.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Rydym yn galw'r cynhenid yn uniongyrchol i osgoi galwadau swyddogaeth yn y cod a gynhyrchir gan fod `intrinsics::copy_nonoverlapping` yn swyddogaeth lapio.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // DIOGELWCH: rhaid i'r galwr warantu bod `dst` yn ddilys ar gyfer ysgrifennu.
    // `dst` ni all orgyffwrdd `src` oherwydd bod gan y galwr fynediad symudol i `dst` tra bod `src` yn eiddo i'r swyddogaeth hon.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Yn trosysgrifo lleoliad cof gyda'r gwerth a roddir heb ddarllen na gollwng yr hen werth.
///
/// Yn wahanol i [`write()`], gall y pwyntydd fod heb ei lofnodi.
///
/// `write_unaligned` ddim yn gollwng cynnwys `dst`.Mae hyn yn ddiogel, ond gallai ollwng dyraniadau neu adnoddau, felly dylid cymryd gofal i beidio â throsysgrifo gwrthrych y dylid ei ollwng.
///
/// Yn ogystal, nid yw'n gollwng `src`.Yn semantig, mae `src` yn cael ei symud i'r lleoliad y mae `dst` yn cyfeirio ato.
///
/// Mae hyn yn briodol ar gyfer cychwyn cof heb ei ddynodi, neu drosysgrifennu cof a ddarllenwyd o'r blaen gyda [`read_unaligned`].
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `dst` rhaid iddo fod yn [valid] ar gyfer ysgrifennu.
///
/// Sylwch, hyd yn oed os oes gan `T` faint `0`, rhaid i'r pwyntydd fod yn ddi-NULL.
///
/// [valid]: self#safety
///
/// ## Ar strwythurau `packed`
///
/// Ar hyn o bryd mae'n amhosibl creu awgrymiadau amrwd i gaeau heb eu llofnodi o strwythur wedi'i bacio.
///
/// Mae ceisio creu pwyntydd amrwd i gae strwythuredig `unaligned` gyda mynegiad fel `&packed.unaligned as *const FieldType` yn creu cyfeirnod canolradd heb ei lofnodi cyn trosi hwnnw i bwyntydd amrwd.
///
/// Bod y cyfeirnod hwn dros dro a'i gastio ar unwaith yn amherthnasol gan fod y casglwr bob amser yn disgwyl i gyfeiriadau gael eu halinio'n iawn.
/// O ganlyniad, mae defnyddio `&packed.unaligned as *const FieldType` yn achosi* ymddygiad heb ei ddiffinio * ar unwaith yn eich rhaglen.
///
/// Enghraifft o'r hyn i beidio â'i wneud a sut mae hyn yn berthnasol i `write_unaligned` yw:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Yma rydym yn ceisio cymryd cyfeiriad cyfanrif 32-did nad yw wedi'i alinio.
///     let unaligned =
///         // Mae cyfeirnod dros dro heb ei lofnodi yn cael ei greu yma sy'n arwain at ymddygiad heb ei ddiffinio p'un a yw'r cyfeirnod yn cael ei ddefnyddio ai peidio.
/////
///         &mut packed.unaligned
///         // Nid yw castio i bwyntydd amrwd yn helpu;digwyddodd y camgymeriad eisoes.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Fodd bynnag, mae'n ddiogel cyrchu caeau heb eu llofnodi yn uniongyrchol ag ee `packed.unaligned`.
///
///
///
///
///
///
///
///
///
// FIXME: Diweddaru docs yn seiliedig ar ganlyniad RFC #2582 a'i ffrindiau.
/// # Examples
///
/// Ysgrifennwch werth usize i byffer beit:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // DIOGELWCH: rhaid i'r galwr warantu bod `dst` yn ddilys ar gyfer ysgrifennu.
    // `dst` ni all orgyffwrdd `src` oherwydd bod gan y galwr fynediad symudol i `dst` tra bod `src` yn eiddo i'r swyddogaeth hon.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Rydym yn galw'r cynhenid yn uniongyrchol i osgoi galwadau swyddogaeth yn y cod a gynhyrchir.
        intrinsics::forget(src);
    }
}

/// Yn perfformio darlleniad cyfnewidiol o'r gwerth o `src` heb ei symud.Mae hyn yn gadael y cof yn `src` yn ddigyfnewid.
///
/// Bwriad gweithrediadau cyfnewidiol yw gweithredu ar gof I/O, ac maent yn sicr na fyddant yn cael eu twyllo na'u had-drefnu gan y casglwr ar draws gweithrediadau cyfnewidiol eraill.
///
/// # Notes
///
/// Ar hyn o bryd nid oes gan Rust fodel cof wedi'i ddiffinio'n drylwyr ac yn ffurfiol, felly gall union semanteg yr hyn y mae "volatile" yn ei olygu yma newid dros amser.
/// Wedi dweud hynny, bydd y semanteg bron bob amser yn eithaf tebyg i [C11's definition of volatile][c11].
///
/// Ni ddylai'r casglwr newid trefn gymharol na nifer y gweithrediadau cof cyfnewidiol.
/// Fodd bynnag, mae gweithrediadau cof cyfnewidiol ar fathau o faint sero (ee, os yw math sero o faint yn cael ei basio i `read_volatile`) yn noops a gellir eu hanwybyddu.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `src` rhaid iddo fod yn [valid] ar gyfer darlleniadau.
///
/// * `src` rhaid ei alinio'n iawn.
///
/// * `src` rhaid pwyntio at werth cychwynnol cychwynnol math `T`.
///
/// Fel [`read`], mae `read_volatile` yn creu copi bitwise o `T`, ni waeth a yw `T` yn [`Copy`].
/// Os nad yw `T` yn [`Copy`], gall defnyddio'r gwerth a ddychwelwyd a'r gwerth yn `*src` [violate memory safety][read-ownership].
/// Fodd bynnag, mae storio mathau nad ydynt yn [`Copi`] mewn cof cyfnewidiol bron yn sicr yn anghywir.
///
/// Sylwch, hyd yn oed os oes gan `T` faint `0`, rhaid i'r pwyntydd fod yn ddi-NULL ac wedi'i alinio'n iawn.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Yn union fel yn C, nid yw p'un a yw llawdriniaeth yn gyfnewidiol yn cael unrhyw effaith o gwbl ar gwestiynau sy'n ymwneud â mynediad cydamserol o sawl edefyn.Mae mynedfeydd anweddol yn ymddwyn yn union fel mynedfeydd nad ydynt yn atomig yn hynny o beth.
///
/// Yn benodol, mae ras rhwng `read_volatile` ac unrhyw weithrediad ysgrifennu i'r un lleoliad yn ymddygiad heb ei ddiffinio.
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Peidio â mynd i banig i gadw effaith codegen yn llai.
        abort();
    }
    // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Yn perfformio ysgrifen gyfnewidiol o leoliad cof gyda'r gwerth penodol heb ddarllen na gollwng yr hen werth.
///
/// Bwriad gweithrediadau cyfnewidiol yw gweithredu ar gof I/O, ac maent yn sicr na fyddant yn cael eu twyllo na'u had-drefnu gan y casglwr ar draws gweithrediadau cyfnewidiol eraill.
///
/// `write_volatile` ddim yn gollwng cynnwys `dst`.Mae hyn yn ddiogel, ond gallai ollwng dyraniadau neu adnoddau, felly dylid cymryd gofal i beidio â throsysgrifo gwrthrych y dylid ei ollwng.
///
/// Yn ogystal, nid yw'n gollwng `src`.Yn semantig, mae `src` yn cael ei symud i'r lleoliad y mae `dst` yn cyfeirio ato.
///
/// # Notes
///
/// Ar hyn o bryd nid oes gan Rust fodel cof wedi'i ddiffinio'n drylwyr ac yn ffurfiol, felly gall union semanteg yr hyn y mae "volatile" yn ei olygu yma newid dros amser.
/// Wedi dweud hynny, bydd y semanteg bron bob amser yn eithaf tebyg i [C11's definition of volatile][c11].
///
/// Ni ddylai'r casglwr newid trefn gymharol na nifer y gweithrediadau cof cyfnewidiol.
/// Fodd bynnag, mae gweithrediadau cof cyfnewidiol ar fathau o faint sero (ee, os yw math sero o faint yn cael ei basio i `write_volatile`) yn noops a gellir eu hanwybyddu.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ymddygiad yn cael ei diffinio os bydd unrhyw un o'r amodau canlynol yn cael eu torri:
///
/// * `dst` rhaid iddo fod yn [valid] ar gyfer ysgrifennu.
///
/// * `dst` rhaid ei alinio'n iawn.
///
/// Sylwch, hyd yn oed os oes gan `T` faint `0`, rhaid i'r pwyntydd fod yn ddi-NULL ac wedi'i alinio'n iawn.
///
/// [valid]: self#safety
///
/// Yn union fel yn C, nid yw p'un a yw llawdriniaeth yn gyfnewidiol yn cael unrhyw effaith o gwbl ar gwestiynau sy'n ymwneud â mynediad cydamserol o sawl edefyn.Mae mynedfeydd anweddol yn ymddwyn yn union fel mynedfeydd nad ydynt yn atomig yn hynny o beth.
///
/// Yn benodol, mae ras rhwng `write_volatile` ac unrhyw weithrediad arall (darllen neu ysgrifennu) yn yr un lleoliad yn ymddygiad heb ei ddiffinio.
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Peidio â mynd i banig i gadw effaith codegen yn llai.
        abort();
    }
    // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Alinio pwyntydd `p`.
///
/// Cyfrifwch y gwrthbwyso (o ran elfennau o `stride` stride) y mae'n rhaid ei gymhwyso i bwyntydd `p` fel y byddai'r pwyntydd `p` yn cael ei alinio â `a`.
///
/// Note: Mae'r gweithrediad hwn wedi'i deilwra'n ofalus i beidio â panic.Mae'n UB i hyn panic.
/// Yr unig newid gwirioneddol y gellir ei wneud yma yw newid `INV_TABLE_MOD_16` a chysonion cysylltiedig.
///
/// Os penderfynwn byth ei gwneud yn bosibl galw'r cynhenid â `a` nad yw'n bwer i ddau, mae'n debyg y bydd yn fwy doeth newid i weithred naïf yn hytrach na cheisio addasu hyn i ddarparu ar gyfer y newid hwnnw.
///
///
/// Mae unrhyw gwestiynau'n mynd i@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Mae defnydd uniongyrchol o'r cynhenid hyn yn gwella codgen yn sylweddol ar y lefel optig <=
    // 1, lle nad yw fersiynau dull y gweithrediadau hyn wedi'u llinellu.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Cyfrifwch wrthdro modiwlaidd lluosol o `x` modulo `m`.
    ///
    /// Mae'r gweithrediad hwn wedi'i deilwra ar gyfer `align_offset` ac mae ganddo ragamodau canlynol:
    ///
    /// * `m` yn bwer i ddau;
    /// * `x < m`; (os `x ≥ m`, pasiwch `x % m` yn lle)
    ///
    /// Ni fydd gweithredu'r swyddogaeth hon yn panic.Erioed.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Modulo tabl gwrthdro modiwlaidd lluosol 2⁴=16.
        ///
        /// Sylwch, nad yw'r tabl hwn yn cynnwys gwerthoedd lle nad oes gwrthdro yn bodoli (hy ar gyfer `0⁻¹ mod 16`, `2⁻¹ mod 16`, ac ati)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo y mae'r `INV_TABLE_MOD_16` wedi'i fwriadu ar ei gyfer.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // DIOGELWCH: Mae'n ofynnol i `m` fod yn bŵer dau, felly nid yw'n sero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Rydym yn ailadrodd "up" gan ddefnyddio'r fformiwla ganlynol:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // tan 2²ⁿ ≥ m.Yna gallwn leihau i'n `m` a ddymunir trwy gymryd y canlyniad `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Sylwch, ein bod yn defnyddio gweithrediadau lapio yma yn fwriadol-mae'r fformiwla wreiddiol yn defnyddio ee, tynnu `mod n`.
                // Mae'n hollol iawn eu gwneud `mod usize::MAX` yn lle, oherwydd rydyn ni'n cymryd y canlyniad `mod n` ar y diwedd beth bynnag.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // DIOGELWCH: Mae `a` yn bŵer dau, felly nid yw'n sero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` gellir cyfrif achos yn symlach trwy `-p (mod a)`, ond mae gwneud hynny yn rhwystro gallu LLVM i ddewis cyfarwyddiadau fel `lea`.Yn lle rydym yn cyfrifiannu
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // sy'n dosbarthu gweithrediadau o amgylch y llwyth, ond yn pesimio `and` yn ddigonol er mwyn i LLVM allu defnyddio'r amrywiol optimeiddiadau y mae'n gwybod amdanynt.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Eisoes wedi'i alinio.Hwrê!
        return 0;
    } else if stride == 0 {
        // Os nad yw'r pwyntydd wedi'i alinio, a bod yr elfen o faint sero, yna ni fydd unrhyw faint o elfennau byth yn alinio'r pwyntydd.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // DIOGELWCH: a yw pŵer dau, felly nid yw'n sero.ymdrinnir ag achos==0 uchod.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // DIOGELWCH: mae gan gcdpow rwymyn uchaf sydd ar y mwyaf yn nifer y darnau mewn usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // DIOGELWCH: mae gcd bob amser yn fwy neu'n hafal i 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Mae'r branch hwn yn datrys ar gyfer yr hafaliad cyfathru llinol canlynol:
        //
        // ` p + so = 0 mod a `
        //
        // `p` dyma werth y pwyntydd, `s`, cam o `T`, `o` wedi'i wrthbwyso yn `T`s, a `a`, yr aliniad y gofynnwyd amdano.
        //
        // Gyda `g = gcd(a, s)`, a'r amod uchod yn honni bod `p` hefyd yn rhanadwy gan `g`, gallwn ddynodi `a' = a/g`, `s' = s/g`, `p' = p/g`, yna daw hyn yn gyfwerth â:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Y term cyntaf yw "the relative alignment of `p` to `a`" (wedi'i rannu â'r `g`), yr ail dymor yw "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (wedi'i rannu eto â `g`).
        //
        // Mae angen rhannu â `g` i wneud y gwrthdro wedi'i ffurfio'n dda os nad yw `a` a `s` yn gyd-gysefin.
        //
        // At hynny, nid "minimal" yw'r canlyniad a gynhyrchir gan yr ateb hwn, felly mae angen cymryd y canlyniad `o mod lcm(s, a)`.Gallwn ddisodli `lcm(s, a)` gyda `a'` yn unig.
        //
        //
        //
        //
        //

        // DIOGELWCH: Mae gan `gcdpow` rwymyn uchaf nad yw'n fwy na nifer y 0 darn yn `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // DIOGELWCH: Mae `a2` yn ddi-sero.Ni all symud `a` gan `gcdpow` symud unrhyw un o'r darnau gosod allan
        // yn `a` (y mae ganddo un yn union ohono).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // DIOGELWCH: Mae gan `gcdpow` rwymyn uchaf nad yw'n fwy na nifer y 0 darn yn `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // DIOGELWCH: Mae gan `gcdpow` rwymyn uchaf nad yw'n fwy na nifer y darnau 0 trailing i mewn
        // `a`.
        // At hynny, ni all y tynnu orlifo, oherwydd bydd `a2 = a >> gcdpow` bob amser yn hollol fwy na `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // DIOGELWCH: Mae `a2` yn bŵer dau, fel y profwyd uchod.Mae `s2` yn hollol llai na `a2`
        // oherwydd bod `(s % a) >> gcdpow` yn hollol llai na `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ni ellir ei alinio o gwbl.
    usize::MAX
}

/// Cymharu awgrymiadau amrwd ar gyfer cydraddoldeb.
///
/// Mae hyn yr un peth â defnyddio'r gweithredwr `==`, ond yn llai generig:
/// rhaid i'r dadleuon fod yn awgrymiadau amrwd `*const T`, nid unrhyw beth sy'n gweithredu `PartialEq`.
///
/// Gellir defnyddio hyn i gymharu cyfeiriadau `&T` (sy'n cyd-fynd â `*const T` yn ymhlyg) yn ôl eu cyfeiriad yn hytrach na chymharu'r gwerthoedd y maent yn tynnu sylw atynt (sef yr hyn y mae gweithrediad `PartialEq for &T` yn ei wneud).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Mae tafelli hefyd yn cael eu cymharu yn ôl eu hyd (awgrymiadau braster):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Mae Traits hefyd yn cael eu cymharu gan eu gweithrediad:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Mae gan gynghorwyr gyfeiriadau cyfartal.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Mae gan wrthrychau gyfeiriadau cyfartal, ond mae gan `Trait` weithrediadau gwahanol.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Mae trosi'r cyfeiriad i `*const u8` yn cymharu yn ôl cyfeiriad.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash pwyntydd amrwd.
///
/// Gellir defnyddio hwn i hash cyfeirnod `&T` (sy'n gorfodi `*const T` yn ymhlyg) yn ôl ei gyfeiriad yn hytrach na'r gwerth y mae'n tynnu sylw ato (sef yr hyn y mae gweithrediad `Hash for &T` yn ei wneud).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls ar gyfer awgrymiadau swyddogaeth
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Mae angen y cast canolraddol fel usize ar gyfer AVR
                // fel bod gofod cyfeiriad pwyntydd y swyddogaeth ffynhonnell yn cael ei gadw yn y pwyntydd swyddogaeth derfynol.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Mae angen y cast canolraddol fel usize ar gyfer AVR
                // fel bod gofod cyfeiriad pwyntydd y swyddogaeth ffynhonnell yn cael ei gadw yn y pwyntydd swyddogaeth derfynol.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Dim swyddogaethau variadig gyda 0 paramedr
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Creu pwyntydd amrwd `const` i le, heb greu cyfeirnod canolradd.
///
/// Caniateir creu cyfeirnod gyda `&`/`&mut` dim ond os yw'r pwyntydd wedi'i alinio'n iawn ac yn pwyntio at ddata cychwynnol.
/// Ar gyfer achosion lle nad oes gan y gofynion hynny, dylid defnyddio awgrymiadau amrwd yn lle.
/// Fodd bynnag, mae `&expr as *const _` yn creu cyfeirnod cyn ei daflu at bwyntydd amrwd, ac mae'r cyfeiriad hwnnw'n ddarostyngedig i'r un rheolau â'r holl gyfeiriadau eraill.
///
/// Gall y macro hwn greu pwyntydd amrwd *heb* greu cyfeirnod yn gyntaf.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` yn creu cyfeiriad heb ei lofnodi, ac felly'n Ymddygiad Heb ei Ddylunio!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Creu pwyntydd amrwd `mut` i le, heb greu cyfeirnod canolradd.
///
/// Caniateir creu cyfeirnod gyda `&`/`&mut` dim ond os yw'r pwyntydd wedi'i alinio'n iawn ac yn pwyntio at ddata cychwynnol.
/// Ar gyfer achosion lle nad oes gan y gofynion hynny, dylid defnyddio awgrymiadau amrwd yn lle.
/// Fodd bynnag, mae `&mut expr as *mut _` yn creu cyfeirnod cyn ei daflu at bwyntydd amrwd, ac mae'r cyfeiriad hwnnw'n ddarostyngedig i'r un rheolau â'r holl gyfeiriadau eraill.
///
/// Gall y macro hwn greu pwyntydd amrwd *heb* greu cyfeirnod yn gyntaf.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` yn creu cyfeiriad heb ei lofnodi, ac felly'n Ymddygiad Heb ei Ddylunio!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` yn gorfodi copïo'r cae yn lle creu cyfeirnod.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}