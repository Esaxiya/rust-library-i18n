use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Yn dychwelyd `true` os yw'r pwyntydd yn null.
    ///
    /// Sylwch fod gan fathau heb eu mesur lawer o awgrymiadau null posibl, gan mai dim ond y pwyntydd data crai sy'n cael ei ystyried, nid eu hyd, eu hyfed, ac ati.
    /// Felly, mae'n bosibl na fydd dau awgrym sy'n null yn cymharu'n gyfartal â'i gilydd o hyd.
    ///
    /// ## Ymddygiad yn ystod gwerthuso const
    ///
    /// Pan ddefnyddir y swyddogaeth hon yn ystod gwerthuso const, gall ddychwelyd `false` ar gyfer awgrymiadau sy'n troi allan i fod yn null ar amser rhedeg.
    /// Yn benodol, pan fydd pwyntydd i ryw gof yn cael ei wrthbwyso y tu hwnt i'w ffiniau yn y fath fodd fel bod y pwyntydd sy'n deillio ohono yn null, bydd y swyddogaeth yn dal i ddychwelyd `false`.
    ///
    /// Nid oes unrhyw ffordd i CTFE wybod lleoliad absoliwt y cof hwnnw, felly ni allwn ddweud a yw'r pwyntydd yn null ai peidio.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Cymharwch trwy gast i bwyntydd tenau, felly dim ond ar gyfer null-ness y mae awgrymiadau braster yn ystyried eu rhan "data".
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Yn castio at bwyntydd o fath arall.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Dadelfennu pwyntydd (llydan o bosibl) i mewn yw cydrannau cyfeiriad a metadata.
    ///
    /// Gellir ailadeiladu'r pwyntydd yn ddiweddarach gyda [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Yn dychwelyd `None` os yw'r pwyntydd yn null, neu fel arall yn dychwelyd cyfeiriad a rennir at y gwerth sydd wedi'i lapio yn `Some`.Os gall y gwerth fod yn anfwriadol, rhaid defnyddio [`as_uninit_ref`] yn lle.
    ///
    /// Am y cymar mutable gweler [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Wrth alw'r dull hwn, mae'n rhaid i chi sicrhau bod *naill ai* y pwyntydd yn NULL *neu* mae pob un o'r canlynol yn wir:
    ///
    /// * Rhaid i'r pwyntydd gael ei alinio'n iawn.
    ///
    /// * Rhaid iddo fod yn "dereferencable" yn yr ystyr a ddiffinnir yn [the module documentation].
    ///
    /// * Rhaid i'r pwyntydd bwyntio at enghraifft gychwynnol o `T`.
    ///
    /// * Rhaid i chi orfodi rheolau gwyro Rust, gan fod yr oes a ddychwelwyd `'a` yn cael ei dewis yn fympwyol ac nid yw o reidrwydd yn adlewyrchu oes wirioneddol y data.
    ///   Yn benodol, trwy gydol yr oes hon, rhaid i'r cof y mae'r pwyntydd yn pwyntio ato beidio â threiglo (ac eithrio y tu mewn i `UnsafeCell`).
    ///
    /// Mae hyn yn berthnasol hyd yn oed os nad yw canlyniad y dull hwn yn cael ei ddefnyddio!
    /// (Nid yw'r rhan am gael ei sefydlu wedi ei phenderfynu'n llawn eto, ond hyd nes y bydd, yr unig ddull diogel yw sicrhau eu bod yn cael eu cychwyn yn wir.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Fersiwn heb ei wirio
    ///
    /// Os ydych chi'n siŵr na all y pwyntydd byth fod yn null ac yn chwilio am ryw fath o `as_ref_unchecked` sy'n dychwelyd yr `&T` yn lle `Option<&T>`, gwyddoch y gallwch chi ddad-gyfeirio'r pwyntydd yn uniongyrchol.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // DIOGELWCH: rhaid i'r galwr warantu bod `self` yn ddilys ar gyfer a
        // cyfeirnod os nad yw'n null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Yn dychwelyd `None` os yw'r pwyntydd yn null, neu fel arall yn dychwelyd cyfeiriad a rennir at y gwerth sydd wedi'i lapio yn `Some`.
    /// Mewn cyferbyniad â [`as_ref`], nid yw hyn yn gofyn bod yn rhaid cychwyn y gwerth.
    ///
    /// Am y cymar mutable gweler [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Wrth alw'r dull hwn, mae'n rhaid i chi sicrhau bod *naill ai* y pwyntydd yn NULL *neu* mae pob un o'r canlynol yn wir:
    ///
    /// * Rhaid i'r pwyntydd gael ei alinio'n iawn.
    ///
    /// * Rhaid iddo fod yn "dereferencable" yn yr ystyr a ddiffinnir yn [the module documentation].
    ///
    /// * Rhaid i chi orfodi rheolau gwyro Rust, gan fod yr oes a ddychwelwyd `'a` yn cael ei dewis yn fympwyol ac nid yw o reidrwydd yn adlewyrchu oes wirioneddol y data.
    ///
    ///   Yn benodol, trwy gydol yr oes hon, rhaid i'r cof y mae'r pwyntydd yn pwyntio ato beidio â threiglo (ac eithrio y tu mewn i `UnsafeCell`).
    ///
    /// Mae hyn yn berthnasol hyd yn oed os nad yw canlyniad y dull hwn yn cael ei ddefnyddio!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr warantu bod `self` yn cwrdd â'r holl
        // gofynion ar gyfer geirda.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Yn cyfrifo'r gwrthbwyso o bwyntydd.
    ///
    /// `count` mewn unedau o T;ee, mae `count` o 3 yn cynrychioli gwrthbwyso pwyntydd o beitiau `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Os bydd unrhyw un o'r amodau canlynol yn cael eu torri, y canlyniad yw Ymddygiad Heb ei ddiffinio:
    ///
    /// * Rhaid i'r pwyntydd cychwynnol a'r pwyntydd canlyniadol fod naill ai mewn ffiniau neu un beit heibio i ddiwedd yr un gwrthrych a ddyrannwyd.
    /// Sylwch, yn Rust, bod pob newidyn (stack-allocated) yn cael ei ystyried yn wrthrych a ddyrannwyd ar wahân.
    ///
    /// * Ni all y gwrthbwyso cyfrifedig,**mewn beitiau**, orlifo `isize`.
    ///
    /// * Ni all y gwrthbwyso sydd mewn ffiniau ddibynnu ar "wrapping around" y gofod cyfeiriad.Hynny yw, rhaid i'r swm manwl gywirdeb anfeidrol,**mewn beitiau** ffitio mewn usize.
    ///
    /// Yn gyffredinol, mae'r casglwr a'r llyfrgell safonol yn ceisio sicrhau nad yw dyraniadau byth yn cyrraedd maint lle mae gwrthbwyso yn bryder.
    /// Er enghraifft, mae `Vec` a `Box` yn sicrhau nad ydyn nhw byth yn dyrannu mwy na beit `isize::MAX`, felly mae `vec.as_ptr().add(vec.len())` bob amser yn ddiogel.
    ///
    /// Yn sylfaenol, ni all y mwyafrif o lwyfannau adeiladu dyraniad o'r fath hyd yn oed.
    /// Er enghraifft, ni all unrhyw blatfform 64-did hysbys gyflwyno cais am 2 <sup>63</sup> beit oherwydd cyfyngiadau bwrdd tudalen neu rannu'r gofod cyfeiriad.
    /// Fodd bynnag, gall rhai platfformau 32-did ac 16-did gyflwyno cais am fwy na beit `isize::MAX` yn llwyddiannus gyda phethau fel Estyniad Cyfeiriad Corfforol.
    ///
    /// O'r herwydd, gall cof a gafwyd yn uniongyrchol gan ddyranwyr neu ffeiliau wedi'u mapio â chof * fod yn rhy fawr i'w drin â'r swyddogaeth hon.
    ///
    /// Ystyriwch ddefnyddio [`wrapping_offset`] yn lle os yw'r cyfyngiadau hyn yn anodd eu bodloni.
    /// Yr unig Mantais y dull hwn yw ei fod yn galluogi optimeiddiad compiler yn fwy ymosodol.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `offset`.
        // Mae'r pwyntydd a gafwyd yn ddilys ar gyfer ysgrifennu gan fod yn rhaid i'r galwr warantu ei fod yn pwyntio at yr un gwrthrych a ddyrannwyd â `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Yn cyfrifo'r gwrthbwyso o bwyntydd gan ddefnyddio rhifyddeg lapio.
    /// `count` mewn unedau o T;ee, mae `count` o 3 yn cynrychioli gwrthbwyso pwyntydd o beitiau `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Mae'r llawdriniaeth hon ei hun bob amser yn ddiogel, ond nid yw defnyddio'r pwyntydd sy'n deillio o hynny.
    ///
    /// Mae'r pwyntydd sy'n deillio o hyn yn parhau i fod ynghlwm wrth yr un gwrthrych a ddyrannwyd y mae `self` yn pwyntio ato.
    /// Ni chaniateir ei ddefnyddio i gyrchu gwrthrych gwahanol a ddyrannwyd.Sylwch, yn Rust, bod pob newidyn (stack-allocated) yn cael ei ystyried yn wrthrych a ddyrannwyd ar wahân.
    ///
    /// Mewn geiriau eraill, nid yw `let z = x.wrapping_offset((y as isize) - (x as isize))`*yn* gwneud `z` yr un peth â `y` hyd yn oed os ydym yn tybio bod gan `T` faint `1` ac nad oes gorlif: mae `z` yn dal i fod ynghlwm wrth y gwrthrych y mae `x` ynghlwm wrtho, ac yn ei ddad-gyfeirio'n Ymddygiad Heb ei Ddiffinio oni bai bod `x` a Mae `y` yn pwyntio i'r un gwrthrych a ddyrannwyd.
    ///
    /// O'i gymharu â [`offset`], mae'r dull hwn yn y bôn yn gohirio'r gofyniad i aros o fewn yr un gwrthrych a ddyrannwyd: Mae [`offset`] yn Ymddygiad Heb ei ddiffinio ar unwaith wrth groesi ffiniau gwrthrychau;Mae `wrapping_offset` yn cynhyrchu pwyntydd ond mae'n dal i arwain at Ymddygiad Heb ei Ddiffinio os yw pwyntydd yn cael ei ddadreoleiddio pan fydd y tu allan i ffiniau'r gwrthrych y mae ynghlwm wrtho.
    /// [`offset`] gellir ei optimeiddio'n well ac felly mae'n well mewn cod sy'n sensitif i berfformiad.
    ///
    /// Nid yw'r gwiriad gohiriedig ond yn ystyried gwerth y pwyntydd a ddad-gyfeiriwyd, nid y gwerthoedd canolradd a ddefnyddiwyd wrth gyfrifo'r canlyniad terfynol.
    /// Er enghraifft, mae `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` bob amser yr un peth â `x`.Hynny yw, caniateir gadael y gwrthrych a ddyrannwyd ac yna ei ail-fynd yn ddiweddarach.
    ///
    /// Os oes angen i chi groesi ffiniau gwrthrychau, taflwch y pwyntydd i gyfanrif a gwnewch y rhifyddeg yno.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // Iterate gan ddefnyddio pwyntydd amrwd mewn cynyddrannau o ddwy elfen
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // DIOGELWCH: nid oes gan y cynhenid `arith_offset` unrhyw ragofynion i'w galw.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Yn dychwelyd `None` os yw'r pwyntydd yn null, neu fel arall yn dychwelyd cyfeiriad unigryw at y gwerth sydd wedi'i lapio yn `Some`.Os gall y gwerth fod yn anfwriadol, rhaid defnyddio [`as_uninit_mut`] yn lle.
    ///
    /// Am y cymar a rennir gweler [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Wrth alw'r dull hwn, mae'n rhaid i chi sicrhau bod *naill ai* y pwyntydd yn NULL *neu* mae pob un o'r canlynol yn wir:
    ///
    /// * Rhaid i'r pwyntydd gael ei alinio'n iawn.
    ///
    /// * Rhaid iddo fod yn "dereferencable" yn yr ystyr a ddiffinnir yn [the module documentation].
    ///
    /// * Rhaid i'r pwyntydd bwyntio at enghraifft gychwynnol o `T`.
    ///
    /// * Rhaid i chi orfodi rheolau gwyro Rust, gan fod yr oes a ddychwelwyd `'a` yn cael ei dewis yn fympwyol ac nid yw o reidrwydd yn adlewyrchu oes wirioneddol y data.
    ///   Yn benodol, trwy gydol yr oes hon, rhaid i'r cof y mae'r pwyntydd yn pwyntio ato beidio â chael mynediad (darllen neu ysgrifennu) trwy unrhyw bwyntydd arall.
    ///
    /// Mae hyn yn berthnasol hyd yn oed os nad yw canlyniad y dull hwn yn cael ei ddefnyddio!
    /// (Nid yw'r rhan am gael ei sefydlu wedi ei phenderfynu'n llawn eto, ond hyd nes y bydd, yr unig ddull diogel yw sicrhau eu bod yn cael eu cychwyn yn wir.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Bydd yn argraffu: "[4, 2, 3]".
    /// ```
    ///
    /// # Fersiwn heb ei wirio
    ///
    /// Os ydych chi'n siŵr na all y pwyntydd byth fod yn null ac yn chwilio am ryw fath o `as_mut_unchecked` sy'n dychwelyd yr `&mut T` yn lle `Option<&mut T>`, gwyddoch y gallwch chi ddad-gyfeirio'r pwyntydd yn uniongyrchol.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Bydd yn argraffu: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // DIOGELWCH: rhaid i'r galwr warantu bod `self` yn ddilys ar ei gyfer
        // cyfeiriad symudol os nad yw'n null.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Yn dychwelyd `None` os yw'r pwyntydd yn null, neu fel arall yn dychwelyd cyfeiriad unigryw at y gwerth sydd wedi'i lapio yn `Some`.
    /// Mewn cyferbyniad â [`as_mut`], nid yw hyn yn gofyn bod yn rhaid cychwyn y gwerth.
    ///
    /// Am y cymar a rennir gweler [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Wrth alw'r dull hwn, mae'n rhaid i chi sicrhau bod *naill ai* y pwyntydd yn NULL *neu* mae pob un o'r canlynol yn wir:
    ///
    /// * Rhaid i'r pwyntydd gael ei alinio'n iawn.
    ///
    /// * Rhaid iddo fod yn "dereferencable" yn yr ystyr a ddiffinnir yn [the module documentation].
    ///
    /// * Rhaid i chi orfodi rheolau gwyro Rust, gan fod yr oes a ddychwelwyd `'a` yn cael ei dewis yn fympwyol ac nid yw o reidrwydd yn adlewyrchu oes wirioneddol y data.
    ///
    ///   Yn benodol, trwy gydol yr oes hon, rhaid i'r cof y mae'r pwyntydd yn pwyntio ato beidio â chael mynediad (darllen neu ysgrifennu) trwy unrhyw bwyntydd arall.
    ///
    /// Mae hyn yn berthnasol hyd yn oed os nad yw canlyniad y dull hwn yn cael ei ddefnyddio!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr warantu bod `self` yn cwrdd â'r holl
        // gofynion ar gyfer geirda.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Yn dychwelyd a yw dau awgrym yn sicr o fod yn gyfartal.
    ///
    /// Ar amser rhedeg mae'r swyddogaeth hon yn ymddwyn fel `self == other`.
    /// Fodd bynnag, mewn rhai cyd-destunau (ee gwerthuso amser-llunio), nid yw bob amser yn bosibl pennu cydraddoldeb dau awgrym, felly gall y swyddogaeth hon ddychwelyd `false` yn ysbeidiol ar gyfer awgrymiadau sydd yn ddiweddarach yn troi allan i fod yn gyfartal.
    ///
    /// Ond pan fydd yn dychwelyd `true`, mae'r awgrymiadau'n sicr o fod yn gyfartal.
    ///
    /// Y swyddogaeth hon yw drych [`guaranteed_ne`], ond nid ei wrthdro.Mae cymariaethau pwyntydd y mae'r ddwy swyddogaeth yn dychwelyd `false` ar eu cyfer.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Efallai y bydd y gwerth dychwelyd yn dibynnu ar y fersiwn crynhowr ac efallai na fydd y cod anniogel yn dibynnu ar ganlyniad y swyddogaeth hon er cadernid.
    /// Awgrymir defnyddio'r swyddogaeth hon ar gyfer optimeiddiadau perfformiad yn unig lle nad yw gwerthoedd dychwelyd `false` ysblennydd gan y swyddogaeth hon yn effeithio ar y canlyniad, ond ar y perfformiad yn unig.
    /// Nid archwiliwyd canlyniadau defnyddio'r dull hwn i wneud i amser rhedeg a llunio amser-amser ymddwyn yn wahanol.
    /// Ni ddylid defnyddio'r dull hwn i gyflwyno gwahaniaethau o'r fath, ac ni ddylid ei sefydlogi hefyd cyn bod gennym well dealltwriaeth o'r mater hwn.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Yn dychwelyd a yw dau awgrym yn sicr o fod yn anghyfartal.
    ///
    /// Ar amser rhedeg mae'r swyddogaeth hon yn ymddwyn fel `self != other`.
    /// Fodd bynnag, mewn rhai cyd-destunau (ee gwerthuso amser llunio), nid yw bob amser yn bosibl pennu anghydraddoldeb dau awgrym, felly gall y swyddogaeth hon ddychwelyd `false` yn ysbeidiol ar gyfer awgrymiadau sydd yn ddiweddarach yn anghyfartal mewn gwirionedd.
    ///
    /// Ond pan fydd yn dychwelyd `true`, mae'r awgrymiadau'n sicr o fod yn anghyfartal.
    ///
    /// Y swyddogaeth hon yw drych [`guaranteed_eq`], ond nid ei wrthdro.Mae cymariaethau pwyntydd y mae'r ddwy swyddogaeth yn dychwelyd `false` ar eu cyfer.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Efallai y bydd y gwerth dychwelyd yn dibynnu ar y fersiwn crynhowr ac efallai na fydd y cod anniogel yn dibynnu ar ganlyniad y swyddogaeth hon er cadernid.
    /// Awgrymir defnyddio'r swyddogaeth hon ar gyfer optimeiddiadau perfformiad yn unig lle nad yw gwerthoedd dychwelyd `false` ysblennydd gan y swyddogaeth hon yn effeithio ar y canlyniad, ond ar y perfformiad yn unig.
    /// Nid archwiliwyd canlyniadau defnyddio'r dull hwn i wneud i amser rhedeg a llunio amser-amser ymddwyn yn wahanol.
    /// Ni ddylid defnyddio'r dull hwn i gyflwyno gwahaniaethau o'r fath, ac ni ddylid ei sefydlogi hefyd cyn bod gennym well dealltwriaeth o'r mater hwn.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Yn cyfrifo'r pellter rhwng dau awgrym.Mae'r gwerth a ddychwelwyd mewn unedau o T: rhennir y pellter mewn beitiau â `mem::size_of::<T>()`.
    ///
    /// Y swyddogaeth hon yw gwrthdro [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Os bydd unrhyw un o'r amodau canlynol yn cael eu torri, y canlyniad yw Ymddygiad Heb ei ddiffinio:
    ///
    /// * Rhaid i'r pwyntydd cychwyn a'r pwyntydd arall fod naill ai mewn ffiniau neu un beit heibio i ddiwedd yr un gwrthrych a ddyrannwyd.
    /// Sylwch, yn Rust, bod pob newidyn (stack-allocated) yn cael ei ystyried yn wrthrych a ddyrannwyd ar wahân.
    ///
    /// * Mae'n rhaid i'r ddau awgrymiadau ddeillio *o* pwyntydd i'r un gwrthrych.
    ///   (Gweler isod am enghraifft.)
    ///
    /// * Rhaid i'r pellter rhwng yr awgrymiadau, mewn beitiau, fod yn lluosrif union o faint `T`.
    ///
    /// * Ni all y pellter rhwng yr awgrymiadau,**mewn beitiau**, orlifo `isize`.
    ///
    /// * Ni all y pellter sydd mewn ffiniau ddibynnu ar "wrapping around" y gofod cyfeiriad.
    ///
    /// Nid yw mathau Rust byth yn fwy na dyraniadau `isize::MAX` a Rust byth yn lapio o amgylch y gofod cyfeiriad, felly bydd dau awgrym o fewn rhywfaint o werth i unrhyw fath `isize::MAX` Rust bob amser yn bodloni'r ddau amod olaf.
    ///
    /// Mae'r llyfrgell safonol hefyd yn gyffredinol yn sicrhau nad yw dyraniadau byth yn cyrraedd maint lle mae gwrthbwyso yn bryder.
    /// Er enghraifft, mae `Vec` a `Box` yn sicrhau nad ydyn nhw byth yn dyrannu mwy na beit `isize::MAX`, felly mae `ptr_into_vec.offset_from(vec.as_ptr())` bob amser yn bodloni'r ddau amod olaf.
    ///
    /// Yn sylfaenol, ni all y mwyafrif o lwyfannau adeiladu dyraniad mor fawr hyd yn oed.
    /// Er enghraifft, ni all unrhyw blatfform 64-did hysbys gyflwyno cais am 2 <sup>63</sup> beit oherwydd cyfyngiadau bwrdd tudalen neu rannu'r gofod cyfeiriad.
    /// Fodd bynnag, gall rhai platfformau 32-did ac 16-did gyflwyno cais am fwy na beit `isize::MAX` yn llwyddiannus gyda phethau fel Estyniad Cyfeiriad Corfforol.
    /// O'r herwydd, gall cof a gafwyd yn uniongyrchol gan ddyranwyr neu ffeiliau wedi'u mapio â chof * fod yn rhy fawr i'w drin â'r swyddogaeth hon.
    /// (Sylwch fod gan [`offset`] a [`add`] gyfyngiad tebyg hefyd ac felly ni ellir eu defnyddio ar ddyraniadau mor fawr chwaith.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Mae'r swyddogaeth hon panics os yw `T` yn Math Zero-Sized ("ZST").
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// Defnydd *anghywir*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Gwnewch ptr2_other yn "alias" o ptr2, ond mae'n deillio o ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Gan fod ptr2_other a ptr2 yn deillio o awgrymiadau i wahanol wrthrychau, mae cyfrifiadura eu gwrthbwyso yn ymddygiad heb ei ddiffinio, er eu bod yn pwyntio i'r un cyfeiriad!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Ymddygiad heb ei ddiffinio
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Yn cyfrifo'r gwrthbwyso o bwyntydd (cyfleustra ar gyfer `.offset(count as isize)`).
    ///
    /// `count` mewn unedau o T;ee, mae `count` o 3 yn cynrychioli gwrthbwyso pwyntydd o beitiau `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Os bydd unrhyw un o'r amodau canlynol yn cael eu torri, y canlyniad yw Ymddygiad Heb ei ddiffinio:
    ///
    /// * Rhaid i'r pwyntydd cychwynnol a'r pwyntydd canlyniadol fod naill ai mewn ffiniau neu un beit heibio i ddiwedd yr un gwrthrych a ddyrannwyd.
    /// Sylwch, yn Rust, bod pob newidyn (stack-allocated) yn cael ei ystyried yn wrthrych a ddyrannwyd ar wahân.
    ///
    /// * Ni all y gwrthbwyso cyfrifedig,**mewn beitiau**, orlifo `isize`.
    ///
    /// * Ni all y gwrthbwyso sydd mewn ffiniau ddibynnu ar "wrapping around" y gofod cyfeiriad.Hynny yw, rhaid i'r swm anfeidrol-gywirdeb ffitio mewn `usize`.
    ///
    /// Yn gyffredinol, mae'r casglwr a'r llyfrgell safonol yn ceisio sicrhau nad yw dyraniadau byth yn cyrraedd maint lle mae gwrthbwyso yn bryder.
    /// Er enghraifft, mae `Vec` a `Box` yn sicrhau nad ydyn nhw byth yn dyrannu mwy na beit `isize::MAX`, felly mae `vec.as_ptr().add(vec.len())` bob amser yn ddiogel.
    ///
    /// Yn sylfaenol, ni all y mwyafrif o lwyfannau adeiladu dyraniad o'r fath hyd yn oed.
    /// Er enghraifft, ni all unrhyw blatfform 64-did hysbys gyflwyno cais am 2 <sup>63</sup> beit oherwydd cyfyngiadau bwrdd tudalen neu rannu'r gofod cyfeiriad.
    /// Fodd bynnag, gall rhai platfformau 32-did ac 16-did gyflwyno cais am fwy na beit `isize::MAX` yn llwyddiannus gyda phethau fel Estyniad Cyfeiriad Corfforol.
    ///
    /// O'r herwydd, gall cof a gafwyd yn uniongyrchol gan ddyranwyr neu ffeiliau wedi'u mapio â chof * fod yn rhy fawr i'w drin â'r swyddogaeth hon.
    ///
    /// Ystyriwch ddefnyddio [`wrapping_add`] yn lle os yw'r cyfyngiadau hyn yn anodd eu bodloni.
    /// Yr unig Mantais y dull hwn yw ei fod yn galluogi optimeiddiad compiler yn fwy ymosodol.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Yn cyfrifo'r gwrthbwyso o bwyntydd (cyfleustra ar gyfer `.offset ((cyfrif fel isize).wrapping_neg())`).)
    ///
    /// `count` mewn unedau o T;ee, mae `count` o 3 yn cynrychioli gwrthbwyso pwyntydd o beitiau `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Os bydd unrhyw un o'r amodau canlynol yn cael eu torri, y canlyniad yw Ymddygiad Heb ei ddiffinio:
    ///
    /// * Rhaid i'r pwyntydd cychwynnol a'r pwyntydd canlyniadol fod naill ai mewn ffiniau neu un beit heibio i ddiwedd yr un gwrthrych a ddyrannwyd.
    /// Sylwch, yn Rust, bod pob newidyn (stack-allocated) yn cael ei ystyried yn wrthrych a ddyrannwyd ar wahân.
    ///
    /// * Ni all y gwrthbwyso cyfrifedig fod yn fwy na beitiau `isize::MAX` **.
    ///
    /// * Ni all y gwrthbwyso sydd mewn ffiniau ddibynnu ar "wrapping around" y gofod cyfeiriad.Hynny yw, rhaid i'r swm manwl gywirdeb anfeidrol ffitio mewn defnydd.
    ///
    /// Yn gyffredinol, mae'r casglwr a'r llyfrgell safonol yn ceisio sicrhau nad yw dyraniadau byth yn cyrraedd maint lle mae gwrthbwyso yn bryder.
    /// Er enghraifft, mae `Vec` a `Box` yn sicrhau nad ydyn nhw byth yn dyrannu mwy na beit `isize::MAX`, felly mae `vec.as_ptr().add(vec.len()).sub(vec.len())` bob amser yn ddiogel.
    ///
    /// Yn sylfaenol, ni all y mwyafrif o lwyfannau adeiladu dyraniad o'r fath hyd yn oed.
    /// Er enghraifft, ni all unrhyw blatfform 64-did hysbys gyflwyno cais am 2 <sup>63</sup> beit oherwydd cyfyngiadau bwrdd tudalen neu rannu'r gofod cyfeiriad.
    /// Fodd bynnag, gall rhai platfformau 32-did ac 16-did gyflwyno cais am fwy na beit `isize::MAX` yn llwyddiannus gyda phethau fel Estyniad Cyfeiriad Corfforol.
    ///
    /// O'r herwydd, gall cof a gafwyd yn uniongyrchol gan ddyranwyr neu ffeiliau wedi'u mapio â chof * fod yn rhy fawr i'w drin â'r swyddogaeth hon.
    ///
    /// Ystyriwch ddefnyddio [`wrapping_sub`] yn lle os yw'r cyfyngiadau hyn yn anodd eu bodloni.
    /// Yr unig Mantais y dull hwn yw ei fod yn galluogi optimeiddiad compiler yn fwy ymosodol.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Yn cyfrifo'r gwrthbwyso o bwyntydd gan ddefnyddio rhifyddeg lapio.
    /// (cyfleustra i `.wrapping_offset(count as isize)`)
    ///
    /// `count` mewn unedau o T;ee, mae `count` o 3 yn cynrychioli gwrthbwyso pwyntydd o beitiau `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Mae'r llawdriniaeth hon ei hun bob amser yn ddiogel, ond nid yw defnyddio'r pwyntydd sy'n deillio o hynny.
    ///
    /// Mae'r pwyntydd sy'n deillio o hyn yn parhau i fod ynghlwm wrth yr un gwrthrych a ddyrannwyd y mae `self` yn pwyntio ato.
    /// Ni chaniateir ei ddefnyddio i gyrchu gwrthrych gwahanol a ddyrannwyd.Sylwch, yn Rust, bod pob newidyn (stack-allocated) yn cael ei ystyried yn wrthrych a ddyrannwyd ar wahân.
    ///
    /// Mewn geiriau eraill, nid yw `let z = x.wrapping_add((y as usize) - (x as usize))`*yn* gwneud `z` yr un peth â `y` hyd yn oed os ydym yn tybio bod gan `T` faint `1` ac nad oes gorlif: mae `z` yn dal i fod ynghlwm wrth y gwrthrych y mae `x` ynghlwm wrtho, ac yn ei ddad-gyfeirio'n Ymddygiad Heb ei Ddiffinio oni bai bod `x` a Mae `y` yn pwyntio i'r un gwrthrych a ddyrannwyd.
    ///
    /// O'i gymharu â [`add`], mae'r dull hwn yn y bôn yn gohirio'r gofyniad i aros o fewn yr un gwrthrych a ddyrannwyd: Mae [`add`] yn Ymddygiad Heb ei Ddiffinio ar unwaith wrth groesi ffiniau gwrthrychau;Mae `wrapping_add` yn cynhyrchu pwyntydd ond mae'n dal i arwain at Ymddygiad Heb ei Ddiffinio os yw pwyntydd yn cael ei ddadreoleiddio pan fydd y tu allan i ffiniau'r gwrthrych y mae ynghlwm wrtho.
    /// [`add`] gellir ei optimeiddio'n well ac felly mae'n well mewn cod sy'n sensitif i berfformiad.
    ///
    /// Nid yw'r gwiriad gohiriedig ond yn ystyried gwerth y pwyntydd a ddad-gyfeiriwyd, nid y gwerthoedd canolradd a ddefnyddiwyd wrth gyfrifo'r canlyniad terfynol.
    /// Er enghraifft, mae `x.wrapping_add(o).wrapping_sub(o)` bob amser yr un peth â `x`.Hynny yw, caniateir gadael y gwrthrych a ddyrannwyd ac yna ei ail-fynd yn ddiweddarach.
    ///
    /// Os oes angen i chi groesi ffiniau gwrthrychau, taflwch y pwyntydd i gyfanrif a gwnewch y rhifyddeg yno.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // Iterate gan ddefnyddio pwyntydd amrwd mewn cynyddrannau o ddwy elfen
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Mae'r ddolen hon yn argraffu "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Yn cyfrifo'r gwrthbwyso o bwyntydd gan ddefnyddio rhifyddeg lapio.
    /// (cyfleustra ar gyfer `.wrapping_offset ((cyfrif fel isize).wrapping_neg())`).)
    ///
    /// `count` mewn unedau o T;ee, mae `count` o 3 yn cynrychioli gwrthbwyso pwyntydd o beitiau `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Mae'r llawdriniaeth hon ei hun bob amser yn ddiogel, ond nid yw defnyddio'r pwyntydd sy'n deillio o hynny.
    ///
    /// Mae'r pwyntydd sy'n deillio o hyn yn parhau i fod ynghlwm wrth yr un gwrthrych a ddyrannwyd y mae `self` yn pwyntio ato.
    /// Ni chaniateir ei ddefnyddio i gyrchu gwrthrych gwahanol a ddyrannwyd.Sylwch, yn Rust, bod pob newidyn (stack-allocated) yn cael ei ystyried yn wrthrych a ddyrannwyd ar wahân.
    ///
    /// Mewn geiriau eraill, nid yw `let z = x.wrapping_sub((x as usize) - (y as usize))`*yn* gwneud `z` yr un peth â `y` hyd yn oed os ydym yn tybio bod gan `T` faint `1` ac nad oes gorlif: mae `z` yn dal i fod ynghlwm wrth y gwrthrych y mae `x` ynghlwm wrtho, ac yn ei ddad-gyfeirio'n Ymddygiad Heb ei Ddiffinio oni bai bod `x` a Mae `y` yn pwyntio i'r un gwrthrych a ddyrannwyd.
    ///
    /// O'i gymharu â [`sub`], mae'r dull hwn yn y bôn yn gohirio'r gofyniad i aros o fewn yr un gwrthrych a ddyrannwyd: Mae [`sub`] yn Ymddygiad Heb ei Ddiffinio ar unwaith wrth groesi ffiniau gwrthrychau;Mae `wrapping_sub` yn cynhyrchu pwyntydd ond mae'n dal i arwain at Ymddygiad Heb ei Ddiffinio os yw pwyntydd yn cael ei ddadreoleiddio pan fydd y tu allan i ffiniau'r gwrthrych y mae ynghlwm wrtho.
    /// [`sub`] gellir ei optimeiddio'n well ac felly mae'n well mewn cod sy'n sensitif i berfformiad.
    ///
    /// Nid yw'r gwiriad gohiriedig ond yn ystyried gwerth y pwyntydd a ddad-gyfeiriwyd, nid y gwerthoedd canolradd a ddefnyddiwyd wrth gyfrifo'r canlyniad terfynol.
    /// Er enghraifft, mae `x.wrapping_add(o).wrapping_sub(o)` bob amser yr un peth â `x`.Hynny yw, caniateir gadael y gwrthrych a ddyrannwyd ac yna ei ail-fynd yn ddiweddarach.
    ///
    /// Os oes angen i chi groesi ffiniau gwrthrychau, taflwch y pwyntydd i gyfanrif a gwnewch y rhifyddeg yno.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// // Iterate gan ddefnyddio pwyntydd amrwd mewn cynyddrannau o ddwy elfen (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Mae'r ddolen hon yn argraffu "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Yn gosod gwerth y pwyntydd i `ptr`.
    ///
    /// Rhag ofn bod `self` yn pwyntydd (fat) i fath heb ei feintioli, bydd y llawdriniaeth hon yn effeithio ar ran y pwyntydd yn unig, ond ar gyfer awgrymiadau (thin) i fathau o faint, mae hyn yn cael yr un effaith ag aseiniad syml.
    ///
    /// Bydd gan y pwyntydd sy'n deillio o hyn darddiad `val`, hy, ar gyfer pwyntydd braster, mae'r llawdriniaeth hon yr un peth yn semantig â chreu pwyntydd braster newydd gyda gwerth pwyntydd data `val` ond metadata `self`.
    ///
    ///
    /// # Examples
    ///
    /// Mae'r swyddogaeth hon yn ddefnyddiol yn bennaf ar gyfer caniatáu rhifyddeg pwyntydd doeth-ddoeth ar awgrymiadau a allai fod yn dew:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // yn argraffu "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // DIOGELWCH: Mewn achos pwyntydd tenau, mae'r gweithrediadau hyn yn union yr un fath
        // i aseiniad syml.
        // Mewn achos o bwyntydd braster, gyda'r cynllun pwyntydd braster cyfredol yn cael ei weithredu, maes cyntaf pwyntydd o'r fath yw'r pwyntydd data bob amser, a roddir yn yr un modd.
        //
        unsafe { *thin = val };
        self
    }

    /// Yn darllen y gwerth o `self` heb ei symud.
    /// Mae hyn yn gadael y cof yn `self` yn ddigyfnewid.
    ///
    /// Gweler [`ptr::read`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer ``.
        unsafe { read(self) }
    }

    /// Yn perfformio darlleniad cyfnewidiol o'r gwerth o `self` heb ei symud.Mae hyn yn gadael y cof yn `self` yn ddigyfnewid.
    ///
    /// Bwriad gweithrediadau cyfnewidiol yw gweithredu ar gof I/O, ac maent yn sicr na fyddant yn cael eu twyllo na'u had-drefnu gan y casglwr ar draws gweithrediadau cyfnewidiol eraill.
    ///
    ///
    /// Gweler [`ptr::read_volatile`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Yn darllen y gwerth o `self` heb ei symud.
    /// Mae hyn yn gadael y cof yn `self` yn ddigyfnewid.
    ///
    /// Yn wahanol i `read`, gall y pwyntydd fod heb ei lofnodi.
    ///
    /// Gweler [`ptr::read_unaligned`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Copïau o beitiau `count * size_of<T>` o `self` i `dest`.
    /// Gall y ffynhonnell a'r gyrchfan orgyffwrdd.
    ///
    /// NOTE: mae gan hwn yr un drefn ddadl * â [`ptr::copy`].
    ///
    /// Gweler [`ptr::copy`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Copïau o beitiau `count * size_of<T>` o `self` i `dest`.
    /// Efallai na fydd y ffynhonnell a'r gyrchfan yn gorgyffwrdd *.
    ///
    /// NOTE: mae gan hwn yr un drefn ddadl * â [`ptr::copy_nonoverlapping`].
    ///
    /// Gweler [`ptr::copy_nonoverlapping`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Copïau o beitiau `count * size_of<T>` o `src` i `self`.
    /// Gall y ffynhonnell a'r gyrchfan orgyffwrdd.
    ///
    /// NOTE: mae gan hwn y drefn ddadl *gyferbyn* o [`ptr::copy`].
    ///
    /// Gweler [`ptr::copy`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Copïau o beitiau `count * size_of<T>` o `src` i `self`.
    /// Efallai na fydd y ffynhonnell a'r gyrchfan yn gorgyffwrdd *.
    ///
    /// NOTE: mae gan hwn y drefn ddadl *gyferbyn* o [`ptr::copy_nonoverlapping`].
    ///
    /// Gweler [`ptr::copy_nonoverlapping`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Yn cyflawni dinistriwr (os oes un) y gwerth pwyntiedig.
    ///
    /// Gweler [`ptr::drop_in_place`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Yn trosysgrifo lleoliad cof gyda'r gwerth a roddir heb ddarllen na gollwng yr hen werth.
    ///
    ///
    /// Gweler [`ptr::write`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `write`.
        unsafe { write(self, val) }
    }

    /// Yn galw memset ar y pwyntydd penodedig, gan osod beitiau cof `count * size_of::<T>()` gan ddechrau yn `self` i `val`.
    ///
    ///
    /// Gweler [`ptr::write_bytes`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Yn perfformio ysgrifen gyfnewidiol o leoliad cof gyda'r gwerth penodol heb ddarllen na gollwng yr hen werth.
    ///
    /// Bwriad gweithrediadau cyfnewidiol yw gweithredu ar gof I/O, ac maent yn sicr na fyddant yn cael eu twyllo na'u had-drefnu gan y casglwr ar draws gweithrediadau cyfnewidiol eraill.
    ///
    ///
    /// Gweler [`ptr::write_volatile`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Yn trosysgrifo lleoliad cof gyda'r gwerth a roddir heb ddarllen na gollwng yr hen werth.
    ///
    ///
    /// Yn wahanol i `write`, gall y pwyntydd fod heb ei lofnodi.
    ///
    /// Gweler [`ptr::write_unaligned`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Yn disodli'r gwerth yn `self` gyda `src`, gan ddychwelyd yr hen werth, heb ollwng y naill na'r llall.
    ///
    ///
    /// Gweler [`ptr::replace`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `replace`.
        unsafe { replace(self, src) }
    }

    /// Yn cyfnewid y gwerthoedd mewn dau leoliad symudol o'r un math, heb ddad-ddyneiddio'r naill na'r llall.
    /// Gallant orgyffwrdd, yn wahanol i `mem::swap` sydd fel arall yn gyfwerth.
    ///
    /// Gweler [`ptr::swap`] am bryderon ac enghreifftiau diogelwch.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `swap`.
        unsafe { swap(self, with) }
    }

    /// Yn cywasgu'r gwrthbwyso y mae angen ei gymhwyso i'r pwyntydd er mwyn ei alinio â `align`.
    ///
    /// Os nad yw'n bosibl alinio'r pwyntydd, mae'r gweithredu'n dychwelyd `usize::MAX`.
    /// Caniateir i'r gweithredu ddychwelyd *bob amser*`usize::MAX`.
    /// Dim ond perfformiad eich algorithm all ddibynnu ar gael gwrthbwyso defnyddiadwy yma, nid ei gywirdeb.
    ///
    /// Mynegir y gwrthbwyso yn nifer yr elfennau `T`, ac nid beit.Gellir defnyddio'r gwerth a ddychwelwyd gyda'r dull `wrapping_add`.
    ///
    /// Nid oes unrhyw warantau o gwbl na fydd gwrthbwyso'r pwyntydd yn gorlifo nac yn mynd y tu hwnt i'r dyraniad y mae'r pwyntydd yn tynnu sylw ato.
    ///
    /// Mater i'r galwr yw sicrhau bod y gwrthbwyso a ddychwelwyd yn gywir ym mhob term heblaw aliniad.
    ///
    /// # Panics
    ///
    /// Mae'r swyddogaeth panics os nad yw `align` yn bŵer dau.
    ///
    /// # Examples
    ///
    /// Cyrchu `u8` cyfagos fel `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // er y gellir alinio'r pwyntydd trwy `offset`, byddai'n pwyntio y tu allan i'r dyraniad
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // DIOGELWCH: Gwiriwyd bod `align` yn bŵer 2 uchod
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Yn dychwelyd hyd tafell amrwd.
    ///
    /// Y gwerth a ddychwelwyd yw nifer yr **elfennau**, nid nifer y bytes.
    ///
    /// Mae'r swyddogaeth hon yn ddiogel, hyd yn oed pan na ellir bwrw'r sleisen amrwd i gyfeirnod tafell oherwydd bod y pwyntydd yn null neu heb ei lofnodi.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // DIOGELWCH: mae hyn yn ddiogel oherwydd bod gan `*const [T]` a `FatPtr<T>` yr un cynllun.
            // Dim ond `std` all wneud y warant hon.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Yn dychwelyd pwyntydd amrwd i byffer y dafell.
    ///
    /// Mae hyn yn cyfateb i gastio `self` i `*mut T`, ond yn fwy diogel o ran math.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Yn dychwelyd pwyntydd amrwd i elfen neu aruchel, heb wirio ffiniau.
    ///
    /// Mae galw'r dull hwn gyda mynegai y tu allan i ffiniau neu pan nad yw `self` yn ddadreferenadwy yn *[ymddygiad heb ei ddiffinio]* hyd yn oed os na ddefnyddir y pwyntydd sy'n deillio o hynny.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // DIOGELWCH: mae'r galwr yn sicrhau bod `self` yn ddereferencable a `index` mewn ffiniau.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Yn dychwelyd `None` os yw'r pwyntydd yn null, neu fel arall yn dychwelyd tafell a rennir i'r gwerth sydd wedi'i lapio yn `Some`.
    /// Mewn cyferbyniad â [`as_ref`], nid yw hyn yn gofyn bod yn rhaid cychwyn y gwerth.
    ///
    /// Am y cymar mutable gweler [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Wrth alw'r dull hwn, mae'n rhaid i chi sicrhau bod *naill ai* y pwyntydd yn NULL *neu* mae pob un o'r canlynol yn wir:
    ///
    /// * Rhaid i'r pwyntydd fod yn [valid] ar gyfer darlleniadau ar gyfer `ptr.len() * mem::size_of::<T>()` llawer o beit, a rhaid ei alinio'n iawn.Mae hyn yn golygu yn benodol:
    ///
    ///     * Rhaid cynnwys ystod cof gyfan y dafell hon mewn un gwrthrych a ddyrannwyd!
    ///       Ni all tafelli fyth rychwantu sawl gwrthrych a ddyrannwyd.
    ///
    ///     * Rhaid i'r pwyntydd gael ei alinio hyd yn oed ar gyfer sleisys hyd sero.
    ///     Un rheswm am hyn yw y gall optimeiddiadau cynllun enwm ddibynnu ar gyfeiriadau (gan gynnwys sleisys o unrhyw hyd) yn cael eu halinio a heb fod yn null i'w gwahaniaethu oddi wrth ddata arall.
    ///
    ///     Gallwch gael pwyntydd y gellir ei ddefnyddio fel `data` ar gyfer sleisys hyd sero gan ddefnyddio [`NonNull::dangling()`].
    ///
    /// * Rhaid i gyfanswm maint `ptr.len() * mem::size_of::<T>()` y dafell beidio â bod yn fwy na `isize::MAX`.
    ///   Gweler dogfennaeth ddiogelwch [`pointer::offset`].
    ///
    /// * Rhaid i chi orfodi rheolau gwyro Rust, gan fod yr oes a ddychwelwyd `'a` yn cael ei dewis yn fympwyol ac nid yw o reidrwydd yn adlewyrchu oes wirioneddol y data.
    ///   Yn benodol, trwy gydol yr oes hon, rhaid i'r cof y mae'r pwyntydd yn pwyntio ato beidio â threiglo (ac eithrio y tu mewn i `UnsafeCell`).
    ///
    /// Mae hyn yn berthnasol hyd yn oed os nad yw canlyniad y dull hwn yn cael ei ddefnyddio!
    ///
    /// Gweler hefyd [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Yn dychwelyd `None` os yw'r pwyntydd yn null, neu fel arall yn dychwelyd tafell unigryw i'r gwerth sydd wedi'i lapio yn `Some`.
    /// Mewn cyferbyniad â [`as_mut`], nid yw hyn yn gofyn bod yn rhaid cychwyn y gwerth.
    ///
    /// Am y cymar a rennir gweler [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Wrth alw'r dull hwn, mae'n rhaid i chi sicrhau bod *naill ai* y pwyntydd yn NULL *neu* mae pob un o'r canlynol yn wir:
    ///
    /// * Rhaid i'r pwyntydd fod yn [valid] ar gyfer darllen ac ysgrifennu ar gyfer `ptr.len() * mem::size_of::<T>()` llawer o beit, a rhaid ei alinio'n iawn.Mae hyn yn golygu yn benodol:
    ///
    ///     * Rhaid cynnwys ystod cof gyfan y dafell hon mewn un gwrthrych a ddyrannwyd!
    ///       Ni all tafelli fyth rychwantu sawl gwrthrych a ddyrannwyd.
    ///
    ///     * Rhaid i'r pwyntydd gael ei alinio hyd yn oed ar gyfer sleisys hyd sero.
    ///     Un rheswm am hyn yw y gall optimeiddiadau cynllun enwm ddibynnu ar gyfeiriadau (gan gynnwys sleisys o unrhyw hyd) yn cael eu halinio a heb fod yn null i'w gwahaniaethu oddi wrth ddata arall.
    ///
    ///     Gallwch gael pwyntydd y gellir ei ddefnyddio fel `data` ar gyfer sleisys hyd sero gan ddefnyddio [`NonNull::dangling()`].
    ///
    /// * Rhaid i gyfanswm maint `ptr.len() * mem::size_of::<T>()` y dafell beidio â bod yn fwy na `isize::MAX`.
    ///   Gweler dogfennaeth ddiogelwch [`pointer::offset`].
    ///
    /// * Rhaid i chi orfodi rheolau gwyro Rust, gan fod yr oes a ddychwelwyd `'a` yn cael ei dewis yn fympwyol ac nid yw o reidrwydd yn adlewyrchu oes wirioneddol y data.
    ///   Yn benodol, trwy gydol yr oes hon, rhaid i'r cof y mae'r pwyntydd yn pwyntio ato beidio â chael mynediad (darllen neu ysgrifennu) trwy unrhyw bwyntydd arall.
    ///
    /// Mae hyn yn berthnasol hyd yn oed os nad yw canlyniad y dull hwn yn cael ei ddefnyddio!
    ///
    /// Gweler hefyd [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Cydraddoldeb ar gyfer awgrymiadau
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}