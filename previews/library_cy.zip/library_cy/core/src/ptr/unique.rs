use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Pecyn lapio o amgylch `*mut T` amrwd nad yw'n null sy'n nodi mai perchennog y deunydd lapio hwn sy'n berchen ar y canolwr.
/// Yn ddefnyddiol ar gyfer adeiladu tyniadau fel `Box<T>`, `Vec<T>`, `String`, a `HashMap<K, V>`.
///
/// Yn wahanol i `*mut T`, mae `Unique<T>` yn ymddwyn "as if" roedd yn enghraifft o `T`.
/// Mae'n gweithredu `Send`/`Sync` os yw `T` yn `Send`/`Sync`.
/// Mae hefyd yn awgrymu'r math o warantau gwyro cryf y gall enghraifft o `T` eu disgwyl:
/// ni ddylid addasu canolwr y pwyntydd heb lwybr unigryw i'w berchen unigryw.
///
/// Os ydych chi'n ansicr a yw'n gywir defnyddio `Unique` at eich dibenion, ystyriwch ddefnyddio `NonNull`, sydd â semanteg wannach.
///
///
/// Yn wahanol i `*mut T`, rhaid i'r pwyntydd fod yn ddi-null bob amser, hyd yn oed os nad yw'r pwyntydd byth yn cael ei ddadreoleiddio.
/// Mae hyn er mwyn i enymau ddefnyddio'r gwerth gwaharddedig hwn fel gwahaniaethydd-mae gan `Option<Unique<T>>` yr un maint â `Unique<T>`.
/// Fodd bynnag, gall y pwyntydd ddal i hongian os nad yw wedi'i ddadreoleiddio.
///
/// Yn wahanol i `*mut T`, mae `Unique<T>` yn gyfochrog dros `T`.
/// Dylai hyn fod yn gywir bob amser ar gyfer unrhyw fath sy'n cynnal gofynion aliasio unigryw.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: nid oes gan y marciwr hwn unrhyw ganlyniadau o ran amrywiant, ond mae'n angenrheidiol
    // er mwyn i dropck ddeall ein bod yn rhesymegol yn berchen ar `T`.
    //
    // Am fanylion, gweler:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` yr awgrymiadau yw `Send` os yw `T` yn `Send` oherwydd bod y data y maent yn cyfeirio ato yn ddiduedd.
/// Sylwch fod y invariant aliasing hwn yn cael ei orfodi gan y system fath;rhaid i'r tyniad sy'n defnyddio'r `Unique` ei orfodi.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` yr awgrymiadau yw `Sync` os yw `T` yn `Sync` oherwydd bod y data y maent yn cyfeirio ato yn ddiduedd.
/// Sylwch fod y invariant aliasing hwn yn cael ei orfodi gan y system fath;rhaid i'r tyniad sy'n defnyddio'r `Unique` ei orfodi.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Yn creu `Unique` newydd sy'n hongian, ond wedi'i alinio'n dda.
    ///
    /// Mae hyn yn ddefnyddiol ar gyfer cychwyn mathau sy'n dyrannu yn ddiog, fel y mae `Vec::new` yn ei wneud.
    ///
    /// Sylwch y gall gwerth y pwyntydd gynrychioli pwyntydd dilys i `T` o bosibl, sy'n golygu na ddylid defnyddio hwn fel gwerth sentinel "not yet initialized".
    /// Rhaid i fathau sy'n dyrannu'n ddiog olrhain cychwyniad mewn rhyw fodd arall.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // DIOGELWCH: Mae mem::align_of() yn dychwelyd pwyntydd dilys, di-null.Mae'r
        // felly parchir amodau i alw new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Yn creu `Unique` newydd.
    ///
    /// # Safety
    ///
    /// `ptr` rhaid iddo fod yn ddi-null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // DIOGELWCH: rhaid i'r galwr warantu bod `ptr` yn ddi-null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Yn creu `Unique` newydd os yw `ptr` yn ddi-null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // DIOGELWCH: Mae'r pwyntydd eisoes wedi'i wirio ac nid yw'n null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Yn caffael y pwyntydd `*mut` sylfaenol.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Yn gohirio'r cynnwys.
    ///
    /// Mae'r oes sy'n deillio o hyn yn sicr o fod yn hunan felly mae hyn yn ymddwyn "as if", mewn gwirionedd roedd yn enghraifft o T sy'n cael ei fenthyg.
    /// Os oes angen oes (unbound) hirach, defnyddiwch `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // DIOGELWCH: rhaid i'r galwr warantu bod `self` yn cwrdd â'r holl
        // gofynion ar gyfer geirda.
        unsafe { &*self.as_ptr() }
    }

    /// Yn dad-gyfeirio'r cynnwys yn aml.
    ///
    /// Mae'r oes sy'n deillio o hyn yn sicr o fod yn hunan felly mae hyn yn ymddwyn "as if", mewn gwirionedd roedd yn enghraifft o T sy'n cael ei fenthyg.
    /// Os oes angen oes (unbound) hirach, defnyddiwch `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // DIOGELWCH: rhaid i'r galwr warantu bod `self` yn cwrdd â'r holl
        // gofynion ar gyfer cyfeirnod symudol.
        unsafe { &mut *self.as_ptr() }
    }

    /// Yn castio at bwyntydd o fath arall.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // DIOGELWCH: Mae Unique::new_unchecked() yn creu unigryw ac anghenion newydd
        // ni ddylai'r pwyntydd a roddir fod yn null.
        // Gan ein bod yn pasio'ch hun fel pwyntydd, ni all fod yn null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // DIOGELWCH: Ni all cyfeiriad symudol fod yn null
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}