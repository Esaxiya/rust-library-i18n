use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ond heb fod yn sero ac yn gyfochrog.
///
/// Yn aml, dyma'r peth cywir i'w ddefnyddio wrth adeiladu strwythurau data gan ddefnyddio awgrymiadau amrwd, ond yn y pen draw mae'n fwy peryglus i'w ddefnyddio oherwydd ei briodweddau ychwanegol.Os nad ydych yn siŵr a ddylech ddefnyddio `NonNull<T>`, defnyddiwch `*mut T`!
///
/// Yn wahanol i `*mut T`, rhaid i'r pwyntydd fod yn ddi-null bob amser, hyd yn oed os nad yw'r pwyntydd byth yn cael ei ddadreoleiddio.Mae hyn er mwyn i enymau ddefnyddio'r gwerth gwaharddedig hwn fel gwahaniaethydd-mae gan `Option<NonNull<T>>` yr un maint â `* mut T`.
/// Fodd bynnag, gall y pwyntydd ddal i hongian os nad yw wedi'i ddadreoleiddio.
///
/// Yn wahanol i `*mut T`, dewiswyd `NonNull<T>` i fod yn gyfochrog dros `T`.Mae hyn yn ei gwneud hi'n bosibl defnyddio `NonNull<T>` wrth adeiladu mathau cyfochrog, ond mae'n cyflwyno'r risg o ansicrwydd os caiff ei ddefnyddio mewn math na ddylai fod yn gyfochrog mewn gwirionedd.
/// (Gwnaed y dewis arall ar gyfer `*mut T` er yn dechnegol dim ond trwy alw swyddogaethau anniogel y gellid achosi'r ansicrwydd.)
///
/// Mae cydvariance yn gywir ar gyfer y rhan fwyaf o dyniadau diogel, fel `Box`, `Rc`, `Arc`, `Vec`, a `LinkedList`.Mae hyn yn wir oherwydd eu bod yn darparu API cyhoeddus sy'n dilyn rheolau treiddiol XOR arferol Rust.
///
/// Os na all eich math fod yn gyfochrog yn ddiogel, rhaid i chi sicrhau ei fod yn cynnwys rhywfaint o gae ychwanegol i ddarparu goresgyniad.Yn aml, bydd y maes hwn yn fath [`PhantomData`] fel `PhantomData<Cell<T>>` neu `PhantomData<&'a mut T>`.
///
/// Sylwch fod gan `NonNull<T>` enghraifft `From` ar gyfer `&T`.Fodd bynnag, nid yw hyn yn newid y ffaith bod treiglo trwy gyfeirnod (pwyntydd sy'n deillio o a) yn ymddygiad heb ei ddiffinio oni bai bod y treiglad yn digwydd y tu mewn i [`UnsafeCell<T>`].Mae'r un peth yn wir am greu cyfeirnod symudol o gyfeirnod a rennir.
///
/// Wrth ddefnyddio'r enghraifft `From` hon heb `UnsafeCell<T>`, eich cyfrifoldeb chi yw sicrhau nad yw `as_mut` byth yn cael ei alw, ac ni ddefnyddir `as_ptr` byth ar gyfer treiglo.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` nid yw awgrymiadau yn `Send` oherwydd gellir aliasio'r data y maent yn cyfeirio ato.
// DS, nid yw'r impl hwn yn ddiangen, ond dylai ddarparu gwell negeseuon gwall.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` nid yw awgrymiadau yn `Sync` oherwydd gellir aliasio'r data y maent yn cyfeirio ato.
// DS, nid yw'r impl hwn yn ddiangen, ond dylai ddarparu gwell negeseuon gwall.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Yn creu `NonNull` newydd sy'n hongian, ond wedi'i alinio'n dda.
    ///
    /// Mae hyn yn ddefnyddiol ar gyfer cychwyn mathau sy'n dyrannu yn ddiog, fel y mae `Vec::new` yn ei wneud.
    ///
    /// Sylwch y gall gwerth y pwyntydd gynrychioli pwyntydd dilys i `T` o bosibl, sy'n golygu na ddylid defnyddio hwn fel gwerth sentinel "not yet initialized".
    /// Rhaid i fathau sy'n dyrannu'n ddiog olrhain cychwyniad mewn rhyw fodd arall.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // DIOGELWCH: Mae mem::align_of() yn dychwelyd usize di-sero sydd wedyn yn cael ei gasio
        // i a * mut T.
        // Felly, nid yw `ptr` yn null ac mae'r amodau ar gyfer galw new_unchecked() yn cael eu parchu.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Yn dychwelyd cyfeiriadau a rennir at y gwerth.Mewn cyferbyniad â [`as_ref`], nid yw hyn yn gofyn bod yn rhaid cychwyn y gwerth.
    ///
    /// Am y cymar mutable gweler [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Wrth alw'r dull hwn, mae'n rhaid i chi sicrhau bod pob un o'r canlynol yn wir:
    ///
    /// * Rhaid i'r pwyntydd gael ei alinio'n iawn.
    ///
    /// * Rhaid iddo fod yn "dereferencable" yn yr ystyr a ddiffinnir yn [the module documentation].
    ///
    /// * Rhaid i chi orfodi rheolau gwyro Rust, gan fod yr oes a ddychwelwyd `'a` yn cael ei dewis yn fympwyol ac nid yw o reidrwydd yn adlewyrchu oes wirioneddol y data.
    ///
    ///   Yn benodol, trwy gydol yr oes hon, rhaid i'r cof y mae'r pwyntydd yn pwyntio ato beidio â threiglo (ac eithrio y tu mewn i `UnsafeCell`).
    ///
    /// Mae hyn yn berthnasol hyd yn oed os nad yw canlyniad y dull hwn yn cael ei ddefnyddio!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // DIOGELWCH: rhaid i'r galwr warantu bod `self` yn cwrdd â'r holl
        // gofynion ar gyfer geirda.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Yn dychwelyd cyfeiriadau unigryw at y gwerth.Mewn cyferbyniad â [`as_mut`], nid yw hyn yn gofyn bod yn rhaid cychwyn y gwerth.
    ///
    /// Am y cymar a rennir gweler [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Wrth alw'r dull hwn, mae'n rhaid i chi sicrhau bod pob un o'r canlynol yn wir:
    ///
    /// * Rhaid i'r pwyntydd gael ei alinio'n iawn.
    ///
    /// * Rhaid iddo fod yn "dereferencable" yn yr ystyr a ddiffinnir yn [the module documentation].
    ///
    /// * Rhaid i chi orfodi rheolau gwyro Rust, gan fod yr oes a ddychwelwyd `'a` yn cael ei dewis yn fympwyol ac nid yw o reidrwydd yn adlewyrchu oes wirioneddol y data.
    ///
    ///   Yn benodol, trwy gydol yr oes hon, rhaid i'r cof y mae'r pwyntydd yn pwyntio ato beidio â chael mynediad (darllen neu ysgrifennu) trwy unrhyw bwyntydd arall.
    ///
    /// Mae hyn yn berthnasol hyd yn oed os nad yw canlyniad y dull hwn yn cael ei ddefnyddio!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // DIOGELWCH: rhaid i'r galwr warantu bod `self` yn cwrdd â'r holl
        // gofynion ar gyfer geirda.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Yn creu `NonNull` newydd.
    ///
    /// # Safety
    ///
    /// `ptr` rhaid iddo fod yn ddi-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // DIOGELWCH: rhaid i'r galwr warantu bod `ptr` yn ddi-null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Yn creu `NonNull` newydd os yw `ptr` yn ddi-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // DIOGELWCH: Mae'r pwyntydd eisoes wedi'i wirio ac nid yw'n null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Yn perfformio'r un swyddogaeth â [`std::ptr::from_raw_parts`], heblaw bod pwyntydd `NonNull` yn cael ei ddychwelyd, yn hytrach na phwyntydd `*const` amrwd.
    ///
    ///
    /// Gweler dogfennaeth [`std::ptr::from_raw_parts`] i gael mwy o fanylion.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // DIOGELWCH: Mae canlyniad `ptr::from::raw_parts_mut` yn ddi-null oherwydd bod `data_address`.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Dadelfennu pwyntydd (llydan o bosibl) i mewn yw cydrannau cyfeiriad a metadata.
    ///
    /// Gellir ailadeiladu'r pwyntydd yn ddiweddarach gyda [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Yn caffael y pwyntydd `*mut` sylfaenol.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Yn dychwelyd cyfeiriad a rennir at y gwerth.Os gall y gwerth fod yn anfwriadol, rhaid defnyddio [`as_uninit_ref`] yn lle.
    ///
    /// Am y cymar mutable gweler [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Wrth alw'r dull hwn, mae'n rhaid i chi sicrhau bod pob un o'r canlynol yn wir:
    ///
    /// * Rhaid i'r pwyntydd gael ei alinio'n iawn.
    ///
    /// * Rhaid iddo fod yn "dereferencable" yn yr ystyr a ddiffinnir yn [the module documentation].
    ///
    /// * Rhaid i'r pwyntydd bwyntio at enghraifft gychwynnol o `T`.
    ///
    /// * Rhaid i chi orfodi rheolau gwyro Rust, gan fod yr oes a ddychwelwyd `'a` yn cael ei dewis yn fympwyol ac nid yw o reidrwydd yn adlewyrchu oes wirioneddol y data.
    ///
    ///   Yn benodol, trwy gydol yr oes hon, rhaid i'r cof y mae'r pwyntydd yn pwyntio ato beidio â threiglo (ac eithrio y tu mewn i `UnsafeCell`).
    ///
    /// Mae hyn yn berthnasol hyd yn oed os nad yw canlyniad y dull hwn yn cael ei ddefnyddio!
    /// (Nid yw'r rhan am gael ei sefydlu wedi ei phenderfynu'n llawn eto, ond hyd nes y bydd, yr unig ddull diogel yw sicrhau eu bod yn cael eu cychwyn yn wir.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // DIOGELWCH: rhaid i'r galwr warantu bod `self` yn cwrdd â'r holl
        // gofynion ar gyfer geirda.
        unsafe { &*self.as_ptr() }
    }

    /// Yn dychwelyd cyfeiriad unigryw at y gwerth.Os gall y gwerth fod yn anfwriadol, rhaid defnyddio [`as_uninit_mut`] yn lle.
    ///
    /// Am y cymar a rennir gweler [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Wrth alw'r dull hwn, mae'n rhaid i chi sicrhau bod pob un o'r canlynol yn wir:
    ///
    /// * Rhaid i'r pwyntydd gael ei alinio'n iawn.
    ///
    /// * Rhaid iddo fod yn "dereferencable" yn yr ystyr a ddiffinnir yn [the module documentation].
    ///
    /// * Rhaid i'r pwyntydd bwyntio at enghraifft gychwynnol o `T`.
    ///
    /// * Rhaid i chi orfodi rheolau gwyro Rust, gan fod yr oes a ddychwelwyd `'a` yn cael ei dewis yn fympwyol ac nid yw o reidrwydd yn adlewyrchu oes wirioneddol y data.
    ///
    ///   Yn benodol, trwy gydol yr oes hon, rhaid i'r cof y mae'r pwyntydd yn pwyntio ato beidio â chael mynediad (darllen neu ysgrifennu) trwy unrhyw bwyntydd arall.
    ///
    /// Mae hyn yn berthnasol hyd yn oed os nad yw canlyniad y dull hwn yn cael ei ddefnyddio!
    /// (Nid yw'r rhan am gael ei sefydlu wedi ei phenderfynu'n llawn eto, ond hyd nes y bydd, yr unig ddull diogel yw sicrhau eu bod yn cael eu cychwyn yn wir.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // DIOGELWCH: rhaid i'r galwr warantu bod `self` yn cwrdd â'r holl
        // gofynion ar gyfer cyfeirnod symudol.
        unsafe { &mut *self.as_ptr() }
    }

    /// Yn castio at bwyntydd o fath arall.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // DIOGELWCH: Mae `self` yn bwyntydd `NonNull` sydd o reidrwydd yn ddi-null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Yn creu sleisen amrwd nad yw'n null o bwyntydd tenau a hyd.
    ///
    /// Dadl `len` yw nifer yr **elfennau**, nid nifer y bytes.
    ///
    /// Mae'r swyddogaeth hon yn ddiogel, ond mae dad-gyfeirio'r gwerth dychwelyd yn anniogel.
    /// Gweler dogfennaeth [`slice::from_raw_parts`] i gael gofynion diogelwch tafell.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // creu pwyntydd tafell wrth ddechrau gyda phwyntydd i'r elfen gyntaf
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Sylwch fod yr enghraifft hon yn artiffisial yn dangos defnydd o'r dull hwn, ond `gadewch tafell= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // DIOGELWCH: Mae `data` yn bwyntydd `NonNull` sydd o reidrwydd yn ddi-null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Yn dychwelyd hyd tafell amrwd nad yw'n null.
    ///
    /// Y gwerth a ddychwelwyd yw nifer yr **elfennau**, nid nifer y bytes.
    ///
    /// Mae'r swyddogaeth hon yn ddiogel, hyd yn oed pan na ellir dad-gyfeirio'r sleisen amrwd nad yw'n null i dafell oherwydd nad oes gan y pwyntydd gyfeiriad dilys.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Yn dychwelyd pwyntydd nad yw'n null i byffer y sleisen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // DIOGELWCH: Rydym yn gwybod bod `self` yn ddi-null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Yn dychwelyd pwyntydd amrwd i byffer y dafell.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Yn dychwelyd cyfeiriad a rennir at dafell o werthoedd sydd heb eu datganoli o bosibl.Mewn cyferbyniad â [`as_ref`], nid yw hyn yn gofyn bod yn rhaid cychwyn y gwerth.
    ///
    /// Am y cymar mutable gweler [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Wrth alw'r dull hwn, mae'n rhaid i chi sicrhau bod pob un o'r canlynol yn wir:
    ///
    /// * Rhaid i'r pwyntydd fod yn [valid] ar gyfer darlleniadau ar gyfer `ptr.len() * mem::size_of::<T>()` llawer o beit, a rhaid ei alinio'n iawn.Mae hyn yn golygu yn benodol:
    ///
    ///     * Rhaid cynnwys ystod cof gyfan y dafell hon mewn un gwrthrych a ddyrannwyd!
    ///       Ni all tafelli fyth rychwantu sawl gwrthrych a ddyrannwyd.
    ///
    ///     * Rhaid i'r pwyntydd gael ei alinio hyd yn oed ar gyfer sleisys hyd sero.
    ///     Un rheswm am hyn yw y gall optimeiddiadau cynllun enwm ddibynnu ar gyfeiriadau (gan gynnwys sleisys o unrhyw hyd) yn cael eu halinio a heb fod yn null i'w gwahaniaethu oddi wrth ddata arall.
    ///
    ///     Gallwch gael pwyntydd y gellir ei ddefnyddio fel `data` ar gyfer sleisys hyd sero gan ddefnyddio [`NonNull::dangling()`].
    ///
    /// * Rhaid i gyfanswm maint `ptr.len() * mem::size_of::<T>()` y dafell beidio â bod yn fwy na `isize::MAX`.
    ///   Gweler dogfennaeth ddiogelwch [`pointer::offset`].
    ///
    /// * Rhaid i chi orfodi rheolau gwyro Rust, gan fod yr oes a ddychwelwyd `'a` yn cael ei dewis yn fympwyol ac nid yw o reidrwydd yn adlewyrchu oes wirioneddol y data.
    ///   Yn benodol, trwy gydol yr oes hon, rhaid i'r cof y mae'r pwyntydd yn pwyntio ato beidio â threiglo (ac eithrio y tu mewn i `UnsafeCell`).
    ///
    /// Mae hyn yn berthnasol hyd yn oed os nad yw canlyniad y dull hwn yn cael ei ddefnyddio!
    ///
    /// Gweler hefyd [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Yn dychwelyd cyfeiriad unigryw at dafell o werthoedd a allai fod yn anfwriadol.Mewn cyferbyniad â [`as_mut`], nid yw hyn yn gofyn bod yn rhaid cychwyn y gwerth.
    ///
    /// Am y cymar a rennir gweler [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Wrth alw'r dull hwn, mae'n rhaid i chi sicrhau bod pob un o'r canlynol yn wir:
    ///
    /// * Rhaid i'r pwyntydd fod yn [valid] ar gyfer darllen ac ysgrifennu ar gyfer `ptr.len() * mem::size_of::<T>()` llawer o beit, a rhaid ei alinio'n iawn.Mae hyn yn golygu yn benodol:
    ///
    ///     * Rhaid cynnwys ystod cof gyfan y dafell hon mewn un gwrthrych a ddyrannwyd!
    ///       Ni all tafelli fyth rychwantu sawl gwrthrych a ddyrannwyd.
    ///
    ///     * Rhaid i'r pwyntydd gael ei alinio hyd yn oed ar gyfer sleisys hyd sero.
    ///     Un rheswm am hyn yw y gall optimeiddiadau cynllun enwm ddibynnu ar gyfeiriadau (gan gynnwys sleisys o unrhyw hyd) yn cael eu halinio a heb fod yn null i'w gwahaniaethu oddi wrth ddata arall.
    ///
    ///     Gallwch gael pwyntydd y gellir ei ddefnyddio fel `data` ar gyfer sleisys hyd sero gan ddefnyddio [`NonNull::dangling()`].
    ///
    /// * Rhaid i gyfanswm maint `ptr.len() * mem::size_of::<T>()` y dafell beidio â bod yn fwy na `isize::MAX`.
    ///   Gweler dogfennaeth ddiogelwch [`pointer::offset`].
    ///
    /// * Rhaid i chi orfodi rheolau gwyro Rust, gan fod yr oes a ddychwelwyd `'a` yn cael ei dewis yn fympwyol ac nid yw o reidrwydd yn adlewyrchu oes wirioneddol y data.
    ///   Yn benodol, trwy gydol yr oes hon, rhaid i'r cof y mae'r pwyntydd yn pwyntio ato beidio â chael mynediad (darllen neu ysgrifennu) trwy unrhyw bwyntydd arall.
    ///
    /// Mae hyn yn berthnasol hyd yn oed os nad yw canlyniad y dull hwn yn cael ei ddefnyddio!
    ///
    /// Gweler hefyd [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Mae hyn yn ddiogel gan fod `memory` yn ddilys ar gyfer darllen ac ysgrifennu ar gyfer `memory.len()` llawer o beit.
    /// // Sylwch na chaniateir ffonio `memory.as_mut()` yma oherwydd gall y cynnwys fod yn anfwriadol.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Yn dychwelyd pwyntydd amrwd i elfen neu aruchel, heb wirio ffiniau.
    ///
    /// Mae galw'r dull hwn gyda mynegai y tu allan i ffiniau neu pan nad yw `self` yn ddadreferenadwy yn *[ymddygiad heb ei ddiffinio]* hyd yn oed os na ddefnyddir y pwyntydd sy'n deillio o hynny.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // DIOGELWCH: mae'r galwr yn sicrhau bod `self` yn ddereferencable a `index` mewn ffiniau.
        // O ganlyniad, ni all y pwyntydd sy'n deillio o hyn fod yn NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // DIOGELWCH: Ni all pwyntydd unigryw fod yn null, felly mae'r amodau ar gyfer
        // new_unchecked() yn cael eu parchu.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // DIOGELWCH: Ni all cyfeiriad symudol fod yn null.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // DIOGELWCH: Ni all cyfeiriad fod yn null, felly mae'r amodau ar gyfer
        // new_unchecked() yn cael eu parchu.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}