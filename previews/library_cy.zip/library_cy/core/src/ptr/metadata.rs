#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Mae'n darparu'r math metadata pwyntydd o unrhyw fath pwyntiedig.
///
/// # Metadata pwyntydd
///
/// Gellir meddwl bod mathau pwyntydd amrwd a mathau cyfeirio yn Rust wedi'u gwneud o ddwy ran:
/// pwyntydd data sy'n cynnwys cyfeiriad cof y gwerth, a rhywfaint o fetadata.
///
/// Ar gyfer mathau o faint statig (sy'n gweithredu'r `Sized` traits) yn ogystal ag ar gyfer mathau `extern`, dywedir bod awgrymiadau yn `denau`: mae metadata o faint sero a'i fath yw `()`.
///
///
/// Dywedir bod awgrymiadau i [dynamically-sized types][dst] yn `llydan` neu'n `dew`, mae ganddyn nhw fetadata heb fod yn sero:
///
/// * Ar gyfer strwythurau y mae eu maes olaf yn DST, metadata yw'r metadata ar gyfer y maes olaf
/// * Ar gyfer y math `str`, metadata yw'r hyd mewn beitiau fel `usize`
/// * Ar gyfer mathau tafell fel `[T]`, metadata yw'r hyd mewn eitemau fel `usize`
/// * Ar gyfer gwrthrychau trait fel `dyn SomeTrait`, metadata yw [`DynMetadata<Self>`][DynMetadata] (ee `DynMetadata<dyn SomeTrait>`)
///
/// Yn y future, gall yr iaith Rust ennill mathau newydd o fathau sydd â metadata pwyntydd gwahanol.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Yr `Pointee` trait
///
/// Pwynt y trait hwn yw ei fath cysylltiedig â `Metadata`, sef `()` neu `usize` neu `DynMetadata<_>` fel y disgrifir uchod.
/// Fe'i gweithredir yn awtomatig ar gyfer pob math.
/// Gellir tybio ei fod yn cael ei weithredu mewn cyd-destun generig, hyd yn oed heb rwymiad cyfatebol.
///
/// # Usage
///
/// Gellir dadelfennu awgrymiadau amrwd i'r cyfeiriad data a'r cydrannau metadata gyda'u dull [`to_raw_parts`].
///
/// Fel arall, gellir tynnu metadata yn unig gyda'r swyddogaeth [`metadata`].
/// Gellir trosglwyddo cyfeiriad at [`metadata`] a'i orfodi'n ymhlyg.
///
/// Gellir rhoi pwyntydd (possibly-wide) yn ôl at ei gilydd o'i gyfeiriad a'i fetadata gyda [`from_raw_parts`] neu [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Y math ar gyfer metadata mewn awgrymiadau a chyfeiriadau at `Self`.
    #[lang = "metadata_type"]
    // NOTE: Cadwch trait bounds yn `static_assert_expected_bounds_for_metadata`
    //
    // yn `library/core/src/ptr/metadata.rs` yn cyd-fynd â'r rhai yma:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Mae awgrymiadau ar gyfer mathau sy'n gweithredu'r alias trait hwn yn `denau`.
///
/// Mae hyn yn cynnwys mathau statig-`Sized` a mathau `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: peidiwch â sefydlogi hyn cyn bod arallenwau trait yn sefydlog yn yr iaith?
pub trait Thin = Pointee<Metadata = ()>;

/// Tynnwch gydran metadata pwyntydd.
///
/// Gellir trosglwyddo gwerthoedd o fath `*mut T`, `&T`, neu `&mut T` yn uniongyrchol i'r swyddogaeth hon gan eu bod yn ymhlyg yn gorfodi i `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // DIOGELWCH: Mae cyrchu'r gwerth o'r undeb `PtrRepr` yn ddiogel ers * const T.
    // a PtrComponents<T>cael yr un cynlluniau cof.
    // Dim ond std all wneud y warant hon.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Yn ffurfio pwyntydd amrwd (possibly-wide) o gyfeiriad data a metadata.
///
/// Mae'r swyddogaeth hon yn ddiogel ond nid yw'r pwyntydd a ddychwelwyd o reidrwydd yn ddiogel i'w ddadgyfeirio.
/// Am dafelli, gweler dogfennaeth [`slice::from_raw_parts`] i gael gofynion diogelwch.
/// Ar gyfer gwrthrychau trait, rhaid i'r metadata ddod o bwyntydd i'r un math danbaid sylfaenol.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // DIOGELWCH: Mae cyrchu'r gwerth o'r undeb `PtrRepr` yn ddiogel ers * const T.
    // a PtrComponents<T>cael yr un cynlluniau cof.
    // Dim ond std all wneud y warant hon.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Yn perfformio'r un swyddogaeth â [`from_raw_parts`], heblaw bod pwyntydd `*mut` amrwd yn cael ei ddychwelyd, yn hytrach na phwyntydd `* const` amrwd.
///
///
/// Gweler dogfennaeth [`from_raw_parts`] i gael mwy o fanylion.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // DIOGELWCH: Mae cyrchu'r gwerth o'r undeb `PtrRepr` yn ddiogel ers * const T.
    // a PtrComponents<T>cael yr un cynlluniau cof.
    // Dim ond std all wneud y warant hon.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Mae angen impl â llaw i osgoi rhwymo `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Mae angen impl â llaw i osgoi rhwymo `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Y metadata ar gyfer math o wrthrych `Dyn = dyn SomeTrait` trait.
///
/// Mae'n pwyntydd i dabl (bwrdd galwadau rhithwir) sy'n cynrychioli'r holl wybodaeth angenrheidiol i drin y math concrit sydd wedi'i storio y tu mewn i wrthrych trait.
/// Mae'r vtable yn arbennig yn cynnwys:
///
/// * maint math
/// * aliniad math
/// * pwyntydd i impl `drop_in_place` y math (gall fod yn no-op ar gyfer hen ddata plaen)
/// * awgrymiadau i'r holl ddulliau ar gyfer gweithredu'r math o'r trait
///
/// Sylwch fod y tri cyntaf yn arbennig oherwydd eu bod yn angenrheidiol i ddyrannu, gollwng a deallocate unrhyw wrthrych trait.
///
/// Mae'n bosibl enwi'r strwythur hwn gyda pharamedr math nad yw'n wrthrych `dyn` trait (er enghraifft `DynMetadata<u64>`) ond i beidio â chael gwerth ystyrlon o'r strwythur hwnnw.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Rhagddodiad cyffredin yr holl vtables.Fe'i dilynir gan awgrymiadau swyddogaeth ar gyfer dulliau trait.
///
/// Manylion gweithredu preifat `DynMetadata::size_of` ac ati.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Yn dychwelyd maint y math sy'n gysylltiedig â'r vtable hwn.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Yn dychwelyd aliniad y math sy'n gysylltiedig â'r vtable hwn.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Yn dychwelyd y maint a'r aliniad gyda'i gilydd fel `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // DIOGELWCH: gollyngodd y casglwr y hyfyw hon ar gyfer math concrit Rust sydd
        // gwyddys fod ganddo gynllun dilys.Yr un rhesymeg ag yn `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Mae angen impls â llaw i osgoi ffiniau `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}