//! Ffyrdd o greu `str` o bytes sleisen.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Trosi tafell o bytes yn dafell llinyn.
///
/// Mae tafell llinyn ([`&str`]) cael ei wneud o bytes ([`u8`]), a sleisen beit ([`&[u8]`][byteslice]) cael ei wneud o bytes, felly swyddogaeth hon yn trosi rhwng y ddau.
/// Nid yw pob tafell beit yn sleisys llinyn ddilys, fodd bynnag: [`&str`] yn mynnu ei fod yn ddilys UTF-8.
/// `from_utf8()` gwiriadau i sicrhau bod y bytes yn UTF-8 dilys, ac yna'n gwneud y trawsnewid.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Os ydych chi'n siŵr bod y sleisen beit yn ddilys UTF-8, ac nad ydych chi am fynd i orbenion y gwiriad dilysrwydd, mae fersiwn anniogel o'r swyddogaeth hon, [`from_utf8_unchecked`], sydd â'r un ymddygiad ond sy'n sgipio'r gwiriad.
///
///
/// Os oes angen `String` arnoch yn lle `&str`, ystyriwch [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Oherwydd y gallwch stac-ddyrannu `[u8; N]`, a gallwch gymryd [`&[u8]`][byteslice] ohono, mae'r swyddogaeth hon yn un ffordd i gael llinyn wedi'i ddyrannu ar gyfer pentwr.Mae enghraifft o hyn yn yr adran enghreifftiau isod.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Yn dychwelyd `Err` os nad yw'r sleisen yn UTF-8 gyda disgrifiad o pam nad yw'r sleisen a ddarperir yn UTF-8.
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::str;
///
/// // rhai beit, mewn vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Rydym yn gwybod bod y bytes hyn yn ddilys, felly defnyddiwch `unwrap()` yn unig.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Beitiau anghywir:
///
/// ```
/// use std::str;
///
/// // rhai beit annilys, mewn vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Gweler y docs ar gyfer [`Utf8Error`] i gael mwy o fanylion am y mathau o wallau y gellir eu dychwelyd.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // rhai beitiau, mewn arae a ddyrannwyd gan stac
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Rydym yn gwybod bod y bytes hyn yn ddilys, felly defnyddiwch `unwrap()` yn unig.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // DIOGELWCH: Newydd ddilysu.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Trosi tafell gyfnewidiol o bytes yn dafell llinyn symudol.
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" fel vector treiddgar
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Fel y gwyddom fod y beitiau hyn yn ddilys, gallwn ddefnyddio `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Beitiau anghywir:
///
/// ```
/// use std::str;
///
/// // Rhai beit annilys mewn vector treiddgar
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Gweler y docs ar gyfer [`Utf8Error`] i gael mwy o fanylion am y mathau o wallau y gellir eu dychwelyd.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // DIOGELWCH: Newydd ddilysu.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Trosi sleisen o bytes i tafell llinyn heb wirio bod y llinyn yn cynnwys UTF-8 dilys.
///
/// Gweler y fersiwn ddiogel, [`from_utf8`], am fwy o wybodaeth.
///
/// # Safety
///
/// Mae'r swyddogaeth hon yn anniogel oherwydd nad yw'n gwirio bod y bytes a ddaeth iddo yn ddilys UTF-8.
/// Os bydd y cyfyngiad hwn yn cael ei dorri, mae ymddygiad heb ei ddiffinio yn arwain, gan fod gweddill Rust yn tybio bod [`&str`] s yn UTF-8 dilys.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::str;
///
/// // rhai beit, mewn vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // DIOGELWCH: mae'n rhaid i'r sawl sy'n galw yn gwarantu bod y bytes `v` yn ddilys UTF-8.
    // Mae hefyd yn dibynnu bod gan `&str` a `&[u8]` yr un cynllun.
    unsafe { mem::transmute(v) }
}

/// Trosi tafell o bytes i dafell llinyn heb wirio bod y llinyn yn cynnwys UTF-8 dilys;Fersiwn mutable.
///
///
/// Gweler y fersiwn na ellir ei symud, [`from_utf8_unchecked()`] i gael mwy o wybodaeth.
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // DIOGELWCH: rhaid i'r galwr warantu bod y bytes `v`
    // yn UTF-8 dilys, felly mae'r cast i `*mut str` yn ddiogel.
    // Hefyd, mae'r dereference pwyntydd yn ddiogel oherwydd bod y pwyntydd yn dod o gyfeiriad sydd yn sicr o fod yn ddilys ar gyfer ysgrifennu yn.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}