//! Yn diffinio math gwall utf8.

use crate::fmt;

/// Gwallau a all ddigwydd wrth geisio dehongli dilyniant o [`u8`] fel llinyn.
///
/// Yn hynny o beth, mae'r teulu `from_utf8` o swyddogaethau a dulliau ar gyfer [`String`] s a [`&str`] s yn defnyddio'r gwall hwn, er enghraifft.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Gall dulliau Mae'r math hwn wall yn cael ei ddefnyddio i greu ymarferoldeb tebyg i `String::from_utf8_lossy` heb ddyrannu cof domen:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Yn dychwelyd y mynegai yn y llinyn a roddwyd y gwiriwyd UTF-8 dilys iddo.
    ///
    /// Mae'n mynegai uchafswm o'r fath y byddai `from_utf8(&input[..index])` yn dychwelyd `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// use std::str;
    ///
    /// // rhai beit annilys, mewn vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 yn dychwelyd Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // mae'r ail beit yn annilys yma
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Mae'n darparu mwy o wybodaeth am y methiant:
    ///
    /// * `None`: diwedd y cyfraniad cyrhaeddwyd yn annisgwyl.
    ///   `self.valid_up_to()` yw 1 i 3 bytes o ddiwedd y mewnbwn.
    ///   Os ffrwd beit (fel ffeil neu soced rhwydwaith) yn cael ei ddatgodio raddol, gallai hyn fod yn `char` dilys sy'n UTF-8 beit dilyniant yn rhychwantu darnau lluosog.
    ///
    ///
    /// * `Some(len)`: daethpwyd ar draws beit annisgwyl.
    ///   Y hyd a ddarperir yw dilyniant y beit annilys sy'n dechrau yn y mynegai a roddir gan `valid_up_to()`.
    ///   Dylai datgodio ailddechrau ar ôl y dilyniant hwnnw (ar ôl mewnosod [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) rhag ofn y bydd datgodio colledus.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Mae gwall a ddychwelwyd wrth dosrannu `bool` gan ddefnyddio [`from_str`] yn methu
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}