//! Gweithrediadau Trait ar gyfer `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Offer archebu o dannau.
///
/// Mae llinynnau'n cael eu harchebu [lexicographically](Ord#lexicographical-comparison) yn ôl eu gwerthoedd beit.
/// Mae hyn yn archebu pwyntiau cod Unicode yn seiliedig ar eu safleoedd yn y siartiau cod.
/// Nid yw hyn o reidrwydd yr un peth â threfn "alphabetical", sy'n amrywio yn ôl iaith a locale.
/// Mae didoli llinynnau yn unol â safonau a dderbynnir yn ddiwylliannol yn gofyn am ddata penodol i locale sydd y tu allan i gwmpas y math `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Yn gweithredu gweithrediadau cymharu ar dannau.
///
/// Llinynnau yn cael eu cymharu [lexicographically](Ord#lexicographical-comparison) gan eu gwerthoedd beit.
/// Mae hyn yn cymharu pwyntiau cod Unicode yn seiliedig ar eu safleoedd yn y siartiau cod.
/// Nid yw hyn o reidrwydd yr un peth â threfn "alphabetical", sy'n amrywio yn ôl iaith a locale.
/// Mae cymharu llinynnau yn unol â safonau a dderbynnir yn ddiwylliannol yn gofyn am ddata penodol i locale sydd y tu allan i gwmpas y math `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Yn gweithredu sleisio israddol gyda chystrawen `&self[..]` neu `&mut self[..]`.
///
/// Yn dychwelyd tafell o'r llinyn cyfan, hy, yn dychwelyd `&self` neu `&mut self`.Cyfwerth â `&hunan [0 ..
/// len] `neu`&mut self [0 ..
/// len]`.
/// Yn wahanol i weithrediadau mynegeio eraill, ni all hyn fyth panic.
///
/// Y llawdriniaeth hon yw *O*(1).
///
/// Cyn 1.20.0, roedd y gweithrediadau mynegeio hyn yn dal i gael eu cefnogi gan weithredu `Index` a `IndexMut` yn uniongyrchol.
///
/// Cyfwerth â `&self[0 .. len]` neu `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Yn gweithredu sleisio israddol gyda chystrawen `&self[begin .. end]` neu `&mut self[begin .. end]`.
///
/// Yn dychwelyd tafell o'r llinyn a roddir o'r ystod beit [`begin`, `end`).
///
/// Y llawdriniaeth hon yw *O*(1).
///
/// Cyn 1.20.0, roedd y gweithrediadau mynegeio hyn yn dal i gael eu cefnogi gan weithredu `Index` a `IndexMut` yn uniongyrchol.
///
/// # Panics
///
/// Panics os nad yw `begin` neu `end` yn pwyntio at wrthbwyso beit cychwynnol cymeriad (fel y'i diffinnir gan `is_char_boundary`), os `begin > end`, neu os `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // bydd y rhain yn panic:
/// // mae beit 2 yn gorwedd o fewn `ö`:
/// // &s [2 ..3];
///
/// // beit 8 gorwedd o fewn `老`&s [1 ..
/// // 8];
///
/// // mae beit 100 y tu allan i'r llinyn&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // DIOGELWCH: dim ond gwirio bod `start` a `end` ar ffin golosg,
            // ac rydym yn pasio cyfeirnod diogel, felly bydd y gwerth dychwelyd hefyd yn un.
            // Gwnaethom hefyd wirio ffiniau torgoch, felly mae hyn yn ddilys UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // DIOGELWCH: newydd wirio bod `start` a `end` ar ffin torgoch.
            // Rydym yn gwybod bod y pwyntydd yn unigryw oherwydd cawsom ef gan `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // gwarantau y galwr fod `self` yn ffiniau'r `slice`: DIOGELWCH
        // sy'n bodloni'r holl amodau ar gyfer `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // DIOGELWCH: gweler y sylwadau ar gyfer `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // mae is_char_boundary yn gwirio bod y mynegai yn [0, ni all .len()] ailddefnyddio `get` fel uchod, oherwydd trafferth NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // DIOGELWCH: dim ond gwirio bod `start` a `end` ar ffin golosg,
            // ac rydym yn pasio cyfeirnod diogel, felly bydd y gwerth dychwelyd hefyd yn un.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Yn gweithredu sleisio israddol gyda chystrawen `&self[.. end]` neu `&mut self[.. end]`.
///
/// Yn dychwelyd tafell o'r llinyn a roddir o'r ystod beit [`0`, `end`).
/// Cyfwerth â `&self[0 .. end]` neu `&mut self[0 .. end]`.
///
/// Y llawdriniaeth hon yw *O*(1).
///
/// Cyn 1.20.0, roedd y gweithrediadau mynegeio hyn yn dal i gael eu cefnogi gan weithredu `Index` a `IndexMut` yn uniongyrchol.
///
/// # Panics
///
/// Panics os nad `end` yn cyfeirio at y beit dechrau gwrthbwyso o gymeriad (fel y'i diffinnir gan `is_char_boundary`), neu os `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // DIOGELWCH: dim ond gwirio bod `end` ar ffin golosg,
            // ac rydym yn pasio cyfeirnod diogel, felly bydd y gwerth dychwelyd hefyd yn un.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // DIOGELWCH: dim ond gwirio bod `end` ar ffin golosg,
            // ac rydym yn pasio cyfeirnod diogel, felly bydd y gwerth dychwelyd hefyd yn un.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // DIOGELWCH: dim ond gwirio bod `end` ar ffin golosg,
            // ac rydym yn pasio cyfeirnod diogel, felly bydd y gwerth dychwelyd hefyd yn un.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Offer linyn sleisio gyda chystrawen `&self[begin ..]` neu `&mut self[begin ..]`.
///
/// Datganiadau niferoedd sleisen y llinyn a roddir o'r ystod beit [`begin`, `len`).Cyfwerth â `&hunan [dechrau ..
/// len] `neu`&mut self [dechreuwch ..
/// len]`.
///
/// Y llawdriniaeth hon yw *O*(1).
///
/// Cyn 1.20.0, roedd y gweithrediadau mynegeio hyn yn dal i gael eu cefnogi gan weithredu `Index` a `IndexMut` yn uniongyrchol.
///
/// # Panics
///
/// Panics os nad `begin` yn cyfeirio at y beit dechrau gwrthbwyso o gymeriad (fel y'i diffinnir gan `is_char_boundary`), neu os `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // DIOGELWCH: dim ond gwirio bod `start` ar ffin golosg,
            // ac rydym yn pasio cyfeirnod diogel, felly bydd y gwerth dychwelyd hefyd yn un.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // DIOGELWCH: dim ond gwirio bod `start` ar ffin golosg,
            // ac rydym yn pasio cyfeirnod diogel, felly bydd y gwerth dychwelyd hefyd yn un.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // gwarantau y galwr fod `self` yn ffiniau'r `slice`: DIOGELWCH
        // sy'n bodloni'r holl amodau ar gyfer `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // DIOGELWCH: yn union yr un fath â `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // DIOGELWCH: dim ond gwirio bod `start` ar ffin golosg,
            // ac rydym yn pasio cyfeirnod diogel, felly bydd y gwerth dychwelyd hefyd yn un.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Yn gweithredu sleisio israddol gyda chystrawen `&self[begin ..= end]` neu `&mut self[begin ..= end]`.
///
/// Yn dychwelyd tafell o'r llinyn a roddir o'r ystod beit [`begin`, `end`].Cyfwerth â `&self [begin .. end + 1]` neu `&mut self[begin .. end + 1]`, eithrio os `end` wedi y gwerth gorau am `usize`.
///
/// Y llawdriniaeth hon yw *O*(1).
///
/// # Panics
///
/// Panics os nad yw `begin` yn pwyntio at wrthbwyso beit cychwynnol cymeriad (fel y'i diffinnir gan `is_char_boundary`), os nad yw `end` yn pwyntio at wrthbwyso cymeriad sy'n dod i ben (mae `end + 1` naill ai'n wrthbwyso beit cychwynnol neu'n hafal i `len`), os yw `begin > end`, neu os `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Yn gweithredu sleisio israddol gyda chystrawen `&self[..= end]` neu `&mut self[..= end]`.
///
/// Yn dychwelyd tafell o'r llinyn a roddir o'r ystod beit [0, `end`].
/// Cyfwerth â `&self [0 .. end + 1]`, ac eithrio os oes gan `end` y gwerth mwyaf ar gyfer `usize`.
///
/// Y llawdriniaeth hon yw *O*(1).
///
/// # Panics
///
/// Panics os nad yw `end` yn pwyntio at wrthbwyso cymeriad diweddu beit (mae `end + 1` naill ai'n wrthbwyso beit cychwynnol fel y'i diffinnir gan `is_char_boundary`, neu'n hafal i `len`), neu os `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Dosbarthwch werth o linyn
///
/// Mae dull [`from_str`] `FromStr` yn aml yn cael ei ddefnyddio'n ymhlyg, trwy ddull [`parse`] [`str`].
/// Gweler dogfennaeth [`dosrannu '] am enghreifftiau.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` nid oes ganddo baramedr oes, ac felly dim ond dosrannu mathau nad ydyn nhw'n cynnwys paramedr oes eu hunain y gallwch chi eu dosrannu.
///
/// Hynny yw, gallwch ddosrannu `i32` gyda `FromStr`, ond nid `&i32`.
/// Gallwch dosrannu yn struct sy'n cynnwys `i32`, ond nid un sy'n cynnwys `&i32`.
///
/// # Examples
///
/// Gweithredu `FromStr` yn sylfaenol ar enghraifft math `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Y gwall cysylltiedig y gellir ei ddychwelyd o dosrannu.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Yn dosrannu llinyn `s` i ddychwelyd gwerth o'r math hwn.
    ///
    /// Os yw dosrannu yn llwyddo, dychwelwch y gwerth y tu mewn i [`Ok`], fel arall pan nad yw'r llinyn wedi'i fformatio'n dda dychwelwch wall sy'n benodol i'r [`Err`] y tu mewn.
    /// Mae'r math gwall yn benodol i weithredu'r trait.
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol gyda [`i32`], math sy'n gweithredu `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Dosbarthwch `bool` o linyn.
    ///
    /// Cynnyrch `Result<bool, ParseBoolError>`, oherwydd gall `s` fod yn ddosranadwy ai peidio.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Noder, mewn llawer o achosion, y dull `.parse()` ar `str` yn fwy priodol.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}