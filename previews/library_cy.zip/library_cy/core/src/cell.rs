//! cynwysyddion mutable shareable.
//!
//! Mae diogelwch cof Rust yn seiliedig ar y rheol hon: O ystyried gwrthrych `T`, dim ond un o'r canlynol y mae'n bosibl ei gael:
//!
//! - Wedi sawl cyfeiriad ddigyfnewid (`&T`) at y gwrthrych (a elwir hefyd yn aliasing ** **).
//! - Mae cael un geirda mutable (`&T` Mut) i'r gwrthrych (a elwir hefyd yn mutability ** **).
//!
//! Mae hyn yn cael ei gorfodi gan y compiler Rust.Fodd bynnag, mae yna sefyllfaoedd lle nad yw rheol hon yn ddigon hyblyg.Weithiau mae'n ofynnol iddo gael sawl cyfeiriad at wrthrych ac eto ei dreiglo.
//!
//! Mae cynwysyddion symudol y gellir eu rhannu yn bodoli i ganiatáu treiglad mewn dull rheoledig, hyd yn oed ym mhresenoldeb gwyro.Mae [`Cell<T>`] a [`RefCell<T>`] yn caniatáu gwneud hyn mewn ffordd un-threaded.
//! Fodd bynnag, nid `Cell<T>` nac `RefCell<T>` yn edau ddiogel (nid ydynt yn gweithredu [`Sync`]).
//! Os oes angen i wneud aliasing a threiglo rhwng edafedd lluosog, mae'n bosibl defnyddio [`Mutex<T>`], [`RwLock<T>`] neu [`atomic`] math.
//!
//! Gellir treiglo gwerthoedd o'r mathau `Cell<T>` a `RefCell<T>` trwy gyfeiriadau a rennir (h.y.
//! y math `&T` cyffredin), ond dim ond trwy gyfeiriadau unigryw (`&mut T`) y gellir treiglo'r mwyafrif o fathau Rust.
//! Rydym yn dweud bod `Cell<T>` a `RefCell<T>` yn darparu 'mutability mewnol', mewn cyferbyniad â mathau Rust nodweddiadol sy'n arddangos 'mutability etifeddol'.
//!
//! fathau o gelloedd yn dod mewn dau blasau: `Cell<T>` a `RefCell<T>`.Mae `Cell<T>` yn gweithredu treiddioldeb mewnol trwy symud gwerthoedd i mewn ac allan o'r `Cell<T>`.
//! I ddefnyddio cyfeiriadau yn lle o werthoedd, rhaid i un yn defnyddio'r math `RefCell<T>`, caffael clo ysgrifennu cyn treiglo.`Cell<T>` yn darparu dulliau i adfer a newid y gwerth tu cyfredol:
//!
//!  - Ar gyfer mathau sy'n gweithredu [`Copy`], mae'r dull [`get`](Cell::get) yn adfer y gwerth mewnol cyfredol.
//!  - Ar gyfer mathau sy'n gweithredu [`Default`], y dull [`take`](Cell::take) yn disodli'r werth tu presennol gyda [`Default::default()`] ac yn dychwelyd y gwerth disodli.
//!  - Ar gyfer pob math, y dull [`replace`](Cell::replace) yn disodli'r gwerth a ffurflenni gwerth disodli a'r dull yn ei ddefnyddio [`into_inner`](Cell::into_inner) y `Cell<T>` a ffurflenni gwerth tu tu cyfredol.
//!  Yn ogystal, mae'r dull [`set`](Cell::set) yn disodli'r gwerth tu mewn, gollwng y gwerth disodli.
//!
//! `RefCell<T>` defnyddio hoes Rust i weithredu 'benthyca deinamig', proses lle y gall un wneud cais unigryw mynediad mutable dros dro,, at werth mewnol.
//! Benthyciadau ar gyfer `RefCell<T>`S yn cael eu holrhain 'pan mae'n gweithredu', yn wahanol i fathau cyfeirio frodorol Rust sy'n cael eu holrhain yn llwyr llonydd, ar adeg crynhoi.
//! Oherwydd bod Borrows `RefCell<T>` yn ddeinamig mae'n bosibl ceisio fenthyg gwerth sydd eisoes yn benthyg mutably;pan fydd hyn yn digwydd, ei fod yn arwain yn y trywydd panic.
//!
//! # Pryd i ddewis tu mutability
//!
//! Mae'r mutability etifeddwyd fwy cyffredin, lle y mae'n rhaid i un gael mynediad unigryw i mutate gwerth, yn un o'r elfennau iaith allweddol sy'n galluogi Rust i reswm gryf am aliasing pwyntydd, llonydd atal bygiau ddamwain.
//! Oherwydd hynny, mutability etifeddu ei ffafrio, ac mutability tu mewn yn rhywbeth o dewis olaf.
//! Gan fod mathau o gelloedd yn galluogi treiglo lle na fyddai fel arall yn cael ei wrthod, mae yna adegau pan allai treiglad y tu mewn fod yn briodol, neu hyd yn oed *rhaid ei ddefnyddio*, ee.
//!
//! * Cyflwyno mutability 'inside' o rywbeth na ellir ei symud
//! * Gweithredu yn rhoi manylion dulliau rhesymegol-ddigyfnewid.
//! * Treiglo implementations o [`Clone`].
//!
//! ## Cyflwyno mutability 'inside' o rywbeth na ellir ei symud
//!
//! Mae llawer o fathau pwyntydd craff a rennir, gan gynnwys [`Rc<T>`] a [`Arc<T>`], yn darparu cynwysyddion y gellir eu clonio a'u rhannu rhwng sawl parti.
//! Oherwydd y gall gwerthoedd a gynhwysir yn-wedi'i anwybyddu lluosi, gellir ond eu benthyg gyda `&`, nid `&mut`.
//! Heb celloedd byddai'n amhosibl i'r tu mewn data treiglo'n o awgrymiadau smart hyn o gwbl.
//!
//! Mae'n gyffredin iawn wedyn i roi `RefCell<T>` tu mewn mathau rennir pwyntydd i mutability Ailgyflwyno:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Creu bloc newydd i gyfyngu ar gwmpas y benthyciad deinamig
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Sylwch, pe na baem wedi gadael i fenthyciad blaenorol y storfa ddisgyn allan o'i gwmpas, yna byddai'r benthyciad dilynol yn achosi edau ddeinamig panic.
//!     //
//!     // Mae hyn yn y perygl mawr o ddefnyddio `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Noder bod yr enghraifft hon yn defnyddio `Rc<T>` ac nid `Arc<T>`.`RefCell<T>mae s ar gyfer senarios un edefyn.Ystyriwch ddefnyddio [`RwLock<T>`] neu [`Mutex<T>`] a oes angen mutability mewn sefyllfa aml-threaded a rennir.
//!
//! ## Manylion Gweithredu dulliau rhesymegol-ddigyfnewid
//!
//! Weithiau, gallai fod yn ddymunol peidio â datgelu mewn API bod treiglad yn digwydd "under the hood".
//! Gall hyn fod oherwydd bod rhesymegol y llawdriniaeth yn ddigyfnewid, ond ee, caching lluoedd gweithredu i berfformio treiglo;neu oherwydd mae'n rhaid i chi gyflogi mwtaniad i weithredu dull trait a ddiffiniwyd yn wreiddiol i gymryd `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Mae cyfrifiant drud yn mynd yma
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Gweithrediadau treiglo `Clone`
//!
//! Mae hyn yn unig yw arbennig, ond cyffredin, achos yr blaenorol: mutability cuddio ar gyfer gweithrediadau sy'n ymddangos yn ddigyfnewid.
//! Disgwylir i'r dull [`clone`](Clone::clone) beidio â newid gwerth y ffynhonnell, a datganir ei fod yn cymryd `&self`, nid `&mut self`.
//! Felly, rhaid i unrhyw dreiglad sy'n digwydd yn y dull `clone` ddefnyddio mathau o gelloedd.
//! Er enghraifft, mae [`Rc<T>`] yn cynnal ei gyfrifiadau cyfeirio o fewn `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Lleoliad cof mutable.
///
/// # Examples
///
/// Yn yr enghraifft hon, gallwch weld bod `Cell<T>` yn galluogi treiglo tu mewn struct ddigyfnewid.
/// Mewn geiriau eraill, mae'n galluogi "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // GWALL: Mae `my_struct` yn anadferadwy
/// // my_struct.regular_field =new_value;
///
/// // GWAITH: er bod `my_struct` yn anadferadwy, mae `special_field` yn `Cell`,
/// // y gellir eu treiglo bob amser
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Gweler y [module-level documentation](self) am fwy.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Creu `Cell<T>`, gyda gwerth `Default` am T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Yn creu `Cell` newydd sy'n cynnwys y gwerth a roddir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Gosod y gwerth a geir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Cyfnewidiadau gwerthoedd dau Celloedd.
    /// Gwahaniaeth gyda `std::mem::swap` yw nad yw swyddogaeth hon oes angen cyfeirio `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // DIOGELWCH: Gall hyn fod yn beryglus os galw o edafedd ar wahân, ond `Cell`
        // yw `!Sync` felly ni fydd hyn yn digwydd.
        // Mae hyn, ni fydd hefyd yn annilysu unrhyw awgrymiadau ers `Cell` yn gwneud yn siwr unrhyw beth arall fydd yn pwyntio i mewn i un o'r rhain `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Yn disodli gwerth a geir gyda `val`, ac yn dychwelyd yr hen werth a geir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // DIOGELWCH: Gall hyn achosi rasys data os alw o edau ar wahân,
        // ond `Cell` yw `!Sync` felly ni fydd hyn yn digwydd.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Unwraps gwerth.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Dychwelyd copi o'r gwerth a geir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // DIOGELWCH: Gall hyn achosi rasys data os alw o edau ar wahân,
        // ond `Cell` yw `!Sync` felly ni fydd hyn yn digwydd.
        unsafe { *self.value.get() }
    }

    /// Diweddaru'r gwerth a geir drwy ddefnyddio swyddogaeth a dychwelyd y gwerth newydd.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Ffurflenni pwyntydd crai i'r data sylfaenol yn y gell hon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Ffurflenni cyfeiriad mutable at y data sylfaenol.
    ///
    /// Mae'r alwad hon yn benthyca `Cell` yn fân (ar amser llunio) sy'n gwarantu mai ni sydd â'r unig gyfeirnod.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Yn dychwelyd `&Cell<T>` o `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // DIOGELWCH: Mae `&mut` yn sicrhau mynediad unigryw.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Yn cymryd gwerth y gell, gan adael `Default::default()` yn ei lle.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Yn dychwelyd `&[Cell<T>]` o `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // Mae gan `Cell<T>` yr un gosodiad cof fel `T`: DIOGELWCH.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Lleoliad cof symudol gyda rheolau benthyca wedi'u gwirio'n ddeinamig
///
/// Gweler y [module-level documentation](self) am fwy.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Gwall a ddychwelwyd gan [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Gwall a ddychwelwyd gan [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// gwerthoedd cadarnhaol yn cynrychioli nifer y `Ref` gweithredol.Mae gwerthoedd negyddol yn cynrychioli nifer yr `RefMut` gweithredol.
// Gall Lluosog `RefMut`s yn unig fod yn weithgar ar y tro os ydynt yn cyfeirio at wahanol nonoverlapping gydrannau, o `RefCell` (ee, ystodau gwahanol o sleisen).
//
// `Ref` a `RefMut` ill dau yn ddau air o ran maint, ac felly bydd yn debygol byth yn ddigon `Ref`s neu`RefMut`s mewn bodolaeth i gorlif hanner o'r ystod `usize`.
// Felly, mae `BorrowFlag` mae'n debyg y bydd byth yn gorlifo neu'n islif.
// Fodd bynnag, nid yw hyn yn gwarantu, fel y gallai rhaglen patholegol creu dro ar ôl tro ac yna mem::forget `Ref`s neu`RefMut`s.
// Felly, rhaid i bob cod wirio'n benodol am orlif a gorlif er mwyn osgoi anniogel, neu o leiaf ymddwyn yn gywir os bydd gorlif neu orlif yn digwydd (ee, gweler BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Yn creu `RefCell` newydd sy'n cynnwys `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Yn defnyddio'r `RefCell`, gan ddychwelyd y gwerth wedi'i lapio.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Gan fod y swyddogaeth hon yn cymryd `self` (yr `RefCell`) yn ôl gwerth, mae'r casglwr yn dilysu'n statig nad yw'n cael ei fenthyg ar hyn o bryd.
        //
        self.value.into_inner()
    }

    /// Yn disodli'r gwerth wedi'i lapio ag un newydd, gan ddychwelyd yr hen werth, heb ddad-ddynodi'r naill na'r llall.
    ///
    ///
    /// Mae'r swyddogaeth hon yn cyfateb i [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics os yw gwerth ei fenthyca ar hyn o bryd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Yn disodli gwerth lapio gyda un newydd gyfrifo o `f`, gan ddychwelyd yr hen werth, heb deinitializing naill ai un.
    ///
    ///
    /// # Panics
    ///
    /// Panics os yw gwerth ei fenthyca ar hyn o bryd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Yn cyfnewid gwerth lapio `self` gyda gwerth lapio `other`, heb ddad-ddynodi'r naill na'r llall.
    ///
    ///
    /// Mae'r swyddogaeth hon yn cyfateb i [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics os yw gwerth yn y naill `RefCell` ei fenthyca ar hyn o bryd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Yn fenthyg benthyg y gwerth wedi'i lapio.
    ///
    /// Mae'r benthyciad yn para nes bod yr `Ref` a ddychwelwyd yn gadael ei gwmpas.
    /// Gall Borrows ddigyfnewid Lluosog yn cael eu cymryd allan ar yr un pryd.
    ///
    /// # Panics
    ///
    /// Panics os yw gwerth ei fenthyca mutably ar hyn o bryd.
    /// Am amrywiad nad yw'n mynd i banig, defnyddiwch [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Enghraifft o panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Immutably benthyg gwerth lapio, gan ddychwelyd gwall os yw gwerth ei fenthyca mutably ar hyn o bryd.
    ///
    ///
    /// Mae'r benthyciad yn para nes bod yr `Ref` a ddychwelwyd yn gadael ei gwmpas.
    /// Gall Borrows ddigyfnewid Lluosog yn cael eu cymryd allan ar yr un pryd.
    ///
    /// Mae hyn yn y nad ydynt yn mynd i banig amrywiad ar [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // DIOGELWCH: `BorrowRef` yn sicrhau mai dim ond mynediad ddigyfnewid
            // at werth tra fenthycwyd.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mae cyd-fenthyg y gwerth wedi'i lapio.
    ///
    /// Mae'r benthyg yn para nes bod y `RefMut` dychwelyd neu gyd `RefMut`s deillio ohono gwmpas allanfa.
    ///
    /// Ni all y gwerth yn cael ei benthyg tra benthyg hwn yn weithredol.
    ///
    /// # Panics
    ///
    /// Panics os yw gwerth ei fenthyca ar hyn o bryd.
    /// Am amrywiad nad yw'n mynd i banig, defnyddiwch [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Enghraifft o panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mae cyd-fenthyg y gwerth wedi'i lapio, gan ddychwelyd gwall os yw'r gwerth yn cael ei fenthyg ar hyn o bryd.
    ///
    ///
    /// Mae'r benthyg yn para nes bod y `RefMut` dychwelyd neu gyd `RefMut`s deillio ohono gwmpas allanfa.
    /// Ni all y gwerth yn cael ei benthyg tra benthyg hwn yn weithredol.
    ///
    /// Mae hyn yn y nad ydynt yn mynd i banig amrywiad ar [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // DIOGELWCH: Mae `BorrowRef` yn gwarantu mynediad unigryw.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Ffurflenni pwyntydd crai i'r data sylfaenol yn y gell hon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Ffurflenni cyfeiriad mutable at y data sylfaenol.
    ///
    /// Mae'r alwad yn benthyg `RefCell` mutably (ar crynhoi amser) felly nid oes angen am wiriadau deinamig.
    ///
    /// Fodd bynnag, byddwch yn ofalus: mae'r dull hwn yn disgwyl i `self` yn mutable, ac nid yw ar y cyfan yn wir wrth ddefnyddio `RefCell`.
    ///
    /// Cymerwch olwg ar y dull [`borrow_mut`] yn lle os nad `self` yn mutable.
    ///
    /// Hefyd, byddwch yn ymwybodol bod y dull hwn ar gyfer amgylchiadau arbennig yn unig ac fel arfer nid dyna'r hyn rydych chi ei eisiau.
    /// Mewn achos o amheuaeth, defnyddiwch [`borrow_mut`] yn lle hynny.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Dadwneud effaith gwarchodwyr gollwng ar gyflwr benthyg y `RefCell`.
    ///
    /// Mae'r alwad yn debyg i [`get_mut`] ond yn fwy arbenigol.
    /// Mae'n benthyca `RefCell` yn fân i sicrhau nad oes benthyciadau yn bodoli ac yna'n ailosod y wladwriaeth gan olrhain benthyciadau a rennir.
    /// Mae hyn yn berthnasol os yw rhai benthyciadau `Ref` neu `RefMut` wedi'u gollwng.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Immutably benthyg gwerth lapio, gan ddychwelyd gwall os yw gwerth ei fenthyca mutably ar hyn o bryd.
    ///
    /// # Safety
    ///
    /// Yn wahanol i `RefCell::borrow`, y dull hwn yn anniogel oherwydd nad yw'n dychwelyd `Ref`, gan adael y faner benthyca heb ei gyffwrdd.
    /// Mutably benthyca'r `RefCell` tra bod y cyfeiriad a ddychwelwyd gan y dull hwn yn fyw yn ymddygiad anniffiniedig.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // DIOGELWCH: Byddwn yn gwirio nad oes neb yn mynd ati i ysgrifennu yn awr, ond mae'n
            // cyfrifoldeb y galwr i sicrhau nad oes neb yn ysgrifennu nes nad yw'r cyfeirnod a ddychwelwyd yn cael ei ddefnyddio mwyach.
            // Hefyd, mae `self.value.get()` yn cyfeirio at y gwerth sy'n eiddo i `self` ac felly mae'n sicr y bydd yn ddilys am oes `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Cymryd gwerth lapio, gan adael `Default::default()` yn ei le.
    ///
    /// # Panics
    ///
    /// Panics os yw gwerth ei fenthyca ar hyn o bryd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics os yw gwerth ei fenthyca mutably ar hyn o bryd.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Creu `RefCell<T>`, gyda gwerth `Default` am T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics os yw gwerth yn y naill `RefCell` ei fenthyca ar hyn o bryd.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics os yw gwerth yn y naill `RefCell` ei fenthyca ar hyn o bryd.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics os yw gwerth yn y naill `RefCell` ei fenthyca ar hyn o bryd.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics os yw gwerth yn y naill `RefCell` ei fenthyca ar hyn o bryd.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics os yw gwerth yn y naill `RefCell` ei fenthyca ar hyn o bryd.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics os yw gwerth yn y naill `RefCell` ei fenthyca ar hyn o bryd.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics os yw gwerth yn y naill `RefCell` ei fenthyca ar hyn o bryd.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Gall cynyddu benthyciad arwain at werth nad yw'n ddarllen (<=0) yn yr achosion hyn:
            // 1. Roedd yn <0, hy mae yna fenthyciadau ysgrifennu, felly ni allwn ganiatáu benthyg darllen oherwydd rheolau aliasio cyfeirnod Rust
            // 2.
            // Roedd isize::MAX (y swm max darllen Borrows) ac mae'n gorlifo i mewn i isize::MIN (y swm max o ysgrifennu Borrows) felly ni allwn ganiatáu i benthyg ychwanegol darllen oherwydd na all isize cynrychioli cymaint o Borrows darllen (gall hyn ond digwydd os ydych mem::forget yn fwy na swm cyson bach o `Ref`s, nad yw'n arfer da)
            //
            //
            //
            //
            None
        } else {
            // Gall cynyddu benthyciad arwain at werth darllen (> 0) yn yr achosion hyn:
            // 1. Roedd=0, hy cafodd ei benthyg, ac rydym yn cymryd y benthyca cyntaf darllen
            // 2. Roedd> 0 a <isize::MAX, hy
            // roedd Borrows darllen, ac isize ddigon mawr i gynrychioli cael un benthyg mwy darllen
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Gan fod y Cyf hwn yn bodoli, rydym yn gwybod bod y faner fenthyg yn fenthyciad darllen.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Atal y benthyg cownter rhag gorlifo i mewn i benthyg ysgrifennu.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Wraps cyfeiriad fenthycwyd i werth mewn blwch `RefCell`.
/// Mae math lapio am werth a fenthycwyd immutably o `RefCell<T>`.
///
/// Gweler y [module-level documentation](self) am fwy.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Copïau o `Ref`.
    ///
    /// Mae'r `RefCell` eisoes wedi'i fenthyca'n anadferadwy, felly ni all hyn fethu.
    ///
    /// Mae hon yn swyddogaeth gysylltiedig y mae angen ei defnyddio fel `Ref::clone(...)`.
    /// Byddai gweithrediad `Clone` neu ddull yn ymyrryd â'r defnydd eang o `r.borrow().clone()` i glonio cynnwys `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Yn gwneud `Ref` newydd ar gyfer cydran o'r data a fenthycwyd.
    ///
    /// Mae'r `RefCell` eisoes wedi'i fenthyca'n anadferadwy, felly ni all hyn fethu.
    ///
    /// Mae hyn yn swyddogaeth cysylltiedig y mae angen ei ddefnyddio fel `Ref::map(...)`.
    /// Byddai dull yn ymyrryd â dulliau o'r un enw ar gynnwys `RefCell` a ddefnyddir trwy `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Gwneud `Ref` newydd ar gyfer elfen ddewisol o'r data a fenthycwyd.
    /// Mae'r gard gwreiddiol yn cael ei dychwelyd fel `Err(..)` pe gau yn dychwelyd `None`.
    ///
    /// Mae'r `RefCell` eisoes wedi'i fenthyca'n anadferadwy, felly ni all hyn fethu.
    ///
    /// Mae hyn yn swyddogaeth cysylltiedig y mae angen ei ddefnyddio fel `Ref::filter_map(...)`.
    /// Byddai dull yn ymyrryd â dulliau o'r un enw ar gynnwys `RefCell` a ddefnyddir trwy `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Rhannu a `Ref` mewn i lluosog `Ref`s ar gyfer gwahanol elfennau o'r data a fenthycwyd.
    ///
    /// Mae'r `RefCell` eisoes wedi'i fenthyca'n anadferadwy, felly ni all hyn fethu.
    ///
    /// Mae hyn yn swyddogaeth cysylltiedig y mae angen ei ddefnyddio fel `Ref::map_split(...)`.
    /// Byddai dull yn ymyrryd â dulliau o'r un enw ar gynnwys `RefCell` a ddefnyddir trwy `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Trosi i mewn i gyfeirio at y data sylfaenol.
    ///
    /// Ni all y `RefCell` gwaelodol ei fenthyca mutably o eto a bydd yn ymddangos bob amser yn barod benthyg immutably.
    ///
    /// Nid yw'n syniad da gollwng mwy na nifer gyson o gyfeiriadau.
    /// Gellir benthyca'r `RefCell` yn anadferadwy eto os mai dim ond nifer llai o ollyngiadau sydd wedi digwydd i gyd.
    ///
    /// Mae hon yn swyddogaeth gysylltiedig y mae angen ei defnyddio fel `Ref::leak(...)`.
    /// Byddai dull yn ymyrryd â dulliau o'r un enw ar gynnwys `RefCell` a ddefnyddir trwy `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Trwy anghofio'r Cyf. Hwn, rydym yn sicrhau na all y cownter benthyca yn y RefCell fynd yn ôl i UNUSED o fewn oes `'b`.
        // Byddai Ailosod y wladwriaeth cyfeirio olrhain angen cyfeirnod unigryw i'r RefCell fenthycwyd.
        // Ni ellir creu unrhyw gyfeiriadau symudol eraill o'r gell wreiddiol.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Gwneud `RefMut` newydd ar gyfer elfen o'r data a fenthycwyd, ee, mae enum amrywiad.
    ///
    /// Mae'r `RefCell` eisoes wedi'i fenthyg ar y cyd, felly ni all hyn fethu.
    ///
    /// Mae hon yn swyddogaeth gysylltiedig y mae angen ei defnyddio fel `RefMut::map(...)`.
    /// Byddai dull yn ymyrryd â dulliau o'r un enw ar gynnwys `RefCell` a ddefnyddir trwy `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): atgyweiria benthyg-wiriad
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Gwneud `RefMut` newydd ar gyfer elfen ddewisol o'r data a fenthycwyd.
    /// Mae'r gard gwreiddiol yn cael ei dychwelyd fel `Err(..)` pe gau yn dychwelyd `None`.
    ///
    /// Mae'r `RefCell` eisoes wedi'i fenthyg ar y cyd, felly ni all hyn fethu.
    ///
    /// Mae hon yn swyddogaeth gysylltiedig y mae angen ei defnyddio fel `RefMut::filter_map(...)`.
    /// Byddai dull yn ymyrryd â dulliau o'r un enw ar gynnwys `RefCell` a ddefnyddir trwy `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): atgyweiria benthyg-wiriad
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // DIOGELWCH: swyddogaeth yn dal i gyfeiriad unigryw ar gyfer y cyfnod
        // o'i alwad trwy `orig`, a dim ond y tu mewn i'r alwad swyddogaeth y mae'r pwyntydd yn cael ei ddad-gyfeirio byth yn caniatáu i'r cyfeirnod unigryw ddianc.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // DIOGELWCH: yr un fath ag uchod.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Rhannu a `RefMut` mewn i lluosog `RefMut`s ar gyfer gwahanol elfennau o'r data a fenthycwyd.
    ///
    /// Bydd yr `RefCell` sylfaenol yn parhau i gael ei fenthyg ar y cyd nes i'r ddau ddychwelyd `RefMut`s fynd allan o'u cwmpas.
    ///
    /// Mae'r `RefCell` eisoes wedi'i fenthyg ar y cyd, felly ni all hyn fethu.
    ///
    /// Mae hon yn swyddogaeth gysylltiedig y mae angen ei defnyddio fel `RefMut::map_split(...)`.
    /// Byddai dull yn ymyrryd â dulliau o'r un enw ar gynnwys `RefCell` a ddefnyddir trwy `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Trosi i gyfeiriad cyfnewidiol at y data sylfaenol.
    ///
    /// Ni all y `RefCell` gwaelodol ei fenthyca gan unwaith eto a bydd yn ymddangos bob amser yn barod benthyg mutably, gan wneud y cyfeiriad dychwelyd yr unig i'r tu mewn.
    ///
    ///
    /// Mae hon yn swyddogaeth gysylltiedig y mae angen ei defnyddio fel `RefMut::leak(...)`.
    /// Byddai dull yn ymyrryd â dulliau o'r un enw ar gynnwys `RefCell` a ddefnyddir trwy `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Trwy anghofio'r BorrowRefMut hwn rydym yn sicrhau na all y cownter benthyca yn y RefCell fynd yn ôl i UNUSED o fewn oes `'b`.
        // Byddai Ailosod y wladwriaeth cyfeirio olrhain angen cyfeirnod unigryw i'r RefCell fenthycwyd.
        // Ni all unrhyw gyfeiriadau pellach yn cael ei greu gan y gell gwreiddiol o fewn y oes, gan wneud y benthyca presennol yr unig cyfeirio ar gyfer gweddill oes.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Yn wahanol i BorrowRefMut::clone, a elwir newydd i greu'r cychwynnol
        // cyfeirnod symudol, ac felly mae'n rhaid nad oes unrhyw gyfeiriadau ar hyn o bryd.
        // Felly, er bod clôn yn cynyddu'r ailgyfrifiad symudol, yma dim ond o UNUSED i UNUSED yr ydym yn caniatáu mynd yn benodol.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clonau a `BorrowRefMut`.
    //
    // Mae hyn yn ddilys oni bai pob `BorrowRefMut` yn cael ei ddefnyddio i olrhain cyfeiriad mutable at wahanol nonoverlapping ystod y gwrthrych gwreiddiol,.
    //
    // Nid yw hyn yn mewn impl Clone fel nad yw cod yn galw hyn yn ymhlyg.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Atal y cownter benthyg rhag gorlifo.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Mae math lapio am werth a fenthycwyd mutably o `RefCell<T>`.
///
/// Gweler y [module-level documentation](self) am fwy.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Y cyntefig craidd ar gyfer treiddioldeb mewnol yn Rust.
///
/// Os oes gennych gyfeiriad `&T`, yna fel arfer yn Rust y optimeiddiad perfformio casglwr yn seiliedig ar y wybodaeth y pwyntiau `&T` data ddigyfnewid.Mae treiglo'r data hwnnw, er enghraifft trwy alias neu drwy drawsnewid `&T` yn `&mut T`, yn cael ei ystyried yn ymddygiad heb ei ddiffinio.
/// `UnsafeCell<T>` optio allan o'r warant immutability ar gyfer `&T`: gall cyfeirnod a rennir `&UnsafeCell<T>` dynnu sylw at ddata sy'n cael ei dreiglo.Gelwir hyn yn "interior mutability".
///
/// Pob math arall sy'n caniatáu mutability mewnol, fel `Cell<T>` a `RefCell<T>`, yn fewnol yn defnyddio `UnsafeCell` i lapio eu data.
///
/// Sylwch mai dim ond y warant immutability ar gyfer cyfeiriadau a rennir sy'n cael ei effeithio gan `UnsafeCell`.Nid yw'r warant unigryw ar gyfer cyfeiriadau symudol yn cael ei heffeithio.Nid *unrhyw ffordd gyfreithiol* i gael aliasing `&mut`, nid hyd yn oed gyda `UnsafeCell<T>`.
///
/// Mae'r API `UnsafeCell` ei hun yn dechnegol syml iawn: mae [`.get()`] yn rhoi pwyntydd amrwd `*mut T` i chi i'w gynnwys.Mae hyd at _you_ fel y dylunydd tynnu dŵr i ddefnyddio'r pwyntydd amrwd hwnnw'n gywir.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Mae union reolau aliasio Rust ychydig yn fflwcs, ond nid yw'r prif bwyntiau'n ddadleuol:
///
/// - Os ydych chi'n creu cyfeirnod diogel gydag oes `'a` (naill ai cyfeirnod `&T` neu `&mut T`) sy'n hygyrch trwy god diogel (er enghraifft, oherwydd ichi ei ddychwelyd), yna rhaid i chi beidio â chyrchu'r data mewn unrhyw ffordd sy'n gwrthddweud y cyfeirnod hwnnw am y gweddill. o `'a`.
/// Er enghraifft, mae hyn yn golygu, os cymerwch yr `*mut T` o `UnsafeCell<T>` a'i daflu i `&T`, yna mae'n rhaid i'r data yn `T` aros yn anadferadwy (modulo unrhyw ddata `UnsafeCell` a geir o fewn `T`, wrth gwrs) nes bod oes y cyfeirnod hwnnw'n dod i ben.
/// Yn yr un modd, os ydych chi'n creu cyfeirnod `&mut T` sy'n cael ei ryddhau i god diogel, yna rhaid i chi beidio â chyrchu'r data yn yr `UnsafeCell` nes i'r cyfeirnod hwnnw ddod i ben.
///
/// - Bob amser, rhaid i chi osgoi rasys data.Os edafedd lluosog yn cael mynediad at yr un `UnsafeCell`, yna rhaid i unrhyw ysgrifennu yn cael go iawn yn digwydd-cyn perthynas â'r holl mynedfeydd eraill (neu ddefnyddio Atomics).
///
/// Cynorthwyo gyda dyluniad priodol, mae'r senarios canlynol yn cael eu datgan yn benodol cyfreithiol ar gyfer cod un-threaded:
///
/// 1. Gellir rhyddhau cyfeirnod `&T` i god diogel ac yno gall gydfodoli â chyfeiriadau `&T` eraill, ond nid gyda `&mut T`
///
/// 2. Efallai y cyfeirnod A `&mut T` yn cael ei ryddhau i cod diogel a ddarperir naill arall `&mut T` nac `&T` cydfodoli ag ef.Rhaid i `&mut T` fod yn unigryw bob amser.
///
/// Sylwch, er bod treiglo cynnwys `&UnsafeCell<T>` (hyd yn oed tra bod cyfeiriadau `&UnsafeCell<T>` eraill yn alias y gell) yn iawn (ar yr amod eich bod yn gorfodi'r invariants uchod ryw ffordd arall), mae'n dal i fod yn ymddygiad heb ei ddiffinio i gael arallenwau `&mut UnsafeCell<T>` lluosog.
/// Hynny yw, `UnsafeCell` yn papur lapio gynlluniwyd i gael rhyngweithio arbennig gyda _shared_ accesses (_i.e._, drwy gyfeirio `&UnsafeCell<_>`);nid oes unrhyw hud o gwbl wrth ddelio â _exclusive_ accesses (_e.g._, drwy `&mut UnsafeCell<_>`): Efallai nad yw'r gell na'r gwerth lapio yn cael eu wedi'i anwybyddu drwy gydol y `&mut` benthyg.
///
/// Caiff hyn ei arddangos gan y accessor [`.get_mut()`], sy'n getter _safe_ sy'n yn cynhyrchu `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Dyma enghraifft yn dangos sut i dreiglo cynnwys `UnsafeCell<_>` yn gadarn er bod sawl cyfeiriad yn aliasio'r gell:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Cael cyfeiriadau lluosog/rhannu i'r un `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // DIOGELWCH: o fewn cwmpas hwn nid oes unrhyw gyfeiriadau eraill at `cynnwys x` yn,
///     // felly mae ein un ni i bob pwrpas yn unigryw.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- benthyg-+
///     *p1_exclusive += 27; // |
/// } // <---------- Ni all fynd y tu hwnt i'r pwynt -------------------+
///
/// unsafe {
///     // DIOGELWCH: o fewn y neb cwmpas yn disgwyl i gael mynediad unigryw i `cynnwys x` yn,
///     // felly gallwn gael sawl mynediad a rennir ar yr un pryd.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Mae'r enghraifft ganlynol yn arddangos y ffaith bod mynediad unigryw i `UnsafeCell<T>` yn awgrymu mynediad unigryw i'w `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // gyda mynedfeydd unigryw,
///                         // `UnsafeCell` yn lapiwr no-op tryloyw, felly nid oes angen `unsafe` yma.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Sicrhewch gyfeiriad unigryw at `x` wedi'i wirio gan amser.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Gyda cyfeirio unigryw, gallwn treiglo y cynnwys am ddim.
/// *p_unique.get_mut() = 0;
/// // Neu, gydradd:
/// x = UnsafeCell::new(0);
///
/// // Pan fyddwn yn berchen ar y gwerth, gallwn echdynnu'r cynnwys am ddim.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Yn llunio enghraifft newydd o `UnsafeCell` a fydd yn lapio'r gwerth penodedig.
    ///
    ///
    /// Yr holl fynediad i'r gwerth mewnol trwy ddulliau yw `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Unwraps gwerth.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Cael pwyntydd symudol i'r gwerth wedi'i lapio.
    ///
    /// Gall hyn fod cast i pwyntydd o unrhyw fath.
    /// Sicrhewch fod y fynedfa yn unigryw (dim cyfeiriadau gweithredol, treiddiol neu beidio) wrth gastio i `&mut T`, a sicrhau nad oes treigladau nac arallenwau treiddgar yn digwydd wrth gastio i `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // allwn fwrw pwyntydd o `UnsafeCell<T>` i `T` oherwydd #[repr(transparent)].
        // Mae hyn yn manteisio ar statws arbennig libstd, nid oes unrhyw sicrwydd ar gyfer cod defnyddiwr y bydd hyn yn gweithio mewn fersiynau future o'r crynhoydd!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Ffurflenni cyfeiriad mutable at y data sylfaenol.
    ///
    /// Mae'r alwad hon yn benthyca'r `UnsafeCell` yn fân (ar amser llunio) sy'n gwarantu mai ni sydd â'r unig gyfeirnod.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Cael pwyntydd symudol i'r gwerth wedi'i lapio.
    /// Y gwahaniaeth i [`get`] yw bod y swyddogaeth hon yn derbyn pwyntydd amrwd, sy'n ddefnyddiol i osgoi creu cyfeiriadau dros dro.
    ///
    /// Gellir bwrw'r canlyniad i bwyntydd o unrhyw fath.
    /// Sicrhewch fod y fynedfa yn unigryw (dim cyfeiriadau gweithredol, treiddiol neu beidio) wrth gastio i `&mut T`, a sicrhau nad oes treigladau nac arallenwau treiddgar yn digwydd wrth gastio i `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Mae cychwyn `UnsafeCell` yn raddol yn gofyn am `raw_get`, gan y byddai galw `get` yn gofyn am greu cyfeiriad at ddata heb ei ddynodi:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // allwn fwrw pwyntydd o `UnsafeCell<T>` i `T` oherwydd #[repr(transparent)].
        // Mae hyn yn manteisio ar statws arbennig libstd, nid oes unrhyw sicrwydd ar gyfer cod defnyddiwr y bydd hyn yn gweithio mewn fersiynau future o'r crynhoydd!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Creu `UnsafeCell`, gyda gwerth `Default` am T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}