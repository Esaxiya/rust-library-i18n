use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Mae rhyngwyneb ar gyfer ymdrin â iterators asynchronous.
///
/// Dyma'r brif ffrwd trait.
/// I gael rhagor o wybodaeth am y cysyniad o nentydd yn gyffredinol, gweler y [module-level documentation].
/// Yn benodol, efallai yr hoffech wybod sut i [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Y math o eitemau a esgor ger y nant.
    type Item;

    /// Ceisiwch dynnu gwerth nesaf y nant hon allan, gan gofrestru'r dasg gyfredol ar gyfer deffro os nad yw'r gwerth ar gael eto, a dychwelyd `None` os yw'r nant wedi disbyddu.
    ///
    /// # Gwerth dychwelyd
    ///
    /// Mae yna sawl gwerth dychwelyd posib, pob un yn nodi cyflwr nant penodol:
    ///
    /// - `Poll::Pending` yn golygu nad yw gwerth nesaf y nant hon yn barod eto.Bydd gweithrediadau yn sicrhau y bydd y dasg gyfredol yn cael ei hysbysu pryd y gall y gwerth nesaf fod yn barod.
    ///
    /// - `Poll::Ready(Some(val))` yn golygu bod y nant wedi cynhyrchu gwerth, `val`, a gall gynhyrchu gwerthoedd pellach ar alwadau `poll_next` dilynol.
    ///
    /// - `Poll::Ready(None)` yn golygu bod y nant wedi dod i ben, ac ni ddylid galw `poll_next` eto.
    ///
    /// # Panics
    ///
    /// Ar ôl i nant orffen (wedi dychwelyd `Ready(None)` from `poll_next`), gan alw ei dull `poll_next` eto gall panic, blocio am byth, neu achosi mathau eraill o broblemau; nid yw'r `Stream` trait yn gosod unrhyw ofynion ar effeithiau galwad o'r fath.
    ///
    /// Fodd bynnag, gan nad yw'r dull `poll_next` wedi'i farcio `unsafe`, mae rheolau arferol Rust yn berthnasol: rhaid i alwadau byth achosi ymddygiad heb ei ddiffinio (llygredd cof, defnydd anghywir o swyddogaethau `unsafe`, neu debyg), waeth beth yw cyflwr y nant.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Dychwelyd y terfynau ar hyd gweddill y nant.
    ///
    /// Yn benodol, `size_hint()` yn dychwelyd tuple lle mae'r elfen gyntaf yn rhwymo yr isaf, a'r ail elfen yw'r rhwymo uchaf.
    ///
    /// Ail hanner y twple sy'n cael ei ddychwelyd yw [`Opsiwn`]`<`[`usize`] `>`.
    /// A [`None`] yma yn golygu naill ai nad oes yn hysbys uchaf rhwymo, neu'r rhwymo uchaf yn fwy na [`usize`].
    ///
    /// # nodiadau Gweithredu
    ///
    /// Ni orfodir bod gweithrediad nant yn esgor ar y nifer datganedig o elfennau.Gall nant bygi gynhyrchu llai na'r rhimyn isaf neu fwy na'r rhimyn uchaf o elfennau.
    ///
    /// `size_hint()` wedi'i fwriadu yn bennaf i'w defnyddio ar gyfer optimeiddiad megis cadw'r lle ar gyfer yr elfennau y nant, ond ni ddylai fod yn ymddiried ynddo i ee gwiriadau terfynau hepgorer mewn cod anniogel.
    /// Ni ddylai weithredu anghywir `size_hint()` yn arwain at droseddau diogelwch cof.
    ///
    /// Wedi dweud hynny, dylai'r gweithrediad ddarparu amcangyfrif cywir, oherwydd fel arall byddai'n groes protocol y trait yn.
    ///
    /// Mae'r gweithredu diofyn yn dychwelyd `(0,` [`Dim`]`)`sy'n gywir ar gyfer unrhyw nant.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}