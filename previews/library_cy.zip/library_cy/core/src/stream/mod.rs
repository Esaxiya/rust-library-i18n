//! Ailadroddiad asyncronig compostadwy.
//!
//! Os yw futures yn werthoedd asyncronig, yna mae ffrydiau'n ailadroddwyr asyncronig.
//! Os ydych chi wedi cael eich hun gyda chasgliad asyncronig o ryw fath, ac angen perfformio gweithrediad ar elfennau'r casgliad hwnnw, byddwch chi'n rhedeg i mewn i 'streams' yn gyflym.
//! Defnyddir nentydd yn helaeth mewn cod Rust asyncronig idiomatig, felly mae'n werth dod yn gyfarwydd â nhw.
//!
//! Cyn egluro mwy, gadewch i ni siarad am strwythur y modiwl hwn:
//!
//! # Organization
//!
//! Mae'r modiwl hwn yn cael ei drefnu i raddau helaeth yn ôl math:
//!
//! * [Traits] yw'r gyfran graidd: mae'r traits hyn yn diffinio pa fath o ffrydiau sy'n bodoli a beth allwch chi ei wneud gyda nhw.Mae'n werth rhoi rhywfaint o amser astudio ychwanegol i ddulliau'r traits hyn.
//! * Mae swyddogaethau'n darparu rhai ffyrdd defnyddiol o greu rhai ffrydiau sylfaenol.
//! * Structs yn aml y mathau dychwelyd y gwahanol ddulliau ar traits modiwl hwn.Fel arfer, byddwch chi am edrych ar y dull sy'n creu'r `struct`, yn hytrach na'r `struct` ei hun.
//! Am fwy o fanylion ynghylch pam, gweler '[Gweithredu Ffrwd](#gweithredu-ffrwd)'.
//!
//! [Traits]: #traits
//!
//! Dyna ni!Gadewch i ni gloddio i mewn i nentydd.
//!
//! # Stream
//!
//! Calon ac enaid y modiwl hwn yw'r [`Stream`] trait.Mae craidd [`Stream`] yn edrych fel hyn:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Yn wahanol i `Iterator`, `Stream` yn gwahaniaethu rhwng y dull [`poll_next`], sy'n defnyddio wrth weithredu `Stream`, a dull (to-be-implemented) `next` a ddefnyddir wrth cymryd llawer o nant.
//!
//! Mae angen dim ond defnyddwyr `Stream` i ystyried `next`, a oedd pan elwir, yn dychwelyd future sy'n gynnyrch `Option<Stream::Item>`.
//!
//! Bydd y future a ddychwelir gan `next` yn esgor ar `Some(Item)` cyhyd â bod elfennau, ac unwaith y byddant i gyd wedi disbyddu, bydd yn cynhyrchu `None` i nodi bod iteriad wedi'i orffen.
//! Os ydym yn aros ar rywbeth asynchronous i ddatrys, bydd y future aros nes y nant yn barod i ildio eto.
//!
//! Efallai y bydd ffrydiau unigol yn dewis ailddechrau iteriad, ac felly gall galw `next` eto ildio `Some(Item)` eto ar ryw adeg.
//!
//! Mae diffiniad llawn [`Stream`] yn cynnwys nifer o ddulliau eraill hefyd, ond maent yn ddulliau diofyn, wedi'u hadeiladu ar ben [`poll_next`], ac felly rydych chi'n eu cael am ddim.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Ffrwd Gweithredu
//!
//! Creu ffrwd eich hun yn cynnwys dau gam: creu `struct` i ddal y wladwriaeth y nant, ac yna gweithredu [`Stream`] am hynny `struct`.
//!
//! Gadewch i ni wneud nant o'r enw `Counter` sy'n cyfrif o `1` i `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Yn gyntaf, y strwythur:
//!
//! /// Ffrwd sy'n cyfrif o un i bump
//! struct Counter {
//!     count: usize,
//! }
//!
//! // rydym am i'n cyfrif i ddechrau am un, felly gadewch i ni ychwanegu dull new() i help.
//! // Nid yw hyn yn hollol angenrheidiol, ond yn gyfleus.
//! // Sylwch ein bod yn dechrau `count` ar sero, fe welwn pam wrth weithredu `poll_next()`'s isod.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Yna, rydyn ni'n gweithredu `Stream` ar gyfer ein `Counter`:
//!
//! impl Stream for Counter {
//!     // byddwn yn cyfrif gyda ni
//!     type Item = usize;
//!
//!     // poll_next() yw'r dull yn unig sy'n ofynnol
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Cynyddiad ein cyfrif.Dyma pam ein bod yn dechrau ar sero.
//!         self.count += 1;
//!
//!         // Edrychwch i weld os rydym wedi cyfrif gorffenedig neu beidio.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Nentydd yn * * ddiog.Mae hyn yn golygu nad yw creu nant yn _do_ yn llawer iawn.Nid oes dim yn digwydd mewn gwirionedd nes i chi ffonio `next`.
//! Weithiau mae hyn yn destun dryswch wrth greu nant ar gyfer ei sgîl-effeithiau yn unig.
//! Bydd y casglwr yn ein rhybuddio am y math hwn o ymddygiad:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;