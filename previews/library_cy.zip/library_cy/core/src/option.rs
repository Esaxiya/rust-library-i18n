//! Gwerthoedd dewisol.
//!
//! Mae Math [`Option`] yn cynrychioli gwerth dewisol: mae pob [`Option`] naill ai'n [`Some`] ac yn cynnwys gwerth, neu [`None`], ac nid yw.
//! [`Option`] mae mathau'n gyffredin iawn yng nghod Rust, gan fod ganddyn nhw nifer o ddefnyddiau:
//!
//! * Gwerthoedd cychwynnol
//! * Gwerthoedd dychwelyd ar gyfer swyddogaethau nad ydynt wedi'u diffinio dros eu hystod fewnbwn gyfan (swyddogaethau rhannol)
//! * Gwerth dychwelyd am riportio gwallau syml fel arall, lle dychwelir [`None`] ar gamgymeriad
//! * Meysydd strwythuredig dewisol
//! * Meysydd strwythur y gellir eu benthyca neu "taken"
//! * Dadleuon swyddogaeth ddewisol
//! * Awgrymiadau y gellir eu hoelio
//! * Cyfnewid pethau allan o sefyllfaoedd anodd
//!
//! Mae [`opsiwn`] fel arfer yn cael eu paru â chydweddu patrwm i gwestiynu presenoldeb gwerth a gweithredu, gan gyfrif am achos [`None`] bob amser.
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // Mae gwerth dychwelyd y swyddogaeth yn opsiwn
//! let result = divide(2.0, 3.0);
//!
//! // Cydweddiad patrwm i adfer y gwerth
//! match result {
//!     // Roedd yr adran yn ddilys
//!     Some(x) => println!("Result: {}", x),
//!     // Roedd yr adran yn annilys
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: Dangoswch sut mae `Option` yn cael ei ddefnyddio'n ymarferol, gyda llawer o ddulliau
//
//! # Opsiynau ac awgrymiadau (awgrymiadau "nullable")
//!
//! Rhaid i fathau pwyntydd Rust bob amser bwyntio at leoliad dilys;nid oes unrhyw gyfeiriadau "null".Yn lle, mae gan Rust awgrymiadau *dewisol*, fel y blwch dewisol sy'n eiddo, [`Opsiwn`]`<`[`Blwch<T>`]`>`.
//!
//! Mae'r enghraifft ganlynol yn defnyddio [`Option`] i greu blwch dewisol o [`i32`].
//! Sylwch, er mwyn defnyddio'r gwerth [`i32`] mewnol yn gyntaf, mae angen i'r swyddogaeth `check_optional` ddefnyddio paru patrymau i benderfynu a oes gan y blwch werth (hy, mae'n [`Some(...)`][`Some`]) ai peidio ([`None`]).
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Mae Rust yn gwarantu gwneud y gorau o'r mathau `T` canlynol fel bod gan [`Option<T>`] yr un maint â `T`:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` strwythuro o amgylch un o'r mathau ar y rhestr hon.
//!
//! Gwarantir ymhellach, ar gyfer yr achosion uchod, y gall un [`mem::transmute`] o holl werthoedd dilys `T` i `Option<T>` ac o `Some::<T>(_)` i `T` (ond mae trawsfudo `None::<T>` i `T` yn ymddygiad heb ei ddiffinio).
//!
//! # Examples
//!
//! Paru patrwm sylfaenol ar [`Option`]:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // Cyfeiriwch at y llinyn sydd wedi'i gynnwys
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // Tynnwch y llinyn sydd wedi'i gynnwys, gan ddinistrio'r Opsiwn
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! Dechreuwch ganlyniad i [`None`] cyn dolen:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // Rhestr o ddata i chwilio drwyddo.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // Rydyn ni'n mynd i chwilio am enw'r anifail mwyaf, ond i ddechrau, mae `None` gyda ni.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // Nawr rydyn ni wedi dod o hyd i enw anifail mawr
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// Y math `Option`.Gweler [the module level documentation](self) am fwy.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// Dim gwerth
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// Mae rhai yn gwerthfawrogi `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// Math o weithredu
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // Ymholi am y gwerthoedd a gynhwysir
    /////////////////////////////////////////////////////////////////////////

    /// Yn dychwelyd `true` os yw'r opsiwn yn werth [`Some`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// Yn dychwelyd `true` os yw'r opsiwn yn werth [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// Yn dychwelyd `true` os yw'r opsiwn yn werth [`Some`] sy'n cynnwys y gwerth a roddir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Addasydd ar gyfer gweithio gyda chyfeiriadau
    /////////////////////////////////////////////////////////////////////////

    /// Trosiadau o `&Option<T>` i `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Trosi `Opsiwn <` [`String`]`>`yn`Opsiwn <`[`usize`] `>`, gan gadw'r gwreiddiol.
    /// Mae'r dull [`map`] yn cymryd dadl `self` yn ôl gwerth, gan ddefnyddio'r gwreiddiol, felly mae'r dechneg hon yn defnyddio `as_ref` i fynd â `Option` yn gyntaf i gyfeirio at y gwerth y tu mewn i'r gwreiddiol.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // Yn gyntaf, castiwch `Option<String>` i `Option<&String>` gyda `as_ref`, yna defnyddiwch *hynny* gyda `map`, gan adael `text` ar y pentwr.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// Trosiadau o `&mut Option<T>` i `Option<&mut T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// Trosiadau o [`Pin`]`<&Opsiwn<T>>`i`Opsiwn <`[`Pin`] `<&T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // DIOGELWCH: Mae `x` yn sicr o gael ei binio oherwydd ei fod yn dod o `self`
        // sy'n pinned.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// Trosiadau o [`Pin`]`<&mut Option<T>>`i`Opsiwn <`[`Pin`] `<&mut T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // DIOGELWCH: Ni ddefnyddir `get_unchecked_mut` byth i symud yr `Option` y tu mewn i `self`.
        // `x` yn sicr o gael ei binio oherwydd ei fod yn dod o `self` sydd wedi'i binio.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // Cyrraedd gwerthoedd cyfyng
    /////////////////////////////////////////////////////////////////////////

    /// Yn dychwelyd y gwerth [`Some`] a gynhwysir, gan ddefnyddio gwerth `self`.
    ///
    /// # Panics
    ///
    /// Panics os yw'r gwerth yn [`None`] gyda neges panic wedi'i darparu gan `msg`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// Yn dychwelyd y gwerth [`Some`] a gynhwysir, gan ddefnyddio gwerth `self`.
    ///
    /// Oherwydd y gall y swyddogaeth hon panic, nid yw ei ddefnydd yn cael ei annog yn gyffredinol.
    /// Yn lle hynny, mae'n well gennych ddefnyddio paru patrymau a thrafod achos [`None`] yn benodol, neu ffonio [`unwrap_or`], [`unwrap_or_else`], neu [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics os yw'r hunan-werth yn hafal i [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// Yn dychwelyd y gwerth [`Some`] a gynhwysir neu ragosodiad a ddarperir.
    ///
    /// Mae dadleuon a basiwyd i `unwrap_or` yn cael eu gwerthuso'n eiddgar;os ydych chi'n pasio canlyniad galwad swyddogaeth, argymhellir defnyddio [`unwrap_or_else`], sy'n cael ei werthuso'n ddiog.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// Yn dychwelyd y gwerth [`Some`] a gynhwysir neu'n ei gyfrifo ar ôl cau.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// Yn dychwelyd y gwerth [`Some`] a gynhwysir, gan ddefnyddio gwerth `self`, heb wirio nad yw'r gwerth yn [`None`].
    ///
    ///
    /// # Safety
    ///
    /// Galw'r dull hwn ar [`None`] yw *[ymddygiad heb ei ddiffinio]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // Ymddygiad undefined!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // DIOGELWCH: mae'n rhaid i'r contract ddiogelwch yn cael ei gadarnhau gan y galwr.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Trawsnewid gwerthoedd sydd wedi'u cynnwys
    /////////////////////////////////////////////////////////////////////////

    /// Yn mapio `Option<T>` i `Option<U>` trwy gymhwyso swyddogaeth i werth cyfyng.
    ///
    /// # Examples
    ///
    /// Trosi `Opsiwn <` [`String`]`>`yn`Opsiwn <`[`usize`] `>`, gan ddefnyddio'r gwreiddiol:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` yn cymryd hunan *yn ôl gwerth*, gan ddefnyddio `maybe_some_string`
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// Yn cymhwyso swyddogaeth i'r gwerth a gynhwysir (os oes un), neu'n dychwelyd y rhagosodiad a ddarperir (os na).
    ///
    /// Mae dadleuon a basiwyd i `map_or` yn cael eu gwerthuso'n eiddgar;os ydych chi'n pasio canlyniad galwad swyddogaeth, argymhellir defnyddio [`map_or_else`], sy'n cael ei werthuso'n ddiog.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// Yn cymhwyso swyddogaeth i'r gwerth a gynhwysir (os oes un), neu'n cyfrifo diofyn (os na).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// Yn trawsnewid yr `Option<T>` yn [`Result<T, E>`], gan fapio [`Some(v)`] i [`Ok(v)`] a [`None`] i [`Err(err)`].
    ///
    /// Mae dadleuon a basiwyd i `ok_or` yn cael eu gwerthuso'n eiddgar;os ydych chi'n pasio canlyniad galwad swyddogaeth, argymhellir defnyddio [`ok_or_else`], sy'n cael ei werthuso'n ddiog.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// Yn trawsnewid yr `Option<T>` yn [`Result<T, E>`], gan fapio [`Some(v)`] i [`Ok(v)`] a [`None`] i [`Err(err())`].
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// Mewnosod `value` yn yr opsiwn ac yna dychwelyd cyfeiriad symudol ato.
    ///
    /// Os yw'r opsiwn eisoes yn cynnwys gwerth, mae'r hen werth yn cael ei ollwng.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // DIOGELWCH: roedd y cod uchod newydd lenwi'r opsiwn
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adeiladwyr Iterator
    /////////////////////////////////////////////////////////////////////////

    /// Yn dychwelyd ailadroddwr dros y gwerth a gynhwysir o bosibl.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// Yn dychwelyd ailadroddwr symudol dros y gwerth a gynhwysir o bosibl.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // Gweithrediadau Boole ar y gwerthoedd, yn awyddus ac yn ddiog
    /////////////////////////////////////////////////////////////////////////

    /// Yn dychwelyd [`None`] os yw'r opsiwn yn [`None`], fel arall yn dychwelyd `optb`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// Yn dychwelyd [`None`] os yw'r opsiwn yn [`None`], fel arall yn galw `f` gyda'r gwerth wedi'i lapio ac yn dychwelyd y canlyniad.
    ///
    ///
    /// Mae rhai ieithoedd yn galw'r llawdriniaeth hon yn fap gwastad.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// Yn dychwelyd [`None`] os yw'r opsiwn yn [`None`], fel arall yn galw `predicate` gyda'r gwerth wedi'i lapio ac yn dychwelyd:
    ///
    ///
    /// - [`Some(t)`] os yw `predicate` yn dychwelyd `true` (lle `t` yw'r gwerth wedi'i lapio), a
    /// - [`None`] os yw `predicate` yn dychwelyd `false`.
    ///
    /// Mae'r swyddogaeth hon yn gweithio'n debyg i [`Iterator::filter()`].
    /// Gallwch ddychmygu bod yr `Option<T>` yn ailadroddwr dros un neu ddim elfen.
    /// `filter()` yn gadael i chi benderfynu pa elfennau i'w cadw.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// Yn dychwelyd yr opsiwn os yw'n cynnwys gwerth, fel arall yn dychwelyd `optb`.
    ///
    /// Mae dadleuon a basiwyd i `or` yn cael eu gwerthuso'n eiddgar;os ydych chi'n pasio canlyniad galwad swyddogaeth, argymhellir defnyddio [`or_else`], sy'n cael ei werthuso'n ddiog.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// Yn dychwelyd yr opsiwn os yw'n cynnwys gwerth, fel arall yn galw `f` ac yn dychwelyd y canlyniad.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// Yn dychwelyd [`Some`] os yw un yn union o `self`, `optb` yn [`Some`], fel arall yn dychwelyd [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Gweithrediadau tebyg i fynediad i'w mewnosod os Dim a dychwelyd geirda
    /////////////////////////////////////////////////////////////////////////

    /// Mewnosod `value` yn yr opsiwn os yw'n [`None`], yna'n dychwelyd cyfeiriad symudol at y gwerth a gynhwysir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// Mewnosodwch y gwerth diofyn yn yr opsiwn os yw'n [`None`], yna mae'n dychwelyd cyfeiriad symudol at y gwerth a gynhwysir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// Mewnosod gwerth a gyfrifir o `f` yn yr opsiwn os yw'n [`None`], yna'n dychwelyd cyfeiriad symudol at y gwerth a gynhwysir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // DIOGELWCH: byddai amrywiad `None` ar gyfer `self` wedi cael ei ddisodli gan `Some`
            // amrywiad yn y cod uchod.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// Yn cymryd y gwerth allan o'r opsiwn, gan adael [`None`] yn ei le.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// Yn disodli'r gwir werth yn yr opsiwn â'r gwerth a roddir mewn paramedr, gan ddychwelyd yr hen werth os yw'n bresennol, gan adael [`Some`] yn ei le heb ddad-ddynodi'r naill neu'r llall.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// Sipiau `self` gyda `Option` arall.
    ///
    /// Os yw `self` yn `Some(s)` a `other` yn `Some(o)`, mae'r dull hwn yn dychwelyd `Some((s, o))`.
    /// Fel arall, dychwelir `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// Zips `self` a `Option` arall gyda swyddogaeth `f`.
    ///
    /// Os yw `self` yn `Some(s)` a `other` yn `Some(o)`, mae'r dull hwn yn dychwelyd `Some(f(s, o))`.
    /// Fel arall, dychwelir `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// Yn mapio `Option<&T>` i `Option<T>` trwy gopïo cynnwys yr opsiwn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// Yn mapio `Option<&mut T>` i `Option<T>` trwy gopïo cynnwys yr opsiwn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// Yn mapio `Option<&T>` i `Option<T>` trwy glonio cynnwys yr opsiwn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// Yn mapio `Option<&mut T>` i `Option<T>` trwy glonio cynnwys yr opsiwn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// Yn defnyddio `self` wrth ddisgwyl [`None`] a dychwelyd dim.
    ///
    /// # Panics
    ///
    /// Panics os yw'r gwerth yn [`Some`], gyda neges panic yn cynnwys y neges a basiwyd, a chynnwys yr [`Some`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Ni fydd hyn yn panic, gan fod yr holl allweddi yn unigryw.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// Yn defnyddio `self` wrth ddisgwyl [`None`] a dychwelyd dim.
    ///
    /// # Panics
    ///
    /// Panics os yw'r gwerth yn [`Some`], gyda neges panic wedi'i darparu gan werth [`Rhai`].
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Ni fydd hyn yn panic, gan fod yr holl allweddi yn unigryw.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// Yn dychwelyd y gwerth [`Some`] a gynhwysir neu ddiffyg
    ///
    /// Yn defnyddio'r ddadl `self` yna, os yw [`Some`], yn dychwelyd y gwerth a gynhwysir, fel arall os yw [`None`], yn dychwelyd yr [default value] ar gyfer y math hwnnw.
    ///
    ///
    /// # Examples
    ///
    /// Yn trosi llinyn i gyfanrif, gan droi llinynnau sydd wedi'u ffurfio'n wael yn 0 (y gwerth diofyn ar gyfer cyfanrifau).
    /// [`parse`] yn trosi llinyn i unrhyw fath arall sy'n gweithredu [`FromStr`], gan ddychwelyd [`None`] ar gamgymeriad.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// Trosiadau o `Option<T>` (neu `&Option<T>`) i `Option<&T::Target>`.
    ///
    /// Yn gadael yr Opsiwn gwreiddiol yn ei le, gan greu un newydd gan gyfeirio at yr un gwreiddiol, gan orfodi'r cynnwys trwy [`Deref`] hefyd.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// Trosiadau o `Option<T>` (neu `&mut Option<T>`) i `Option<&mut T::Target>`.
    ///
    /// Yn gadael yr `Option` gwreiddiol yn ei le, gan greu un newydd sy'n cynnwys cyfeiriad symudol at fath `Deref::Target` y math mewnol.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// Yn trosi `Option` o [`Result`] yn [`Result`] o `Option`.
    ///
    /// [`None`] yn cael ei fapio i [`Ok`]`(`[`Dim`] `)`.
    /// Bydd [`Rhai`]`(`[`Iawn`] `(_))` a [`Rhai`]`(`[`Err`] `(_))` yn cael eu mapio i [`Ok`]`(`[`Rhai`] `(_))` ac [`Err`]`(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// Swyddogaeth ar wahân yw hon i leihau maint cod .expect() ei hun.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// Swyddogaeth ar wahân yw hon i leihau maint cod .expect_none() ei hun.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Gweithrediadau Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// Yn dychwelyd [`None`][Option::None].
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Yn dychwelyd ailadroddwr llafurus dros y gwerth a gynhwysir o bosibl.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// Copïau `val` i mewn i `Some` newydd.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// Trosiadau o `&Option<T>` i `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Trosi `Opsiwn <` [`String`]`>`yn`Opsiwn <`[`usize`] `>`, gan gadw'r gwreiddiol.
    /// Mae'r dull [`map`] yn cymryd dadl `self` yn ôl gwerth, gan ddefnyddio'r gwreiddiol, felly mae'r dechneg hon yn defnyddio `as_ref` i fynd â `Option` yn gyntaf i gyfeirio at y gwerth y tu mewn i'r gwreiddiol.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// Trosiadau o `&mut Option<T>` i `Option<&mut T>`
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Yr Iterators Opsiwn
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// Ailadroddwr dros gyfeiriad at amrywiad [`Some`] [`Option`].
///
/// Mae'r ailadroddwr yn cynhyrchu un gwerth os yw'r [`Option`] yn [`Some`], fel arall dim.
///
/// Mae'r `struct` hwn yn cael ei greu gan y swyddogaeth [`Option::iter`].
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// Ailadroddwr dros gyfeiriad treiddiol at amrywiad [`Some`] [`Option`].
///
/// Mae'r ailadroddwr yn cynhyrchu un gwerth os yw'r [`Option`] yn [`Some`], fel arall dim.
///
/// Mae'r `struct` hwn yn cael ei greu gan y swyddogaeth [`Option::iter_mut`].
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// Ailadroddwr dros werth amrywiolyn [`Some`] [`Option`].
///
/// Mae'r ailadroddwr yn cynhyrchu un gwerth os yw'r [`Option`] yn [`Some`], fel arall dim.
///
/// Mae'r `struct` hwn yn cael ei greu gan y swyddogaeth [`Option::into_iter`].
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// Yn cymryd pob elfen yn yr [`Iterator`]: os yw'n [`None`][Option::None], ni chymerir unrhyw elfennau pellach, a dychwelir yr [`None`][Option::None].
    /// Os na fydd [`None`][Option::None] yn digwydd, dychwelir cynhwysydd sydd â gwerthoedd pob [`Option`].
    ///
    /// # Examples
    ///
    /// Dyma enghraifft sy'n cynyddu pob cyfanrif mewn vector.
    /// Rydym yn defnyddio'r amrywiad wedi'i wirio o `add` sy'n dychwelyd `None` pan fyddai'r cyfrifiad yn arwain at orlif.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// Fel y gallwch weld, bydd hyn yn dychwelyd yr eitemau dilys, disgwyliedig.
    ///
    /// Dyma enghraifft arall sy'n ceisio tynnu un o restr gyfanrifau arall, y tro hwn yn gwirio am orlif:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// Gan fod yr elfen olaf yn sero, byddai'n gorlifo.Felly, y gwerth canlyniadol yw `None`.
    ///
    /// Dyma amrywiad ar yr enghraifft flaenorol, gan ddangos na chymerir unrhyw elfennau pellach o `iter` ar ôl yr `None` cyntaf.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Ers i'r drydedd elfen achosi gorlif, ni chymerwyd unrhyw elfennau pellach, felly gwerth terfynol `shared` yw 6 (= `3 + 2 + 1`), nid 16.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): Gellid disodli hyn gyda Iterator::scan pan fydd y nam perfformiad hwn ar gau.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// Y math gwall sy'n deillio o gymhwyso'r gweithredwr trio (`?`) i werth `None`.
/// Os ydych yn dymuno caniatáu trosi `x?` (lle mae `x` yn `Option<T>`) yn eich math gwall, gallwch weithredu `impl From<NoneError>` ar gyfer `YourErrorType`.
///
/// Yn yr achos hwnnw, bydd `x?` o fewn swyddogaeth sy'n dychwelyd `Result<_, YourErrorType>` yn cyfieithu gwerth `None` yn ganlyniad `Err`.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// Trosiadau o `Option<Option<T>>` i `Option<T>`
    ///
    /// # Examples
    ///
    /// Defnydd sylfaenol:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// Gwastatau yn unig yn dileu un lefel o nythu ar y tro:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}