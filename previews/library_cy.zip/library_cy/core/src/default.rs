//! Y trait `Default` gyfer mathau a all fod â gwerthoedd diofyn ystyrlon.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait am roi gwerth diofyn defnyddiol math.
///
/// Weithiau, rydych chi am ddisgyn yn ôl i ryw fath o werth diofyn, a pheidiwch â malio beth ydyw yn arbennig.
/// Mae hyn yn aml yn cynnig `strwythurau 'sy'n diffinio set o opsiynau:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Sut allwn ni ddiffinio rhai gwerthoedd diofyn?Gallwch ddefnyddio `Default`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Yn awr, byddwch yn cael yr holl werthoedd diofyn.Mae Rust yn gweithredu `Default` ar gyfer gwahanol fathau o bethau cyntefig.
///
/// Os ydych chi eisiau bod yn drech na'r opsiwn penodol, ond yn dal i gadw y rhagosodiadau eraill:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// Gellir defnyddio'r trait hwn gyda `#[derive]` os yw pob un o feysydd y math yn gweithredu `Default`.
/// Pan `derive`d, bydd yn defnyddio'r gwerth diofyn ar gyfer y math pob cae yn.
///
/// ## Sut y gallaf weithredu `Default`?
///
/// Darparu gweithredu ar gyfer y dull `default()` sy'n dychwelyd gwerth eich math a ddylai fod yn 'r ball:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// Yn dychwelyd yr "default value" ar gyfer math.
    ///
    /// Mae gwerthoedd diofyn yn aml yn rhyw fath o werth cychwynnol, gwerth hunaniaeth, neu unrhyw beth arall a allai wneud synnwyr fel rhagosodiad.
    ///
    ///
    /// # Examples
    ///
    /// Gan ddefnyddio adeiledig yn werthoedd diofyn:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Gwneud eich un eich hun:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// Dychwelwch y gwerth diofyn o fath yn ôl y `Default` trait.
///
/// Y math i ddychwelyd yn cael ei casglu o gyd-destun;mae hyn yn gyfwerth â `Default::default()` ond byrrach i'r math.
///
/// Er enghraifft:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// Deillio macro sy'n cynhyrchu impl o'r trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }