//! Mae hwn yn fodiwl mewnol a ddefnyddir gan y ifmt!Rhedeg.strwythurau hyn yn cael eu hallyrru i araeau statig i llinynnau fformat precompile o flaen amser.
//!
//! Mae'r diffiniadau hyn yn debyg i'w cyfwerth â `ct`, ond maent yn wahanol yn yr ystyr y gellir dyrannu'r rhain yn statig a'u optimeiddio ychydig ar gyfer yr amser rhedeg
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// aliniadau posibl y gellir gwneud cais fel rhan o gyfarwyddeb fformatio.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Arwydd y dylid cynnwys y cynnwys wedi'i alinio i'r chwith.
    Left,
    /// Arwydd y dylai cynnwys fod yn iawn-alinio.
    Right,
    /// Dynodi y dylai'r cynnwys fod wedi'i alinio â chanolbwynt.
    Center,
    /// Ni ofynnwyd am aliniad.
    Unknown,
}

/// Defnyddir gan fanylebwyr [width](https://doc.rust-lang.org/std/fmt/#width) a [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Penodedig gyda nifer llythrennol, yn storio'r gwerth
    Is(usize),
    /// Wedi'i nodi gan ddefnyddio cystrawennau `$` a `*`, mae'n storio'r mynegai yn `args`
    Param(usize),
    /// Heb ei nodi
    Implied,
}