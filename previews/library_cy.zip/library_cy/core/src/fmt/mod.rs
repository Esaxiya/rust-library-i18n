//! Cyfleustodau ar gyfer fformatio ac argraffu tannau.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// aliniadau posibl dychwelyd erbyn `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Arwydd y dylid cynnwys y cynnwys wedi'i alinio i'r chwith.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Arwydd y dylai cynnwys fod yn iawn-alinio.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Dynodi y dylai'r cynnwys fod wedi'i alinio â chanolbwynt.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Y math a ddychwelir trwy ddulliau fformatiwr.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Mae'r math wall sydd wedi ei ddychwelyd o fformatio neges i mewn i nant.
///
/// Nid yw'r math hwn yn cefnogi trosglwyddo i gamgymeriad heblaw bod camgymeriad wedi digwydd.
/// Rhaid trefnu i unrhyw wybodaeth ychwanegol gael ei throsglwyddo trwy ryw fodd arall.
///
/// Peth pwysig i'w gofio yw na ddylid cymysgu'r math `fmt::Error` â [`std::io::Error`] neu [`std::error::Error`], a allai fod gennych o fewn cwmpas hefyd.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// A trait gyfer ysgrifennu neu fformadu mewn i Unicode-dderbyn byfferau neu nentydd.
///
/// Mae'r trait hwn yn derbyn data wedi'i amgodio UTF-8 yn unig ac nid yw'n [flushable].
/// Os mai dim ond eisiau derbyn Unicode ac nad ydych yn angen fflysio, dylech roi'r trait hwn;
/// fel arall dylech weithredu [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Ysgrifennu sleisen llinyn i mewn i awdur hwn, gan ddychwelyd a yw'r ysgrifennu llwyddo.
    ///
    /// Gall y dull hwn ond yn llwyddo os y dafell llinyn cyfan ei ysgrifennu yn llwyddiannus, ac ni fydd y dull hwn yn dychwelyd nes bod yr holl ddata wedi cael ei ysgrifennu neu fo gwall yn digwydd.
    ///
    ///
    /// # Errors
    ///
    /// Bydd y swyddogaeth hon yn dychwelyd enghraifft o [`Error`] ar wall.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Yn ysgrifennu [`char`] mewn i awdur hwn, gan ddychwelyd a yw'r ysgrifennu llwyddo.
    ///
    /// Gall un [`char`] yn cael ei hamgodio fel mwy nag un beit.
    /// Gall y dull hwn ond yn llwyddo os y dilyniant beit cyfan ei ysgrifennu yn llwyddiannus, ac ni fydd y dull hwn yn dychwelyd nes bod yr holl ddata wedi cael ei ysgrifennu neu fo gwall yn digwydd.
    ///
    ///
    /// # Errors
    ///
    /// Bydd y swyddogaeth hon yn dychwelyd enghraifft o [`Error`] ar wall.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Glud ar gyfer defnydd o'r macro [`write!`] gyda implementors o trait hwn.
    ///
    /// Dylai'r dull hwn yn gyffredinol nid yn cael eu gweithredu â llaw, ond yn hytrach drwy macro [`write!`] ei hun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Configuration ar gyfer fformatio.
///
/// Mae `Formatter` yn cynrychioli amryw opsiynau sy'n gysylltiedig â fformatio.
/// nid yw defnyddwyr yn adeiladu `Formatter`s yn uniongyrchol;mae cyfeiriad at mutable un yn cael ei throsglwyddo i'r dull `fmt` pob traits fformatio, fel [`Debug`] a [`Display`].
///
///
/// Er mwyn rhyngweithio â `Formatter`, byddwch chi'n galw amrywiol ddulliau i newid yr amrywiol opsiynau sy'n gysylltiedig â fformatio.
/// I gael enghreifftiau, gweler y dogfennau o'r dulliau a ddiffinnir ar `Formatter` isod.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Ddadl yn ei hanfod yn swyddogaeth fformatio cymhwyso'n rhannol optimized, yn cyfateb i `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Mae'r struct cynrychioli'r "argument" generig sy'n cael ei gymryd gan y teulu Xprintf o swyddogaethau.Mae'n cynnwys swyddogaeth i fformatio'r gwerth a roddir.
/// Ar adeg crynhoi sicrheir bod y swyddogaeth a gwerth yn cael y mathau cywir, ac yna struct hwn yn cael ei ddefnyddio i canonicalize dadleuon i un math.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Mae hyn yn gwarantu gwerth sefydlog sengl ar gyfer y pwyntydd swyddogaeth sy'n gysylltiedig ag indices/counts yn y seilwaith fformatio.
//
// Sylwer na fyddai swyddogaeth a ddiffinnir fel y cyfryw fod yn gywir fel swyddogaethau bob amser yn cael eu tagio unnamed_addr gyda'r gyfredol gostwng i LLVM IR, felly ni ystyrir ei gyfeiriad yn bwysig i LLVM ac fel y gallai y cyfryw mae'r cast as_usize wedi cael eu miscompiled.
//
// Yn ymarferol, nid ydym byth yn galw as_usize ar ddata nad yw'n defnyddio (fel mater o gynhyrchu statig o'r dadleuon fformatio), felly dim ond gwiriad ychwanegol yw hwn.
//
// Yn bennaf, rydym am sicrhau bod gan y pwyntydd swyddogaeth yn `USIZE_MARKER` gyfeiriad sy'n cyfateb *yn unig* i swyddogaethau sydd hefyd yn cymryd `&usize` fel eu dadl gyntaf.
// Mae'r read_volatile yma yn sicrhau y gallwn yn ddiogel yn barod allan usize o'r cyfeiriad basio a bod y cyfeiriad hwn nid yw pwynt di-usize cymryd swyddogaeth.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // DIOGELWCH: ptr yn gyfeiriad
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // DIOGELWCH: `mem::transmute(x)` yn ddiogel oherwydd
        //     1. `&'b T` cadw'r oes fod yn tarddu gyda `'b` (er mwyn peidio cael oes diderfyn)
        //     2.
        //     `&'b T` a `&'b Opaque` yn cael yr un gosodiad cof (pan `T` yn `Sized`, gan ei fod yn fan hyn) `mem::transmute(f)` yn ddiogel ers `fn(&T, &mut Formatter<'_>) -> Result` a `fn(&Opaque, &mut Formatter<'_>) -> Result` yr un ABI (cyn belled ag y `T` yn `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // DIOGELWCH: Y cae `formatter` wedi ei osod i USIZE_MARKER dim ond os
            // mae'r gwerth yn usize, felly mae hyn yn ddiogel
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// baneri ar gael yn y fformat v1 o format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Wrth ddefnyddio'r format_args! () Macro, y swyddogaeth hon yn cael ei ddefnyddio i gynhyrchu strwythur Dadleuon.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Mae'r swyddogaeth hon yn cael ei ddefnyddio i bennu paramedrau fformatio nonstandard.
    /// Mae'n rhaid i'r amrywiaeth `pieces` fod o leiaf cyn belled â `fmt` i adeiladu strwythur Dadleuon dilys.
    /// Hefyd, unrhyw `Count` fewn `fmt` sy'n `CountIsParam` neu `CountIsNextParam` wedi i bwynt i ffrae a grëwyd gyda `argumentusize`.
    ///
    /// Fodd bynnag, mae methu â gwneud felly nid yw'n achosi unsafety, ond bydd yn anwybyddu yn annilys.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Amcangyfrifon hyd y testun fformatio.
    ///
    /// Y bwriad yw defnyddio hwn ar gyfer gosod capasiti `String` cychwynnol wrth ddefnyddio `format!`.
    /// Note: mae hyn yn nad yw'r isaf nac rhwymo uchaf.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Os yw'r llinyn fformat yn dechrau gyda dadl, peidiwch â ailddyrannu unrhyw beth, oni bai bod hyd y darnau yn arwyddocaol.
            //
            //
            0
        } else {
            // Mae rhai dadleuon, felly bydd unrhyw gwthio ychwanegol ailddyrannu'r y llinyn.
            //
            // Er mwyn osgoi hynny, rydym yn "pre-doubling" y gallu yma.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Mae'r strwythur hwn yn cynrychioli fersiwn precompiled ddiogel o fformat llinyn a'i ddadleuon.
/// Ni all hyn gael ei gynhyrchu mewn Rhedeg oherwydd na ellir ei gael ei wneud yn ddiogel, felly dim adeiladwyr yn cael eu rhoi ac mae'r caeau'n preifat i atal newid.
///
///
/// Bydd y macro [`format_args!`] yn creu enghraifft o'r strwythur hwn yn ddiogel.
/// Mae'r macro dilysu'r fformat llinyn ar crynhoi amser fel y gall defnydd o'r swyddogaethau [`write()`] a [`format()`] yn cael ei pherfformio yn ddiogel.
///
/// Gallwch ddefnyddio'r `Arguments<'a>` fod [`format_args!`] yn dychwelyd mewn cyd-destunau `Debug` a `Display` fel y gwelir isod.
/// Dengys y Enghraifft hefyd fod `Debug` a fformat `Display` at yr un peth: y fformat rhyngosod llinyn yn `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // darnau Fformat llinyn i argraffu.
    pieces: &'a [&'static str],

    // Specs deiliad, neu `None` os yw'r holl specs yn ddiofyn (fel yn "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Dadleuon deinamig dros ryngosod, i fod yn rhyngddalennog â darnau llinyn.
    // (Mae pob dadl yn cael ei ragflaenu gan ddarn llinyn.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Cael y llinyn fformatio, os nad oes ganddi dadleuon gael ei fformatio.
    ///
    /// Gellir defnyddio hyn i osgoi dyraniadau yn yr achos mwyaf dibwys.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` Dylai fformat yr allbwn yn rhaglennydd sy'n wynebu'r, debugging cyd-destun.
///
/// A siarad yn gyffredinol, dim ond `derive` a `Debug` y dylech ei weithredu.
///
/// Pan gaiff ei ddefnyddio gyda `#?` fformat yn ail rhagnodwr, mae'r allbwn yn cael ei argraffu 'n bert.
///
/// I gael mwy o wybodaeth am formatters, gweler [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Gellir defnyddio'r trait hwn gyda `#[derive]` os yw pob maes yn gweithredu `Debug`.
/// Pan `derive`d gyfer structs, bydd yn defnyddio enw'r `struct`, yna `{`, yna rhestr gyda chomas rhyngddynt o enw pob cae a gwerth `Debug`, yna `}`.
/// Ar gyfer `enum`s, bydd yn defnyddio enw'r amrywiad ac, os yn berthnasol, `(`, yna bydd y gwerthoedd `Debug` y caeau, yna `)`.
///
/// # Stability
///
/// Nid yw fformatau `Debug` sy'n deillio yn sefydlog, ac felly gallant newid gyda fersiynau future Rust.
/// Yn ogystal, nid yw gweithrediadau `Debug` o fathau a ddarperir gan y llyfrgell safonol (`libstd`, `libcore`, `liballoc`, ac ati) yn sefydlog, a gall hefyd yn newid gyda fersiynau future Rust.
///
///
/// # Examples
///
/// Deillio gweithrediad:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Manually weithredu:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Mae nifer o ddulliau cynorthwy-ydd ar y struct [`Formatter`] i'ch helpu gyda implementations llaw, megis [`debug_struct`].
///
/// `Debug` gweithrediadau gan ddefnyddio naill ai `derive` neu'r API debug adeiladwr ar gefnogaeth [`Formatter`] 'n bert-argraffu gan ddefnyddio'r faner yn ail: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Argraffu 'n bert gyda `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Yn fformatio'r gwerth gan ddefnyddio'r fformatydd a roddir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Modiwl ar wahân i ail-adrodd y macro `Debug` o prelude heb y trait `Debug`.
pub(crate) mod macros {
    /// macro Deillio cynhyrchu impl o'r trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Fformat trait ar gyfer fformat gwag, `{}`.
///
/// `Display` yn debyg i [`Debug`], ond `Display` ar gyfer allbwn-wynebu defnyddwyr, ac felly ni ellir ei deillio.
///
///
/// I gael mwy o wybodaeth am formatters, gweler [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Gweithredu `Display` ar fath:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Yn fformatio'r gwerth gan ddefnyddio'r fformatydd a roddir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// Dylai'r trait `Octal` fformat ei gynnyrch fel rhif yn base-8.
///
/// Ar gyfer gyfanrifau llofnodi cyntefig (`i8` i `i128`, a `isize`), gwerthoedd negatif yn cael eu fformatio fel cynrychiolaeth y ddau yn ategu.
///
///
/// Mae'r faner arall, `#`, yn ychwanegu `0o` o flaen yr allbwn.
///
/// I gael mwy o wybodaeth am formatters, gweler [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Defnydd sylfaenol gyda `i32`:
///
/// ```
/// let x = 42; // 42 yw '52' yn wythol
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Gweithredu `Octal` ar fath:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // ddirprwyo i weithredu i32 yn
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Yn fformatio'r gwerth gan ddefnyddio'r fformatydd a roddir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// Dylai'r trait `Binary` fformat ei gynnyrch fel rhif deuaidd yn.
///
/// Ar gyfer cyfanrifau cyntefig wedi'u llofnodi ([`i8`] i [`i128`], a [`isize`]), mae gwerthoedd negyddol yn cael eu fformatio fel cynrychiolaeth gyflenwol y ddau.
///
///
/// Mae'r faner yn ail, `#`, yn ychwanegu `0b` o flaen y cynnyrch.
///
/// I gael mwy o wybodaeth am formatters, gweler [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// defnydd Sylfaenol gyda [`i32`]:
///
/// ```
/// let x = 42; // 42 yw '101010' mewn deuaidd
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Gweithredu `Binary` ar fath:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // ddirprwyo i weithredu i32 yn
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Yn fformatio'r gwerth gan ddefnyddio'r fformatydd a roddir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// Dylai'r `LowerHex` trait fformatio ei allbwn fel rhif mewn hecsadegol, gyda `a` trwy `f` mewn llythrennau bach.
///
/// Ar gyfer gyfanrifau llofnodi cyntefig (`i8` i `i128`, a `isize`), gwerthoedd negatif yn cael eu fformatio fel cynrychiolaeth y ddau yn ategu.
///
///
/// Mae'r faner yn ail, `#`, yn ychwanegu `0x` o flaen y cynnyrch.
///
/// I gael mwy o wybodaeth am formatters, gweler [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Defnydd sylfaenol gyda `i32`:
///
/// ```
/// let x = 42; // 42 yw '2a' mewn hecs
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Gweithredu `LowerHex` ar fath:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // ddirprwyo i weithredu i32 yn
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Yn fformatio'r gwerth gan ddefnyddio'r fformatydd a roddir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// Dylai'r trait `UpperHex` fformat ei gynnyrch fel rhif hecsadegol mewn, gyda `A` drwy `F` mewn priflythrennau.
///
/// Ar gyfer gyfanrifau llofnodi cyntefig (`i8` i `i128`, a `isize`), gwerthoedd negatif yn cael eu fformatio fel cynrychiolaeth y ddau yn ategu.
///
///
/// Mae'r faner yn ail, `#`, yn ychwanegu `0x` o flaen y cynnyrch.
///
/// I gael mwy o wybodaeth am formatters, gweler [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Defnydd sylfaenol gyda `i32`:
///
/// ```
/// let x = 42; // 42 yw '2A' mewn hecs
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Gweithredu `UpperHex` ar fath:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // ddirprwyo i weithredu i32 yn
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Yn fformatio'r gwerth gan ddefnyddio'r fformatydd a roddir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// Dylai'r `Pointer` trait fformatio ei allbwn fel lleoliad cof.
/// Mae hyn yn cael ei gyflwyno yn gyffredin fel hecsadegol.
///
/// I gael mwy o wybodaeth am formatters, gweler [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// defnydd Sylfaenol gyda `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // mae hyn yn cynhyrchu rhywbeth fel '0x7f06092ac6d0'
/// ```
///
/// Gweithredu `Pointer` ar fath:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // defnyddio `as` i drosi i `*const T`, sy'n gweithredu Pointer, y gallwn ei ddefnyddio
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Yn fformatio'r gwerth gan ddefnyddio'r fformatydd a roddir.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// Dylai'r trait `LowerExp` fformat ei allbwn mewn nodiant gwyddonol gyda is-achos `e`.
///
/// I gael mwy o wybodaeth am formatters, gweler [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Defnydd sylfaenol gyda `f64`:
///
/// ```
/// let x = 42.0; // 42.0 yw '4.2e1' mewn nodiant gwyddonol
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Gweithredu `LowerExp` ar fath:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // ddirprwyo i weithredu f64 yn
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Yn fformatio'r gwerth gan ddefnyddio'r fformatydd a roddir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// Dylai'r `UpperExp` trait fformatio ei allbwn mewn nodiant gwyddonol gyda `E` mewn llythrennau bras.
///
/// I gael mwy o wybodaeth am formatters, gweler [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Defnydd sylfaenol gyda `f64`:
///
/// ```
/// let x = 42.0; // 42.0 yw '4.2E1' mewn nodiant gwyddonol
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Gweithredu `UpperExp` ar fath:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // ddirprwyo i weithredu f64 yn
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Yn fformatio'r gwerth gan ddefnyddio'r fformatydd a roddir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Mae'r swyddogaeth `write` yn cymryd ffrwd allbwn, a struct `Arguments` gellir ei precompiled gyda'r macro `format_args!`.
///
///
/// Caiff y dadleuon yn cael eu fformatio yn ôl y fformat a nodir llinyn i mewn i'r llif allbwn a ddarperir.
///
/// # Examples
///
/// Defnydd sylfaenol:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Noder y gallai defnyddio [`write!`] yn well.enghraifft:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Gallwn ddefnyddio paramedrau rhagosodedig fformadu ar gyfer yr holl ddadleuon.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Mae gan bob spec ddadl cyfatebol sy'n cael ei ragflaenu gan ddarn llinyn.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // DIOGELWCH: arg a args.args dod o'r un dadleuon,
                // sy'n gwarantu y mynegeion bob amser o fewn ffiniau.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Gall fod yn unig ddarn llinyn un llusgo ar ôl.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // DIOGELWCH: arg a args dod o'r un dadleuon,
    // sy'n gwarantu y mynegeion bob amser o fewn ffiniau.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Dyfyniad y ddadl cywir
    debug_assert!(arg.position < args.len());
    // DIOGELWCH: arg a args dod o'r un dadleuon,
    // sy'n gwarantu ei mynegai bob amser o fewn terfynau.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Yna, mewn gwirionedd yn gwneud rhywfaint o argraffu
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // DIOGELWCH: CNT a args dod o'r un dadleuon,
            // sy'n gwarantu mynegai hwn bob amser o fewn terfynau.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Padin ar ôl diwedd o rywbeth.Dychwelyd erbyn `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Ysgrifennwch y padin post.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Rydym yn awyddus i newid hyn
            buf: wrap(self.buf),

            // A chadw y rhain
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // dulliau a ddefnyddir ar gyfer cynorthwy-ydd padin a phrosesu dadleuon fformatio y gall pob traits fformatio defnyddio.
    //

    /// Perfformio y padin cywir ar gyfer cyfanrif sydd eisoes wedi'i allyrrir i mewn i str.
    /// Dylai'r str * * Nid yw cynnwys yr arwydd am y cyfanrif, a fydd yn cael eu hychwanegu drwy'r dull hwn.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, a oedd y cyfanrif gwreiddiol naill ai'n gadarnhaol neu'n sero.
    /// * rhagddodiad, os yw'r cymeriad '#' (Alternate) yn cael ei ddarparu, mae hyn yn y rhagddodiad i roi o flaen y rhif.
    ///
    /// * buf, yr arae beit y mae'r rhif wedi'i fformatio iddo
    ///
    /// Bydd y swyddogaeth hon yn cyfrif yn gywir am y fflagiau a ddarperir yn ogystal â'r lled lleiaf.
    /// Ni fydd yn ystyried manwl gywirdeb.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Mae angen i ni gael gwared ar "-" o'r rhif allbwn.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Yn ysgrifennu'r arwydd os yw'n bodoli, ac yna'r rhagddodiad os gofynnwyd amdano
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Mae'r cae `width` yn fwy o paramedr `min-width` ar y pwynt hwn.
        match self.width {
            // Os nad oes unrhyw ofynion hyd lleiaf, yna gallwn ysgrifennu'r beit.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Gwiriwch a ydym dros y lled lleiaf, os felly, gallwn hefyd ysgrifennu'r beit.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Mae'r arwydd a'r rhagddodiad yn mynd cyn y padin os yw'r cymeriad llenwi yn sero
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Fel arall, mae'r arwydd a'r rhagddodiad yn mynd ar ôl y padin
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Mae'r swyddogaeth hon yn cymryd sleisen llinyn ac yn gollwng i'r byffer mewnol ar ôl cymhwyso'r baneri fformatio perthnasol penodedig.
    /// Mae'r baneri cydnabyddedig ar gyfer llinynnau generig yw:
    ///
    /// * lled, lleiafswm lled yr hyn i'w ollwng
    /// * fill/align - beth i allyrru a ble i allyrru os anghenion llinyn a ddarperir i fod yn padio
    /// * manwl gywirdeb, yr hyd mwyaf i'w allyrru, caiff y llinyn ei chwtogi os yw'n hirach na'r hyd hwn
    ///
    /// Yn nodedig swyddogaeth hon yn anwybyddu'r paramedrau `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Gwnewch yn siwr mae 'na lwybr cyflym o flaen llaw
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Gellir dehongli'r maes `precision` fel `max-width` ar gyfer fformatio'r llinyn.
        //
        let s = if let Some(max) = self.precision {
            // Os yw ein llinyn yn hirach na'r manwl gywirdeb, yna mae'n rhaid i ni gael cwtogi.
            // Fodd bynnag, rhaid baneri eraill fel `fill`, `width` a `align` yn gweithredu fel bob amser.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // Ni all LLVM yma brofi na fydd `..i` panic `&s[..i]`, ond rydym yn gwybod na all panic.
                // Defnyddiwch `get` + `unwrap_or` i osgoi `unsafe` ac fel arall peidiwch ag allyrru unrhyw god sy'n gysylltiedig â panic yma.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Mae'r cae `width` yn fwy o paramedr `min-width` ar y pwynt hwn.
        match self.width {
            // Os ydym o dan yr hyd mwyaf, ac nad oes unrhyw ofynion hyd lleiaf, yna gallwn allyrru'r llinyn yn unig
            //
            None => self.buf.write_str(s),
            // Os ydym o dan y lled mwyaf, gwiriwch a ydym dros y lled lleiaf, os felly mae mor hawdd ag allyrru'r llinyn yn unig.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Os ydym yn dan y mwyaf a'r lleiaf led, ac yna llenwi y lleiafswm lled gyda'r llinyn penodedig + rhywfaint o aliniad.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Ysgrifennwch y padin ymlaen llaw a dychwelwch y padin post anysgrifenedig.
    /// Galwyr yn gyfrifol am sicrhau ôl-padin ei ysgrifennu ar ôl y peth sy'n cael ei padded.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Yn cymryd y rhannau fformatio ac yn cymhwyso'r padin.
    /// Yn tybio bod y galwr eisoes wedi gwneud y rhannau gyda'r manwl gywirdeb gofynnol, fel y gellir anwybyddu `self.precision`.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // am yr arwydd-ymwybodol sero padin, rydym yn gwneud y arwydd cyntaf ac yn ymddwyn fel pe bai gennym unrhyw arwydd o'r dechrau.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // arwydd bob amser yn mynd yn gyntaf
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // tynnwch yr arwydd o'r rhannau wedi'u fformatio
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // rhannau sy'n weddill yn mynd drwy'r broses padin cyffredin.
            let len = formatted.len();
            let ret = if width <= len {
                // dim padin
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // dyma'r achos cyffredin ac rydym yn cymryd llwybr byr
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // DIOGELWCH: Defnyddir hwn ar gyfer `flt2dec::Part::Num` a `flt2dec::Part::Copy`.
            // Mae'n ddiogel i'w ddefnyddio ar gyfer `flt2dec::Part::Num` gan fod pob torgoch `c` rhwng `b'0'` a `b'9'`, sy'n golygu bod `s` yn UTF-8 dilys.
            // Mae hefyd yn debyg yn ddiogel yn ymarferol i'w defnyddio ar gyfer `flt2dec::Part::Copy(buf)` ers `buf` fod yn ASCII blaen, ond mae'n bosibl i rywun basio mewn gwerth gwael am `buf` i `flt2dec::to_shortest_str` gan ei fod yn swyddogaeth gyhoeddus.
            //
            // FIXME: Benderfynu a gallai hyn arwain at UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 sero
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Ysgrifennu rhai data i'r byffer sylfaenol a geir yn Formatter hwn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Mae hyn yn cyfateb i:
    ///         // ysgrifennu! (fformatiwr, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Yn ysgrifennu rhywfaint o wybodaeth wedi'i fformatio i'r achos hwn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Baneri ar gyfer fformatio
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Cymeriad ddefnyddio fel 'fill' pryd bynnag y mae aliniad.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Rydym yn gosod aliniad i'r dde gyda ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Baner yn nodi pa fath o aliniad y gofynnwyd amdano.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Lled cyfanrif a bennir yn ddewisol y dylai'r allbwn fod.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Os byddwn yn derbyn led, byddwn yn ei defnyddio
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Fel arall, rydym yn gwneud dim arbennig
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// penodol trachywiredd Ddewisol ar gyfer mathau rhifol.
    /// Fel arall, uchafswm lled ar gyfer mathau llinyn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Os cawsom gywirdeb, rydym yn ei ddefnyddio.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Fel arall, byddwn yn ddiofyn 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Yn penderfynu a yw'r faner `+` nodwyd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Yn penderfynu a yw'r faner `-` nodwyd.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Rydych am arwydd minws?Cael un!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Yn penderfynu a nodwyd y faner `#`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Yn penderfynu a nodwyd y faner `0`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Rydym yn anwybyddu opsiynau'r fformatiwr.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Penderfynwch pa API cyhoedd yr ydym ei eisiau ar gyfer y ddau baneri.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Yn creu adeiladwr [`DebugStruct`] wedi'i gynllunio i gynorthwyo gyda chreu gweithrediadau [`fmt::Debug`] ar gyfer strwythurau.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Yn creu adeiladwr `DebugTuple` wedi'i gynllunio i gynorthwyo gyda chreu gweithrediadau `fmt::Debug` ar gyfer strwythurau twple.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Creu adeiladwr `DebugList` gynllunio i gynorthwyo gyda chreu implementations `fmt::Debug` am restr tebyg i strwythurau.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Creu adeiladwr `DebugSet` gynllunio i gynorthwyo gyda chreu implementations `fmt::Debug` am set-debyg strwythurau.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Yn yr enghraifft fwy cymhleth hon, rydym yn defnyddio [`format_args!`] a `.debug_set()` i adeiladu rhestr o freichiau paru:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Creu adeiladwr `DebugMap` gynllunio i gynorthwyo gyda chreu implementations `fmt::Debug` i gweld y map sy'n debyg i strwythurau.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Gweithrediadau y craidd fformatio traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Os yw anghenion torgoch dianc, ôl-groniad fflysio hyd yn hyn ac ysgrifennu, arall sgip
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Mae'r faner yn ail eisoes yn cael ei drin gan LowerHex fel special-mae'n nodi p'un ai i rhagddodiad â 0x.
        // Rydym yn ei ddefnyddio i weithio allan p'un ai i sero yn ymestyn, ac yna ei osod yn ddiamod i gael y rhagddodiad.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Gweithredu Display/Debug ar gyfer gwahanol fathau craidd

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // Mae'r RefCell yn cael ei fenthyg ar y cyd felly ni allwn edrych ar ei werth yma.
                // Dangoswch placeholder yn lle hynny.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Os ydych yn disgwyl profion i fod yma, yn edrych yn hytrach ar y ffeil core/tests/fmt.rs, mae'n llawer haws na chreu pob un o'r strwythurau rt::Piece yma.
//
// Mae yna hefyd brofion yn y Gweig crate, ar gyfer y rhai y dyraniadau angen.