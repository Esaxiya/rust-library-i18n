Panics yr edefyn cyfredol.

Mae hyn yn caniatáu rhaglen i derfynu ar unwaith ac yn rhoi adborth i'r galwr y rhaglen.
`panic!` Dylai fod yn defnyddio pan fydd rhaglen yn cyrraedd cyflwr anadferadwy.

Mae'r macro yw'r ffordd berffaith i amodau ASSERT yn enghraifft cod ac mewn profion.
`panic!` yn gysylltiedig yn agos â'r dull `unwrap` y ddau enums [`Option`][ounwrap] a [`Result`][runwrap].
Mae'r ddau weithrediad yn galw `panic!` pan fyddant wedi'u gosod i amrywiadau [`None`] neu [`Err`].

Wrth ddefnyddio `panic!()` gallwch nodi prif lwyth llinyn, sy'n cael ei hadeiladu gan ddefnyddio cystrawen [`format!`].
Bod prif lwyth yw ddefnyddir wrth chwistrellu y panic i mewn i'r edau Rust galw, gan achosi i'r edau i panic yn gyfan gwbl.

Ymddygiad y `std` hook rhagosodedig, h.y.
cod sy'n rhedeg yn syth ar ôl y panic ei galw i rym, yw i argraffu'r prif lwyth neges i `stderr` ynghyd â'r wybodaeth file/line/column yr alwad `panic!()`.

Gallwch diystyru'r panic hook ddefnyddio [`std::panic::set_hook()`].
Y tu mewn i'r hook Gellir gweld yn panic fel `&dyn Any + Send`, sy'n cynnwys naill ai `&str` neu `String` i `panic!()` invocations rheolaidd.
I panic gyda gwerth o fath arall arall, gellir defnyddio [`panic_any`].

[`Result`] enum yn aml yn ateb gwell ar gyfer adennill o gamgymeriadau na defnyddio'r macro `panic!`.
Dylai hyn macro gael ei ddefnyddio i osgoi mynd ymlaen gan ddefnyddio gwerthoedd anghywir, megis o ffynonellau allanol.
Mae gwybodaeth fanwl am trin gwall yn dod o hyd yn y [book].

Gweler hefyd y [`compile_error!`] macro, am godi camgymeriadau yn ystod y casgliad.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Gweithredu cyfredol

Os bydd y prif edau panics bydd yn terfynu eich holl edafedd ac yn gorffen eich rhaglen gyda chod `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





