#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Yn ehangu i naill ai `$crate::panic::panic_2015` neu `$crate::panic::panic_2021` yn dibynnu ar rifyn y galwr.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Honni bod dau fynegiad yn gyfartal â'i gilydd (gan ddefnyddio [`PartialEq`]).
///
/// Ar panic, bydd macro hwn yn argraffu'r gwerthoedd o'r ymadroddion gyda'u sylwadau debug.
///
///
/// Fel [`assert!`], macro mae hyn yn cael ail fath, lle gall arfer panic neges yn cael ei ddarparu.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Mae'r adweithiau isod yn fwriadol.
                    // Hebddyn nhw, mae'r slot pentwr ar gyfer y benthyciad yn cael ei ymsefydlu hyd yn oed cyn i'r gwerthoedd gael eu cymharu, gan arwain at arafu amlwg.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Mae'r adweithiau isod yn fwriadol.
                    // Hebddyn nhw, mae'r slot pentwr ar gyfer y benthyciad yn cael ei ymsefydlu hyd yn oed cyn i'r gwerthoedd gael eu cymharu, gan arwain at arafu amlwg.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Yn honni nad yw dau ymadrodd yn hafal i'w gilydd (gan ddefnyddio [`PartialEq`]).
///
/// Ar panic, bydd macro hwn yn argraffu'r gwerthoedd o'r ymadroddion gyda'u sylwadau debug.
///
///
/// Fel [`assert!`], macro mae hyn yn cael ail fath, lle gall arfer panic neges yn cael ei ddarparu.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Mae'r adweithiau isod yn fwriadol.
                    // Hebddyn nhw, mae'r slot pentwr ar gyfer y benthyciad yn cael ei ymsefydlu hyd yn oed cyn i'r gwerthoedd gael eu cymharu, gan arwain at arafu amlwg.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Mae'r adweithiau isod yn fwriadol.
                    // Hebddyn nhw, mae'r slot pentwr ar gyfer y benthyciad yn cael ei ymsefydlu hyd yn oed cyn i'r gwerthoedd gael eu cymharu, gan arwain at arafu amlwg.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Yn honni bod mynegiad boolean yn `true` ar amser rhedeg.
///
/// Bydd hyn yn galw y macro [`panic!`] os na all yr ymadrodd a ddarperir yn cael eu gwerthuso i `true` yn Rhedeg.
///
/// Fel [`assert!`], mae gan y macro hwn ail fersiwn hefyd, lle gellir darparu neges panic wedi'i haddasu.
///
/// # Uses
///
/// Yn wahanol i [`assert!`], dim ond mewn adeiladau nad ydynt wedi'u optimeiddio y mae datganiadau `debug_assert!` yn cael eu galluogi.
/// Ni fydd adeilad wedi'i optimeiddio yn gweithredu datganiadau `debug_assert!` oni bai bod `-C debug-assertions` yn cael ei basio i'r casglwr.
/// Mae hyn yn gwneud `debug_assert!` yn ddefnyddiol ar gyfer archwiliadau sy'n rhy ddrud i fod yn bresennol mewn adeiladu rhyddhau ond gall fod yn ddefnyddiol yn ystod y datblygiad.
/// Mae canlyniad ehangu `debug_assert!` bob amser yn cael ei wirio math.
///
/// Honiad unchecked yn caniatáu rhaglen yn anghyson i gadw redeg, a allai arwain at ganlyniadau annisgwyl ond nid yw'n cyflwyno unsafety cyhyd â bod hyn yn digwydd dim ond mewn cod yn ddiogel.
///
/// Mae cost perfformiad haeriadau, fodd bynnag, yn fesuradwy yn gyffredinol.
/// Felly dim ond ar ôl proffilio trylwyr y caiff disodli [`assert!`] â `debug_assert!`, ac yn bwysicach fyth, dim ond mewn cod diogel!
///
/// # Examples
///
/// ```
/// // neges panic ar gyfer yr honiadau hyn yw gwerth llinynnol yr ymadrodd a roddir.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // swyddogaeth syml iawn
/// debug_assert!(some_expensive_computation());
///
/// // honni gyda neges arferiad
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Honni bod dau fynegiad yn gyfartal â'i gilydd.
///
/// Ar panic, bydd macro hwn yn argraffu'r gwerthoedd o'r ymadroddion gyda'u sylwadau debug.
///
/// Yn wahanol i [`assert_eq!`], datganiadau `debug_assert_eq!` yn unig galluogi mewn pobl nad ydynt yn adeiladu optimized yn ddiofyn.
/// Ni fydd adeiladu optimized gweithredu datganiadau `debug_assert_eq!` oni `-C debug-assertions` cael ei drosglwyddo i'r casglwr.
/// Mae hyn yn gwneud `debug_assert_eq!` yn ddefnyddiol ar gyfer archwiliadau sy'n rhy ddrud i fod yn bresennol mewn adeiladu rhyddhau ond gall fod yn ddefnyddiol yn ystod y datblygiad.
///
/// Mae canlyniad ehangu `debug_assert_eq!` bob amser yn cael ei wirio math.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Honni nad yw dau fynegiad yn gyfartal â'i gilydd.
///
/// Ar panic, bydd macro hwn yn argraffu'r gwerthoedd o'r ymadroddion gyda'u sylwadau debug.
///
/// Yn wahanol i [`assert_ne!`], datganiadau `debug_assert_ne!` yn unig galluogi mewn pobl nad ydynt yn adeiladu optimized yn ddiofyn.
/// Ni fydd adeilad wedi'i optimeiddio yn gweithredu datganiadau `debug_assert_ne!` oni bai bod `-C debug-assertions` yn cael ei basio i'r casglwr.
/// Mae hyn yn gwneud `debug_assert_ne!` yn ddefnyddiol ar gyfer archwiliadau sy'n rhy ddrud i fod yn bresennol mewn adeiladu rhyddhau ond gall fod yn ddefnyddiol yn ystod y datblygiad.
///
/// Canlyniad ehangu `debug_assert_ne!` yn teipiwch wirio.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Yn dychwelyd a yw'r mynegiad a roddir yn cyfateb i unrhyw un o'r patrymau a roddir.
///
/// Fel mewn mynegiant `match`, gall y patrwm yn cael ei ddilyn yn ddewisol gan `if` a mynegiant gard sydd â mynediad at enwau rhwymo gan y patrwm.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Unwraps canlyniad neu ehangun ei gamgymeriad.
///
/// Ychwanegwyd gweithredwr `?` i gymryd lle `try!` a dylid ei ddefnyddio yn lle.
/// Ar ben hynny, mae `try` yn air neilltuedig yn Rust 2018, felly os oes rhaid i chi ei ddefnyddio, bydd angen i chi ddefnyddio'r [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` cyfateb i'r [`Result`] a roddir.Yn achos y amrywiad `Ok`, mynegiant mae gwerth y gwerth lapio.
///
/// Mewn achos o amrywiad `Err`, mae'n adennill y gwall mewnol.`try!` wedyn yn perfformio trosi ddefnyddio `From`.
/// Mae hyn yn darparu trosi awtomatig rhwng gwallau arbenigol a rhai mwy cyffredinol.
/// Yna dychwelir y gwall sy'n deillio o hyn ar unwaith.
///
/// Oherwydd y dychweliad cynnar, dim ond mewn swyddogaethau sy'n dychwelyd [`Result`] y gellir defnyddio `try!`.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Y dull a ffafrir of Errors dychwelyd cyflym
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Mae'r dull blaenorol o Gwallau dychwelyd cyflym
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Mae hyn yn cyfateb i:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Yn ysgrifennu data wedi'i fformatio i mewn i byffer.
///
/// Mae'r macro yn derbyn 'writer', fformat llinyn, a rhestr o ddadleuon.
/// Bydd dadleuon yn cael eu fformatio yn ôl y llinyn fformat penodedig a bydd y canlyniad yn cael ei drosglwyddo i'r ysgrifennwr.
/// Gall yr awdur fod yn unrhyw werth gyda dull `write_fmt`;yn gyffredinol daw hyn o weithrediad naill ai'r [`fmt::Write`] neu'r [`io::Write`] trait.
/// Mae'r macro yn dychwelyd beth bynnag mae'r dull `write_fmt` yn ei ddychwelyd;yn gyffredin [`fmt::Result`], neu [`io::Result`].
///
/// Gweler [`std::fmt`] i gael mwy o wybodaeth am gystrawen y llinyn fformat.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Gall modiwl mewnforio ddau `std::fmt::Write` a `std::io::Write` a `write!` galw ar wrthrychau gweithredu naill ai, gan nad yw gwrthrychau yn gweithredu y ddau fel arfer.
///
/// Fodd bynnag, mae'r modiwl yn rhaid mewnforio i'r traits gymhwyso fel nad yw eu henwau yn gwrthdaro:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // yn defnyddio fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // yn defnyddio io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Gellir defnyddio'r macro hwn mewn setiau `no_std` hefyd.
/// Mewn setup `no_std` rydych yn gyfrifol am y manylion gweithredu'r cydrannau.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Ysgrifennu data fformatio i mewn i byffer, gyda newline atodi.
///
/// Ar bob llwyfan, mae'r newline yw'r cymeriad FEED LINE (`\n`/`U+000A`) ei ben ei hun (dim ychwanegol CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Am fwy o wybodaeth, gweler [`write!`].Am wybodaeth ar gystrawen llinyn y fformat, gweler [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Gall modiwl mewnforio ddau `std::fmt::Write` a `std::io::Write` a `write!` galw ar wrthrychau gweithredu naill ai, gan nad yw gwrthrychau yn gweithredu y ddau fel arfer.
/// Fodd bynnag, mae'r modiwl yn rhaid mewnforio i'r traits gymhwyso fel nad yw eu henwau yn gwrthdaro:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // yn defnyddio fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // yn defnyddio io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Yn dangos cod anghyraeddadwy.
///
/// Mae hyn yn ddefnyddiol unrhyw adeg na all y casglwr phenderfynu bod rhyw cod yn anghyraeddadwy.Er enghraifft:
///
/// * Cydweddwch freichiau ag amodau gwarchod.
/// * Dolenni hynny ddeinamig terfynu.
/// * Iterators sy'n terfynu'n ddeinamig.
///
/// Os yw'r penderfyniad bod y cod yn anghyraeddadwy yn profi'n anghywir, daw'r rhaglen i ben ar unwaith gyda [`panic!`].
///
/// Mae'r cyfatebol anniogel macro hwn yw swyddogaeth [`unreachable_unchecked`], a fydd yn achosi ymddygiad anniffiniedig os yw'r cod yn cael ei gyrraedd.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Bydd hyn bob amser yn [`panic!`].
///
/// # Examples
///
/// Cydweddu breichiau:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // llunio gwall os rhoddir sylwadau arno
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // un o gweithrediadau tlotaf x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Yn dangos cod heb ei weithredu trwy banig gyda neges o "not implemented".
///
/// Mae hyn yn caniatáu eich cod i math-siec, sy'n ddefnyddiol os ydych yn prototeipio neu'n gweithredu trait sy'n gofyn dulliau lluosog nad ydych yn gwneud cynllun o ddefnyddio pob un.
///
/// Y gwahaniaeth rhwng `unimplemented!` a [`todo!`] yw tra `todo!` yn cyfleu bwriad o weithredu'r swyddogaeth yn ddiweddarach ac mae'r neges yn "not yet implemented", `unimplemented!` yn gwneud unrhyw hawliadau o'r fath.
/// Mae ei neges yn "not implemented".
/// Hefyd bydd rhai IDEs nodi `todo!` S.
///
/// # Panics
///
/// Bydd hyn bob amser [`panic!`] oherwydd `unimplemented!` yn unig yw llaw-fer am `panic!` â neges sefydlog, yn benodol.
///
/// Fel `panic!`, macro mae hyn yn cael ail ffurf ar gyfer arddangos gwerthoedd arferiad.
///
/// # Examples
///
/// Dweud gennym `Foo` trait:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Rydym yn awyddus i weithredu `Foo` i 'MyStruct', ond am ryw reswm yn unig mae'n gwneud synnwyr i weithredu'r swyddogaeth `bar()`.
/// `baz()` a bydd angen diffinio `qux()` o hyd wrth inni weithredu `Foo`, ond gallwn ddefnyddio `unimplemented!` yn eu diffiniadau i ganiatáu i'n cod lunio.
///
/// Rydym yn dal yn awyddus i gael ein rhedeg stopio rhaglen os dulliau heb eu gweithredu yn cael eu cyrraedd.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Nid yw'n gwneud unrhyw synnwyr i `baz` a `MyStruct`, felly nid oes gennym resymeg yma o gwbl.
/////
///         // Bydd hyn yn arddangos "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Gennym rai rhesymeg yma, Gallwn ychwanegu neges i heb eu gweithredu!i arddangos ein hepgor.
///         // Bydd hyn yn dangos: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Yn dangos cod heb ei orffen.
///
/// Gall hyn fod yn ddefnyddiol os ydych chi'n prototeipio ac yn edrych i gael eich teip-god cod yn unig.
///
/// Y gwahaniaeth rhwng [`unimplemented!`] a `todo!` yw er bod `todo!` yn cyfleu bwriad o weithredu'r swyddogaeth yn ddiweddarach a'r neges yw "not yet implemented", nid yw `unimplemented!` yn gwneud unrhyw honiadau o'r fath.
/// Mae ei neges yn "not implemented".
/// Hefyd bydd rhai IDEs nodi `todo!` S.
///
/// # Panics
///
/// Bydd hyn bob amser yn [`panic!`].
///
/// # Examples
///
/// Dyma enghraifft o rai Cod y gweill.Mae gennym trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Rydym yn awyddus i weithredu `Foo` ar un o'n math, ond rydym hefyd yn awyddus i weithio ar ddim ond `bar()` yn gyntaf.Er mwyn ein cod i crynhoi, mae angen i ni weithredu `baz()`, fel y gallwn eu defnyddio `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // gweithredu yn mynd yma
///     }
///
///     fn baz(&self) {
///         // gadewch i ni boeni am weithredu baz() am nawr
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // nid ydym yn hyd yn oed yn defnyddio baz(), felly mae hyn yn iawn.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Diffiniadau o adeiledig yn macros.
///
/// Mae'r rhan fwyaf o'r tai macro (sefydlogrwydd, gwelededd, ac ati) yn cael eu cymryd o'r cod ffynhonnell yma, ac eithrio swyddogaethau ehangu drawsnewid mewnbynnau macro mewn allbynnau, y swyddogaethau hynny yn cael eu darparu gan y compiler.
///
///
pub(crate) mod builtin {

    /// Yn achosi i'r crynhoad fethu â'r neges gwall a roddir pan ddaw ar ei draws.
    ///
    /// Dylai hyn gael ei ddefnyddio macro pan fydd crate yn defnyddio strategaeth casgliad amodol i ddarparu gwell negeseuon gwall ar gyfer cyflyrau wallus.
    ///
    /// Mae'n y ffurflen lefel casglwr o [`panic!`], ond yn allyrru gwall yn ystod llunio * * yn hytrach nag yn Rhedeg * *.
    ///
    /// # Examples
    ///
    /// Dwy enghraifft o'r fath yn macros ac amgylcheddau `#[cfg]`.
    ///
    /// Allyrru gwell gwall compiler os yw macro ei basio gwerthoedd annilys.
    /// Heb y branch terfynol, byddai'r compiler yn dal i allyrru camgymeriad, ond ni fyddai neges gwall yn sôn am y ddau werth dilys.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Gwall compiler allyrru os nad oes un o nifer o nodweddion ar gael.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Yn adeiladu paramedrau ar gyfer y macros eraill llinyn-fformatio.
    ///
    /// Mae hyn yn swyddogaethau macro drwy gymryd llinyn fformatio lythrennol cynnwys `{}` gyfer pob ddadl ychwanegol a drosglwyddir.
    /// `format_args!` yn paratoi'r paramedrau ychwanegol i sicrhau y gellir dehongli'r allbwn fel llinyn ac yn canoneiddio'r dadleuon yn un math.
    /// Gellir trosglwyddo unrhyw werth sy'n gweithredu'r [`Display`] trait i `format_args!`, fel y gellir trosglwyddo unrhyw weithrediad [`Debug`] i `{:?}` o fewn y llinyn fformatio.
    ///
    ///
    /// Mae'r macro yn cynhyrchu gwerth y math [`fmt::Arguments`].Gall y gwerth hwn yn cael ei throsglwyddo i'r macros fewn [`std::fmt`] ar gyfer perfformio ailgyfeirio defnyddiol.
    /// Mae'r holl macros fformatio eraill ([`fformat!`], [`write!`], [`println!`], ac ati) yn cael eu dirprwyo trwy'r un hwn.
    /// `format_args!`, wahanol i'w macros sy'n deillio, yn osgoi domen dyraniadau.
    ///
    /// Gallwch ddefnyddio'r gwerth [`fmt::Arguments`] fod `format_args!` yn dychwelyd mewn cyd-destunau `Debug` a `Display` fel y gwelir isod.
    /// Dengys y Enghraifft hefyd fod `Debug` a fformat `Display` at yr un peth: y fformat rhyngosod llinyn yn `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// I gael rhagor o wybodaeth, gweler y dogfennau yn [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Yr un peth â'r `format_args`, ond yn ychwanegu newline yn y diwedd.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Yn archwilio newidyn amgylchedd ar amser llunio.
    ///
    /// Bydd y macro ehangu i werth yr newidyn amgylchedd a enwir ar adeg crynhoi, cynhyrchu yn fynegiant o fath `&'static str`.
    ///
    ///
    /// Os na chaiff y newidyn amgylchedd ei ddiffinio, yna bydd gwall llunio yn cael ei ollwng.
    /// Er mwyn peidio allyrru gwall crynhoi, defnyddiwch y macro [`option_env!`] yn lle hynny.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Gallwch chi addasu'r neges gwall trwy basio llinyn fel yr ail baramedr:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Os nad yw'r newidyn amgylchedd `documentation` ei ddiffinio, byddwch yn cael y gwall canlynol:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Optionally yn arolygu newidyn amgylchedd ar adeg crynhoi.
    ///
    /// Os yw'r newidyn amgylchedd a enwir yn bresennol ar adeg crynhoi, bydd hyn yn ehangu i fynegiant o fath `Option<&'static str>` y mae eu gwerth yn `Some` o werth y newidyn amgylchedd.
    /// Os nad yw'r newidyn amgylchedd yn bresennol, yna bydd hyn yn ehangu i `None`.
    /// Gweler [`Option<T>`][Option] am fwy o wybodaeth ar y math hwn.
    ///
    /// Nid yw gwall amser llunio byth yn cael ei ollwng wrth ddefnyddio'r macro hwn ni waeth a yw'r newidyn amgylchedd yn bresennol ai peidio.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates dynodwyr i mewn i un dynodydd.
    ///
    /// Mae'r macro yn cymryd unrhyw nifer o ddynodwyr chomas rhyngddynt, a concatenates nhw i gyd i mewn i un, cynhyrchu mynegiant sy'n dynodwr newydd.
    /// Sylwch fod hylendid yn ei gwneud yn gymaint fel na all y macro hwn ddal newidynnau lleol.
    /// Hefyd, fel rheol gyffredinol, caniateir macros yn unig yn eitem, datganiad neu sefyllfa mynegiant.
    /// Mae hynny'n golygu er y gallwch ddefnyddio'r macro hwn i gyfeirio at newidynnau, swyddogaethau neu fodiwlau ac ati, ni allwch ddiffinio un newydd ag ef.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (newydd, hwyl, enw) { }//ddim yn ddefnyddiadwy fel hyn!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Yn cyd-fynd â llythrennau yn dafell llinyn statig.
    ///
    /// Mae'r macro yn cymryd unrhyw nifer o lythrenyddion chomas rhyngddynt, cynhyrchu yn fynegiant o fath `&'static str` sy'n cynrychioli pob un o'r lythrenyddion concatenated chwith i'r dde.
    ///
    ///
    /// Cyfanrif a pwynt arnawf lythrenyddion eu stringified er mwyn cael eu concatenated.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ehangu i'r rhif llinell y cafodd ei galw i rym.
    ///
    /// Gyda [`column!`] a [`file!`], mae'r macros hyn yn darparu gwybodaeth ddifa chwilod i ddatblygwyr am y lleoliad yn y ffynhonnell.
    ///
    /// Mae gan yr ymadrodd estynedig fath `u32` ac mae'n seiliedig ar 1, felly mae'r llinell gyntaf ym mhob ffeil yn gwerthuso i 1, yr ail i 2, ac ati.
    /// Mae hyn yn gyson â negeseuon gwall gan crynoadyddion cyffredin neu golygyddion poblogaidd.
    /// Nid yw'r llinell a ddychwelwyd *o reidrwydd* llinell y galwedigaeth `line!` ei hun, ond yn hytrach y macro-wahoddiad cyntaf sy'n arwain at erfyn y macro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Ehangu at y nifer golofn lle cafodd ei galw i rym.
    ///
    /// Gyda [`line!`] a [`file!`], macros hyn yn darparu gwybodaeth debugging i ddatblygwyr ynghylch y lleoliad o fewn y ffynhonnell.
    ///
    /// Mae gan yr ymadrodd estynedig fath `u32` ac mae'n seiliedig ar 1, felly mae'r golofn gyntaf ym mhob llinell yn gwerthuso i 1, yr ail i 2, ac ati.
    /// Mae hyn yn gyson â negeseuon gwall gan crynoadyddion cyffredin neu golygyddion poblogaidd.
    /// Nid yw'r golofn a ddychwelwyd *o reidrwydd* llinell y galwedigaeth `column!` ei hun, ond yn hytrach y macro-wahoddiad cyntaf sy'n arwain at erfyn y macro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Yn ehangu i enw'r ffeil y cafodd ei galw ynddo.
    ///
    /// Gyda [`line!`] a [`column!`], macros hyn yn darparu gwybodaeth debugging i ddatblygwyr ynghylch y lleoliad o fewn y ffynhonnell.
    ///
    /// Mae gan yr ymadrodd estynedig fath `&'static str`, ac nid y ffeil a ddychwelwyd yw erfyn y macro `file!` ei hun, ond yn hytrach y macro-wahoddiad cyntaf sy'n arwain at erfyn y macro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifies ei ddadleuon.
    ///
    /// Bydd y macro cynnyrch yn fynegiant o fath `&'static str` sef y stringification yr holl tokens trosglwyddo i'r macro.
    /// Dim cyfyngiadau yn cael eu rhoi ar y gystrawen y invocation macro ei hun.
    ///
    /// Sylwch y gall canlyniadau estynedig y mewnbwn tokens newid yn y future.Dylech fod yn ofalus os ydych yn dibynnu ar yr allbwn.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Yn cynnwys ffeil wedi'i hamgodio UTF-8 fel llinyn.
    ///
    /// Mae'r ffeil wedi ei leoli gymharu â'r ffeil gyfredol (yn yr un modd â sut modiwlau yn cael eu canfod).
    /// Mae'r llwybr a ddarperir yn cael ei ddehongli mewn ffordd benodol i blatfform ar amser llunio.
    /// Felly, er enghraifft, mae invocation gyda llwybr Windows yn cynnwys backslashes `\` ni fyddai llunio yn gywir ar Unix.
    ///
    ///
    /// Bydd y macro cynnyrch yn fynegiant o fath `&'static str` sef cynnwys y ffeil.
    ///
    /// # Examples
    ///
    /// Tybio bod dwy ffeil yn yr un cyfeiriadur gyda chynnwys canlynol:
    ///
    /// Ffeil 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Ffeil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Llunio 'main.rs' a rhedeg y deuaidd sy'n deillio bydd argraffu "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Yn cynnwys ffeil fel cyfeiriad at amrywiaeth beit.
    ///
    /// Mae'r ffeil wedi ei leoli gymharu â'r ffeil gyfredol (yn yr un modd â sut modiwlau yn cael eu canfod).
    /// Mae'r llwybr a ddarperir yn cael ei ddehongli mewn ffordd benodol i blatfform ar amser llunio.
    /// Felly, er enghraifft, mae invocation gyda llwybr Windows yn cynnwys backslashes `\` ni fyddai llunio yn gywir ar Unix.
    ///
    ///
    /// Bydd y macro hwn yn cynhyrchu mynegiad o fath `&'static [u8; N]` sef cynnwys y ffeil.
    ///
    /// # Examples
    ///
    /// Tybio bod dwy ffeil yn yr un cyfeiriadur gyda chynnwys canlynol:
    ///
    /// Ffeil 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Ffeil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Llunio 'main.rs' a rhedeg y deuaidd sy'n deillio bydd argraffu "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Yn ehangu i linyn sy'n cynrychioli llwybr cyfredol y modiwl.
    ///
    /// Gall y llwybr modiwl presennol yn cael ei ystyried fel yr hierarchaeth o fodiwlau sy'n arwain yn ôl i fyny at y crate root.
    /// Mae'r elfen gyntaf y llwybr dychwelyd yn enw'r crate cael ei lunio ar hyn o bryd.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Yn gwerthuso cyfuniadau boolean o fflagiau cyfluniad ar amser llunio.
    ///
    /// Yn ychwanegol at y priodoledd `#[cfg]`, macro hwn yn cael ei ddarparu er mwyn caniatáu gwerthuso mynegiant boolean o faneri cyfluniad.
    /// Mae hyn yn aml yn arwain at cod llai dyblygu.
    ///
    /// Mae'r gystrawen a roddir i'r macro hwn yr un gystrawen â'r priodoledd [`cfg`].
    ///
    /// `cfg!`, yn wahanol i `#[cfg]`, nid yw'n tynnu unrhyw cod a dim ond yn gwerthuso i wir neu'n anwir.
    /// Er enghraifft, pob blociau mewn angen mynegiant if/else i fod yn ddilys pan `cfg!` yn cael ei ddefnyddio ar gyfer y cyflwr, ni waeth beth `cfg!` yn gwerthuso.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parses ffeil fel mynegiant neu eitem yn ôl y cyd-destun.
    ///
    /// Mae'r ffeil wedi ei leoli gymharu â'r ffeil gyfredol (yn yr un modd â sut modiwlau yn cael eu canfod).Mae'r llwybr a ddarperir yn cael ei ddehongli mewn modd lwyfan-benodol ar adeg crynhoi.
    /// Felly, er enghraifft, mae invocation gyda llwybr Windows yn cynnwys backslashes `\` ni fyddai llunio yn gywir ar Unix.
    ///
    /// Gan ddefnyddio'r macro hyn yn aml yn syniad drwg, oherwydd os bydd y ffeil yn cael ei parsed fel mynegiant, mae'n mynd i gael ei roi yn y cod amgylch unhygienically.
    /// Gallai hyn arwain at newidynnau neu swyddogaethau fod yn wahanol i'r hyn a ddisgwylir ffeil os oes newidynnau neu swyddogaethau sydd â'r un enw yn y ffeil cyfredol.
    ///
    ///
    /// # Examples
    ///
    /// Tybio bod dwy ffeil yn yr un cyfeiriadur gyda chynnwys canlynol:
    ///
    /// Ffeil 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Ffeil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Llunio 'main.rs' a rhedeg y deuaidd sy'n deillio bydd argraffu "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Yn honni bod mynegiad boolean yn `true` ar amser rhedeg.
    ///
    /// Bydd hyn yn galw y macro [`panic!`] os na all yr ymadrodd a ddarperir yn cael eu gwerthuso i `true` yn Rhedeg.
    ///
    /// # Uses
    ///
    /// Haeriadau bob amser yn cael eu gwirio yn y ddau debug a rhyddhau yn adeiladu, ac ni ellir fod yn anabl.
    /// Gweler [`debug_assert!`] i honiadau nad ydynt yn cael eu galluogi yn y datganiad yn adeiladu yn ddiofyn.
    ///
    /// Efallai y cod anniogel yn dibynnu ar `assert!` i orfodi invariants rhedeg-amser, gallai os sathru arwain at unsafety.
    ///
    /// Mae achosion defnydd eraill o `assert!` yn cynnwys profi a gorfodi invariants amser rhedeg mewn cod diogel (ni all eu torri arwain at anniogelrwydd).
    ///
    ///
    /// # Negeseuon Custom
    ///
    /// Mae hwn macro ail fath, lle gall arfer panic neges yn cael ei ddarparu gyda neu heb dadleuon dros fformatio.
    /// Gweler [`std::fmt`] am cystrawen ar gyfer y ffurflen hon.
    /// Dim ond os bydd yr honiad yn methu y bydd mynegiadau a ddefnyddir fel dadleuon fformat yn cael eu gwerthuso.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // neges panic ar gyfer yr honiadau hyn yw gwerth llinynnol yr ymadrodd a roddir.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // swyddogaeth syml iawn
    ///
    /// assert!(some_computation());
    ///
    /// // honni gyda neges arferiad
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Unol cynulliad.
    ///
    /// Darllenwch yr [unstable book] i'w ddefnyddio.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-arddull inline cynulliad.
    ///
    /// Darllenwch yr [unstable book] i'w ddefnyddio.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Modiwl lefel inline cynulliad.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Printiau pasio tokens i mewn i'r allbwn safonol.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Galluogi neu analluogir olrhain ymarferoldeb a ddefnyddir ar gyfer debugging macros eraill.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Priodoledd macro a ddefnyddir i gymhwyso macros deillio.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// macro priodoledd berthnasol i swyddogaeth i droi i mewn i brawf uned.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// macro priodoledd berthnasol i swyddogaeth i droi i mewn prawf meincnod.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Mae manylion gweithredu'r `#[test]` a `#[bench]` macros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Mae priodoledd macro wedi'i gymhwyso i statig i'w gofrestru fel dyrannwr byd-eang.
    ///
    /// Gweler hefyd [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Yn cadw'r eitem y mae'n berthnasol iddi os yw'r llwybr a basiwyd yn hygyrch, ac yn ei dynnu fel arall.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Ehangu pob `#[cfg]` a `#[cfg_attr]` priodoleddau yn y cod darn mae'n berthnasol i.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Manylion gweithredu ansefydlog y crynhoydd `rustc`, peidiwch â defnyddio.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Manylion gweithredu ansefydlog y crynhoydd `rustc`, peidiwch â defnyddio.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}