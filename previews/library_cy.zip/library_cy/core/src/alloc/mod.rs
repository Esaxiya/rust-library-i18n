//! APIs dyrannu cof

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Mae'r gwall `AllocError` yn nodi methiant dyrannu a allai fod oherwydd blinder adnoddau neu rywbeth o'i le wrth gyfuno'r dadleuon mewnbwn a roddir gyda'r dyrannwr hwn.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (mae angen hwn arnom ar gyfer impl i lawr yr afon o Gwall trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Gall gweithredu `Allocator` dyrannu, tyfu, crebachu, ac yn deallocate blociau mympwyol o ddata a ddisgrifir drwy [`Layout`][].
///
/// `Allocator` wedi ei gynllunio i gael ei rhoi ar waith ar ZSTs, cyfeiriadau, neu awgrymiadau smart oherwydd ar ôl ni all dyrannydd fel `MyAlloc([u8; N])` yn cael ei symud, heb ddiweddaru'r awgrymiadau er cof a ddyrannwyd.
///
/// Yn wahanol i [`GlobalAlloc`][], dyraniadau sero maint ganiateir yn `Allocator`.
/// Os nad yw dyrannydd gwaelodol yn cefnogi hyn (fel jemalloc) neu ddychwelyd pwyntydd null (fel `libc::malloc`), rhaid i hyn gael ei dal gan y gweithrediad.
///
/// ### Cof wedi'i ddyrannu ar hyn o bryd
///
/// Mae rhai o'r dulliau a gofyn bod bloc cof yn cael ei ddyrannu * * ar hyn o bryd drwy dyrannydd.Mae hyn yn golygu:
///
/// * y cyfeiriad cychwyn ar gyfer y bloc cof ei ddychwelyd yn flaenorol gan [`allocate`], [`grow`], neu [`shrink`], ac
///
/// * nid yw'r bloc cof wedi'i ddeall wedi hynny, lle mae blociau naill ai'n cael eu deall yn uniongyrchol trwy gael eu trosglwyddo i [`deallocate`] neu eu newid trwy gael eu trosglwyddo i [`grow`] neu [`shrink`] sy'n dychwelyd `Ok`.
///
/// Os yw `grow` neu `shrink` wedi dychwelyd `Err`, mae'r pwyntydd a basiwyd yn parhau i fod yn ddilys.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Gosod cof
///
/// Mae rhai o'r dulliau'n mynnu bod cynllun *yn ffitio* bloc cof.
/// Yr hyn y mae'n ei olygu i gynllun i "fit" mae bloc cof yn ei olygu (neu'n gyfwerth, ar gyfer bloc cof i "fit" cynllun) yw bod yn rhaid i'r amodau canlynol ddal:
///
/// * Rhaid i'r bloc yn cael ei ddyrannu gyda'r un aliniad â [`layout.align()`], a
///
/// * Rhaid i'r [`layout.size()`] a ddarperir yn disgyn yn yr ystod `min ..= max`, lle:
///   - `min` yw maint y cynllun a ddefnyddiwyd yn fwyaf diweddar i ddyrannu'r bloc, a
///   - `max` yw maint gwirioneddol diweddaraf dychwelyd o [`allocate`], [`grow`], neu [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Rhaid i flociau cof a ddychwelir gan ddyrannwr bwyntio at gof dilys a chadw eu dilysrwydd nes bod yr enghraifft a'i holl glonau wedi'u gollwng,
///
/// * rhaid i glonio neu symud y dyrannwr beidio annilysu blociau cof a ddychwelwyd o'r dyrannwr hwn.Rhaid i dyrannydd clonio ymddwyn fel yr un dyrannydd, ac
///
/// * gall unrhyw pwyntydd i'r bloc cof sydd [*currently allocated*] yn cael ei drosglwyddo i unrhyw ddull arall y dyrannydd.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Ymdrechion i ddyrannu bloc o gof.
    ///
    /// Ar lwyddiant, yn dychwelyd [`NonNull<[u8]>`][NonNull] cwrdd â'r gwarantau maint ac alinio `layout`.
    ///
    /// Efallai y bydd y bloc a ddychwelwyd yn cael maint mwy na nodir gan `layout.size()`, a allai neu efallai na fydd yn rhaid ei gynnwys ymgychwyn.
    ///
    /// # Errors
    ///
    /// Mae dychwelyd `Err` yn nodi bod naill ai cof wedi disbyddu neu nad yw `layout` yn cwrdd â maint y dyraniad neu gyfyngiadau alinio.
    ///
    /// Anogir gweithrediadau i ddychwelyd `Err` ar flinder cof yn hytrach na mynd i banig neu erthylu, ond nid yw hwn yn ofyniad llym.
    /// (Yn benodol: mae'n *gyfreithiol* gweithredu'r trait hwn ar ben llyfrgell dyrannu brodorol sylfaenol sy'n erthylu ar flinder cof.)
    ///
    /// Mae cleientiaid sy'n dymuno Erthylu gyfrifiannu mewn ymateb i wall dyrannu yn cael eu hannog i alw swyddogaeth [`handle_alloc_error`], yn hytrach na galw ar `panic!` neu debyg yn uniongyrchol.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Yn ymddwyn fel `allocate`, ond hefyd yn sicrhau bod y cof a ddychwelwyd yn sero-ymgychwyn.
    ///
    /// # Errors
    ///
    /// Mae dychwelyd `Err` yn nodi bod naill ai cof wedi disbyddu neu nad yw `layout` yn cwrdd â maint y dyraniad neu gyfyngiadau alinio.
    ///
    /// Anogir gweithrediadau i ddychwelyd `Err` ar flinder cof yn hytrach na mynd i banig neu erthylu, ond nid yw hwn yn ofyniad llym.
    /// (Yn benodol: mae'n *gyfreithiol* gweithredu'r trait hwn ar ben llyfrgell dyrannu brodorol sylfaenol sy'n erthylu ar flinder cof.)
    ///
    /// Mae cleientiaid sy'n dymuno Erthylu gyfrifiannu mewn ymateb i wall dyrannu yn cael eu hannog i alw swyddogaeth [`handle_alloc_error`], yn hytrach na galw ar `panic!` neu debyg yn uniongyrchol.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // DIOGELWCH: Mae `alloc` yn dychwelyd bloc cof dilys
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Yn dyrannu'r cof y cyfeirir ato gan `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` rhaid dynodi bloc o gof [*currently allocated*] trwy'r dyrannwr hwn, a
    /// * `layout` rhaid [*fit*] bod bloc o cof.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Ymdrechion i ymestyn y bloc cof.
    ///
    /// Yn dychwelyd [`NonNull<[u8]>`][NonNull] newydd sy'n cynnwys pwyntydd a maint gwirioneddol y cof a ddyrannwyd.Mae'r pwyntydd yn addas ar gyfer dal data a ddisgrifir gan `new_layout`.
    /// I gyflawni hyn, efallai y bydd y dyrannydd ymestyn y dyraniad gyfeirio gan `ptr` i gyd-fynd â'r cynllun newydd.
    ///
    /// Os yw hyn yn dychwelyd `Ok`, yna mae perchnogaeth y bloc cof y cyfeirir ato gan `ptr` wedi'i drosglwyddo i'r dyrannwr hwn.
    /// Gall y cof neu efallai na fydd wedi cael eu rhyddhau, a dylid ystyried na ellir eu defnyddio oni bai iddo gael ei drosglwyddo yn ôl i'r galwr eto drwy'r gwerth dychwelyd y dull hwn.
    ///
    /// Os yw'r dull hwn yn dychwelyd `Err`, yna ni throsglwyddwyd perchnogaeth y bloc cof i'r dyrannwr hwn, ac mae cynnwys y bloc cof heb ei newid.
    ///
    /// # Safety
    ///
    /// * `ptr` rhaid dynodi bloc o gof [*currently allocated*] trwy'r dyrannwr hwn.
    /// * `old_layout` rhaid [*fit*] y bloc cof hwnnw (Nid oes angen i ddadl `new_layout` ei ffitio.).
    /// * `new_layout.size()` rhaid iddo fod yn fwy na neu'n hafal i `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Yn dychwelyd `Err` os nad yw'r cynllun newydd yn cwrdd â maint a chyfyngiad aliniad y dyrannwr, neu os yw tyfu fel arall yn methu.
    ///
    /// Anogir gweithrediadau i ddychwelyd `Err` ar flinder cof yn hytrach na mynd i banig neu erthylu, ond nid yw hwn yn ofyniad llym.
    /// (Yn benodol: mae'n *gyfreithiol* gweithredu'r trait hwn ar ben llyfrgell dyrannu brodorol sylfaenol sy'n erthylu ar flinder cof.)
    ///
    /// Mae cleientiaid sy'n dymuno Erthylu gyfrifiannu mewn ymateb i wall dyrannu yn cael eu hannog i alw swyddogaeth [`handle_alloc_error`], yn hytrach na galw ar `panic!` neu debyg yn uniongyrchol.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // DIOGELWCH: oherwydd rhaid i `new_layout.size()` fod yn fwy na neu'n hafal i
        // `old_layout.size()`, mae'r dyraniad cof hen a newydd yn ddilys ar gyfer darlleniadau ac ysgrifennu ar gyfer beitiau `old_layout.size()`.
        // Hefyd, oherwydd nad oedd yr hen ddyraniad wedi'i ddeall eto, ni all orgyffwrdd `new_ptr`.
        // Felly, mae'r alwad i `copy_nonoverlapping` yn ddiogel.
        // Rhaid i'r galwr gadarnhau'r contract diogelwch ar gyfer `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ymddwyn fel `grow`, ond hefyd yn sicrhau bod y cynnwys newydd yn cael eu gosod i sero cyn cael eu dychwelyd.
    ///
    /// Bydd y bloc cof gynnwys y cynnwys canlynol ar ôl galwad llwyddiannus i
    /// `grow_zeroed`:
    ///   * Mae beitiau `0..old_layout.size()` yn cael eu cadw o'r dyraniad gwreiddiol.
    ///   * Bydd Bytes `old_layout.size()..old_size` naill ai'n cael eu cadw neu eu sero, yn dibynnu ar weithrediad y dyrannwr.
    ///   `old_size` yn cyfeirio at faint y bloc cof cyn i'r alwad `grow_zeroed`, a all fod yn fwy na maint y gofynnwyd yn wreiddiol pan gafodd ei ddyrannu.
    ///   * Mae beitiau `old_size..new_size` yn sero.`new_size` yn cyfeirio at faint y bloc cof a ddychwelwyd gan yr alwad `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` rhaid dynodi bloc o gof [*currently allocated*] trwy'r dyrannwr hwn.
    /// * `old_layout` rhaid [*fit*] y bloc cof hwnnw (Nid oes angen i ddadl `new_layout` ei ffitio.).
    /// * `new_layout.size()` rhaid iddo fod yn fwy na neu'n hafal i `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Yn dychwelyd `Err` os nad yw'r cynllun newydd yn cwrdd â maint a chyfyngiad aliniad y dyrannwr, neu os yw tyfu fel arall yn methu.
    ///
    /// Anogir gweithrediadau i ddychwelyd `Err` ar flinder cof yn hytrach na mynd i banig neu erthylu, ond nid yw hwn yn ofyniad llym.
    /// (Yn benodol: mae'n *gyfreithiol* gweithredu'r trait hwn ar ben llyfrgell dyrannu brodorol sylfaenol sy'n erthylu ar flinder cof.)
    ///
    /// Mae cleientiaid sy'n dymuno Erthylu gyfrifiannu mewn ymateb i wall dyrannu yn cael eu hannog i alw swyddogaeth [`handle_alloc_error`], yn hytrach na galw ar `panic!` neu debyg yn uniongyrchol.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // DIOGELWCH: oherwydd rhaid i `new_layout.size()` fod yn fwy na neu'n hafal i
        // `old_layout.size()`, mae'r dyraniad cof hen a newydd yn ddilys ar gyfer darlleniadau ac ysgrifennu ar gyfer beitiau `old_layout.size()`.
        // Hefyd, oherwydd nad oedd yr hen ddyraniad wedi'i ddeall eto, ni all orgyffwrdd `new_ptr`.
        // Felly, mae'r alwad i `copy_nonoverlapping` yn ddiogel.
        // Rhaid i'r galwr gadarnhau'r contract diogelwch ar gyfer `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ymdrechion i grebachu y bloc cof.
    ///
    /// Yn dychwelyd [`NonNull<[u8]>`][NonNull] newydd sy'n cynnwys pwyntydd a maint gwirioneddol y cof a ddyrannwyd.Mae'r pwyntydd yn addas ar gyfer dal data a ddisgrifir gan `new_layout`.
    /// I gyflawni hyn, efallai y bydd y dyrannydd crebachu y dyraniad gyfeirio gan `ptr` i gyd-fynd â'r cynllun newydd.
    ///
    /// Os yw hyn yn dychwelyd `Ok`, yna mae perchnogaeth y bloc cof y cyfeirir ato gan `ptr` wedi'i drosglwyddo i'r dyrannwr hwn.
    /// Gall y cof neu efallai na fydd wedi cael eu rhyddhau, a dylid ystyried na ellir eu defnyddio oni bai iddo gael ei drosglwyddo yn ôl i'r galwr eto drwy'r gwerth dychwelyd y dull hwn.
    ///
    /// Os yw'r dull hwn yn dychwelyd `Err`, yna ni throsglwyddwyd perchnogaeth y bloc cof i'r dyrannwr hwn, ac mae cynnwys y bloc cof heb ei newid.
    ///
    /// # Safety
    ///
    /// * `ptr` rhaid dynodi bloc o gof [*currently allocated*] trwy'r dyrannwr hwn.
    /// * `old_layout` rhaid [*fit*] y bloc cof hwnnw (Nid oes angen i ddadl `new_layout` ei ffitio.).
    /// * `new_layout.size()` rhaid iddo fod yn llai na neu'n hafal i `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ffurflenni `Err` os nad yw'r cynllun newydd yn bodloni cyfyngiadau maint ac aliniad y dyrannydd o'r dyrannydd, neu os crebachu yn methu fel arall.
    ///
    /// Anogir gweithrediadau i ddychwelyd `Err` ar flinder cof yn hytrach na mynd i banig neu erthylu, ond nid yw hwn yn ofyniad llym.
    /// (Yn benodol: mae'n *gyfreithiol* gweithredu'r trait hwn ar ben llyfrgell dyrannu brodorol sylfaenol sy'n erthylu ar flinder cof.)
    ///
    /// Mae cleientiaid sy'n dymuno Erthylu gyfrifiannu mewn ymateb i wall dyrannu yn cael eu hannog i alw swyddogaeth [`handle_alloc_error`], yn hytrach na galw ar `panic!` neu debyg yn uniongyrchol.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // DIOGELWCH: oherwydd rhaid `new_layout.size()` fod yn is na neu'n hafal i
        // `old_layout.size()`, mae'r dyraniad cof hen a newydd yn ddilys ar gyfer darlleniadau ac ysgrifennu ar gyfer beitiau `new_layout.size()`.
        // Hefyd, oherwydd nad oedd yr hen ddyraniad wedi'i ddeall eto, ni all orgyffwrdd `new_ptr`.
        // Felly, mae'r alwad i `copy_nonoverlapping` yn ddiogel.
        // Rhaid i'r galwr gadarnhau'r contract diogelwch ar gyfer `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Creu adapter "by reference" er enghraifft yma o `Allocator`.
    ///
    /// Mae'r adapter dychwelyd hefyd yn gweithredu `Allocator` a bydd yn syml benthyg hyn.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // DIOGELWCH: rhaid i'r galwr gadarnhau'r contract diogelwch
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // DIOGELWCH: rhaid i'r galwr gadarnhau'r contract diogelwch
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // DIOGELWCH: rhaid i'r galwr gadarnhau'r contract diogelwch
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // DIOGELWCH: rhaid i'r galwr gadarnhau'r contract diogelwch
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}