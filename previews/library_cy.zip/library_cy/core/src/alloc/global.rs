use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Mae dyrannydd cof y gellir ei gofrestru fel rhagosodedig llyfrgell safonol drwy'r priodoledd `#[global_allocator]`.
///
/// Mae rhai o'r dulliau a gofyn bod bloc cof yn cael ei ddyrannu * * ar hyn o bryd drwy dyrannydd.Mae hyn yn golygu:
///
/// * y cyfeiriad cychwyn ar gyfer y bloc cof ei ddychwelyd yn flaenorol gan alwad blaenorol i ddull dyrannu fel `alloc`, a
///
/// * nid yw'r bloc cof wedi ei deallocated hynny, lle mae blociau yn cael eu deallocated naill ai trwy gael eu trosglwyddo i ddull deallocation fel `dealloc` neu drwy gael ei drosglwyddo i ddull ailddyrannu bod yn dychwelyd pwyntydd heb fod yn null.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// Mae'r `GlobalAlloc` trait yn `unsafe` trait am nifer o resymau, a rhaid i weithredwyr sicrhau eu bod yn cadw at y contractau hyn:
///
/// * Mae'n ymddygiad heb ei ddiffinio os yw dyranwyr byd-eang yn dadflino.Gellir codi'r cyfyngiad hwn yn y future, ond ar hyn o bryd gall panic o unrhyw un o'r swyddogaethau hyn arwain at anniogelrwydd cof.
///
/// * `Layout` rhaid i ymholiadau a chyfrifiadau yn gyffredinol fod yn gywir.Galwyr o trait hwn chaniateir i ddibynnu ar y contractau a ddiffinnir ar bob dull, ac mae'n rhaid i implementors sicrhau contractau o'r fath yn parhau i fod yn wir.
///
/// * Efallai na fyddwch yn dibynnu ar ddyraniadau digwydd mewn gwirionedd, hyd yn oed os oes dyraniadau domen amlwg yn y ffynhonnell.
/// Efallai y bydd yr optimizer yn canfod dyraniadau nas defnyddiwyd y gall naill ai eu dileu yn gyfan gwbl neu symud i'r pentwr ac felly byth â galw'r dynodwr.
/// Efallai y bydd yr optimizer yn tybio ymhellach fod y dyraniad yn anffaeledig, felly gall cod a arferai fethu oherwydd methiannau dyrannu nawr weithio'n sydyn oherwydd bod yr optimizer wedi gweithio o amgylch yr angen am ddyraniad.
/// Yn fwy pendant, mae'r enghraifft god ganlynol yn ddi-sail, ni waeth a yw'ch dyrannwr arferiad yn caniatáu cyfrif faint o ddyraniadau sydd wedi digwydd.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Noder nad yw'r optimeiddiad a grybwyllir uchod yw'r unig optimization y gellir eu cymhwyso.Yn gyffredinol, mae'n bosibl na fydd byddwch yn dibynnu ar ddyraniadau tomen digwydd os gellir eu dileu heb newid ymddygiad rhaglen.
///   P'un a dyraniadau yn digwydd neu beidio nid yn rhan o'r ymddygiad rhaglen, hyd yn oed pe gellid ei ganfod drwy dyrannydd bod traciau dyraniadau drwy argraffu neu fel arall yn cael sgîl-effeithiau.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Dyrannu cof fel y'i disgrifir gan yr `layout` a roddir.
    ///
    /// Dychwelyd pwyntydd i gof sydd newydd eu dyrannu, neu null i nodi methiant dyrannu.
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn anniogel oherwydd gall ymddygiad heb ei ddiffinio arwain os nad yw'r galwr yn sicrhau bod gan `layout` faint nad yw'n sero.
    ///
    /// (Gallai is-draciau estyniad ddarparu ffiniau mwy penodol ar ymddygiad, ee, gwarantu cyfeiriad sentinel neu bwyntydd null mewn ymateb i gais am ddyraniad maint sero.)
    ///
    /// Gellir cychwyn y bloc cof a ddyrannwyd neu beidio.
    ///
    /// # Errors
    ///
    /// Mae dychwelyd pwyntydd null yn dangos bod naill ai cof wedi disbyddu neu nad yw `layout` yn cwrdd â chyfyngiadau maint neu aliniad y dyrannwr hwn.
    ///
    /// Gweithrediadau yn cael eu hannog i ddychwelyd null ar blinder cof yn hytrach nag erthylu, ond nid yw hyn yn ofyniad caeth.
    /// (Yn benodol: mae'n *gyfreithiol* gweithredu'r trait hwn ar ben llyfrgell dyrannu brodorol sylfaenol sy'n erthylu ar flinder cof.)
    ///
    /// Mae cleientiaid sy'n dymuno Erthylu gyfrifiannu mewn ymateb i wall dyrannu yn cael eu hannog i alw swyddogaeth [`handle_alloc_error`], yn hytrach na galw ar `panic!` neu debyg yn uniongyrchol.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Dadddyrannwch y bloc cof ar y pwyntydd `ptr` a roddir gyda'r `layout` a roddir.
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn anniogel oherwydd gall ymddygiad undefined arwain os nad yw'r galwr yn sicrhau bod yr holl o'r canlynol:
    ///
    ///
    /// * `ptr` Rhaid dynodi bloc o cof a ddyrennir ar hyn o bryd drwy gyfrwng dyrannydd hwn,
    ///
    /// * `layout` rhaid iddo fod yr un cynllun ag a ddefnyddiwyd i ddyrannu'r bloc cof hwnnw.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Yn ymddwyn fel `alloc`, ond hefyd yn sicrhau bod y cynnwys wedi'i osod i sero cyn ei ddychwelyd.
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn anniogel am yr un rhesymau ag y mae `alloc`.
    /// Fodd bynnag, y bloc a ddyrannwyd o gof yn sicr o gael ei ymgychwyn.
    ///
    /// # Errors
    ///
    /// Mae dychwelyd pwyntydd null yn dangos bod naill ai cof wedi disbyddu neu nad yw `layout` yn cwrdd â chyfyngiadau maint neu aliniad y dyrannwr, yn yr un modd ag yn `alloc`.
    ///
    /// Mae cleientiaid sy'n dymuno Erthylu gyfrifiannu mewn ymateb i wall dyrannu yn cael eu hannog i alw swyddogaeth [`handle_alloc_error`], yn hytrach na galw ar `panic!` neu debyg yn uniongyrchol.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // DIOGELWCH: rhaid i'r galwr gadarnhau'r contract diogelwch ar gyfer `alloc`.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // DIOGELWCH: wrth i'r dyraniad lwyddo, y rhanbarth o `ptr`
            // o faint `size` yn sicr o fod yn ddilys ar gyfer ysgrifennu yn.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Crebachu neu dyfu bloc o cof i'r `new_size` a roddir.
    /// Mae'r bloc yn cael ei ddisgrifio gan y pwyntydd `ptr` a roddwyd ac `layout`.
    ///
    /// Os yw hyn yn dychwelyd pwyntydd heb fod yn null, yna perchnogaeth y bloc cof gyfeirio gan `ptr` wedi cael ei drosglwyddo i dyrannydd hwn.
    /// Gall y cof neu efallai na fydd wedi cael eu deallocated, a dylid ystyried na ellir eu defnyddio (oni bai, wrth gwrs, y cafodd ei drosglwyddo yn ôl i'r galwr eto drwy'r gwerth dychwelyd y dull hwn).
    /// Dyrennir y bloc cof newydd gyda `layout`, ond gyda'r `size` wedi'i ddiweddaru i `new_size`.
    /// Dylid defnyddio'r cynllun newydd hwn wrth ddeallococio'r bloc cof newydd gyda `dealloc`.
    /// Gwarantir y bydd gan ystod `0..min(layout.size(), new_size) `y bloc cof newydd yr un gwerthoedd â'r bloc gwreiddiol.
    ///
    /// Os bydd y dull hwn yn dychwelyd yn null, yna ni throsglwyddwyd perchnogaeth y bloc cof i'r dyrannwr hwn, ac nid yw cynnwys y bloc cof wedi'i newid.
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn anniogel oherwydd gall ymddygiad undefined arwain os nad yw'r galwr yn sicrhau bod yr holl o'r canlynol:
    ///
    /// * `ptr` Rhaid ei ddyrannu ar hyn o bryd drwy gyfrwng dyrannydd hwn,
    ///
    /// * `layout` Mae'n rhaid fod yr un cynllun a ddefnyddiwyd i ddyrannu bod bloc o cof,
    ///
    /// * `new_size` rhaid iddo fod yn fwy na sero.
    ///
    /// * `new_size`, wrth ei dalgrynnu i'r lluosrif agosaf o `layout.align()`, rhaid iddo beidio â gorlifo (hy, rhaid i'r gwerth crwn fod yn llai na `usize::MAX`).
    ///
    /// (Gallai is-draciau estyniad ddarparu ffiniau mwy penodol ar ymddygiad, ee, gwarantu cyfeiriad sentinel neu bwyntydd null mewn ymateb i gais am ddyraniad maint sero.)
    ///
    /// # Errors
    ///
    /// Yn dychwelyd null os nad yw'r cynllun newydd yn cwrdd â chyfyngiadau maint ac aliniad y dyrannwr, neu os yw ailddyrannu fel arall yn methu.
    ///
    /// Gweithrediadau yn cael eu hannog i ddychwelyd null ar blinder cof yn hytrach na mynd i banig neu erthylu, ond nid yw hyn yn ofyniad caeth.
    /// (Yn benodol: mae'n *gyfreithiol* gweithredu'r trait hwn ar ben llyfrgell dyrannu brodorol sylfaenol sy'n erthylu ar flinder cof.)
    ///
    /// Mae cleientiaid sy'n dymuno Erthylu gyfrifiannu mewn ymateb i wall ailddyrannu yn cael eu hannog i alw swyddogaeth [`handle_alloc_error`], yn hytrach na galw ar `panic!` neu debyg yn uniongyrchol.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // DIOGELWCH: mae'n rhaid i'r galwr sicrhau nad yw'r `new_size` yn gorlifo.
        // `layout.align()` yn dod o `Layout` ac felly mae'n sicr y bydd yn ddilys.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // DIOGELWCH: rhaid i'r galwr sicrhau bod `new_layout` yn fwy na sero.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // DIOGELWCH: ni all y bloc a ddyrannwyd yn flaenorol orgyffwrdd â'r bloc a ddyrannwyd o'r newydd.
            // Rhaid i'r galwr gadarnhau'r contract diogelwch ar gyfer `dealloc`.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}