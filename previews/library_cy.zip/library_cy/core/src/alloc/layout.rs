use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Tra bod y swyddogaeth hon yn cael ei ddefnyddio mewn un lle ac y gellid ei weithredu yn cael ei inlined, mae'r ymdrechion blaenorol i wneud a wnaed hyd rustc arafach:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Cynllun bloc o gof.
///
/// Mae enghraifft o `Layout` yn disgrifio cynllun cof penodol.
/// Rydych chi'n adeiladu `Layout` i fyny fel mewnbwn i'w roi i ddyrannwr.
///
/// Mae'r holl gynlluniau yn cael maint gysylltiedig ac aliniad phŵer i ddau.
///
/// (Noder bod gosodiadau yn * * Nid yw ofynnol iddynt gael heb fod yn sero maint, hyd yn oed er `GlobalAlloc` yn mynnu bod pob cais cof fod yn ddi-sero o ran maint.
/// Rhaid i galwr naill ai sicrhau bod amodau fel hyn yn cael eu bodloni, dyranwyr defnydd penodol â gofynion mwy llac, neu defnyddiwch y rhyngwyneb `Allocator` yn fwy trugarog.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // maint y bloc gofynnwyd y cof, wedi'i fesur mewn bytes.
    size_: usize,

    // aliniad y bloc cof y gofynnwyd amdano, wedi'i fesur mewn beit.
    // rydym yn sicrhau bod hwn bob amser yn bwer i ddau, oherwydd mae APIs fel `posix_memalign` yn gofyn amdano ac mae'n gyfyngiad rhesymol i'w osod ar adeiladwyr Cynllun.
    //
    //
    // (Fodd bynnag, nid ydym yn ei gwneud yn ofynnol analogously `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Yn llunio `Layout` o `size` a `align` penodol, neu'n dychwelyd `LayoutError` os na fodlonir unrhyw un o'r amodau canlynol:
    ///
    /// * `align` ni ddylent fod yn sero,
    ///
    /// * `align` rhaid iddo fod yn bŵer o ddau,
    ///
    /// * `size`, wrth ei dalgrynnu i'r lluosrif agosaf o `align`, rhaid iddo beidio â gorlifo (hy, rhaid i'r gwerth crwn fod yn llai na neu'n hafal i `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (Pŵer i ddau yn awgrymu align!=0.)

        // faint hyd Rounded yw:
        //   size_rounded_up=(maint + alinio, 1)&! (alinio, 1);
        //
        // Rydym yn gwybod o uchod y align!=0.
        // Os ychwanegu (alinio, 1) yn gorlifo, yna dalgrynnu i fyny yn iawn.
        //
        // I'r gwrthwyneb, bydd&-masking with! (Alinio, 1) yn tynnu darnau trefn isel yn unig.
        // Felly os bydd gorlif yn digwydd gyda'r swm, ni all yr&-mask dynnu digon i ddadwneud y gorlif hwnnw.
        //
        //
        // Uchod yn awgrymu bod gwirio am orlifiad crynhoad yn angenrheidiol ac yn ddigonol.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // DIOGELWCH: mae'r amodau ar gyfer `from_size_align_unchecked` wedi bod
        // gwirio uchod.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Yn creu cynllun, gan osgoi'r holl wiriadau.
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn anniogel gan nad yw'n gwirio'r rhagamodau o [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // DIOGELWCH: rhaid i'r galwr sicrhau bod `align` yn fwy na sero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Y maint lleiaf mewn beitiau ar gyfer bloc cof o'r cynllun hwn.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Yr aliniad beit lleiaf ar gyfer bloc cof o'r cynllun hwn.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Yn adeiladu `Layout` addas i gynnal gwerth y math `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // DIOGELWCH: mae'r aliniad wedi'i warantu gan Rust i fod yn bŵer dau a
        // mae'r combo maint + alinio yn sicr o ffitio yn ein gofod cyfeiriad.
        // O ganlyniad defnyddio'r Constructor unchecked yma i osgoi cod sy'n panics os na chaiff ei optimeiddio ar ddigon da fewnosod.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Yn cynhyrchu cynllun ddisgrifio cofnod y gellid ei ddefnyddio i ddyrannu strwythur cefnogaeth i `T` (a allai fod yn trait neu fath unsized eraill fel sleisen).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // DIOGELWCH: gweler y rhesymeg yn `new` pam mae hyn yn defnyddio'r amrywiad anniogel
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Yn cynhyrchu cynllun ddisgrifio cofnod y gellid ei ddefnyddio i ddyrannu strwythur cefnogaeth i `T` (a allai fod yn trait neu fath unsized eraill fel sleisen).
    ///
    /// # Safety
    ///
    /// Mae'r swyddogaeth hon yn unig yn ddiogel i'r alwad os yw'r amodau canlynol yn cynnal:
    ///
    /// - Os yw `T` yn `Sized`, mae'r swyddogaeth hon bob amser yn ddiogel i'w galw.
    /// - Os bydd y gynffon unsized o `T` yw:
    ///     - [slice], yna rhaid i hyd y gynffon dafell fod yn gyfanrif wedi'i fewnoli, a rhaid i faint y *gwerth cyfan*(hyd cynffon deinamig + rhagddodiad maint statig) ffitio yn `isize`.
    ///     - a [trait object], yna mae'n rhaid i ran y gellir ei newid o'r pwyntydd bwyntio at ddillad dilys ar gyfer y math `T` a gaffaelir gan orchudd annifyr, a rhaid i faint y *gwerth cyfan*(hyd cynffon deinamig + rhagddodiad maint statig) ffitio yn `isize`.
    ///
    ///     - yn (unstable) [extern type], yna swyddogaeth hon bob amser yn ddiogel i alw, ond gall panic neu fel arall yn dychwelyd y gwerth anghywir, gan nad cynllun y math extern yn hysbys.
    ///     Dyma'r un ymddygiad â [`Layout::for_value`] ar gyfeiriad at gynffon math allanol.
    ///     - fel arall, nid yw geidwadol chaniateir i alw swyddogaeth hon.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // DIOGELWCH: rydym yn trosglwyddo rhagofynion y swyddogaethau hyn i'r galwr
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // DIOGELWCH: gweler y rhesymeg yn `new` pam mae hyn yn defnyddio'r amrywiad anniogel
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Yn creu `NonNull` sy'n hongian, ond wedi'i alinio'n dda ar gyfer y Cynllun hwn.
    ///
    /// Sylwch y gallai gwerth y pwyntydd gynrychioli pwyntydd dilys o bosibl, sy'n golygu na ddylid defnyddio hwn fel gwerth sentinel "not yet initialized".
    /// Rhaid i fathau sy'n dyrannu'n ddiog olrhain cychwyniad mewn rhyw fodd arall.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // DIOGELWCH: alinio yn sicr o fod yn ddi-sero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Creu cynllun disgrifio'r record sy'n gallu cynnal gwerth yr un cynllun ag `self`, ond sydd hefyd yn cyd-fynd â aliniad `align` (wedi'i fesur mewn bytes).
    ///
    ///
    /// Os yw `self` eisoes yn cwrdd â'r aliniad rhagnodedig, yna mae'n dychwelyd `self`.
    ///
    /// Sylwch nad yw'r dull hwn yn ychwanegu unrhyw badin at y maint cyffredinol, ni waeth a oes gan y cynllun a ddychwelwyd aliniad gwahanol.
    /// Mewn geiriau eraill, os oes gan `K` faint 16, bydd `K.align_to(32)` * yn dal i fod â maint 16.
    ///
    /// Yn dychwelyd gwall os yw'r cyfuniad o `self.size()` a'r `align` a roddir yn torri'r amodau a restrir yn [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Yn dychwelyd faint o badin y mae'n rhaid i ni ei fewnosod ar ôl `self` i sicrhau y bydd y cyfeiriad canlynol yn bodloni `align` (wedi'i fesur mewn beit).
    ///
    /// ee, os `self.size()` yn 9, yna `self.padding_needed_for(4)` yn dychwelyd 3, oherwydd dyna yw'r nifer lleiaf o bytes o padin ei angen i gael gyfeiriad 4-alinio (gan dybio bod y cyfatebol dechrau bloc cof mewn cyfeiriad 4-alinio).
    ///
    ///
    /// Nid oes ystyr i werth dychwelyd y swyddogaeth hon os nad yw `align` yn bŵer dau.
    ///
    /// Sylwch fod defnyddioldeb y gwerth a ddychwelwyd yn ei gwneud yn ofynnol i `align` fod yn llai na neu'n hafal i aliniad y cyfeiriad cychwynnol ar gyfer y bloc cof cyfan a ddyrannwyd.Un ffordd i fodloni'r cyfyngiad hwn yw sicrhau `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // gwerth i fyny Rounded yw:
        //   len_rounded_up=(len + alinio, 1)&! (alinio, 1);
        // ac yna dychwelwn y gwahaniaeth padin: `len_rounded_up - len`.
        //
        // Rydym yn defnyddio rhifyddeg modiwlaidd gydol:
        //
        // 1. mae alinio yn sicr o fod yn> 0, felly mae alinio, 1 bob amser yn ddilys.
        //
        // 2.
        // `len + align - 1` yn gallu gorlifo erbyn `align - 1` ar y mwyaf, felly bydd yr&-mask gyda `!(align - 1)` yn sicrhau y bydd `len_rounded_up` ei hun yn 0 yn achos gorlifo.
        //
        //    Felly mae'r padin a ddychwelwyd, o'i ychwanegu at `len`, yn cynhyrchu 0, sy'n bodloni'r aliniad `align` yn ddibwys.
        //
        // (Wrth gwrs, dylai ymdrechion i ddyrannu blociau o gof y dylai eu maint a'u padin orlifo yn y modd uchod beri i'r dyrannwr esgor ar wall beth bynnag.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Creu cynllun drwy dalgrynnu maint y cynllun hwn hyd at lluosrif o aliniad y cynllun yn.
    ///
    ///
    /// Mae hyn yn cyfateb i ychwanegu canlyniad `padding_needed_for` at faint cyfredol y cynllun.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Ni all hyn orlifo.Gan ddyfynnu o ddigyfnewid o Layout:
        // > `size`, wrth ei dalgrynnu i'r lluosrif agosaf o `align`,
        // > rhaid iddo beidio â gorlifo (h.y., rhaid i'r gwerth crwn fod yn llai na
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Yn creu cynllun sy'n disgrifio'r cofnod ar gyfer enghreifftiau `n` o `self`, gyda swm addas o badin rhwng pob un i sicrhau bod pob achos yn cael ei faint a'i aliniad y gofynnir amdano.
    /// Ar lwyddiant, yn dychwelyd `(k, offs)` lle `k` yn y cynllun y llu a `offs` yw'r pellter rhwng ddechrau pob elfen yn y rhesi.
    ///
    /// Ar gorlif rhifyddeg, yn dychwelyd `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Ni all hyn orlifo.Gan ddyfynnu o ddigyfnewid o Layout:
        // > `size`, wrth ei dalgrynnu i'r lluosrif agosaf o `align`,
        // > rhaid iddo beidio â gorlifo (h.y., rhaid i'r gwerth crwn fod yn llai na
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // DIOGELWCH: Gwyddys eisoes fod self.align yn ddilys ac mae alloc_size wedi bod
        // padio yn barod.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Yn creu cynllun sy'n disgrifio'r cofnod ar gyfer `self` ac yna `next`, gan gynnwys unrhyw badin angenrheidiol i sicrhau y bydd `next` wedi'i alinio'n iawn, ond *dim padin llusgo*.
    ///
    /// Er mwyn cyd-fynd â gosodiad cynrychiolaeth C `repr(C)`, dylech ffonio `pad_to_align` ar ôl ymestyn y cynllun gyda'r holl feysydd.
    /// (Nid oes unrhyw ffordd i gyd-fynd 'r ball cynrychiolaeth Rust gosodiad `repr(Rust)`, as it is unspecified.)
    ///
    /// Sylwch mai aliniad y cynllun canlyniadol fydd yr uchafswm o rai `self` a `next`, er mwyn sicrhau aliniad y ddwy ran.
    ///
    /// Yn dychwelyd `Ok((k, offset))`, lle mae `k` yn gynllun y cofnod cydgysylltiedig ac `offset` yw'r lleoliad cymharol, mewn beitiau, ar ddechrau'r `next` sydd wedi'i fewnosod yn y cofnod cydgysylltiedig (gan dybio bod y cofnod ei hun yn dechrau ar wrthbwyso 0).
    ///
    ///
    /// Ar gorlif rhifyddeg, yn dychwelyd `LayoutError`.
    ///
    /// # Examples
    ///
    /// I gyfrifo cynllun strwythur `#[repr(C)]` a gwrthbwyso y caeau o gynlluniau ei meysydd ':
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Cofiwch gwblhau gyda `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // prawf ei fod yn gweithio
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Yn creu cynllun sy'n disgrifio'r cofnod ar gyfer enghreifftiau `n` o `self`, heb unrhyw badin rhwng pob achos.
    ///
    /// Sylwch, yn wahanol i `repeat`, nid yw `repeat_packed` yn gwarantu y bydd yr achosion ailadroddus o `self` wedi'u halinio'n iawn, hyd yn oed os yw enghraifft benodol o `self` wedi'i halinio'n iawn.
    /// Hynny yw, os defnyddir y cynllun a ddychwelir gan `repeat_packed` i ddyrannu arae, ni warantir y bydd yr holl elfennau yn yr arae wedi'u halinio'n iawn.
    ///
    /// Ar gorlif rhifyddeg, yn dychwelyd `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Yn creu cynllun sy'n disgrifio'r cofnod ar gyfer `self` ac yna `next` heb unrhyw badin ychwanegol rhwng y ddau.
    /// Gan nad oes padin yn cael ei fewnosod, mae aliniad `next` yn amherthnasol, ac nid yw wedi'i ymgorffori *o gwbl* yn y cynllun sy'n deillio o hynny.
    ///
    ///
    /// Ar gorlif rhifyddeg, yn dychwelyd `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Creu cynllun disgrifio'r record am `[T; n]`.
    ///
    /// Ar gorlif rhifyddeg, yn dychwelyd `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Nid yw'r paramedrau a roddir i `Layout::from_size_align` neu ryw adeiladwr `Layout` arall yn bodloni ei gyfyngiadau dogfenedig.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (mae angen hwn arnom ar gyfer impl i lawr yr afon o Gwall trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}