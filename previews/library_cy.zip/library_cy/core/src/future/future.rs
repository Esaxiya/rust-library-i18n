#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A future cynrychioli gyfrifiannu asynchronous.
///
/// A future yn werth nad ydynt efallai wedi gorffen cyfrifiadurol eto.
/// Mae'r math hwn o "asynchronous value" yn ei gwneud hi'n bosibl i edau barhau i wneud gwaith defnyddiol wrth iddo aros i'r gwerth ddod ar gael.
///
///
/// # Mae'r dull `poll`
///
/// Mae'r dull craidd future, `poll`, ymdrechion * * i ddatrys y future i mewn i werth terfynol.
/// Nid yw'r dull hwn yn bloc os nad yw'r gwerth yn barod.
/// Yn lle hynny, mae'r dasg gyfredol wedi ei raglennu i gael ei ddeffro pan fydd hi'n bosib i wneud cynnydd pellach gan `poll`ing eto.
/// Trosglwyddodd y `context` i'r dull `poll` yn gallu darparu [`Waker`], sy'n handlen i deffro y dasg gyfredol.
///
/// Wrth ddefnyddio future, yn gyffredinol ni fyddwch yn galw `poll` yn uniongyrchol, ond yn lle `.await` y gwerth.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Mae'r math o werth a gynhyrchir wrth gwblhau.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Ceisio datrys y future i werth terfynol, cofrestru dasg presennol ar gyfer wakeup os nad oedd gwerth ar gael eto.
    ///
    /// # Gwerth dychwelyd
    ///
    /// Mae'r swyddogaeth hon yn dychwelyd:
    ///
    /// - [`Poll::Pending`] os nad yw'r future yn barod eto
    /// - [`Poll::Ready(val)`] gyda'r canlyniad `val` y future hwn os yw'n gorffen yn llwyddiannus.
    ///
    /// Unwaith y bydd future wedi gorffen, ni ddylai cleientiaid `poll` eto.
    ///
    /// Pan nad yw future yn barod eto, `poll` yn dychwelyd `Poll::Pending` a storfeydd clôn o'r [`Waker`] gopïo o'r [`Context`] cyfredol.
    /// yna mae hyn [`Waker`] yn deffro unwaith y bydd y future wneud cynnydd.
    /// Er enghraifft, byddai future sy'n aros i soced ddod yn ddarllenadwy yn galw `.clone()` ar yr [`Waker`] a'i storio.
    /// Pan fydd signal yn cyrraedd mewn mannau eraill yn nodi bod y soced yn ddarllenadwy, a elwir [`Waker::wake`] a'r soced dasg future yn cael ei deffro.
    /// Unwaith y dasg wedi ei ddeffro, dylai geisio `poll` y future eto, a allai neu na allai gynhyrchu gwerth terfynol.
    ///
    /// Dylai Nodwch fod ar alwadau lluosog i `poll`, dim ond y [`Waker`] o'r [`Context`] trosglwyddo i'r alwad ddiweddaraf yn cael ei drefnu i dderbyn wakeup.
    ///
    /// # nodweddion Rhedeg
    ///
    /// Futures unig yn anadweithiol * *;rhaid iddynt fod yn *weithredol*`poll`ed i wneud cynnydd, sy'n golygu bod pob tro y dasg bresennol yn deffro i fyny, dylai weithredol ail-`poll` nes futures ei fod yn dal â diddordeb mewn.
    ///
    /// Nid oes enw ar y swyddogaeth `poll` dro ar ôl tro mewn cylch tynn-yn lle hynny, dylai fod dim ond cael eu galw pan fydd y future yn nodi ei fod yn barod i wneud cynnydd (drwy ffonio `wake()`).
    /// Os ydych yn gyfarwydd â'r `poll(2)` neu'r `select(2)` syscalls ar Unix ei yn werth nodi bod futures fel arfer yn ei wneud * * Nid yw yn dioddef yr un problemau o "all wakeups must poll all events";maent yn fwy tebyg i `epoll(4)`.
    ///
    /// Dylai gweithredu'r `poll` yn ymdrechu i ddychwelyd yn gyflym, ac ni ddylai bloc.Mae dychwelyd yn gyflym yn atal edafedd neu ddolenni digwyddiadau yn ddiangen.
    /// Os yw'n hysbys ymlaen llaw y gall galwad i `poll` yn y pen draw yn cymryd ennyd, dylai'r gwaith gael ei dadlwytho i gronfa edau (neu rywbeth tebyg) i sicrhau y gall `poll` yn dychwelyd yn gyflym.
    ///
    /// # Panics
    ///
    /// Unwaith y bydd wedi cwblhau future (dychwelyd `Ready` o `poll`), yn galw ei ddull `poll` eto gall panic, bloc am byth, neu achos mathau eraill o broblemau;y `Future` trait yn gosod unrhyw ofynion ar effeithiau galwad o'r fath.
    /// Fodd bynnag, gan nad yw'r dull `poll` wedi'i farcio `unsafe`, mae rheolau arferol Rust yn berthnasol: rhaid i alwadau byth achosi ymddygiad heb ei ddiffinio (llygredd cof, defnydd anghywir o swyddogaethau `unsafe`, neu debyg), waeth beth yw cyflwr future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}