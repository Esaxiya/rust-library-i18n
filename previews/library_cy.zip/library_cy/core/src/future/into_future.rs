use crate::future::Future;

/// Trosi i mewn i `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Yr allbwn y bydd y future yn ei gynhyrchu ar ôl ei gwblhau.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Pa fath o future rydym yn troi i mewn i hyn?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Creu future o werth.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}