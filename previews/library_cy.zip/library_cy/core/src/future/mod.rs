#![stable(feature = "futures_api", since = "1.36.0")]

//! gwerthoedd asynchronous.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Mae angen y math oherwydd:
///
/// a) Ni all generaduron weithredu `for<'a, 'b> Generator<&'a mut Context<'b>>`, felly mae angen i ni basio pwyntydd amrwd (gweler <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Nid yw awgrymiadau crai a `NonNull` yn `Send` neu `Sync`, felly byddai hynny'n gwneud pob un future non-Send/Sync yn ogystal, ac nid ydym am hynny.
///
/// Mae hefyd yn symleiddio'r gostyngiad HIR o `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Lapiwch generadur mewn future.
///
/// Mae'r swyddogaeth hon yn dychwelyd oddi tano `GenFuture`, ond crwyn yn `impl Trait` i roi gwell negeseuon gwall (`impl Future` yn hytrach na `GenFuture<[closure.....]>`).
///
// Dyma `const` i osgoi gwallau ychwanegol ar ôl i ni wella ar ôl `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Rydym yn dibynnu ar y ffaith bod async/await futures yn na ellir ei symud er mwyn creu Borrows hunan-cyfeiriadol yn y generadur sylfaenol.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // DIOGELWCH: Safe oherwydd ein bod yn !Unpin + !Drop, ac mae hyn yn unig yw amcanestyniad cae.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Ail-gychwynwch y generadur, gan droi'r `&mut Context` yn bwyntydd amrwd `NonNull`.
            // Bydd y gostyngiad `.await` yn bwrw hynny'n ôl i `&mut Context` yn ddiogel.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // DIOGELWCH: y warant rhaid galwr bod `cx.0` yn pwyntydd dilys
    // sy'n cyflawni'r holl ofynion ar gyfer cyfeirnod symudol.
    unsafe { &mut *cx.0.as_ptr().cast() }
}