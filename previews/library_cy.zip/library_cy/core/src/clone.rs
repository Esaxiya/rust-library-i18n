//! Yr `Clone` trait ar gyfer mathau na ellir eu 'copïo'n ymhlyg'.
//!
//! Yn Rust, rhai mathau syml yw "implicitly copyable" a phan fyddwch chi'n eu haseinio neu'n eu pasio fel dadleuon, bydd y derbynnydd yn cael copi, gan adael y gwerth gwreiddiol yn ei le.
//! Nid oes angen dyraniad ar y mathau hyn i gopïo ac nid oes ganddynt derfynwyr (hy, nid ydynt yn cynnwys blychau dan berchnogaeth nac yn gweithredu [`Drop`]), felly mae'r casglwr yn eu hystyried yn rhad ac yn ddiogel i'w copïo.
//!
//! Ar gyfer mathau eraill rhaid gwneud copïau yn benodol, trwy gonfensiwn sy'n gweithredu'r [`Clone`] trait a galw'r dull [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Enghraifft o ddefnydd sylfaenol:
//!
//! ```
//! let s = String::new(); // offer math Llinynnol Clone
//! let copy = s.clone(); // felly gallwn ei glonio
//! ```
//!
//! I weithredu yn hawdd y Clonio trait, gallwch hefyd ddefnyddio `#[derive(Clone)]`.enghraifft:
//!
//! ```
//! #[derive(Clone)] // rydym yn ychwanegu y Clone trait i Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ac erbyn hyn gallwn chlôn y peth!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Mae comin trait am y gallu i ddyblygu benodol gwrthrych.
///
/// Yn wahanol i [`Copy`] yn yr ystyr bod [`Copy`] yn ymhlyg ac yn rhad iawn, tra bod `Clone` bob amser yn eglur ac efallai na fydd yn ddrud.
/// Er mwyn gorfodi'r nodweddion hyn, nid yw Rust yn caniatáu i chi reimplement [`Copy`], ond efallai y byddwch yn reimplement `Clone` a rhedeg cod mympwyol.
///
/// Gan `Clone` yn fwy cyffredinol nag [`Copy`], gallwch wneud yn awtomatig unrhyw beth [`Copy`] yn `Clone` yn ogystal.
///
/// ## Derivable
///
/// Gellir defnyddio'r trait hwn gyda `#[derive]` os yw'r holl feysydd yn `Clone`.Mae gweithredu 'deillio' [`Clone`] yn galw [`clone`] ar bob maes.
///
/// [`clone`]: Clone::clone
///
/// Am struct generig, `#[derive]` yn gweithredu `Clone` amodol gan ychwanegu `Clone` rhwymo ar baramedrau generig.
///
/// ```
/// // `derive` yn gweithredu Clôn ar gyfer Darllen<T>pan mae T yn Clôn.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Sut alla i weithredu `Clone`?
///
/// Dylai Mathau sy'n [`Copy`] yn cael gweithredu dibwys o `Clone`.Yn fwy ffurfiol:
/// os `T: Copy`, `x: T`, ac `y: &T`, yna `let x = y.clone();` yn cyfateb i `let x = *y;`.
/// Dylai gweithrediadau â llaw fod yn ofalus i gynnal yr invariant hwn;Fodd bynnag, ni ddylai cod anniogel yn dibynnu arno i sicrhau diogelwch y cof.
///
/// Un enghraifft yw struct generig dal pwyntydd swyddogaeth.Yn yr achos hwn, ni all y gwaith o weithredu'r `Clone` yn `derive`d, ond gellir eu gweithredu fel a ganlyn:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## implementors ychwanegol
///
/// Yn ogystal â'r [implementors listed below][impls], mae'r mathau canlynol hefyd yn gweithredu `Clone`:
///
/// * Mathau o eitemau swyddogaeth (hy, y mathau penodol a ddiffinnir ar gyfer pob swyddogaeth)
/// * Mathau pwyntydd swyddogaeth (ee, `fn() -> i32`)
/// * Mathau arae, ar gyfer pob maint, os yw'r math o eitem hefyd yn gweithredu `Clone` (ee, `[i32; 123456]`)
/// * mathau tuple, os pob cydran hefyd yn gweithredu `Clone` (ee, `()`, `(i32, bool)`)
/// * mathau cau, os ydynt yn dal unrhyw werth gan yr amgylchedd neu os yw'r holl werthoedd dal o'r fath yn gweithredu `Clone` eu hunain.
///   Sylwch fod newidynnau sy'n cael eu dal trwy gyfeirnod a rennir bob amser yn gweithredu `Clone` (hyd yn oed os nad yw'r canolwr yn gwneud hynny), tra bod newidynnau sy'n cael eu dal trwy gyfeirnod symudol byth yn gweithredu `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Dychwelyd copi o werth.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str yn gweithredu Clôn
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Yn perfformio copi-aseiniad o `source`.
    ///
    /// `a.clone_from(&b)` yn cyfateb i `a = b.clone()` mewn functionality, ond gellir eu diystyru i ailddefnyddio adnoddau `a` i osgoi dyraniadau diangen.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Deillio macro sy'n cynhyrchu impl o'r trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): structs hyn yn cael eu defnyddio yn unig gan#[Deillio] i fynnu bod pob cydran o offer fath clôn neu Copi.
//
//
// Ni ddylai'r strwythurau hyn byth ymddangos mewn cod defnyddiwr.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Gweithrediadau o `Clone` gyfer mathau cyntefig.
///
/// Gweithredir gweithrediadau na ellir eu disgrifio yn Rust yn `traits::SelectionContext::copy_clone_conditions()` yn `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Gellir clonio cyfeiriadau a rennir, ond ni all cyfeiriadau treiddgar *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Gellir clonio cyfeiriadau a rennir, ond ni all cyfeiriadau treiddgar *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}