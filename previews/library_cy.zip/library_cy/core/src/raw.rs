#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Yn cynnwys diffiniadau strwythuredig ar gyfer cynllun mathau adeiledig crynhowr.
//!
//! Gellir eu defnyddio fel targedau trawsosod mewn cod anniogel ar gyfer trin y sylwadau amrwd yn uniongyrchol.
//!
//!
//! Dylai eu diffiniad bob amser gyd-fynd â'r ABI a ddiffinnir yn `rustc_middle::ty::layout`.
//!

/// Cynrychiolaeth gwrthrych trait fel `&dyn SomeTrait`.
///
/// Mae gan y strwythur hwn yr un cynllun â mathau fel `&dyn SomeTrait` a `Box<dyn AnotherTrait>`.
///
/// `TraitObject` yn sicr o gyd-fynd â chynlluniau, ond nid dyma'r math o wrthrychau trait (ee, nid yw'r caeau yn uniongyrchol hygyrch ar `&dyn SomeTrait`) ac nid yw'n rheoli'r cynllun hwnnw (ni fydd newid y diffiniad yn newid cynllun `&dyn SomeTrait`).
///
/// Fe'i cynlluniwyd i'w ddefnyddio gan god anniogel yn unig y mae angen iddo drin y manylion lefel isel.
///
/// Nid oes unrhyw ffordd i gyfeirio at yr holl wrthrychau trait yn gyffredinol, felly yr unig ffordd i greu gwerthoedd o'r math hwn yw gyda swyddogaethau fel [`std::mem::transmute`][transmute].
/// Yn yr un modd, yr unig ffordd i greu gwir trait gwrthrych o werth `TraitObject` gyda `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Mae syntheseiddio gwrthrych trait â mathau heb ei gyfateb-un lle nad yw'r hyfyw yn cyfateb i'r math o werth y mae'r pwyntydd data yn pwyntio ato-yn debygol iawn o arwain at ymddygiad heb ei ddiffinio.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // enghraifft trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // gadewch i'r casglwr wneud gwrthrych trait
/// let object: &dyn Foo = &value;
///
/// // edrychwch ar y gynrychiolaeth amrwd
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // y pwyntydd data yw cyfeiriad `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // lluniwch wrthrych newydd, gan bwyntio at `i32` gwahanol, gan fod yn ofalus i ddefnyddio'r hyfyw `i32` o `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // dylai weithio yn union fel pe baem wedi adeiladu gwrthrych trait allan o `other_value` yn uniongyrchol
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}