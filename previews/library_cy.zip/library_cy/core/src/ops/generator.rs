use crate::marker::Unpin;
use crate::pin::Pin;

/// Canlyniad ailddechrau generadur.
///
/// Dychwelir yr enwm hwn o'r dull `Generator::resume` ac mae'n nodi gwerthoedd dychwelyd posibl generadur.
/// Ar hyn o bryd mae hyn yn cyfateb i naill ai pwynt atal (`Yielded`) neu bwynt terfynu (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Ataliwyd y generadur gyda gwerth.
    ///
    /// Mae'r wladwriaeth hon yn nodi bod generadur wedi'i atal, ac yn nodweddiadol mae'n cyfateb i ddatganiad `yield`.
    /// Mae'r gwerth a ddarperir yn yr amrywiad hwn yn cyfateb i'r mynegiad a basiwyd i `yield` ac yn caniatáu i eneraduron ddarparu gwerth bob tro y maent yn cynhyrchu.
    ///
    ///
    Yielded(Y),

    /// Cwblhaodd y generadur gyda gwerth dychwelyd.
    ///
    /// Mae'r wladwriaeth hon yn nodi bod generadur wedi gorffen gweithredu gyda'r gwerth a ddarperir.
    /// Ar ôl i generadur ddychwelyd `Complete` ystyrir ei fod yn wall rhaglennydd i ffonio `resume` eto.
    ///
    Complete(R),
}

/// Y trait a weithredir gan fathau o generaduron adeiledig.
///
/// Ar hyn o bryd mae generaduron, y cyfeirir atynt yn gyffredin fel coroutines, yn nodwedd iaith arbrofol yn Rust.
/// Ar hyn o bryd, bwriad generaduron [RFC 2033] wedi'u hychwanegu yw darparu bloc adeiladu ar gyfer cystrawen async/await yn bennaf ond byddant yn debygol o ymestyn i ddarparu diffiniad ergonomig ar gyfer ailadroddwyr a rhai cyntefig eraill.
///
///
/// Mae'r gystrawen a'r semanteg ar gyfer generaduron yn ansefydlog a bydd angen RFC pellach ar gyfer sefydlogi.Ar yr adeg hon, fodd bynnag, mae'r gystrawen yn debyg i gau:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Mae mwy o ddogfennaeth generaduron i'w gweld yn y llyfr ansefydlog.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Y math o werth y mae'r generadur hwn yn ei gynhyrchu.
    ///
    /// Mae'r math cysylltiedig hwn yn cyfateb i'r mynegiad `yield` a'r gwerthoedd y caniateir eu dychwelyd bob tro y mae generadur yn cynhyrchu.
    ///
    /// Er enghraifft, mae'n debygol y byddai gan ailadroddwr-fel-a-generadur y math hwn fel `T`, gyda'r math yn cael ei ailadrodd.
    ///
    type Yield;

    /// Y math o werth y mae'r generadur hwn yn ei ddychwelyd.
    ///
    /// Mae hyn yn cyfateb i'r math a ddychwelwyd o generadur naill ai gyda datganiad `return` neu'n ymhlyg fel mynegiad olaf llythrennol generadur.
    /// Er enghraifft, byddai futures yn defnyddio hwn fel `Result<T, E>` gan ei fod yn cynrychioli future wedi'i gwblhau.
    ///
    ///
    type Return;

    /// Ailddechrau gweithredu'r generadur hwn.
    ///
    /// Bydd y swyddogaeth hon yn ailddechrau gweithredu'r generadur neu'n dechrau ei weithredu os nad yw wedi gwneud hynny eisoes.
    /// Bydd yr alwad hon yn dychwelyd yn ôl i bwynt atal olaf y generadur, gan ailafael yn y dienyddiad o'r `yield` diweddaraf.
    /// Bydd y generadur yn parhau i weithredu nes ei fod naill ai'n cynhyrchu neu'n dychwelyd, ac ar yr adeg honno bydd y swyddogaeth hon yn dychwelyd.
    ///
    /// # Gwerth dychwelyd
    ///
    /// Mae'r enwm `GeneratorState` a ddychwelwyd o'r swyddogaeth hon yn nodi ym mha gyflwr mae'r generadur wrth ddychwelyd.
    /// Os dychwelir yr amrywiad `Yielded` yna mae'r generadur wedi cyrraedd pwynt atal ac mae gwerth wedi'i gynhyrchu.
    /// Mae generaduron yn y wladwriaeth hon ar gael i'w hailddechrau yn nes ymlaen.
    ///
    /// Os dychwelir `Complete` yna mae'r generadur wedi gorffen yn llwyr gyda'r gwerth a ddarperir.Mae'n annilys i'r generadur gael ei ailddechrau eto.
    ///
    /// # Panics
    ///
    /// Gall y swyddogaeth hon panic os caiff ei galw ar ôl i'r amrywiad `Complete` gael ei ddychwelyd o'r blaen.
    /// Er bod llythrennau generaduron yn yr iaith yn sicr o gael panic wrth ailddechrau ar ôl `Complete`, nid yw hyn wedi'i warantu ar gyfer holl weithrediadau'r `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}