/// Fersiwn gweithredwr yr alwad sy'n cymryd derbynnydd na ellir ei symud.
///
/// Gellir galw enghreifftiau o `Fn` dro ar ôl tro heb dreiglo cyflwr.
///
/// *Ni ddylid cymysgu'r trait (`Fn`) hwn â [function pointers] (`fn`).*
///
/// `Fn` yn cael ei weithredu'n awtomatig trwy gau sydd ddim ond yn cymryd cyfeiriadau na ellir eu symud at newidynnau sydd wedi'u dal neu nad ydyn nhw'n dal unrhyw beth o gwbl, yn ogystal â (safe) [function pointers] (gyda rhai cafeatau, gweler eu dogfennaeth am ragor o fanylion).
///
/// Yn ogystal, ar gyfer unrhyw fath `F` sy'n gweithredu `Fn`, mae `&F` yn gweithredu `Fn`, hefyd.
///
/// Gan fod [`FnMut`] a [`FnOnce`] yn supertraits o `Fn`, gellir defnyddio unrhyw enghraifft o `Fn` fel paramedr lle mae disgwyl [`FnMut`] neu [`FnOnce`].
///
/// Defnyddiwch `Fn` fel rhwymwr pan fyddwch chi eisiau derbyn paramedr o fath tebyg i swyddogaeth ac mae angen i chi ei alw dro ar ôl tro a heb dreiglo cyflwr (ee, wrth ei alw ar yr un pryd).
/// Os nad oes angen gofynion mor gaeth arnoch chi, defnyddiwch [`FnMut`] neu [`FnOnce`] fel ffiniau.
///
/// Gweler yr [chapter on closures in *The Rust Programming Language*][book] i gael mwy o wybodaeth am y pwnc hwn.
///
/// Hefyd i'w nodi yw'r gystrawen arbennig ar gyfer `Fn` traits (ee
/// `Fn(usize, bool) -> usize`).Gall y rhai sydd â diddordeb ym manylion technegol hyn gyfeirio at [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Galw cau
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Gan ddefnyddio paramedr `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // fel y gall regex ddibynnu ar `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Yn cyflawni'r gweithrediad galwadau.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Fersiwn gweithredwr yr alwad sy'n cymryd derbynnydd symudol.
///
/// Gellir galw enghreifftiau o `FnMut` dro ar ôl tro a gallant dreiglo cyflwr.
///
/// `FnMut` yn cael ei weithredu'n awtomatig trwy gau sy'n cymryd cyfeiriadau symudol at newidynnau sydd wedi'u dal, yn ogystal â phob math sy'n gweithredu [`Fn`], ee, (safe) [function pointers] (gan fod `FnMut` yn oruchafiaeth o [`Fn`]).
/// Yn ogystal, ar gyfer unrhyw fath `F` sy'n gweithredu `FnMut`, mae `&mut F` yn gweithredu `FnMut`, hefyd.
///
/// Gan fod [`FnOnce`] yn oruchafiaeth o `FnMut`, gellir defnyddio unrhyw enghraifft o `FnMut` lle mae disgwyl [`FnOnce`], a chan fod [`Fn`] yn is-nodwedd o `FnMut`, gellir defnyddio unrhyw enghraifft o [`Fn`] lle mae disgwyl `FnMut`.
///
/// Defnyddiwch `FnMut` fel rhwymwr pan fyddwch chi am dderbyn paramedr o fath tebyg i swyddogaeth ac mae angen i chi ei alw dro ar ôl tro, wrth ganiatáu iddo dreiglo cyflwr.
/// Os nad ydych chi am i'r paramedr dreiglo cyflwr, defnyddiwch [`Fn`] fel rhwymwr;os nad oes angen i chi ei alw dro ar ôl tro, defnyddiwch [`FnOnce`].
///
/// Gweler yr [chapter on closures in *The Rust Programming Language*][book] i gael mwy o wybodaeth am y pwnc hwn.
///
/// Hefyd i'w nodi yw'r gystrawen arbennig ar gyfer `Fn` traits (ee
/// `Fn(usize, bool) -> usize`).Gall y rhai sydd â diddordeb ym manylion technegol hyn gyfeirio at [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Galw cau ar y cyd
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Gan ddefnyddio paramedr `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // fel y gall regex ddibynnu ar `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Yn cyflawni'r gweithrediad galwadau.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Fersiwn gweithredwr yr alwad sy'n cymryd derbynnydd is-werth.
///
/// Gellir galw enghreifftiau o `FnOnce`, ond efallai na fydd modd eu galw sawl gwaith.Oherwydd hyn, os mai'r unig beth sy'n hysbys am fath yw ei fod yn gweithredu `FnOnce`, dim ond unwaith y gellir ei alw.
///
/// `FnOnce` yn cael ei weithredu'n awtomatig trwy gau a allai ddefnyddio newidynnau wedi'u dal, yn ogystal â phob math sy'n gweithredu [`FnMut`], ee, (safe) [function pointers] (gan fod `FnOnce` yn oruchafiaeth o [`FnMut`]).
///
///
/// Gan fod [`Fn`] a [`FnMut`] yn is-draciau `FnOnce`, gellir defnyddio unrhyw enghraifft o [`Fn`] neu [`FnMut`] lle mae disgwyl `FnOnce`.
///
/// Defnyddiwch `FnOnce` fel rhwymwr pan fyddwch chi am dderbyn paramedr o fath tebyg i swyddogaeth a dim ond unwaith y mae angen i chi ei alw.
/// Os oes angen i chi ffonio'r paramedr dro ar ôl tro, defnyddiwch [`FnMut`] fel rhwymiad;os oes ei angen arnoch hefyd i beidio â threiglo cyflwr, defnyddiwch [`Fn`].
///
/// Gweler yr [chapter on closures in *The Rust Programming Language*][book] i gael mwy o wybodaeth am y pwnc hwn.
///
/// Hefyd i'w nodi yw'r gystrawen arbennig ar gyfer `Fn` traits (ee
/// `Fn(usize, bool) -> usize`).Gall y rhai sydd â diddordeb ym manylion technegol hyn gyfeirio at [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Gan ddefnyddio paramedr `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` yn defnyddio ei newidynnau wedi'u dal, felly ni ellir ei redeg fwy nag unwaith.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Bydd ceisio galw `func()` eto yn taflu gwall `use of moved value` ar gyfer `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ni ellir ei alw ar y pwynt hwn mwyach
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // fel y gall regex ddibynnu ar `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Y math a ddychwelwyd ar ôl defnyddio'r gweithredwr galwadau.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Yn cyflawni'r gweithrediad galwadau.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}