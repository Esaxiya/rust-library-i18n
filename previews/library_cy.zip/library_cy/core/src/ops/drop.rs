/// Cod arfer o fewn y dinistriwr.
///
/// Pan nad oes angen gwerth mwyach, bydd Rust yn rhedeg "destructor" ar y gwerth hwnnw.
/// Y ffordd fwyaf cyffredin nad oes angen gwerth mwyach yw pan fydd yn mynd allan o'i gwmpas.Efallai y bydd dinistrwyr yn dal i redeg mewn amgylchiadau eraill, ond rydyn ni'n mynd i ganolbwyntio ar gwmpas yr enghreifftiau yma.
/// I ddysgu am rai o'r achosion eraill hynny, gweler adran [the reference] ar ddinistrwyr.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Mae'r dinistriwr hwn yn cynnwys dwy gydran:
/// - Galwad i `Drop::drop` am y gwerth hwnnw, os gweithredir yr `Drop` trait arbennig hwn ar gyfer ei fath.
/// - Mae'r "drop glue" a gynhyrchir yn awtomatig sy'n galw dro ar ôl tro yn dinistrio holl feysydd y gwerth hwn.
///
/// Gan fod Rust yn galw dinistrwyr yr holl feysydd a gynhwysir yn awtomatig, nid oes rhaid i chi weithredu `Drop` yn y rhan fwyaf o achosion.
/// Ond mae rhai achosion lle mae'n ddefnyddiol, er enghraifft ar gyfer mathau sy'n rheoli adnodd yn uniongyrchol.
/// Efallai bod yr adnodd hwnnw'n gof, gall fod yn ddisgrifydd ffeiliau, gall fod yn soced rhwydwaith.
/// Unwaith na fydd gwerth o'r math hwnnw'n mynd i gael ei ddefnyddio mwyach, dylai "clean up" ei adnodd trwy ryddhau'r cof neu gau'r ffeil neu'r soced.
/// Swydd dinistriwr yw hon, ac felly swydd `Drop::drop`.
///
/// ## Examples
///
/// I weld dinistrwyr ar waith, gadewch i ni edrych ar y rhaglen ganlynol:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Yn gyntaf, bydd Rust yn galw `Drop::drop` ar gyfer `_x` ac yna ar gyfer `_x.one` a `_x.two`, sy'n golygu y bydd rhedeg hwn yn argraffu
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Hyd yn oed os ydym yn dileu gweithrediad `Drop` ar gyfer `HasTwoDrop`, gelwir dinistrwyr ei feysydd o hyd.
/// Byddai hyn yn arwain at
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Ni allwch ffonio `Drop::drop` eich hun
///
/// Oherwydd bod `Drop::drop` yn cael ei ddefnyddio i lanhau gwerth, gallai fod yn beryglus defnyddio'r gwerth hwn ar ôl i'r dull gael ei alw.
/// Gan nad yw `Drop::drop` yn cymryd perchnogaeth o'i fewnbwn, mae Rust yn atal camddefnydd trwy beidio â chaniatáu i chi ffonio `Drop::drop` yn uniongyrchol.
///
/// Hynny yw, pe byddech chi'n ceisio ffonio `Drop::drop` yn benodol yn yr enghraifft uchod, byddech chi'n cael gwall casglwr.
///
/// Os hoffech chi alw dinistriwr gwerth yn benodol, gellir defnyddio [`mem::drop`] yn lle.
///
/// [`mem::drop`]: drop
///
/// ## Gorchymyn gollwng
///
/// Pa un o'n dau `HasDrop` sy'n disgyn gyntaf, serch hynny?Ar gyfer strwythurau, yr un drefn ag y maent yn cael eu datgan: yn gyntaf `one`, yna `two`.
/// Os hoffech chi roi cynnig ar hyn eich hun, gallwch addasu `HasDrop` uchod i gynnwys rhywfaint o ddata, fel cyfanrif, ac yna ei ddefnyddio yn yr `println!` y tu mewn i `Drop`.
/// Mae'r ymddygiad hwn wedi'i warantu gan yr iaith.
///
/// Yn wahanol i strwythurau, mae newidynnau lleol yn cael eu gollwng yn ôl trefn:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Bydd hwn yn argraffu
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Gweler [the reference] am y rheolau llawn.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` ac `Drop` yn unigryw
///
/// Ni allwch weithredu [`Copy`] a `Drop` ar yr un math.Mae mathau sy'n `Copy` yn cael eu dyblygu'n ymhlyg gan y casglwr, gan ei gwneud hi'n anodd iawn rhagweld pryd, a pha mor aml y bydd dinistrwyr yn cael eu gweithredu.
///
/// O'r herwydd, ni all y mathau hyn fod â dinistrwyr.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Yn cyflawni'r dinistriwr ar gyfer y math hwn.
    ///
    /// Gelwir y dull hwn yn ymhlyg pan fydd y gwerth yn mynd allan o'i gwmpas, ac ni ellir ei alw'n benodol (gwall casglwr [E0040] yw hwn).
    /// Fodd bynnag, gellir defnyddio'r swyddogaeth [`mem::drop`] yn y prelude i alw gweithrediad `Drop` y ddadl.
    ///
    /// Pan alwyd y dull hwn, nid yw `self` wedi'i ddeall eto.
    /// Dim ond ar ôl i'r dull ddod i ben y bydd hynny'n digwydd.
    /// Pe na bai hyn yn wir, byddai `self` yn gyfeirnod hongian.
    ///
    /// # Panics
    ///
    /// O ystyried y bydd [`panic!`] yn galw `drop` wrth iddo ddadflino, bydd unrhyw [`panic!`] mewn gweithrediad `drop` yn debygol o erthylu.
    ///
    /// Sylwch, hyd yn oed os yw'r panics hwn, ystyrir bod y gwerth yn cael ei ostwng;
    /// rhaid i chi beidio ag achosi i `drop` gael ei alw eto.
    /// Fel rheol, caiff hyn ei drin yn awtomatig gan y casglwr, ond wrth ddefnyddio cod anniogel, gall ddigwydd yn anfwriadol weithiau, yn enwedig wrth ddefnyddio [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}