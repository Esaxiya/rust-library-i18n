/// trait ar gyfer addasu ymddygiad gweithredwr `?`.
///
/// Math sy'n gweithredu `Try` yw un sydd â ffordd ganonaidd i'w weld o ran deuoliaeth success/failure.
/// Mae'r trait hwn yn caniatáu echdynnu'r gwerthoedd llwyddiant neu fethiant hynny o enghraifft bresennol a chreu enghraifft newydd o werth llwyddiant neu fethiant.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Y math o'r gwerth hwn pan ystyrir ei fod yn llwyddiannus.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Y math o'r gwerth hwn pan ystyrir ei fod wedi methu.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Yn cymhwyso gweithredwr "?".Mae dychweliad `Ok(t)` yn golygu y dylai'r dienyddiad barhau fel arfer, a chanlyniad `?` yw'r gwerth `t`.
    /// Mae dychweliad `Err(e)` yn golygu y dylai dienyddiad branch i'r mwyaf mewnol sy'n amgáu `catch`, neu ddychwelyd o'r swyddogaeth.
    ///
    /// Os dychwelir canlyniad `Err(e)`, gwerth `e` fydd "wrapped" yn y math dychwelyd o'r cwmpas amgáu (y mae'n rhaid iddo ei hun weithredu `Try`).
    ///
    /// Yn benodol, dychwelir y gwerth `X::from_error(From::from(e))`, lle `X` yw math dychwelyd y swyddogaeth amgáu.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Lapiwch werth gwall i lunio'r canlyniad cyfansawdd.
    /// Er enghraifft, mae `Result::Err(x)` a `Result::from_error(x)` yn gyfwerth.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Lapiwch werth iawn i lunio'r canlyniad cyfansawdd.
    /// Er enghraifft, mae `Result::Ok(x)` a `Result::from_ok(x)` yn gyfwerth.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}