/// Fe'i defnyddir ar gyfer gweithrediadau dadreoleiddio na ellir eu symud, fel `*v`.
///
/// Yn ogystal â chael ei ddefnyddio ar gyfer gweithrediadau dadreoleiddio penodol gyda'r gweithredwr (unary) `*` mewn cyd-destunau na ellir eu symud, mae `Deref` hefyd yn cael ei ddefnyddio'n ymhlyg gan y casglwr mewn llawer o amgylchiadau.
/// Enw'r mecanwaith hwn yw ['`Deref` coercion'][more].
/// Mewn cyd-destunau symudol, defnyddir [`DerefMut`].
///
/// Mae gweithredu `Deref` ar gyfer awgrymiadau craff yn ei gwneud yn gyfleus cyrchu'r data y tu ôl iddynt, a dyna pam eu bod yn gweithredu `Deref`.
/// Ar y llaw arall, cynlluniwyd y rheolau ynghylch `Deref` a [`DerefMut`] yn benodol i ddarparu ar gyfer awgrymiadau craff.
/// Oherwydd hyn, dim ond ar gyfer awgrymiadau craff **y dylid gweithredu**`Deref` er mwyn osgoi dryswch.
///
/// Am resymau tebyg,**ni ddylai'r trait hwn fyth fethu**.Gall methiant yn ystod dad-gynadledda fod yn hynod ddryslyd pan fydd `Deref` yn cael ei alw'n ymhlyg.
///
/// # Mwy am orfodaeth `Deref`
///
/// Os yw `T` yn gweithredu `Deref<Target = U>`, a `x` yn werth math `T`, yna:
///
/// * Mewn cyd-destunau na ellir eu symud, mae `*x` (lle nad yw `T` yn gyfeirnod nac yn bwyntydd amrwd) yn cyfateb i `* Deref::deref(&x)`.
/// * Mae gwerthoedd math `&T` wedi'u gorfodi i werthoedd math `&U`
/// * `T` yn ymhlyg yn gweithredu holl ddulliau (immutable) o'r math `U`.
///
/// Am fwy o fanylion, ymwelwch â [the chapter in *The Rust Programming Language*][book] yn ogystal â'r adrannau cyfeirio ar [the dereference operator][ref-deref-op], [method resolution] a [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Strwythur gydag un cae sy'n hygyrch trwy ddad-gyfeirio'r strwythur.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Y math sy'n deillio o hyn ar ôl dadreoleiddio.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Yn gohirio'r gwerth.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Fe'i defnyddir ar gyfer gweithrediadau dad-gynadledda symudol, fel yn `*v = 1;`.
///
/// Yn ogystal â chael ei ddefnyddio ar gyfer gweithrediadau dadreoleiddio penodol gyda'r gweithredwr (unary) `*` mewn cyd-destunau symudol, mae `DerefMut` hefyd yn cael ei ddefnyddio'n ymhlyg gan y casglwr mewn sawl amgylchiad.
/// Enw'r mecanwaith hwn yw ['`Deref` coercion'][more].
/// Mewn cyd-destunau na ellir eu symud, defnyddir [`Deref`].
///
/// Mae gweithredu `DerefMut` ar gyfer awgrymiadau craff yn gwneud treiglo'r data y tu ôl iddynt yn gyfleus, a dyna pam eu bod yn gweithredu `DerefMut`.
/// Ar y llaw arall, cynlluniwyd y rheolau ynghylch [`Deref`] a `DerefMut` yn benodol i ddarparu ar gyfer awgrymiadau craff.
/// Oherwydd hyn, dim ond ar gyfer awgrymiadau craff **y dylid gweithredu**`DerefMut` er mwyn osgoi dryswch.
///
/// Am resymau tebyg,**ni ddylai'r trait hwn fyth fethu**.Gall methiant yn ystod dad-gynadledda fod yn hynod ddryslyd pan fydd `DerefMut` yn cael ei alw'n ymhlyg.
///
/// # Mwy am orfodaeth `Deref`
///
/// Os yw `T` yn gweithredu `DerefMut<Target = U>`, a `x` yn werth math `T`, yna:
///
/// * Mewn cyd-destunau symudol, mae `*x` (lle nad yw `T` yn gyfeirnod nac yn bwyntydd amrwd) yn cyfateb i `* DerefMut::deref_mut(&mut x)`.
/// * Mae gwerthoedd math `&mut T` wedi'u gorfodi i werthoedd math `&mut U`
/// * `T` yn ymhlyg yn gweithredu holl ddulliau (mutable) o'r math `U`.
///
/// Am fwy o fanylion, ymwelwch â [the chapter in *The Rust Programming Language*][book] yn ogystal â'r adrannau cyfeirio ar [the dereference operator][ref-deref-op], [method resolution] a [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Strwythur gydag un cae y gellir ei addasu trwy ddad-gyfeirio'r strwythur.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Yn dad-gyfeirio'r gwerth yn aml.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Yn nodi y gellir defnyddio strwythur fel derbynnydd dull, heb y nodwedd `arbitrary_self_types`.
///
/// Gweithredir hyn gan fathau pwyntydd stdlib fel `Box<T>`, `Rc<T>`, `&T`, a `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}