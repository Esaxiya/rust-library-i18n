use crate::marker::Unsize;

/// Trait sy'n nodi mai pwyntydd neu lapiwr ar gyfer un yw hwn, lle gellir perfformio anniddorol ar yr awgrym.
///
/// Gweler yr [DST coercion RFC][dst-coerce] a [the nomicon entry on coercion][nomicon-coerce] i gael mwy o fanylion.
///
/// Ar gyfer mathau pwyntydd adeiledig, bydd awgrymiadau i `T` yn gorfodi i awgrymiadau i `U` os `T: Unsize<U>` trwy drosi o bwyntydd tenau i bwyntydd braster.
///
/// Ar gyfer mathau penodol, mae'r orfodaeth yma'n gweithio trwy orfodi `Foo<T>` i `Foo<U>` ar yr amod bod impl o `CoerceUnsized<Foo<U>> for Foo<T>` yn bodoli.
/// Dim ond os oes gan `Foo<T>` un maes di-phantomdata sy'n cynnwys `T` yn unig y gellir ysgrifennu impl o'r fath.
/// Os mai math y maes hwnnw yw `Bar<T>`, rhaid gweithredu `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Bydd yr orfodaeth yn gweithio trwy orfodi'r maes `Bar<T>` i mewn i `Bar<U>` a llenwi gweddill y caeau o `Foo<T>` i greu `Foo<U>`.
/// Bydd hyn i bob pwrpas yn drilio i lawr i gae pwyntydd ac yn gorfodi hynny.
///
/// Yn gyffredinol, ar gyfer awgrymiadau craff byddwch yn gweithredu `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, gyda `?Sized` dewisol wedi'i rwymo ar `T` ei hun.
/// Ar gyfer mathau lapio sy'n gwreiddio `T` yn uniongyrchol fel `Cell<T>` a `RefCell<T>`, gallwch chi weithredu `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` yn uniongyrchol.
///
/// Bydd hyn yn gadael i orfodaethau o fathau fel `Cell<Box<T>>` weithio.
///
/// [`Unsize`][unsize] yn cael ei ddefnyddio i farcio mathau y gellir eu gorfodi i DSTs os ydynt y tu ôl i awgrymiadau.Fe'i gweithredir yn awtomatig gan y casglwr.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Defnyddir hwn ar gyfer diogelwch gwrthrychau, i wirio y gellir anfon math derbynnydd dull.
///
/// Enghraifft o weithredu'r trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}