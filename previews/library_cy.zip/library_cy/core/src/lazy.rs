//! Gwerthoedd diog a chychwyn data statig ar un adeg.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Mae cell y gellir eu hysgrifennu i unwaith yn unig.
///
/// Yn wahanol i `RefCell`, mae `OnceCell` yn unig yn darparu rhannu cyfeiriadau `&T` at ei werth.
/// Yn wahanol i `Cell`, nid oes angen copïo nac ailosod y gwerth ar `OnceCell` i gael mynediad iddo.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Ddigyfnewid: ysgrifennu at ar y mwyaf unwaith.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Yn creu cell wag newydd.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Gets y cyfeiriad at y gwerth sylfaenol.
    ///
    /// Dychwelyd `None` os yw'r gell yn wag.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // DIOGELWCH: Safe oherwydd `ddigyfnewid inner` yn
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Yn cael y cyfeiriad mutable at werth sylfaenol.
    ///
    /// Dychwelyd `None` os yw'r gell yn wag.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // DIOGELWCH: Safe oherwydd ein bod yn cael mynediad unigryw
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Setiau cynnwys y gell i `value`.
    ///
    /// # Errors
    ///
    /// Mae'r dull hwn yn dychwelyd `Ok(())` os oedd y gell yn wag ac `Err(value)` os oedd yn llawn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // DIOGELWCH: Safe oherwydd na allwn fod wedi gorgyffwrdd Borrows mutable
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // DIOGELWCH: Dyma'r unig fan lle rydym yn gosod y slot, dim rasys
        // oherwydd reentrancy/concurrency yn bosibl, ac rydym wedi gwirio bod slot ar hyn o bryd `None`, felly ysgrifennu hwn yn cynnal ddigyfnewid y `inner` yn.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Cael cynnwys y gell, gan ei gychwyn gyda `f` os oedd y gell yn wag.
    ///
    /// # Panics
    ///
    /// Os `f` panics, mae'r panic ei gyflwyno i'r sawl sy'n galw, a'r gell yn parhau i fod uninitialized.
    ///
    ///
    /// Gwall yw cychwyn y gell yn reentrant o `f`.Mae gwneud hynny'n arwain at panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Cael cynnwys y gell, gan ei gychwyn gyda `f` os oedd y gell yn wag.
    /// Os bydd y gell yn wag a `f` methu, gwall yn cael ei ddychwelyd.
    ///
    /// # Panics
    ///
    /// Os `f` panics, mae'r panic ei gyflwyno i'r sawl sy'n galw, a'r gell yn parhau i fod uninitialized.
    ///
    ///
    /// Gwall yw cychwyn y gell yn reentrant o `f`.Mae gwneud hynny'n arwain at panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Sylwer bod rhai ffurfiau * * o initialization reentrant allai arwain at UB (gweler prawf `reentrant_init`).
        // Yr wyf yn credu mai dim ond cael gwared `assert` hwn, tra'n cadw byddai `set/get` yn gadarn, ond mae'n ymddangos yn well i panic, yn hytrach nag i dawel ddefnyddio hen werth.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Yn defnyddio y gell, gan ddychwelyd y gwerth lapio.
    ///
    /// Dychwelyd `None` os oedd y gell yn wag.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Gan fod `into_inner` yn cymryd `self` yn ôl gwerth, mae'r casglwr llonydd cadarnhau nad yw'n cael ei benthyg ar hyn o bryd.
        // Felly, mae'n ddiogel i symud allan `Option<T>`.
        self.inner.into_inner()
    }

    /// Yn cymryd y gwerth y tu allan i `OnceCell` hwn, gan symud yn ôl i gyflwr uninitialized.
    ///
    /// Yn cael unrhyw effaith ac yn dychwelyd `None` os nad yw'r `OnceCell` wedi'i ymgychwyn.
    ///
    /// Gwarantir diogelwch trwy ofyn am gyfeirnod symudol.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Gwerth sy'n cael ei gychwyn ar y mynediad cyntaf.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   parod cychwynnol
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Creu gwerth diog newydd gyda'r swyddogaeth ymgychwyn roddir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Grymoedd y gwerthusiad hwn werth ddiog ac yn dychwelyd yn gyfeiriad at y canlyniad.
    ///
    ///
    /// Mae hyn yn cyfateb i'r impl `Deref`, ond mae'n eglur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Creu gwerth ddiog newydd gan ddefnyddio `Default` fel swyddogaeth ymgychwyn.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}