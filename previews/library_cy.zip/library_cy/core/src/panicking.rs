//! Cefnogaeth Panic ar gyfer libcore
//!
//! Ni all y llyfrgell graidd ddiffinio panicio, ond mae'n *datgan* panicio.
//! Mae hyn yn golygu bod y swyddogaethau y tu mewn i libcore yn cael eu caniatáu i panic, ond i fod yn ddefnyddiol rhaid i crate i fyny'r afon ddiffinio panicio er mwyn i libcore ei ddefnyddio.
//! Y rhyngwyneb cyfredol ar gyfer panicio yw:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Mae'r diffiniad hwn yn caniatáu mynd i banig gydag unrhyw neges gyffredinol, ond nid yw'n caniatáu methu â gwerth `Box<Any>`.
//! (Mae `PanicInfo` yn cynnwys `&(dyn Any + Send)` yn unig, yr ydym yn llenwi gwerth ffug yn `PanicInfo: : internal_constructor`.) Y rheswm am hyn yw na chaniateir i libcore ddyrannu.
//!
//!
//! Mae'r modiwl hwn yn cynnwys ychydig o swyddogaethau panicio eraill, ond dim ond yr eitemau lang angenrheidiol ar gyfer y casglwr yw'r rhain.Mae pob panics yn cael ei ffrydio trwy'r un swyddogaeth hon.
//! Cyhoeddir y symbol gwirioneddol trwy'r priodoledd `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Gweithrediad sylfaenol macro `panic!` libcore pan na ddefnyddir fformatio.
#[cold]
// peidiwch byth â mewnlin oni bai bod panic_immediate_abort i osgoi cod yn chwyddo yn y safleoedd galw cymaint â phosibl
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ei angen gan codegen ar gyfer panic ar orlif a therfynwyr `Assert` MIR eraill
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Defnyddiwch Arguments::new_v1 yn lle format_args! ("{}", Expr) i leihau maint uwchben o bosibl.
    // Y fformat_args!mae macro yn defnyddio Arddangos trait str i ysgrifennu expr, sy'n galw Formatter::pad, y mae'n rhaid iddo gynnwys tocio llinyn a phadin (er na ddefnyddir yr un yma).
    //
    // Gall defnyddio Arguments::new_v1 ganiatáu i'r casglwr hepgor Formatter::pad o'r deuaidd allbwn, gan arbed hyd at ychydig o gilobeit.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // sydd ei angen ar gyfer panics wedi'i werthuso'n gyson
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // ei angen gan codegen ar gyfer panic ar fynediad OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Defnyddir gweithredu sylfaenol macro `panic!` libcore wrth fformatio.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // SYLWCH Nid yw'r swyddogaeth hon byth yn croesi ffin FFI;mae'n alwad Rust-to-Rust sy'n cael ei datrys i'r swyddogaeth `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // DIOGELWCH: Diffinnir `panic_impl` mewn cod Rust diogel ac felly mae'n ddiogel ei alw.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Swyddogaeth fewnol ar gyfer macros `assert_eq!` a `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}