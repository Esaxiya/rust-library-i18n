//! Addasiad Rust o'r algorithm Grisu3 a ddisgrifir yn "Argraffu Rhifau Pwynt fel y bo'r Angen yn Gyflym ac yn Gywir gyda Chyfanrifau" [^ 1].
//! Mae'n defnyddio tua 1KB o dabl wedi'i rag-gyfrifo, ac yn ei dro, mae'n gyflym iawn ar gyfer y mwyafrif o fewnbynnau.
//!
//! [^1]: Florian Loitsch.2010. Argraffu rhifau pwynt arnofio yn gyflym a
//!   yn gywir gyda chyfanrifau.SIGPLAN Ddim.45, 6 (Mehefin 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// gweler y sylwadau yn `format_shortest_opt` am y rhesymeg.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (dd, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// O ystyried `x > 0`, yn dychwelyd `(k, 10^k)` fel bod `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Y modd gweithredu byrraf ar gyfer Grisu.
///
/// Mae'n dychwelyd `None` pan fyddai'n dychwelyd cynrychiolaeth ddibwys fel arall.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // mae angen o leiaf dri darn o gywirdeb ychwanegol arnom

    // dechreuwch gyda'r gwerthoedd normaleiddiedig gyda'r esboniwr a rennir
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // dewch o hyd i unrhyw `cached = 10^minusk` fel `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // gan fod `plus` yn cael ei normaleiddio, mae hyn yn golygu `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // o ystyried ein dewisiadau o `ALPHA` a `GAMMA`, mae hyn yn rhoi `plus * cached` yn `[4, 2^32)`.
    //
    // mae'n amlwg yn ddymunol gwneud y mwyaf o `GAMMA - ALPHA`, fel nad oes angen llawer o bwerau wedi'u storio o 10 arnom, ond mae rhai ystyriaethau:
    //
    //
    // 1. rydym am gadw `floor(plus * cached)` o fewn `u32` gan fod angen rhaniad costus arno.
    //    (ni ellir osgoi hyn mewn gwirionedd, mae angen gweddill ar gyfer amcangyfrif cywirdeb.)
    // 2.
    // mae gweddill `floor(plus * cached)` yn cael ei luosi dro ar ôl tro â 10, ac ni ddylai orlifo.
    //
    // mae'r cyntaf yn rhoi `64 + GAMMA <= 32`, tra bod yr ail yn rhoi `10 * 2^-ALPHA <= 2^64`;
    // -60 ac -32 yw'r amrediad mwyaf posibl gyda'r cyfyngiad hwn, ac mae V8 hefyd yn eu defnyddio.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // graddfa fps.mae hyn yn rhoi'r gwall mwyaf posibl o 1 mwydyn (profwyd o Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-ystod wirioneddol minws
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 mwydyn | 1 mwydyn || 1 mwydyn | 1 mwydyn || 1 mwydyn | 1 mwydyn |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // mae `minus`, `v` a `plus` yn amcangyfrifon *meintiol*(gwall <1 ulp).
    // gan nad ydym yn gwybod bod y gwall yn gadarnhaol neu'n negyddol, rydym yn defnyddio dau amcangyfrif yn cael eu gosod yn gyfartal ac mae gennym y gwall mwyaf posibl o 2 friw.
    //
    // mae'r "unsafe region" yn gyfwng rhyddfrydol yr ydym yn ei gynhyrchu i ddechrau.
    // mae'r "safe region" yn gyfwng ceidwadol yr ydym yn ei dderbyn yn unig.
    // rydym yn dechrau gyda'r cynrychiolwyr cywir yn y rhanbarth anniogel, ac yn ceisio dod o hyd i'r repr agosaf at `v` sydd hefyd o fewn y rhanbarth diogel.
    // os na allwn, rydym yn rhoi`r gorau iddi.
    //
    let plus1 = plus.f + 1;
    // gadewch i plus0 = plus.f, 1;//dim ond am esboniad gadewch minus0 = minus.f + 1;//dim ond am esboniad
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // esboniwr a rennir

    // rhannwch `plus1` yn rhannau annatod a ffracsiynol.
    // mae rhannau annatod yn sicr o ffitio yn u32, gan fod pŵer storfa yn gwarantu `plus < 2^32` ac mae `plus.f` wedi'i normaleiddio bob amser yn llai na `2^64 - 2^4` oherwydd y gofyniad manwl gywirdeb.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // cyfrifwch yr `10^max_kappa` mwyaf dim mwy na `plus1` (felly `plus1 < 10^(max_kappa+1)`).
    // mae hwn yn rwymyn uchaf o `kappa` isod.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Theorem 6.2: os `k` yw'r cyfanrif mwyaf st
    // `0 <= y mod 10^k <= y - x`,              yna mae `V = floor(y / 10^k) * 10^k` yn `[x, y]` ac un o'r sylwadau byrraf (gyda'r nifer lleiaf o ddigidau arwyddocaol) yn yr ystod honno.
    //
    //
    // darganfyddwch hyd digid `kappa` rhwng `(minus1, plus1)` yn unol â Theorem 6.2.
    // Gellir mabwysiadu Theorem 6.2 i eithrio `x` trwy fynnu `y mod 10^k < y - x` yn lle.
    // (ee, `x` =32000, `y` =32777; `kappa` =2 ers `y mod 10 ^ 3=777 <y, x=777`.) mae'r algorithm yn dibynnu ar y cam dilysu diweddarach i eithrio `y`.
    //
    let delta1 = plus1 - minus1;
    // gadewch i delta1int=(delta1>> e) fel usize;//dim ond am esboniad
    let delta1frac = delta1 & ((1 << e) - 1);

    // rendro rhannau annatod, wrth wirio am y cywirdeb ar bob cam.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // digidau eto i'w rendro
    loop {
        // mae gennym o leiaf un digid i'w roi bob amser, fel invariants `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (mae'n dilyn hynny `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // rhannwch `remainder` â `10^kappa`.mae'r ddau wedi'u graddio gan `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; rydym wedi dod o hyd i'r `kappa` cywir.
            let ten_kappa = (ten_kappa as u64) << e; // graddfa 10 ^ kappa yn ôl i'r esboniwr a rennir
            return round_and_weed(
                // DIOGELWCH: gwnaethom gychwyn y cof uchod.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // torri'r ddolen pan fyddwn wedi rendro'r holl ddigidau annatod.
        // yr union nifer o ddigidau yw `max_kappa + 1` fel `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // adfer invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // rendro rhannau ffracsiynol, wrth wirio am y cywirdeb ar bob cam.
    // y tro hwn rydym yn dibynnu ar luosiadau dro ar ôl tro, gan y bydd rhannu yn colli'r manwl gywirdeb.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // dylai'r digid nesaf fod yn arwyddocaol gan ein bod wedi profi hynny cyn torri allan invariants, lle mae `m = max_kappa + 1` (#digid yn y rhan annatod):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ni fydd yn gorlifo, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // rhannwch `remainder` â `10^kappa`.
        // mae'r ddau wedi'u graddio gan `2^e / 10^kappa`, felly mae'r olaf ymhlyg yma.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // rhannwr ymhlyg
            return round_and_weed(
                // DIOGELWCH: gwnaethom gychwyn y cof uchod.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // adfer invariants
        kappa -= 1;
        remainder = r;
    }

    // rydym wedi cynhyrchu pob digid sylweddol o `plus1`, ond ddim yn siŵr ai hwn yw'r un gorau posibl.
    // er enghraifft, os yw `minus1` yn 3.14153 ... a `plus1` yn 3.14158 ..., mae 5 cynrychiolaeth fyrraf wahanol o 3.14154 i 3.14158 ond dim ond yr un mwyaf sydd gennym.
    // mae'n rhaid i ni ostwng y digid olaf yn olynol a gwirio ai hwn yw'r cynrychiolydd gorau posibl.
    // mae 9 ymgeisydd ar y mwyaf (..1 i ..9), felly mae hyn yn weddol gyflym.(Cyfnod "rounding")
    //
    // mae'r swyddogaeth yn gwirio a yw'r repr "optimal" hwn o fewn yr ystodau mwydion, a hefyd, mae'n bosibl y gall y repr "second-to-optimal" fod yn optimaidd mewn gwirionedd oherwydd y gwall talgrynnu.
    // yn y naill achos neu'r llall, mae hyn yn dychwelyd `None`.
    // (Cyfnod "weeding")
    //
    // mae pob dadl yma yn cael ei graddio gan y gwerth cyffredin (ond ymhlyg) `k`, fel:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (a hefyd, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (a hefyd, `threshold > plus1v` o invariants blaenorol)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // cynhyrchu dau amcangyfrif i `v` (`plus1 - v` mewn gwirionedd) o fewn briwiau 1.5.
        // dylai'r gynrychiolaeth sy'n deillio o hyn fod y gynrychiolaeth agosaf at y ddau.
        //
        // yma defnyddir `plus1 - v` gan fod cyfrifiadau'n cael eu gwneud mewn perthynas â `plus1` er mwyn osgoi overflow/underflow (dyna'r enwau sy'n cael eu cyfnewid yn ôl pob golwg).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // gostwng y digid olaf a stopio ar y gynrychiolaeth agosaf i `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // rydym yn gweithio gyda'r digidau bras `w(n)`, sydd i ddechrau yn hafal i `plus1 - plus1 % 10^kappa`.ar ôl rhedeg y corff dolen `n` gwaith, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // rydym yn gosod `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (felly `gweddill= plus1w(0)`) i symleiddio gwiriadau.
            // nodwch fod `plus1w(n)` bob amser yn cynyddu.
            //
            // mae gennym dri amod i ddod i ben.bydd unrhyw un ohonynt yn golygu na all y ddolen symud ymlaen, ond yna mae gennym o leiaf un gynrychiolaeth ddilys y gwyddys ei bod agosaf at `v + 1 ulp` beth bynnag.
            // byddwn yn eu dynodi fel TC1 trwy TC3 ar gyfer cryno.
            //
            // TC1: `w(n) <= v + 1 ulp`, h.y., dyma'r repr olaf a all fod yr un agosaf.
            // mae hyn yn cyfateb i `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // ynghyd â TC2 (sy'n gwirio a yw `w(n+1)` is valid), mae hyn yn atal y gorlif posibl wrth gyfrifo `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, h.y., yn bendant nid yw'r repr nesaf yn talgrynnu i `v`.
            // mae hyn yn cyfateb i `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // gall yr ochr chwith orlifo, ond rydyn ni'n gwybod `threshold > plus1v`, felly os yw TC1 yn ffug, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` a gallwn ni brofi a yw `threshold - plus1w(n) < 10^kappa` yn lle hynny.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, h.y., y repr nesaf yw
            // ddim yn agosach at `v + 1 ulp` na'r repr cyfredol.
            // o ystyried `z(n) = plus1v_up - plus1w(n)`, daw hyn yn `abs(z(n)) <= abs(z(n+1))`.eto gan dybio bod TC1 yn ffug, mae gennym `z(n) > 0`.mae gennym ddau achos i'w hystyried:
            //
            // - pan ddaw `z(n+1) >= 0`: TC3 yn `z(n) <= z(n+1)`.
            // gan fod `plus1w(n)` yn cynyddu, dylai `z(n)` fod yn gostwng ac mae hyn yn amlwg yn ffug.
            // - pan `z(n+1) < 0`:
            //   - TC3a: y rhagamod yw `plus1v_up < plus1w(n) + 10^kappa`.gan dybio bod TC2 yn ffug, `threshold >= plus1w(n) + 10^kappa` felly ni all orlifo.
            //   - TC3b: TC3 yn dod yn `z(n) <= -z(n+1)`, h.y. `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   mae'r TC1 diriaethol yn rhoi `plus1v_up > plus1w(n)`, felly ni all orlifo na gorlifo wrth ei gyfuno â TC3a.
            //
            // o ganlyniad, dylem stopio pan `TC1 || TC2 || (TC3a && TC3b)`.mae'r canlynol yn hafal i'w wrthdro, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // ni all y cynrychiolydd byrraf ddod i ben gyda `0`
                plus1w += ten_kappa;
            }
        }

        // gwiriwch ai`r gynrychiolaeth hon hefyd yw`r gynrychiolaeth agosaf at `v - 1 ulp`.
        //
        // mae hyn yn syml yr un peth â'r amodau terfynu ar gyfer `v + 1 ulp`, gyda `plus1v_down` yn disodli pob `plus1v_up`.
        // mae dadansoddiad gorlif yr un mor bwysig.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // nawr mae gennym y gynrychiolaeth agosaf at `v` rhwng `plus1` a `minus1`.
        // mae hyn yn rhy ryddfrydol, serch hynny, felly rydym yn gwrthod unrhyw `w(n)` nid rhwng `plus0` a `minus0`, hy, `plus1 - plus1w(n) <= minus0` neu `plus1 - plus1w(n) >= plus0`.
        // rydym yn defnyddio'r ffeithiau bod `threshold = plus1 - minus1` a `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Y modd gweithredu byrraf ar gyfer Grisu gyda Dragon fallback.
///
/// Dylid defnyddio hwn yn y mwyafrif o achosion.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // DIOGELWCH: Nid yw'r gwiriwr benthyg yn ddigon craff i adael inni ddefnyddio `buf`
    // yn yr ail branch, felly rydyn ni'n gwyngalchu'r oes yma.
    // Ond dim ond os dychwelodd `format_shortest_opt` `None` y byddwn yn ail-ddefnyddio `buf` felly mae hyn yn iawn.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Y dull gweithredu union a sefydlog ar gyfer Grisu.
///
/// Mae'n dychwelyd `None` pan fyddai'n dychwelyd cynrychiolaeth ddibwys fel arall.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // mae angen o leiaf dri darn o gywirdeb ychwanegol arnom
    assert!(!buf.is_empty());

    // normaleiddio a graddio `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // rhannwch `v` yn rhannau annatod a ffracsiynol.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // mae gan yr hen `v` a'r `v` newydd (wedi'i raddio gan `10^-k`) wall o <1 ulp (Theorem 5.1).
    // gan nad ydym yn gwybod bod y gwall yn gadarnhaol neu'n negyddol, rydym yn defnyddio dau amcangyfrif sydd wedi'u gosod yn gyfartal ac mae gennym y gwall mwyaf posibl o 2 wddf (yr un peth â'r achos byrraf).
    //
    //
    // y nod yw dod o hyd i'r gyfres gyfan o ddigidau sy'n gyffredin i `v - 1 ulp` a `v + 1 ulp`, fel ein bod yn hyderus ar y mwyaf.
    // os nad yw hyn yn bosibl, nid ydym yn gwybod pa un yw'r allbwn cywir ar gyfer `v`, felly rydyn ni'n rhoi'r gorau iddi ac yn cwympo yn ôl.
    //
    // `err` fe'i diffinnir fel `1 ulp * 2^e` yma (yr un peth â'r mwydyn yn `vfrac`), a byddwn yn ei raddfa pryd bynnag y bydd `v` yn cael ei raddio.
    //
    //
    //
    let mut err = 1;

    // cyfrifwch yr `10^max_kappa` mwyaf dim mwy na `v` (felly `v < 10^(max_kappa+1)`).
    // mae hwn yn rwymyn uchaf o `kappa` isod.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // os ydym yn gweithio gyda'r cyfyngiad digid olaf, mae angen i ni fyrhau'r byffer cyn y rendro gwirioneddol er mwyn osgoi talgrynnu dwbl.
    //
    // nodwch fod yn rhaid i ni ehangu'r byffer eto pan fydd talgrynnu yn digwydd!
    let len = if exp <= limit {
        // wps, ni allwn hyd yn oed gynhyrchu *un* digid.
        // mae hyn yn bosibl pan fydd gennym ni, dyweder, rywbeth fel 9.5 ac mae'n cael ei dalgrynnu i 10.
        //
        // mewn egwyddor gallwn ffonio `possibly_round` ar unwaith gyda byffer gwag, ond gall graddio `max_ten_kappa << e` erbyn 10 arwain at orlif.
        //
        // felly rydym yn bod yn flêr yma ac yn ehangu'r ystod gwallau gan ffactor o 10.
        // bydd hyn yn cynyddu'r gyfradd negyddol ffug, ond dim ond ychydig iawn, * ychydig iawn;
        // dim ond pan fydd y mantissa yn fwy na 60 darn y gall fod o bwys.
        //
        // DIOGELWCH: `len=0`, felly mae'r rhwymedigaeth o gychwyn y cof hwn yn ddibwys.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // rendro rhannau annatod.
    // mae'r gwall yn hollol ffracsiynol, felly nid oes angen i ni ei wirio yn y rhan hon.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // digidau eto i'w rendro
    loop {
        // mae gennym o leiaf un digid bob amser i roi invariants:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (mae'n dilyn hynny `remainder = vint % 10^(kappa+1)`)
        //
        //

        // rhannwch `remainder` â `10^kappa`.mae'r ddau wedi'u graddio gan `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ydy'r byffer yn llawn?rhedeg y tocyn talgrynnu gyda'r gweddill.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // DIOGELWCH: rydym wedi cychwyn llawer o beit `len`.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // torri'r ddolen pan fyddwn wedi rendro'r holl ddigidau annatod.
        // yr union nifer o ddigidau yw `max_kappa + 1` fel `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // adfer invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // rendro rhannau ffracsiynol.
    //
    // mewn egwyddor gallwn barhau i'r digid olaf sydd ar gael a gwirio am y cywirdeb.
    // yn anffodus rydym yn gweithio gyda'r cyfanrifau maint cyfyngedig, felly mae angen rhywfaint o faen prawf arnom i ganfod y gorlif.
    // V8 yn defnyddio `remainder > err`, sy'n dod yn ffug pan fydd y digidau arwyddocaol `i` cyntaf o `v - 1 ulp` a `v` yn wahanol.
    // fodd bynnag, mae hyn yn gwrthod gormod o fewnbwn sydd fel arall yn ddilys.
    //
    // gan fod y cam diweddarach â chanfod gorlif cywir, rydym yn lle defnyddio maen prawf tynnach:
    // rydym yn parhau nes bod `err` yn fwy na `10^kappa / 2`, fel bod yr ystod rhwng `v - 1 ulp` a `v + 1 ulp` yn bendant yn cynnwys dau neu fwy o sylwadau crwn.
    //
    // mae hyn yr un peth â'r ddau gymhariaeth gyntaf o `possibly_round`, ar gyfer y cyfeirnod.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, lle mae `m = max_kappa + 1` (#o ddigidau yn y rhan annatod):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ni fydd yn gorlifo, `2^e * 10 < 2^64`
        err *= 10; // ni fydd yn gorlifo, `err * 10 < 2^e * 5 < 2^64`

        // rhannwch `remainder` â `10^kappa`.
        // mae'r ddau wedi'u graddio gan `2^e / 10^kappa`, felly mae'r olaf ymhlyg yma.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ydy'r byffer yn llawn?rhedeg y tocyn talgrynnu gyda'r gweddill.
        if i == len {
            // DIOGELWCH: rydym wedi cychwyn llawer o beit `len`.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // adfer invariants
        remainder = r;
    }

    // mae cyfrifiad pellach yn ddiwerth (mae `possibly_round` yn bendant yn methu), felly rydyn ni'n rhoi'r gorau iddi.
    return None;

    // rydym wedi cynhyrchu'r holl ddigidau y gofynnwyd amdanynt o `v`, a ddylai hefyd fod yr un fath â digidau cyfatebol `v - 1 ulp`.
    // nawr rydym yn gwirio a oes cynrychiolaeth unigryw a rennir gan `v - 1 ulp` a `v + 1 ulp`;gall hyn fod yr un fath â digidau a gynhyrchir, neu i fersiwn grwn y digidau hynny.
    //
    // os yw'r amrediad yn cynnwys cynrychiolaethau lluosog o'r un hyd, ni allwn fod yn sicr a dylem ddychwelyd `None` yn lle.
    //
    // mae pob dadl yma yn cael ei graddio gan y gwerth cyffredin (ond ymhlyg) `k`, fel:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // DIOGELWCH: rhaid cychwyn y beit `len` cyntaf o `buf`.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (ar gyfer y cyfeirnod, mae'r llinell doredig yn nodi'r union werth ar gyfer sylwadau posibl mewn nifer penodol o ddigidau.)
        //
        //
        // gwall yn rhy fawr fel bod o leiaf dri chynrychiolaeth bosibl rhwng `v - 1 ulp` a `v + 1 ulp`.
        // ni allwn benderfynu pa un sy'n gywir.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // mewn gwirionedd, mae mwydion 1/2 yn ddigon i gyflwyno dau sylw posibl.
        // (cofiwch fod angen cynrychiolaeth unigryw arnom ar gyfer `v - 1 ulp` a `v + 1 ulp`.) ni fydd hyn yn gorlifo, fel `ulp < ten_kappa` o'r gwiriad cyntaf.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 mwydyn | 1 mwydyn |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // os yw `v + 1 ulp` yn agosach at y gynrychiolaeth dalgrynnu i lawr (sydd eisoes yn `buf`), yna gallwn ddychwelyd yn ddiogel.
        // nodwch y gall `v - 1 ulp`* * fod yn llai na'r gynrychiolaeth gyfredol, ond fel `1 ulp < 10^kappa / 2`, mae'r amod hwn yn ddigon:
        // ni all y pellter rhwng `v - 1 ulp` a'r gynrychiolaeth gyfredol fod yn fwy na `10^kappa / 2`.
        //
        // mae'r cyflwr yn hafal i `remainder + ulp < 10^kappa / 2`.
        // gan y gall hyn orlifo'n hawdd, gwiriwch yn gyntaf a yw `remainder < 10^kappa / 2`.
        // rydym eisoes wedi gwirio bod `ulp < 10^kappa / 2`, felly cyn belled nad oedd `10^kappa` yn gorlifo wedi'r cyfan, mae'r ail wiriad yn iawn.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // DIOGELWCH: cychwynnodd ein galwr y cof hwnnw.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------gweddill------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // ar y dwylo eraill, os yw `v - 1 ulp` yn agosach at y gynrychiolaeth dalgrynnu, dylem dalgrynnu a dychwelyd.
        // am yr un rheswm nid oes angen i ni wirio `v + 1 ulp`.
        //
        // mae'r cyflwr yn hafal i `remainder - ulp >= 10^kappa / 2`.
        // eto rydym yn gwirio yn gyntaf a yw `remainder > ulp` (nodwch nad `remainder >= ulp` yw hwn, gan nad yw `10^kappa` byth yn sero).
        //
        // nodwch hefyd fod `remainder - ulp <= 10^kappa`, felly nid yw'r ail wiriad yn gorlifo.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // DIOGELWCH: mae'n rhaid bod ein galwr wedi cychwyn y cof hwnnw.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // dim ond ychwanegu digid ychwanegol pan ofynnwyd i ni am y manwl gywirdeb sefydlog.
                // mae angen i ni wirio hefyd, pe bai'r byffer gwreiddiol yn wag, dim ond pan fydd `exp == limit` (achos edge) y gellir ychwanegu'r digid ychwanegol.
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // DIOGELWCH: fe wnaethom ni a'n galwr gychwyn y cof hwnnw.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // fel arall rydym wedi ein tynghedu (h.y., mae rhai gwerthoedd rhwng `v - 1 ulp` a `v + 1 ulp` yn talgrynnu i lawr ac mae eraill yn talgrynnu) ac yn rhoi'r gorau iddi.
        //
        None
    }
}

/// Y gweithredu modd union a sefydlog ar gyfer Grisu gyda Dragon fallback.
///
/// Dylid defnyddio hwn yn y mwyafrif o achosion.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // DIOGELWCH: Nid yw'r gwiriwr benthyg yn ddigon craff i adael inni ddefnyddio `buf`
    // yn yr ail branch, felly rydyn ni'n gwyngalchu'r oes yma.
    // Ond dim ond os dychwelodd `format_exact_opt` `None` y byddwn yn ail-ddefnyddio `buf` felly mae hyn yn iawn.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}