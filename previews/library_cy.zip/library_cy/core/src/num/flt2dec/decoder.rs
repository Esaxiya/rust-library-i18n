//! Yn dadgodio gwerth pwynt arnofio yn rhannau unigol ac ystodau gwallau.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Gwerth cyfyngedig heb ei lofnodi wedi'i ddatgodio, fel:
///
/// - Mae'r gwerth gwreiddiol yn hafal i `mant * 2^exp`.
///
/// - Bydd unrhyw rif o `(mant - minus)*2^exp` i `(mant + plus)* 2^exp` yn talgrynnu i'r gwerth gwreiddiol.
/// Mae'r ystod yn gynhwysol dim ond pan fydd `inclusive` yn `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Y mantissa graddedig.
    pub mant: u64,
    /// Yr ystod gwallau is.
    pub minus: u64,
    /// Yr ystod gwall uchaf.
    pub plus: u64,
    /// Yr esboniwr a rennir yn sylfaen 2.
    pub exp: i16,
    /// Gwir pan fydd yr ystod gwallau yn gynhwysol.
    ///
    /// Yn IEEE 754, mae hyn yn wir pan oedd y mantissa gwreiddiol hyd yn oed.
    pub inclusive: bool,
}

/// Gwerth heb ei ddadgodio.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Anfeidredd, naill ai'n gadarnhaol neu'n negyddol.
    Infinite,
    /// Sero, naill ai'n gadarnhaol neu'n negyddol.
    Zero,
    /// Rhifau cyfyngedig gyda chaeau wedi'u datgodio ymhellach.
    Finite(Decoded),
}

/// Math o bwynt arnofio y gellir ei 'ddadgodio'.
pub trait DecodableFloat: RawFloat + Copy {
    /// Y gwerth normaleiddio cadarnhaol lleiaf.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Yn dychwelyd arwydd (gwir pan yn negyddol) a gwerth `FullDecoded` o'r rhif pwynt arnofio penodol.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // cymdogion: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode bob amser yn cadw'r esboniwr, felly mae'r mantissa yn cael ei raddio ar gyfer subnormals.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // cymdogion: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // lle maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // cymdogion: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}