//! Cysonion ar gyfer y math cyfanrif wedi'i lofnodi 128-did.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Dylai cod newydd ddefnyddio'r cysonion cysylltiedig yn uniongyrchol ar y math cyntefig.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }