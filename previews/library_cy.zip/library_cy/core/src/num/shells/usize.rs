//! Cysonion ar gyfer y math cyfanrif heb ei arwyddo maint pwyntydd.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Dylai cod newydd ddefnyddio'r cysonion cysylltiedig yn uniongyrchol ar y math cyntefig.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }