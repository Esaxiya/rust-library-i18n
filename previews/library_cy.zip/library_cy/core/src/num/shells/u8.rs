//! Cysonion ar gyfer y math cyfanrif 8-did heb ei arwyddo.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Dylai cod newydd ddefnyddio'r cysonion cysylltiedig yn uniongyrchol ar y math cyntefig.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }