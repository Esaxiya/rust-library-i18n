//! Cysonion ar gyfer y math cyfanrif 64-did heb ei lofnodi.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Dylai cod newydd ddefnyddio'r cysonion cysylltiedig yn uniongyrchol ar y math cyntefig.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }