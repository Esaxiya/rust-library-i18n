//! Trosi llinynnau degol yn rhifau pwynt arnofio deuaidd IEEE 754.
//!
//! # Datganiad problem
//!
//! Rydyn ni'n cael llinyn degol fel `12.34e56`.
//! Mae'r llinyn hwn yn cynnwys rhannau annatod (`12`), ffracsiynol (`34`), ac esboniwr (`56`).Mae pob rhan yn ddewisol ac yn cael ei ddehongli fel sero pan fyddant ar goll.
//!
//! Rydym yn ceisio rhif pwynt arnofio IEEE 754 sydd agosaf at union werth y llinyn degol.
//! Mae'n hysbys nad oes gan lawer o dannau degol gynrychioliadau terfynu yn sylfaen dau, felly rydym yn talgrynnu i unedau 0.5 yn y lle olaf (mewn geiriau eraill, cystal â phosibl).
//! Datrysir cysylltiadau, gwerthoedd degol union hanner ffordd rhwng dau fflôt yn olynol, gyda'r strategaeth hanner-hyd yn oed, a elwir hefyd yn dalgrynnu bancwyr.
//!
//! Afraid dweud, mae hyn yn eithaf caled, o ran cymhlethdod gweithredu ac o ran cylchoedd CPU a gymerir.
//!
//! # Implementation
//!
//! Yn gyntaf, rydym yn anwybyddu arwyddion.Neu yn hytrach, rydyn ni'n ei dynnu ar ddechrau'r broses drosi a'i ail-gymhwyso ar y diwedd.
//! Mae hyn yn gywir ym mhob achos edge gan fod fflotiau IEEE yn gymesur o amgylch sero, gan negyddu un yn syml yn fflipio'r darn cyntaf.
//!
//! Yna rydyn ni'n dileu'r pwynt degol trwy addasu'r esboniwr: Yn gysyniadol, mae `12.34e56` yn troi'n `1234e54`, rydyn ni'n ei ddisgrifio gyda chyfanrif positif `f = 1234` a chyfanrif `e = 54`.
//! Defnyddir y gynrychiolaeth `(f, e)` gan bron pob cod heibio'r cam dosrannu.
//!
//! Yna byddwn yn rhoi cynnig ar gadwyn hir o achosion arbennig sy'n fwy cyffredinol a drud yn raddol gan ddefnyddio cyfanrifau maint peiriant a rhifau pwyntiau arnofio bach, maint sefydlog (`f32`/`f64` cyntaf, yna math gyda arwyddocâd 64 did, `Fp`).
//!
//! Pan fydd y rhain i gyd yn methu, rydym yn brathu'r bwled ac yn troi at algorithm syml ond araf iawn a oedd yn cynnwys cyfrifiadura `f * 10^e` yn llawn a gwneud chwiliad ailadroddol am y brasamcan gorau.
//!
//! Yn bennaf, mae'r modiwl hwn a'i blant yn gweithredu'r algorithmau a ddisgrifir yn:
//! "How to Read Floating Point Numbers Accurately" gan William D.
//! Clinger, ar gael ar-lein: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! Yn ogystal, mae yna nifer o swyddogaethau cynorthwyydd sy'n cael eu defnyddio yn y papur ond nad ydyn nhw ar gael yn Rust (neu o leiaf yn greiddiol).
//! Mae ein fersiwn hefyd wedi'i gymhlethu gan yr angen i drin gorlif a gorlif a'r awydd i drin rhifau isnormal.
//! Mae Bellerophon ac Algorithm R yn cael trafferth gyda gorlif, subnormals, a gorlif.
//! Rydym yn newid yn geidwadol i Algorithm M (gyda'r addasiadau a ddisgrifir yn adran 8 o'r papur) ymhell cyn i'r mewnbynnau gyrraedd y rhanbarth critigol.
//!
//! Agwedd arall sydd angen sylw yw'r ``RawFloat`` trait lle mae bron pob swyddogaeth yn cael ei pharameraleiddio.Efallai y bydd rhywun yn meddwl ei bod yn ddigon i ddosrannu i `f64` a bwrw'r canlyniad i `f32`.
//! Yn anffodus nid dyma'r byd rydyn ni'n byw ynddo, ac nid oes gan hyn unrhyw beth i'w wneud â defnyddio talgrynnu sylfaen dau neu hanner hyd yn oed.
//!
//! Ystyriwch, er enghraifft, ddau fath `d2` a `d4` sy'n cynrychioli math degol gyda dau ddigid degol a phedwar digid degol yr un a chymryd "0.01499" fel mewnbwn.Gadewch i ni ddefnyddio talgrynnu hanner i fyny.
//! Mae mynd yn uniongyrchol i ddau ddigid degol yn rhoi `0.01`, ond os ydym yn talgrynnu i bedwar digid yn gyntaf, rydym yn cael `0.0150`, sydd wedyn yn cael ei dalgrynnu hyd at `0.02`.
//! Mae'r un egwyddor yn berthnasol i weithrediadau eraill hefyd, os ydych chi eisiau cywirdeb 0.5 ULP mae angen i chi wneud *popeth* yn fanwl gywir a rownd *yn union unwaith, ar y diwedd*, trwy ystyried yr holl ddarnau wedi'u cwtogi ar unwaith.
//!
//! FIXME: Er bod angen rhywfaint o ddyblygu cod, efallai y gallai rhannau o'r cod gael eu symud o gwmpas fel bod llai o god yn cael ei ddyblygu.
//! Mae rhannau helaeth o'r algorithmau yn annibynnol ar y math arnofio i'w allbwn, neu dim ond ychydig o gysonion sydd eu hangen arnynt, y gellid eu pasio i mewn fel paramedrau.
//!
//! # Other
//!
//! Ni ddylai'r trawsnewidiad *byth* panic.
//! Mae honiadau a panics penodol yn y cod, ond ni ddylid byth eu sbarduno a dim ond fel gwiriadau sancteiddrwydd mewnol y dylent eu gwasanaethu.Dylid ystyried unrhyw panics yn nam.
//!
//! Mae profion uned ond maent yn druenus o annigonol wrth sicrhau cywirdeb, dim ond canran fach o wallau posibl y maent yn eu cynnwys.
//! Mae profion llawer mwy helaeth i'w gweld yn y cyfeiriadur `src/etc/test-float-parse` fel sgript Python.
//!
//! Nodyn ar orlif cyfanrif: Mae llawer o rannau o'r ffeil hon yn perfformio rhifyddeg gyda'r esboniwr degol `e`.
//! Yn bennaf, rydym yn symud y pwynt degol o gwmpas: Cyn y digid degol cyntaf, ar ôl y digid degol olaf, ac ati.Gallai hyn orlifo os caiff ei wneud yn ddiofal.
//! Rydym yn dibynnu ar yr is-fodiwl dosrannu i ddosbarthu esbonwyr digon bach yn unig, lle mae "sufficient" yn golygu "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! Derbynnir esbonwyr mwy, ond nid ydym yn rhifyddeg gyda nhw, cânt eu troi ar unwaith yn {positive,negative} {zero,infinity}.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// Mae gan y ddau hyn eu profion eu hunain.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// Trosi llinyn yn sylfaen 10 i fflôt.
            /// Yn derbyn esboniwr degol dewisol.
            ///
            /// Mae'r swyddogaeth hon yn derbyn tannau fel
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', neu'n gyfwerth, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', neu, yn yr un modd, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// Mae gofod gwyn arweiniol a llusgo yn cynrychioli gwall.
            ///
            /// # Grammar
            ///
            /// Bydd pob llinyn sy'n glynu wrth y gramadeg [EBNF] canlynol yn arwain at ddychwelyd [`Ok`]:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # Bygiau hysbys
            ///
            /// Mewn rhai sefyllfaoedd, mae rhai llinynnau a ddylai greu fflôt dilys yn lle dychwelyd gwall.
            /// Gweler [issue #31407] am fanylion.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, Llinyn
            ///
            /// # Gwerth dychwelyd
            ///
            /// `Err(ParseFloatError)` os nad oedd y llinyn yn cynrychioli rhif dilys.
            /// Fel arall, `Ok(n)` lle `n` yw'r rhif pwynt arnofio a gynrychiolir gan `src`.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// Gwall y gellir ei ddychwelyd wrth dosrannu arnofio.
///
/// Defnyddir y gwall hwn fel y math gwall ar gyfer gweithredu [`FromStr`] ar gyfer [`f32`] a [`f64`].
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// Yn rhannu llinyn degol yn arwydd a'r gweddill, heb archwilio na dilysu'r gweddill.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // Os yw'r llinyn yn annilys, nid ydym byth yn defnyddio'r arwydd, felly nid oes angen i ni ddilysu yma.
        _ => (Sign::Positive, s),
    }
}

/// Trosi llinyn degol yn rhif pwynt arnofio.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// Y prif flaen gwaith ar gyfer y trawsnewid degol-i-arnofio: Trefnwch yr holl brosesu ymlaen llaw a chyfrif i maes pa algorithm ddylai wneud y trawsnewidiad gwirioneddol.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift allan y pwynt degol.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Mae Big32x40 wedi'i gyfyngu i 1280 darn, sy'n cyfieithu i tua 385 digid degol.
    // Os byddwn yn rhagori ar hyn, byddwn yn chwalu, felly byddwn yn camgymryd cyn mynd yn rhy agos (o fewn 10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // Nawr mae'r esboniwr yn sicr yn ffitio mewn 16 did, a ddefnyddir trwy'r prif algorithmau.
    let e = e as i16;
    // FIXME Mae'r ffiniau hyn braidd yn geidwadol.
    // Gallai dadansoddiad mwy gofalus o ddulliau methu Bellerophon ganiatáu ei ddefnyddio mewn mwy o achosion ar gyfer cyflymu enfawr.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// Yn ysgrifenedig, mae hyn yn gwneud y gorau yn wael (gweler #27130, er ei fod yn cyfeirio at hen fersiwn o'r cod).
// `inline(always)` yn gweithio ar gyfer hynny.
// Dim ond dau safle galwadau sydd ar y cyfan ac nid yw'n gwaethygu maint cod.

/// Llain sero lle bo hynny'n bosibl, hyd yn oed pan fydd hyn yn gofyn am newid yr esboniwr
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // Nid yw trimio'r seroau hyn yn newid unrhyw beth ond gallai alluogi'r llwybr cyflym (<15 digid).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // Symleiddiwch rifau'r ffurflen 0.0 ... x a x ... 0.0, gan addasu'r esboniwr yn unol â hynny.
    // Efallai na fydd hyn bob amser yn fuddugoliaeth (o bosibl yn gwthio rhai rhifau allan o'r llwybr cyflym), ond mae'n symleiddio rhannau eraill yn sylweddol (yn benodol, gan amcangyfrif maint y gwerth).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// Yn dychwelyd rhwymyn uchaf cyflym-budr ar faint (log10) o'r gwerth mwyaf y bydd Algorithm R ac Algorithm M yn ei gyfrifo wrth weithio ar y degol a roddir.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // Nid oes angen i ni boeni gormod am orlif yma diolch i trivial_cases() a'r parser, sy'n hidlo'r mewnbynnau mwyaf eithafol i ni.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // Yn achos e>=0, mae'r ddau algorithm yn cyfrifo tua `f * 10^e`.
        // Mae Algorithm R yn mynd yn ei flaen i wneud rhai cyfrifiadau cymhleth gyda hyn ond gallwn anwybyddu hynny ar gyfer y rhwymiad uchaf oherwydd ei fod hefyd yn lleihau'r ffracsiwn ymlaen llaw, felly mae gennym ddigon o byffer yno.
        //
        f_len + (e as u64)
    } else {
        // Os yw e <0, mae Algorithm R yn gwneud yr un peth yn fras, ond mae Algorithm M yn wahanol:
        // Mae'n ceisio dod o hyd i rif positif k fel bod `f << k / 10^e` yn arwyddocâd mewn ystod.
        // Bydd hyn yn arwain at oddeutu `2^53 *f* 10^e` <`10^17 *f* 10^e`.
        // Un mewnbwn sy'n sbarduno hyn yw 0.33 ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// Yn canfod gorlifiadau a gorlifiadau amlwg heb hyd yn oed edrych ar y digidau degol.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // Roedd yna seroau ond cawsant eu tynnu gan simplify()
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // Brasamcan bras o ceil(log10(the real value)) yw hwn.
    // Nid oes angen i ni boeni gormod am orlif yma oherwydd bod y hyd mewnbwn yn fach (o leiaf o'i gymharu â 2 ^ 64) ac mae'r parser eisoes yn trin esbonwyr y mae eu gwerth absoliwt yn fwy na 10 ^ 18 (sy'n dal i fod 10 ^ 19 yn fyr o 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}