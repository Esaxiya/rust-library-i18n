//! Swyddogaethau cyfleustodau ar gyfer bignums nad ydynt yn gwneud gormod o synnwyr i droi yn ddulliau.

// FIXME Mae enw'r modiwl hwn ychydig yn anffodus, gan fod modiwlau eraill hefyd yn mewnforio `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Profwch a yw torri pob darn yn llai arwyddocaol na `ones_place` yn cyflwyno gwall cymharol llai, cyfartal neu fwy na 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Os yw'r holl ddarnau sy'n weddill yn sero, mae'n= 0.5 ULP, fel arall> 0.5 Os nad oes mwy o ddarnau (hanner_bit==0), mae'r isod hefyd yn dychwelyd Cyfartal yn gywir.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Yn trosi llinyn ASCII sy'n cynnwys digidau degol yn unig i `u64`.
///
/// Nid yw'n perfformio gwiriadau ar gyfer nodau gorlifo neu annilys, felly os nad yw'r galwr yn ofalus, mae'r canlyniad yn ffug ac yn gallu panic (er na fydd yn `unsafe`).
/// Yn ogystal, mae llinynnau gwag yn cael eu trin fel sero.
/// Mae'r swyddogaeth hon yn bodoli oherwydd
///
/// 1. mae defnyddio `FromStr` ar `&[u8]` yn gofyn am `from_utf8_unchecked`, sy'n ddrwg, a
/// 2. mae gosod canlyniadau `integral.parse()` a `fractional.parse()` gyda'i gilydd yn fwy cymhleth na'r swyddogaeth gyfan hon.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Trosi llinyn o ddigidau ASCII yn bignwm.
///
/// Fel `from_str_unchecked`, mae'r swyddogaeth hon yn dibynnu ar y parser i chwynnu di-ddigidau.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Dad-lapio bignwm i gyfanrif 64 did.Panics os yw'r nifer yn rhy fawr.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Yn tynnu ystod o ddarnau.

/// Mynegai 0 yw'r darn lleiaf arwyddocaol ac mae'r amrediad yn hanner agored fel arfer.
/// Panics os gofynnir iddo dynnu mwy o ddarnau nag sy'n ffitio i'r math dychwelyd.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}