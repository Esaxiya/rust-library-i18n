//! Dilysu a dadelfennu llinyn degol o'r ffurflen:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Mewn geiriau eraill, cystrawen pwynt arnofio safonol, gyda dau eithriad: Dim arwydd, a dim trin "inf" a "NaN".Mae'r rhain yn cael eu trin gan swyddogaeth gyrrwr (super::dec2flt).
//!
//! Er bod cydnabod mewnbynnau dilys yn gymharol hawdd, mae'n rhaid i'r modiwl hwn hefyd wrthod yr amrywiadau annilys dirifedi, byth panic, a pherfformio nifer o wiriadau y mae'r modiwlau eraill yn dibynnu arnynt i beidio â panic (neu orlif) yn eu tro.
//!
//! I wneud pethau'n waeth, popeth sy'n digwydd mewn un pas dros y mewnbwn.
//! Felly, byddwch yn ofalus wrth addasu unrhyw beth, a gwiriwch ddwywaith gyda'r modiwlau eraill.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Rhannau diddorol llinyn degol.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Yr esboniwr degol, y mae'n sicr y bydd ganddo lai na 18 digid degol.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Yn gwirio a yw'r llinyn mewnbwn yn rhif pwynt arnofio dilys ac os felly, lleolwch y rhan annatod, y rhan ffracsiynol, a'r esboniwr ynddo.
/// Nid yw'n trin arwyddion.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Dim digidau cyn 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Mae angen o leiaf un digid arnom cyn neu ar ôl y pwynt.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Sothach llusgo ar ôl rhan ffracsiynol
            }
        }
        _ => Invalid, // Sothach llusgo ar ôl y llinyn digid cyntaf
    }
}

/// Yn cerfio digidau degol hyd at y cymeriad digid cyntaf.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Echdynnu esboniwr a gwirio gwallau.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Sothach llusgo ar ôl esboniwr
    }
    if number.is_empty() {
        return Invalid; // Esboniwr gwag
    }
    // Ar y pwynt hwn, yn sicr mae gennym linyn dilys o ddigidau.Efallai y bydd yn rhy hir i'w roi mewn `i64`, ond os yw mor enfawr, mae'r mewnbwn yn sicr yn sero neu'n anfeidredd.
    // Gan fod pob sero yn y digidau degol yn addasu'r esboniwr erbyn +/-1 yn unig, ar exp=10 ^ 18 byddai'n rhaid i'r mewnbwn fod yn 17 exabyte (!) o sero er mwyn dod yn agos o bell i fod yn gyfyngedig.
    //
    // Nid yw hwn yn union achos defnydd y mae angen i ni ddarparu ar ei gyfer.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}