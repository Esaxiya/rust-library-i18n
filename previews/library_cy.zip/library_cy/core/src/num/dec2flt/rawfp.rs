//! Ffidlan did ar fflotiau IEEE 754 positif.Nid oes angen ac nid oes angen trin rhifau negyddol.
//! Mae gan rifau pwynt arnofio arferol gynrychiolaeth ganonaidd fel (frac, exp) fel bod y gwerth yn 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) lle mai N yw nifer y darnau.
//!
//! Mae subnormals ychydig yn wahanol ac yn rhyfedd, ond mae'r un egwyddor yn berthnasol.
//!
//! Yma, fodd bynnag, rydym yn eu cynrychioli fel (sig, k) gyda f positif, fel bod y gwerth yn f *
//! 2 <sup>e</sup> .Ar wahân i wneud yr "hidden bit" yn eglur, mae hyn yn newid yr esboniwr gan y shifft mantissa, fel y'i gelwir.
//!
//! Rhowch ffordd arall, fel rheol ysgrifennir fflotiau fel (1) ond yma fe'u hysgrifennir fel (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Rydym yn galw (1) yn **gynrychiolaeth ffracsiynol** a (2) yn **gynrychiolaeth annatod**.
//!
//! Mae llawer o swyddogaethau yn y modiwl hwn yn trin rhifau arferol yn unig.Mae'r arferion dec2flt yn geidwadol yn cymryd y llwybr araf sy'n gywir yn gyffredinol (Algorithm M) ar gyfer niferoedd bach iawn a mawr iawn.
//! Dim ond next_float() sydd ei angen ar yr algorithm hwnnw sy'n trin subnormals a sero.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Cynorthwyydd trait i osgoi dyblygu'r holl god trosi ar gyfer `f32` a `f64` yn y bôn.
///
/// Gweler sylw doc y modiwl rhiant am pam mae hyn yn angenrheidiol.
///
/// Oni ddylid gweithredu **byth** ar gyfer mathau eraill neu gael ei ddefnyddio y tu allan i'r modiwl dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Math a ddefnyddir gan `to_bits` a `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Yn perfformio trawsfudiad amrwd i gyfanrif.
    fn to_bits(self) -> Self::Bits;

    /// Yn perfformio trawsfudiad amrwd o gyfanrif.
    fn from_bits(v: Self::Bits) -> Self;

    /// Yn dychwelyd y categori y mae'r rhif hwn yn perthyn iddo.
    fn classify(self) -> FpCategory;

    /// Yn dychwelyd y mantissa, yr esboniwr a'i lofnodi fel cyfanrifau.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Yn dadgodio'r arnofio.
    fn unpack(self) -> Unpacked;

    /// Castiau o gyfanrif bach y gellir ei gynrychioli'n union.
    /// Panic os na ellir cynrychioli'r cyfanrif, mae'r cod arall yn y modiwl hwn yn sicrhau na fydd byth yn gadael i hynny ddigwydd.
    fn from_int(x: u64) -> Self;

    /// Yn cael y gwerth 10 <sup>e</sup> o dabl wedi'i gyfrifo ymlaen llaw.
    /// Panics ar gyfer `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Beth mae'r enw'n ei ddweud.
    /// Mae'n haws cod caled na jyglo cynhenid a gobeithio bod LLVM cyson yn ei blygu.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Ceidwadwr wedi'i rwymo ar ddigidau degol mewnbynnau na allant gynhyrchu gorlif na sero neu
    /// subnormals.Mae'n debyg mai esboniwr degol y gwerth arferol uchaf, a dyna'r enw.
    const MAX_NORMAL_DIGITS: usize;

    /// Pan fydd gan y digid degol mwyaf arwyddocaol werth lle sy'n fwy na hyn, mae'r nifer yn sicr wedi'i dalgrynnu i anfeidredd.
    ///
    const INF_CUTOFF: i64;

    /// Pan fydd gan y digid degol mwyaf arwyddocaol werth lle llai na hyn, mae'r nifer yn sicr wedi'i dalgrynnu i sero.
    ///
    const ZERO_CUTOFF: i64;

    /// Nifer y darnau yn yr esboniwr.
    const EXP_BITS: u8;

    /// Nifer y darnau yn yr arwyddocâd,*gan gynnwys* y darn cudd.
    const SIG_BITS: u8;

    /// Nifer y darnau yn yr arwyddocâd,*heb gynnwys* y darn cudd.
    const EXPLICIT_SIG_BITS: u8;

    /// Yr esboniwr cyfreithiol uchaf mewn cynrychiolaeth ffracsiynol.
    const MAX_EXP: i16;

    /// Yr esboniwr cyfreithiol lleiaf mewn cynrychiolaeth ffracsiynol, ac eithrio subnormals.
    const MIN_EXP: i16;

    /// `MAX_EXP` ar gyfer cynrychiolaeth annatod, hy, gyda'r shifft wedi'i chymhwyso.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` wedi'i amgodio (hy, gyda gogwydd gwrthbwyso)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` ar gyfer cynrychiolaeth annatod, hy, gyda'r shifft wedi'i chymhwyso.
    const MIN_EXP_INT: i16;

    /// Yr arwyddocâd normaleiddiedig uchaf mewn cynrychiolaeth annatod.
    const MAX_SIG: u64;

    /// Yr arwyddocâd normaleiddiedig lleiaf posibl mewn cynrychiolaeth annatod.
    const MIN_SIG: u64;
}

// Gweithred ar gyfer #34344 yn bennaf.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Yn dychwelyd y mantissa, yr esboniwr a'i lofnodi fel cyfanrifau.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Tuedd esboniwr + shifft mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // mae rkruppe yn ansicr a yw `as` yn rowndio'n gywir ar bob platfform.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Yn dychwelyd y mantissa, yr esboniwr a'i lofnodi fel cyfanrifau.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Tuedd esboniwr + shifft mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // mae rkruppe yn ansicr a yw `as` yn rowndio'n gywir ar bob platfform.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Yn trosi `Fp` i'r math arnofio peiriant agosaf.
/// Nid yw'n trin canlyniadau isnormal.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f yn 64 did, felly mae gan xe shifft mantissa o 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Talgrynnwch y darnau arwyddocaol 64-did i ddarnau T::SIG_BITS gyda hanner-hyd yn oed.
/// Nid yw'n trin gorlif esboniwr.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Addasu shifft mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Gwrthdro `RawFloat::unpack()` ar gyfer rhifau wedi'u normaleiddio.
/// Panics os nad yw'r arwyddocâd neu'r esboniwr yn ddilys ar gyfer rhifau wedi'u normaleiddio.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Tynnwch y darn cudd
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Addaswch yr esboniwr ar gyfer gogwydd esboniwr a shifft mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Gadewch y darn arwydd ar 0 ("+"), mae ein niferoedd i gyd yn bositif
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Adeiladu isnormal.Caniateir mantissa o 0 ac mae'n adeiladu sero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Esboniwr wedi'i amgodio yw 0, y did arwydd yw 0, felly mae'n rhaid i ni ail-ddehongli'r darnau.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Tua bignwm gyda Fp.Rowndiau o fewn 0.5 ULP gyda hanner-hyd yn oed.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Rydym yn torri'r holl ddarnau cyn y mynegai `start`, hy, rydym i bob pwrpas yn symud i'r dde gan swm o `start`, felly dyma'r esboniwr sydd ei angen arnom hefyd.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Rownd (half-to-even) yn dibynnu ar y darnau cwtog.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Yn dod o hyd i'r rhif pwynt arnofio mwyaf yn hollol llai na'r ddadl.
/// Nid yw'n trin subnormals, sero, neu orlif esboniwr.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Dewch o hyd i'r rhif pwynt arnofio lleiaf yn hollol fwy na'r ddadl.
// Mae'r llawdriniaeth hon yn dirlawn, hy, next_float(inf) ==inf.
// Yn wahanol i'r rhan fwyaf o god yn y modiwl hwn, mae'r swyddogaeth hon yn trin sero, is-hormonau ac anfeidredd.
// Fodd bynnag, fel pob cod arall yma, nid yw'n delio â NaN a rhifau negyddol.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Mae hyn yn ymddangos yn rhy dda i fod yn wir, ond mae'n gweithio.
        // 0.0 wedi'i amgodio fel y gair holl-sero.Mae isnormalau yn 0x000m ... m lle mai m yw'r mantissa.
        // Yn benodol, yr isnormal lleiaf yw 0x0 ... 01 a'r mwyaf yw 0x000F ... F.
        // Y rhif arferol lleiaf yw 0x0010 ... 0, felly mae'r achos cornel hwn yn gweithio hefyd.
        // Os yw'r cynyddiad yn gorlifo'r mantissa, mae'r did cario yn cynyddu'r esboniwr fel y dymunwn, ac mae'r darnau mantissa yn dod yn sero.
        // Oherwydd y confensiwn did cudd, dyma hefyd yr union beth yr ydym ei eisiau!
        // Yn olaf, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}