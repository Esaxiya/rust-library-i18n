//! Yr algorithmau amrywiol o'r papur.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Nifer y darnau arwyddocaol yn Fp
const P: u32 = 64;

// Yn syml, rydym yn storio'r brasamcan gorau ar gyfer *pob* esboniwr, felly gellir hepgor y newidyn "h" a'r amodau cysylltiedig.
// Mae hyn yn masnachu perfformiad ar gyfer cwpl cilobeit o le.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Yn y rhan fwyaf o bensaernïaeth, mae gan weithrediadau pwynt arnofio faint did penodol, felly mae manwl gywirdeb y cyfrifiant yn cael ei bennu ar sail pob gweithrediad.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Ar x86, defnyddir yr x87 FPU ar gyfer gweithrediadau arnofio os nad yw'r estyniadau SSE/SSE2 ar gael.
// Mae'r x87 FPU yn gweithredu gydag 80 darn o gywirdeb yn ddiofyn, sy'n golygu y bydd gweithrediadau'n talgrynnu i 80 darn gan achosi i dalgrynnu dwbl ddigwydd pan fydd gwerthoedd yn cael eu cynrychioli yn y pen draw fel
//
// 32/64 gwerthoedd arnofio did.Er mwyn goresgyn hyn, gellir gosod y gair rheoli FPU fel bod y cyfrifiannau'n cael eu perfformio yn y manwl gywirdeb a ddymunir.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Strwythur a ddefnyddir i gadw gwerth gwreiddiol y gair rheoli FPU, fel y gellir ei adfer pan ollyngir y strwythur.
    ///
    ///
    /// Mae'r x87 FPU yn gofrestr 16 darn y mae ei feysydd fel a ganlyn:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Mae'r ddogfennaeth ar gyfer yr holl feysydd ar gael yn Llawlyfr Datblygwr Meddalwedd Pensaernïaeth IA-32 (Cyfrol 1).
    ///
    /// Yr unig faes sy'n berthnasol ar gyfer y cod canlynol yw PC, Precision Control.
    /// Mae'r maes hwn yn pennu manwl gywirdeb y gweithrediadau a gyflawnir gan yr FPU.
    /// Gellir ei osod i:
    ///  - 0b00, manwl gywirdeb sengl hy, 32 darn
    ///  - 0b10, manwl gywirdeb dwbl hy, 64-darn
    ///  - 0b11, manwl gywirdeb estynedig hy, 80 darn (cyflwr diofyn) Mae'r gwerth 0b01 wedi'i gadw ac ni ddylid ei ddefnyddio.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // DIOGELWCH: archwiliwyd y cyfarwyddyd `fldcw` i allu gweithio'n gywir gydag ef
        // unrhyw `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Rydym yn defnyddio cystrawen ATT i gefnogi LLVM 8 a LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Yn gosod maes manwl gywirdeb yr FPU i `T` ac yn dychwelyd `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Cyfrifwch y gwerth ar gyfer y maes Rheoli Manwl sy'n briodol ar gyfer `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 darn
            8 => 0x0200, // 64 darn
            _ => 0x0300, // diofyn, 80 darn
        };

        // Sicrhewch werth gwreiddiol y gair rheoli i'w adfer yn ddiweddarach, pan fydd y strwythur `FPUControlWord` yn cael ei ollwng DIOGELWCH: archwiliwyd y cyfarwyddyd `fnstcw` i allu gweithio'n gywir gydag unrhyw `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Rydym yn defnyddio cystrawen ATT i gefnogi LLVM 8 a LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Gosodwch y gair rheoli i'r manwl gywirdeb a ddymunir.
        // Cyflawnir hyn trwy guddio'r hen gywirdeb (darnau 8 a 9, 0x300) a rhoi y faner fanwl a gyfrifir uchod yn ei lle.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Llwybr cyflym Bellerophon gan ddefnyddio cyfanrifau a fflotiau maint peiriant.
///
/// Mae hwn yn cael ei dynnu i mewn i swyddogaeth ar wahân fel y gellir rhoi cynnig arno cyn llunio bignwm.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Rydyn ni'n cymharu'r union werth â MAX_SIG yn agos at y diwedd, dim ond gwrthodiad cyflym, rhad yw hwn (ac mae hefyd yn rhyddhau gweddill y cod rhag poeni am danlif).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Mae'r llwybr cyflym yn dibynnu'n hanfodol ar rifyddeg yn cael ei dalgrynnu i'r nifer cywir o ddarnau heb unrhyw dalgrynnu canolradd.
    // Ar x86 (heb SSE na SSE2) mae hyn yn ei gwneud yn ofynnol i gywirdeb y pentwr x87 FPU gael ei newid fel ei fod yn talgrynnu'n uniongyrchol i did 64/32.
    // Mae swyddogaeth `set_precision` yn gofalu am osod y manwl gywirdeb ar bensaernïaeth sy'n gofyn am ei osod trwy newid y wladwriaeth fyd-eang (fel gair rheoli'r x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Ni ellir plygu'r achos e <0 i'r branch arall.
    // Mae pwerau negyddol yn arwain at ailadrodd rhan ffracsiynol mewn deuaidd, sy'n cael ei dalgrynnu, sy'n achosi gwallau go iawn (ac weithiau'n eithaf sylweddol!) Yn y canlyniad terfynol.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Cod dibwys yw Algorithm Bellerophon y gellir ei gyfiawnhau gan ddadansoddiad rhifol dibwys.
///
/// Mae'n rowndio ``f`` i arnofio gyda arwyddocâd 64 did ac yn ei luosi â'r brasamcan gorau o `10^e` (yn yr un fformat pwynt arnofio).Mae hyn yn aml yn ddigon i gael y canlyniad cywir.
/// Fodd bynnag, pan fydd y canlyniad yn agos at hanner ffordd rhwng dau fflôt (ordinary) cyfagos, mae'r gwall talgrynnu cyfansawdd o luosi dau frasamcan yn golygu y gall y canlyniad fod ychydig o ddarnau i ffwrdd.
/// Pan fydd hyn yn digwydd, mae'r Algorithm ailadroddol R yn trwsio pethau.
///
/// Gwneir y "close to halfway" tonnog llaw yn fanwl gywir gan y dadansoddiad rhifol yn y papur.
/// Yng ngeiriau Clinger:
///
/// > Mae llethr, wedi'i fynegi mewn unedau o'r darn lleiaf arwyddocaol, yn rhwym cynhwysol am y gwall
/// > wedi'i gronni yn ystod cyfrifiad pwynt arnofio y brasamcan i f * 10 ^ e.(Mae llethr yn
/// > nid yn rhwym ar gyfer y gwir wall, ond mae'n cyfyngu'r gwahaniaeth rhwng y brasamcan z a
/// > y brasamcan gorau posibl sy'n defnyddio darnau p o arwyddocâd.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Mae'r achosion abs(e) <log5(2^N) yn fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // A yw'r llethr yn ddigon mawr i wneud gwahaniaeth wrth dalgrynnu i ddarnau?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Algorithm ailadroddol sy'n gwella brasamcan pwynt arnofio o `f * 10^e`.
///
/// Mae pob iteriad yn cael un uned yn y lle olaf yn agosach, sydd wrth gwrs yn cymryd amser ofnadwy o hir i gydgyfeirio os yw `z0` hyd yn oed yn ysgafn i ffwrdd.
/// Yn ffodus, pan gaiff ei ddefnyddio fel cwymp wrth gefn ar gyfer Bellerophon, mae'r brasamcan cychwynnol i ffwrdd gan un ULP ar y mwyaf.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Dewch o hyd i gyfanrifau positif `x`, `y` fel bod `x / y` yn union `(f *10^e) / (m* 2^k)`.
        // Mae hyn nid yn unig yn osgoi delio ag arwyddion `e` a `k`, rydym hefyd yn dileu pŵer dau sy'n gyffredin i `10^e` a `2^k` i wneud y niferoedd yn llai.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Mae hyn wedi'i ysgrifennu ychydig yn lletchwith oherwydd nad yw ein bignums yn cefnogi rhifau negyddol, felly rydyn ni'n defnyddio'r wybodaeth werth absoliwt + arwydd.
        // Ni all y lluosi â m_digits orlifo.
        // Os yw `x` neu `y` yn ddigon mawr bod angen i ni boeni am orlif, yna maent hefyd yn ddigon mawr bod `make_ratio` wedi lleihau'r ffracsiwn gan ffactor o 2 ^ 64 neu fwy.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Peidiwch â bod angen x mwy, arbed clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Dal angen y, gwnewch gopi.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// O ystyried `x = f` a `y = m` lle mae `f` yn cynrychioli digidau degol mewnbwn fel arfer a `m` yw arwyddocâd brasamcan pwynt arnofio, gwnewch y gymhareb `x / y` yn hafal i `(f *10^e) / (m* 2^k)`, wedi'i lleihau o bosibl gan bŵer dau sydd gan y ddau yn gyffredin.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, heblaw ein bod yn lleihau'r ffracsiwn gan ryw bwer o ddau.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Ni all hyn orlifo oherwydd bod angen `e` positif a `k` negyddol arno, a all ddigwydd dim ond ar gyfer gwerthoedd sy'n agos iawn at 1, sy'n golygu y bydd `e` a `k` yn gymharol fach.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Ni all hyn orlifo chwaith, gweler uchod.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), gan leihau eto gan bŵer cyffredin o ddau.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Yn gysyniadol, Algorithm M yw'r ffordd symlaf o drosi degol yn arnofio.
///
/// Rydym yn ffurfio cymhareb sy'n hafal i `f * 10^e`, ac yna'n taflu pwerau dau nes ei bod yn rhoi arwyddocâd arnofio dilys.
/// Yr esboniwr deuaidd `k` yw'r nifer o weithiau y gwnaethom luosi rhifiadur neu enwadur â dau, hy, mae `f *10^e` bob amser yn hafal i `(u / v)* 2^k`.
/// Pan fyddwn wedi darganfod arwyddocâd, dim ond trwy archwilio gweddill yr is-adran y mae angen i ni dalgrynnu, a wneir mewn swyddogaethau cynorthwyydd ymhellach isod.
///
///
/// Mae'r algorithm hwn yn araf iawn, hyd yn oed gyda'r optimeiddio a ddisgrifir yn `quick_start()`.
/// Fodd bynnag, dyma'r symlaf o'r algorithmau i'w haddasu ar gyfer canlyniadau gorlifo, gorlifo ac isnormal.
/// Mae'r gweithrediad hwn yn cymryd drosodd pan fydd Bellerophon ac Algorithm R wedi'u gorlethu.
/// Mae'n hawdd canfod gorlif a gorlif: Nid yw'r gymhareb yn arwyddocâd mewn ystod o hyd, ac eto mae'r esboniwr minimum/maximum wedi'i gyrraedd.
/// Yn achos gorlif, rydym yn syml yn dychwelyd anfeidredd.
///
/// Mae trin tanlif ac isnormalau yn anoddach.
/// Un broblem fawr yw, gyda'r esboniad lleiaf, y gallai'r gymhareb fod yn rhy fawr o hyd ar gyfer arwyddocâd.
/// Gweler underflow() am fanylion.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Optimeiddio posibl FIXME: cyffredinoli big_to_fp fel y gallwn wneud yr hyn sy'n cyfateb i fp_to_float(big_to_fp(u)) yma, dim ond heb y talgrynnu dwbl.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Mae'n rhaid i ni stopio ar yr esboniwr lleiaf, os arhoswn tan `k < T::MIN_EXP_INT`, yna byddem i ffwrdd â ffactor o ddau.
            // Yn anffodus mae hyn yn golygu bod yn rhaid i ni rifo rhifau arferol gyda'r esboniwr lleiaf.
            // FIXME dod o hyd i fformiwleiddiad mwy cain, ond rhedeg y prawf `tiny-pow10` i sicrhau ei fod yn gywir mewn gwirionedd!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Sgipiau dros y rhan fwyaf o iteriadau Algorithm M trwy wirio hyd y did.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Mae hyd y did yn amcangyfrif o'r logarithm sylfaen dau, a log(u / v) = log(u), log(v).
    // Mae'r amcangyfrif i ffwrdd o 1 ar y mwyaf, ond tanamcangyfrif bob amser, felly mae'r gwall ar log(u) a log(v) o'r un arwydd ac yn canslo (os yw'r ddau yn fawr).
    // Felly mae'r gwall ar gyfer log(u / v) yn un ar y mwyaf hefyd.
    // Y gymhareb darged yw un lle mae u/v mewn arwyddocâd mewn ystod.Felly ein cyflwr terfynu yw log2(u / v) yw'r darnau arwyddocâd, plus/minus un.
    // FIXME Gallai edrych ar yr ail ddarn wella'r amcangyfrif ac osgoi mwy o raniadau.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Dan-lif neu isnormal.Gadewch ef i'r brif swyddogaeth.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Gorlif.Gadewch ef i'r brif swyddogaeth.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Nid yw'r gymhareb yn arwyddocâd mewn ystod ac â'r esboniwr lleiaf, felly mae angen i ni dalgrynnu darnau gormodol ac addasu'r esboniwr yn unol â hynny.
    // Mae'r gwir werth nawr yn edrych fel hyn:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(wedi'i gynrychioli gan rem)
    //
    // Felly, pan fo'r darnau talgrynnu!= 0.5 ULP, maen nhw'n penderfynu ar y talgrynnu ar eu pennau eu hunain.
    // Pan fyddant yn gyfartal a'r gweddill yn ddi-sero, mae angen talgrynnu'r gwerth o hyd.
    // Dim ond pan fydd y darnau crwn yn 1/2 a'r gweddill yn sero, mae gennym ni sefyllfa hanner-hyd yn oed.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Rownd-hyd yn oed arferol, wedi'i rwystro trwy orfod talgrynnu yn seiliedig ar weddill rhaniad.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}