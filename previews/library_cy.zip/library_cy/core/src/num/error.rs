//! Mathau gwall i'w trosi i fathau annatod.

use crate::convert::Infallible;
use crate::fmt;

/// Dychwelodd y math gwall pan fydd trosiad math annatod wedi'i wirio yn methu.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Cydweddwch yn hytrach na gorfodi i sicrhau y bydd cod fel `From<Infallible> for TryFromIntError` uchod yn parhau i weithio pan ddaw `Infallible` yn alias i `!`.
        //
        //
        match never {}
    }
}

/// Gwall y gellir ei ddychwelyd wrth dosrannu cyfanrif.
///
/// Defnyddir y gwall hwn fel y math gwall ar gyfer swyddogaethau `from_str_radix()` ar y mathau cyfanrif cyntefig, megis [`i8::from_str_radix`].
///
/// # Achosion posib
///
/// Ymhlith achosion eraill, gellir taflu `ParseIntError` oherwydd arwain neu dreilio gofod gwyn yn y llinyn ee, pan geir ef o'r mewnbwn safonol.
///
/// Mae defnyddio'r dull [`str::trim()`] yn sicrhau nad oes unrhyw le gwyn yn aros cyn dosrannu.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum i storio'r gwahanol fathau o wallau a all beri i dosrannu cyfanrif fethu.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Mae'r gwerth sy'n cael ei dosrannu yn wag.
    ///
    /// Ymhlith achosion eraill, bydd yr amrywiad hwn yn cael ei adeiladu wrth dosrannu llinyn gwag.
    Empty,
    /// Yn cynnwys digid annilys yn ei gyd-destun.
    ///
    /// Ymhlith achosion eraill, bydd yr amrywiad hwn yn cael ei adeiladu wrth dosrannu llinyn sy'n cynnwys torgoch nad yw'n ASCII.
    ///
    /// Mae'r amrywiad hwn hefyd yn cael ei adeiladu pan fydd `+` neu `-` yn cael ei gamosod o fewn llinyn naill ai ar ei ben ei hun neu yng nghanol rhif.
    ///
    ///
    InvalidDigit,
    /// Mae cyfanrif yn rhy fawr i'w storio yn y math cyfanrif targed.
    PosOverflow,
    /// Mae cyfanrif yn rhy fach i'w storio yn y math cyfanrif targed.
    NegOverflow,
    /// Gwerth oedd Zero
    ///
    /// Bydd yr amrywiad hwn yn cael ei ollwng pan fydd gan y llinyn dosrannu werth o sero, a fyddai'n anghyfreithlon ar gyfer mathau nad ydynt yn sero.
    ///
    Zero,
}

impl ParseIntError {
    /// Yn allbynnu achos manwl dosrannu cyfanrif yn methu.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}