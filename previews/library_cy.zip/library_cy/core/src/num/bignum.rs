//! Gweithredu rhif mympwyol-fanwl (bignum) wedi'i deilwra.
//!
//! Mae hyn wedi'i gynllunio i osgoi dyraniad y domen ar draul cof pentwr.
//! Mae'r math bignwm a ddefnyddir fwyaf, `Big32x40`, wedi'i gyfyngu gan 32 × 40=1,280 darn a bydd yn cymryd 160 beit o gof pentwr ar y mwyaf.
//! Mae hyn yn fwy na digon ar gyfer baglu rownd yr holl werthoedd `f64` cyfyngedig posibl.
//!
//! Mewn egwyddor mae'n bosibl cael sawl math bignwm ar gyfer gwahanol fewnbynnau, ond nid ydym yn gwneud hynny er mwyn osgoi'r cod yn chwyddo.
//!
//! Mae pob bignwm yn dal i gael ei olrhain ar gyfer y defnyddiau go iawn, felly nid oes ots fel rheol.
//!

// Mae'r modiwl hwn ar gyfer dec2flt a flt2dec yn unig, ac yn gyhoeddus yn unig oherwydd profion craidd.
// Ni fwriedir iddo gael ei sefydlogi byth.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Gweithrediadau rhifyddeg sy'n ofynnol gan bignums.
pub trait FullOps: Sized {
    /// Yn dychwelyd `(carry', v')` fel bod `carry' * 2^W + v' = self + other + carry`, lle `W` yw nifer y darnau yn `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Yn dychwelyd `(carry', v')` fel bod `carry'*2^W + v' = self* other + carry`, lle `W` yw nifer y darnau yn `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Yn dychwelyd `(carry', v')` fel bod `carry'*2^W + v' = self* other + other2 + carry`, lle `W` yw nifer y darnau yn `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Yn dychwelyd `(quo, rem)` fel bod `borrow *2^W + self = quo* other + rem` a `0 <= rem < other`, lle `W` yw nifer y darnau yn `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Ni all hyn orlifo;mae'r allbwn rhwng `0` a `2 * 2^nbits - 1`.
                    // FIXME: a fydd LLVM yn gwneud y gorau o hyn i ADC neu debyg?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Ni all hyn orlifo;
                    // mae'r allbwn rhwng `0` a `2^nbits * (2^nbits - 1)`.
                    // FIXME: a fydd LLVM yn gwneud y gorau o hyn i ADC neu debyg?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Ni all hyn orlifo;
                    // mae'r allbwn rhwng `0` a `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Ni all hyn orlifo;mae'r allbwn rhwng `0` a `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Gweler RFC #521 i alluogi hyn.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Tabl o bwerau 5 y gellir eu cynrychioli mewn digidau.Yn benodol, y gwerth {u8, u16, u32} mwyaf sy'n bwer o bump, ynghyd â'r esboniwr cyfatebol.
/// Defnyddir yn `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Cyfanrif mympwyol-fanwl fympwyol (hyd at derfyn penodol).
        ///
        /// Ategir hyn gan amrywiaeth maint sefydlog o fath penodol ("digit").
        /// Er nad yw'r arae yn fawr iawn (rhyw gant beit fel arfer), gall ei chopïo'n ddi-hid arwain at y perfformiad.
        ///
        /// Felly nid yw hyn yn fwriadol nid `Copy`.
        ///
        /// Yr holl weithrediadau sydd ar gael i bignums panic yn achos gorlifo.
        /// Mae'r galwr yn gyfrifol am ddefnyddio mathau bignwm digon mawr.
        pub struct $name {
            /// Un ynghyd â'r gwrthbwyso i'r uchafswm "digit" sy'n cael ei ddefnyddio.
            /// Nid yw hyn yn lleihau, felly byddwch yn ymwybodol o'r gorchymyn cyfrifiant.
            /// `base[size..]` dylai fod yn sero.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` yn cynrychioli `a + b *2^W + c* 2^(2W) + ...` lle `W` yw nifer y darnau yn y math digid.
            base: [$ty; $n],
        }

        impl $name {
            /// Yn gwneud bignwm o un digid.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Yn gwneud bignwm o werth `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Yn dychwelyd y digidau mewnol fel sleisen `[a, b, c, ...]` fel mai'r gwerth rhifol yw `a + b *2^W + c* 2^(2W) + ...` lle `W` yw nifer y darnau yn y math digid.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Yn dychwelyd y darn `i`-th lle mai did 0 yw'r un lleiaf arwyddocaol.
            /// Mewn geiriau eraill, y darn â phwysau `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Yn dychwelyd `true` os yw'r bignwm yn sero.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Yn dychwelyd nifer y darnau sy'n angenrheidiol i gynrychioli'r gwerth hwn.
            /// Sylwch yr ystyrir bod angen 0 darn ar sero.
            pub fn bit_length(&self) -> usize {
                // Neidio dros y digidau mwyaf arwyddocaol sy'n sero.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Nid oes unrhyw ddigidau nad ydynt yn sero, hy, y nifer yw sero.
                    return 0;
                }
                // Gellid optimeiddio hyn gyda sifftiau leading_zeros() a did, ond mae'n debyg nad yw hynny'n werth y drafferth.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Yn ychwanegu `other` ato'i hun ac yn dychwelyd ei gyfeirnod symudol ei hun.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Yn tynnu `other` ohono'i hun ac yn dychwelyd ei gyfeirnod symudol ei hun.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Yn lluosi ei hun â `other` maint digid ac yn dychwelyd ei gyfeirnod symudol ei hun.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Yn lluosi ei hun â `2^bits` ac yn dychwelyd ei gyfeirnod symudol ei hun.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // shifft gan ddarnau `digits * digitbits`
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // shifft gan ddarnau `bits`
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // mae hunan.base [.. digidau] yn sero, nid oes angen symud
                }

                self.size = sz;
                self
            }

            /// Yn lluosi ei hun â `5^e` ac yn dychwelyd ei gyfeirnod symudol ei hun.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Mae union n sero yn llusgo ar 2 ^ n, a'r unig feintiau digid perthnasol yw pwerau olynol o ddau, felly mae hwn yn fynegai addas ar gyfer y tabl.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Lluoswch â'r pŵer un digid mwyaf cyhyd ag y bo modd ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... yna gorffen y gweddill.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Yn lluosi ei hun â rhif a ddisgrifir gan `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (lle `W` yw nifer y darnau yn y math digid) ac yn dychwelyd ei gyfeirnod treiddgar ei hun.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // y drefn fewnol.yn gweithio orau pan fydd aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Yn rhannu ei hun â `other` maint digid ac yn dychwelyd ei gyfeirnod treiddgar ei hun *a* y gweddill.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Rhannwch eich hun â bignwm arall, gan drosysgrifo `q` gyda'r cyniferydd a `r` gyda'r gweddill.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Rhaniad araf araf base-2 wedi'i gymryd o
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME defnyddio sylfaen fwy ($ty) ar gyfer y rhaniad hir.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Gosod did `i` o q i 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Y math digid ar gyfer `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// defnyddir yr un hon ar gyfer profi yn unig.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}