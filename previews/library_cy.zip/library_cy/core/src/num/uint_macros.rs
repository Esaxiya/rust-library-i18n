macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Y gwerth lleiaf y gellir ei gynrychioli gan y math cyfanrif hwn.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Y gwerth mwyaf y gellir ei gynrychioli gan y math cyfanrif hwn.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Maint y math cyfanrif hwn mewn darnau.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Trosi sleisen llinyn mewn sylfaen benodol yn gyfanrif.
        ///
        /// Disgwylir i'r llinyn fod yn arwydd `+` dewisol ac yna digidau.
        ///
        /// Mae gofod gwyn arweiniol a llusgo yn cynrychioli gwall.
        /// Mae digidau yn is-set o'r cymeriadau hyn, yn dibynnu ar `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Mae'r swyddogaeth hon panics os nad yw `radix` yn yr ystod o 2 i 36.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Yn dychwelyd nifer y rhai yng nghynrychiolaeth ddeuaidd `self`.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Yn dychwelyd nifer y seroau yng nghynrychiolaeth ddeuaidd `self`.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Yn dychwelyd nifer y seroau blaenllaw yng nghynrychiolaeth ddeuaidd `self`.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Yn dychwelyd nifer y seroau llusgo yng nghynrychiolaeth ddeuaidd `self`.
        ///
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Yn dychwelyd nifer y rhai blaenllaw yng nghynrychiolaeth ddeuaidd `self`.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Yn dychwelyd nifer y rhai sy'n llusgo yng nghynrychiolaeth ddeuaidd `self`.
        ///
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Yn symud y darnau i'r chwith gan swm penodol, `n`, gan lapio'r darnau cwtog i ddiwedd y cyfanrif sy'n deillio o hynny.
        ///
        ///
        /// Sylwch nad dyma'r un gweithrediad â'r gweithredwr symud `<<`!
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Yn symud y darnau i'r dde gan swm penodol, `n`, gan lapio'r darnau cwtog i ddechrau'r cyfanrif sy'n deillio o hynny.
        ///
        ///
        /// Sylwch nad dyma'r un gweithrediad â'r gweithredwr symud `>>`!
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Yn gwrthdroi trefn beit y cyfanrif.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// gadewch m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Yn gwrthdroi trefn y darnau yn y cyfanrif.
        /// Y did lleiaf arwyddocaol yw'r darn mwyaf arwyddocaol, yr ail ddarn lleiaf arwyddocaol yn dod yn ail ddarn mwyaf arwyddocaol, ac ati.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// gadewch m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Yn trosi cyfanrif o endian mawr i barhad y targed.
        ///
        /// Ar endian mawr mae hwn yn no-op.
        /// Ar endian bach mae'r beit yn cael eu cyfnewid.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// os cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } arall {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Yn trosi cyfanrif o ychydig o endian i barhad y targed.
        ///
        /// Ar endian bach mae hwn yn no-op.
        /// Ar endian mawr mae'r beit yn cael eu cyfnewid.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// os cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } arall {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Trosi `self` i endian mawr o barhad y targed.
        ///
        /// Ar endian mawr mae hwn yn no-op.
        /// Ar endian bach mae'r beit yn cael eu cyfnewid.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// os cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } arall { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // neu i beidio â bod?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Yn trosi `self` i fod yn endian bach o barhad y targed.
        ///
        /// Ar endian bach mae hwn yn no-op.
        /// Ar endian mawr mae'r beit yn cael eu cyfnewid.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// os cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } arall { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Ychwanegiad cyfanrif wedi'i wirio.
        /// Yn cywasgu `self + rhs`, gan ddychwelyd `None` pe bai gorlif yn digwydd.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ychwanegiad cyfanrif heb ei wirio.Yn cywasgu `self + rhs`, gan dybio na all gorlif ddigwydd.
        /// Mae hyn yn arwain at ymddygiad heb ei ddiffinio pan
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Tynnu cyfanrif wedi'i wirio.
        /// Yn cywasgu `self - rhs`, gan ddychwelyd `None` pe bai gorlif yn digwydd.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tynnu cyfanrif heb ei wirio.Yn cywasgu `self - rhs`, gan dybio na all gorlif ddigwydd.
        /// Mae hyn yn arwain at ymddygiad heb ei ddiffinio pan
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Gwiriad lluosi cyfanrif.
        /// Yn cywasgu `self * rhs`, gan ddychwelyd `None` pe bai gorlif yn digwydd.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Lluosi cyfanrif heb ei wirio.Yn cywasgu `self * rhs`, gan dybio na all gorlif ddigwydd.
        /// Mae hyn yn arwain at ymddygiad heb ei ddiffinio pan
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // DIOGELWCH: rhaid i'r galwr gynnal y contract diogelwch ar gyfer `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Rhaniad cyfanrif wedi'i wirio.
        /// Yn cywasgu `self / rhs`, gan ddychwelyd `None` os `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // DIOGELWCH: gwiriwyd div â sero uchod ac nid oes gan fathau heb eu llofnodi unrhyw un arall
                // dulliau methu ar gyfer rhannu
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Is-adran Ewclidaidd wedi'i gwirio.
        /// Yn cywasgu `self.div_euclid(rhs)`, gan ddychwelyd `None` os `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Gweddill cyfanrif wedi'i wirio.
        /// Yn cywasgu `self % rhs`, gan ddychwelyd `None` os `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // DIOGELWCH: gwiriwyd div â sero uchod ac nid oes gan fathau heb eu llofnodi unrhyw un arall
                // dulliau methu ar gyfer rhannu
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Gwiriwyd modulo Ewclidaidd.
        /// Yn cywasgu `self.rem_euclid(rhs)`, gan ddychwelyd `None` os `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Gwiriad negyddu.Yn cywasgu `-self`, gan ddychwelyd `None` oni bai bod `hunan==
        /// 0`.
        ///
        /// Sylwch y bydd negyddu unrhyw gyfanrif positif yn gorlifo.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Sifft wedi'i wirio i'r chwith.
        /// Yn cywasgu `self << rhs`, gan ddychwelyd `None` os yw `rhs` yn fwy na neu'n hafal i nifer y darnau yn `self`.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Gwiriwyd y shifft yn iawn.
        /// Yn cywasgu `self >> rhs`, gan ddychwelyd `None` os yw `rhs` yn fwy na neu'n hafal i nifer y darnau yn `self`.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Gwiriad esboniad.
        /// Yn cywasgu `self.pow(exp)`, gan ddychwelyd `None` pe bai gorlif yn digwydd.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // ers exp!=0, yn olaf rhaid i'r exp fod yn 1.
            // Deliwch â darn olaf yr esboniwr ar wahân, gan nad yw sgwario'r sylfaen wedi hynny yn angenrheidiol a gallai achosi gorlif diangen.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Ychwanegiad dirlawn cyfanrif.
        /// Yn cywasgu `self + rhs`, yn dirlawn ar y ffiniau rhifol yn lle gorlifo.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Tynnu cyfanrif dirlawn.
        /// Yn cywasgu `self - rhs`, yn dirlawn ar y ffiniau rhifol yn lle gorlifo.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Lluosi cyfanrif cyfanrif.
        /// Yn cywasgu `self * rhs`, yn dirlawn ar y ffiniau rhifol yn lle gorlifo.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Dirywiad esboniad cyfanrif.
        /// Yn cywasgu `self.pow(exp)`, yn dirlawn ar y ffiniau rhifol yn lle gorlifo.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Lapio ychwanegiad (modular).
        /// Yn cywasgu `self + rhs`, gan lapio o gwmpas ar ffin y math.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Lapio tynnu (modular).
        /// Yn cywasgu `self - rhs`, gan lapio o gwmpas ar ffin y math.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Lapio lluosi (modular).
        /// Yn cywasgu `self * rhs`, gan lapio o gwmpas ar ffin y math.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// Sylwch fod yr enghraifft hon yn cael ei rhannu rhwng mathau cyfanrif.
        /// Sy'n esbonio pam mae `u8` yn cael ei ddefnyddio yma.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Lapio adran (modular).Computes `self / rhs`.
        /// Rhaniad arferol yn unig yw rhaniad wedi'i lapio ar fathau heb eu llofnodi.
        /// Nid oes unrhyw ffordd y gallai lapio ddigwydd byth.
        /// Mae'r swyddogaeth hon yn bodoli, fel bod cyfrif am yr holl weithrediadau yn y gweithrediadau lapio.
        ///
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Lapio adran Ewclidaidd.Computes `self.div_euclid(rhs)`.
        /// Rhaniad arferol yn unig yw rhaniad wedi'i lapio ar fathau heb eu llofnodi.
        /// Nid oes unrhyw ffordd y gallai lapio ddigwydd byth.
        /// Mae'r swyddogaeth hon yn bodoli, fel bod cyfrif am yr holl weithrediadau yn y gweithrediadau lapio.
        /// Gan fod yr holl ddiffiniadau cyffredin o rannu yn gyfartal ar gyfer y cyfanrifau positif, mae hyn yn union hafal i `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Lapio gweddill (modular).Computes `self % rhs`.
        /// Dim ond y cyfrifiad gweddill rheolaidd yw'r cyfrifiad gweddill wedi'i lapio ar fathau heb eu llofnodi.
        ///
        /// Nid oes unrhyw ffordd y gallai lapio ddigwydd byth.
        /// Mae'r swyddogaeth hon yn bodoli, fel bod cyfrif am yr holl weithrediadau yn y gweithrediadau lapio.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Lapio modulo Ewclidaidd.Computes `self.rem_euclid(rhs)`.
        /// Dim ond y cyfrifiad gweddill rheolaidd yw'r cyfrifiad modulo wedi'i lapio ar fathau heb eu llofnodi.
        /// Nid oes unrhyw ffordd y gallai lapio ddigwydd byth.
        /// Mae'r swyddogaeth hon yn bodoli, fel bod cyfrif am yr holl weithrediadau yn y gweithrediadau lapio.
        /// Gan fod yr holl ddiffiniadau cyffredin o rannu yn gyfartal ar gyfer y cyfanrifau positif, mae hyn yn union hafal i `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Lapio negyddu (modular).
        /// Yn cywasgu `-self`, gan lapio o gwmpas ar ffin y math.
        ///
        /// Gan nad oes gan fathau heb eu llofnodi gyfwerth negyddol bydd holl gymwysiadau'r swyddogaeth hon yn lapio (ac eithrio `-0`).
        /// Ar gyfer gwerthoedd sy'n llai nag uchafswm y math wedi'i lofnodi cyfatebol, mae'r canlyniad yr un peth â bwrw'r gwerth llofnod cyfatebol.
        ///
        /// Mae unrhyw werthoedd mwy yn cyfateb i `MAX + 1 - (val - MAX - 1)` lle mai `MAX` yw uchafswm y math wedi'i lofnodi.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// Sylwch fod yr enghraifft hon yn cael ei rhannu rhwng mathau cyfanrif.
        /// Sy'n esbonio pam mae `i8` yn cael ei ddefnyddio yma.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-did bitwise free-shift;
        /// yn cynhyrchu `self << mask(rhs)`, lle mae `mask` yn dileu unrhyw ddarnau uchel o `rhs` a fyddai'n achosi i'r shifft fod yn fwy na lled y math.
        ///
        /// Sylwch nad yw hyn * yr un peth â chylchdroi-chwith;mae RHS sifft lapio chwith-gyfyngedig wedi'i gyfyngu i ystod y math, yn hytrach na dychwelyd y darnau sy'n cael eu symud allan o'r LHS i'r pen arall.
        /// Mae'r mathau cyfanrif cyntefig i gyd yn gweithredu swyddogaeth [`rotate_left`](Self::rotate_left), a allai fod yr hyn rydych chi ei eisiau yn lle.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // DIOGELWCH: mae'r masgio gan bitsize y math yn sicrhau nad ydym yn symud
            // allan o ffiniau
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-did bitwise shift-right;
        /// yn cynhyrchu `self >> mask(rhs)`, lle mae `mask` yn dileu unrhyw ddarnau uchel o `rhs` a fyddai'n achosi i'r shifft fod yn fwy na lled y math.
        ///
        /// Sylwch nad yw hyn * yr un peth â hawl cylchdroi;mae RHS sifft lapio i'r dde wedi'i gyfyngu i ystod y math, yn hytrach na dychwelyd y darnau sy'n cael eu symud allan o'r LHS i'r pen arall.
        /// Mae'r mathau cyfanrif cyntefig i gyd yn gweithredu swyddogaeth [`rotate_right`](Self::rotate_right), a allai fod yr hyn rydych chi ei eisiau yn lle.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // DIOGELWCH: mae'r masgio gan bitsize y math yn sicrhau nad ydym yn symud
            // allan o ffiniau
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Lapio esboniad (modular).
        /// Yn cywasgu `self.pow(exp)`, gan lapio o gwmpas ar ffin y math.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // ers exp!=0, yn olaf rhaid i'r exp fod yn 1.
            // Deliwch â darn olaf yr esboniwr ar wahân, gan nad yw sgwario'r sylfaen wedi hynny yn angenrheidiol a gallai achosi gorlif diangen.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Yn cyfrifo `self` + `rhs`
        ///
        /// Yn dychwelyd twple o'r ychwanegiad ynghyd â boolean yn nodi a fyddai gorlif rhifyddeg yn digwydd.
        /// Pe bai gorlif wedi digwydd yna dychwelir y gwerth wedi'i lapio.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Yn cyfrifo `self`, `rhs`
        ///
        /// Yn dychwelyd twple o'r tynnu ynghyd â boolean sy'n nodi a fyddai gorlif rhifyddeg yn digwydd.
        /// Pe bai gorlif wedi digwydd yna dychwelir y gwerth wedi'i lapio.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Yn cyfrifo lluosi `self` a `rhs`.
        ///
        /// Yn dychwelyd twple o'r lluosi ynghyd â boolean sy'n nodi a fyddai gorlif rhifyddeg yn digwydd.
        /// Pe bai gorlif wedi digwydd yna dychwelir y gwerth wedi'i lapio.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// Sylwch fod yr enghraifft hon yn cael ei rhannu rhwng mathau cyfanrif.
        /// Sy'n esbonio pam mae `u32` yn cael ei ddefnyddio yma.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Yn cyfrifo'r rhannwr pan rhennir `self` â `rhs`.
        ///
        /// Yn dychwelyd twple o'r rhannwr ynghyd â boolean yn nodi a fyddai gorlif rhifyddeg yn digwydd.
        /// Sylwch, ar gyfer cyfanrifau heb eu llofnodi, nad yw gorlif byth yn digwydd, felly'r ail werth bob amser yw `false`.
        ///
        /// # Panics
        ///
        /// Bydd y swyddogaeth hon yn panic os yw `rhs` yn 0.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Yn cyfrifo cyniferydd adran Ewclidaidd `self.div_euclid(rhs)`.
        ///
        /// Yn dychwelyd twple o'r rhannwr ynghyd â boolean yn nodi a fyddai gorlif rhifyddeg yn digwydd.
        /// Sylwch, ar gyfer cyfanrifau heb eu llofnodi, nad yw gorlif byth yn digwydd, felly'r ail werth bob amser yw `false`.
        /// Gan fod yr holl ddiffiniadau cyffredin o rannu yn gyfartal ar gyfer y cyfanrifau positif, mae hyn yn union hafal i `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Bydd y swyddogaeth hon yn panic os yw `rhs` yn 0.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Yn cyfrifo'r gweddill pan rhennir `self` â `rhs`.
        ///
        /// Yn dychwelyd twple o'r gweddill ar ôl ei rannu ynghyd â boolean sy'n nodi a fyddai gorlif rhifyddeg yn digwydd.
        /// Sylwch, ar gyfer cyfanrifau heb eu llofnodi, nad yw gorlif byth yn digwydd, felly'r ail werth bob amser yw `false`.
        ///
        /// # Panics
        ///
        /// Bydd y swyddogaeth hon yn panic os yw `rhs` yn 0.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Yn cyfrifo'r gweddill `self.rem_euclid(rhs)` fel petai yn ôl adran Ewclidaidd.
        ///
        /// Yn dychwelyd twple o'r modulo ar ôl ei rannu ynghyd â boolean sy'n nodi a fyddai gorlif rhifyddeg yn digwydd.
        /// Sylwch, ar gyfer cyfanrifau heb eu llofnodi, nad yw gorlif byth yn digwydd, felly'r ail werth bob amser yw `false`.
        /// Gan fod yr holl ddiffiniadau cyffredin o rannu yn gyfartal ar gyfer y cyfanrifau positif, mae'r llawdriniaeth hon yn union yr un fath â `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Bydd y swyddogaeth hon yn panic os yw `rhs` yn 0.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Yn negyddu'ch hun mewn modd sy'n gorlifo.
        ///
        /// Yn dychwelyd `!self + 1` gan ddefnyddio gweithrediadau lapio i ddychwelyd y gwerth sy'n cynrychioli esgeulustod y gwerth heb ei lofnodi hwn.
        /// Sylwch, ar gyfer gwerthoedd positif heb eu llofnodi, mae gorlif bob amser yn digwydd, ond nid yw negyddu 0 yn gorlifo.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Yn symud ei hun ar ôl gan ddarnau `rhs`.
        ///
        /// Yn dychwelyd twple o'r fersiwn symudol ohonoch chi'ch hun ynghyd â boolean sy'n nodi a oedd y gwerth sifft yn fwy na neu'n hafal i nifer y darnau.
        /// Os yw'r gwerth sifft yn rhy fawr, yna mae gwerth yn cael ei guddio (N-1) lle mai N yw nifer y darnau, ac yna defnyddir y gwerth hwn i gyflawni'r sifft.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Yn symud ei hun yn iawn gan ddarnau `rhs`.
        ///
        /// Yn dychwelyd twple o'r fersiwn symudol ohonoch chi'ch hun ynghyd â boolean sy'n nodi a oedd y gwerth sifft yn fwy na neu'n hafal i nifer y darnau.
        /// Os yw'r gwerth sifft yn rhy fawr, yna mae gwerth yn cael ei guddio (N-1) lle mai N yw nifer y darnau, ac yna defnyddir y gwerth hwn i gyflawni'r sifft.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Yn codi ei hun i rym `exp`, gan ddefnyddio esboniad trwy sgwario.
        ///
        /// Yn dychwelyd twple o'r esboniad ynghyd â bool yn nodi a ddigwyddodd gorlif.
        ///
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, gwir));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Lle crafu ar gyfer storio canlyniadau gorlifo_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // ers exp!=0, yn olaf rhaid i'r exp fod yn 1.
            // Deliwch â darn olaf yr esboniwr ar wahân, gan nad yw sgwario'r sylfaen wedi hynny yn angenrheidiol a gallai achosi gorlif diangen.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Yn codi ei hun i rym `exp`, gan ddefnyddio esboniad trwy sgwario.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // ers exp!=0, yn olaf rhaid i'r exp fod yn 1.
            // Deliwch â darn olaf yr esboniwr ar wahân, gan nad yw sgwario'r sylfaen wedi hynny yn angenrheidiol a gallai achosi gorlif diangen.
            //
            //
            acc * base
        }

        /// Yn perfformio adran Ewclidaidd.
        ///
        /// Gan fod yr holl ddiffiniadau cyffredin o rannu yn gyfartal ar gyfer y cyfanrifau positif, mae hyn yn union hafal i `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Bydd y swyddogaeth hon yn panic os yw `rhs` yn 0.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Yn cyfrifo'r gweddill lleiaf o `self (mod rhs)`.
        ///
        /// Gan fod yr holl ddiffiniadau cyffredin o rannu yn gyfartal ar gyfer y cyfanrifau positif, mae hyn yn union hafal i `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Bydd y swyddogaeth hon yn panic os yw `rhs` yn 0.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Yn dychwelyd `true` os a dim ond os `self == 2^k` ar gyfer rhywfaint o `k`.
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Yn dychwelyd un pŵer llai na dau nesaf.
        // (Ar gyfer 8u8 pŵer nesaf dau yw 8u8 ac ar gyfer 6u8 mae'n 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Ni all y dull hwn orlifo, oherwydd yn yr achosion gorlifo `next_power_of_two`, yn hytrach mae'n dychwelyd gwerth uchaf y math, a gall ddychwelyd 0 am 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // DIOGELWCH: Oherwydd `p > 0`, ni all gynnwys sero yn gyfan gwbl.
            // Mae hynny'n golygu bod y shifft bob amser yn gyfyngedig, ac mae gan rai proseswyr (fel intel pre-haswell) gynhenid ctlz mwy effeithlon pan nad yw'r ddadl yn sero.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Yn dychwelyd y pŵer lleiaf o ddau sy'n fwy na neu'n hafal i `self`.
        ///
        /// Pan fydd gwerth dychwelyd yn gorlifo (h.y., `self > (1 << (N-1))` ar gyfer math `uN`), mae'n panics yn y modd dadfygio ac mae gwerth dychwelyd wedi'i lapio i 0 yn y modd rhyddhau (yr unig sefyllfa lle gall y dull ddychwelyd 0).
        ///
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Yn dychwelyd y pŵer lleiaf o ddau sy'n fwy na neu'n hafal i `n`.
        /// Os yw'r pŵer nesaf o ddau yn fwy nag uchafswm gwerth y math, dychwelir `None`, fel arall mae pŵer dau wedi'i lapio yn `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Yn dychwelyd y pŵer lleiaf o ddau sy'n fwy na neu'n hafal i `n`.
        /// Os yw'r pŵer nesaf o ddau yn fwy nag uchafswm gwerth y math, mae'r gwerth dychwelyd wedi'i lapio i `0`.
        ///
        ///
        /// # Examples
        ///
        /// Defnydd sylfaenol:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Dychwelwch gynrychiolaeth cof y cyfanrif hwn fel arae beit yn nhrefn beit (network) mawr-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Dychwelwch gynrychiolaeth cof y cyfanrif hwn fel arae beit mewn trefn beit bach-endiaidd.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Dychwelwch gynrychiolaeth cof y cyfanrif hwn fel arae beit yn nhrefn beit brodorol.
        ///
        /// Wrth i endidoldeb brodorol y platfform targed gael ei ddefnyddio, dylai'r cod cludadwy ddefnyddio [`to_be_bytes`] neu [`to_le_bytes`], fel sy'n briodol, yn lle.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     beit, os cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } arall {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // DIOGELWCH: const const oherwydd bod cyfanrifau yn hen datatypes plaen fel y gallwn ni bob amser
        // eu trosglwyddo i araeau o bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // DIOGELWCH: mae cyfanrifau yn hen datatypes plaen fel y gallwn ni bob amser eu trosglwyddo
            // araeau o bytes
            unsafe { mem::transmute(self) }
        }

        /// Dychwelwch gynrychiolaeth cof y cyfanrif hwn fel arae beit yn nhrefn beit brodorol.
        ///
        ///
        /// [`to_ne_bytes`] dylid ei ffafrio yn hytrach na hyn pryd bynnag y bo modd.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// gadewch beitiau= num.as_ne_bytes();
        /// assert_eq!(
        ///     beit, os cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } arall {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // DIOGELWCH: mae cyfanrifau yn hen datatypes plaen fel y gallwn ni bob amser eu trosglwyddo
            // araeau o bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Creu gwerth cyfanrif endianaidd brodorol o'i gynrychiolaeth fel arae beit mewn endian mawr.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// defnyddio std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * mewnbwn=gorffwys;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Creu gwerth cyfanrif endian brodorol o'i gynrychiolaeth fel arae beit mewn ychydig o endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// defnyddio std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * mewnbwn=gorffwys;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Creu gwerth cyfanrif endianaidd brodorol o'i gynrychiolaeth cof fel arae beit mewn endianness brodorol.
        ///
        /// Wrth i endianoldeb brodorol y platfform targed gael ei ddefnyddio, mae'n debyg bod cod cludadwy eisiau defnyddio [`from_be_bytes`] neu [`from_le_bytes`], fel sy'n briodol yn lle.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } arall {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// defnyddio std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * mewnbwn=gorffwys;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // DIOGELWCH: const const oherwydd bod cyfanrifau yn hen datatypes plaen fel y gallwn ni bob amser
        // transmute iddynt
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // DIOGELWCH: mae cyfanrifau yn hen datatypes plaen fel y gallwn ni drawsnewid iddynt bob amser
            unsafe { mem::transmute(bytes) }
        }

        /// Dylai fod yn well gan god newydd ei ddefnyddio
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Yn dychwelyd y gwerth lleiaf y gellir ei gynrychioli gan y math cyfanrif hwn.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Dylai fod yn well gan god newydd ei ddefnyddio
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Yn dychwelyd y gwerth mwyaf y gellir ei gynrychioli gan y math cyfanrif hwn.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}