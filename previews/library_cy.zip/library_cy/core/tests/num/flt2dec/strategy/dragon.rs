use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Mae Miri yn rhy araf
fn exact_sanity_test() {
    // Mae'r prawf hwn yn dod i ben i fyny redeg beth allaf ond tybio rhywfaint achos cornel-ish o'r swyddogaeth llyfrgell `exp2`, a ddiffinnir ym mha bynnag C Rhedeg rydym yn ei ddefnyddio.
    // Yn VS 2013 yn ôl pob golwg roedd swyddogaeth hon a bug fel y prawf hwn yn methu pan cysylltiedig, ond gyda VS 2015 y nam ymddangos sefydlog fel y prawf yn rhedeg jyst ddirwya.
    //
    // Y nam yn ymddangos i fod gwahaniaeth yn y gwerth dychwelyd `exp2(-1057)`, ble yn VS 2013 mae'n dychwelyd dwbl gyda phatrwm bit 0x2 ac yn VS 2015 mae'n dychwelyd 0x20000.
    //
    //
    // Am y tro dim ond anwybyddu'r prawf hwn yn gyfan gwbl ar MSVC gan ei fod yn profi mewn mannau eraill beth bynnag ac nid ydym yn diddordeb super wrth brofi gweithrediad exp2 pob platfform yn.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}