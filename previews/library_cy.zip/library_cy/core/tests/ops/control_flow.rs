use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Nid yw hwn yn arwynebedd sefydlog, ond mae'n helpu i gadw `?` yn rhad rhyngddynt, hyd yn oed os na all LLVM fanteisio arno ar hyn o bryd.
    //
    // (Yn anffodus mae Canlyniad ac Opsiwn yn anghyson, felly ni all ControlFlow gyd-fynd â'r ddau.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}