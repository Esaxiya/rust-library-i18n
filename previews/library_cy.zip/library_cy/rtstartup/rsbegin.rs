// rsbegin.o a rsend.o yw'r hyn a elwir yn "compiler runtime startup objects".
// Maent yn cynnwys cod sydd ei angen i gychwyn amser rhedeg y casglwr yn gywir.
//
// Pan delwedd weithredadwy neu dylib wedi'i gysylltu, pob cod defnyddiwr a llyfrgelloedd yn "sandwiched" rhwng y ddwy ffeil gwrthrych, felly cod neu ddata o rsbegin.o yn dod yn gyntaf yn yr adrannau priodol y ddelwedd, tra cod a data o rsend.o yn dod yn y rhai olaf.
// Gellir defnyddio'r effaith hon i osod symbolau ar ddechrau neu ar ddiwedd adran, yn ogystal â mewnosod unrhyw benawdau neu droedynnau gofynnol.
//
// Noder bod y pwynt mynediad modiwl gwirioneddol wedi ei leoli yn y C Rhedeg startup gwrthrych (a elwir fel arfer `crtX.o`), sydd wedyn yn ennyn initialization callbacks o gydrannau Rhedeg eraill (cofrestredig drwy eto adran ddelwedd arbennig arall).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Marciau dechrau'r adran wybodaeth ffrâm ffrâm dadflino
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Crafu lle ar gyfer cadw llyfrau mewnol dad-dynnu.
    // Diffinnir hyn fel `struct object` yn $ GCC/ymlacio-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Arferion XwX gwybodaeth annoeth.
    // Gweler y docs o libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // cofrestru info ymlacio ar startup modiwl
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ddadgofrestru ar shutdown
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Cofrestriad arferol init/uninit MinGW-benodol
    pub mod mingw_init {
        // Bydd gwrthrychau startup MinGW (yn crt0.o/dllcrt0.o) alw adeiladwyr byd-eang yn yr adrannau .ctors a .dtors ar startup ac ymadael.
        // Yn achos y DLLs, gwneir hyn pan fydd y DLL ei lwytho a dadlwytho.
        //
        // Bydd y linker didoli'r rhannau, sy'n sicrhau bod ein callbacks yn cael eu lleoli ar ddiwedd y rhestr.
        // Gan fod adeiladwyr yn cael eu rhedeg am yn ôl, mae hyn yn sicrhau bod ein callbacks yw'r rhai cyntaf a'r olaf ddienyddio.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C galwadau cychwynnol ymgychwyn
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: Galwadau terfynu C.
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}