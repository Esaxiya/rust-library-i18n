//! Llyfrgell gymorth ar gyfer awduron macro wrth ddiffinio macros newydd.
//!
//! Mae'r llyfrgell hon, a ddarperir gan y dosbarthiad safonol, yn darparu'r mathau a ddefnyddir yn rhyngwynebau diffiniadau macro a ddiffiniwyd yn weithdrefnol megis macros tebyg i swyddogaeth `#[proc_macro]`, priodoleddau macro `#[proc_macro_attribute]` a phriodoleddau deilliadau arfer`#[proc_macro_derive]`.
//!
//!
//! Gweler [the book] am fwy.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Penderfynu a proc_macro wedi cael ei wneud yn hygyrch i'r rhaglen sy'n rhedeg ar hyn o bryd.
///
/// Mae'r crate proc_macro unig fwriedir ar gyfer defnydd y tu mewn i'r o macros gweithdrefnol ar waith.Mae'r holl swyddogaethau yn y crate panic os galw i rym o'r tu allan macro trefniadol, megis o sgript adeiladu neu brawf uned neu'r deuaidd Rust cyffredin.
///
/// Gan ystyried llyfrgelloedd Rust sydd wedi'u cynllunio i gefnogi achosion macro a di-macro, mae `proc_macro::is_available()` yn darparu ffordd nad yw'n mynd i banig i ganfod a yw'r seilwaith sy'n ofynnol i ddefnyddio'r API proc_macro ar gael ar hyn o bryd.
/// Ffurflenni wir os galw i rym o tu mewn macro gweithdrefnol, ffug os galw i rym gan unrhyw deuaidd eraill.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Y prif fath a ddarperir gan y crate hwn, sy'n cynrychioli llif haniaethol o tokens, neu, yn fwy penodol, dilyniant o goed token.
/// Mae'r math yn darparu rhyngwynebau ar gyfer ailadrodd dros y coed token hynny ac, i'r gwrthwyneb, casglu nifer o goed token i mewn i un nant.
///
///
/// Mae hyn yn y mewnbwn ac allbwn o ddiffiniadau `#[proc_macro]`, `#[proc_macro_attribute]` a `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Dychwelwyd gwall o `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Yn dychwelyd `TokenStream` gwag heb unrhyw goed token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Yn gwirio a yw'r `TokenStream` hwn yn wag.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Ymdrechion i dorri'r llinyn yn tokens a dosrannu'r tokens hynny i mewn i nant token.
/// Mai methu am nifer o resymau, er enghraifft, os bydd y llinyn yn cynnwys amffinyddion neu gymeriadau anghytbwys peidio bodoli yn yr iaith.
///
/// Mae pob tokens yn y nant dosrannu yn cael rhychwantu `Span::call_site()`.
///
/// NOTE: Gall rhai gwallau achosi panics yn hytrach na dychwelyd `LexError`.Rydym yn cadw'r hawl i newid y gwallau hyn yn `LexError`s yn ddiweddarach.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// DS, y bont yn unig yn rhoi `to_string`, gweithredu `fmt::Display` seiliedig arno (gefn y berthynas arferol rhwng y ddau).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Yn argraffu llif token fel llinyn sydd i fod i gael ei drawsnewid yn ddi-golled yn ôl i'r un nant token (rhychwantu modulo), heblaw am o bosibl `TokenTree: : Group`s gyda delimiters `Delimiter::None` a llythrennau rhifol negyddol.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Printiau token mewn ffurf gyfleus ar gyfer debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Yn creu nant token sy'n cynnwys un goeden token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Yn casglu nifer o goed token i mewn i un nant.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// A "flattening" weithredol ar nentydd token, casglu coed token o ffrydiau lluosog token i mewn i nant sengl.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Defnyddiwch gweithredu optimized if/when bosibl.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Manylion gweithredu cyhoeddus ar gyfer y math `TokenStream`, fel ailadroddwyr.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Ailadroddwr dros `TokenTree`s`TokenStream`s.
    /// Yr iteriad yw "shallow", ee, nid yw'r ailadroddwr yn dychwelyd i grwpiau wedi'u hamffinio, ac mae'n dychwelyd grwpiau cyfan fel coed token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` yn derbyn mympwyol tokens ac yn ehangu i mewn i `TokenStream` disgrifio'r mewnbwn.
/// Er enghraifft, bydd `quote!(a + b)` cynhyrchu mynegiant,, pan gwerthuso, yn adeiladu y `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Gwneir unquoting gyda `$`, ac mae'n gweithio trwy gymryd yr un hunaniaeth nesaf fel y term heb ei nodi.
/// I ddyfynnu `$` ei hun, defnyddiwch `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Rhanbarth o god ffynhonnell, ynghyd â gwybodaeth ehangu macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Creu `Diagnostic` newydd gyda'r `message` a roddwyd yn y rhychwant `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Rhychwant sy'n datrys ar y safle macro-ddiffiniad.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Rhychwant galw'r macro gweithdrefnol cyfredol.
    /// Bydd dynodwyr greu gyda rhychwant hyn ei ddatrys fel pe cawsant eu hysgrifennu yn uniongyrchol yn y lleoliad macro ffoniwch (hylendid galw-safle) a chod eraill ar y safle galw macro yn gallu cyfeirio atynt hefyd.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Mae rhychwant sy'n cynrychioli hylendid `macro_rules`, ac weithiau yn penderfynu ar y safle macro diffiniad (newidynnau lleol, labeli, `$crate`) ac weithiau ar y safle galw macro (popeth arall).
    ///
    /// Mae lleoliad span yn cael ei gymryd o'r alwad y safle.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Y ffeil ffynhonnell wreiddiol y mae'r rhychwant hwn yn pwyntio ati.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Yr `Span` ar gyfer y tokens yn yr ehangiad macro blaenorol y cynhyrchwyd `self` ohono, os o gwbl.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Mae'r rhychwant ar gyfer y cod ffynhonnell tarddiad y `self` ei gynhyrchu o.
    /// Os na chynhyrchwyd yr `Span` hwn o macro-ehangiadau eraill yna mae'r gwerth dychwelyd yr un peth â `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Yn cael y line/column yn dechrau yn y ffeil ffynhonnell ar gyfer y rhychwant hwn.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Yn cael y line/column yn dod i ben yn y ffeil ffynhonnell ar gyfer y rhychwant hwn.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Creu rhychwant newydd sy'n cwmpasu `self` a `other`.
    ///
    /// Ffurflenni `None` os `self` a `other` yn dod o ffeiliau gwahanol.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Creu rhychwant newydd gyda'r un wybodaeth line/column â `self` ond sy'n datrys symbolau fel pe bai'n yn `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Creu rhychwant newydd gyda'r un ymddygiad penderfyniad enw fel `self` ond gyda'r wybodaeth line/column o `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Cymharwch â rhychwantu i weld a ydyn nhw'n gyfartal.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Dychwelyd y testun ffynhonnell y tu ôl cyfnod.
    /// Mae hyn yn cadw'r cod ffynhonnell gwreiddiol, gan gynnwys bylchau a sylwadau.
    /// Dim ond os yw'r rhychwant yn cyfateb i god ffynhonnell go iawn y mae'n dychwelyd canlyniad.
    ///
    /// Note: Dylai canlyniad gweladwy macro ddibynnu ar y tokens yn unig ac nid ar y testun ffynhonnell hwn.
    ///
    /// Canlyniad y swyddogaeth hon yw'r ymdrech orau i'w defnyddio ar gyfer diagnosteg yn unig.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Printiau rhychwant mewn ffurf gyfleus ar gyfer debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Mae pâr llinell-colofn cynrychioli'r ddechrau neu ddiwedd `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Mae'r llinell 1-indexed yn y ffeil ffynhonnell y mae'r rhychwant yn dechrau neu'n dod i ben (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Mae'r golofn 0-indexed (mewn llythrennau UTF-8) yn y ffeil ffynhonnell y mae'r rhychwant yn dechrau neu'n dod i ben (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Ffeil ffynhonnell `Span` penodol.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Cael y llwybr i'r ffeil ffynhonnell hon.
    ///
    /// ### Note
    /// Os bydd y rhychwant cod sy'n gysylltiedig â'r `SourceFile` hwn ei gynhyrchu gan macro allanol, macro hwn, efallai na fydd hyn fod yn llwybr gwirioneddol ar y system ffeiliau.
    /// Defnyddiwch [`is_real`] i wirio.
    ///
    /// Sylwch hefyd, hyd yn oed os yw `is_real` yn dychwelyd `true`, pe bai `--remap-path-prefix` yn cael ei basio ar y llinell orchymyn, efallai na fydd y llwybr fel y'i rhoddir yn ddilys mewn gwirionedd.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Ffurflenni `true` os yw hyn ffeil ffynhonnell yn ffeil ffynhonnell go iawn, ac nid yn ei gynhyrchu gan ehangu yn macro allanol.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Mae hwn yn darnia nes rhychwantau intercrate yn cael eu gweithredu a gallwn gael ffeiliau ffynhonnell gwirioneddol i rhychwantau gynhyrchir yn macros allanol.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Mae un token neu ddilyniant delimited o goed token (ee, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// ffrwd A token amgylchynu gan amffinyddion braced.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Dynodwr.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Cymeriad atalnodi sengl (`+`, `,`, `$`, ac ati).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Cymeriad llythrennol (`'a'`), llinyn (`"hello"`), rhif (`2.3`), ac ati.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Ffurflenni y rhychwant y goeden hon, dirprwyo i'r dull `span` y token cynnwys neu nant delimited.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Configures y rhychwant ar gyfer *Dim ond y token*.
    ///
    /// Sylwer, os token hwn yn `Group`, yna ni fydd y dull hwn yn ffurfweddu y rhychwant pob un o'r tokens mewnol, bydd hyn yn syml yn dirprwyo i'r dull `set_span` pob amrywiad.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// coeden Printiau token mewn ffurf gyfleus ar gyfer debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Mae gan bob un o'r rhain yr enw yn y math struct yn y debug deillio, felly peidiwch trafferthu gyda haen ychwanegol o indirection
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// DS, y bont yn unig yn rhoi `to_string`, gweithredu `fmt::Display` seiliedig arno (gefn y berthynas arferol rhwng y ddau).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Printiau y goeden token fel llinyn sydd i fod i fod yn ôl losslessly trosi'n i mewn i'r un goeden token (rhychwantu modwlo), eithrio am o bosibl `TokenTree: : Group`s gyda amffinyddion `Delimiter::None` a lythrenyddion rhifol negyddol.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Ffrwd token wedi'i hamffinio.
///
/// A `Group` yn fewnol yn cynnwys `TokenStream` sy'n cael ei amgylchynu gan `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Yn disgrifio sut mae cyfres o goed token yn cael ei hamffinio.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Mae amffinydd ymhlyg, y gall, er enghraifft, yn ymddangos o gwmpas tokens dod o "macro variable" `$var`.
    /// Mae'n bwysig i gadw blaenoriaethau gweithredwr mewn achosion fel `$var * 3` lle `$var` yn `1 + 2`.
    /// Efallai na fydd delimiters ymhlyg yn goroesi cylchdro o nant token trwy linyn.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Creu `Group` newydd gyda'r amffinydd a roddwyd a'r nant token.
    ///
    /// Bydd y Constructor gosod y rhychwant gyfer y grŵp hwn i `Span::call_site()`.
    /// I newid y rhychwant gallwch ddefnyddio'r dull `set_span` isod.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Yn dychwelyd amffinydd yr `Group` hwn
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Yn dychwelyd yr `TokenStream` o tokens sy'n cael ei amffinio yn yr `Group` hwn.
    ///
    /// Noder nad yw'r ffrwd token ddychwelwyd yn cynnwys y amffinydd dychwelyd uchod.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Dychwelyd y rhychwant ar gyfer amffinyddion y ffrwd token, yn rhychwantu'r `Group` cyfan.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Yn dychwelyd y rhychwant gan bwyntio at amffinydd agoriadol y grŵp hwn.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Yn dychwelyd y rhychwant gan bwyntio at amffinydd cau'r grŵp hwn.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Configures y rhychwant ar gyfer hyn `amffinyddion Group`, ond nid yw ei tokens mewnol.
    ///
    /// Ni fydd y dull hwn **yn** gosod rhychwant yr holl tokens mewnol a rychwantir gan y grŵp hwn, ond yn hytrach dim ond rhychwant y delimydd tokens y bydd yn ei osod ar lefel yr `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// DS, y bont yn unig yn rhoi `to_string`, gweithredu `fmt::Display` seiliedig arno (gefn y berthynas arferol rhwng y ddau).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Printiau y grŵp fel llinyn a ddylai fod yn ôl losslessly trosi'n i mewn i'r un grŵp (rhychwantu modwlo), eithrio am o bosibl `TokenTree: : Group`s gyda amffinyddion `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Mae `Punct` yn gymeriad atalnodi sengl fel `+`, `-` neu `#`.
///
/// gweithredwyr aml-cymeriad fel `+=` yn cael eu cynrychioli fel dau achos o `Punct` gyda gwahanol fathau o `Spacing` dychwelyd.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// P'un a yw `Punct` yn cael ei ddilyn ar unwaith gan `Punct` arall neu ei ddilyn gan token arall neu ofod gwyn.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ee, `+` yn `Alone` yn `+ =`, `+ident` neu `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ee, `+` yw `Joint` yn `+=` neu `'#`.
    /// Yn ogystal, gall dyfyniad sengl `'` yn ymuno gyda dynodwyr i ffurflen hoes `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Yn creu `Punct` newydd o'r cymeriad a'r bylchau a roddir.
    /// Rhaid i'r ddadl `ch` yn gymeriad atalnodi dilys a ganiateir gan yr iaith, fel arall bydd y swyddogaeth panic.
    ///
    /// Bydd y `Punct` ddychwelwyd yn cael y rhychwant ddiffyg `Span::call_site()` y gellir ei ffurfweddu ymhellach â'r dull `set_span` isod.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Yn dychwelyd gwerth y cymeriad atalnodi hwn fel `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Ffurflenni y bylchau rhwng y cymeriad atalnodi, gan nodi a yw'n ddilyn yn syth gan `Punct` arall yn y ffrwd token, fel y gallant o bosibl gael eu cyfuno i mewn i weithredwr aml-cymeriad (`Joint`), neu mae'n cael ei ddilyn gan rai token neu ofod gwyn (`Alone`) felly gan y gweithredwr sicr eraill a ddaeth i ben.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Yn dychwelyd y rhychwant ar gyfer y cymeriad atalnodi hwn.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ffurfweddu y rhychwant ar gyfer y cymeriad atalnodi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// DS, y bont yn unig yn rhoi `to_string`, gweithredu `fmt::Display` seiliedig arno (gefn y berthynas arferol rhwng y ddau).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Yn argraffu'r cymeriad atalnodi fel llinyn y dylid ei drosi'n ddi-golled yn ôl i'r un cymeriad.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Dynodwr (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Yn creu `Ident` newydd gyda'r `string` a roddir yn ogystal â'r `span` penodedig.
    /// Rhaid i'r ddadl `string` fod yn ddynodwr dilys a ganiateir gan yr iaith (gan gynnwys geiriau allweddol, ee `self` neu `fn`).Fel arall, bydd y swyddogaeth yn panic.
    ///
    /// Sylwch fod `span`, ar hyn o bryd yn rustc, configures y wybodaeth hylendid ar gyfer y dynodwr hwn.
    ///
    /// Fel o'r amser hwn `Span::call_site()` yn dewis-yn benodol at ystyr hylendid "call-site" y bydd dynodwyr greu gyda rhychwant hyn ei ddatrys fel pe cawsant eu hysgrifennu yn uniongyrchol yn y lleoliad yr alwad macro, a bydd y cod arall ar y safle galw macro yn gallu cyfeirio at nhw hefyd.
    ///
    ///
    /// Bydd rhychwantu Yn ddiweddarach fel `Span::def_site()` yn caniatáu i optio i mewn i hylendid "definition-site" sy'n golygu y bydd dynodwyr greu gyda rhychwant hwn yn cael ei datrys ar y lleoliad y diffiniad macro a chod eraill ar y safle galw macro, ni fydd yn gallu cyfeirio atynt.
    ///
    /// Oherwydd pwysigrwydd hylendid ar hyn o bryd, mae'r adeiladwr hwn, yn wahanol i tokens eraill, yn ei gwneud yn ofynnol nodi `Span` wrth ei adeiladu.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Yr un peth â `Ident::new`, ond mae'n creu dynodwr amrwd (`r#ident`).
    /// Mae'r ddadl `string` yn dynodwr dilys a ganiateir gan yr iaith (yn cynnwys geiriau allweddol, ee `fn`).
    /// Geiriau allweddol y gellir eu defnyddio mewn rhannau llwybr (ee
    /// `self`, ni chefnogir `super`), a bydd yn achosi panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Dychwelyd y rhychwant `Ident` hwn, gan gwmpasu'r llinyn cyfan a ddychwelwyd gan [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures y rhychwant `Ident` hwn, gan newid ei gyd-destun hylendid o bosibl.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// DS, y bont yn unig yn rhoi `to_string`, gweithredu `fmt::Display` seiliedig arno (gefn y berthynas arferol rhwng y ddau).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Printiau y dynodwr fel llinyn a ddylai fod yn ôl losslessly trosi'n i mewn i'r un dynodwr.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Llinyn llythrennol (`"hello"`), llinyn beit (`b"hello"`), cymeriad (`'a'`), cymeriad beit (`b'a'`), cyfanrif neu rif pwynt arnofio gyda ôl-ddodiad neu hebddo (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Nid yw llythrennau Boole fel `true` a `false` yn perthyn yma, maen nhw'n `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Creu newydd ôl-ddodiad cyfanrif lythrennol â gwerth penodol.
        ///
        /// Bydd y swyddogaeth hon yn creu cyfanrif fel `1u32` lle mae gwerth cyfanrif penodol yw rhan gyntaf y token ac mae'r rhan annatod hefyd yn cael ei ôl-ddodiad ar y diwedd.
        /// Efallai na fydd llythrennau a grëir o rifau negyddol yn goroesi teithiau crwn trwy `TokenStream` neu dannau a gellir eu rhannu'n ddwy tokens (`-` a llythrennol gadarnhaol).
        ///
        ///
        /// Lythrenyddion grëwyd drwy'r dull hwn yn cael y rhychwant `Span::call_site()` yn ddiofyn, y gellir ei ffurfweddu gyda'r dull `set_span` isod.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Yn creu llythrennol cyfanrif heb ei osod newydd gyda'r gwerth penodedig.
        ///
        /// Bydd y swyddogaeth hon yn creu cyfanrif fel `1` lle mae gwerth cyfanrif penodol yw rhan gyntaf y token.
        /// Nid oes unrhyw ôl-ddodiad wedi'i bennu ar token hyn, sy'n golygu bod invocations fel `Literal::i8_unsuffixed(1)` yn cyfateb i `Literal::u32_unsuffixed(1)`.
        /// Efallai na lythrenyddion creu o rifau negatif yn goroesi rountrips trwy `TokenStream` neu llinynnau a gellir eu torri yn ddau tokens (`-` a llythrennol cadarnhaol).
        ///
        ///
        /// Lythrenyddion grëwyd drwy'r dull hwn yn cael y rhychwant `Span::call_site()` yn ddiofyn, y gellir ei ffurfweddu gyda'r dull `set_span` isod.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Creu unsuffixed llythrennol fel y bo'r angen-pwynt newydd.
    ///
    /// Mae'r Constructor yn debyg i'r rhai fel `Literal::i8_unsuffixed` lle gwerth fflôt yn cael ei ollwng yn uniongyrchol i mewn i'r token ond nid oes unrhyw ôl-ddodiad yn cael ei ddefnyddio, felly gellir casglu i fod yn `f64` yn ddiweddarach yn y compiler.
    ///
    /// Efallai na lythrenyddion creu o rifau negatif yn goroesi rountrips trwy `TokenStream` neu llinynnau a gellir eu torri yn ddau tokens (`-` a llythrennol cadarnhaol).
    ///
    /// # Panics
    ///
    /// Mae'r swyddogaeth hon yn ei gwneud yn ofynnol bod y arnofio a bennwyd yn gyfyngedig, er enghraifft, os yw'n anfeidredd neu NaN swyddogaeth hon, bydd panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Yn creu llythrennol pwynt arnofio ôl-ddodiad newydd.
    ///
    /// Bydd y Constructor creu llythrennol fel `1.0f32` lle mae gwerth penodedig yw'r rhan flaenorol o'r token a `f32` yw ôl-ddodiad yr token.
    /// Bydd y token bob amser yn cael ei casglu i fod yn `f32` yn y compiler.
    /// Efallai na lythrenyddion creu o rifau negatif yn goroesi rountrips trwy `TokenStream` neu llinynnau a gellir eu torri yn ddau tokens (`-` a llythrennol cadarnhaol).
    ///
    ///
    /// # Panics
    ///
    /// Mae'r swyddogaeth hon yn ei gwneud yn ofynnol bod y arnofio a bennwyd yn gyfyngedig, er enghraifft, os yw'n anfeidredd neu NaN swyddogaeth hon, bydd panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Creu unsuffixed llythrennol fel y bo'r angen-pwynt newydd.
    ///
    /// Mae'r Constructor yn debyg i'r rhai fel `Literal::i8_unsuffixed` lle gwerth fflôt yn cael ei ollwng yn uniongyrchol i mewn i'r token ond nid oes unrhyw ôl-ddodiad yn cael ei ddefnyddio, felly gellir casglu i fod yn `f64` yn ddiweddarach yn y compiler.
    ///
    /// Efallai na lythrenyddion creu o rifau negatif yn goroesi rountrips trwy `TokenStream` neu llinynnau a gellir eu torri yn ddau tokens (`-` a llythrennol cadarnhaol).
    ///
    /// # Panics
    ///
    /// Mae'r swyddogaeth hon yn ei gwneud yn ofynnol bod y arnofio a bennwyd yn gyfyngedig, er enghraifft, os yw'n anfeidredd neu NaN swyddogaeth hon, bydd panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Yn creu llythrennol pwynt arnofio ôl-ddodiad newydd.
    ///
    /// Bydd y Constructor creu llythrennol fel `1.0f64` lle mae gwerth penodedig yw'r rhan flaenorol o'r token a `f64` yw ôl-ddodiad yr token.
    /// Bydd y token bob amser yn cael ei casglu i fod yn `f64` yn y compiler.
    /// Efallai na lythrenyddion creu o rifau negatif yn goroesi rountrips trwy `TokenStream` neu llinynnau a gellir eu torri yn ddau tokens (`-` a llythrennol cadarnhaol).
    ///
    ///
    /// # Panics
    ///
    /// Mae'r swyddogaeth hon yn ei gwneud yn ofynnol bod y arnofio a bennwyd yn gyfyngedig, er enghraifft, os yw'n anfeidredd neu NaN swyddogaeth hon, bydd panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Llinynnol llythrennol.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// lythrennol Cymeriad.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Beit llinyn llythrennol.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Yn dychwelyd y rhychwant sy'n cwmpasu'r llythrennol hwn.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures y rhychwant cysylltiedig ar gyfer llythrennol hwn.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Yn dychwelyd `Span` sydd yn is-set o `self.span()` yn cynnwys dim ond y ffynhonnell bytes yn ystod `range`.
    /// Dychwelyd `None` os y rhychwant byddai-yn cael ei docio y tu allan i ffiniau `self`.
    ///
    // FIXME(SergioBenitez): gwirio bod yr ystod beit yn dechrau ac yn gorffen ar derfyn UTF-8 o'r ffynhonnell.
    // fel arall, mae'n debygol y bydd panic yn digwydd mewn man arall pan fydd y testun ffynhonnell wedi'i argraffu.
    // FIXME(SergioBenitez): nid oes unrhyw ffordd ar gyfer y defnyddiwr i wybod beth `self.span()` mewn gwirionedd mapiau i, fel y gall y dull hwn ar hyn o bryd dim ond cael eu galw blindly.
    // Er enghraifft, `to_string()` gyfer y cymeriad 'c' yn dychwelyd "'\u{63}'";nid oes unrhyw ffordd i'r defnyddiwr wybod ai 'c' oedd y testun ffynhonnell neu ai '\u{63}' ydoedd.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) rhywbeth tebyg i `Option::cloned`, ond ar gyfer `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// DS, y bont yn unig yn rhoi `to_string`, gweithredu `fmt::Display` seiliedig arno (gefn y berthynas arferol rhwng y ddau).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Yn argraffu'r llythrennol fel llinyn a ddylai gael ei drawsnewid yn ddi-golled yn ôl i'r un llythrennol (heblaw am dalgrynnu posibl ar gyfer llythrennau pwynt arnofio).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Mynediad wedi'i olrhain i newidynnau amgylchedd.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Adfer newidyn amgylchedd a'i ychwanegu at adeiladu info dibyniaeth.
    /// Bydd y system adeiladu sy'n gweithredu'r crynhoydd yn gwybod y cyrchwyd at y newidyn wrth ei lunio, a bydd yn gallu ail-redeg yr adeilad pan fydd gwerth y newidyn hwnnw'n newid.
    ///
    /// Heblaw am olrhain dibyniaeth dylai'r swyddogaeth hon fod yn gyfwerth â `env::var` o'r llyfrgell safonol, heblaw bod yn rhaid i'r ddadl fod yn UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}