#![feature(no_core)]
#![no_core]

// Gweler rustc-std-workpace-core am pam mae angen y crate hwn.

// Ail-enwi y crate i osgoi gwrthdaro gyda'r modiwl Gweig yn liballoc.
extern crate alloc as foo;

pub use foo::*;