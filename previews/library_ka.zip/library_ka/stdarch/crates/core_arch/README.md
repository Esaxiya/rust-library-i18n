`core::arch` - Rust-ის ძირითადი ბიბლიოთეკის არქიტექტურის სპეციფიკური შინაარსი
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` მოდული ახორციელებს არქიტექტურაზე დამოკიდებულ შინაარსს (მაგ. SIMD).

# Usage 

`core::arch` ხელმისაწვდომია როგორც `libcore` ნაწილი და ის რეექსპორტირდება `libstd`- ის მიერ.ამჯობინეთ გამოიყენოთ იგი `core::arch` ან `std::arch` საშუალებით, ვიდრე ამ crate.
არასტაბილური მახასიათებლები ხშირად ხელმისაწვდომია ღამით Rust- ში `feature(stdsimd)`- ის საშუალებით.

`core::arch`- ის გამოყენება ამ crate- ის საშუალებით მოითხოვს Rust- ს და მას ხშირად შეუძლია (და აკეთებს) შესვენებას.ერთადერთი შემთხვევა, როდესაც უნდა გაითვალისწინოთ მისი გამოყენება ამ crate- ით, არის:

* თუ თქვენ გჭირდებათ `core::arch`-ის ხელახლა შედგენა, მაგალითად, ჩართულია სპეციალური სამიზნე მახასიათებლები, რომლებიც არ არის ჩართული `libcore`/`libstd`-ისთვის.
Note: თუ თქვენ გჭირდებათ მისი არასტანდარტული სამიზნეის ხელახლა შედგენა, ამ crate-ის ნაცვლად, გირჩევნიათ გამოიყენოთ `xargo` და ხელახლა შეადგინოთ `libcore`/`libstd`.
  
* ზოგიერთი მახასიათებლის გამოყენებით, რომლებიც შესაძლოა არ იყოს ხელმისაწვდომი არასტაბილური Rust მახასიათებლების მიღმაც.ჩვენ ვცდილობთ ეს მინიმუმამდე დავიყვანოთ.
თუ თქვენ გჭირდებათ ამ მახასიათებლების გამოყენება, გახსენით საკითხი ისე, რომ ჩვენ გამოვავლინოთ ისინი ღამით Rust-ში და მათი გამოყენება იქიდან შეძლოთ.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` ძირითადად ნაწილდება როგორც MIT ლიცენზიის, ისე Apache ლიცენზიის (ვერსია 2.0) პირობების შესაბამისად, ნაწილები, რომლებიც დაფარულია სხვადასხვა BSD მსგავსი ლიცენზიით.

დეტალებისთვის იხილეთ LICENSE-APACHE და LICENSE-MIT.

# Contribution

თუ თქვენ პირდაპირ არ თქვით სხვაგვარად, თქვენს მიერ `core_arch`-ში ჩასასმელად განზრახ შეტანილი ნებისმიერი წვლილი, როგორც ეს განსაზღვრულია Apache-2.0 ლიცენზიაში, ორმაგი ლიცენზირებული იქნება ზემოთ, ყოველგვარი დამატებითი პირობებისა და პირობების გარეშე.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












