#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// იხილეთ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// იხილეთ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// იხილეთ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// იხილეთ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// იხილეთ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// იხილეთ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// მოიტანეთ ქეშის ხაზი, რომელიც შეიცავს მისამართს `p` მოცემული `rw` და `locality` გამოყენებით.
///
/// `rw` უნდა იყოს ერთ-ერთი:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): პრეფეტჩი ემზადება წაკითხვისთვის.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): პრეფეტჩი წერისთვის ემზადება.
///
/// `locality` უნდა იყოს ერთ-ერთი:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): ნაკადი ან არა-დროებითი წინასწარი მონაცემი, მონაცემებისთვის, რომელიც გამოიყენება მხოლოდ ერთხელ.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): მოიყვანეთ მე -3 დონის მეხსიერებაში.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): 2-ე დონის ქეშის გადატანა.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): 1-ე დონის ქეშში მოტანა.
///
/// წინასწარი მეხსიერების ინსტრუქციები მეხსიერების სისტემას აწვდის სიგნალს, რომ მეხსიერების წვდომა მითითებული მისამართიდან შეიძლება მოხდეს ახლომდებარე future-ში.
/// მეხსიერების სისტემას შეუძლია რეაგირება მოახდინოს ისეთი ქმედებებით, რომლებიც, სავარაუდოდ, დააჩქარებს მეხსიერების წვდომას, როდესაც ხდება, მაგალითად, მითითებული მისამართის წინასწარ ჩატვირთვა ერთ ან მეტ მეხსიერებაში.
///
/// იმის გამო, რომ ეს სიგნალები მხოლოდ მინიშნებებია, კონკრეტული CPU- სთვის მოქმედებს ნებისმიერი ან ყველა წინასწარი მითითების NOP- ით მკურნალობა.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // ჩვენ ვიყენებთ `llvm.prefetch` ინსტრუქციას `cache type` =1 (მონაცემთა ქეში).
    // `rw` და `strategy` ემყარება ფუნქციის პარამეტრებს.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}