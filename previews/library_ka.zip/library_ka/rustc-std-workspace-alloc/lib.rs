#![feature(no_core)]
#![no_core]

// იხილეთ rustc-std-სამუშაო სივრცის ბირთვი, თუ რატომ არის ეს crate საჭირო.

// გადარქმევა crate, რომ თავიდან იქნას აცილებული წინააღმდეგობა მოდულთან liballoc.
extern crate alloc as foo;

pub use foo::*;