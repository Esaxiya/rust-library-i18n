//! `Cell` ვარიანტი (scoped) ეგზისტენციალური სიცოცხლის განმავლობაში.

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// აკრიფეთ lambda პროგრამა, მთელი ცხოვრების განმავლობაში.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// აკრიფეთ ლამბდა მთელი ცხოვრების განმავლობაში, ანუ `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) იმუშავეთ პროექციის შეზღუდვების გარშემო newtype FIXME(#52812) შეცვალეთ `&'a mut <T as ApplyL<'b>>::Out`
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// X001 გაშვებისას ადგენს მნიშვნელობას `self`-ში `replacement`-ში, რომელიც ძველ მნიშვნელობას იღებს, მუდამ.
    /// ძველი მნიშვნელობა აღდგება `f`- ის გასვლის შემდეგ, თუნდაც panic- ით, მათ შორის `f`- ით შეტანილი ცვლილებებით.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// შესაფუთი, რომელიც უზრუნველყოფს უჯრედის ყოველთვის შევსებას (თავდაპირველი მდგომარეობით, სურვილისამებრ შეიცვალა `f`), მაშინაც კი, თუ `f` პანიკაში იყო.
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// ადგენს `self` მნიშვნელობას `value`- ში `f`- ის გაშვების დროს.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}