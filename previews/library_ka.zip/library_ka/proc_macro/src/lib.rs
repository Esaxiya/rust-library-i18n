//! მაკრო ავტორების დამხმარე ბიბლიოთეკა ახალი მაკროების განსაზღვრისას.
//!
//! სტანდარტული ბიბლიოთეკის მიერ მოწოდებული ეს ბიბლიოთეკა უზრუნველყოფს ტიპების მოხმარებას პროცედურულად განსაზღვრული მაკრო განმარტებებისთვის, როგორიცაა ფუნქციის მსგავსი მაკროები `#[proc_macro]`, მაკრო ატრიბუტები `#[proc_macro_attribute]` და მორგებული ატრიბუტები`#[proc_macro_derive].
//!
//!
//! იხილეთ [the book] მეტი.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// განსაზღვრავს, ხელმისაწვდომია თუ არა proc_macro ხელმისაწვდომი პროგრამისთვის.
///
/// Proc_macro crate განკუთვნილია მხოლოდ პროცედურული მაკროების განხორციელებისას.ყველა ფუნქცია ამ crate panic-ში, თუ გამოძახებულია პროცედურული მაკროდან, მაგალითად, build სკრიპტიდან ან ერთეულის ტესტიდან ან ჩვეულებრივი Rust ორობიდან.
///
/// Rust ბიბლიოთეკების გათვალისწინებით, რომლებიც გამიზნულია როგორც მაკრო, ისე არა მაკრო გამოყენების შემთხვევების დასახმარებლად, `proc_macro::is_available()` გთავაზობთ პანიკაში მოხვედრის საშუალებას, რათა დადგინდეს, არის თუ არა ხელმისაწვდომი proc_macro API- ს გამოყენებისთვის საჭირო ინფრასტრუქტურა.
/// აბრუნებს მნიშვნელობას, თუ პროცედურული მაკროდან არის გამოძახებული, ყალბი, თუ რომელიმე სხვა ორობიდან არის გამოძახებული.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// ამ ტიპის crate მიერ მოწოდებული ძირითადი ტიპი, რომელიც წარმოადგენს tokens-ის აბსტრაქტულ ნაკადს, ან, უფრო კონკრეტულად, token ხეების თანმიმდევრობას.
/// ტიპი უზრუნველყოფს ინტერფეისებს token ხეების განმეორებადობისთვის და, პირიქით, token ხეების ერთ ნაკადში შეგროვებისთვის.
///
///
/// ეს არის `#[proc_macro]`, `#[proc_macro_attribute]` და `#[proc_macro_derive]` განსაზღვრებების როგორც შეყვანა, ასევე გამომავალი.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str`-დან დაბრუნებული შეცდომა.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// აბრუნებს ცარიელ `TokenStream`-ს, რომელშიც არ არის token ხე.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// ამოწმებს ცარიელია თუ არა ეს `TokenStream`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// სტრიქონის tokens გაყოფის და tokens-ის token ნაკადში გარჩევის მცდელობები.
/// შეიძლება ვერ მოხერხდეს რამოდენიმე მიზეზის გამო, მაგალითად, თუ სტრიქონი შეიცავს დაუბალანსებელ გამყოფი ან სიმბოლოებს, რომლებიც არ არსებობს ენაში.
///
/// გაანალიზებული ნაკადის ყველა tokens იღებს `Span::call_site()` დიაპაზონს.
///
/// NOTE: ზოგიერთმა შეცდომამ შეიძლება გამოიწვიოს panics `LexError`-ის დაბრუნების ნაცვლად.ჩვენ ვიტოვებთ უფლებას შეცვალოს ეს შეცდომები `LexError` მოგვიანებით.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, ხიდი უზრუნველყოფს მხოლოდ `to_string`-ს, განახორციელეთ `fmt::Display` მის საფუძველზე (ჩვეულებრივი ურთიერთობის საპირისპირო მხარე).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// ბეჭდავს token ნაკადს, როგორც სტრიქონი, რომელიც შეიძლება უნაკლოდ გარდაიქმნას იმავე token ნაკადში (მოდულის სიგრძე), გარდა `TokenTree: : Group` `Delimiter::None` გამყოფი და უარყოფითი რიცხვითი ასოებით.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ბეჭდავს token-ს გამოსწორებისათვის მოსახერხებელი ფორმით.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// ქმნის token ნაკადს, რომელიც შეიცავს ერთ token ხეს.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// აგროვებს token რიგ ხეებს ერთ ნაკადში.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// "flattening" ოპერაცია token ნაკადებზე, აგროვებს token ხეებს მრავალი token ნაკადებიდან ერთ ნაკადში.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) გამოიყენეთ ოპტიმიზირებული დანერგვა if/when.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// `TokenStream` ტიპის საზოგადოების რეალიზაციის დეტალები, როგორიცაა განმეორება.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Iterator`TokenStream-ის`TokenTree` ს შესახებ.
    /// განმეორებაა "shallow", მაგ., გამეორება არ იშორებს გამოყოფილ ჯგუფებს და აბრუნებს მთელ ჯგუფებს token ხეებად.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` იღებს თვითნებურ tokens-ს და ფართოვდება `TokenStream`-ში, რომელშიც აღწერილია შეყვანა.
/// მაგალითად, `quote!(a + b)` წარმოქმნის გამოხატვას, რომელიც შეფასებისას აშენებს `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// მოხსენიება ხორციელდება `$`- ით და მუშაობს შემდეგი შემდეგი იდენტურობით, როგორც არ ციტირებული ტერმინით.
/// `$` თავის ციტირებისთვის გამოიყენეთ `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// კოდის რეგიონი, მაკრო გაფართოების ინფორმაციასთან ერთად.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// ქმნის ახალ `Diagnostic`-ს მოცემული `message`-ით `self` სიგრძეზე.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// სიგრძე, რომელიც მოგვარდება მაკრო განსაზღვრის საიტზე.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// მოქმედი პროცედურული მაკროს გამოძახების ხანგრძლივობა.
    /// ამ დიაპაზონით შექმნილი იდენტიფიკატორები გადაწყდება ისე, რომ თითქოს ისინი დაწერილი იყოს პირდაპირ მაკრო ზარის ადგილზე (ზარის საიტის ჰიგიენა) და მაკრო ზარის საიტზე განთავსებულ სხვა კოდში იქნება შესაძლებელი მათზე მითითებაც.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// დიაპაზონი, რომელიც წარმოადგენს `macro_rules` ჰიგიენას და ზოგჯერ წყდება მაკრო განსაზღვრის საიტზე (ადგილობრივი ცვლადები, ეტიკეტები, `$crate`) და ზოგჯერ მაკრო ზარის საიტზე (ყველაფერი დანარჩენი).
    ///
    /// გაშლის ადგილი აღებულია ზარის საიტიდან.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// ორიგინალი საწყისი ფაილი, რომელშიც მიუთითებს ეს დიაპაზონი.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` tokens- სთვის წინა მაკრო გაფართოებისას, საიდანაც წარმოიქმნა `self`, ასეთის არსებობის შემთხვევაში.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// დაწყების კოდის ხანგრძლივობა, რომლისგანაც შეიქმნა `self`.
    /// თუ ეს `Span` არ არის გამომუშავებული სხვა მაკრო გაფართოების შედეგად, დაბრუნების მნიშვნელობა იგივეა, რაც `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// იღებს დაწყების line/column ამ ფაილის წყაროს ფაილში.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// იღებს ამ ბოლოსთვის line/column წყაროს ფაილს.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// ქმნის ახალ დიაპაზონს, რომელიც მოიცავს `self` და `other`.
    ///
    /// აბრუნებს `None`-ს, თუ `self` და `other` სხვადასხვა ფაილიდან არის.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// ქმნის ახალ დიაპაზონს იგივე line/column ინფორმაციით, როგორც `self`, მაგრამ ის წყვეტს სიმბოლოებს, ვითომ `other`- ზე.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// ქმნის ახალ დიაპაზონს იგივე სახელის რეზოლუციის ქცევით, როგორც `self`, მაგრამ `other` line/column ინფორმაციით.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// ადარებს spans-ს, რომ მათი ტოლი იყოს.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// აბრუნებს საწყისი ტექსტს span.
    /// ეს ინახავს თავდაპირველ კოდს, სივრცეების და კომენტარების ჩათვლით.
    /// იგი მხოლოდ შედეგს უბრუნებს, თუ span შეესაბამება რეალურ კოდს.
    ///
    /// Note: მაკროდან შესამჩნევი შედეგი მხოლოდ tokens- ს უნდა დაეყრდნოს და არა ამ წყაროს ტექსტს.
    ///
    /// ამ ფუნქციის შედეგი არის საუკეთესო მცდელობა, რომ გამოიყენოთ მხოლოდ დიაგნოსტიკისთვის.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// ბეჭდავს ხანგრძლივობას შეცდომების გამოსასწორებლად მოსახერხებელ ფორმაში.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// ხაზის სვეტის წყვილი, რომელიც წარმოადგენს `Span`-ის დასაწყისს ან დასასრულს.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// წყაროს ფაილში 1 ინდექსაციური ხაზი, რომელზეც იწყება ან მთავრდება (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 0 ინდექსირებული სვეტი (UTF-8 სიმბოლოებით) წყაროს ფაილში, რომელზეც იწყება ან მთავრდება (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// მოცემული `Span` წყაროს ფაილი.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// იღებს გზას ამ წყაროს ფაილისკენ.
    ///
    /// ### Note
    /// თუ ამ `SourceFile`- სთან ასოცირებული კოდის მოქმედება შეიქმნა გარე მაკროთი, ამ მაკროთი, ეს შეიძლება არ იყოს ფაილთა სისტემის ნამდვილი გზა.
    /// შეამოწმეთ [`is_real`].
    ///
    /// ასევე გაითვალისწინეთ, რომ მაშინაც კი, თუ `is_real` დააბრუნებს `true`, თუ `--remap-path-prefix` გაიარა ბრძანების ხაზზე, მოცემული გეზი შესაძლოა არ იყოს მართებული.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// აბრუნებს `true`-ს, თუ ეს საწყისი ფაილი არის ნამდვილი საწყისი ფაილი და არ არის გენერირებული გარე მაკროს გაფართოებით.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // ეს არის გატეხვა, სანამ ინტერკრატული მოცულობები განხორციელდება და ჩვენ შეგვიძლია ვიყოთ რეალური წყაროების ფაილები გარე მაკროებში წარმოქმნილი მოცულობებისთვის.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// ერთი token ან token ხეების გამიჯნული თანმიმდევრობა (მაგ., `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// token ნაკადი, რომელიც გარშემორტყმულია ფრჩხილების გამყოფებით.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// იდენტიფიკატორი.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// ერთი პუნქტუაციის სიმბოლო ("+", `,`, `$` და ა.შ.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// ლიტერატურული სიმბოლო (`'a'`), სიმებიანი (`"hello"`), რიცხვი (`2.3`) და ა.შ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// აბრუნებს ამ ხის სიგრძეს, გადასცემს `span` მეთოდს შეიცავს token ან შემოსაზღვრული ნაკადის.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// ახდენს დიაპაზონის კონფიგურაციას *მხოლოდ ამ token*-ისთვის.
    ///
    /// გაითვალისწინეთ, რომ თუ ეს token არის `Group`, მაშინ ეს მეთოდი არ განსაზღვრავს თითოეული შიდა tokens დიაპაზონის კონფიგურაციას, ეს უბრალოდ გადაეცემა თითოეული ვარიანტის `set_span` მეთოდს.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// ბეჭდავს token ხეს გამოსწორებისათვის მოსახერხებელი ფორმით.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // თითოეულ მათგანს აქვს სახელწოდება სტრუქტურულ ტიპში მიღებულ ხარვეზში, ასე რომ ნუ შეაწუხებთ ირიდენტობის დამატებით ფენას
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, ხიდი უზრუნველყოფს მხოლოდ `to_string`-ს, განახორციელეთ `fmt::Display` მის საფუძველზე (ჩვეულებრივი ურთიერთობის საპირისპირო მხარე).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// ბეჭდავს token ხეს, როგორც სტრიქონი, რომელიც უნდა დაკარგოს და გარდაიქმნას იმავე token ხეში (მოდულის სიგრძე), გარდა `TokenTree: : Group` `Delimiter::None` გამყოფი და უარყოფითი რიცხვითი ასოებით.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// შემოფარგლული token ნაკადი.
///
/// `Group` შინაგანად შეიცავს `TokenStream`-ს, რომელიც გარშემორტყმულია `Delimiter`-ით.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// აღწერს, თუ როგორ განლაგებულია token ხეების თანმიმდევრობა.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// ნაგულისხმევი გამყოფი, რომელიც შეიძლება, მაგალითად, აღმოჩნდეს tokens-ის გარშემო, რომელიც მოდის "macro variable" `$var`.
    /// მნიშვნელოვანია ოპერატორის პრიორიტეტების დაცვა ისეთ შემთხვევებში, როგორიცაა `$var * 3`, როდესაც `$var` არის `1 + 2`.
    /// ნაგულისხმევი გამყოფები შეიძლება არ გადარჩეს token ნაკადის მობრუნებული სტრიქონის მეშვეობით.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// ქმნის ახალ `Group`-ს მოცემული გამყოფი და token ნაკადით.
    ///
    /// ეს კონსტრუქტორი ამ ჯგუფის ხანგრძლივობას დაადგენს `Span::call_site()`.
    /// ხანგრძლივობის შესაცვლელად შეგიძლიათ გამოიყენოთ ქვემოთ მოცემული `set_span` მეთოდი.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// აბრუნებს ამ `Group`-ის გამყოფს
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// აბრუნებს tokens-ის `TokenStream`-ს, რომელიც შემოიფარგლება ამ `Group`-ში.
    ///
    /// გაითვალისწინეთ, რომ დაბრუნებული token ნაკადი არ შეიცავს ზემოთ დაბრუნებულ გამყოფს.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// აბრუნებს დიაპაზონს ამ token ნაკადის გამყოფებისათვის, მთლიანი `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// აბრუნებს დიაპაზონს ამ ჯგუფის გახსნის გამყოფზე.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// აბრუნებს დიაპაზონს ამ ჯგუფის დახურვის გამყოფზე.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// ახდენს დიაპაზონის კონფიგურაციას ამ `ჯგუფის` გამყოფთათვის, მაგრამ არა მისი შიდა tokens.
    ///
    /// ეს მეთოდი ** არ დააყენებს ამ ჯგუფის მასშტაბით გათვალისწინებული ყველა შიდა tokens-ის დიაპაზონს, არამედ ის განსაზღვრავს მხოლოდ გამყოფი tokens-ის დიაპაზონს `Group` დონეზე.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, ხიდი უზრუნველყოფს მხოლოდ `to_string`-ს, განახორციელეთ `fmt::Display` მის საფუძველზე (ჩვეულებრივი ურთიერთობის საპირისპირო მხარე).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ბეჭდავს ჯგუფს, როგორც სტრიქონი, რომელიც დაკარგულად უნდა გარდაიქმნას იმავე ჯგუფში (მოდულების სიგრძე), გარდა შესაძლოა `TokenTree: : Group` `Delimiter::None` გამყოფი.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` არის ერთი პუნქტუაციის სიმბოლო, როგორიცაა `+`, `-` ან `#`.
///
/// მრავალ პერსონაჟიანი ოპერატორები, როგორიცაა `+=`, წარმოდგენილია როგორც `Punct` ორი ინსტანცია, რომელთაც დაუბრუნდებათ `Spacing` სხვადასხვა ფორმა.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// მოჰყვება `Punct`-ს დაუყოვნებლივ სხვა `Punct` თუ მოჰყვება სხვა token ან თეთრი სივრცე.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// მაგ., `+` არის `Alone` `+ =`, `+ident` ან `+()`-ში.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// მაგ., `+` არის `Joint` `+=` ან `'#`-ში.
    /// დამატებით, `'` ერთ ციტირებას შეუძლია შეუერთდეს იდენტიფიკატორებს და შექმნას სიცოცხლის ხანგრძლივობა `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// ქმნის ახალ `Punct`-ს მოცემული სიმბოლოდან და ინტერვალიდან.
    /// `ch` არგუმენტი უნდა იყოს ენის მიერ ნებადართული ნიშნების სწორი სიმბოლო, წინააღმდეგ შემთხვევაში ფუნქცია იქნება panic.
    ///
    /// დაბრუნებულ `Punct`- ს ექნება `Span::call_site()`- ის ნაგულისხმევი დიაპაზონი, რომლის კონფიგურაცია შესაძლებელია ქვემოთ მოცემული `set_span` მეთოდით.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// აბრუნებს ამ პუნქტუაციის სიმბოლოს `char` მნიშვნელობას.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// აბრუნებს ამ პუნქტუაციის სიმბოლოს ინტერვალით, მიუთითებს, დაუყოვნებლივ მოყვება თუ არა მას სხვა `Punct` token ნაკადში, ასე რომ, ისინი პოტენციურად შეიძლება გაერთიანდეს მრავალ პერსონაჟის ოპერატორში (`Joint`), ან მას მოსდევს სხვა token ან (`Alone`) სივრცეში, ასე რომ ოპერატორს ნამდვილად აქვს დასრულდა.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// აბრუნებს ამ პუნქტუაციის სიმბოლოს ხანგრძლივობას.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ამ პუნქტუაციის სიმბოლოსთვის კონფიგურაცია გაუწიეთ span-ს.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ხიდი უზრუნველყოფს მხოლოდ `to_string`-ს, განახორციელეთ `fmt::Display` მის საფუძველზე (ჩვეულებრივი ურთიერთობის საპირისპირო მხარე).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// დაბეჭდის პუნქტუაციის სიმბოლოს, როგორც სტრიქონს, რომელიც უნდა დაკარგოს კონვერტირებად იმავე სიმბოლოში.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// იდენტიფიკატორი (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// ქმნის ახალ `Ident`-ს მოცემული `string`-ით, ისევე როგორც მითითებული `span`-ით.
    /// `string` არგუმენტი უნდა იყოს მოქმედი იდენტიფიკატორი, რომელიც ნებადართულია ენის მიერ (საკვანძო სიტყვების ჩათვლით, მაგ. `self` ან `fn`).წინააღმდეგ შემთხვევაში, ფუნქცია იქნება panic.
    ///
    /// გაითვალისწინეთ, რომ `span`, ამჟამად rustc-ში, კონფიგურაციას უკეთებს ჰიგიენის ინფორმაციას ამ იდენტიფიკატორისთვის.
    ///
    /// ამ დროისთვის `Span::call_site()` აშკარად ირჩევს "call-site" ჰიგიენას, რაც ნიშნავს, რომ ამ დიაპაზონში შექმნილი იდენტიფიკატორები მოგვარდება ისე, რომ თითქოს ისინი დაწერილი არიან მაკრო ზარის ადგილას, ხოლო მაკრო ზარის საიტზე სხვა კოდს შეეძლება მითითება მათ ასევე.
    ///
    ///
    /// `Span::def_site()`-ის მსგავსად შემდგომი პერიოდები საშუალებას მისცემს უარი თქვან "definition-site" ჰიგიენაზე, რაც ნიშნავს, რომ ამ დიაპაზონში შექმნილი იდენტიფიკატორები გადაწყდება მაკრო განსაზღვრის ადგილას და მაკრო ზარის საიტზე სხვა კოდი ვერ შეძლებს მათ მითითებას.
    ///
    /// ჰიგიენის ამჟამინდელი მნიშვნელობის გამო, ეს კონსტრუქტორი, სხვა tokens-სგან განსხვავებით, მოითხოვს `Span`-ს მითითებას მშენებლობის დროს.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// იგივეა, რაც `Ident::new`, მაგრამ ქმნის ნედლ იდენტიფიკატორს (`r#ident`).
    /// `string` არგუმენტი იქნება მოქმედი იდენტიფიკატორი, რომელიც ნებადართულია ენის მიერ (საკვანძო სიტყვების ჩათვლით, მაგ. `fn`).
    /// საკვანძო სიტყვები, რომლებიც გამოსადეგია გზის სეგმენტებში (მაგ
    /// `self`, `super`) არ არის მხარდაჭერილი და გამოიწვევს panic-ს.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// აბრუნებს ამ `Ident`-ის ხანგრძლივობას, მოიცავს [`to_string`](Self::to_string)-ით დაბრუნებულ მთელ სტრიქონს.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// კონფიგურაციას უკეთებს ამ `Ident`-ის ხანგრძლივობას, შესაძლოა შეიცვალოს მისი ჰიგიენის კონტექსტი.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ხიდი უზრუნველყოფს მხოლოდ `to_string`-ს, განახორციელეთ `fmt::Display` მის საფუძველზე (ჩვეულებრივი ურთიერთობის საპირისპირო მხარე).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// იბეჭდება იდენტიფიკატორი, როგორც სტრიქონი, რომელიც უდანაკარგოდ უნდა გარდაიქმნას იმავე იდენტიფიკატორში.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// პირდაპირი სტრიქონი (`"hello"`), ბაიტის სტრიქონი (`b"hello"`), სიმბოლო (`'a'`), ბაიტის სიმბოლო (`b'a'`), მთელი ან მცურავი წერტილის რიცხვი სუფიქსით ან მის გარეშე (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// ლოგიკური ასოები, როგორიცაა `true` და `false`, აქ არ არის, ისინი `იდენტურია`.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// ქმნის ახალ სუფიქსიან რიცხვს, პირდაპირი მნიშვნელობით, მითითებული მნიშვნელობით.
        ///
        /// ეს ფუნქცია შექმნის მთელ რიცხვს, როგორიცაა `1u32`, სადაც მითითებული მთელი რიცხვი არის token-ის პირველი ნაწილი, ხოლო ინტეგრალი ასევე სუფიქსირდება ბოლოს.
        /// უარყოფითი რიცხვებისგან შექმნილი ასოები შეიძლება არ გადარჩეს მრგვალი მოგზაურობის დროს `TokenStream` ან სტრიქონებში და შეიძლება დაიყოს ორ tokens (`-` და პოზიტიურად პირდაპირი).
        ///
        ///
        /// ამ მეთოდის საშუალებით შექმნილ ასოებს აქვთ `Span::call_site()` დიაპაზონი, რომლის კონფიგურაცია შესაძლებელია `set_span` მეთოდით.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// ქმნის ახალ არაოფიცირებულ მთელ რიგს მითითებული მნიშვნელობით.
        ///
        /// ეს ფუნქცია შექმნის მთელ რიცხვს, როგორიცაა `1`, სადაც მითითებული მთელი რიცხვი არის token-ის პირველი ნაწილი.
        /// ამ token-ზე არ არის მითითებული სუფიქსი, რაც იმას ნიშნავს, რომ `Literal::i8_unsuffixed(1)`-ის მსგავსი გამოძახებები `Literal::u32_unsuffixed(1)` ექვივალენტურია.
        /// უარყოფითი რიცხვებისგან შექმნილი ასოები შეიძლება არ გადარჩეს გადანაწილებით `TokenStream` ან სტრიქონების მეშვეობით და შეიძლება დაიყოს ორ tokens (`-` და პოზიტიურად პირდაპირი).
        ///
        ///
        /// ამ მეთოდის საშუალებით შექმნილ ასოებს აქვთ `Span::call_site()` დიაპაზონი, რომლის კონფიგურაცია შესაძლებელია `set_span` მეთოდით.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// ქმნის ახალ არაორაზირებულ მცურავ წერტილს.
    ///
    /// ეს კონსტრუქტორი მსგავსია `Literal::i8_unsuffixed`- ის მსგავსი, სადაც float- ის მნიშვნელობა უშუალოდ token- ში გამოიყოფა, მაგრამ არ გამოიყენება სუფიქსი, ამიტომ შემდგენელში შეიძლება მოგვიანებით მივიღოთ `f64`.
    ///
    /// უარყოფითი რიცხვებისგან შექმნილი ასოები შეიძლება არ გადარჩეს გადანაწილებით `TokenStream` ან სტრიქონების მეშვეობით და შეიძლება დაიყოს ორ tokens (`-` და პოზიტიურად პირდაპირი).
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია მოითხოვს, რომ მითითებული ათწილადი სასრული იყოს, მაგალითად, თუ იგი უსასრულობაა ან NaN, ეს ფუნქცია იქნება panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// ქმნის ახალ სუფიქსის მცურავი წერტილის ლიტერატურას.
    ///
    /// ეს კონსტრუქტორი შექმნის `1.0f32`-ის მსგავსი ლიტერატურას, სადაც მითითებული მნიშვნელობა არის token-ის წინა ნაწილი და `f32` არის token სუფიქსი.
    /// ამ token შემდგენელში ყოველთვის გამოითვლება `f32`.
    /// უარყოფითი რიცხვებისგან შექმნილი ასოები შეიძლება არ გადარჩეს გადანაწილებით `TokenStream` ან სტრიქონების მეშვეობით და შეიძლება დაიყოს ორ tokens (`-` და პოზიტიურად პირდაპირი).
    ///
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია მოითხოვს, რომ მითითებული ათწილადი სასრული იყოს, მაგალითად, თუ იგი უსასრულობაა ან NaN, ეს ფუნქცია იქნება panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// ქმნის ახალ არაორაზირებულ მცურავ წერტილს.
    ///
    /// ეს კონსტრუქტორი მსგავსია `Literal::i8_unsuffixed`- ის მსგავსი, სადაც float- ის მნიშვნელობა უშუალოდ token- ში გამოიყოფა, მაგრამ არ გამოიყენება სუფიქსი, ამიტომ შემდგენელში შეიძლება მოგვიანებით მივიღოთ `f64`.
    ///
    /// უარყოფითი რიცხვებისგან შექმნილი ასოები შეიძლება არ გადარჩეს გადანაწილებით `TokenStream` ან სტრიქონების მეშვეობით და შეიძლება დაიყოს ორ tokens (`-` და პოზიტიურად პირდაპირი).
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია მოითხოვს, რომ მითითებული ათწილადი სასრული იყოს, მაგალითად, თუ იგი უსასრულობაა ან NaN, ეს ფუნქცია იქნება panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// ქმნის ახალ სუფიქსის მცურავი წერტილის ლიტერატურას.
    ///
    /// ეს კონსტრუქტორი შექმნის `1.0f64`-ის მსგავსი ლიტერატურას, სადაც მითითებული მნიშვნელობა არის token-ის წინა ნაწილი და `f64` არის token სუფიქსი.
    /// ამ token შემდგენელში ყოველთვის გამოითვლება `f64`.
    /// უარყოფითი რიცხვებისგან შექმნილი ასოები შეიძლება არ გადარჩეს გადანაწილებით `TokenStream` ან სტრიქონების მეშვეობით და შეიძლება დაიყოს ორ tokens (`-` და პოზიტიურად პირდაპირი).
    ///
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია მოითხოვს, რომ მითითებული ათწილადი სასრული იყოს, მაგალითად, თუ იგი უსასრულობაა ან NaN, ეს ფუნქცია იქნება panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// სიმებიანი.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// პერსონაჟი პირდაპირია.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// ბაიტის სიმებიანი სიტყვასიტყვით.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// აბრუნებს ამ სტრიქონების მოცულობას.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// კონფიგურაციას ახდენს ამ ლიტერატურული მნიშვნელობის ხანგრძლივობას.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// აბრუნებს `Span`, რომელიც არის `self.span()` ქვეჯგუფი, რომელიც შეიცავს მხოლოდ წყაროს ბაიტებს `range` დიაპაზონში.
    /// აბრუნებს `None`-ს, თუ სავარაუდო გასწორებული სიგრძე `self`-ის საზღვრებს მიღმაა.
    ///
    // FIXME(SergioBenitez): შეამოწმეთ რომ ბაიტის დიაპაზონი იწყება და მთავრდება წყაროს UTF-8 საზღვარზე.
    // წინააღმდეგ შემთხვევაში, სავარაუდოა, რომ panic სხვაგან მოხდეს, როდესაც წყარო ტექსტი დაიბეჭდება.
    // FIXME(SergioBenitez): მომხმარებელს არ აქვს საშუალება იცოდეს რას ასახავს `self.span()` სინამდვილეში, ამიტომ ამ მეთოდს ამჟამად მხოლოდ ბრმად შეიძლება ეწოდოს.
    // მაგალითად, `to_string()` სიმბოლო 'c' აბრუნებს "'\u{63}'";მომხმარებელს არ აქვს საშუალება გაიგოს, იყო თუ არა საწყისი ტექსტი 'c' ან იყო ის '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) რაღაც მსგავსია `Option::cloned`-ს, მაგრამ `Bound<&T>`-სთვის.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, ხიდი უზრუნველყოფს მხოლოდ `to_string`-ს, განახორციელეთ `fmt::Display` მის საფუძველზე (ჩვეულებრივი ურთიერთობის საპირისპირო მხარე).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ბეჭდავს ლიტერატურას, როგორც სტრიქონს, რომელიც უნდა დაკარგოს კონვერტირებად იმავე ლიტერატურაში (გარდა მცურავი წერტილის ტექსტური წერილების შესაძლო დამრგვალებისა).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// თვალყური ედევნება გარემო ცვლადებზე.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// გარემოს ცვლადის მოძიება და დამატებაზე დამოკიდებულების ინფორმაციის შესაქმნელად.
    /// შემდგენლის შემსრულებელი სისტემის აშენება იცნობს, რომ ცვლადზე წვდომა მოხდა კომპილაციის დროს და შეძლებს აღდგენას ხელახლა, როდესაც ამ ცვლადის მნიშვნელობა შეიცვლება.
    ///
    /// დამოკიდებულების თვალყურისდევნების გარდა, ეს ფუნქცია უნდა იყოს ექვივალენტი `env::var` სტანდარტული ბიბლიოთეკისგან, გარდა იმისა, რომ არგუმენტი უნდა იყოს UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}