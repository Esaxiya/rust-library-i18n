// rsbegin.o და rsend.o არის ე.წ. "compiler runtime startup objects".
// ისინი შეიცავს კოდს, რომელიც სწორად იწყებს შემდგენლის ხანგრძლივობის შესრულებას.
//
// როდესაც შესრულებადი ან dylib სურათი უკავშირდება, ყველა მომხმარებლის კოდი და ბიბლიოთეკა არის "sandwiched" ამ ორ ობიექტის ფაილებს შორის, ამიტომ კოდი ან მონაცემები rsbegin.o- დან ხდება პირველი სურათის შესაბამის სექციებში, ხოლო კოდი და მონაცემები rsend.o- დან ხდება უკანასკნელი.
// ეს ეფექტი შეიძლება გამოყენებულ იქნას განყოფილების დასაწყისში ან ბოლოს სიმბოლოების დასაყენებლად, ასევე ნებისმიერი საჭირო სათაურის ან ქვედა კოლონტიტულის ჩასასმელად.
//
// გაითვალისწინეთ, რომ მოდულის საწყისი წერტილი მდებარეობს C ხანგრძლივობის გაშვების ობიექტში (რომელსაც ჩვეულებრივ უწოდებენ `crtX.o`), რომელიც შემდეგ იწვევს სხვა კომპონენტების შესრულების ინიციალიზაციას (რეგისტრირებულია კიდევ ერთი სპეციალური სურათის განყოფილების საშუალებით).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // დასტის ჩარჩოს დასაწყისის ნიშნები იშლება ინფორმაციის განყოფილების განტვირთვისთვის
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // გადასაფხეკი ადგილი წიგნების შიდა შენახვისთვის.
    // ეს განისაზღვრება, როგორც `struct object` $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // გახსენით ინფორმაცია registration/deregistration რუტინები.
    // იხილეთ libpanic_unwind-ის დოკუმენტები.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // დაარეგისტრირეთ ინფორმაცია მოდულის გაშვების შესახებ
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // რეგისტრაციის გაუქმება გამორთვაზე
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW სპეციფიკური init/uninit რუტინული რეგისტრაცია
    pub mod mingw_init {
        // MinGW- ის გაშვების ობიექტები (crt0.o/dllcrt0.o) გამოიყენებენ გლობალურ კონსტრუქტორებს .ctors და .dtors სექციებში გაშვებისა და გასვლის შესახებ.
        // DLL- ების შემთხვევაში, ეს ხდება DLL- ის ჩატვირთვის და გადმოტვირთვისას.
        //
        // დამაკავშირებელი დაალაგებს სექციებს, რაც უზრუნველყოფს ჩვენი ზარების განლაგებას სიის ბოლოს.
        // ვინაიდან კონსტრუქტორების მართვა ხდება საპირისპირო თანმიმდევრობით, ეს უზრუნველყოფს ჩვენი უკუკავშირის შესრულებას პირველი და ბოლო.
        //
        //

        #[link_section = ".ctors.65535"] // .ქტორები. *: C ინიცირების ზარები
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C დასრულების ზარები
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}