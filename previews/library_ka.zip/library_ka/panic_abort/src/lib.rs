//! Rust panics-ის განხორციელება პროცესის შეწყვეტის გზით
//!
//! განტვირთვის საშუალებით განხორციელებასთან შედარებით, ეს crate * ბევრად უფრო მარტივია!როგორც ითქვა, ეს არც ისე მრავალმხრივია, მაგრამ აი აქ!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" დატვირთვა და შემცირება შესაბამის აბორტზე მოცემულ პლატფორმაზე.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // დარეკეთ std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows- ზე გამოიყენეთ პროცესორის სპეციფიკური __ სწრაფი დაზიანების მექანიზმი.Windows 8 და უფრო ახალი ვერსიით, ეს პროცესს დაუყოვნებლივ შეწყვეტს პროცესში გამონაკლისების დამუშავების გარეშე.
            // Windows- ის ადრინდელ ვერსიებში ინსტრუქციების ეს მიმდევრობა განიხილება, როგორც წვდომის დარღვევა, რაც წყვეტს პროცესს, მაგრამ ყველა გამონაკლისის დამმუშავებლის გვერდის ავლით.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ეს არის იგივე განხორციელება, როგორც libstd's `abort_internal`-ში
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// ეს ... ცოტა უცნაურია.Tl; dr;არის ის, რომ ეს საჭიროა სწორად დასაკავშირებლად, გრძელი ახსნა ქვემოთ.
//
// ახლა libcore/libstd-ის ორობითი სისტემა, რომელსაც ჩვენ ვაგზავნით, შედგენილია `-C panic=unwind`-ით.ეს კეთდება იმის უზრუნველსაყოფად, რომ binaries მაქსიმალურად შეესაბამება მაქსიმალურ სიტუაციებს.
// ამასთან, შემდგენელს სჭირდება "personality function" `-C panic=unwind`-ით შედგენილი ყველა ფუნქციისთვის.ეს პიროვნების ფუნქცია გაშიფრულია `rust_eh_personality` სიმბოლოზე და განისაზღვრება `eh_personality` ენაზე.
//
// So...
// რატომ არ უნდა განსაზღვროთ ეს ენა?კარგი კითხვაა panic ხანგრძლივობის დაკავშირების გზა სინამდვილეში ცოტათი დახვეწილია იმაში, რომ ისინი "sort of" არიან შემდგენელის crate მაღაზიაში, მაგრამ მხოლოდ სინამდვილეშია დაკავშირებული, თუ სხვა ნამდვილად არ არის დაკავშირებული.
//
// ეს ნიშნავს, რომ ეს crate და panic_unwind crate შეიძლება გამოჩნდეს შემდგენლის crate მაღაზიაში და თუ ორივე განსაზღვრავს `eh_personality` ენათა ელემენტს, ეს შეცდომას მოყვება.
//
// ამის გასამკლავებლად, შემდგენელს მხოლოდ `eh_personality` სჭირდება, თუ panic მოქმედების ხანგრძლივობა, რომელიც უკავშირდება, განტვირთვის ხანგრძლივობაა, წინააღმდეგ შემთხვევაში, ამის განსაზღვრა საჭირო არ არის (სწორად).
// ამ შემთხვევაში, ეს ბიბლიოთეკა უბრალოდ განსაზღვრავს ამ სიმბოლოს, ასე რომ სადმე მაინც აქვს პიროვნება.
//
// არსებითად ეს სიმბოლო უბრალოდ განსაზღვრულია, რომ სადენიანი იყოს libcore/libstd ორობითი ოდენობით, მაგრამ მას არასდროს არ უნდა ეწოდოს, რადგან საერთოდ არ ვუკავშირდებით განტვირთვის დროს.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // X86_64-pc-windows-gnu-ზე ჩვენ ვიყენებთ ჩვენს პიროვნულ ფუნქციას, რომელიც უნდა დააბრუნოს `ExceptionContinueSearch`, რადგან გადავცემთ ჩვენს ყველა ჩარჩოს.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // ზემოთ მოყვანილი მსგავსი, ეს შეესაბამება `eh_catch_typeinfo` ენათა ელემენტს, რომელიც ამჟამად გამოიყენება მხოლოდ Emscripten-ზე.
    //
    // რადგან panics არ ქმნის გამონაკლისებს და უცხოური გამონაკლისები ამჟამად UB- სთან არის -C panic=შეწყვეტილი (თუმცა ეს შეიძლება შეიცვალოს), ნებისმიერი ზარი_დაძახება არასოდეს გამოიყენებს ამ ტიპის ინფოს.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // ამ ორს იძახებენ ჩვენი გაშვების ობიექტები i686-pc-windows-gnu-ზე, მაგრამ მათ არაფრის გაკეთება არ სჭირდებათ, ამიტომ სხეულები არ არის.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}