//! მოდული, რომელიც ხელს შეუწყობს dbghelp კავშირების მართვას Windows-ზე
//!
//! უკუჩვენებები Windows- ზე (ყოველ შემთხვევაში, MSVC- სთვის) მეტწილად იკვებება `dbghelp.dll`- ით და სხვადასხვა ფუნქციებით, რომელსაც იგი შეიცავს.
//! ეს ფუნქციები ამჟამად იტვირთება *დინამიურად*, ვიდრე სტატიკურად უკავშირდება `dbghelp.dll`-ს.
//! ეს გაკეთებულია სტანდარტული ბიბლიოთეკის მიერ (და თეორიულად ამას მოითხოვს იქ), მაგრამ ის ცდილობს დაეხმაროს ბიბლიოთეკის სტატიკური DLL დამოკიდებულების შემცირებას, რადგან უკუქცევის ტიპები ჩვეულებრივ არჩეულია.
//!
//! როგორც ითქვა, `dbghelp.dll` თითქმის ყოველთვის წარმატებით იტვირთება Windows.
//!
//! გაითვალისწინეთ, რომ ვინაიდან ამ ყველა დახმარებას დინამიურად ვტვირთავთ, სინამდვილეში არ შეგვიძლია გამოვიყენოთ ნედლეული განსაზღვრებები `winapi`- ში, არამედ უნდა განვსაზღვროთ ფუნქციის მაჩვენებლის ტიპები და გამოვიყენოთ ეს.
//! ჩვენ ნამდვილად არ გვინდა ვინაპის დუბლირების საქმეში ვიყოთ, ამიტომ ჩვენ გვაქვს Cargo თვისება `verify-winapi`, რომელიც ამტკიცებს, რომ ყველა შესაკრავი ემთხვევა Winapi- ში და ეს ფუნქცია ჩართულია CI- ზე.
//!
//! დაბოლოს, აქვე გაითვალისწინებთ, რომ dll `dbghelp.dll`- სთვის არასოდეს იტვირთება და ეს გაკეთებულია განზრახ.
//! მოსაზრებაა, რომ შეგვიძლია გლობალურად გავაფართოვოთ იგი და გამოვიყენოთ იგი API- სკენ ზარებში, თავიდან ავიცილოთ ძვირი loads/unloads.
//! თუ ეს პრობლემაა გაჟონვის დეტექტორებისთვის ან მსგავსი რამ, ჩვენ შეგვიძლია ხიდზე გადასვლა, როდესაც იქ ჩავდივართ.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// იმუშავეთ `SymGetOptions` და `SymSetOptions` გარშემო, არ არის წარმოდგენილი Winapi- ში.
// წინააღმდეგ შემთხვევაში, ეს მხოლოდ მაშინ გამოიყენება, როდესაც ორმაგად ვამოწმებთ ტიპებს Winapi- ს წინააღმდეგ.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // ჯერ არ არის განსაზღვრული Winapi-ში
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // ეს განისაზღვრება winapi-ში, მაგრამ არასწორია (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // ჯერ არ არის განსაზღვრული Winapi-ში
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// ეს მაკრო გამოიყენება `Dbghelp` სტრუქტურის დასადგენად, რომელიც შინაგანად შეიცავს ყველა იმ ფუნქციის მითითებას, რომელთა ჩატვირთვაც შეიძლება.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// ჩატვირთულია DLL `dbghelp.dll`- ისთვის
            dll: HMODULE,

            // თითოეული ფუნქციის მაჩვენებელი თითოეული ფუნქციისთვის, რომელიც შეიძლება გამოვიყენოთ
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // თავდაპირველად ჩვენ არ დატვირთეთ DLL
            dll: 0 as *mut _,
            // თავდაპირველად ყველა ფუნქცია დაყენებულია ნულზე, რომ ითქვას, რომ ისინი დინამიურად უნდა ჩატვირთონ.
            //
            $($name: 0,)*
        };

        // მოსახერხებელი typedef თითოეული ფუნქციის ტიპისთვის.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` გახსნის მცდელობები.
            /// უბრუნებს წარმატებას, თუ ის მუშაობს ან შეცდომას, თუ `LoadLibraryW` ვერ ხერხდება.
            ///
            /// Panics თუ ბიბლიოთეკა უკვე დატვირთულია.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // თითოეული მეთოდის ფუნქცია, რომლის გამოყენებაც გვსურს.
            // დარეკვისას ან წაიკითხავს ქეშირებული ფუნქციის მაჩვენებელს ან ჩატვირთავს მას და დააბრუნებს დატვირთულ მნიშვნელობას.
            // წარმატების მისაღწევად იტვირთება დატვირთვები.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // კომფორტული მარიონეტული წმენდის საკეტების გამოყენება dbghelp ფუნქციების მითითების მიზნით.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// ამ crate- დან `dbghelp` API ფუნქციებზე წვდომისათვის საჭირო ყველა მხარდაჭერის ინიციალიზაცია.
///
///
/// გაითვალისწინეთ, რომ ეს ფუნქცია **უსაფრთხოა**, მას შინაგანად აქვს საკუთარი სინქრონიზაცია.
/// ასევე გაითვალისწინეთ, რომ უსაფრთხოა ამ ფუნქციის განმეორებით გამოძახება.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // პირველი, რაც უნდა გავაკეთოთ, არის ამ ფუნქციის სინქრონიზაცია.ამას შეიძლება ეწოდოს პარალელურად სხვა ძაფებიდან ან რეკურსიულად ერთი ძაფის შიგნით.
        // გაითვალისწინეთ, რომ ეს უფრო რთულიცაა, რადგან ამ პროცესში რასაც ჩვენ ვიყენებთ, `dbghelp`,*ასევე* სჭირდება სინქრონიზირება ყველა სხვა აბონენტთან `dbghelp`- ით.
        //
        // როგორც წესი, `dbghelp`-ზე იმავე ზარის რეალურად იმდენი ზარი არ არის ერთი და იგივე პროცესში და, ალბათ, უსაფრთხოდ შეგვიძლია ვიფიქროთ, რომ მხოლოდ ჩვენ ვწვდებით მას.
        // ამასთან, არსებობს კიდევ ერთი ძირითადი მომხმარებელი, რომელზეც ირონიულად უნდა ვიფიქროთ, მაგრამ სტანდარტულ ბიბლიოთეკაში.
        // Rust სტანდარტული ბიბლიოთეკა დამოკიდებულია ამ crate-ზე backtrace მხარდაჭერისთვის, და ეს crate ასევე არსებობს crates.io-ზე.
        // ეს ნიშნავს, რომ თუ სტანდარტული ბიბლიოთეკა ბეჭდავს panic უკანა მხარეს, მას შეუძლია შეჯიბრი გაუწიოს ამ crate- ს, რომელიც მოდის crates.io- დან, რაც იწვევს სეგმენტურ შეცდომებს.
        //
        // სინქრონიზაციის პრობლემის გადასაჭრელად ჩვენ ვიყენებთ Windows- ის სპეციფიკურ ხრიკს აქ (ეს, ბოლოს და ბოლოს, Windows- ის სპეციფიკური შეზღუდვაა სინქრონიზაციის შესახებ).
        // ამ ზარის დასაცავად ჩვენ ვქმნით *სესიის ადგილობრივ* სახელად mutex-ს.
        // მიზანი აქ არის ის, რომ სტანდარტულ ბიბლიოთეკას და ამ crate- ს არ უნდა გაუზიარონ Rust- ის დონის API- ები აქ სინქრონიზაციისთვის, მაგრამ მათ შეუძლიათ იმუშაონ კულისებში, რათა დარწმუნდნენ, რომ ისინი სინქრონიზდებიან ერთმანეთთან.
        //
        // ამ გზით, როდესაც ამ ფუნქციას იძახებენ სტანდარტული ბიბლიოთეკის საშუალებით ან crates.io- ით, დარწმუნებული უნდა ვიყოთ, რომ იგივე mutex იძენს.
        //
        // ამ ყველაფრისთვის უნდა ითქვას, რომ პირველი, რასაც აქ ვაკეთებთ, არის ატომურად შევქმნათ `HANDLE`, რომელიც დაასახელა mutex Windows- ზე.
        // ჩვენ ცოტათი ვასინქრონიზებთ სხვა თემებთან, რომლებიც ამ ფუნქციას სპეციალურად იზიარებს და ვცდილობთ, რომ მხოლოდ ერთი სახელური შეიქმნას ამ ფუნქციის მაგალითზე.
        // გაითვალისწინეთ, რომ სახელური არასდროს იკეტება გლობალურში შენახვის შემდეგ.
        //
        // მას შემდეგ, რაც რეალურად ჩავატარებთ საკეტს, მას უბრალოდ შევიძენთ და ჩვენი `Init` სახელური, რომელსაც დაურიგებთ, პასუხისმგებელი იქნება მისი საბოლოოდ ჩაგდებაზე.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // კარგი!ახლა, როდესაც ჩვენ ყველა უსაფრთხოდ სინქრონიზებულია, მოდით, რეალურად დავიწყოთ ყველაფრის დამუშავება.
        // პირველ რიგში, ჩვენ უნდა დავრწმუნდეთ, რომ `dbghelp.dll` ამ პროცესში დატვირთულია.
        // ჩვენ ამას ვაკეთებთ დინამიურად, რომ თავიდან ავიცილოთ სტატიკური დამოკიდებულება.
        // ეს ისტორიულად გაკეთდა უცნაური დამაკავშირებელი საკითხების მოსაწყობად და მიზნად ისახავს ორობით ოდნავ პორტატულობას, რადგან ეს ძირითადად მხოლოდ გამართვის პროგრამაა.
        //
        //
        // `dbghelp.dll`-ის გახსნის შემდეგ, მასში უნდა ვიწოდოთ რამდენიმე ინიციალიზაციის ფუნქცია, რაც დეტალურადაა მოცემული ქვემოთ.
        // ამას ჩვენ მხოლოდ ერთხელ ვაკეთებთ, ასე რომ, ჩვენ მივიღეთ გლობალური ლოგიკური ნიშანი, რომელიც მიუთითებს დასრულებამდე თუ არა.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // დარწმუნდით, რომ `SYMOPT_DEFERRED_LOADS` დროშა დაყენებულია, რადგან ამის შესახებ MSVC- ს საკუთარი დოკუმენტების მიხედვით: "This is the fastest, most efficient way to use the symbol handler.", მოდით ასე მოვიქცეთ!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // სინამდვილეში სიმბოლოების ინიცირება MSVC- ით.გაითვალისწინეთ, რომ ეს შეიძლება ვერ მოხერხდეს, მაგრამ ჩვენ ამას არ ვუვლით.
        // თავისთავად აქ ერთი ტონა ხელოვნება არ არის, მაგრამ LLVM შინაგანად აქ უგულებელყოფს დაბრუნების მნიშვნელობას და LLVM-ის ერთ-ერთი გამწმენდი ბიბლიოთეკა ბეჭდავს საშინელ გაფრთხილებას, თუ ეს ვერ მოხერხდება, მაგრამ ძირითადად უგულებელყოფს მას გრძელვადიან პერსპექტივაში.
        //
        //
        // ერთი შემთხვევა, რაც Rust- სთვის ბევრს გამოდგება არის ის, რომ სტანდარტულ ბიბლიოთეკას და ამ crate- ს crates.io- ზე ორივე სურთ კონკურენცია გაუწიონ `SymInitializeW`- ს.
        // სტანდარტულ ბიბლიოთეკას ისტორიულად სურდა დასუფთავების ინიცირება უმეტესად, მაგრამ ახლა, როდესაც იგი იყენებს ამ crate-ს, ეს ნიშნავს, რომ ვინმე პირველ რიგში მიიღებს ინიციალიზაციას, ხოლო მეორე მიიღებს ამ ინიციალიზაციას.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}