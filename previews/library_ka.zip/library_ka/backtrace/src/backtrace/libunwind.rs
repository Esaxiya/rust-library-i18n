//! Backtrace მხარდაჭერა libunwind/gcc_s/etc API- ს გამოყენებით.
//!
//! ეს მოდული შეიცავს დასტის განტვირთვის შესაძლებლობას libunwind სტილის API- ების გამოყენებით.
//! გაითვალისწინეთ, რომ არსებობს libunwind-ის მსგავსი API-ს მთელი რიგი განხორციელება, და ეს უბრალოდ ცდილობს იყოს ერთობლივი უმეტესობა ერთდროულად და არა შერჩევითი.
//!
//!
//! Libunwind API იკვებება `_Unwind_Backtrace`- ით და პრაქტიკაში ძალიან საიმედოა backtrace- ს წარმოქმნისას.
//! ბოლომდე არ არის ნათელი, როგორ ხდება ეს (ჩარჩოს მითითებები? Eh_frame ინფორმაცია? ორივე?), მაგრამ, როგორც ჩანს, მუშაობს!
//!
//! ამ მოდულის სირთულის უმეტესი ნაწილი პლატფორმის სხვადასხვა განსხვავებების მოგვარებაა libunwind- ის პროგრამებში.
//! წინააღმდეგ შემთხვევაში, ეს საკმაოდ მარტივი Rust სავალდებულოა libunwind API-ებისთვის.
//!
//! ეს არის ნაგულისხმევი განტვირთვის API ამჟამად არა-ვინდოუსის პლატფორმებისათვის.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// ნედლი libunwind მაჩვენებლის საშუალებით, მასზე წვდომა მხოლოდ წაკითხული ძაფით უსაფრთხო რეჟიმში უნდა იყოს, ასე რომ, ეს არის `Sync`.
// `Clone`- ით სხვა ძაფებზე გაგზავნისას ჩვენ ყოველთვის გადავდივართ ვერსიაზე, რომელიც არ ინარჩუნებს შინაგან მითითებებს, ამიტომ ჩვენც უნდა ვიყოთ `Send`.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // როგორც ჩანს, OSX-ზე `_Unwind_FindEnclosingFunction` უბრუნებს მაჩვენებელს ... რაღაც გაუგებარია.
        // ეს ყოველთვის არ არის თანდართული ფუნქცია რაიმე მიზეზით.
        // ჩემთვის ბოლომდე არ არის ნათელი, რა ხდება აქ, ასე რომ, ახლავე დააფასე ეს და უბრალოდ ყოველთვის დააბრუნე ip.
        //
        // გაითვალისწინეთ, რომ `skip_inner_frames.rs` ტესტი გამოტოვებულია OSX- ზე ამ პუნქტის გამო, და თუ ეს დაფიქსირდა, თეორიულად ტესტის ჩატარება OSX- ზე შეიძლება!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// გახსენით ბიბლიოთეკის ინტერფეისი, რომელიც გამოიყენება უკუქცევისთვის
///
/// გაითვალისწინეთ, რომ მკვდარი კოდი დასაშვებია, რადგან აქ არის მხოლოდ კავშირი, iOS არ იყენებს ყველა მათგანს, მაგრამ უფრო პლატფორმის სპეციფიკური კონფიგურაციების დამატება კოდს ძალიან აბინძურებს
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // გამოიყენება მხოლოდ ARM EABI-ს მიერ
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // არ არის შექმნილი _ გახსენით_ბექტრეისი iOS-ზე
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // ხელმისაწვდომია GCC 4.2.0- ით, ჩვენი მიზნისთვის ჯარიმა უნდა იყოს
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // ეს ფუნქცია არასწორი სახელია: ვიდრე ამ ჩარჩოს Canonical Frame მისამართი მიიღებს (იგივეა, რაც აბონენტის ჩარჩოს SP), ის აბრუნებს ამ ჩარჩოს SP-ს.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x იყენებს მიკერძოებულ CFA მნიშვნელობას, ამიტომ ჩვენ უნდა გამოვიყენოთ _Unwind_GetGR, რომ stack მაჩვენებელი დავრეგისტრირდეთ (%r15) ნაცვლად რომ ენდოთ _Unwind_GetCFA.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android და მკლავზე, ფუნქცია `_Unwind_GetIP` და სხვა რგოლები მაკროებია, ამიტომ ჩვენ განვსაზღვრავთ მაკროების გაფართოების შემცველ ფუნქციებს.
    //
    //
    // TODO: თუ შეგიძლიათ იპოვოთ ის სათაურის ფაილში, რომელიც განსაზღვრავს ამ მაკროებს.
    // (მე, ფიცგენ, ვერ ვპოულობ სათაურის ფაილს, რომლიდანაც ამ მაკრო გაფართოებების ნაწილი თავდაპირველად იყო ნასესხები).
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 არის დასტის მაჩვენებელი მკლავზე.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // ეს ფუნქცია ასევე არ არსებობს Android ან ARM/Linux- ზე, ასე რომ გახადეთ ის no-op.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}