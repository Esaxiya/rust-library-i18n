// ახლა მხოლოდ Linux- ზე გამოიყენება, ამიტომ სხვაგან დაუშვით მკვდარი კოდი
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// არენის მარტივი გამანაწილებელი ბაიტის ბუფერებისთვის.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// გამოყოფს მითითებული ზომის ბუფერს და უბრუნებს მას მუტაბელურ მითითებას.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // უსაფრთხოება: ეს არის ერთადერთი ფუნქცია, რომელიც ოდესმე ქმნის მუტაბელს
        // მითითება `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // უსაფრთხოება: ჩვენ არასდროს ამოვიღებთ ელემენტებს `self.buffers`- დან, ამიტომ მინიშნება
        // მონაცემთა ნებისმიერი ბუფერული იცხოვრებს, სანამ `self` ცხოვრობს.
        &mut buffers[i]
    }
}