use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// გადაჭერით მისამართი სიმბოლოზე, გადასცეთ სიმბოლო მითითებულ დახურვას.
///
/// ეს ფუნქცია ეძებს მოცემულ მისამართს ისეთ ადგილებში, როგორიცაა ადგილობრივი სიმბოლოების ცხრილი, დინამიური სიმბოლოების ცხრილი ან DWARF გამართვის ინფორმაცია (დამოკიდებულია გააქტიურებულ შესრულებაზე) სიმბოლოების მოსაძებნად.
///
///
/// დახურვის დარეკვა არ შეიძლება, თუ რეზოლუციის შესრულება შეუძლებელია, და ასევე შეიძლება ერთჯერადად გამოიძახოს ხაზგასმული ფუნქციების შემთხვევაში.
///
/// მიღებული სიმბოლოები წარმოადგენს შესრულებას მითითებულ `addr`-ზე, უბრუნებს file/line წყვილებს ამ მისამართისთვის (ასეთის არსებობის შემთხვევაში).
///
/// გაითვალისწინეთ, რომ თუ თქვენ გაქვთ `Frame`, მაშინ გირჩევთ გამოიყენოთ `resolve_frame` ფუნქცია ამ ფუნქციის ნაცვლად.
///
/// # საჭირო მახასიათებლები
///
/// ამ ფუნქციისთვის საჭიროა `backtrace` crate- ის `std` მახასიათებლის ჩართვა, ხოლო `std` ფუნქციის ჩართვა ნაგულისხმევად.
///
/// # Panics
///
/// ეს ფუნქცია ისწრაფვის არასოდეს panic, მაგრამ თუ `cb` უზრუნველყოფს panics, მაშინ ზოგიერთი პლატფორმა აიძულებს ორმაგ panic პროცესის შეწყვეტას.
/// ზოგი პლატფორმა იყენებს C ბიბლიოთეკას, რომელიც შინაგანად იყენებს ზარების უკუგდებას, რომელთა გახსნაც შეუძლებელია, ამიტომ `cb`- დან პანიკამ შეიძლება გამოიწვიოს პროცესის შეწყვეტა.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // მხოლოდ ზედა ჩარჩოს გადახედეთ
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// გადაჭერით ადრე აღბეჭდილი ჩარჩო სიმბოლოზე, გადასცეთ სიმბოლო მითითებულ დახურვას.
///
/// ეს functin ასრულებს იმავე ფუნქციას, როგორც `resolve`, გარდა იმისა, რომ იგი იღებს `Frame`-ს, როგორც არგუმენტი მისამართის ნაცვლად.
/// ამის საშუალებით შესაძლებელია backtracing-ის ზოგიერთი პლატფორმის განხორციელება უზრუნველყოს სიმბოლოების უფრო ზუსტი ინფორმაცია ან ინფორმაცია ჩარჩოების შესახებ მაგალითად.
///
/// გირჩევთ გამოიყენოთ ეს თუ შეგიძლიათ.
///
/// # საჭირო მახასიათებლები
///
/// ამ ფუნქციისთვის საჭიროა `backtrace` crate- ის `std` მახასიათებლის ჩართვა, ხოლო `std` ფუნქციის ჩართვა ნაგულისხმევად.
///
/// # Panics
///
/// ეს ფუნქცია ისწრაფვის არასოდეს panic, მაგრამ თუ `cb` უზრუნველყოფს panics, მაშინ ზოგიერთი პლატფორმა აიძულებს ორმაგ panic პროცესის შეწყვეტას.
/// ზოგი პლატფორმა იყენებს C ბიბლიოთეკას, რომელიც შინაგანად იყენებს ზარების უკუგდებას, რომელთა გახსნაც შეუძლებელია, ამიტომ `cb`- დან პანიკამ შეიძლება გამოიწვიოს პროცესის შეწყვეტა.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // მხოლოდ ზედა ჩარჩოს გადახედეთ
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// დასტის ჩარჩოებიდან IP მნიშვნელობები, როგორც წესი, (always?) ინსტრუქციაა *ზარის შემდეგ*, რომელიც არის სტეკის კვალი.
// ამის სიმბოლოზაცია იწვევს filename/line რიცხვის წინსვლას და შესაძლოა სიცარიელეს, თუ ის ფუნქციის ბოლოს არის.
//
// როგორც ჩანს, ეს ძირითადად ყოველთვის ხდება ყველა პლატფორმაზე, ასე რომ, ჩვენ ყოველთვის გამოვყოფთ ip- ს, რომ გადავჭრათ წინა ზარის ინსტრუქციაში, ინსტრუქციის დაბრუნების ნაცვლად.
//
//
// იდეალურ შემთხვევაში ჩვენ ამას არ გავაკეთებდით.
// იდეალურ შემთხვევაში, ჩვენ დაგვჭირდება `resolve` API- ების აბონენტებს ხელით გააკეთონ -1 და გაითვალისწინონ, რომ მათ სჭირდებათ მდებარეობის ინფორმაცია *წინა* ინსტრუქციისთვის და არა მიმდინარე.
// იდეალურ შემთხვევაში ჩვენ ასევე გამოვავლენდით `Frame`- ზე, თუ ჩვენ ნამდვილად ვართ შემდეგი ინსტრუქციის მისამართი ან მიმდინარე.
//
// ახლა კი ეს საკმაოდ საშიშია, ამიტომ ჩვენ შინაგანად ყოველთვის გამოვაკლებთ ერთს.
// მომხმარებლებმა უნდა განაგრძონ მუშაობა და მიიღონ საკმაოდ კარგი შედეგები, ამიტომ ჩვენ საკმარისად კარგები უნდა ვიყოთ.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// იგივეა, რაც `resolve`, მხოლოდ სახიფათოა, რადგან არ არის სინქრონიზებული.
///
/// ამ ფუნქციას არ აქვს სინქრონიზაციის გარანტიები, მაგრამ ის ხელმისაწვდომია, როდესაც ამ crate-ის `std` თვისება არ არის შედგენილი.
/// დამატებითი დოკუმენტაციისა და მაგალითებისათვის იხილეთ `resolve` ფუნქცია.
///
/// # Panics
///
/// იხილეთ ინფორმაცია `resolve`- ზე `cb` პანიკაში ჩავარდნაზე.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// იგივეა, რაც `resolve_frame`, მხოლოდ სახიფათოა, რადგან არ არის სინქრონიზებული.
///
/// ამ ფუნქციას არ აქვს სინქრონიზაციის გარანტიები, მაგრამ ის ხელმისაწვდომია, როდესაც ამ crate-ის `std` თვისება არ არის შედგენილი.
/// დამატებითი დოკუმენტაციისა და მაგალითებისათვის იხილეთ `resolve_frame` ფუნქცია.
///
/// # Panics
///
/// იხილეთ ინფორმაცია `resolve_frame`- ზე `cb` პანიკაში ჩავარდნაზე.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait წარმოადგენს სიმბოლოების გარჩევადობას ფაილში.
///
/// ეს trait მოცემულია როგორც trait ობიექტი `backtrace::resolve` ფუნქციის დახურვისთვის, და ის ფაქტობრივად გაიგზავნება, რადგან უცნობია, რომელი განხორციელების უკან დგას.
///
///
/// სიმბოლოს შეუძლია მისცეს კონტექსტური ინფორმაცია ფუნქციის შესახებ, მაგალითად სახელი, ფაილის სახელი, ხაზის ნომერი, ზუსტი მისამართი და ა.შ.
/// ყველა ინფორმაცია ყოველთვის არ არის ხელმისაწვდომი სიმბოლოთი, ამიტომ ყველა მეთოდი უბრუნებს `Option`-ს.
///
///
pub struct Symbol {
    // TODO: ეს სიცოცხლის ხანგრძლივობა საბოლოოდ უნდა გაგრძელდეს `Symbol`- მდე,
    // მაგრამ ეს არის მომენტალური ცვლილება.
    // ახლა ეს უსაფრთხოა, რადგან `Symbol` მხოლოდ მითითებით არის გადაცემული და მისი კლონირება შეუძლებელია.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// აბრუნებს ამ ფუნქციის სახელს.
    ///
    /// დაბრუნებული სტრუქტურა შეიძლება გამოყენებულ იქნას სიმბოლოს სახელის შესახებ სხვადასხვა თვისებების დასაკითხად:
    ///
    ///
    /// * `Display` დანერგვა დაბეჭდავს დაშლილ სიმბოლოს.
    /// * სიმბოლოს ნედლეული `str` მნიშვნელობაზე წვდომა შეიძლება (თუ ის მართებულია utf-8).
    /// * ნებადართულია ნედლეული ბაიტი სიმბოლოს სახელისთვის.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// აბრუნებს ამ ფუნქციის საწყისი მისამართს.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// უბრუნებს დაუმუშავებელ ფაილის სახელს ნაჭრებად.
    /// ეს ძირითადად სასარგებლოა `no_std` გარემოში.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// აბრუნებს სვეტის ნომერს, სადაც ეს სიმბოლო ამჟამად ახორციელებს.
    ///
    /// მხოლოდ gimli ამჟამად უზრუნველყოფს მნიშვნელობას აქ და მაშინაც მხოლოდ მაშინ, თუ `filename` დააბრუნებს `Some`, და შესაბამისად, იგი ექვემდებარება მსგავს სიფრთხილით.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// აბრუნებს სტრიქონის ნომერს, სადაც ამჟამად ახორციელებს ეს სიმბოლო.
    ///
    /// ეს საპასუხო მნიშვნელობა, როგორც წესი, `Some` ა, თუ `filename` დააბრუნებს `Some` და, შესაბამისად, ექვემდებარება მსგავსი სიფრთხილით.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// აბრუნებს ფაილის სახელს, სადაც ეს ფუნქცია განისაზღვრა.
    ///
    /// ამჟამად ეს ხელმისაწვდომია მხოლოდ მაშინ, როდესაც libbacktrace ან gimli გამოიყენება (მაგ
    /// unix პლატფორმების სხვა) და როდესაც ორობითი შედგება debuginfo-სთან.
    /// თუ არცერთი პირობა არ არის შესრულებული, ეს სავარაუდოდ დააბრუნებს `None`.
    ///
    /// # საჭირო მახასიათებლები
    ///
    /// ამ ფუნქციისთვის საჭიროა `backtrace` crate- ის `std` მახასიათებლის ჩართვა, ხოლო `std` ფუნქციის ჩართვა ნაგულისხმევად.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // შესაძლოა გაანალიზებული C++ სიმბოლო, თუ მანჯირებული სიმბოლოს ანალიზი ვერ მოხერხდა, რადგან Rust ვერ მოხერხდა.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // დარწმუნდით, რომ შეინახეთ ეს ნულოვანი ზომა, ისე რომ `cpp_demangle` მახასიათებელს არ ექნება ფასი გათიშვისას.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// შესაფუთი სიმბოლოს სახელის ირგვლივ, რათა უზრუნველყოს ერგონომიული აქსესუარები დაშლილი სახელის, ნედლეული ბაიტის, ნედლი სტრიქონის და ა.შ.
///
// დაუშვით მკვდარი კოდი, როდესაც `cpp_demangle` ფუნქცია არ არის ჩართული.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// ქმნის ახალ სიმბოლოთა სახელს ნედლეული ბაიტებისგან.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// აბრუნებს ნედლეულს (mangled) სიმბოლოს სახელს, როგორც `str`, თუ სიმბოლო მოქმედებს utf-8.
    ///
    /// გამოიყენეთ `Display` დანერგვა, თუ გსურთ დემონტაჟული ვერსია.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// აბრუნებს ნედლეულის სიმბოლოს სახელს, როგორც ბაიტების სია
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // ეს შეიძლება დაიბეჭდოს, თუ დაშლილი სიმბოლო სინამდვილეში არასწორია, ასე რომ, გაუმკლავდეთ შეცდომას აქ მოხდენილად და არ გაავრცელოთ იგი გარედან.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// ქეშირებული მეხსიერების აღდგენის მცდელობა, რომელიც მისამართების სიმბოლოს ხმარობდა.
///
/// ეს მეთოდი შეეცდება გამოაქვეყნოს მონაცემთა გლობალური სტრუქტურები, რომლებიც სხვაგვარად იქნა შეფარებული გლობალურად ან ძაფში, რომლებიც, როგორც წესი, წარმოადგენს DWARF-ის გაანალიზებულ ინფორმაციას ან მის მსგავსს.
///
///
/// # Caveats
///
/// მიუხედავად იმისა, რომ ეს ფუნქცია ყოველთვის არის ხელმისაწვდომი, ის რეალურად არაფერს აკეთებს უმეტეს პროგრამებში.
/// ისეთი ბიბლიოთეკები, როგორიცაა dbghelp ან libbacktrace, არ იძლევა გამოყოფილი მეხსიერების გადასაადგილებლად და მართვისთვის საჭირო საშუალებებს.
/// ამ დროისთვის ამ crate- ის `gimli-symbolize` თვისება ერთადერთი მახასიათებელია, სადაც ამ ფუნქციას რაიმე ეფექტი აქვს.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}