use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr იღებს ზარს, რომელიც მიიღებს dl_phdr_info მაჩვენებელს ყველა DSO- სთვის, რომელიც დაკავშირებულია პროცესში.
    // dl_iterate_phdr ასევე უზრუნველყოფს დინამიური დამაკავშირებლის დაბლოკვას განმეორების თავიდან ბოლომდე.
    // თუ უკუკავშირი დაუბრუნებს არა ნულოვან მნიშვნელობას, გამეორება წყდება ადრე.
    // 'data' გადაეცემა მესამე არგუმენტად ზარს თითოეულ ზარზე.
    // 'size' იძლევა dl_phdr_info-ს ზომას.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// ჩვენ უნდა გავაანალიზოთ მშენებლობის ID და ზოგიერთი ძირითადი პროგრამის სათაურის მონაცემები, რაც ნიშნავს, რომ ჩვენ გვჭირდება ცოტაოდენი მასალა ELF სპეციფიკიდან.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// ახლა ჩვენ უნდა გავიმეოროთ, bit for bit, სტრუქტურა dl_phdr_info ტიპის, რომელსაც იყენებს ფუქსიას ამჟამინდელი დინამიური დამაკავშირებელი.
// Chromium- ს ასევე აქვს ABI- ის ეს საზღვარი, ისევე როგორც crashpad.
// საბოლოოდ, ჩვენ გვსურს ამ შემთხვევების გადატანა elf-search- ის გამოყენებით, მაგრამ ამის გათვალისწინება გვჭირდება SDK- ში და ეს ჯერ არ გაკეთებულა.
//
// ამრიგად, ჩვენ (და ისინი) დავრჩებით, რომ უნდა გამოვიყენოთ ეს მეთოდი, რომელიც მჭიდრო კავშირშია fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // ჩვენ არ გვაქვს იმის ცოდნა, რომ გადავამოწმოთ, მართებულია თუ არა e_phoff და e_phnum.
    // libc-მა ეს უნდა უზრუნველყოს ჩვენთვის, თუმცა აქ ნაჭრის შექმნა უსაფრთხოა.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr წარმოადგენს 64-ბიტიან ELF პროგრამულ სათაურს სამიზნე არქიტექტურის ბოლოში.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr წარმოადგენს ELF პროგრამის მოქმედ სათაურს და მის შინაარსს.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // ჩვენ არ გვაქვს გზა, რომ გადავამოწმოთ, p_addr ან p_memsz მართებულია.
    // Fuchsia's libc პირველ რიგში აანალიზებს შენიშვნებს, თუმცა აქ ყოფნის წყალობით ეს სათაურები უნდა იყოს მართებული.
    //
    // NoteIter არ საჭიროებს ძირითადი მონაცემების ვალიდობას, მაგრამ ეს მოითხოვს საზღვრების ვალიდობას.
    // ჩვენ ვენდობით, რომ libc-მა უზრუნველყო, რომ ეს აქ ჩვენთვის ასეა.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// ჩანიშვნის ტიპი ასაშენებელი ID- ებისთვის.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr წარმოადგენს ELF ნოტის სათაურს სამიზნის ბოლოში.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// შენიშვნა წარმოადგენს ELF ნოტს (სათაური + შინაარსი).
// სახელი დარჩა როგორც u8 ნაჭერი, რადგან ის ყოველთვის არ არის დასრულებული და rust საშუალებას იძლევა საკმარისად მარტივად შეამოწმოთ თუ არა ბაიტი მაინც.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter საშუალებას გაძლევთ უსაფრთხოდ გაიმეოროთ ჩანიშვნის სეგმენტი.
// იგი წყდება შეცდომის დადგომისთანავე ან აღარ არის შენიშვნები.
// თუ არასწორი მონაცემებით გაიმეორებთ, ის იმუშავებს, თითქოს ჩანიშვნები ვერ მოიძებნა.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // ფუნქციის უცვლელია, რომ მაჩვენებელი და მოცემული ზომა ნიშნავს ბაიტის მართებულ დიაპაზონს, რომლის წაკითხვაც შესაძლებელია.
    // ამ ბაიტების შინაარსი შეიძლება იყოს ნებისმიერი, მაგრამ დიაპაზონი უნდა იყოს მართებული, რომ ეს უსაფრთხო იყოს.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to გასწორება 'x' to 'to' byte გასწორება ვთქვათ 'to' არის ძალა 2.
// ეს მიჰყვება C/C ++ ELF ანალიზის კოდის სტანდარტულ ნიმუშს, სადაც (x + დან, 1) და -to გამოიყენება.
// Rust არ მოგცემთ უარის თქმის გამოყენებას, ასე რომ მე გამოვიყენო
// 2-ის კომპლემენტის გარდაქმნა იმის შესაქმნელად.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 მოიხმარს ნაკვეთიდან ბაიტებს (ასეთის არსებობის შემთხვევაში) და დამატებით უზრუნველყოფს საბოლოო ნაჭრის სწორად გასწორებას.
// თუ ან მოთხოვნილი ბაიტების რაოდენობა ძალიან დიდია, ან ნაჭრის ხელახლა შეცვლა შეუძლებელია, რადგან ბაიტი არ არის დარჩენილი, არცერთი არ უბრუნდება და ნაკვეთი არ შეცვლილა.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// ამ ფუნქციას რეალური ინვარიანტები არ აქვს, რომლებმაც უნდა დაიცვან აბონენტი, გარდა იმისა, რომ 'bytes' უნდა იყოს გასწორებული შესრულებისთვის (და ზოგიერთი არქიტექტურის სისწორეზე).
// Elf_Nhdr ველების მნიშვნელობები შეიძლება სისულელეა, მაგრამ ეს ფუნქცია არ იძლევა ასეთ რამეს.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // ეს უსაფრთხოა, სანამ საკმარისი ადგილი იქნება და ჩვენ უბრალოდ დაადასტურეთ, რომ ზემოთ მოცემულ განცხადებაში ასე რომ, ეს არ უნდა იყოს სახიფათო.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // გაითვალისწინეთ, რომ sice_of: :<Elf_Nhdr>() ყოველთვის 4 ბაიტიანი გასწორებულია.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // შეამოწმეთ, მივაღწიეთ თუ არა ბოლომდე.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // ჩვენ გადავდოთ nhdr, მაგრამ ყურადღებით განვიხილავთ მიღებულ სტრუქტურას.
        // ჩვენ არ ვენდობით namesz-ს ან descsz-ს და არ ვღებულობთ სახიფათო გადაწყვეტილებებს ტიპის მიხედვით.
        //
        // მაშინაც კი, თუკი ნაგავს ამოვიღებთ, უსაფრთხოდ უნდა ვიყოთ.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// მიუთითებს, რომ სეგმენტი არის შესრულებადი.
const PERM_X: u32 = 0b00000001;
/// მიუთითებს სეგმენტის ჩაწერაზე.
const PERM_W: u32 = 0b00000010;
/// მიუთითებს, რომ სეგმენტი იკითხება.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// წარმოადგენს ELF სეგმენტს მუშაობის დროს.
struct Segment {
    /// აძლევს ამ სეგმენტის შინაარსის ვირტუალურ მისამართს.
    addr: usize,
    /// იძლევა ამ სეგმენტის შინაარსის მეხსიერების ზომას.
    size: usize,
    /// აძლევს მოდულის ამ სეგმენტის ვირტუალურ მისამართს ELF ფაილით.
    mod_rel_addr: usize,
    /// აძლევს ნებართვებს, რომლებიც ნაპოვნია ELF ფაილში.
    /// თუმცა, ეს ნებართვები სულაც არ არის დაშვების დროს არსებული უფლებები.
    flags: Perm,
}

/// განმეორდეს ერთი სსგმ-ზე DSO-სგან.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// წარმოადგენს ELF DSO (დინამიური გაზიარებული ობიექტი).
/// ამ ტიპის მითითება ხდება მონაცემთა DSO- ში შენახულ მონაცემებზე, ვიდრე საკუთარი ასლის დამზადებაზე.
struct Dso<'a> {
    /// დინამიური დამაკავშირებელი ყოველთვის გვაძლევს სახელს, მაშინაც კი, თუ სახელი ცარიელია.
    /// მთავარი შემსრულებლის შემთხვევაში ეს სახელი ცარიელი იქნება.
    /// გაზიარებული ობიექტის შემთხვევაში ეს იქნება სონამი (იხ. DT_SONAME).
    name: &'a str,
    /// ფუქსიაზე, პრაქტიკულად, ყველა ორობითი ქსელს აქვს პირადობის დამადასტურებელი მოწმობა, მაგრამ ეს არ არის მკაცრი მოთხოვნა.
    /// ამის შემდეგ არ არსებობს DSO ინფორმაციის ნამდვილ ELF ფაილს შესატყვისი, თუ build_id არ არსებობს, ამიტომ ჩვენ ვთხოვთ, რომ ყველა OSO-ს ჰქონდეს ერთი აქ.
    ///
    /// DSO- ს გარეშე build_id იგნორირებულია.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// აბრუნებს iterator-ს ამ DSO-ს სეგმენტებზე.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// ეს შეცდომები აშიფრავს საკითხებს, რომლებიც წარმოიქმნება თითოეული DSO- ს შესახებ ინფორმაციის ანალიზისას.
///
enum Error {
    /// NameError ნიშნავს, რომ მოხდა შეცდომა C სტილის სიმების rust სიმებად გადაქცევისას.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError ნიშნავს, რომ ჩვენ ვერ ვიპოვნეთ მშენებლობის ID.
    /// ეს შეიძლება იყოს იმის გამო, რომ DSO- ს არ ჰქონდა ID ID ან აშენებული ID- ს შემცველი სეგმენტი არასწორად იყო ჩამოყალიბებული.
    ///
    BuildIDError,
}

/// ზარებს ან 'dso' ან 'error' თითოეულ DSO- სთვის, რომელიც პროცესში ჩართულია დინამიური დამაკავშირებლის საშუალებით.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter, რომელსაც ექნება ერთ - ერთი მეთოდი, რომელსაც ეწოდება foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr უზრუნველყოფს, რომ info.name მიუთითებს სწორ ადგილას.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// ეს ფუნქცია ბეჭდავს Fuchsia-ს სიმბოლიზირების ნიშანს ყველა ინფორმაციისთვის, რომელიც შეიცავს DSO-ს.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}