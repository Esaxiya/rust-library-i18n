# backtrace-rs

[Documentation](https://docs.rs/backtrace)

ბიბლიოთეკა Rust- სთვის უკუქცევის შეძენის დროს.
ეს ბიბლიოთეკა მიზნად ისახავს სტანდარტული ბიბლიოთეკის მხარდაჭერის ამაღლებას, პროგრამულ ინტერფეისთან ერთად მუშაობისთვის, მაგრამ ის ასევე ხელს უწყობს ამჟამინდელი უკუკავშირის ადვილად დაბეჭდვას, როგორიცაა libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

უკუკავშირის უბრალოდ აღსადგენად და მასთან მოგვიანებით გადადებაზე გადადება, შეგიძლიათ გამოიყენოთ უმაღლესი დონის `Backtrace` ტიპი.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

თუ გსურთ, უფრო მეტი წვდომა იქონიოთ მიკვლევის ფაქტობრივ ფუნქციონალზე, შეგიძლიათ პირდაპირ გამოიყენოთ `trace` და `resolve` ფუნქციები.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // ამ ინსტრუქციის მაჩვენებლის ამოხსნა სიმბოლოს სახელზე
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // გააგრძელეთ შემდეგი კადრის გადასვლა
    });
}
```

# License

ეს პროექტი ლიცენზირებულია რომელიმეზე

 * Apache ლიცენზია, ვერსია 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ან http://www.apache.org/licenses/LICENSE-2.0)
 * MIT ლიცენზია ([LICENSE-MIT](LICENSE-MIT) ან http://opensource.org/licenses/MIT)

თქვენს ვარიანტზე.

### Contribution

თუ მკაფიოდ არ თქვით სხვაგვარად, თქვენს მიერ უკანა ტრასაზე ჩასართავად განზრახ შეტანილი ნებისმიერი წვლილი, როგორც ეს განსაზღვრულია Apache-2.0 ლიცენზიაში, ორმაგი ლიცენზირებული იქნება ზემოთ, ყოველგვარი დამატებითი პირობებისა და პირობების გარეშე.







