use backtrace::Backtrace;

// 50 სიმბოლოთი მოდულის სახელი
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50 პერსონაჟის სტრუქტურული სახელი
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// გრძელი ფუნქციების სახელები უნდა შემცირდეს (MAX_SYM_NAME, 1) სიმბოლოზე.
// მხოლოდ ტესტის ჩატარება msvc-ზე, რადგან gnu ბეჭდავს "<no info>" ყველა ჩარჩოსთვის.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // სტრუქტურის სახელის 10 გამეორება, ასე რომ, სრულად კვალიფიციური ფუნქციის სახელი მინიმუმ 10 *(50 + 50)* 2=2000 სიმბოლოა.
    //
    // ეს რეალურად უფრო გრძელია, რადგან ის მოიცავს `::`, `<>` და მიმდინარე მოდულის სახელს
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}