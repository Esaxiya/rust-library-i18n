use backtrace::Backtrace;

// ეს ტესტი მუშაობს მხოლოდ პლატფორმებზე, რომლებსაც აქვთ სამუშაო `symbol_address` ფუნქცია ჩარჩოებისთვის, რომლებიც ასახავს სიმბოლოს საწყისი მისამართს.
// შედეგად, ის მხოლოდ რამდენიმე პლატფორმაზეა ჩართული.
//
const ENABLED: bool = cfg!(all(
    // Windows სინამდვილეში არ არის გამოცდილი და OSX მხარს არ უჭერს თანდართული ჩარჩოს მოძიებას, ასე რომ, გამორთეთ ეს
    //
    target_os = "linux",
    // ARM- ზე თანდართული ფუნქციის მოძებნა უბრალოდ ip-ის დაბრუნებას ნიშნავს.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}