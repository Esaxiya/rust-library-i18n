//! ორმაგი დასრულებული რიგი, რომელიც ხორციელდება გასაზრდევი ბეჭდის ბუფერით.
//!
//! ამ რიგს აქვს *O*(1) ამორტიზებული ჩასმა და ამოღება კონტეინერის ორივე ბოლოდან.
//! მას ასევე აქვს *O*(1) ინდექსაცია, როგორც vector.
//! საჭირო ელემენტების კოპირება არ არის საჭირო და რიგის გაგზავნა შეუძლებელია, თუ მოცემული ტიპი იგზავნება.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // ორის მაქსიმალური სიმძლავრე

/// ორმაგი დასრულებული რიგი, რომელიც ხორციელდება გასაზრდევი ბეჭდის ბუფერით.
///
/// ამ ტიპის "default" რიგში გამოყენებაა რიგში დასამატებლად [`push_back`] და რიგიდან ამოსაღებად [`pop_front`].
///
/// [`extend`] და [`append`] ამ გზით იწევს ზურგზე და `VecDeque`- ზე მეტი გამრავლება მიდის წინ და უკან.
///
/// მას შემდეგ, რაც `VecDeque` არის რგოლის ბუფერი, მისი ელემენტები სულაც არ არის მიმდებარე მეხსიერებაში.
/// თუ გსურთ ელემენტებზე წვდომა როგორც ერთი ნაჭერი, მაგალითად, ეფექტური დახარისხებისთვის, შეგიძლიათ გამოიყენოთ [`make_contiguous`].
/// ის ტრიალებს `VecDeque` ისე, რომ მისი ელემენტები არ იხვევა და მუტაციურ ნაჭერს უბრუნებს ახლა მომიჯნავე ელემენტის თანმიმდევრობას.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // კუდი და თავი მითითებულია ბუფერებში.
    // კუდი ყოველთვის მიუთითებს პირველ ელემენტზე, რომლის წაკითხვაც შესაძლებელია, Head ყოველთვის მიუთითებს, თუ სად უნდა დაიწეროს მონაცემები.
    //
    // თუ tail==head ბუფერი ცარიელია.ზარის ბუფერის სიგრძე განისაზღვრება, როგორც მანძილი ორს შორის.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// მართავს დესტრუქტორს ნაჭრის ყველა ნივთისთვის, როდესაც ის დაეცემა (ჩვეულებრივ ან განტვირთვის დროს).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // გამოიყენეთ წვეთი [T]- სთვის
            ptr::drop_in_place(front);
        }
        // RawVec ამუშავებს დელოკაციას
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// ქმნის ცარიელ `VecDeque<T>`-ს.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// მარგინალურად უფრო მოსახერხებელია
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// მარგინალურად უფრო მოსახერხებელია
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // ნულოვანი ზომის ტიპებისთვის, ჩვენ ყოველთვის მაქსიმალურ მოცულობაში ვართ
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// ჩართეთ ptr ნაჭრებად
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// ჩართეთ ptr მუწუკ ნაჭრებად
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// გადააქვს ელემენტი ბუფერიდან
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// წერს ელემენტს ბუფერში, გადააქვს იგი.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// აბრუნებს `true` თუ ბუფერი სრული სიმძლავრით არის.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// აბრუნებს ინდექსს ფუძემდებლურ ბუფერში მოცემული ლოგიკური ელემენტის ინდექსისთვის.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// აბრუნებს ინდექსს ფუძემდებლურ ბუფერში მოცემული ლოგიკური ელემენტის ინდექსი + დანამატისთვის.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// აბრუნებს ინდექსს ფუძემდებლურ ბუფერში მოცემული ლოგიკური ელემენტის ინდექსისთვის, ქვეგანყოფილება.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// ასლის მეხსიერების მომიჯნავე ბლოკს src-დან dst-მდე
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// ასლის მეხსიერების მომიჯნავე ბლოკს src-დან dst-მდე
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// ასლის მეხსიერების პოტენციურად შესაფერის ბლოკს, რომელიც გრძელია src- დან dest- მდე.
    /// (abs(dst - src) + len) არ უნდა აღემატებოდეს cap()-ს (src- სა და დანიშნულებას შორის უნდა არსებობდეს მაქსიმუმ ერთი უწყვეტი გადაფარვის რეგიონი).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src არ იხვევს, dst არ იხვევს
                //
                //        ს..
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst სანამ src, src არ იხვევა, dst იხვევს
                //
                //
                //    ს..
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. დ.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src dst-მდე, src არ იხვევს, dst იხვევს
                //
                //
                //              ს..
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. დ.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst სანამ src, src იხვევს, dst არ იხვევა
                //
                //
                //    .. ს.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] დ...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src dst-მდე, src იხვევს, dst არ იხვევა
                //
                //
                //    .. ს.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] დ...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst სანამ src, src იხვევს, dst იხვევს
                //
                //
                //    ... ს.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. დ..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src dst-მდე, src იხვევს, dst იხვევს
                //
                //
                //    .. ს..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... დ.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// ირყევა თავისა და კუდის მონაკვეთებზე, რათა გაუმკლავდეს იმ ფაქტს, რომ ჩვენ ახლახან გადაანაწილეთ.
    /// უსაფრთხო არაა, რადგან ის ენდობა ძველ შესაძლებლობებს.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // ბეჭდის ბუფერის TH უმოკლესი მომიჯნავე მონაკვეთის გადატანა
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...აუუუუუ.....
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // არა
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// ქმნის ცარიელ `VecDeque`-ს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// ქმნის ცარიელ `VecDeque` ადგილს მინიმუმ `capacity` ელემენტისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 რადგან ringbuffer ყოველთვის ტოვებს ერთ ადგილს ცარიელი
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// მოცემულია მოცემულ ინდექსში მითითებული ელემენტის მითითება.
    ///
    /// ინდექსში 0 ელემენტი რიგის წინა მხარეა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// მოცემულია მოცემულ ინდექსში არსებული ელემენტის ცვალებადი მითითება.
    ///
    /// ინდექსში 0 ელემენტი რიგის წინა მხარეა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// ცვლის ელემენტებს `i` და `j` ინდექსებზე.
    ///
    /// `i` და `j` შეიძლება იყოს ტოლი.
    ///
    /// ინდექსში 0 ელემენტი რიგის წინა მხარეა.
    ///
    /// # Panics
    ///
    /// Panics თუ რომელიმე ინდექსი არ არის საზღვრებში.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// აბრუნებს ელემენტების რაოდენობას, რომელსაც `VecDeque` იტევს გადანაწილების გარეშე.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// იტოვებს მინიმალურ შესაძლებლობებს ზუსტად `additional` მეტი ელემენტისთვის, რომლებიც ჩასასმელად მოცემულ `VecDeque`-შია.
    /// არაფერს აკეთებს, თუ ტევადობა უკვე საკმარისია.
    ///
    /// გაითვალისწინეთ, რომ გამანაწილებელმა შეიძლება კოლექციას დაუთმოს მეტი ადგილი, ვიდრე ის ითხოვს.
    /// ამიტომ არ შეიძლება დაეყრდნოთ სიმძლავრე, რომ იყოს მინიმალური.
    /// სასურველია [`reserve`], თუ მოსალოდნელია future ჩასმა.
    ///
    /// # Panics
    ///
    /// Panics თუ ახალი სიმძლავრე გადავსებულია `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// იტოვებს ტევადობას მინიმუმ `additional` მეტი ელემენტის ჩასასმელად მოცემულ `VecDeque`-ში.
    /// კოლექციამ შეიძლება მეტი ადგილი დაზოგოს, რათა თავიდან იქნას აცილებული ხშირი გადანაწილება.
    ///
    /// # Panics
    ///
    /// Panics თუ ახალი სიმძლავრე გადავსებულია `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// ცდილობს დაზოგოს მინიმალური სიმძლავრე ზუსტად `additional` მეტი ელემენტისთვის, რომელიც ჩასასმელად მოცემულ `VecDeque<T>`-შია.
    ///
    /// `try_reserve_exact` დარეკვის შემდეგ, ტევადობა იქნება `self.len() + additional`- ზე მეტი ან ტოლი.
    /// არაფერს აკეთებს, თუ ტევადობა უკვე საკმარისია.
    ///
    /// გაითვალისწინეთ, რომ გამანაწილებელმა შეიძლება კოლექციას დაუთმოს მეტი ადგილი, ვიდრე ის ითხოვს.
    /// აქედან გამომდინარე, არ შეიძლება დაეყრდნონ სიმძლავრე, რომ იყოს მინიმალური.
    /// სასურველია `reserve`, თუ მოსალოდნელია future ჩასმა.
    ///
    /// # Errors
    ///
    /// თუ სიმძლავრე გადავსებულია `usize`-ით, ან გამანაწილებელი აცხადებს გაუმართაობის შესახებ, შეცდომა უბრუნდება.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // წინასწარ დაიცავით მეხსიერება, გამოდით თუ არ შეგვიძლია
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // ახლა ჩვენ ვიცით, რომ ეს არ შეიძლება OOM(Out-Of-Memory) ჩვენს რთულ საქმიანობაში
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ძალიან რთული
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// ცდილობს შეინარჩუნოს ტევადობა მინიმუმ `additional` მეტი ელემენტის ჩასასმელად მოცემულ `VecDeque<T>`-ში.
    /// კოლექციამ შეიძლება მეტი ადგილი დაზოგოს, რათა თავიდან იქნას აცილებული ხშირი გადანაწილება.
    /// `try_reserve` დარეკვის შემდეგ, ტევადობა იქნება `self.len() + additional`- ზე მეტი ან ტოლი.
    /// არაფერს აკეთებს, თუ ტევადობა უკვე საკმარისია.
    ///
    /// # Errors
    ///
    /// თუ სიმძლავრე გადავსებულია `usize`-ით, ან გამანაწილებელი აცხადებს გაუმართაობის შესახებ, შეცდომა უბრუნდება.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // წინასწარ დაიცავით მეხსიერება, გამოდით თუ არ შეგვიძლია
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ახლა ჩვენ ვიცით, რომ ეს OOM არ შეიძლება ჩვენს რთულ სამუშაოებში
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ძალიან რთული
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// მაქსიმალურად ამცირებს `VecDeque`- ის მოცულობას.
    ///
    /// ის ჩამოიწევს რაც შეიძლება ახლოს უნდა იყოს სიგრძეზე, მაგრამ გამყოფმა შეიძლება მაინც აცნობოს `VecDeque`-ს, რომ კიდევ რამდენიმე ელემენტისთვის არის ადგილი.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// ამცირებს `VecDeque`- ის მოცულობას ქვედა ზღვრით.
    ///
    /// სიმძლავრე დარჩება მინიმუმ ისეთივე გრძელი, როგორც სიგრძე და მოწოდებული მნიშვნელობა.
    ///
    ///
    /// თუ ამჟამინდელი სიმძლავრე ქვედა ზღვარზე ნაკლებია, ეს არის op-no op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // ჩვენ არ უნდა ვიდარდოთ გადახურვაზე, რადგან არც `self.len()` და არც `self.capacity()` ვერასოდეს იქნება `usize::MAX`.
        // +1 რადგან ringbuffer ყოველთვის ცარიელს ტოვებს ერთ ადგილს.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // საინტერესოა სამი შემთხვევა:
            //   ყველა ელემენტი არ არის სასურველი საზღვრებიდან ელემენტები მომიჯნავეა და თავი არ არის სასურველი საზღვრები ელემენტები არ არის ურთიერთმიმართებული და კუდი არ არის სასურველი საზღვრებიდან
            //
            //
            // ნებისმიერ სხვა დროს, ელემენტის პოზიციები არ მოქმედებს.
            //
            // მიუთითებს, რომ სათავეში ელემენტები უნდა გადაადგილდეს.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // ელემენტების გადატანა სასურველი საზღვრებიდან (პოზიციები target_cap-ის შემდეგ)
            if self.tail >= target_cap && head_outside {
                // თ
                //   [. . . . . . . . o o o o o o o . ]
                //    თ
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // თ
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// ამცირებს `VecDeque`-ს, ინახავს პირველ `len` ელემენტებს და ატოვებს დანარჩენს.
    ///
    ///
    /// თუ `len` უფრო მეტია, ვიდრე `VecDeque`-ის ამჟამინდელი სიგრძე, ამას არანაირი ეფექტი არ აქვს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// მართავს დესტრუქტორს ნაჭრის ყველა ნივთისთვის, როდესაც ის დაეცემა (ჩვეულებრივ ან განტვირთვის დროს).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // უსაფრთხო, რადგან:
        //
        // * `drop_in_place`- ზე გადაცემული ნებისმიერი ნაჭერი მართებულია;მეორე შემთხვევაში აქვს `len <= front.len()` და `len > self.len()`-ზე დაბრუნება უზრუნველყოფს `begin <= back.len()` პირველ შემთხვევაში
        //
        // * VecDeque-ის ხელმძღვანელი გადაადგილდება `drop_in_place`-ზე დარეკვამდე, ასე რომ მნიშვნელობა არ ხდება ორჯერ, თუ `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // დარწმუნდით, რომ მეორე ნახევარი დაეცა მაშინაც კი, როდესაც დესტრუქტორი პირველ panics- შია.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// აბრუნებს წინა - უკანა იტერატორს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// აბრუნებს წინა - უკანა იტერატორს, რომელიც აბრუნებს ცვალებად ცნობებს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // უსაფრთხოება: შიდა `IterMut` უსაფრთხოების ინვარიანტი დადგენილია, რადგან
        // `ring` ჩვენ ვქმნით მოხსენიებულ ნაჭერს მთელი ცხოვრების განმავლობაში '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// აბრუნებს რამდენიმე ნაჭერს, რომლებიც, წესრიგში, შეიცავს `VecDeque`-ის შინაარსს.
    ///
    /// თუ [`make_contiguous`] ადრე იყო გამოძახებული, `VecDeque` ყველა ელემენტი იქნება პირველ ნაჭერში და მეორე ნაჭერი ცარიელი იქნება.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// აბრუნებს რამდენიმე ნაჭერს, რომლებიც, წესრიგში, შეიცავს `VecDeque`-ის შინაარსს.
    ///
    /// თუ [`make_contiguous`] ადრე იყო გამოძახებული, `VecDeque` ყველა ელემენტი იქნება პირველ ნაჭერში და მეორე ნაჭერი ცარიელი იქნება.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// აბრუნებს ელემენტების რაოდენობას `VecDeque`-ში.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// აბრუნებს `true`-ს, თუ `VecDeque` ცარიელია.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// ქმნის იტერატორს, რომელიც მოიცავს მითითებულ დიაპაზონს `VecDeque`-ში.
    ///
    /// # Panics
    ///
    /// Panics თუ საწყისი წერტილი მეტია ბოლოს წერტილზე ან თუ წერტილი დასრულებულია vector სიგრძეზე.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // სრული სპექტრი მოიცავს ყველა შინაარსს
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // &self- ში გაზიარებული ცნობარი შენარჩუნებულია იტერის '_- ში.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// ქმნის იტერატორს, რომელიც მოიცავს `VecDeque`- ის მითითებულ მუტაბელურ დიაპაზონს.
    ///
    /// # Panics
    ///
    /// Panics თუ საწყისი წერტილი მეტია ბოლოს წერტილზე ან თუ წერტილი დასრულებულია vector სიგრძეზე.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // სრული სპექტრი მოიცავს ყველა შინაარსს
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // უსაფრთხოება: შიდა `IterMut` უსაფრთხოების ინვარიანტი დადგენილია, რადგან
        // `ring` ჩვენ ვქმნით მოხსენიებულ ნაჭერს მთელი ცხოვრების განმავლობაში '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// ქმნის სადრენაჟო iterator-ს, რომელიც ხსნის მითითებულ დიაპაზონს `VecDeque`-ში და იძლევა ამოღებულ ნივთებს.
    ///
    /// შენიშვნა 1: ელემენტის დიაპაზონი ამოღებულია მაშინაც კი, თუ გამამრავლებელი არ არის მოხმარებული ბოლომდე.
    ///
    /// შენიშვნა 2: დაზუსტებულია რამდენი ელემენტის ამოღება ხდება დეკიდან, თუ `Drain` მნიშვნელობა არ დაეცემა, მაგრამ მას სესხის ვადა ეწურება (მაგ., `mem::forget` გამო).
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ საწყისი წერტილი მეტია ბოლოს წერტილზე ან თუ წერტილი დასრულებულია vector სიგრძეზე.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // სრული სპექტრი ასუფთავებს ყველა შინაარსს
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // მეხსიერების უსაფრთხოება
        //
        // როდესაც Drain პირველად შეიქმნება, წყაროს წყარო შემცირდება, რათა დარწმუნდეთ, რომ არაინციალიზებული ან გადაადგილებული ელემენტები ხელმისაწვდომი არ არის, თუ Drain გამანადგურებელი არასოდეს იწყებს გაშვებას.
        //
        //
        // Drain გამოაქვს ptr::read ამოღების მნიშვნელობები.
        // დასრულების შემდეგ, დარჩენილი მონაცემები კოპირდება ხვრელის დასაფარავად, ხოლო head/tail მნიშვნელობები სწორად აღდგება.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // დეკის ელემენტები იყოფა სამ სეგმენტად:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // ჩვენ ვინახავთ drain_tail-ს, როგორც self.head, და drain_head-ს და self.head-ს, როგორც after_tail და after_head შესაბამისად Drain-ზე.
        // ეს ასევე ამცირებს ეფექტურ მასივს ისე, რომ თუ Drain გაჟონა, ჩვენ დავივიწყეთ პოტენციურად გადატანილი მნიშვნელობები drain-ის დაწყების შემდეგ.
        //
        //
        //        მე -5 თ
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" drain-ის დაწყების შემდეგ drain-ის დასრულებამდე და Drain დესტრუქტორის გაშვების შემდეგ მნიშვნელობების შესახებ.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // მნიშვნელოვანია, რომ ჩვენ მხოლოდ `self`- ისგან ვქმნით გაზიარებულ ცნობებს და ვკითხულობთ მისგან.
                // ჩვენ არ ვწერთ `self`-ს და არც მივმართავთ ცვალებად მითითებას.
                // აქედან გამომდინარე, `deque`- ისთვის ჩვენ მიერ ზემოთ შექმნილი ნედლეული მაჩვენებელი ძალაში რჩება.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// ასუფთავებს `VecDeque` და ხსნის ყველა მნიშვნელობას.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// აბრუნებს `true`-ს, თუ `VecDeque` შეიცავს მოცემული მნიშვნელობის ტოლ ელემენტს.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// გთავაზობთ მითითებას წინა ელემენტზე, ან `None`-ზე, თუ `VecDeque` ცარიელია.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// უზრუნველყოფს ცვალებად მითითებას წინა ელემენტზე, ან `None`-ზე, თუ `VecDeque` ცარიელია.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// უზრუნველყოფს მითითებას უკანა ელემენტზე, ან `None`-ზე, თუ `VecDeque` ცარიელია.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// უზრუნველყოფს ცვალებად მითითებას უკანა ელემენტზე, ან `None`-ზე, თუ `VecDeque` ცარიელია.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// ხსნის პირველ ელემენტს და უბრუნებს მას, ან `None` თუ `VecDeque` ცარიელია.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque`- დან შლის ბოლო ელემენტს და უბრუნებს მას, ან `None` თუ ის ცარიელია.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// XIX ელემენტს ანაზღაურებს ელემენტს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque` უკანა მხარეს ემატება ელემენტს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: უნდა ჩავთვალოთ თუ არა `head == 0` მნიშვნელობა
        // რომ `self` მომიჯნავეა?
        self.tail <= self.head
    }

    /// ხსნის ელემენტს `VecDeque` ნებისმიერი ადგილიდან და უბრუნებს მას, ანაცვლებს მას პირველ ელემენტს.
    ///
    ///
    /// ეს არ ინარჩუნებს შეკვეთას, მაგრამ არის *O*(1).
    ///
    /// აბრუნებს `None`-ს, თუ `index` არ არის საზღვრებში.
    ///
    /// ინდექსში 0 ელემენტი რიგის წინა მხარეა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// ხსნის ელემენტს `VecDeque` ნებისმიერი ადგილიდან და უბრუნებს მას, ანაცვლებს მას ბოლო ელემენტს.
    ///
    ///
    /// ეს არ ინარჩუნებს შეკვეთას, მაგრამ არის *O*(1).
    ///
    /// აბრუნებს `None`-ს, თუ `index` არ არის საზღვრებში.
    ///
    /// ინდექსში 0 ელემენტი რიგის წინა მხარეა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// ჩასვამს `index` ელემენტს `VecDeque`-ის შიგნით, გადააქვს ყველა ელემენტი `index`-ზე მეტი ან ტოლი მაჩვენებლებით უკანა მხარეს.
    ///
    ///
    /// ინდექსში 0 ელემენტი რიგის წინა მხარეა.
    ///
    /// # Panics
    ///
    /// Panics თუ `index` აღემატება "VecDeque"-ის სიგრძეს
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // გადააადგილეთ ელემენტების მინიმალური რაოდენობა ბეჭდის ბუფერში და ჩადეთ მოცემული ობიექტი
        //
        // მაქსიმუმ len/2, 1 ელემენტი გადავა. O(min(n, n-i))
        //
        // არსებობს სამი ძირითადი შემთხვევა:
        //  ელემენტები მომიჯნავეა
        //      - განსაკუთრებული შემთხვევა, როდესაც კუდი არის 0 ელემენტები ურთიერთგამომრიცხავია და ჩანართი კუდის განყოფილებაშია ელემენტები დისკონტიგურია და ჩანართი არის თავის განყოფილებაში
        //
        //
        // თითოეული მათგანისთვის კიდევ ორი შემთხვევა არსებობს:
        //  ჩასმა უფრო ახლოს არის კუდთან ჩასმა უფრო ახლოს არის თავში
        //
        // გასაღები: H, self.head
        //      T, self.tail o, მოქმედი ელემენტი I, ჩასმის ელემენტი A, ელემენტი, რომელიც უნდა იყოს ჩასმის M წერტილის შემდეგ, მიუთითებს ელემენტის გადატანა
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [აუუუუუ.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // მომიჯნავე, ჩასვით კუდთან ახლოს:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           თ
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // მომიჯნავე, ჩასმა კუდთან და კუდთან არის 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       მმ

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // კუდი უკვე გადავიტანეთ, ამიტომ ჩვენ მხოლოდ `index - 1` ელემენტებს ვაკოპირებთ.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // მომიჯნავე, ჩასვით უფრო ახლოს:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             თ
                    //      [. . . o o o o I A o o . . . . .]
                    //                       მმმ

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, ჩადეთ უფრო ახლოს კუდი, კუდი განყოფილება:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, ჩადეთ უფრო ახლოს ხელმძღვანელი, კუდი განყოფილება:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       მმმმ

                    // დააკოპირეთ ელემენტები ახალ თავამდე
                    self.copy(1, 0, self.head);

                    // ბოლო ელემენტის კოპირება ბუფერის ბოლოში ცარიელ ადგილზე
                    self.copy(0, self.cap() - 1, 1);

                    // გადაადგილეთ ელემენტები idx- დან დასრულებისკენ, ^ ელემენტის ჩათვლით
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, ჩანართი უფრო ახლოს არის კუდთან, თავის განყოფილებასთან და არის ნულოვანი ინდექსი შიდა ბუფერში:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               მმმ

                    // დააკოპირეთ ელემენტები ახალ კუდამდე
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // ბოლო ელემენტის კოპირება ბუფერის ბოლოში ცარიელ ადგილზე
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, ჩადეთ უფრო ახლოს კუდი, თავი განყოფილება:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       მმმმმმმ

                    // დააკოპირეთ ელემენტები ახალ კუდამდე
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // ბოლო ელემენტის კოპირება ბუფერის ბოლოში ცარიელ ადგილზე
                    self.copy(self.cap() - 1, 0, 1);

                    // გადაადგილეთ ელემენტები idx-1- დან დასრულებისკენ, ^ ელემენტის ჩათვლით
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, ჩადეთ უფრო ახლოს ხელმძღვანელი, ხელმძღვანელი განყოფილება:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 მმმ

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // შესაძლოა კუდი შეიცვალა, ამიტომ საჭიროა გადაანგარიშება
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// ხსნის და უბრუნებს ელემენტს `index` `VecDeque`- დან.
    /// რომელი დასასრული უფრო ახლოს არის ამოღების წერტილთან, ის გადაადგილდება ოთახის გასათავისუფლებლად და დაზარალებული ყველა ელემენტი გადავა ახალ პოზიციებზე.
    ///
    /// აბრუნებს `None`-ს, თუ `index` არ არის საზღვრებში.
    ///
    /// ინდექსში 0 ელემენტი რიგის წინა მხარეა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // არსებობს სამი ძირითადი შემთხვევა:
        //  ელემენტები მომიჯნავეა ელემენტები დისკომფორტულია და მოცილება ხდება კუდის განყოფილებაში. ელემენტები არ არის ურთიერთმიმართებული, ხოლო მოცილება ხდება სათავე განყოფილებაში
        //
        //      - განსაკუთრებული შემთხვევა, როდესაც ელემენტები ტექნიკურად მომიჯნავეა, მაგრამ self.head =0
        //
        // თითოეული მათგანისთვის კიდევ ორი შემთხვევა არსებობს:
        //  ჩასმა უფრო ახლოს არის კუდთან ჩასმა უფრო ახლოს არის თავში
        //
        // გასაღები: H, self.head
        //      T, self.tail o, სწორი ელემენტი x, ელემენტი აღინიშნება R მოხსნისთვის, მიუთითებს ელემენტს, რომელიც იხსნება M, მიუთითებს ელემენტის გადატანა
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // მომიჯნავე, მოაცილეთ კუდიდან უფრო ახლოს:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               თ
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // მომიჯნავე, ახლოს მოაცილეთ თავი:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             თ
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, ამოიღეთ უფრო ახლოს კუდი, კუდი განყოფილება:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, ამოიღეთ უფრო ახლოს ხელმძღვანელი, ხელმძღვანელი განყოფილება:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, ამოიღონ უფრო ახლოს ხელმძღვანელი, კუდი განყოფილება:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       მმმმ
                    //
                    // ან კვაზი დისკონტიგენტით, ამოიღეთ თავის, კუდის განყოფილების გვერდით:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         თ
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // მიაპყროს ელემენტები კუდის განყოფილებაში
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // ხელს უშლის ნაკადის ჩამოდინებას.
                    if self.head != 0 {
                        // პირველი ელემენტის კოპირება ცარიელ ადგილზე
                        self.copy(self.cap() - 1, 0, 1);

                        // გადაადგილეთ ელემენტები სათავეში უკან
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, ამოიღეთ უფრო ახლოს კუდი, თავი განყოფილება:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       მმმმმ

                    // idx- მდე ელემენტების დახაზვა
                    self.copy(1, 0, idx);

                    // ბოლო ელემენტის გადაწერა ცარიელ ადგილზე
                    self.copy(0, self.cap() - 1, 1);

                    // გადაადგილეთ ელემენტები კუდიდან ბოლომდე, გარდა უკანასკნელისა
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// მოცემული ინდექსით `VecDeque` იყოფა ორად.
    ///
    /// აბრუნებს ახლად გამოყოფილ `VecDeque`-ს.
    /// `self` შეიცავს `[0, at)` ელემენტებს, ხოლო დაბრუნებული `VecDeque` შეიცავს `[at, len)` ელემენტებს.
    ///
    /// გაითვალისწინეთ, რომ `self` მოცულობა არ იცვლება.
    ///
    /// ინდექსში 0 ელემენტი რიგის წინა მხარეა.
    ///
    /// # Panics
    ///
    /// Panics თუ `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` მდგომარეობს პირველ ნახევარში.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // უბრალოდ აიღე მთელი მეორე ნახევარი.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` მეორე ნახევარში მდგომარეობს, საჭიროა განვახილოთ ის ელემენტები, რომლებიც პირველ ნახევარში გამოვტოვეთ.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // გასუფთავება იქ, სადაც ბუფერების ბოლოებია
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other`- ის ყველა ელემენტს გადააქვს `self`- ში, დატოვებს `other` ცარიელს.
    ///
    /// # Panics
    ///
    /// Panics თუ ელემენტთა ახალი რაოდენობა გადაფარავს `usize`-ს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // გულუბრყვილო impl
        self.extend(other.drain(..));
    }

    /// ინარჩუნებს მხოლოდ პრედიკატით განსაზღვრულ ელემენტებს.
    ///
    /// სხვა სიტყვებით რომ ვთქვათ, წაშალეთ ყველა ელემენტი `e` ისე, რომ `f(&e)` ცრუ დაბრუნდეს
    /// ეს მეთოდი მოქმედებს თავის ადგილზე, თითოეული ელემენტის მონახულება ზუსტად ერთხელ ორიგინალური თანმიმდევრობით და ინარჩუნებს შენარჩუნებული ელემენტების რიგს.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// ზუსტი შეკვეთა შეიძლება სასარგებლო იყოს გარე მდგომარეობის დასადგენად, ინდექსის მსგავსად.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // ეს შეიძლება panic ან შეწყდეს
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // გაორმაგეთ ბუფერის ზომა.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` შეცვლის ადგილზე ისე, რომ `len()` ტოლია `new_len`, ან ზურგის ზედმეტი ელემენტების ამოღებით ან `generator` ზარის უკანა მხარეს წარმოქმნილი ელემენტების დამატებით.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// ალაგებს ამ დეკის შიდა შენახვას, ასე რომ, ეს არის ერთი მომიჯნავე ნაჭერი, რომელიც შემდეგ უბრუნდება.
    ///
    /// ეს მეთოდი არ გამოყოფს და არ ცვლის ჩასმული ელემენტების თანმიმდევრობას.რადგან ის აბრუნებს მუტაბელურ ნაჭერს, ის შეიძლება გამოყენებულ იქნას deque- ს დასალაგებლად.
    ///
    /// შიდა მეხსიერების მომიჯნავე შემდეგ, [`as_slices`] და [`as_mut_slices`] მეთოდები დააბრუნებს `VecDeque`-ის მთლიან შინაარსს ერთ ნაჭერში.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// დეკის შინაარსის დალაგება.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // დალაგების დეკი
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // დალაგება საპირისპირო წესრიგში
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// მომიჯნავე ნაჭერზე უცვლელი წვდომის მიღება.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // ახლა შეგვიძლია დარწმუნებული ვიყოთ, რომ `slice` შეიცავს დეკის ყველა ელემენტს, ხოლო `buf`- ზე კვლავ უცვლელი წვდომაა.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // საკმარისია თავისუფალი ადგილი კუდის ერთჯერადად გადასაწერად, ეს ნიშნავს, რომ ჩვენ თავდაპირველად გადავწიეთ თავი უკან, შემდეგ კი კუდი გადავწეროთ სწორ მდგომარეობაში.
            //
            //
            // დან: DEFGH .... ABC
            // ადრესატი: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: ამჟამად არ განვიხილავთ .... ABCDEFGH
            // იყოს მომიჯნავე, რადგან `head` ამ შემთხვევაში იქნება `0`.
            // მართალია, ამის შეცვლა გვინდა, მაგრამ ეს ტრივიალური არ არის, რადგან რამდენიმე ადგილი ველით, რომ `is_contiguous` ნიშნავს, რომ ჩვენ შეგვიძლია უბრალოდ გავჭრათ `buf[tail..head]`.
            //
            //

            // თავისუფალი ადგილი საკმარისია იმისათვის, რომ თავი ერთჯერადად გადაწეროთ, ეს ნიშნავს, რომ ჩვენ ჯერ კუდი გადავაწიეთ წინ, შემდეგ კი თავი გადავწეროთ სწორ მდგომარეობაში.
            //
            //
            // დან: FGH .... ABCDE
            // დან: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // თავისუფალი უფრო მცირეა, ვიდრე თავი და კუდი, ეს ნიშნავს, რომ ჩვენ ნელა უნდა გავატაროთ "swap" კუდი და თავი.
            //
            //
            // დან: EFGHI ... ABCD ან HIJK.ABCDEFG
            // მდე: ABCDEFGHI ... ან ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // ზოგადი პრობლემა ასე გამოიყურება GHIJKLM ... ABCDEF, ნებისმიერი გაცვლამდე ABCDEFM ... GHIJKL, სვოპების 1 პასის შემდეგ ABCDEFGHIJM ... KL, შეცვალეთ მანამ, სანამ მარცხენა edge არ მიაღწევს დროებით მაღაზიას
                //                  - შემდეგ გადატვირთეთ ალგორითმი ახალი (smaller) მაღაზიით. ზოგჯერ დროებითი შენახვა მიიღწევა, როდესაც სწორი edge არის ბუფერულის ბოლოს, ეს ნიშნავს, რომ ჩვენ უფრო სწორად დავალაგეთ ნაკლები გაცვლებით!
                //
                // E.g
                // EF..ABCD ABCDEF .. მხოლოდ ოთხი გაცვლის შემდეგ დავასრულეთ
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// ორმაგად დასრულებული რიგის `mid` ადგილებით ტრიალებს მარცხნივ.
    ///
    /// Equivalently,
    /// - `mid` პუნქტს ატრიალებს პირველ პოზიციაზე.
    /// - აწყობს პირველ `mid` ნივთებს და უბიძგებს მათ ბოლომდე.
    /// - ატრიალებს `len() - mid` ადგილს მარჯვნივ.
    ///
    /// # Panics
    ///
    /// თუ `mid` მეტია `len()`.
    /// გაითვალისწინეთ, რომ `mid == len()` აკეთებს _not_ panic და არის ოპერაციის გარეშე როტაცია.
    ///
    /// # Complexity
    ///
    /// იღებს `*O*(min(mid, len() - mid))` დროს და არ საჭიროებს დამატებით ადგილს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// ორმაგად დასრულებული რიგის `k` ადგილებისკენ მიტრიალებს მარჯვნივ.
    ///
    /// Equivalently,
    /// - ატრიალებს პირველ ნივთს `k` პოზიციაში.
    /// - ათავსებს ბოლო `k` ნივთებს და უბიძგებს მათ წინ.
    /// - ატრიალებს `len() - k` ადგილებს მარცხნივ.
    ///
    /// # Panics
    ///
    /// თუ `k` მეტია `len()`.
    /// გაითვალისწინეთ, რომ `k == len()` აკეთებს _not_ panic და არის ოპერაციის გარეშე როტაცია.
    ///
    /// # Complexity
    ///
    /// იღებს `*O*(min(k, len() - k))` დროს და არ საჭიროებს დამატებით ადგილს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // უსაფრთხოება: შემდეგი ორი მეთოდი მოითხოვს როტაციის რაოდენობას
    // იყოს დეკის სიგრძის ნახევარზე ნაკლები.
    //
    // `wrap_copy` მოითხოვს `min(x, cap() - x) + copy_len <= cap()`- ს, მაგრამ `min`- ზე არასოდეს არის მოცულობის ნახევარზე მეტი, მიუხედავად x- ს, ამიტომ აქ დარეკვა ჟღერს, რადგან ჩვენ ვურეკავთ სიგრძეზე ნახევარზე ნაკლები, რაც არასოდეს აღემატება ტევადობის ნახევარს.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// ორობითი ეძებს დალაგებულ `VecDeque`-ს მოცემულ ელემენტს.
    ///
    /// თუ მნიშვნელობა ნაპოვნია, [`Result::Ok`] უბრუნდება, რომელიც შეიცავს შესატყვისი ელემენტის ინდექსს.
    /// თუ არსებობს მრავალი მატჩი, მაშინ რომელიმე მატჩის დაბრუნება შეიძლება.
    /// თუ მნიშვნელობა ვერ მოიძებნა, [`Result::Err`] უბრუნდება, რომელიც შეიცავს ინდექსს, სადაც შესატყვისი ელემენტის ჩასმა შესაძლებელია დახარისხებული წესრიგის შენარჩუნებისას.
    ///
    ///
    /// # Examples
    ///
    /// ეძებს ოთხი ელემენტის სერიას.
    /// პირველი გვხვდება, ცალსახად განსაზღვრული პოზიციით;მეორე და მესამე არ არის ნაპოვნი;მეოთხე შეიძლება ემთხვეოდეს ნებისმიერ პოზიციას `[1, 4]`-ში.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// თუ გსურთ ჩასვათ დახარისხებული `VecDeque` ერთეული, დალაგების წესრიგის დაცვით:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// ორობითი ეძებს ამ დალაგებულ `VecDeque`-ს შედარების ფუნქციით.
    ///
    /// შედარების ფუნქციამ უნდა შეასრულოს ბრძანება, რომელიც შეესაბამება ძირითადი `VecDeque` დალაგების რიგს, დააბრუნებს შეკვეთის კოდს, რომელიც მიუთითებს არის თუ არა მისი არგუმენტი `Less`, `Equal` ან `Greater` ვიდრე სასურველი სამიზნე.
    ///
    ///
    /// თუ მნიშვნელობა ნაპოვნია, [`Result::Ok`] უბრუნდება, რომელიც შეიცავს შესატყვისი ელემენტის ინდექსს.თუ არსებობს მრავალი მატჩი, მაშინ რომელიმე მატჩის დაბრუნება შეიძლება.
    /// თუ მნიშვნელობა ვერ მოიძებნა, [`Result::Err`] უბრუნდება, რომელიც შეიცავს ინდექსს, სადაც შესატყვისი ელემენტის ჩასმა შესაძლებელია დახარისხებული წესრიგის შენარჩუნებისას.
    ///
    /// # Examples
    ///
    /// ეძებს ოთხი ელემენტის სერიას.პირველი გვხვდება, ცალსახად განსაზღვრული პოზიციით;მეორე და მესამე არ არის ნაპოვნი;მეოთხე შეიძლება ემთხვეოდეს ნებისმიერ პოზიციას `[1, 4]`-ში.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// ორობითი ეძებს ამ დალაგებულ `VecDeque`-ს გასაღების მოპოვების ფუნქციით.
    ///
    /// ჩათვლის რომ `VecDeque` დალაგებულია გასაღების მიხედვით, მაგალითად [`make_contiguous().sort_by_key()`](#method.make_contiguous)- ით იმავე გასაღების მოპოვების ფუნქციის გამოყენებით.
    ///
    ///
    /// თუ მნიშვნელობა ნაპოვნია, [`Result::Ok`] უბრუნდება, რომელიც შეიცავს შესატყვისი ელემენტის ინდექსს.
    /// თუ არსებობს მრავალი მატჩი, მაშინ რომელიმე მატჩის დაბრუნება შეიძლება.
    /// თუ მნიშვნელობა ვერ მოიძებნა, [`Result::Err`] უბრუნდება, რომელიც შეიცავს ინდექსს, სადაც შესატყვისი ელემენტის ჩასმა შესაძლებელია დახარისხებული წესრიგის შენარჩუნებისას.
    ///
    /// # Examples
    ///
    /// ეძებს ოთხი ელემენტის სერიას წყვილების ნაჭერში, რომლებიც დალაგებულია მათი მეორე ელემენტების მიხედვით.
    /// პირველი გვხვდება, ცალსახად განსაზღვრული პოზიციით;მეორე და მესამე არ არის ნაპოვნი;მეოთხე შეიძლება ემთხვეოდეს ნებისმიერ პოზიციას `[1, 4]`-ში.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `VecDeque` ადგილზე ცვლის ისე, რომ `len()` უდრის new_len-ს, ან ზურგის ზედმეტი ელემენტების მოცილებით ან `value` კლონების უკანა მხარეს დამატებით.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// აბრუნებს ინდექსს ფუძემდებლურ ბუფერში მოცემული ლოგიკური ელემენტის ინდექსისთვის.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // ზომა ყოველთვის არის 2-ის ძალა
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// გამოთვალეთ ბუფერში ამოსაკითხად დარჩენილი ელემენტების რაოდენობა
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // ზომა ყოველთვის არის 2-ის ძალა
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // ყოველთვის იყოფა სამ ნაწილად, მაგალითად: თვით: [a b c|d e f] სხვა: [0 1 2 3|4 5] წინა=3, შუა=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // შეუძლებელია Hash::hash_slice-ის გამოყენება as_slices მეთოდით დაბრუნებულ ნაჭრებზე, რადგან მათი სიგრძე შეიძლება განსხვავდებოდეს სხვაგვარად იდენტურ დეკიებში.
        //
        //
        // ჰეშერი უზრუნველყოფს მხოლოდ მისი მეთოდების ეკვივალენტურობას ზუსტად იგივე ზარებისთვის.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// `VecDeque`- ს იყენებს წინა - უკანა იტერატორად და იძლევა ელემენტების მნიშვნელობას.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // ეს ფუნქცია უნდა იყოს მორალური ეკვივალენტი:
        //
        //      საქონლისთვის iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// [`Vec<T>`] გადააქციეთ [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// ეს თავიდან აცილებს გადანაწილებას, როდესაც ეს შესაძლებელია, მაგრამ ამის პირობები მკაცრია და ექვემდებარება შეცვლას, ამიტომ არ უნდა იქნეს გამოყენებული, თუ `Vec<T>` არ მოდის `From<VecDeque<T>>`- დან და არ გადანაწილდება.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // ZST- ებისთვის რეალური გამოყოფა არ არის მოცულობის გამო, მაგრამ `VecDeque` ვერ უმკლავდება იმდენ სიგრძეს, რამდენიც `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // ჩვენ უნდა შეცვალოთ ზომა, თუ ტევადობა არ არის ორი, ძალიან მცირე ან არ აქვს მინიმუმ ერთი თავისუფალი ადგილი.
            // ჩვენ ამას ვაკეთებთ, სანამ ის ჯერ კიდევ `Vec`-შია, ამიტომ ელემენტები დაეცემა panic-ზე.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// [`VecDeque<T>`] გადააქციეთ [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// ამას არასდროს სჭირდება გადანაწილება, მაგრამ საჭიროა *O*(*n*) მონაცემთა გადაადგილება, თუ წრიული ბუფერი განაწილების დასაწყისში არ მოხდა.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // ეს არის *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // ამ მონაცემების გადაწყობა სჭირდება.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}