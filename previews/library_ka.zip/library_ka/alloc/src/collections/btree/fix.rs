use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ინახავს შესაძლოა არასაკმარის კვანძს ძმასთან შერწყმით ან ქურდობით.
    /// თუ წარმატებულია, მაგრამ მშობლიური კვანძის შემცირების ფასად დააბრუნებს ამ შემცირებულ მშობელ კვანძს.
    /// აბრუნებს `Err` თუ კვანძი ცარიელი ფესვია.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ინახება შესაძლოა არასაკმარისი კვანძი და თუ ეს იწვევს მისი მშობლიური კვანძის შემცირებას, რეგულარულად ინახავს მშობელს.
    /// აბრუნებს `true`-ს, თუ ის დაფიქსირდა ხე, `false` თუ არ შეეძლო, რადგან ძირეული კვანძი დაცარიელდა.
    ///
    /// ეს მეთოდი არ ელოდება წინაპრების შემოსვლისთანავე სრულფასოვნებას და panics თუ ცარიელ წინაპარს წააწყდება.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// ხსნის ცარიელ დონეს თავზე, მაგრამ ინახავს ცარიელ ფოთოლს, თუ მთელი ხე ცარიელია.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// ინახება ან შერწყმულია ნებისმიერი ქვედა კვანძი ხის მარჯვენა საზღვარზე.
    /// დანარჩენ კვანძებს, რომლებიც არ არიან ძირეული და არც სწორი edge, უკვე უნდა ჰქონდეს მინიმუმ MIN_LEN ელემენტი.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border` სიმეტრიული კლონი.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// შეინახეთ ნებისმიერი ქვედა კვანძი ხის მარჯვენა საზღვარზე.
    /// დანარჩენი კვანძები, რომლებიც არ არიან ძირეული და არც სწორი edge, უნდა იყვნენ მზად MIN_LEN ელემენტამდე მოპარული.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // შეამოწმეთ, არის თუ არა სრულწლოვანი ბავშვი სრულფასოვანი.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // უნდა ვიპაროთ.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // უფრო დაბლა წადი.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// ინახავს მარცხენა შვილს, თუ ჩავთვლით, რომ სწორი ბავშვი არ არის სრულფასოვანი, და ითვალისწინებს დამატებით ელემენტს, რომელიც საშუალებას მისცემს თავის შვილებს რიგრიგობით შეუერთდეს და არ გახდეს სრულფასოვანი.
    ///
    /// აბრუნებს მარცხენა ბავშვს.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` თავიდან აცილების მიზნით, შეცვალოთ შეცდომა, თუ შერწყმა მოხდება შემდეგ დონეზე.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// ინახავს მემარჯვენე ბავშვს, თუ ჩავთვლით, რომ მარცხენა ბავშვი არ არის სრულფასოვანი, და ითვალისწინებს დამატებით ელემენტს, რომელიც საშუალებას მისცემს თავის შვილებს რიგრიგობით შეუერთდეს და არ გახდეს სრულფასოვანი.
    ///
    /// ბრუნდება იქ, სადაც დასრულდა შესაფერისი ბავშვი.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` თავიდან აცილების მიზნით, შეცვალოთ შეცდომა, თუ შერწყმა მოხდება შემდეგ დონეზე.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}