use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// უერთდება საკვანძო მნიშვნელობის ყველა წყვილს ორი აღმავალი იტერატორის გაერთიანებიდან, ზრდის `length` ცვლადს.ეს უკანასკნელი უმარტივებს აბონენტს, რომ თავიდან იქნას აცილებული გაჟონვა, როდესაც წვეთი დამამუშავებელი პანიკაში ჩავარდება.
    ///
    /// თუ ორივე იტერატორი აწარმოებს ერთსა და იმავე კლავიშს, ეს მეთოდი წყვილს ჩამოაგდებს მარცხენა იტერატორიდან და უერთდება წყვილს მარჯვენა იტერატორისგან.
    ///
    /// თუ გსურთ ხე დასრულდეს მკაცრად აღმავალი შეკვეთით, ისევე როგორც `BTreeMap`, ორივე განმეორებითმა უნდა აწარმოოს გასაღებები მკაცრად აღმავალი თანმიმდევრობით, თითოეული აღემატება ხის ყველა გასაღებს, მათ შორის შესასვლელთან უკვე არსებულ გასაღებებს.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // ჩვენ ვამზადებთ `left` და `right` შერწყმას თანმიმდევრობით სწორხაზოვან დროში.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // ამასობაში, ჩვენ ავაშენებთ ხეს დახარისხებული თანმიმდევრობიდან სწორხაზოვან დროში.
        self.bulk_push(iter, length)
    }

    /// გასაღები-მნიშვნელობის ყველა წყვილს ხის ბოლოსკენ უბიძგებს და ზრდის `length` ცვლადს.
    /// ეს უკანასკნელი უმარტივებს აბონენტს, რომ თავიდან იქნას აცილებული გაჟონვა, როდესაც იტერატორი შეშინდება.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // გაიმეორეთ გასაღების მნიშვნელობის ყველა წყვილი და სწორად დააჭირეთ კვანძებს.
        for (key, value) in iter {
            // შეეცადეთ გასაღები-მნიშვნელობის წყვილი ჩაწეროთ მიმდინარე ფოთლის კვანძში.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // ადგილი აღარ დამრჩა, ადი და იქ დააჭირე.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // ნაპოვნია კვანძი, რომელსაც აქვს დარჩენილი სივრცე, დააჭირეთ აქ.
                                open_node = parent;
                                break;
                            } else {
                                // ისევ ადი.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // ჩვენ ზედა ნაწილში ვართ, ვქმნით ახალ ძირეულ კვანძს და ვწევთ იქ.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // დააჭირეთ კლავიშების მნიშვნელობას და ახალ მარჯვენა ქვეძეს.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // ისევ ჩამოხვიეთ მარჯვნივ ყველაზე მეტად ფოთოლზე.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // გაიმეორეთ სიგრძე ყოველ გამეორებაზე, რომ დარწმუნდეთ, რომ რუკა ჩამოყრის დანართულ ელემენტებს მაშინაც კი, თუ იტერატორი პანიკურად მიიწევს.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// ორი დახარისხებული თანმიმდევრობის ერთში შერწყმის გამეორება
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// თუ ორი ღილაკი ტოლია, ანაზღაურება გასაღების მნიშვნელობის წყვილი სწორი წყაროდან.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}