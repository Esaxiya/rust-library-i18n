use core::intrinsics;
use core::mem;
use core::ptr;

/// ეს ცვლის `v` უნიკალური მითითების მნიშვნელობას შესაბამისი ფუნქციის გამოძახებით.
///
///
/// თუ panic მოხდა `change` დახურვაში, მთელი პროცესი შეწყვეტილია.
#[allow(dead_code)] // შეინახეთ როგორც ილუსტრაცია და future გამოყენება
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// ეს ცვლის `v` უნიკალური მითითების მნიშვნელობას შესაბამისი ფუნქციის გამოძახებით და უბრუნებს შედეგს.
///
///
/// თუ panic მოხდა `change` დახურვაში, მთელი პროცესი შეწყვეტილია.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}