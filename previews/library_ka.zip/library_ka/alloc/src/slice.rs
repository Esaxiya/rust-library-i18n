//! დინამიური ზომის ხედი მომიჯნავე თანმიმდევრობით, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! ნაჭრები არის მეხსიერების ბლოკის ხედი, რომელიც წარმოდგენილია როგორც მაჩვენებელი და სიგრძე.
//!
//! ```
//! // დაჭრა ვეკი
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // მასივის იძულება ნაჭერზე
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! ნაჭრები ან მუტაბელურია, ან საერთო.
//! საერთო ნაჭრის ტიპია `&[T]`, ხოლო მუტაბელური ნაჭრის ტიპია `&mut [T]`, სადაც `T` წარმოადგენს ელემენტის ტიპს.
//! მაგალითად, შეგიძლიათ მეხსიერების ბლოკის მუტაცია მოახდინოთ, რომელზეც მიუთითებს მუტაბელური ნაჭერი:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! აქ მოცემულია რამდენიმე რამ, რაც ამ მოდულს შეიცავს:
//!
//! ## Structs
//!
//! არსებობს რამდენიმე სტრიტი, რომელიც გამოსადეგია ნაჭრებისთვის, მაგალითად, [`Iter`], რომელიც წარმოადგენს გამეორებას ნაჭერზე.
//!
//! ## Trait განხორციელება
//!
//! ნაჭრებისთვის არსებობს ჩვეულებრივი traits-ის რამდენიმე განხორციელება.რამდენიმე მაგალითი მოიცავს:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], ნაჭრებისთვის, რომელთა ელემენტის ტიპია [`Eq`] ან [`Ord`].
//! * [`Hash`] - ნაჭრებისთვის, რომელთა ელემენტის ტიპია [`Hash`].
//!
//! ## Iteration
//!
//! ნაჭრები ახორციელებენ `IntoIterator`-ს.იტერატორი იძლევა მითითებებს ნაჭრის ელემენტებზე.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! მუტაბელური ნაჭერი იძლევა ცვალებად მითითებებს ელემენტებზე:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! ეს იტერატორი იძლევა ცვალებადი მითითებებს ნაჭრის ელემენტებზე, ასე რომ, როდესაც ნაჭრის ელემენტის ტიპია `i32`, იტერატორის ელემენტის ტიპია `&mut i32`.
//!
//!
//! * [`.iter`] და [`.iter_mut`] არის ნაგულისხმევი ინტერატორების დაბრუნების მკაფიო მეთოდები.
//! * განმეორების დაბრუნების შემდგომი მეთოდებია [`.split`], [`.splitn`], [`.chunks`], [`.windows`] და სხვა.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// ამ მოდულის მრავალი გამოყენება გამოიყენება მხოლოდ ტესტის კონფიგურაციაში.
// უფრო სუფთაა მხოლოდ გამოუყენებელი_ იმპორტის გაფრთხილების გამორთვა, ვიდრე მათი გამოსწორება.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// ნაჭრის გაფართოების ძირითადი მეთოდები
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB- ს ტესტირების დროს საჭიროა `vec!` მაკროს განსახორციელებლად, დაწვრილებითი ინფორმაციისთვის იხილეთ ამ ფაილში `hack` მოდული.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB- ს ტესტირების დროს საჭიროა `Vec::clone`- ის დანერგვისთვის, დაწვრილებითი ინფორმაციისთვის იხილეთ ამ ფაილში `hack` მოდული.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` არ არის ხელმისაწვდომი, ეს სამი ფუნქცია სინამდვილეში მეთოდებია `impl [T]`-ში, მაგრამ არა `core::slice::SliceExt`-ში, ჩვენ უნდა მივაწოდოთ ეს ფუნქციები `test_permutations` ტესტისთვის.
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // ამას არ უნდა დავამატოთ inline ატრიბუტი, რადგან იგი ძირითადად გამოიყენება `vec!` მაკროში და იწვევს სრულ უკუგანვითარებას.
    // იხილეთ #71204 დისკუსიის და სრულყოფილი შედეგების მისაღებად.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // ნივთების ინიცირება აღინიშნა ქვემოთ მოცემულ მარყუჟში
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) LLVM- სთვის აუცილებელია საზღვრების ამოწმების მოხსნა და აქვს უკეთესი კოდექსი, ვიდრე zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec გამოიყო და ინიცირებული იქნა მინიმუმ ამ სიგრძისთვის.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // გამოყოფილია ზემოთ `s` ტევადობით და ინიცირება `s.len()` ptr::copy_to_non_overlapping ქვემოთ.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// ახარისხებს ნაჭერს.
    ///
    /// ეს დალაგება სტაბილურია (მაგ., არ შეცვლის თანაბარ ელემენტებს) და *O*(*n*\*log(* n*)) უარეს შემთხვევაში).
    ///
    /// გამოყენების შემთხვევაში, არასტაბილური დახარისხება სასურველია, რადგან ის ჩვეულებრივ უფრო სწრაფია, ვიდრე სტაბილური დალაგება და მას არ გამოყოფს დამხმარე მეხსიერება.
    /// იხილეთ [`sort_unstable`](slice::sort_unstable).
    ///
    /// # მიმდინარე განხორციელება
    ///
    /// ამჟამინდელი ალგორითმი არის ადაპტაციური, განმეორებითი შერწყმა, რომელიც შთაგონებულია [timsort](https://en.wikipedia.org/wiki/Timsort)-ით.
    /// იგი შექმნილია ძალიან სწრაფად იმ შემთხვევებში, როდესაც ნაჭერი თითქმის დალაგებულია, ან შედგება ორი ან მეტი დალაგებული თანმიმდევრობით, რომლებიც ერთმანეთის მიყოლებით არის შერწყმული.
    ///
    ///
    /// ასევე, იგი გამოყოფს დროებით შენახვას `self` ზომის ნახევარზე, მაგრამ მოკლე ნაჭრებისთვის გამოიყენება არაანაწილებადი ჩასმის დალაგების ნაცვლად.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// ალაგებს ნაკვეთს შედარების ფუნქციით.
    ///
    /// ეს დალაგება სტაბილურია (მაგ., არ შეცვლის თანაბარ ელემენტებს) და *O*(*n*\*log(* n*)) უარეს შემთხვევაში).
    ///
    /// შედარების ფუნქციამ უნდა განსაზღვროს ნაჭრის ელემენტების სრული შეკვეთა.თუ შეკვეთა არ არის სრული, ელემენტების თანმიმდევრობა არ არის განსაზღვრული.
    /// შეკვეთა არის ჯამური შეკვეთა, თუ იგი არის (ყველა `a`, `b` და `c`):
    ///
    /// * საერთო და ანტისმეტრიული: `a < b`, `a == b` ან `a > b`- დან ზუსტად ერთია მართალი და
    /// * გარდამავალი, `a < b` და `b < c` გულისხმობს `a < c`-ს.იგივე უნდა ეხებოდეს როგორც `==`, ასევე `>`.
    ///
    /// მაგალითად, მიუხედავად იმისა, რომ [`f64`] არ ახორციელებს [`Ord`]-ს, რადგან `NaN != NaN`, ჩვენ შეგვიძლია გამოვიყენოთ `partial_cmp`, როგორც დალაგების ფუნქცია, როდესაც ვიცით, რომ ნაკვეთი არ შეიცავს `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// გამოყენების შემთხვევაში, არასტაბილური დახარისხება სასურველია, რადგან ის ჩვეულებრივ უფრო სწრაფია, ვიდრე სტაბილური დალაგება და მას არ გამოყოფს დამხმარე მეხსიერება.
    /// იხილეთ [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # მიმდინარე განხორციელება
    ///
    /// ამჟამინდელი ალგორითმი არის ადაპტაციური, განმეორებითი შერწყმა, რომელიც შთაგონებულია [timsort](https://en.wikipedia.org/wiki/Timsort)-ით.
    /// იგი შექმნილია ძალიან სწრაფად იმ შემთხვევებში, როდესაც ნაჭერი თითქმის დალაგებულია, ან შედგება ორი ან მეტი დალაგებული თანმიმდევრობით, რომლებიც ერთმანეთის მიყოლებით არის შერწყმული.
    ///
    /// ასევე, იგი გამოყოფს დროებით შენახვას `self` ზომის ნახევარზე, მაგრამ მოკლე ნაჭრებისთვის გამოიყენება არაანაწილებადი ჩასმის დალაგების ნაცვლად.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // საპირისპირო დახარისხება
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// ალაგებს ნაჭერს ძირითადი მოპოვების ფუნქციით.
    ///
    /// ეს დალაგება სტაბილურია (მაგ., თანაბარ ელემენტებს არ გადალაგებს) და *O*(*m*\* * n *\* log(*n*)) უარეს შემთხვევაში, სადაც ძირითადი ფუნქციაა *O*(*m*).
    ///
    /// ძვირადღირებული ძირითადი ფუნქციებისათვის (მაგ
    /// ფუნქციები, რომლებიც არ არის მარტივი ქონების წვდომა ან ძირითადი ოპერაციები), [`sort_by_cached_key`](slice::sort_by_cached_key) სავარაუდოდ მნიშვნელოვნად უფრო სწრაფი იქნება, რადგან ის არ გადაანგარიშებს ელემენტის გასაღებებს.
    ///
    ///
    /// გამოყენების შემთხვევაში, არასტაბილური დახარისხება სასურველია, რადგან ის ჩვეულებრივ უფრო სწრაფია, ვიდრე სტაბილური დალაგება და მას არ გამოყოფს დამხმარე მეხსიერება.
    /// იხილეთ [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # მიმდინარე განხორციელება
    ///
    /// ამჟამინდელი ალგორითმი არის ადაპტაციური, განმეორებითი შერწყმა, რომელიც შთაგონებულია [timsort](https://en.wikipedia.org/wiki/Timsort)-ით.
    /// იგი შექმნილია ძალიან სწრაფად იმ შემთხვევებში, როდესაც ნაჭერი თითქმის დალაგებულია, ან შედგება ორი ან მეტი დალაგებული თანმიმდევრობით, რომლებიც ერთმანეთის მიყოლებით არის შერწყმული.
    ///
    /// ასევე, იგი გამოყოფს დროებით შენახვას `self` ზომის ნახევარზე, მაგრამ მოკლე ნაჭრებისთვის გამოიყენება არაანაწილებადი ჩასმის დალაგების ნაცვლად.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// ალაგებს ნაჭერს ძირითადი მოპოვების ფუნქციით.
    ///
    /// დახარისხების დროს, საკვანძო ფუნქციას მხოლოდ ერთხელ ეწოდება ელემენტი.
    ///
    /// ეს დალაგება სტაბილურია (მაგ., თანაბარ ელემენტებს არ გადალაგებს) და *O*(*m*\* * n *+* n *\* log(*n*)) უარესი შემთხვევაში, სადაც ძირითადი ფუნქციაა *O*(*m*) .
    ///
    /// მარტივი ძირითადი ფუნქციებისათვის (მაგალითად, ფუნქციები, რომლებიც წარმოადგენს საკუთრების წვდომას ან ძირითად ოპერაციებს), [`sort_by_key`](slice::sort_by_key) სავარაუდოდ უფრო სწრაფი იქნება.
    ///
    /// # მიმდინარე განხორციელება
    ///
    /// ამჟამინდელი ალგორითმი ემყარება Orson Peters-ის [pattern-defeating quicksort][pdqsort]-ს, რომელიც აერთიანებს რანდომიზებული quicksort-ის საშუალო საშუალო შემთხვევას და heapsort-ის ყველაზე ცუდ შემთხვევას, ხოლო გარკვეული შაბლონების ნაჭრებზე ხაზოვანი დროის მიღწევას.
    /// იგი იყენებს გარკვეულ რანდომიზაციას, რათა თავიდან აიცილოს გადაგვარებული შემთხვევები, მაგრამ ფიქსირებული seed ყოველთვის უზრუნველყოს დეტერმინირებული ქცევა.
    ///
    /// უარეს შემთხვევაში, ალგორითმი გამოყოფს დროებით შენახვას `Vec<(K, usize)>` ნაჭრის სიგრძით.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // მაკროს მაკონტროლებელი ჩვენი vector ინდექსაციისთვის რაც შეიძლება მცირე ტიპის მიხედვით, განაწილების შესამცირებლად.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices`- ის ელემენტები უნიკალურია, რადგან ინდექსირებულია, ამიტომ ნებისმიერი სახის სტაბილური იქნება ორიგინალ ნაჭერთან მიმართებაში.
                // ჩვენ აქ ვიყენებთ `sort_unstable`-ს, რადგან ის მეხსიერების ნაკლებ გამოყოფას მოითხოვს.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// ასლის `self` ახალ `Vec`-ს.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // აქ, `s` და `x` შეიძლება მოდიფიცირდეს დამოუკიდებლად.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// ასლის გადაწერა `self` ახალ `Vec`-ში, გამოყოფით.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // აქ, `s` და `x` შეიძლება მოდიფიცირდეს დამოუკიდებლად.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // გაითვალისწინეთ, ამ ფაილში იხილეთ `hack` მოდული დამატებითი ინფორმაციისთვის.
        hack::to_vec(self, alloc)
    }

    /// `self`-ს გარდაქმნის vector-ში კლონების და განაწილების გარეშე.
    ///
    /// შედეგად vector შეიძლება გადაკეთდეს ყუთში `Vec-ის საშუალებით<T>`into_boxed_slice` მეთოდი.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` მისი გამოყენება აღარ შეიძლება, რადგან ის გადაკეთდა `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // გაითვალისწინეთ, ამ ფაილში იხილეთ `hack` მოდული დამატებითი ინფორმაციისთვის.
        hack::into_vec(self)
    }

    /// ქმნის vector-ს ნაჭრის `n` ჯერ გამეორებით.
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია იქნება panic, თუ სიმძლავრე გადაივსება.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic გადავსებისას:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // თუ `n` ნულზე მეტია, მისი გაყოფა შესაძლებელია როგორც `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` არის ნომერი, რომელიც წარმოდგენილია `n`-ის მარცხენა '1' ბიტით, და `rem` არის `n`-ის დარჩენილი ნაწილი.
        //
        //

        // `Vec`- ის გამოყენებით `set_len()`- ზე შესასვლელად.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` გამეორება ხდება `buf` `expn`-ჯერ გაორმაგებით.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // თუ `m > 0`, დარჩენილია ბიტები მარცხენა '1'- მდე.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` აქვს ტევადობა `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) გამეორება ხდება `buf` თავად პირველი `rem` გამეორებების კოპირებით.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // ეს არ არის გადახურვა `2^expn > rem`- დან.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` უდრის `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` ნაჭერს ასწორებს ერთ მნიშვნელობად `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T` ნაჭერს ასწორებს ერთ მნიშვნელობად `Self::Output` და თითოეულს ათავსებს მოცემულ გამყოფს.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T` ნაჭერს ასწორებს ერთ მნიშვნელობად `Self::Output` და თითოეულს ათავსებს მოცემულ გამყოფს.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// აბრუნებს vector-ს, რომელიც შეიცავს ამ ნაჭრის ასლს, სადაც თითოეული ბაიტი გამოსახულია ASCII ექვივალენტზე.
    ///
    ///
    /// ASCII ასოები 'a'-დან 'z'-მდე დატანილია 'A'-დან 'Z'-მდე, მაგრამ არა ASCII ასოები უცვლელია.
    ///
    /// მნიშვნელობის ადგილზე დიდი ასლის დასადგენად გამოიყენეთ [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// აბრუნებს vector-ს, რომელიც შეიცავს ამ ნაჭრის ასლს, სადაც თითოეული ბაიტი აისახება ASCII-ის მცირე ეკვივალენტზე.
    ///
    ///
    /// ASCII ასოები 'A'-დან 'Z'-მდე დატანილია 'a'-დან 'z'-მდე, მაგრამ არა ASCII ასოები უცვლელია.
    ///
    /// იმისათვის, რომ ადგილზე ჩამოაყალიბოთ მნიშვნელობა, გამოიყენეთ [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// traits გაფართოება კონკრეტული ტიპის მონაცემების ნაჭრებისთვის
////////////////////////////////////////////////////////////////////////////////

/// trait დამხმარე ["[T]: : concat"](ნაჭერი::concat).
///
/// Note: `Item` ტიპის პარამეტრი არ არის გამოყენებული ამ trait-ში, მაგრამ ის საშუალებას აძლევს impls უფრო ზოგადი იყოს.
/// მის გარეშე მივიღებთ ამ შეცდომას:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// ეს იმიტომ ხდება, რომ იქ შეიძლება არსებობდეს `V` ტიპები მრავალი `Borrow<[_]>` იმპულსით, ისეთი, რომ მრავალი `T` ტიპი გამოიყენებოდეს:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// შედეგად მიღებული ტიპი შერწყმის შემდეგ
    type Output;

    /// [`[T]: : concat`]-ის განხორციელება (ნაჭერი::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// trait დამხმარე [`[T]: : join`](ნაჭერი::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// შედეგად მიღებული ტიპი შერწყმის შემდეგ
    type Output;

    /// [`[T]: : join`]-ის განხორციელება (ნაჭერი::შეერთება)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// სტანდარტული trait განხორციელება ნაჭრებისთვის
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // სამიზნეში ჩააგდეთ ყველაფერი, რაც არ გადაიწერება
        target.truncate(self.len());

        // target.len <= self.len ზემოთ მოცემული კორპუსის გამო, ამიტომ ნაჭრები აქ ყოველთვის არის საზღვრებში.
        //
        let (init, tail) = self.split_at(target.len());

        // ხელახლა გამოიყენეთ მოცემული მნიშვნელობები allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// ჩასვამს `v[0]` წინასწარ დალაგებულ თანმიმდევრობით `v[1..]` ისე, რომ მთელი `v[..]` დალაგდეს.
///
/// ეს არის ჩასმის დალაგების ინტეგრალური ქვერელიზა.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // ჩასმის განხორციელების სამი გზა არსებობს:
            //
            // 1. შეცვალეთ მიმდებარე ელემენტები მანამ, სანამ პირველი არ მივა საბოლოო დანიშნულების ადგილას.
            //    ამასთან, ამ გზით ჩვენ ვაკოპირებთ მონაცემებს იმაზე მეტს, ვიდრე საჭიროა.
            //    თუ ელემენტები დიდი სტრუქტურებია (ძნელია მათი კოპირება), ეს მეთოდი ნელი იქნება.
            //
            // 2. გაიმეორეთ პირველი ელემენტის შესაფერისი ადგილის აღმოჩენამდე.
            // შემდეგ გადაიტანეთ მისი მომდევნო ელემენტები, რომ ადგილი გაათავისუფლოთ მისთვის და ბოლოს განათავსოთ იგი დარჩენილ ხვრელში.
            // ეს კარგი მეთოდია.
            //
            // 3. პირველი ელემენტის კოპირება დროებით ცვლადში.გაიმეორეთ, სანამ მას შესაფერისი ადგილი იპოვნება.
            // გასწვრივ, ყველა გადალახული ელემენტი გადააკოპირეთ მის წინა ჭრილში.
            // დაბოლოს, გადაწერეთ მონაცემები დროებითი ცვლადიდან დანარჩენ ხვრელში.
            // ეს მეთოდი ძალიან კარგია.
            // ნიშნებმა აჩვენა ოდნავ უკეთესი შესრულება, ვიდრე მე-2 მეთოდით.
            //
            // ყველა მეთოდი შეფასდა და მე-3 აჩვენა საუკეთესო შედეგები.ამიტომ ის ავირჩიეთ.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // ჩასმის პროცესის შუალედურ მდგომარეობას ყოველთვის აკონტროლებს `hole`, რომელიც ორ მიზანს ემსახურება:
            // 1. იცავს `v`- ის მთლიანობას panics- დან `is_less`- ში.
            // 2. ბოლოს ავსებს `v` დარჩენილ ხვრელს.
            //
            // Panic უსაფრთხოება:
            //
            // თუ პროცესის ნებისმიერ წერტილში `is_less` panics ნებისმიერ დროს, `hole` დაეცემა და `v`- ში გახსნის `tmp` ნახვრეტს, რითაც უზრუნველყოფს, რომ `v` კვლავ ინახავს ყველა საგანს, რომელიც თავდაპირველად ეჭირა ზუსტად ერთხელ.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` დაეცემა და ამით ასლებს `tmp` `v`- ის დარჩენილ ხვრელში.
        }
    }

    // ჩამოტვირთვისას, ასლები `src`-დან `dest`-ში.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// აერთიანებს არასამთავრობო შემცირება გაშვება `v[..mid]` და `v[mid..]` გამოყენებით `buf` დროებითი შენახვის, და ინახავს შედეგს `v[..]`.
///
/// # Safety
///
/// ორი ნაჭერი არ უნდა იყოს ცარიელი და `mid` უნდა იყოს საზღვრებში.
/// ბუფერული `buf` უნდა იყოს საკმარისად გრძელი, რომ შეინახოს უფრო მოკლე ნაჭრის ასლი.
/// ასევე, `T` არ უნდა იყოს ნულოვანი ზომის ტიპი.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // შერწყმის პროცესი თავდაპირველად ასლის მოკლე ვერსიას `buf`.
    // შემდეგ იგი ადევნებს თვალყურს ახლად კოპირებულ პერსპექტივას და უფრო ხანგრძლივ პერსპექტივას (ან უკან), ადარებს მათ შემდეგ მოხმარებულ ელემენტებს და ასლის უფრო მცირე (ან უფრო მეტს) `v`-ში.
    //
    // როგორც კი მოკლევადიანი სრულად ამოწურვა ხდება, პროცესი სრულდება.თუ გრძელი პერსპექტივა ჯერ დაიხარჯება, მაშინ რაც მოკლე დროში დარჩება, უნდა გადავწეროთ `v`- ის დარჩენილ ხვრელში.
    //
    // პროცესის შუალედურ მდგომარეობას ყოველთვის აკონტროლებს `hole`, რომელიც ორ მიზანს ემსახურება:
    // 1. იცავს `v`- ის მთლიანობას panics- დან `is_less`- ში.
    // 2. ავსებს `v` დარჩენილ ხვრელს, თუ პირველი ხანგრძლივობა დაიხარჯება პირველ რიგში.
    //
    // Panic უსაფრთხოება:
    //
    // თუ პროცესის ნებისმიერ წერტილში `is_less` panics რაიმე დროს, `hole` დაეცემა და შეავსებს `v`- ის ხვრელს `buf`- ში მოხმარებული დიაპაზონით, რაც უზრუნველყოფს იმას, რომ `v` მაინც ინახავს ყველა საგანს, რომელიც თავდაპირველად ზუსტად ერთხელ ჰქონდა გამართული.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // მარცხენა გაშვება უფრო მოკლეა.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // თავდაპირველად, ეს მითითებები მიუთითებს მათი მასივების დასაწყისზე.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // მოიხმარეთ ნაკლები მხარე.
            // თუ თანაბარია, სტაბილურობის შესანარჩუნებლად მარცხენა სვლა გირჩევნიათ.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // სწორი გაშვება უფრო მოკლეა.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // თავდაპირველად, ეს მაჩვენებლები მიუთითებს მათი მასივების ბოლოებზე.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // მოიხმარეთ უფრო დიდი მხარე.
            // თუ თანაბარია, უპირატესობა მიანიჭეთ სწორ სვლას სტაბილურობის შესანარჩუნებლად.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // დაბოლოს, `hole` დაეცა.
    // თუ ხანმოკლე სრულად სრულად არ იქნა მოხმარებული, რაც დარჩება ახლა, გადაწერა `v`- ის ხვრელში.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // ჩამოშვებისას `start..end` დიაპაზონი კოპირდება `dest..`-ში.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` არ არის ნულოვანი ზომის ტიპი, ამიტომ კარგია მისი ზომაზე გაყოფა.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// ამ შერწყმის დალაგება სესხულობს TimSort- ის ზოგიერთ (მაგრამ არა ყველა) იდეას, რომელიც დეტალურად არის აღწერილი [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// ალგორითმი განსაზღვრავს მკაცრად დაღმავალ და არა დაღმავალ ქვედამიმდევრებს, რომლებსაც ბუნებრივ გაშვებებს უწოდებენ.ჯერ კიდევ არ არის შერწყმული გაშვებული სტეკი.
/// ყოველი ახლად აღმოჩენილი პერსპექტივა დაეშვება სტეკს და შემდეგ რამდენიმე წყვილი მიმდებარე გაშვებებით გაერთიანდება, სანამ ეს ორი ინვარიანტი არ დაკმაყოფილდება:
///
/// 1. ყოველი `i` `1..runs.len()`- ში: `runs[i - 1].len > runs[i].len`
/// 2. ყოველი `i` `2..runs.len()`- ში: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// ინვარიანტები უზრუნველყოფენ, რომ გაშვების საერთო დრო არის *O*(*n*\*log(* n*)) უარეს შემთხვევაში.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ამ სიგრძის ნაჭრები დალაგებულია ჩასმის დალაგების გამოყენებით.
    const MAX_INSERTION: usize = 20;
    // ძალიან მოკლე გაშვებები ვრცელდება ჩასმის დალაგების გამოყენებით, ამდენი ელემენტის დასაფარავად მაინც.
    const MIN_RUN: usize = 10;

    // დალაგებას არ აქვს მნიშვნელოვანი ქცევა ნულოვანი ზომის ტიპებზე.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // მოკლე მასივები დალაგებულია ადგილზე ჩასმის დალაგების გზით, გამოყოფის თავიდან ასაცილებლად.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // გამოყავით ბუფერი, რომ გამოიყენოთ როგორც ნაკაწრი მეხსიერება.ჩვენ ვინახავთ 0 სიგრძეს, ასე რომ შეგვიძლია შევინახოთ `v` შინაარსის არაღრმა ასლები ისე, რომ არ გავრისკოთ ასლები, თუ `is_less` panics მუშაობს.
    //
    // ორი დახარისხებული გაშვების შერწყმისას, ამ ბუფერულს ინახავს უფრო მოკლე ასლის ასლი, რომელსაც ყოველთვის ექნება მაქსიმუმ `len / 2` სიგრძე.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v`- ში ბუნებრივი გაშვების გამოვლენის მიზნით, მას უკან ვუვლით.
    // ეს შეიძლება უცნაურ გადაწყვეტილებად მოგეჩვენოთ, მაგრამ გაითვალისწინეთ ის ფაქტი, რომ შერწყმა უფრო ხშირად ხდება საწინააღმდეგო მიმართულებით (forwards).
    // ნიშნულების თანახმად, ფორვარდების შერწყმა ოდნავ უფრო სწრაფია, ვიდრე უკან შერწყმა.
    // დავასკვნათ, რომ გაშვებების იდენტიფიცირება უკან გადახვევით აუმჯობესებს მუშაობას.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // იპოვნეთ შემდეგი ბუნებრივი სვლა და შეცვალეთ იგი, თუ ის მკაცრად დაღმავალია.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // ჩასვით რამდენიმე ელემენტი პერსპექტივაში, თუ ეს ძალიან მოკლეა.
        // ჩასმის დალაგება უფრო სწრაფია, ვიდრე მოკლე თანმიმდევრობით დალაგების შერწყმა, ამიტომ ეს მნიშვნელოვნად აუმჯობესებს მუშაობას.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // დააყენეთ ეს სტეკი დასტაზე.
        runs.push(Run { start, len: end - start });
        end = start;

        // შეუერთეთ რამდენიმე წყვილი მეზობელი გაშვებებით ინვარიანტების დასაკმაყოფილებლად.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // დაბოლოს, ზუსტად ერთი სირბილი უნდა დარჩეს სტეკში.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // იკვლევს გაშვების სტეკს და განსაზღვრავს გაშვების შემდეგ წყვილს შერწყმისთვის.
    // უფრო კონკრეტულად, თუ `Some(r)` დაუბრუნდება, ეს ნიშნავს, რომ შემდეგ უნდა გაერთიანდეს `runs[r]` და `runs[r + 1]`.
    // თუ ალგორითმი უნდა გააგრძელოს ახალი ტირაჟის მშენებლობა, `None` უბრუნდება.
    //
    // TimSort ცნობილია თავისი შეცდომებით განხორციელებული ქმედებებით, როგორც აღწერილია აქ:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // სიუჟეტის არსია: ჩვენ უნდა აღვასრულოთ ინვარიანტები სტეკზე დასაყრდენ ოთხივე გაშვებაში.
    // მათი შესრულება მხოლოდ სამეულში არ არის საკმარისი იმის უზრუნველსაყოფად, რომ ინვარიანტები კვლავ დაიცავს სტეკში *ყველა* გაშვებას.
    //
    // ეს ფუნქცია სწორად ამოწმებს ოთხი საუკეთესო გაშვების ინვარიანტებს.
    // გარდა ამისა, თუ ზედა გაშვება იწყება ინდექსში 0, ის ყოველთვის მოითხოვს შერწყმის ოპერაციას, სანამ სტეკი სრულად არ დაიშლება, დალაგების დასრულების მიზნით.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}