#![stable(feature = "wake_trait", since = "1.51.0")]
//! ტიპები და Traits ასინქრონულ დავალებებთან მუშაობისთვის.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// შემსრულებელზე დავალების გაღვიძების განხორციელება.
///
/// ეს trait შეიძლება გამოყენებულ იქნას [`Waker`]-ის შესაქმნელად.
/// შემსრულებელს შეუძლია განსაზღვროს ამ trait- ის განხორციელება და გამოიყენოს იგი Waker- ის ასაშენებლად, რათა გადასცეს ამოცანები, რომლებიც შესრულებულია ამ შემსრულებელზე.
///
/// ეს trait არის მეხსიერების უსაფრთხო და ერგონომიული ალტერნატივა [`RawWaker`]- ის მშენებლობისთვის.
/// იგი მხარს უჭერს შემსრულებლის საერთო დიზაინს, რომელშიც დავალების გასაღვიძებლად გამოყენებული მონაცემები ინახება [`Arc`]-ში.
/// ზოგიერთ შემსრულებელს (განსაკუთრებით ჩანერგილ სისტემებს) არ შეუძლია გამოიყენოს ეს API, ამიტომ [`RawWaker`] არსებობს ამ სისტემების ალტერნატივად.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// ძირითადი `block_on` ფუნქცია, რომელიც იღებს future და აწარმოებს მას დასრულებამდე მიმდინარე ძაფზე.
///
/// **Note:** ეს მაგალითი სიზუსტეს ვაჭრობს სიმარტივისთვის.
/// ჩიხების თავიდან ასაცილებლად, წარმოების დონის დანერგვას ასევე მოეთხოვება შუალედური ზარების გადაჭრა `thread::unpark`- ზე, ასევე ჩადგმული გამოძახებები.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// გამოღვიძება, რომელიც იღვიძებს მიმდინარე ძაფს დარეკვისას.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// გაუშვით future მიმდინარე ძაფის დასრულებამდე.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // ჩამაგრეთ future, რომ გამოკითხვა მოხდეს.
///     let mut fut = Box::pin(fut);
///
///     // შექმენით ახალი კონტექსტი future-ს გადასაცემად.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // გაუშვით future დასრულებამდე.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// გაიღვიძე ეს დავალება.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// გაიღვიძე ეს დავალება გამაღვიძებლის მოხმარების გარეშე.
    ///
    /// თუ შემსრულებელი მხარს უჭერს გაღვიძების უფრო დაბალ გზას გამათბობელი მოხმარების გარეშე, ეს უნდა გადალახოს ამ მეთოდს.
    /// ნაგულისხმევად, ის კლონირებს [`Arc`]-ს და კლონზე ურეკავს [`wake`]-ს.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // უსაფრთხოება: ეს უსაფრთხოა, რადგან raw_waker უსაფრთხოდ აშენებს
        // RawWaker საწყისი Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker- ის შესაქმნელად ეს კერძო ფუნქცია გამოიყენება, ვიდრე
// ამის მითითება `From<Arc<W>> for RawWaker` impl-ში, იმის უზრუნველსაყოფად, რომ `From<Arc<W>> for Waker` უსაფრთხოება არ არის დამოკიდებული trait-ის სწორად გაგზავნაზე, სამაგიეროდ, ორივე ამ ფუნქციას პირდაპირ და პირდაპირ ეწოდება.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // გაზარდეთ რკალის მითითების რაოდენობა მისი კლონირებისთვის.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // გაიღვიძეთ მნიშვნელობით, გადაიტანეთ Arc Wake::wake ფუნქციაში
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // გაიღვიძეთ მითითებით, შეახვიეთ შუშა ManualDrop-ში, რომ არ ჩამოაგდოთ
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // ჩამოაყალიბეთ Arc-ის მითითების რაოდენობა
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}