#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// ახალი მეხსიერების შინაარსი არაინიციალიზებულია.
    Uninitialized,
    /// ახალი მეხსიერების ნულოვანი გარანტია.
    Zeroed,
}

/// დაბალი დონის კომუნალური მეხსიერების ბუფერის უფრო ერგონომიული განაწილების, გადანაწილებისა და გადანაწილებისათვის გროვაზე ყველა კუთხის შემთხვევაზე ფიქრის გარეშე.
///
/// ეს ტიპი შესანიშნავია თქვენი მონაცემების სტრუქტურების შესაქმნელად, როგორიცაა Vec და VecDeque.
/// Კერძოდ:
///
/// * აწარმოებს `Unique::dangling()`- ს ნულოვანი ზომის ტიპებზე.
/// * აწარმოებს `Unique::dangling()` ნულოვანი სიგრძის გამოყოფებზე.
/// * თავს არიდებს `Unique::dangling()`- ის გათავისუფლებას.
/// * იჭერს ტევადობის გამოთვლებში ყველა გადავსებას (აძლიერებს მათ "capacity overflow" panics- მდე).
/// * დაცვა 32-ბიტიანი სისტემებისგან, რომლებიც გამოყოფენ isize::MAX ბაიტზე მეტს.
/// * იცავს თქვენს სიგრძეზე გადავსებას.
/// * ურეკავს `handle_alloc_error` შეცდომების გამოყოფას.
/// * შეიცავს `ptr::Unique` და ამით მომხმარებელს ანიჭებს ყველა მასთან დაკავშირებულ უპირატესობას.
/// * იყენებს გამანაწილებლისგან დაბრუნებულ ჭარბს, ყველაზე დიდი ხელმისაწვდომი სიმძლავრის გამოსაყენებლად.
///
/// ყოველ შემთხვევაში, ეს ტიპი არ ამოწმებს მეხსიერებას, რომელსაც ის მართავს.ჩამოვარდნისას *გაათავისუფლებს მეხსიერებას, მაგრამ ის* არ შეეცდება * ჩააგდოს მისი შინაარსი.
/// `RawVec` მომხმარებელს გადაეცემა `RawVec`- ის შიგნით შენახული * ნივთები.
///
/// გაითვალისწინეთ, რომ ნულოვანი ზომის ტიპების სიჭარბე ყოველთვის უსასრულოა, ამიტომ `capacity()` ყოველთვის უბრუნებს `usize::MAX`-ს.
/// ეს ნიშნავს, რომ ფრთხილად უნდა იყოთ ამ ტიპის `Box<[T]>`- ით დამრგვალების დროს, რადგან `capacity()` არ იძლევა სიგრძეს.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): ეს არსებობს იმიტომ, რომ `#[unstable]` `const fn` არ უნდა შეესაბამებოდეს `min_const_fn` და ამიტომ მათი გამოძახება არც`min_const_fn` შეუძლებელია.
    ///
    /// თუ შეცვლით `RawVec<T>::new` ან დამოკიდებულებებს, გთხოვთ იზრუნოთ რომ არ შემოიტანოთ ისეთი რამ, რაც ნამდვილად დაარღვევს `min_const_fn`.
    ///
    /// NOTE: ჩვენ შეგვიძლია თავიდან ავიცილოთ ეს გატეხვა და შეამოწმოთ შესაბამისობა ზოგიერთ `#[rustc_force_min_const_fn]` ატრიბუტთან, რომელიც მოითხოვს შესაბამისობას `min_const_fn`- სთან, მაგრამ სულაც არ იძლევა მას დარეკვას `stable(...) const fn`/მომხმარებლის კოდში, რომელიც არ იძლევა `foo`- ს, როდესაც `#[rustc_const_unstable(feature = "foo", issue = "01234")]` არსებობს.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// გამოყოფის გარეშე ქმნის უდიდეს შესაძლო `RawVec` (სისტემის გროვაზე).
    /// თუ `T`- ს აქვს დადებითი ზომა, ეს ქმნის `RawVec`- ს მოცულობით `0`.
    /// თუ `T` არის ნულოვანი ზომის, ეს ქმნის `RawVec` ტევადობას `usize::MAX`.
    /// სასარგებლოა დაგვიანებული გამოყოფის განსახორციელებლად.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// ქმნის `RawVec` (სისტემის გროვაზე) ზუსტად ტევადობის და მისწორების მოთხოვნებისთვის `[T; capacity]`.
    /// ეს ექვივალენტურია `RawVec::new`- ზე დარეკვისა, როდესაც `capacity` არის `0` ან `T` არის ნულოვანი ზომის.
    /// გაითვალისწინეთ, რომ თუ `T` არის ნულოვანი ზომის, ეს ნიშნავს, რომ თქვენ * არ მიიღებთ მოთხოვნილ ტევადობას `RawVec`.
    ///
    /// # Panics
    ///
    /// Panics თუ მოთხოვნილი სიმძლავრე აღემატება `isize::MAX` ბაიტს.
    ///
    /// # Aborts
    ///
    /// აბორტებს OOM- ზე.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// როგორც `with_capacity`, მაგრამ გარანტიას იძლევა, რომ ბუფერი ნულოვანია.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// `RawVec` ახდენს მაჩვენებლისა და სიმძლავრისგან.
    ///
    /// # Safety
    ///
    /// `ptr` უნდა იყოს გამოყოფილი (სისტემის გროვაზე) და მოცემული `capacity`- ით.
    /// `capacity` არ უნდა აღემატებოდეს `isize::MAX` ზომის ტიპებს.(მხოლოდ პრობლემაა 32-ბიტიან სისტემებზე).
    /// ZST vectors შეიძლება ჰქონდეს ტევადობა `usize::MAX` მდე.
    /// თუ `ptr` და `capacity` მოდის `RawVec`- დან, ეს გარანტირებულია.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // პაწაწინა ვეკები დუმან.გადასვლა:
    // - 8, თუ ელემენტის ზომაა 1, რადგან გროვების ნებისმიერი განაწილება, სავარაუდოდ, შეავსებს მოთხოვნას 8 ბაიტზე ნაკლები, მინიმუმ 8 ბაიტზე.
    //
    // - 4 თუ ელემენტები ზომიერი ზომისაა (<=1 KiB).
    // - 1 სხვაგვარად, რომ თავიდან იქნას აცილებული ძალიან მოკლე ადგილის დაკარგვა ძალიან მოკლე ვეკებისთვის.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new`-ის მსგავსად, მაგრამ პარამეტრირებულია დაბრუნებული `RawVec`-ისთვის გამანაწილებლის არჩევისას.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` ნიშნავს "unallocated".ნულოვანი ზომის ტიპები იგნორირებულია.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity`-ის მსგავსად, მაგრამ პარამეტრირებულია დაბრუნებული `RawVec`-ისთვის გამანაწილებლის არჩევისას.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed`-ის მსგავსად, მაგრამ პარამეტრირებულია დაბრუნებული `RawVec`-ისთვის გამანაწილებლის არჩევისას.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>`-ს გარდაქმნის `RawVec<T>`-ში.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// გარდაქმნის მთელ ბუფერს `Box<[MaybeUninit<T>]>` მითითებული `len`- ით.
    ///
    /// გაითვალისწინეთ, რომ ეს სწორად აღადგენს `cap` ცვლილებებს, რომლებიც შეიძლება განხორციელდეს.(დეტალებისთვის იხილეთ ტიპის აღწერა.)
    ///
    /// # Safety
    ///
    /// * `len` უნდა იყოს მეტი ან ტოლი ბოლო დროს მოთხოვნილი სიმძლავრისა და
    /// * `len` უნდა იყოს `self.capacity()`- ზე ნაკლები ან ტოლი.
    ///
    /// გაითვალისწინეთ, რომ მოთხოვნილი სიმძლავრე და `self.capacity()` შეიძლება განსხვავდებოდეს, რადგან გამანაწილებელმა შეიძლება შეადგინოს და დააბრუნოს მეხსიერების უფრო დიდი ბლოკი, ვიდრე მოთხოვნილია.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // საღი აზრი შეამოწმეთ უსაფრთხოების მოთხოვნის ერთი ნახევარი (მეორე ნახევარს ვერ შევამოწმებთ).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // აქ `unwrap_or_else`-ს ვერიდებით, რადგან ის ადიდებს LLVM IR წარმოქმნილ რაოდენობას.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// `RawVec` ახდენს მაჩვენებლის, სიმძლავრისა და გამანაწილებლისგან.
    ///
    /// # Safety
    ///
    /// `ptr` უნდა გამოიყოს (მოცემული გამყოფი `alloc`- ის საშუალებით) და მოცემული `capacity`- ით.
    /// `capacity` არ უნდა აღემატებოდეს `isize::MAX` ზომის ტიპებს.
    /// (მხოლოდ პრობლემაა 32-ბიტიან სისტემებზე).
    /// ZST vectors შეიძლება ჰქონდეს ტევადობა `usize::MAX` მდე.
    /// თუ `ptr` და `capacity` მოდის `alloc`- ით შექმნილი `RawVec`- დან, ეს გარანტირებულია.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// გამოყოფის დაწყებისას იღებს ნედლეულს.
    /// გაითვალისწინეთ, რომ ეს არის `Unique::dangling()`, თუ `capacity == 0` ან `T` არის ნულოვანი ზომის.
    /// ყოფილ შემთხვევაში ფრთხილად უნდა იყოთ.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// იღებს გამოყოფის შესაძლებლობას.
    ///
    /// ეს ყოველთვის იქნება `usize::MAX`, თუ `T` ნულოვანი ზომის იქნება.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// აბრუნებს გაზიარებულ მითითებას ამ `RawVec`-ის მხარდაჭერილ გამანაწილებელზე.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // ჩვენ გამოყოფილი გვაქვს მეხსიერების ნაწილი, ასე რომ, ჩვენ შეგვიძლია გვერდის ავლით გავატაროთ შემოწმებები, რომ მიიღოთ ჩვენი ამჟამინდელი განლაგება.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// უზრუნველყოფს, რომ ბუფერი შეიცავს მინიმუმ საკმარის ადგილს `len + additional` ელემენტების დასაკავებლად.
    /// თუ მას უკვე არ აქვს საკმარისი ტევადობა, გადაანაწილებთ საკმარის ადგილს და კომფორტულ სუსტ ადგილს, რომ მიიღოთ ამორტიზებული *O*(1) ქცევა.
    ///
    /// შეზღუდავს ამ ქცევას, თუ იგი თავისთავად გამოიწვევს panic- ს.
    ///
    /// თუ `len` აღემატება `self.capacity()`-ს, ამან შეიძლება ვერ გამოყოს მოთხოვნილი ადგილი.
    /// ეს ნამდვილად არ არის სახიფათო, მაგრამ შეიძლება დაირღვეს არასაიმედო კოდი, რომელსაც თქვენ წერთ, რომელიც ეყრდნობა ამ ფუნქციის ქცევას.
    ///
    /// ეს იდეალურია ნაყარი-ოპერაციის განსახორციელებლად, როგორიცაა `extend`.
    ///
    /// # Panics
    ///
    /// Panics თუ ახალი სიმძლავრე `isize::MAX` ბაიტს აღემატება.
    ///
    /// # Aborts
    ///
    /// აბორტებს OOM- ზე.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // რეზერვი შეწყვეტილი იქნებოდა ან პანიკა იქნებოდა, თუ სესხი `isize::MAX`- ს გადააჭარბებდა, ამიტომ ამის გაკეთება უსაფრთხოა, ახლა კი მონიშნულია.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// იგივე `reserve`, მაგრამ უბრუნებს შეცდომებს პანიკის და აბორტის ნაცვლად.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// უზრუნველყოფს, რომ ბუფერი შეიცავს მინიმუმ საკმარის ადგილს `len + additional` ელემენტების დასაკავებლად.
    /// თუ ეს უკვე არ მოხდა, გადაანაწილებთ საჭირო მეხსიერების მინიმალურ რაოდენობას.
    /// საერთოდ, ეს იქნება მეხსიერების ზუსტად ის ოდენობა, რაც აუცილებელია, მაგრამ პრინციპში, გამანაწილებელმა თავისუფლად შეიძლება დაუბრუნოს იმაზე მეტს, ვიდრე ვთხოვეთ.
    ///
    ///
    /// თუ `len` აღემატება `self.capacity()`-ს, ამან შეიძლება ვერ გამოყოს მოთხოვნილი ადგილი.
    /// ეს ნამდვილად არ არის სახიფათო, მაგრამ შეიძლება დაირღვეს არასაიმედო კოდი, რომელსაც თქვენ წერთ, რომელიც ეყრდნობა ამ ფუნქციის ქცევას.
    ///
    /// # Panics
    ///
    /// Panics თუ ახალი სიმძლავრე `isize::MAX` ბაიტს აღემატება.
    ///
    /// # Aborts
    ///
    /// აბორტებს OOM- ზე.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// იგივე `reserve_exact`, მაგრამ უბრუნებს შეცდომებს პანიკის ან აბორტის ნაცვლად.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// ამცირებს გამოყოფას მითითებულ თანხამდე.
    /// თუ მოცემული თანხა არის 0, სინამდვილეში მთლიანად გამოიყოფა.
    ///
    /// # Panics
    ///
    /// Panics თუ მოცემული თანხა *უფრო დიდია* ვიდრე ამჟამინდელი მოცულობა.
    ///
    /// # Aborts
    ///
    /// აბორტებს OOM- ზე.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// ბრუნდება, თუ ბუფერი უნდა გაიზარდოს საჭირო დამატებითი სიმძლავრის შესასრულებლად.
    /// ძირითადად გამოიყენება სარეზერვო ზარების ხაზგასმა `grow` ხაზგასმის გარეშე.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // ეს მეთოდი, როგორც წესი, ბევრჯერ არის ინსტანირებული.ასე რომ, ჩვენ გვინდა, რომ რაც შეიძლება მცირე იყოს, შევადგინოთ დროის შედგენა.
    // მაგრამ ჩვენ ასევე გვინდა, რომ რაც შეიძლება მეტი შინაარსი იყოს სტატისტიკურად გამოსათვლელი, რათა წარმოქმნილი კოდი უფრო სწრაფად იმუშაოს.
    // ამიტომ, ეს მეთოდი გულდასმით არის დაწერილი ისე, რომ მთელი კოდი, რომელიც დამოკიდებულია `T`- ზე, იყოს მის შიგნით, ხოლო რაც შეიძლება მეტი კოდი, რომელიც არ არის დამოკიდებული `T`- ზე, არის ფუნქციები, რომლებიც არა ზოგადია `T`- ზე.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // ამას უზრუნველყოფს დარეკვის კონტექსტები.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // მას შემდეგ, რაც ჩვენ დავაბრუნებთ `usize::MAX` მოცულობას, როდესაც `elem_size` არის
            // 0, აქ მოხვედრა აუცილებლად ნიშნავს, რომ `RawVec` არის სრულფასოვანი.
            return Err(CapacityOverflow);
        }

        // სამწუხაროდ, ამ შემოწმებების გაკეთება ნამდვილად არ შეგვიძლია.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // ეს უზრუნველყოფს ექსპონენციალურ ზრდას.
        // გაორმაგება ვერ გადაივსება, რადგან `cap <= isize::MAX` და `cap` ტიპის არის `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` არ არის ზოგადი `T`- ზე.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // ამ მეთოდის შეზღუდვები დაახლოებით იგივეა, რაც `grow_amortized`- ზე, მაგრამ ეს მეთოდი, როგორც წესი, ნაკლებად ხშირად ხდება, ამიტომ ნაკლებად კრიტიკულია.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // ვინაიდან `usize::MAX` მოცულობას ვაბრუნებთ, როდესაც ტიპის ზომაა
            // 0, აქ მოხვედრა აუცილებლად ნიშნავს, რომ `RawVec` არის სრულფასოვანი.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` არ არის ზოგადი `T`- ზე.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// ეს ფუნქცია არ არის `RawVec` გარეთ, რომ შეამციროს კომპილირების დრო.დეტალებისთვის იხილეთ კომენტარი ზემოთ `RawVec::grow_amortized`.
// (`A` პარამეტრი არ არის მნიშვნელოვანი, რადგან სხვადასხვა `A` ტიპის რაოდენობა პრაქტიკაში გაცილებით ნაკლებია, ვიდრე `T` ტიპის.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // შეამოწმეთ შეცდომა აქ, რათა შეამციროთ `RawVec::grow_*` ზომა.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // გამანაწილებელი ამოწმებს გასწორების თანასწორობას
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// ათავისუფლებს `RawVec`*-ის საკუთრებაში არსებულ მეხსიერებას* და არ ცდილობს მისი შინაარსი ჩამოაგდეს.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// სარეზერვო შეცდომების გატარების ცენტრალური ფუნქცია.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// ჩვენ უნდა უზრუნველყოთ შემდეგი:
// * ჩვენ არასდროს გამოყოფთ `> isize::MAX` ბაიტის ზომის ობიექტებს.
// * ჩვენ არ გადავსებთ `usize::MAX`- ს და რეალურად გამოყოფთ ძალიან ცოტას.
//
// 64 ბიტიანზე ჩვენ უბრალოდ უნდა გადავამოწმოთ გადავსება, რადგან `> isize::MAX` ბაიტის გამოყოფის მცდელობა ნამდვილად ვერ მოხერხდება.
// 32-ბიტიან და 16-ბიტიანზე ჩვენ უნდა დავამატოთ ამის დამატებითი დაცვა იმ შემთხვევაში, თუ ჩვენ ვმუშაობთ პლატფორმაზე, რომელსაც შეუძლია გამოიყენოს ყველა 4 გბაიტი მომხმარებლის სივრცეში, მაგალითად, PAE ან x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// ერთი ცენტრალური ფუნქცია, რომელიც პასუხისმგებელია სიმძლავრის გადავსების შესახებ.
// ეს უზრუნველყოფს, რომ ამ panics- სთან დაკავშირებული კოდის წარმოება მინიმალურია, რადგან არსებობს მხოლოდ ერთი ადგილმდებარეობა, რომელიც panics- ს წარმოადგენს, ვიდრე მთლიანი მოდულის კონა.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}