//! მეხსიერების გამოყოფის API

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // ეს არის ჯადოსნური სიმბოლოები, რომლითაც შეგიძლიათ დარეკოთ გლობალური გამყოფი.rustc ქმნის მათ `__rg_alloc` და ა.შ.
    // თუ არსებობს `#[global_allocator]` ატრიბუტი (მაკრო მაკორექტირებელი კოდი ქმნის ამ ფუნქციებს), ან ნაგულისხმევი დანერგვის გამოძახება libstd (`__rdl_alloc` და ა.შ.)
    //
    // `library/std/src/alloc.rs`-ში) სხვაგვარად.
    // LLVM-ის rustc fork ასევე სპეციალურ შემთხვევებში აღნიშნავს ამ ფუნქციების სახელებს, რომ შეძლონ მათი ოპტიმიზაცია, მაგალითად `malloc`, `realloc` და `free`.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// გლობალური მეხსიერების გამანაწილებელი.
///
/// ეს ტიპი ახორციელებს [`Allocator`] trait ზარების გადამისამართებით გამოყოფისთვის, რომელიც რეგისტრირებულია `#[global_allocator]` ატრიბუტით, ან თუ არსებობს `std` crate ნაგულისხმევი.
///
///
/// Note: მიუხედავად იმისა, რომ ეს ტიპი არასტაბილურია, მის ფუნქციონალზე წვდომა შესაძლებელია [free functions in `alloc`](self#functions)- ის საშუალებით.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// მეხსიერების გამოყოფა გლობალურ გამანაწილებელთან.
///
/// ეს ფუნქცია აგზავნის გამოძახების [`GlobalAlloc::alloc`] მეთოდს, რომელიც რეგისტრირებულია `#[global_allocator]` ატრიბუტით, თუ არსებობს, ან `std` crate ნაგულისხმევია.
///
///
/// სავარაუდოდ, ამ ფუნქციის გაუქმება მოხდება [`Global`] ტიპის `alloc` მეთოდის სასარგებლოდ, როდესაც ის და [`Allocator`] trait გახდება სტაბილური.
///
/// # Safety
///
/// იხილეთ [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// მეხსიერების გადანაწილება გლობალურ გამანაწილებელთან.
///
/// ეს ფუნქცია აგზავნის გამოძახების [`GlobalAlloc::dealloc`] მეთოდს, რომელიც რეგისტრირებულია `#[global_allocator]` ატრიბუტით, თუ არსებობს, ან `std` crate ნაგულისხმევია.
///
///
/// სავარაუდოდ, ამ ფუნქციის გაუქმება მოხდება [`Global`] ტიპის `dealloc` მეთოდის სასარგებლოდ, როდესაც ის და [`Allocator`] trait გახდება სტაბილური.
///
/// # Safety
///
/// იხილეთ [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// მეხსიერების გადანაწილება გლობალურ გამანაწილებელთან.
///
/// ეს ფუნქცია აგზავნის გამოძახების [`GlobalAlloc::realloc`] მეთოდს, რომელიც რეგისტრირებულია `#[global_allocator]` ატრიბუტით, თუ არსებობს, ან `std` crate ნაგულისხმევია.
///
///
/// სავარაუდოდ, ამ ფუნქციის გაუქმება მოხდება [`Global`] ტიპის `realloc` მეთოდის სასარგებლოდ, როდესაც ის და [`Allocator`] trait გახდება სტაბილური.
///
/// # Safety
///
/// იხილეთ [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// ნულოვანი ინიცირებული მეხსიერების გამოყოფა გლობალურ გამანაწილებელთან.
///
/// ეს ფუნქცია აგზავნის გამოძახების [`GlobalAlloc::alloc_zeroed`] მეთოდს, რომელიც რეგისტრირებულია `#[global_allocator]` ატრიბუტით, თუ არსებობს, ან `std` crate ნაგულისხმევია.
///
///
/// სავარაუდოდ, ამ ფუნქციის გაუქმება მოხდება [`Global`] ტიპის `alloc_zeroed` მეთოდის სასარგებლოდ, როდესაც ის და [`Allocator`] trait გახდება სტაბილური.
///
/// # Safety
///
/// იხილეთ [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // უსაფრთხოება: `layout` ზომაში არ არის ნულოვანი,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // უსაფრთხოება: იგივეა, რაც `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // უსაფრთხოება: `new_size` ნულოვანია, რადგან `old_size` მეტია ან ტოლია `new_size`
            // როგორც ამას უსაფრთხოების პირობები მოითხოვს.აბონენტის მიერ სხვა პირობები უნდა იყოს დაცული
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` ალბათ ამოწმებს `new_size >= old_layout.size()` ან რამე მსგავსს.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // უსაფრთხოება: რადგან `new_layout.size()` უნდა იყოს მეტი ან ტოლი `old_size`,
            // ძველი და ახალი მეხსიერების განაწილება მოქმედებს `old_size` ბაიტისთვის კითხვისა და წერისთვის.
            // ასევე, იმის გამო, რომ ძველი განაწილება ჯერ კიდევ არ იყო გადატანილი, მას არ შეუძლია გადაფაროს `new_ptr`.
            // ამრიგად, `copy_nonoverlapping`-ზე ზარი უსაფრთხოა.
            // აბონენტის მიერ დაცული უნდა იყოს უსაფრთხოების კონტრაქტი `dealloc`- ზე.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // უსაფრთხოება: `layout` ზომაში არ არის ნულოვანი,
            // აბონენტის მიერ სხვა პირობები უნდა იყოს დაცული
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // უსაფრთხოება: აბონენტის მიერ დაცული უნდა იყოს ყველა პირობა
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // უსაფრთხოება: აბონენტის მიერ დაცული უნდა იყოს ყველა პირობა
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // უსაფრთხოება: პირობები უნდა დაიცვას აბონენტმა
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // უსაფრთხოება: `new_size` არ არის ნულოვანი.აბონენტის მიერ სხვა პირობები უნდა იყოს დაცული
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` ალბათ ამოწმებს `new_size <= old_layout.size()` ან რამე მსგავსს.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // უსაფრთხოება: რადგან `new_size` უნდა იყოს ნაკლები ან ტოლი `old_layout.size()`,
            // ძველი და ახალი მეხსიერების განაწილება მოქმედებს `new_size` ბაიტისთვის კითხვისა და წერისთვის.
            // ასევე, იმის გამო, რომ ძველი განაწილება ჯერ კიდევ არ იყო გადატანილი, მას არ შეუძლია გადაფაროს `new_ptr`.
            // ამრიგად, `copy_nonoverlapping`-ზე ზარი უსაფრთხოა.
            // აბონენტის მიერ დაცული უნდა იყოს უსაფრთხოების კონტრაქტი `dealloc`- ზე.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// გამორჩეული უნიკალური მაჩვენებლებისთვის.
// ეს ფუნქცია არ უნდა განიტვირთოს.თუ ეს მოხდა, MIR კოგენი ვერ მოხერხდება.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// ეს ხელმოწერა უნდა იყოს იგივე, რაც `Box`, წინააღმდეგ შემთხვევაში ICE მოხდება.
// როდესაც `Box`-ს დაემატება დამატებითი პარამეტრი (მაგ. `A: Allocator`), ეს უნდა დაემატოს აქაც.
// მაგალითად, თუ `Box` შეიცვალა `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, ეს ფუნქცია ასევე უნდა შეიცვალოს `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # განაწილების შეცდომის დამმუშავებელი

extern "Rust" {
    // ეს არის ჯადოსნური სიმბოლო გლობალური გამოყოფის შეცდომების დამმუშავებლად.
    // rustc წარმოქმნის მას, რომ `__rg_oom` დარეკოთ, თუ არსებობს `#[alloc_error_handler]`, ან სხვაგვარად დარეკოთ ნაგულისხმევი პროგრამები (`__rdl_oom`) ქვემოთ.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// შეწყვიტე მეხსიერების გამოყოფის შეცდომა ან შეცდომა.
///
/// მეხსიერების გამოყოფის API-ს შემძახებლები, რომელთაც სურთ გამოანგარიშების შეწყვეტა გამოყოფის შეცდომის საპასუხოდ, ურჩევენ ამ ფუნქციას დარეკონ, ვიდრე უშუალოდ `panic!` ან მის მსგავსი გახდეს.
///
///
/// ამ ფუნქციის ნაგულისხმევი ქცევაა შეტყობინების შეცვლა სტანდარტული შეცდომისთვის და პროცესის შეწყვეტა.
/// ის შეიძლება შეიცვალოს [`set_alloc_error_hook`] და [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// გამოყოფის ტესტისთვის `std::alloc::handle_alloc_error` შეიძლება გამოყენებულ იქნას პირდაპირ.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // ეწოდება გენერირებული `__rust_alloc_error_handler`

    // თუ არ არსებობს `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // თუ არსებობს `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// კლონების სპეციალიზაცია წინასწარ გამოყოფილ, არაინციალიზებულ მეხსიერებაში.
/// იყენებენ `Box::clone` და `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *პირველი* გამოყოფის შემთხვევაში, ოპტიმიზატორი საშუალებას მისცემს შექმნას კლონირებული მნიშვნელობა ადგილზე, გამოტოვოთ ადგილობრივი და გადაადგილდეს.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // ჩვენ ყოველთვის შეგვიძლია გადავწეროთ ადგილზე, ადგილობრივი მნიშვნელობის გარეშე.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}