//! მაჩვენებლის ტიპი გროვების გამოყოფისთვის.
//!
//! [`Box<T>`], შემთხვევით მოიხსენიება როგორც 'box', უზრუნველყოფს გროვების განაწილების უმარტივეს ფორმას Rust-ში.ყუთები უზრუნველყოფს ამ განაწილების მფლობელობას და მათ შინაარსს ყრიან, როდესაც ისინი ფარგლებს გარეთ გადიან.ყუთები ასევე უზრუნველყოფს, რომ ისინი არასოდეს გამოყოფენ `isize::MAX` ბაიტზე მეტს.
//!
//! # Examples
//!
//! [`Box`]-ის შექმნით მნიშვნელობიდან დასტის გროვაში გადატანა:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! გადააადგილეთ მნიშვნელობა [`Box`]-დან დასტისკენ [dereferencing]-ით:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! რეკურსიული მონაცემთა სტრუქტურის შექმნა:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! ეს დაბეჭდავს `Cons (1, Cons(2, Nil))`.
//!
//! რეკურსიული სტრუქტურები უნდა იყოს უჯრაში, რადგან თუ `Cons`-ის განმარტება ასე გამოიყურება:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! არ გამოდგებოდა.ეს იმიტომ ხდება, რომ `List` ზომა დამოკიდებულია იმაზე, თუ რამდენი ელემენტია სიაში, და ამიტომ ჩვენ არ ვიცით რამდენი მეხსიერება უნდა გამოყოს `Cons`- სთვის.[`Box<T>`]-ის შემოღებით, რომელსაც აქვს განსაზღვრული ზომა, ჩვენ ვიცით, თუ რამდენად დიდი უნდა იყოს `Cons`.
//!
//! # მეხსიერების განლაგება
//!
//! ნულოვანი ზომის მნიშვნელობებისთვის, [`Box`] გამოიყენებს [`Global`] გამანაწილებელს მისი გამოყოფისთვის.მართებულია ორივე გზით გადაიყვანოთ [`Box`] და [`Global`] გამანაწილებელთან გამოყოფილი ნედლი მაჩვენებელი, იმის გათვალისწინებით, რომ გამანაწილებელთან ერთად გამოყენებული [`Layout`] სწორია ტიპისთვის.
//!
//! უფრო ზუსტად, `value:*mut T`, რომელიც გამოყოფილია [`Global`] გამანაწილებელით `Layout::for_value(&* value)`- ით, შეიძლება გადაკეთდეს ყუთში [`Box::<T>::from_raw(value)`]- ის გამოყენებით.
//! პირიქით, [`Box::<T>::into_raw`]- ისგან მიღებული `value: *mut T` მეხსიერების მხარდაჭერილი მეხსიერება შეიძლება გადანაწილდეს X003- ით [`Global`] გამანაწილებლის გამოყენებით.
//!
//! ნულოვანი ზომის მნიშვნელობებისთვის, `Box` მაჩვენებელი მაინც უნდა იყოს [valid] წაკითხვისა და წერისთვის და საკმარისად გასწორებული.
//! კერძოდ, ნულოვანი მაჩვენებლისთვის ნებისმიერი გასწორებული არა-ნულოვანი მთელი რიცხვის პირდაპირი მნიშვნელობით გამოცემა წარმოშობს მართებულ მაჩვენებელს, მაგრამ ის მაჩვენებელი, რომელიც მიუთითებს ადრე გამოყოფილ მეხსიერებაში, რომელიც გათავისუფლდა, არასწორია.
//! თუ Z0-ში ყუთის აგების რეკომენდებული გზაა, თუ `Box::new` არ შეიძლება გამოყენებულ იქნას [`ptr::NonNull::dangling`]-ის გამოყენება.
//!
//! სანამ `T: Sized`, `Box<T>` გარანტირებული იქნება, როგორც ერთი მაჩვენებელი და ასევე ABI- თავსებადი C მითითებით (მაგ. C ტიპის `T*`).
//! ეს ნიშნავს, რომ თუ თქვენ გაქვთ გარე "C" Rust ფუნქციები, რომლებიც გამოძახებული იქნება C-დან, შეგიძლიათ განსაზღვროთ ეს Rust ფუნქციები `Box<T>` ტიპების გამოყენებით და გამოიყენოთ `T*`, როგორც შესაბამისი ტიპი C მხარეს.
//! მაგალითად, განვიხილოთ ეს C სათაური, რომელიც აცხადებს ფუნქციებს, რომლებიც ქმნიან და ანადგურებენ რაიმე სახის `Foo` მნიშვნელობას:
//!
//! ```c
//! /* C სათაური */
//!
//! /* აბრუნებს მფლობელობას მფლობელს */
//! struct Foo* foo_new(void);
//!
//! /* იღებს საკუთრებას აბონენტისგან;no-op, როდესაც გამოძახებულია NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! ეს ორი ფუნქცია შეიძლება განხორციელდეს Rust- ში შემდეგნაირად.აქ `struct Foo*` ტიპი C-დან ითარგმნება `Box<Foo>`-ზე, რომელიც ასახავს საკუთრების შეზღუდვებს.
//! გაითვალისწინეთ ისიც, რომ `foo_delete`-ის არასასურველი არგუმენტი წარმოდგენილია Rust-ში, როგორც `Option<Box<Foo>>`, რადგან `Box<Foo>` არ შეიძლება იყოს null.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! მიუხედავად იმისა, რომ `Box<T>` აქვს იგივე წარმომადგენლობა და C ABI, როგორც C მაჩვენებელი, ეს არ ნიშნავს, რომ შეგიძლიათ შეცვალოთ თვითნებური `T*` `Box<T>` და ველით, რომ რამე იმუშავებს.
//! `Box<T>` მნიშვნელობები ყოველთვის იქნება სრულად გასწორებული, არასამთავრობო ნულოვანი მითითებით.უფრო მეტიც, `Box<T>`-ის გამანადგურებელი შეეცდება ღირებულების განთავისუფლებას გლობალური გამანაწილებლის საშუალებით.ზოგადად, საუკეთესო პრაქტიკაა გამოიყენოს მხოლოდ `Box<T>` მითითებებისთვის, რომლებიც წარმოიშვა გლობალური გამანაწილებელიდან.
//!
//! **მნიშვნელოვანია.** ამჟამად, თავიდან უნდა აიცილოთ `Box<T>` ტიპის გამოყენება იმ ფუნქციებისთვის, რომლებიც განსაზღვრულია C- ით, მაგრამ გამოძახებულია Rust- დან.ასეთ შემთხვევებში, თქვენ მაქსიმალურად მჭიდროდ უნდა ასახოთ C ტიპები.
//! `Box<T>` მსგავსი ტიპების გამოყენებამ, სადაც C განსაზღვრება მხოლოდ `T*`-ს გამოყენებაა, შეიძლება გამოიწვიოს განუსაზღვრელი ქცევა, როგორც ეს აღწერილია [rust-lang/unsafe-code-guidelines#198][ucg#198]-ში.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// მაჩვენებლის ტიპი გროვების გამოყოფისთვის.
///
/// იხილეთ [module-level documentation](../../std/boxed/index.html) მეტი.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// გამოყოფს მეხსიერებას გროვზე და შემდეგ ათავსებს `x` მასში.
    ///
    /// ეს სინამდვილეში არ გამოყოფს, თუ `T` არის ნულოვანი ზომის.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// აშენებს ახალ ველს არაინციალიზებული შინაარსებით.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// აშენებს ახალ `Box` არაინიციალიზებულ შინაარსს, მეხსიერება ივსება `0` ბაიტით.
    ///
    ///
    /// იხილეთ [`MaybeUninit::zeroed`][zeroed] ამ მეთოდის სწორი და არასწორი გამოყენების მაგალითებისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// აშენებს ახალ `Pin<Box<T>>`-ს.
    /// თუ `T` არ განახორციელებს `Unpin`-ს, მაშინ `x` დამაგრდება მეხსიერებაში და მისი გადაადგილება შეუძლებელია.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// გამოყოფს მეხსიერებას გროვზე, შემდეგ ათავსებს `x` მასში და უბრუნებს შეცდომას, თუ გამოყოფა ვერ ხერხდება
    ///
    ///
    /// ეს სინამდვილეში არ გამოყოფს, თუ `T` არის ნულოვანი ზომის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// აშენებს ახალ ველს არაინციალიზებული შინაარსით გროვაზე, ანაზღაურება ვერ მოხერხდება, თუ გამოყოფა ვერ მოხერხდება
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// აშენებს ახალ `Box` არაინციალიზებულ შინაარსს, მეხსიერება ივსება `0` ბაიტით გროვაში
    ///
    ///
    /// იხილეთ [`MaybeUninit::zeroed`][zeroed] ამ მეთოდის სწორი და არასწორი გამოყენების მაგალითებისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// გამოყოფს მეხსიერებას მოცემულ გამანაწილებელში, შემდეგ ათავსებს `x` მასში.
    ///
    /// ეს სინამდვილეში არ გამოყოფს, თუ `T` არის ნულოვანი ზომის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// გამოყოფს მეხსიერებას მოცემულ გამანაწილებელში, შემდეგ ათავსებს `x` მასში და უბრუნებს შეცდომას, თუ გამოყოფა ვერ ხერხდება
    ///
    ///
    /// ეს სინამდვილეში არ გამოყოფს, თუ `T` არის ნულოვანი ზომის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// აშენებს ახალ ველს არაინციალიზებული შინაარსებით მოწოდებულ გამანაწილებელში.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: უპირატესობა მატჩს გადააადგილეთ ვიდრე unwrap_or_else, რადგან დახურვა ზოგჯერ არ არის ამოკვეთილი.
        // ამით კოდის ზომა უფრო დიდი გახდება.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// აშენებს ახალ ველს არაინციალიზებული შინაარსებით მოწოდებულ გამანაწილებელში, თუ გამოყოფას ვერ ახერხებს, უბრუნებს შეცდომას
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// აშენებს ახალ `Box` არაინიციალიზირებული შინაარსის მქონე მეხსიერებით, რომელიც მოცემულ გამანაწილებელში ივსება `0` ბაიტით.
    ///
    ///
    /// იხილეთ [`MaybeUninit::zeroed`][zeroed] ამ მეთოდის სწორი და არასწორი გამოყენების მაგალითებისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: უპირატესობა მატჩს გადააადგილეთ ვიდრე unwrap_or_else, რადგან დახურვა ზოგჯერ არ არის ამოკვეთილი.
        // ამით კოდის ზომა უფრო დიდი გახდება.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// აშენებს ახალ `Box` არაინციალიზებულ შინაარსს, მეხსიერებაში ივსება `0` ბაიტი მოცემულ გამანაწილებელში, ანაზღაურება ვერ ხერხდება,
    ///
    ///
    /// იხილეთ [`MaybeUninit::zeroed`][zeroed] ამ მეთოდის სწორი და არასწორი გამოყენების მაგალითებისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// აშენებს ახალ `Pin<Box<T, A>>`-ს.
    /// თუ `T` არ განახორციელებს `Unpin`-ს, მაშინ `x` დამაგრდება მეხსიერებაში და მისი გადაადგილება შეუძლებელია.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>`-ს გარდაქმნის `Box<[T]>`-ში
    ///
    /// ეს გარდაქმნა არ არის განაწილებული გროვაში და ხდება ადგილზე.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// მოიხმარს `Box`-ს, დააბრუნებს შეფუთულ მნიშვნელობას.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// აშენებს ახალ კოლოფულ ნაჭერს არაინციალიზებული შინაარსით.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// აშენებს ახალ კოლოფულ ნაჭერს არაინიციალიზებული შინაარსით, მეხსიერება ივსება `0` ბაიტით.
    ///
    ///
    /// იხილეთ [`MaybeUninit::zeroed`][zeroed] ამ მეთოდის სწორი და არასწორი გამოყენების მაგალითებისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// აშენებს ახალ კოლოფულ ნაჭერს არაინციალიზებული შინაარსით გათვალისწინებულ ალაგატორში.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// აშენებს ახალ ყუთში ნაჭერს არაინიციალიზირებული შინაარსებით მოწოდებულ გამანაწილებელში, მეხსიერება ივსება `0` ბაიტით.
    ///
    ///
    /// იხილეთ [`MaybeUninit::zeroed`][zeroed] ამ მეთოდის სწორი და არასწორი გამოყენების მაგალითებისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// გადადის `Box<T, A>`-ზე.
    ///
    /// # Safety
    ///
    /// როგორც [`MaybeUninit::assume_init`]- ს შემთხვევაში, აბონენტის გადასაწყვეტია, რომ ღირებულება ნამდვილად არის თავდაპირველ მდგომარეობაში.
    ///
    /// ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს დაუყოვნებლივ გაურკვეველ ქცევას.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// გადადის `Box<[T], A>`-ზე.
    ///
    /// # Safety
    ///
    /// როგორც [`MaybeUninit::assume_init`]- ზე, აბონენტს ევალება გარანტია, რომ მნიშვნელობები ნამდვილად არის თავდაპირველ მდგომარეობაში.
    ///
    /// ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს დაუყოვნებლივ გაურკვეველ ქცევას.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// აშენებს ყუთს ნედლეული მაჩვენებლისგან.
    ///
    /// ამ ფუნქციის გამოძახების შემდეგ, ნედლეული მაჩვენებლის მფლობელობაშია მიღებული `Box`.
    /// კერძოდ, `Box` დესტრუქტორი გამოიძახებს `T` გამანადგურებელს და გაათავისუფლებს გამოყოფილ მეხსიერებას.
    /// იმისათვის, რომ ეს უსაფრთხო იყოს, მეხსიერება უნდა იყოს გამოყოფილი `Box`- ის მიერ გამოყენებული [memory layout]- ის შესაბამისად.
    ///
    ///
    /// # Safety
    ///
    /// ეს ფუნქცია არ არის უსაფრთხო, რადგან არასათანადო გამოყენებამ შეიძლება მეხსიერების პრობლემები გამოიწვიოს.
    /// მაგალითად, ორმაგი თავისუფალი შეიძლება მოხდეს, თუ ფუნქცია ორჯერ გამოიძახება იმავე ნედლეულ მაჩვენებელზე.
    ///
    /// უსაფრთხოების პირობები აღწერილია [memory layout] განყოფილებაში.
    ///
    /// # Examples
    ///
    /// ხელახლა შექმენით `Box`, რომელიც ადრე გადაკეთდა ნედლეული მაჩვენებლით [`Box::into_raw`]- ის გამოყენებით:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// ხელით შექმენით `Box` ნულიდან გლობალური გამანაწილებლის გამოყენებით:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // ზოგადად, .write საჭიროა, რათა თავიდან აიცილოთ `ptr`- ის (uninitialized) წინა შინაარსის განადგურების მცდელობა, თუმცა ამ მარტივი მაგალითისთვის `*ptr = 5` ასევე იმუშავებდა.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// მოცემულ გამანაწილებელში აშენებს ყუთს ნედლი მაჩვენებლისგან.
    ///
    /// ამ ფუნქციის გამოძახების შემდეგ, ნედლეული მაჩვენებლის მფლობელობაშია მიღებული `Box`.
    /// კერძოდ, `Box` დესტრუქტორი გამოიძახებს `T` გამანადგურებელს და გაათავისუფლებს გამოყოფილ მეხსიერებას.
    /// იმისათვის, რომ ეს უსაფრთხო იყოს, მეხსიერება უნდა იყოს გამოყოფილი `Box`- ის მიერ გამოყენებული [memory layout]- ის შესაბამისად.
    ///
    ///
    /// # Safety
    ///
    /// ეს ფუნქცია არ არის უსაფრთხო, რადგან არასათანადო გამოყენებამ შეიძლება მეხსიერების პრობლემები გამოიწვიოს.
    /// მაგალითად, ორმაგი თავისუფალი შეიძლება მოხდეს, თუ ფუნქცია ორჯერ გამოიძახება იმავე ნედლეულ მაჩვენებელზე.
    ///
    /// # Examples
    ///
    /// ხელახლა შექმენით `Box`, რომელიც ადრე გადაკეთდა ნედლეული მაჩვენებლით [`Box::into_raw_with_allocator`]- ის გამოყენებით:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// ხელით შექმენით `Box` ნულიდან სისტემის გამანაწილებლის გამოყენებით:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // ზოგადად, .write საჭიროა, რათა თავიდან აიცილოთ `ptr`- ის (uninitialized) წინა შინაარსის განადგურების მცდელობა, თუმცა ამ მარტივი მაგალითისთვის `*ptr = 5` ასევე იმუშავებდა.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// მოიხმარს `Box`-ს, უბრუნებს შეფუთულ ნედლეულ მაჩვენებელს.
    ///
    /// მაჩვენებელი იქნება სწორად გასწორებული და არაა ნულოვანი.
    ///
    /// ამ ფუნქციის გამოძახების შემდეგ, აბონენტი პასუხისმგებელია მეხსიერებაზე, რომელსაც ადრე მართავდა `Box`.
    /// კერძოდ, აბონენტმა უნდა გაანადგუროს `T` და გაათავისუფლოს მეხსიერება, იმის გათვალისწინებით, რომ X002 იყენებს `Box`.
    /// ამის უმარტივესი გზაა ნედლეული მაჩვენებლის [`Box::from_raw`] ფუნქციით `Box`- ში გადაკეთება, რაც `Box` დესტრუქტორს საშუალებას აძლევს გაასუფთავოს.
    ///
    ///
    /// Note: ეს არის ასოცირებული ფუნქცია, რაც ნიშნავს, რომ თქვენ მას `Box::into_raw(b)`- ის ნაცვლად უნდა უწოდოთ `Box::into_raw(b)`.
    /// ეს ხდება ისე, რომ შინაგან ტიპზე არ არსებობს რაიმე წინააღმდეგობა მეთოდთან.
    ///
    /// # Examples
    /// ნედლეული მაჩვენებლის [`Box::from_raw`]- ით [`Box::from_raw`] ავტომატური გაწმენდისთვის გადაკეთება:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// ხელით გაწმენდა დესტრუქტორის აშკარად გაშვებით და მეხსიერების დელოკაციით.
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// მოიხმარს `Box`-ს, დააბრუნებს შეფუთულ ნედლეულ მაჩვენებელს და გამყოფს.
    ///
    /// მაჩვენებელი იქნება სწორად გასწორებული და არაა ნულოვანი.
    ///
    /// ამ ფუნქციის გამოძახების შემდეგ, აბონენტი პასუხისმგებელია მეხსიერებაზე, რომელსაც ადრე მართავდა `Box`.
    /// კერძოდ, აბონენტმა უნდა გაანადგუროს `T` და გაათავისუფლოს მეხსიერება, იმის გათვალისწინებით, რომ X002 იყენებს `Box`.
    /// ამის უმარტივესი გზაა ნედლეული მაჩვენებლის [`Box::from_raw_in`] ფუნქციით `Box`- ში გადაკეთება, რაც `Box` დესტრუქტორს საშუალებას აძლევს გაასუფთავოს.
    ///
    ///
    /// Note: ეს არის ასოცირებული ფუნქცია, რაც ნიშნავს, რომ თქვენ მას `Box::into_raw_with_allocator(b)`- ის ნაცვლად უნდა უწოდოთ `Box::into_raw_with_allocator(b)`.
    /// ეს ხდება ისე, რომ შინაგან ტიპზე არ არსებობს რაიმე წინააღმდეგობა მეთოდთან.
    ///
    /// # Examples
    /// ნედლეული მაჩვენებლის [`Box::from_raw_in`]- ით [`Box::from_raw_in`] ავტომატური გაწმენდისთვის გადაკეთება:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// ხელით გაწმენდა დესტრუქტორის აშკარად გაშვებით და მეხსიერების დელოკაციით.
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // ყუთი Stacked Borrows- ს მიერ აღიარებულია როგორც "unique pointer", მაგრამ შინაგანად ის წარმოადგენს ტიპის სისტემის ნედლეულს.
        // მისი პირდაპირ ნედლ მაჩვენებლად გადაქცევა არ იქნება აღიარებული, როგორც "releasing" უნიკალური მაჩვენებელი, რომელიც საშუალებას იძლევა ნებადართული იყოს ნედლეული წვდომა, ამიტომ მაჩვენებლის ყველა ნედლეულის მეთოდი უნდა გაიაროს `Box::leak`.
        //
        // * * ის ნედლ მაჩვენებელზე გადაქცევა სწორად იქცევა.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// აბრუნებს მითითებას ძირეულ გამყოფზე.
    ///
    /// Note: ეს არის ასოცირებული ფუნქცია, რაც ნიშნავს, რომ თქვენ მას `Box::allocator(&b)`- ის ნაცვლად უნდა უწოდოთ `Box::allocator(&b)`.
    /// ეს ხდება ისე, რომ შინაგან ტიპზე არ არსებობს რაიმე წინააღმდეგობა მეთოდთან.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// მოიხმარს და გაჟონავს `Box`-ს, უბრუნებს ცვალებად მითითებას, `&'a mut T`.
    /// გაითვალისწინეთ, რომ ტიპი `T` უნდა აღემატებოდეს არჩეული სიცოცხლის ხანგრძლივობას `'a`.
    /// თუ ტიპს აქვს მხოლოდ სტატიკური ცნობარი, ან საერთოდ არ აქვს, მაშინ ეს შეიძლება იყოს არჩეული `'static`.
    ///
    /// ეს ფუნქცია ძირითადად გამოსადეგია იმ მონაცემებისთვის, რომლებიც სიცოცხლის ბოლომდე ცხოვრობს.
    /// დაბრუნებული მითითების ვარდნა მეხსიერების გაჟონვას გამოიწვევს.
    /// თუ ეს არ არის მისაღები, მითითება პირველ რიგში უნდა შეივსოს [`Box::from_raw`] ფუნქციით, რომელიც აწარმოებს `Box`.
    ///
    /// ამის შემდეგ შეიძლება ჩამოაგდონ ეს `Box`, რაც სწორად გაანადგურებს `T` და გამოყოფს გამოყოფილ მეხსიერებას.
    ///
    /// Note: ეს არის ასოცირებული ფუნქცია, რაც ნიშნავს, რომ თქვენ მას `Box::leak(b)`- ის ნაცვლად უნდა უწოდოთ `Box::leak(b)`.
    /// ეს ხდება ისე, რომ შინაგან ტიპზე არ არსებობს რაიმე წინააღმდეგობა მეთოდთან.
    ///
    /// # Examples
    ///
    /// მარტივი გამოყენება:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// დიდი ზომის მონაცემები:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>`-ს გარდაქმნის `Pin<Box<T>>`-ში
    ///
    /// ეს გარდაქმნა არ არის განაწილებული გროვაში და ხდება ადგილზე.
    ///
    /// ეს ასევე ხელმისაწვდომია [`From`] მეშვეობით.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // შეუძლებელია `Pin<Box<T>>`- ის შიდა ნაწილების გადაადგილება ან შეცვლა `T: !Unpin`- ზე, ამიტომ უსაფრთხოა მისი პირდაპირ დამაგრება დამატებითი მოთხოვნების გარეშე.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: არაფრის გაკეთება, ჩამოვარდნას ამჟამად ასრულებს შემდგენელი.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// ქმნის `Box<T>`-ს, `Default` მნიშვნელობით T-სთვის.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// აბრუნებს ახალ ყუთს ამ ყუთის შინაარსით `clone()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // მნიშვნელობა იგივეა
    /// assert_eq!(x, y);
    ///
    /// // მაგრამ ისინი უნიკალური ობიექტებია
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // წინასწარ გამოყავით მეხსიერება, რომ მოხდეს კლონირებული მნიშვნელობის პირდაპირ ჩაწერა.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// `წყაროს contents შინაარსს ასლის `self`-ში ახალი განაწილების შექმნის გარეშე.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // მნიშვნელობა იგივეა
    /// assert_eq!(x, y);
    ///
    /// // და გამოყოფა არ მომხდარა
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // ეს ქმნის მონაცემთა ასლს
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// `T` ზოგად ტიპს გარდაქმნის `Box<T>`-ად
    ///
    /// გარდაქმნა გამოიყოფა გროვაზე და გადააქვს `t` დასტიდან მასში.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>`-ს გარდაქმნის `Pin<Box<T>>`-ში
    ///
    /// ეს გარდაქმნა არ არის განაწილებული გროვაში და ხდება ადგილზე.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]`-ს გარდაქმნის `Box<[T]>`-ში
    ///
    /// ეს გარდაქმნა გამოიყოფა გროვაზე და ასრულებს `slice` ასლს.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // შექმენით&[u8], რომელიც გამოყენებული იქნება ყუთი <[u8]>-ის შესაქმნელად
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str`-ს გარდაქმნის `Box<str>`-ში
    ///
    /// ეს გარდაქმნა გამოიყოფა გროვაზე და ასრულებს `s` ასლს.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>`-ს გარდაქმნის `Box<[u8]>`-ში
    /// ეს გარდაქმნა არ არის განაწილებული გროვაში და ხდება ადგილზე.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // შექმნა Box<str>რომელიც გამოყენებული იქნება Box <[u8]>-ის შესაქმნელად
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // შექმენით&[u8], რომელიც გამოყენებული იქნება ყუთი <[u8]>-ის შესაქმნელად
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]`-ს გარდაქმნის `Box<[T]>`-ში
    /// ეს გარდაქმნა მასივს გადააქვს ახლად გამოყოფილ მეხსიერებაში.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// ყუთის ჩამოსხმის მცდელობა ბეტონის ტიპზე.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// ყუთის ჩამოსხმის მცდელობა ბეტონის ტიპზე.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// ყუთის ჩამოსხმის მცდელობა ბეტონის ტიპზე.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // შეუძლებელია შიდა Uniq- ის მოპოვება პირდაპირ ყუთიდან, სამაგიეროდ ჩვენ მას ვაძლევთ * კონსტს, რომელიც მეტსახელად უნიკალურს წარმოადგენს
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// სპეციალიზაცია ზომის `I-ისთვის, რომელიც ნაგულისხმევის ნაცვლად იყენებს` I-ს `last()` დანერგვას.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}