use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// იტერატორი, რომელიც იყენებს დახურვას, რათა დაადგინოს, უნდა ამოიღონ თუ არა ელემენტი.
///
/// ამ სტრუქტურას ქმნის [`Vec::drain_filter`].
/// იხილეთ მეტი მისი დოკუმენტაცია.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// იმ ნივთის ინდექსი, რომელსაც გადაამოწმებს შემდეგი ზარი `next`-ზე.
    pub(super) idx: usize,
    /// ჯერჯერობით (removed) გადინებული ნივთების რაოდენობა.
    pub(super) del: usize,
    /// `vec`- ის თავდაპირველი სიგრძე დრენაჟამდე.
    pub(super) old_len: usize,
    /// ფილტრის ტესტის პრედიკატი.
    pub(super) pred: F,
    /// დროშა, რომელიც მიუთითებს panic, მოხდა ფილტრის ტესტის წინასწარმეტყველებაში.
    /// ეს გამოიყენება, როგორც მინიშნება წვეთის დანერგვისას, `DrainFilter`- ის დარჩენილი ნაწილის მოხმარების თავიდან ასაცილებლად.
    /// ნებისმიერი დაუმუშავებელი ელემენტი უკანა გზით შეიცვლება `vec`-ში, მაგრამ ფილტრის მტკიცებულების მიერ აღარ დაეცემა ან ტესტირდება შემდგომი საგნები.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// აბრუნებს მითითებას ძირეულ გამყოფზე.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // განაახლეთ ინდექსი * მას შემდეგ, რაც ეწოდება პრედიკატი.
                // თუ ინდექსის განახლება მოხდება წინასწარ და წინააღმდეგი panics, ამ ინდექსის ელემენტის გაჟონვა მოხდება.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // ეს საკმაოდ არეულ მდგომარეობაშია და აშკარად სწორი საქმე ნამდვილად არ არის.
                        // ჩვენ არ გვინდა, რომ განვაგრძოთ `pred`- ის შესრულება, ამიტომ ჩვენ ყველა გადაუმუშავებელ ელემენტს გადავაბრუნებთ და ვექციას ვუწოდებთ, რომ ისინი კვლავ არსებობენ.
                        //
                        // უკუსვლის გადაადგილება საჭიროა, რომ თავიდან იქნას აცილებული ბოლო წარმატებით გაჟღენთილი ნივთის ორმაგად ვარდნა, ვიდრე წინა ზონაში panic არ არის.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // დარჩენილი ელემენტების მოხმარების მცდელობა, თუ ფილტრის მტკიცებულება ჯერ კიდევ არ არის პანიკა.
        // ჩვენ გადავაბრუნებთ ყველა დანარჩენ ელემენტს, მიუხედავად იმისა, რომ უკვე პანიკა შეგვიქმნა თუ მოხმარება აქ panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}