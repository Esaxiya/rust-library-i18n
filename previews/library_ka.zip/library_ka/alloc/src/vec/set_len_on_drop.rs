// დააყენეთ vec-ის სიგრძე, როდესაც `SetLenOnDrop` მნიშვნელობა არ გამოვა.
//
// იდეა არის: SetLenOnDrop-ის სიგრძის ველი არის ადგილობრივი ცვლადი, რომელსაც ოპტიმიზატორი დაინახავს, არ ეკუთვნის სხვა მაღაზიებს Vec-ის მონაცემთა მაჩვენებლის საშუალებით.
// ეს არის გადაჭრის გზები, რომელიც მეტსახელად აანალიზებს #32155 საკითხს
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}