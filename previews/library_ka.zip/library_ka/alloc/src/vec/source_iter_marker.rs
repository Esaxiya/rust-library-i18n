use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// იტერატორული მილსადენის Vec-ში შეგროვების სპეციალიზაციის მარკერი წყაროს განაწილების ხელახლა გამოყენებისას, ე.ი.
/// მილსადენის ადგილზე შესრულება.
///
/// SourceIter მშობელი trait აუცილებელია სპეციალიზირების ფუნქციისთვის, გამოყოფისთვის გამოსაყენებლად, რომელიც უნდა გამოვიყენოთ.
/// მაგრამ არ არის საკმარისი სპეციალობის მოქმედება.
/// იხილეთ დამატებითი საზღვრები impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-შიდა SourceIter/InPlaceIterable traits ხორციელდება მხოლოდ ადაპტერის ჯაჭვებით <Adapter<Adapter<IntoIter>>> (ყველა საკუთრებაშია core/std).
// ადაპტერის დანერგვის დამატებითი საზღვრები (`impl<I: Trait> Trait for Adapter<I>`- ს მიღმა) მხოლოდ სხვა traits- ზეა დამოკიდებული, რომელიც უკვე მონიშნულია როგორც traits სპეციალიზაცია (ასლი, TrustedRandomAccess, FusedIterator).
//
// I.e. მარკერი არ არის დამოკიდებული მომხმარებლის მიერ მოწოდებული ტიპის სიცოცხლეზე.მოდულის ასლის ნახვრეტი, რომელზეც უკვე რამდენიმე სხვა სპეციალიზაციაა დამოკიდებული.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // დამატებითი მოთხოვნები, რომელთა გამოხატვა შეუძლებელია trait bounds.სამაგიეროდ, ჩვენ ვენდობით კონსტალტს:
        // ა) არავითარი ZST, რადგან არ იქნებოდა გამოყოფილი განმეორებით გამოსაყენებლად და მაჩვენებლის არითმეტიკა იქნებოდა panic ბ) ზომის თანხვედრა, როგორც ამას მოითხოვს Alloc ხელშეკრულება; გ) გასწორება ემთხვევა Alloc ხელშეკრულების მოთხოვნებს
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // უფრო ზოგადი დანერგვების დაბრუნება
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // გამოიყენეთ try-fold წლიდან
        // - ის უკეთესად ვექტორიზირდება ზოგიერთ იტერატორულ ადაპტერზე
        // - შინაგანი გამეორების მეთოდების უმეტესობისგან განსხვავებით, ის მხოლოდ &mut სჭირდება
        // - ის საშუალებას გვაძლევს ჩავწეროთ წერის მაჩვენებელი მისი შიგნით და ბოლოს მივიღოთ იგი
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // იტერაციამ წარმატებით ჩაიარა, თავი არ დაანებოთ
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // შეამოწმეთ, იყო თუ არა დაცული SourceIter კონტრაქტი, თუ ეს არ იყო, შეიძლება ამ ეტაპზე ვერც კი მივაღწიოთ
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // შეამოწმეთ InPlaceIterable ხელშეკრულება.ეს შესაძლებელია მხოლოდ იმ შემთხვევაში, თუ iterator-მა საერთოდ დააწინაურა წყარო მაჩვენებელი.
        // თუ იგი TrustedRandomAccess- ის საშუალებით შეუმოწმებელ წვდომას გამოიყენებს, მაშინ წყაროს მაჩვენებელი დარჩება თავდაპირველ პოზიციაში და ჩვენ არ შეგვიძლია გამოვიყენოთ იგი მითითებად
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ჩამოაგდეს დარჩენილი მნიშვნელობები წყაროს კუდიდან, მაგრამ თავიდან ავიცილოთ გამოყოფის ვარდნა, როდესაც IntoIter გადის ფარგლებიდან, თუ ჩამოაგდეს panics, მაშინ ჩვენ ასევე გაჟონავთ dst_buf-ში შეგროვებულ ელემენტებს.
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable კონტრაქტის დაზუსტება შეუძლებელია ზუსტად აქ, ვინაიდან try_fold- ს აქვს ექსკლუზიური მითითება წყაროს მაჩვენებელზე, რისი გაკეთებაც შეგვიძლია, არის შეამოწმეთ არის თუ არა ის დიაპაზონში.
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}