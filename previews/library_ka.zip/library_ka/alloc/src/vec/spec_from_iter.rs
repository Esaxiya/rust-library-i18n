use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// სპეციალიზაცია trait, რომელიც გამოიყენება Vec::from_iter-სთვის
///
/// ## დელეგაციის გრაფიკი:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // ჩვეულებრივი შემთხვევაა vector ფუნქციის გადაცემა, რომელიც დაუყოვნებლივ ხელახლა აგროვებს vector.
        // ამის მოკლე ჩართვა შეგვიძლია, თუ IntoIter საერთოდ არ არის განვითარებული.
        // როდესაც ის დაწინაურდება, ჩვენ შეგვიძლია აგრეთვე გამოვიყენოთ მეხსიერება და გადავიტანოთ მონაცემები წინა მხარეს.
        // ჩვენ ამას მხოლოდ მაშინ ვაკეთებთ, როდესაც მიღებულ Vec-ს არ ექნება უფრო გამოუყენებელი სიმძლავრე, ვიდრე ამის შექმნა ზოგადი FromIterator-ის საშუალებით.
        //
        // ეს შეზღუდვა არ არის მკაცრად საჭირო, რადგან Vec-ის განაწილების ქცევა განზრახ არ არის განსაზღვრული.
        // მაგრამ ეს კონსერვატიული არჩევანია.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // უნდა გადასცეს spec_extend(), რადგან extend() თავად აკისრებს spec_from ცარიელ ვეკებს
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// ეს იყენებს `iterator.as_slice().to_vec()`-ს, ვინაიდან spec_extend-მა უნდა გადადგას მეტი ნაბიჯები საბოლოო სიმძლავრის + სიგრძეზე მსჯელობისთვის და ამით მეტი სამუშაოს შესრულება.
// `to_vec()` პირდაპირ გამოყოფს სწორ თანხას და ზუსტად ავსებს მას.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test)- ით თანდაყოლილი `[T]::to_vec` მეთოდი, რომელიც საჭიროა ამ მეთოდის განსაზღვრისთვის, არ არის ხელმისაწვდომი.
    // ამის ნაცვლად გამოიყენეთ `slice::to_vec` ფუნქცია, რომელიც მხოლოდ cfg(test) NB- ით არის ხელმისაწვდომი, დამატებითი ინფორმაციისთვის იხილეთ slice::hack მოდული slice.rs- ში.
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}