#![stable(feature = "rust1", since = "1.0.0")]

//! ძაფის უსაფრთხო მითითების თვლის მაჩვენებლები.
//!
//! დამატებითი ინფორმაციისთვის იხილეთ [`Arc<T>`][Arc] დოკუმენტაცია.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// რბილი ზღვარი მითითებების ოდენობაზე, რომელიც შეიძლება გაკეთდეს `Arc`- ზე.
///
/// ამ ზღვარს ზემოთ გადასვლა შეწყვეტს თქვენს პროგრამას (თუმცა არა აუცილებლად) _exactly_ `MAX_REFCOUNT + 1` მითითებებით.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer მხარს არ უჭერს მეხსიერების ღობეებს.
// Arc/სუსტი განხორციელებისას ცრუ პოზიტიური ანგარიშების თავიდან ასაცილებლად გამოიყენეთ ატომური დატვირთვები სინქრონიზაციისთვის.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// ძაფის უსაფრთხო მითითების თვლის მაჩვენებელი.'Arc' ნიშნავს 'Atomically Reference Counted'.
///
/// ტიპი `Arc<T>` უზრუნველყოფს საერთო საკუთრებაში `T` ტიპის მნიშვნელობას, რომელიც გამოიყოფა გროვაში.[`clone`][clone]- ზე [`clone`][clone]- ის გამოძახება ქმნის ახალ `Arc` ინსტანციას, რომელიც მიუთითებს იგივე გამოყოფაზე გროვაზე, როგორც წყარო `Arc`, ამასთან იზრდება მითითების რაოდენობა.
/// როდესაც მოცემული გამოყოფის უკანასკნელი `Arc` მაჩვენებელი განადგურებულია, ამ გამოყოფაში შენახული მნიშვნელობა (ხშირად მოიხსენიება როგორც "inner value") ასევე დაეცემა.
///
/// Rust- ში გაზიარებული მითითებები ნაგულისხმევად არ უშვებს მუტაციას და გამონაკლისი არ არის `Arc`: ზოგადად ვერ მიიღებთ mutable მითითებას `Arc`- ის შიგნით.თუ თქვენ გჭირდებათ `Arc`-ის საშუალებით მუტაცია, გამოიყენეთ [`Mutex`][mutex], [`RwLock`][rwlock] ან [`Atomic`][atomic] ტიპის რომელიმე.
///
/// ## ძაფის უსაფრთხოება
///
/// [`Rc<T>`]-ისგან განსხვავებით, `Arc<T>` იყენებს ატომურ ოპერაციებს მისი მითითების დათვლისთვის.ეს ნიშნავს, რომ ის უსაფრთხოა ძაფით.მინუსი ის არის, რომ ატომური მოქმედებები უფრო ძვირია, ვიდრე ჩვეულებრივი მეხსიერების წვდომა.თუ არ გაზიარებთ მინიშნებით დათვლილ გამოყოფებს ძაფებს შორის, გაითვალისწინეთ, რომ გამოიყენოთ [`Rc<T>`] ქვედა ოვერჰედისთვის.
/// [`Rc<T>`] უსაფრთხო ნაგულისხმევია, რადგან შემდგენელი დაიჭერს ძაფებს შორის [`Rc<T>`] გაგზავნის ნებისმიერ მცდელობას.
/// ამასთან, ბიბლიოთეკამ შეიძლება აირჩიოს `Arc<T>`, რათა მომხმარებლებს მეტი მოქნილობა მისცეს.
///
/// `Arc<T>` განახორციელებს [`Send`] და [`Sync`] სანამ `T` განახორციელებს [`Send`] და [`Sync`].
/// რატომ არ შეგიძლიათ ჩაწეროთ ძაფისგან დაცული ტიპი `T` `Arc<T>`-ში, რომ ის უსაფრთხო იყოს ძაფში?თავდაპირველად, ეს შეიძლება ცოტა კონტრ-ინტუიციური იყოს: ბოლოს და ბოლოს, `Arc<T>` ძაფის უსაფრთხოება არ არის?მთავარია ეს: `Arc<T>` ხდის ძაფის დაცვას, რომ მრავალფეროვანია ერთი და იგივე მონაცემები, მაგრამ ის არ უმატებს ძაფის უსაფრთხოებას მის მონაცემებს.
///
/// განვიხილოთ `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] არ არის [`Sync`] და თუ `Arc<T>` ყოველთვის იყო [`Send`], `Arc <` [`RefCell<T>`]`> ასევე იქნებოდა.
/// მაგრამ შემდეგ ჩვენ გვექნება პრობლემა:
/// [`RefCell<T>`] არ არის უსაფრთხო თემა;იგი ადევნებს თვალს სესხების რაოდენობას არაატომური ოპერაციების გამოყენებით.
///
/// დაბოლოს, ეს ნიშნავს, რომ შეიძლება დაგჭირდეთ `Arc<T>` დაწყვილება რაიმე სახის [`std::sync`] ტიპის, ჩვეულებრივ [`Mutex<T>`][mutex].
///
/// ## ციკლის დარღვევა `Weak`- ით
///
/// [`downgrade`][downgrade] მეთოდი შეიძლება გამოყენებულ იქნას არაპატრონე [`Weak`] მაჩვენებლის შესაქმნელად.[`Weak`] მაჩვენებელი შეიძლება იყოს ["განახლება"][განახლება] d `Arc`- ზე, მაგრამ ეს დაუბრუნებს [`None`] თუ გამოყოფაში შენახული მნიშვნელობა უკვე დაეცა.
/// სხვა სიტყვებით რომ ვთქვათ, `Weak` მაჩვენებლები არ ინარჩუნებს მნიშვნელობას გამოყოფის შიგნით;ამასთან, ისინი * ინარჩუნებენ განაწილებას (ღირებულების სარეზერვო მაღაზია).
///
/// ციკლი `Arc` მაჩვენებლებს შორის არასდროს გადანაწილდება.
/// ამ მიზეზით, [`Weak`] გამოიყენება ციკლის შესამტვრევად.მაგალითად, ხე შეიძლება ჰქონდეს ძლიერი `Arc` მაჩვენებლები მშობლიური კვანძებიდან შვილებამდე, და [`Weak`] მითითებები ბავშვებისგან მშობლებისკენ.
///
/// # ცნობები კლონირებისთვის
///
/// არსებული მითითების თვლიანი მაჩვენებლისგან ახალი მითითების შექმნა ხორციელდება `Clone` trait- ის გამოყენებით, რომელიც განხორციელებულია [`Arc<T>`][Arc] და [`Weak<T>`][Weak]- ზე.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // ქვემოთ მოცემული ორი სინტაქსი ექვივალენტურია.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b და foo ყველა Arc არის, რომლებიც მიუთითებენ მეხსიერების ერთსა და იმავე ადგილზე
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` ავტომატურად მიუთითეთ `T` ([`Deref`][deref] trait) საშუალებით, ასე რომ თქვენ შეგიძლიათ დარეკოთ `T` მეთოდებს `Arc<T>` ტიპის მნიშვნელობაზე."T"-ის მეთოდებთან სახელების შეჯახების თავიდან ასაცილებლად, თავად `Arc<T>` მეთოდები ასოცირებული ფუნქციებია, რომლებსაც [fully qualified syntax] იყენებენ:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `რკალი<T>traits- ს იმპლემენტაციას, როგორიცაა `Clone`, ასევე შეიძლება ეწოდოს სრულად კვალიფიციური სინტაქსის გამოყენებით.
/// ზოგიერთს ურჩევნია გამოიყენოს სრულად კვალიფიციური სინტაქსი, ზოგი კი ამჯობინებს მეთოდის ზარის სინტაქსის გამოყენებას.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // მეთოდი-ზარის სინტაქსი
/// let arc2 = arc.clone();
/// // სრულად კვალიფიციური სინტაქსი
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] არ ახდენს ავტომატური გადამისამართებას `T`- ზე, რადგან შინაგანი მნიშვნელობა შეიძლება უკვე დაეცა.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// ზოგიერთი უცვლელი მონაცემების გაზიარება თემებს შორის:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// გაითვალისწინეთ, რომ ჩვენ **აქ** არ ვატარებთ ამ ტესტებს.
// windows კონსტრუქტორები ძალიან უკმაყოფილონი დარჩებიან, თუ ძაფი აგრძელებს ძირითად ძაფს და შემდეგ ერთდროულად გამოდის (რაღაც ჩიხები), ამიტომ ჩვენ ამას თავიდან ავიცილებთ მთლიანად ამ ტესტების არ ჩატარებით.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// მუტაბელური [`AtomicUsize`]-ის გაზიარება:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// ზოგადად, მითითების დათვლის მეტი მაგალითისთვის იხილეთ [`rc` documentation][rc_examples].
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` არის [`Arc`] ვერსია, რომელიც მართავს გამოყოფას არაკუთვნი მითითებით.
/// განაწილებაზე წვდომაა [`upgrade`] `Weak` მაჩვენებელზე დარეკვით, რომელიც აბრუნებს ["ვარიანტი"] "<" ["Arc"]<T>> "
///
/// ვინაიდან `Weak` მითითება არ ითვლება საკუთრებაში, ეს ხელს არ შეუშლის გამოყოფაში შენახული ღირებულების ვარდნას, ხოლო `Weak` თავად არ იძლევა გარანტიებს ღირებულების არსებობის შესახებ.
///
/// ამრიგად, მას შეუძლია დააბრუნოს [`None`], როდესაც ["განახლება"] დ.
/// ამასთან, გაითვალისწინეთ, რომ `Weak` მითითება * ხელს უშლის გამოყოფის (სარეზერვო მაღაზიის) გადანაწილებას.
///
/// `Weak` მაჩვენებელი სასარგებლოა [`Arc`]-ის მიერ მართული განაწილების დროებითი მითითების შესანარჩუნებლად, მისი შიდა მნიშვნელობის ჩამოშლის თავიდან ასაცილებლად.
/// იგი ასევე გამოიყენება [`Arc`] მაჩვენებლებს შორის ცირკულარული ცნობების თავიდან ასაცილებლად, რადგან ურთიერთსაკუთრების ცნობები არასოდეს იძლევა [`Arc`]-ის ჩაშვების საშუალებას.
/// მაგალითად, ხე შეიძლება ჰქონდეს ძლიერი [`Arc`] მაჩვენებლები მშობლიური კვანძებიდან ბავშვებამდე და `Weak` მითითებები ბავშვებისგან მშობლებამდე.
///
/// `Weak` მაჩვენებლის მოპოვების ტიპიური გზაა [`Arc::downgrade`] დარეკვა.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // ეს არის `NonNull`, რათა ამ ტიპის ზომის ოპტიმიზაცია მოხდეს ციფრებში, მაგრამ ეს სულაც არ არის სწორი მაჩვენებელი.
    //
    // `Weak::new` ადგენს ამას `usize::MAX` ისე, რომ მას არ სჭირდება ადგილის გამოყოფა გროვაში.
    // ეს არ არის ნამდვილი მაჩვენებლის მნიშვნელობა, რადგან RcBox- ს მინიმუმ 2 აქვს გასწორება.
    // ეს შესაძლებელია მხოლოდ მაშინ, როდესაც `T: Sized`;არასაკმარისი `T` არასდროს ირევა.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// ეს არის repr(C)- დან future- მდე დაუშვებელია ველის ხელახალი შეცვლის საწინააღმდეგოდ, რაც ხელს უშლის სხვაგვარად უსაფრთხო [into|from]_raw() ტრანსმუტაციის შიდა ტიპებს.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // მნიშვნელობა usize::MAX მოქმედებს, როგორც დროებითი "locking"-ის მცველი სუსტი მაჩვენებლების განახლების ან ძლიერი მაჩვენებლების დაკნინების შესაძლებლობა;ეს გამოიყენება `make_mut` და `get_mut` შეჯიბრებების თავიდან ასაცილებლად.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// აშენებს ახალ `Arc<T>`-ს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // დაიწყეთ სუსტი მაჩვენებლის რაოდენობა 1-ით, რომელიც არის სუსტი მაჩვენებელი, რომელსაც უჭირავს ყველა ძლიერი მითითება (kinda), იხილეთ std/rc.rs დამატებითი ინფორმაციისთვის
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// აშენებს ახალ `Arc<T>`- ს, საკუთარ თავზე სუსტი მითითების გამოყენებით.
    /// ამ ფუნქციის დაბრუნებამდე სუსტი მითითების განახლების მცდელობა გამოიწვევს `None` მნიშვნელობას.
    /// ამასთან, სუსტი ცნობარი შეიძლება თავისუფლად იყოს კლონირებული და შენახული იქნას გამოყენებისთვის მოგვიანებით.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // ააშენეთ შიდა "uninitialized" მდგომარეობაში ერთი სუსტი მითითებით.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // მნიშვნელოვანია, რომ ჩვენ არ დავთმობთ სუსტი მაჩვენებლის საკუთრებას, თორემ შეიძლება მეხსიერება გათავისუფლდეს `data_fn` დაბრუნების დროს.
        // თუ ჩვენ ნამდვილად გვინდოდა საკუთრების უფლების გადაცემა, შეგვეძლო საკუთარი თავისთვის დამატებითი სუსტი მაჩვენებლის შექმნა, მაგრამ ეს გამოიწვევს სუსტი მითითების რაოდენობის დამატებით განახლებებს, რაც სხვაგვარად შეიძლება არ იყოს საჭირო.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // ახლა ჩვენ შეგვიძლია სწორად დავიწყოთ შინაგანი მნიშვნელობა და ჩვენი სუსტი მითითება ძლიერ მითითებად გადავაქციოთ.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // მონაცემთა ველში ზემოთ ჩაწერილი უნდა იყოს ხილული ნებისმიერი ძაფისთვის, რომლებიც აკვირდებიან არა ნულოვან ძლიერ რიცხვს.
            // ამიტომ ჩვენ მინიმუმ "Release" შეკვეთა გვჭირდება `Weak::upgrade`- ში `compare_exchange_weak`- თან სინქრონიზაციისთვის.
            //
            // "Acquire" შეკვეთა არ არის საჭირო.
            // `data_fn`- ის შესაძლო ქცევის განხილვისას საჭიროა მხოლოდ იმის გარკვევა, თუ რა შეიძლება გააკეთოს მას არა - განახლებადი `Weak`- ით მითითებით:
            //
            // - მას შეუძლია *კლონირება*`Weak`, გაზარდოს სუსტი მითითების რაოდენობა.
            // - მას შეუძლია ჩამოაგდოს ის კლონები, რაც ამცირებს სუსტი მითითების რაოდენობას (მაგრამ არასოდეს ნულამდე).
            //
            // ეს გვერდითი მოვლენები არანაირ გავლენას არ ახდენს ჩვენზე და სხვა უსაფრთხო გვერდითი ეფექტები მხოლოდ უსაფრთხო კოდით არ არის შესაძლებელი.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // ძლიერი ცნობარი ერთობლივად უნდა ფლობდეს საერთო სუსტ მითითებას, ასე რომ ნუ გაუშვებთ გამანადგურებელს ჩვენი ძველი სუსტი ცნობარისთვის.
        //
        mem::forget(weak);
        strong
    }

    /// აშენებს ახალ `Arc`-ს არაინციალიზებული შინაარსებით.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// აშენებს ახალ `Arc` არაინიციალიზებულ შინაარსს, მეხსიერება ივსება `0` ბაიტით.
    ///
    ///
    /// იხილეთ [`MaybeUninit::zeroed`][zeroed] ამ მეთოდის სწორი და არასწორი გამოყენების მაგალითებისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// აშენებს ახალ `Pin<Arc<T>>`-ს.
    /// თუ `T` არ განახორციელებს `Unpin`-ს, მაშინ `data` დამაგრდება მეხსიერებაში და მისი გადაადგილება შეუძლებელია.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// აშენებს ახალ `Arc<T>`-ს, შეცდომას აბრუნებს, თუ გამოყოფა ვერ მოხერხდა.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // დაიწყეთ სუსტი მაჩვენებლის რაოდენობა 1-ით, რომელიც არის სუსტი მაჩვენებელი, რომელსაც უჭირავს ყველა ძლიერი მითითება (kinda), იხილეთ std/rc.rs დამატებითი ინფორმაციისთვის
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// აშენებს ახალ `Arc`-ს არაინციალიზირებული შინაარსის გამოყენებით, ანაზღაურება ვერ მოხერხდება, თუ გამოყოფა ვერ მოხერხდება.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// აშენებს ახალ `Arc` არაინციალიზებულ შინაარსს, მეხსიერება ივსება `0` ბაიტით, ანაზღაურება ვერ მოხერხდება, თუ გამოყოფა შეუძლებელია.
    ///
    ///
    /// იხილეთ [`MaybeUninit::zeroed`][zeroed] ამ მეთოდის სწორი და არასწორი გამოყენების მაგალითებისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// აბრუნებს შინაგან მნიშვნელობას, თუ `Arc`- ს აქვს ზუსტად ერთი ძლიერი მითითება.
    ///
    /// წინააღმდეგ შემთხვევაში, [`Err`] უბრუნდება იმავე `Arc`-ს, რომელიც გაიარა.
    ///
    ///
    /// ეს წარმატებას მიაღწევს მაშინაც კი, თუ არსებობს გამოჩენილი სუსტი ცნობები.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // გააკეთეთ სუსტი მაჩვენებელი, რომ გაიწმინდოს ძლიერი და სუსტი მითითება
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// აშენებს ატომურად მითითებით დათვლილ ნაჭერს არაინციალიზებული შინაარსებით.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// აშენებს ატომურად მითითებით დათვლილ ნაჭერს არაინციალიზირებული შინაარსით, მეხსიერება ივსება `0` ბაიტით.
    ///
    ///
    /// იხილეთ [`MaybeUninit::zeroed`][zeroed] ამ მეთოდის სწორი და არასწორი გამოყენების მაგალითებისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// გადადის `Arc<T>`-ზე.
    ///
    /// # Safety
    ///
    /// როგორც [`MaybeUninit::assume_init`]- ს შემთხვევაში, აბონენტის გადასაწყვეტია, რომ შინაგანი ღირებულება ნამდვილად არის თავდაპირველ მდგომარეობაში.
    ///
    /// ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს დაუყოვნებლივ გაურკვეველ ქცევას.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// გადადის `Arc<[T]>`-ზე.
    ///
    /// # Safety
    ///
    /// როგორც [`MaybeUninit::assume_init`]- ს შემთხვევაში, აბონენტის გადასაწყვეტია, რომ შინაგანი ღირებულება ნამდვილად არის თავდაპირველ მდგომარეობაში.
    ///
    /// ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს დაუყოვნებლივ გაურკვეველ ქცევას.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// მოიხმარს `Arc`-ს, დააბრუნებს გახვეულ კურსორს.
    ///
    /// მეხსიერების გაჟონვის თავიდან ასაცილებლად, მაჩვენებელი უნდა გადაკეთდეს `Arc`- ზე [`Arc::from_raw`]- ის გამოყენებით.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// უზრუნველყოფს მონაცემთა ნედლ მაჩვენებელს.
    ///
    /// დათვლა არანაირად არ მოქმედებს და `Arc` არ არის მოხმარებული.
    /// მაჩვენებელი მოქმედებს მანამ, სანამ `Arc`- ში ძლიერი რაოდენობაა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // უსაფრთხოება: ეს არ შეიძლება გაიაროს Deref::deref ან RcBoxPtr::inner, რადგან
        // ეს საჭიროა raw/mut წარმოშობის შესანარჩუნებლად, რომ მაგ
        // `get_mut` შეუძლია წერა მაჩვენებლის საშუალებით Rc-ის აღდგენის შემდეგ `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// აშენებს `Arc<T>` ნედლეული მაჩვენებლისგან.
    ///
    /// ნედლეული მაჩვენებელი ადრე უნდა დაბრუნდეს [`Arc<U>::into_raw`][into_raw]-ზე დარეკვით, სადაც `U` უნდა ჰქონდეს იგივე ზომა და გასწორება, როგორც `T`.
    /// ეს ტრივიალურად არის მართებული, თუ `U` არის `T`.
    /// გაითვალისწინეთ, რომ თუ `U` არ არის `T`, მაგრამ აქვს იგივე ზომა და გასწორება, ეს ძირითადად ჰგავს სხვადასხვა ტიპის ცნობების ტრანსმუტირებას.
    /// იხილეთ [`mem::transmute`][transmute] დამატებითი ინფორმაციისთვის, თუ რა შეზღუდვები ვრცელდება ამ შემთხვევაში.
    ///
    /// `from_raw` მომხმარებელი უნდა დარწმუნდეს, რომ `T` სპეციფიკური მნიშვნელობა მხოლოდ ერთხელ დაეცა.
    ///
    /// ეს ფუნქცია არ არის უსაფრთხო, რადგან არასათანადო გამოყენებამ შეიძლება გამოიწვიოს მეხსიერების დაუცველობა, მაშინაც კი, თუ დაბრუნებულ `Arc<T>`- ზე არასოდეს შემოდის წვდომა.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // გადაიყვანეთ `Arc`-ზე, რომ არ მოხდეს გაჟონვა.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)`-ზე შემდგომი ზარები მეხსიერებისათვის უსაფრთხო არ იქნება.
    /// }
    ///
    /// // მეხსიერება გათავისუფლდა, როდესაც `x` გავიდა ფარგლებიდან ზემოთ, ამიტომ `x_ptr` ახლა ჩამოკიდებულია!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // შეცვალეთ კომპენსაცია, რათა იპოვოთ ორიგინალი ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// ამ გამოყოფისთვის ქმნის ახალ [`Weak`] მაჩვენებელს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // ეს მოდუნებული კარგადაა, რადგან ჩვენ ვამოწმებთ მნიშვნელობას ქვემოთ მოცემულ CAS-ში.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // შეამოწმეთ არის სუსტი მრიცხველი ამჟამად "locked";თუ ასეა, დატრიალდი.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ეს კოდი ამჟამად უგულებელყოფს გადავსების შესაძლებლობას
            // usize::MAX- ში;ზოგადად, Rc-სა და Arc-ს უნდა მოერგოს, რომ გაუმკლავდეს გადავსებას.
            //

            // Clone()-ისგან განსხვავებით, ეს ჩვენ გვჭირდება Acquire წაკითხვის სინქრონიზაციისთვის, რომელიც მოდის `is_unique`-დან, ისე, რომ ამ წერასთან დაკავშირებული მოვლენები მოხდეს ამ კითხვის წინ.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // დარწმუნდით, რომ ჩვენ არ ვქმნით dangling სუსტს
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// იღებს ამ გამოყოფის [`Weak`] მაჩვენებლების რაოდენობას.
    ///
    /// # Safety
    ///
    /// ეს მეთოდი თავისთავად უსაფრთხოა, მაგრამ მისი სწორად გამოყენება მოითხოვს დამატებით ზრუნვას.
    /// სხვა თემას შეუძლია შეცვალოს სუსტი რაოდენობა ნებისმიერ დროს, მათ შორის პოტენციურად ამ მეთოდის გამოძახებასა და შედეგზე მოქმედებას შორის.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // ეს მტკიცება არის დეტერმინესიული, რადგან ჩვენ არ გვაქვს გაზიარებული `Arc` ან `Weak` ძაფებს შორის.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // თუ სუსტი რიცხვი ამჟამად დაბლოკილია, დათვლის მნიშვნელობა 0 იყო დაბლოკვის აღებამდე.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// იღებს ამ გამოყოფის ძლიერი (`Arc`) მაჩვენებლების რაოდენობას.
    ///
    /// # Safety
    ///
    /// ეს მეთოდი თავისთავად უსაფრთხოა, მაგრამ მისი სწორად გამოყენება მოითხოვს დამატებით ზრუნვას.
    /// სხვა თემას შეუძლია შეცვალოს ძლიერი რაოდენობა ნებისმიერ დროს, მათ შორის პოტენციურად ამ მეთოდის გამოძახებასა და შედეგზე მოქმედებას შორის.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // ეს მტკიცება განსაზღვრულია, რადგან ჩვენ არ გაგვიზიარებია `Arc` ძაფებს შორის.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// `Arc<T>`- ზე ძლიერი მითითების რიცხვის გაზრდა, რომელიც ასოცირდება მოცემულ მაჩვენებელთან, ერთით.
    ///
    /// # Safety
    ///
    /// მაჩვენებელი უნდა იყოს მიღებული `Arc::into_raw`- ის საშუალებით და ასოცირებული `Arc` ინსტანცია უნდა იყოს მართებული (ე.ი.
    /// ძლიერი რაოდენობა უნდა იყოს მინიმუმ 1) ამ მეთოდის განმავლობაში.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ეს მტკიცება განსაზღვრულია, რადგან ჩვენ არ გაგვიზიარებია `Arc` ძაფებს შორის.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // შეინარჩუნეთ Arc, მაგრამ არ შეეხოთ ხელახლა დაანგარიშებას ManualDrop-ში შეფუთვით
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // ახლა გაზრდი თანხას, მაგრამ არც ახალი თანხა ჩამოაგდე
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// ამცირებს ძლიერ მითითებას `Arc<T>`- ზე, რომელიც ასოცირდება მოცემულ მაჩვენებელთან ერთით.
    ///
    /// # Safety
    ///
    /// მაჩვენებელი უნდა იყოს მიღებული `Arc::into_raw`- ის საშუალებით და ასოცირებული `Arc` ინსტანცია უნდა იყოს მართებული (ე.ი.
    /// ძლიერი რაოდენობა უნდა იყოს მინიმუმ 1) ამ მეთოდის გამოყენებისას.
    /// ეს მეთოდი შეიძლება გამოყენებულ იქნას საბოლოო `Arc` და სარეზერვო მეხსიერების გასათავისუფლებლად, მაგრამ ** ** არ უნდა დარეკოთ საბოლოო `Arc` გამოსვლის შემდეგ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ეს მტკიცებები განმსაზღვრელია, რადგან ჩვენ არ გაგვიზიარებია `Arc` ძაფებს შორის.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // ეს უსაფრთხოება კარგადაა, რადგან სანამ ეს რკალი ცოცხალია, ჩვენ გარანტირებულნი ვართ, რომ შიდა მაჩვენებელი ძალაშია.
        // უფრო მეტიც, ჩვენ ვიცით, რომ `ArcInner` სტრუქტურა თავისთავად არის `Sync`, რადგან შინაგანი მონაცემები `Sync` ცაა, ამიტომ ჩვენ ამ შინაარსისთვის უცვლელი მაჩვენებლის სესხის გაცემა გვაქვს.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` არაფუძიანი ნაწილი.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // გაანადგურეთ მონაცემები ამ დროს, მიუხედავად იმისა, რომ ჩვენ არ შეგვიძლია გავათავისუფლოთ ყუთის გამოყოფა (შეიძლება იქ ისევ იყოს სუსტი მითითებები).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // ჩამოაგდეთ სუსტი რეფერატი, რომელიც ყველა მყარ ცნობას შეიცავს
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// აბრუნებს `true`-ს, თუ ორი `Arc` მიუთითებს იმავე განაწილებაზე ([`ptr::eq`]-ის მსგავსი ვენაში).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// გამოყოფს `ArcInner<T>`-ს საკმარისი სივრცის შესაძლო ზომის შიდა მნიშვნელობით, სადაც მნიშვნელობას აქვს განლაგებული.
    ///
    /// ფუნქციას `mem_to_arcinner` ეწოდება მონაცემთა მაჩვენებლის საშუალებით და უნდა დააბრუნოს (პოტენციურად ცხიმიანი) მაჩვენებელი `ArcInner<T>`- სთვის.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // გამოთვალეთ განლაგება მოცემული მნიშვნელობის განლაგების გამოყენებით.
        // მანამდე განლაგება გამოითვლებოდა `&*(ptr as* const ArcInner<T>)` გამოხატვაზე, მაგრამ ამან შექმნა არასწორად მითითებული მითითება (იხ. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// გამოყოფს `ArcInner<T>`-ს საკმარისი სივრცის შესაძლო ზომის შიდა მნიშვნელობისთვის, სადაც მნიშვნელობას აქვს განლაგებული, შეცდომას უბრუნებს გამოყოფის შეუსრულებლობის შემთხვევაში.
    ///
    ///
    /// ფუნქციას `mem_to_arcinner` ეწოდება მონაცემთა მაჩვენებლის საშუალებით და უნდა დააბრუნოს (პოტენციურად ცხიმიანი) მაჩვენებელი `ArcInner<T>`- სთვის.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // გამოთვალეთ განლაგება მოცემული მნიშვნელობის განლაგების გამოყენებით.
        // მანამდე განლაგება გამოითვლებოდა `&*(ptr as* const ArcInner<T>)` გამოხატვაზე, მაგრამ ამან შექმნა არასწორად მითითებული მითითება (იხ. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner-ის ინიციალიზაცია
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// გამოყოფს `ArcInner<T>`- ს, საკმარისი სივრცის გარეშე ზომის შიდა მნიშვნელობით.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // გამოყავით `ArcInner<T>` მოცემული მნიშვნელობის გამოყენებით.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // კოპირება მნიშვნელობით, როგორც ბაიტი
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // გამოყოფის გათავისუფლება მისი შინაარსის ჩაშლის გარეშე
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// გამოყოფს `ArcInner<[T]>` მოცემულ სიგრძეს.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// დააკოპირეთ ელემენტები ნაჭერიდან ახლად გამოყოფილ Arc </[T\]> ში
    ///
    /// არაუსაფრთხოა, რადგან აბონენტმა ან უნდა მიიღოს საკუთრება, ან უნდა დააკავშიროს `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// აშენებს `Arc<[T]>`-ს გარკვეული ზომის იტერატორისგან.
    ///
    /// ქცევა გაურკვეველია, თუ ზომა არასწორია.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic დაცვა T ელემენტების კლონირებისას.
        // panic-ის შემთხვევაში, ახალ ArcInner-ში ჩაწერილი ელემენტები ჩამოიშლება და მეხსიერება გათავისუფლდება.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // მაჩვენებელი პირველ ელემენტზე
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Ყველაფერი გასაგებია.დაივიწყეთ დაცვა, რომ არ გაათავისუფლოს ახალი ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// სპეციალიზაცია trait, რომელიც გამოიყენება `From<&[T]>`-სთვის.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// ქმნის `Arc` მაჩვენებლის კლონს.
    ///
    /// ეს ქმნის სხვა მაჩვენებელს იმავე განაწილებაზე, რაც ზრდის მძლავრი მითითების რაოდენობას.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // მოდუნებული შეკვეთის გამოყენება აქ კარგადაა, რადგან ორიგინალის მითითების ცოდნა ხელს უშლის სხვა ძაფებს ობიექტის შეცდომით წაშლაში.
        //
        // როგორც [Boost documentation][1]- შია ნახსენები, მითითების მრიცხველის გაზრდა ყოველთვის შეიძლება გაკეთდეს memory_order_relaxed- ით: ობიექტის ახალი მითითება შეიძლება ჩამოყალიბდეს მხოლოდ არსებული მითითებიდან და არსებული მითითების ერთი ძაფიდან მეორეზე გადასვლა უკვე საჭირო სინქრონიზაციას ითვალისწინებს.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // ამასთან, ჩვენ უნდა დავიცვათ მასიური თანხების თავიდან აცილების შემთხვევაში, თუ ვინმეს არქმევს Arc?
        // თუ ჩვენ ამას არ გავაკეთებთ, რაოდენობა შეიძლება გადახვიდეს და მომხმარებლები უფასოდ გამოიყენებენ მას შემდეგ.
        // ჩვენ რასობრივად ვიჯერებთ `isize::MAX`-ს იმ ვარაუდით, რომ იქ არ არის ~2 მილიარდი თემა, რომელიც ერთდროულად ზრდის მინიშნების რაოდენობას.
        //
        // ეს branch ვერასოდეს მიიღება რაიმე რეალისტურ პროგრამაში.
        //
        // ჩვენ ვახდენთ აბორტს, რადგან ასეთი პროგრამა წარმოუდგენლად გადაგვარებულია და მისი მხარდაჭერა არ გვაინტერესებს.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// აკეთებს mutable მითითებას მოცემულ `Arc`-ში.
    ///
    /// თუ არსებობს სხვა `Arc` ან [`Weak`] მაჩვენებლები იმავე განაწილებაზე, მაშინ `make_mut` შექმნის ახალ განაწილებას და გამოიყენებს [`clone`][clone] შიდა მნიშვნელობას, უნიკალური საკუთრების უზრუნველსაყოფად.
    /// ამას ასევე უწოდებენ დაწერის კლონს.
    ///
    /// გაითვალისწინეთ, რომ ეს განსხვავდება [`Rc::make_mut`]-ის ქცევისგან, რომელიც აშორებს დანარჩენ `Weak` მითითებას.
    ///
    /// აგრეთვე [`get_mut`][get_mut], რომელიც ვერ მოხერხდება, ვიდრე კლონირება.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // არაფერს კლონირდება
    /// let mut other_data = Arc::clone(&data); // არ მოხდება შინაგანი მონაცემების კლონირება
    /// *Arc::make_mut(&mut data) += 1;         // ახდენს შიდა მონაცემების კლონირებას
    /// *Arc::make_mut(&mut data) += 1;         // არაფერს კლონირდება
    /// *Arc::make_mut(&mut other_data) *= 2;   // არაფერს კლონირდება
    ///
    /// // ახლა `data` და `other_data` მიუთითებს სხვადასხვა განაწილებაზე.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // გაითვალისწინეთ, რომ ჩვენ გვაქვს როგორც ძლიერი, ასევე სუსტი მითითება.
        // ამრიგად, მხოლოდ ჩვენი ძლიერი მითითების გათავისუფლება, თავისთავად, არ გამოიწვევს მეხსიერების დელოკაციას.
        //
        // გამოიყენეთ Acquire, რათა დავრწმუნდეთ, რომ ვხედავთ `weak`-ის წერილებს, რომლებიც ხდება `strong`-ზე გამოქვეყნებამდე დაწერილ წერილობით (ანუ შემცირება)
        // მას შემდეგ, რაც ჩვენ გვაქვს სუსტი რაოდენობა, არანაირი შანსი არ არის, რომ ArcInner-ის დეალოცირება მოხდეს.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // კიდევ ერთი ძლიერი მაჩვენებელი არსებობს, ამიტომ უნდა გავუკეთოთ კლონირება.
            // წინასწარ გამოყავით მეხსიერება, რომ მოხდეს კლონირებული მნიშვნელობის პირდაპირ ჩაწერა.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // ამ ყველაფერში მოდუნებული საკმარისია, რადგან ეს პრინციპულად ოპტიმიზირებულია: ჩვენ ყოველთვის ვიჩქარებთ სუსტი მაჩვენებლების ვარდნას.
            // ყველაზე ცუდი შემთხვევაა, რომ საბოლოოდ ახალი Arc გამოვყავით ზედმეტად.
            //

            // ჩვენ ბოლო ძლიერი საჩივარი ამოვიღეთ, მაგრამ დარჩენილია დამატებითი სუსტი რეფ.
            // ჩვენ გადავიტანთ შინაარსს ახალ Arc-ში და გავაუქმებთ სხვა სუსტ მითითებებს.
            //

            // გაითვალისწინეთ, რომ შეუძლებელია `weak`-ის წაკითხვისას usize::MAX (მაგ., ჩაკეტილი) შედეგი, რადგან სუსტი რიცხვის დაბლოკვა შესაძლებელია მხოლოდ ძაფით, რომელსაც აქვს ძლიერი მითითება.
            //
            //

            // ჩვენი საკუთარი იმპლიციტური სუსტი მაჩვენებლის მატერიალიზება, ისე რომ მას შეუძლია ArcInner გაწმინდოს საჭიროებისამებრ.
            //
            let _weak = Weak { ptr: this.ptr };

            // შეუძლია უბრალოდ მოიპაროს მონაცემები, დარჩენილია მხოლოდ სუსტები
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // ჩვენ ერთადერთი მითითება ვიყავით რომელიმეზე;დაუბრუნეთ ძლიერი რეფ.
            //
            this.inner().strong.store(1, Release);
        }

        // როგორც `get_mut()`- ში, დაუცველობა კარგადაა, რადგან ჩვენი მითითება ან უნიკალური იყო დასაწყისისთვის, ან გახდა შინაარსი კლონირებისთანავე.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// აბრუნებს მუტაბელურ მითითებას მოცემულ `Arc`-ში, თუ არ არსებობს სხვა `Arc` ან [`Weak`] მაჩვენებლები იმავე განაწილებაზე.
    ///
    ///
    /// სხვაგვარად აბრუნებს [`None`]-ს, რადგან გაზიარებული მნიშვნელობის მუტაცია უსაფრთხო არ არის.
    ///
    /// აგრეთვე [`make_mut`][make_mut], რომელიც [`clone`][clone] წარმოადგენს შიდა მნიშვნელობას, როდესაც სხვა მაჩვენებლებია.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // ეს უსაფრთხოება კარგადაა, რადგან გარანტირებული გვაქვს, რომ დაბრუნებული მაჩვენებელი არის *ერთადერთი* მაჩვენებელი, რომელიც ოდესმე დაუბრუნდება T-ს.
            // ამ ეტაპზე ჩვენი მითითების რაოდენობა გარანტირებული იქნება 1 და ჩვენ მოვითხოვეთ რომ Arc უნდა იყოს `mut`, ამიტომ ჩვენ ვუბრუნდებით ერთადერთ შესაძლო მითითებას შიდა მონაცემებზე.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// აბრუნებს მუტაბელურ მითითებას მოცემულ `Arc`- ში, ყოველგვარი შემოწმების გარეშე.
    ///
    /// აგრეთვე [`get_mut`], რომელიც უსაფრთხოა და შესაბამის შემოწმებებს აკეთებს.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// ნებისმიერი სხვა `Arc` ან [`Weak`] მაჩვენებლები იმავე განაწილებაზე არ უნდა იქნეს მითითებული დაბრუნებული სესხის განმავლობაში.
    ///
    /// ეს ტრივიალური შემთხვევაა, თუ ასეთი მაჩვენებლები არ არსებობს, მაგალითად `Arc::new`- ის შემდეგ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // ჩვენ ფრთხილად ვცდილობთ * არ შევქმნათ მითითება, რომელიც მოიცავს "count" ველებს, რადგან ეს იქნება მითითებათა რიცხვზე ერთდროული წვდომის მეტსახელით (მაგ.
        // `Weak`-ის მიერ).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// განსაზღვრეთ არის თუ არა ეს უნიკალური მითითება (მათ შორის სუსტი რეფ.) ძირითადი მონაცემების შესახებ.
    ///
    ///
    /// გაითვალისწინეთ, რომ ეს მოითხოვს დაბლოკვის სუსტი რაოდენობის დაბლოკვას.
    fn is_unique(&mut self) -> bool {
        // ჩაკეტეთ მაჩვენებლის სუსტი რიცხვი, თუ ჩვენ ერთადერთი სუსტი მაჩვენებლის მფლობელი ვართ.
        //
        // აქ შეძენილი ეტიკეტი უზრუნველყოფს `strong`-ს (განსაკუთრებით `Weak::upgrade`-ში) რაიმე წერილობითი ფორმით დამწერლობასთან დაკავშირებული ურთიერთქმედების წინ (X002-ის საშუალებით, რომელიც იყენებს გამოშვებას).
        // თუ განახლებული სუსტი ხაზი არასდროს დაეცა, CAS აქ ვერ მოხერხდება, ამიტომ სინქრონიზაცია არ გვაინტერესებს.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // ეს უნდა იყოს `Acquire`, რომ სინქრონიზირდეს `strong` მრიცხველის შემცირებასთან `drop`- ში-ერთადერთი წვდომა, რაც ხდება, როდესაც რომელიმე ხდება, მაგრამ ბოლო მითითება ხდება.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // აქ გამოშვების სინქრონიზაცია ხდება `downgrade`-ში წაკითხული მასალის გამოყენებით, რაც ეფექტურად უშლის ხელს `strong`- ზე ზემოაღნიშნულ კითხვას ჩაწერის შემდეგ.
            //
            //
            self.inner().weak.store(1, Release); // საკეტი გაათავისუფლე
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// ვარდება `Arc`.
    ///
    /// ეს შეამცირებს ძლიერი მითითების რაოდენობას.
    /// თუ ძლიერი მითითების რაოდენობა ნულს მიაღწევს, მხოლოდ სხვა მითითებები (ასეთის არსებობის შემთხვევაში) არის [`Weak`], ამიტომ ჩვენ `drop` შიდა მნიშვნელობა.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // არაფერს ბეჭდავს
    /// drop(foo2);   // ბეჭდავს "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // იმის გამო, რომ `fetch_sub` უკვე ატომურია, ჩვენ არ გვჭირდება სხვა ძაფებთან სინქრონიზაცია, თუ არ ვაპირებთ ობიექტის წაშლას.
        // ეს იგივე ლოგიკა ეხება ქვემოთ მოცემულ `fetch_sub` `weak` რაოდენობას.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // ეს ღობე საჭიროა, რათა თავიდან იქნას აცილებული მონაცემთა გამოყენება და არ წაიშალოს მონაცემები.
        // იმის გამო, რომ იგი აღნიშნულია `Release`, მითითების რაოდენობის შემცირება სინქრონიზდება ამ `Acquire` ღობესთან.
        // ეს ნიშნავს, რომ მონაცემთა გამოყენება ხდება მითითების რაოდენობის შემცირებამდე, რაც ხდება ამ ღობემდე, რაც ხდება მონაცემების წაშლამდე.
        //
        // როგორც ეს განმარტებულია [Boost documentation][1]- ში,
        //
        // > მნიშვნელოვანია ობიექტში ნებისმიერი შესაძლო წვდომის განხორციელება ერთში
        // > თემა (არსებული მითითების საშუალებით)*რომ მოხდეს* წაშლამდე
        // > ობიექტი სხვადასხვა ძაფში.ეს მიიღწევა "release"
        // > ოპერაცია მითითების ჩაშვების შემდეგ (ობიექტზე ნებისმიერი წვდომა)
        // > ამ მითითების საშუალებით აშკარად უნდა მომხდარიყო ადრე) და
        // > "acquire" ოპერაცია ობიექტის წაშლამდე.
        //
        // კერძოდ, მიუხედავად იმისა, რომ Arc-ის შინაარსი ჩვეულებრივ უცვლელია, შესაძლებელია Mutex-ის მსგავსი ინტერიერის ჩაწერა<T>.
        // მას შემდეგ, რაც Mutex არ არის შეძენილი მისი წაშლის დროს, ჩვენ არ შეგვიძლია დავეყრდნოთ მის სინქრონიზაციის ლოგიკას, რომ A თემაში ჩაწერები გახდეს B ძაფში გაშვებული დესტრუქტორისთვის.
        //
        //
        // ასევე გაითვალისწინეთ, რომ Acquire ღობე აქ შეიძლება შეიცვალოს Acquire დატვირთვით, რამაც შეიძლება გააუმჯობესოს შესრულება მეტად სადავო სიტუაციებში.იხილეთ [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` ბეტონის ტიპისკენ ჩამოწევის მცდელობა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// აშენებს ახალ `Weak<T>`-ს, მეხსიერების გამოყოფის გარეშე.
    /// დაბრუნების მნიშვნელობაზე [`upgrade`] დარეკვა ყოველთვის იძლევა [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// დამხმარის ტიპი, რათა დაშვებული იყოს წვდომა მითითებებზე, მონაცემთა ველთან დაკავშირებით რაიმე მტკიცების გარეშე.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// უბრუნებს ნედლეულ მაჩვენებელს `T` ობიექტზე, რომელსაც მიუთითებს ეს `Weak<T>`.
    ///
    /// მაჩვენებელი ძალაშია მხოლოდ იმ შემთხვევაში, თუ არსებობს ძლიერი მითითება.
    /// სხვაგვარად, მაჩვენებელი შეიძლება იყოს ჩამოკიდებული, შეუსაბამო ან [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // ორივე ერთ ობიექტზე მიუთითებს
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // აქ ძლიერი მას სიცოცხლეს ინარჩუნებს, ამიტომ ობიექტზე წვდომა კვლავ შეგვიძლია.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // მაგრამ აღარ.
    /// // ჩვენ შეგვიძლია გავაკეთოთ weak.as_ptr(), მაგრამ მაჩვენებელზე წვდომა გამოიწვევს განუსაზღვრელ ქცევას.
    /// // assert_eq! ("გამარჯობა", არა უსაფრთხო {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // თუ მაჩვენებელი ჩამოკიდებულია, ჩვენ უბრუნდებით sentinel-ს პირდაპირ.
            // ეს არ შეიძლება იყოს დატვირთვის სწორი მისამართი, რადგან დატვირთვა მინიმუმ ისეთივე შეესაბამება, როგორც ArcInner (usize).
            ptr as *const T
        } else {
            // უსაფრთხოება: თუ is_dangling არასწორია, მაშინ მაჩვენებელი ამოღებულია.
            // ამ ეტაპზე დატვირთვა შეიძლება დაეცეს და ჩვენ უნდა შევინარჩუნოთ წარმოშობა, ამიტომ გამოიყენეთ ნედლი მაჩვენებლით მანიპულირება.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// მოიხმარს `Weak<T>`-ს და აქცევს მას ნედლეულ მაჩვენებლად.
    ///
    /// ეს გარდაქმნის სუსტ მაჩვენებელს ნედლეულ მაჩვენებლად, ხოლო შენარჩუნებულია ერთი სუსტი მითითების მფლობელობა (სუსტი რაოდენობა არ შეცვლილა ამ ოპერაციით).
    /// ის შეიძლება ისევ `Weak<T>` გახდეს [`from_raw`].
    ///
    /// მაჩვენებლის სამიზნეზე წვდომის იგივე შეზღუდვები მოქმედებს, როგორც [`as_ptr`]- ით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`]-ის მიერ ადრე შექმნილ ნედლეულ მაჩვენებელს ისევ `Weak<T>`-ად აქცევს.
    ///
    /// ეს შეიძლება გამოყენებულ იქნას ძლიერი მითითების უსაფრთხოდ მისაღებად (მოგვიანებით [`upgrade`] დარეკვით) ან სუსტი რიცხვის გამოსაყოფად `Weak<T>` ვარდნათ.
    ///
    /// იგი ფლობს ერთ სუსტ მითითებას (გარდა [`new`]-ის მიერ შექმნილი მითითებებისა, რადგან ისინი არაფერს ფლობენ; მეთოდი ისევ მუშაობს მათზე).
    ///
    /// # Safety
    ///
    /// მაჩვენებელი უნდა წარმოშობილიყო [`into_raw`]- დან და მაინც უნდა ფლობდეს მის პოტენციურ სუსტ მითითებას.
    ///
    /// დასაშვებია ძლიერი რიცხვი იყოს 0 დარეკვის დროს.
    /// ამის მიუხედავად, ეს ფლობს ერთ სუსტ მითითებას, რომელიც ამჟამად წარმოდგენილია როგორც ნედლი მაჩვენებელი (სუსტი რაოდენობა არ შეცვლილა ამ ოპერაციით) და ამიტომ იგი უნდა დაწყვილდეს [`into_raw`]-ზე წინა ზარისთვის.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // ბოლო სუსტი რაოდენობის შემცირება.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // იხილეთ Weak::as_ptr კონტექსტში, თუ როგორ ხდება შეყვანის მაჩვენებელი.

        let ptr = if is_dangling(ptr as *mut T) {
            // ეს არის dangling სუსტი.
            ptr as *mut ArcInner<T>
        } else {
            // წინააღმდეგ შემთხვევაში, ჩვენ გარანტირებული ვართ, რომ მაჩვენებელი მოვიდა არასასურველი სუსტიდან.
            // უსაფრთხოება: data_offset დარეკვა უსაფრთხოა, რადგან ptr მიუთითებს რეალურ (პოტენციურად ჩამოვარდნილ) T-ზე.
            let offset = unsafe { data_offset(ptr) };
            // ამრიგად, ჩვენ ვიცავთ კომპენსაციას, რომ მივიღოთ მთელი RcBox.
            // უსაფრთხოება: მაჩვენებელი წარმოიშვა სუსტიდან, ამიტომ ეს კომპენსაცია უსაფრთხოა.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // უსაფრთხოება: ახლა ჩვენ დავადგინეთ ორიგინალური სუსტი მაჩვენებელი, ამიტომ შეგვიძლია შევქმნათ სუსტი.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` მაჩვენებლის [`Arc`]-ზე განახლების მცდელობები, წარმატების შემთხვევაში შეაფერხებს შიდა მნიშვნელობას.
    ///
    ///
    /// აბრუნებს [`None`] თუ შიდა მნიშვნელობა დაეცა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // გაანადგურეთ ყველა ძლიერი მაჩვენებელი.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // ჩვენ ვიყენებთ CAS მარყუჟს, რომ გავზარდოთ ძლიერი რიცხვი fetch_add-ის ნაცვლად, რადგან ამ ფუნქციამ არასოდეს უნდა მიიღოს მითითების რაოდენობა ნულიდან ერთამდე.
        //
        //
        let inner = self.inner()?;

        // მოდუნებული დატვირთვა, რადგან 0-ის ნებისმიერი ჩანაწერი, რომლის დაკვირვებაც შეგვიძლია, ტოვებს ველს მუდმივად ნულოვან მდგომარეობაში (ასე რომ 0-ის "stale" კითხვა კარგია) და ნებისმიერი სხვა მნიშვნელობა დასტურდება ქვემოთ მოცემული CAS-ით.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // იხილეთ `Arc::clone` კომენტარი, თუ რატომ ვაკეთებთ ამას (`mem::forget`-ისთვის).
            if n > MAX_REFCOUNT {
                abort();
            }

            // დამშვიდებული კარგადაა წარუმატებლობის შემთხვევაში, რადგან ახალი სახელმწიფოს შესახებ არანაირი მოლოდინი არ გვაქვს.
            // შეძენა აუცილებელია წარმატების საქმისთვის სინქრონიზაციისთვის `Arc::new_cyclic`, როდესაც შიდა მნიშვნელობის ინიცირება შესაძლებელია `Weak` ცნობების შექმნის შემდეგ.
            // ამ შემთხვევაში, ჩვენ ველით, რომ დავიცავთ სრულად ინიცირებულ მნიშვნელობას.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null შემოწმებულია ზემოთ
                Err(old) => n = old,
            }
        }
    }

    /// იღებს ძლიერი გამოყოფის (`Arc`) მაჩვენებლებს.
    ///
    /// თუ `self` შეიქმნა [`Weak::new`]- ის გამოყენებით, ეს დაბრუნდება 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// იღებს `Weak` მითითების რაოდენობის მიახლოებას, რომელიც მიუთითებს ამ განაწილებაზე.
    ///
    /// თუ `self` შეიქმნა [`Weak::new`]- ის გამოყენებით, ან თუ არ დარჩა ძლიერი მანიშნებლები, ეს დაგიბრუნებთ 0 - ს.
    ///
    /// # Accuracy
    ///
    /// განხორციელების დეტალების გამო, დაბრუნებული მნიშვნელობა შეიძლება გაუქმდეს 1-ით, ორივე მიმართულებით, როდესაც სხვა ძაფები მანიპულირებენ ნებისმიერი `Arc` ან`Weak`იმავე განაწილებაზე.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // მას შემდეგ, რაც დავაკვირდით, რომ სუსტი რიცხვის წაკითხვის შემდეგ სულ მცირე ერთი ძლიერი მაჩვენებელი იყო, ვიცით, რომ აშკარა სუსტი მითითება (ყოველთვის, როდესაც რაიმე ძლიერი მითითებაა ცოცხალი) ჯერ კიდევ არსებობდა, როდესაც ჩვენ დავაკვირდით სუსტ რაოდენობას და, შესაბამისად, მისი გამოკლება შეგვიძლია.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// აბრუნებს `None`-ს, როდესაც მაჩვენებელი ეკიდება და იქ არ არის გამოყოფილი `ArcInner`, (მაგ., როდესაც ეს `Weak` შეიქმნა `Weak::new`-ის მიერ).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ჩვენ ფრთხილად ვცდილობთ * არ შევქმნათ მითითება, რომელიც მოიცავს "data" ველს, რადგან ამ სფეროში შეიძლება მუტაცია მოხდეს პარალელურად (მაგალითად, თუ ბოლო `Arc` დაეცა, მონაცემთა ველი ადგილზე დაეცემა).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// აბრუნებს `true`-ს, თუ ორი `სუსტი point მიუთითებს ერთ და იმავე გამოყოფაზე (მსგავსი [`ptr::eq`]), ან თუ ორივე არ მიუთითებს რაიმე გამოყოფაზე (რადგან ისინი შექმნილია `Weak::new()`)-ით).
    ///
    ///
    /// # Notes
    ///
    /// ვინაიდან ეს ადარებს მაჩვენებლებს, ეს ნიშნავს, რომ `Weak::new()` გაუტოლდება ერთმანეთს, მიუხედავად იმისა, რომ ისინი არ მიუთითებენ რაიმე განაწილებაზე.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// შედარება `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// ქმნის `Weak` მაჩვენებლის კლონს, რომელიც მიუთითებს იმავე განაწილებაზე.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // იხილეთ კომენტარი Arc::clone()- ში, თუ რატომ არის ეს მოდუნებული.
        // ამით შეგიძლიათ გამოიყენოთ fetch_add (დაბლოკვის იგნორირება), რადგან სუსტი რიცხვი იბლოკება მხოლოდ იქ, სადაც *სხვა* სუსტი მაჩვენებლები არ არის.
        //
        // (ამ შემთხვევაში ამ კოდის გაშვება შეუძლებელია).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // იხილეთ Arc::clone() კომენტარი, თუ რატომ ვაკეთებთ ამას (mem::forget-ისთვის).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// აშენებს ახალ `Weak<T>`-ს, მეხსიერების გამოყოფის გარეშე.
    /// დაბრუნების მნიშვნელობაზე [`upgrade`] დარეკვა ყოველთვის იძლევა [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// ჩამოაგდებს `Weak` მაჩვენებელს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // არაფერს ბეჭდავს
    /// drop(foo);        // ბეჭდავს "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // თუ გავიგეთ, რომ ჩვენ ვიყავით ბოლო სუსტი მაჩვენებელი, დროა მთლიანად გამოვყოთ მონაცემები.იხილეთ დისკუსია Arc::drop() მეხსიერების შეკვეთების შესახებ
        //
        // დაბლოკილი მდგომარეობის შემოწმება აქ არ არის საჭირო, რადგან სუსტი რიცხვის დაბლოკვა შესაძლებელია მხოლოდ იმ შემთხვევაში, თუ ზუსტად ერთი სუსტი ნიშანი იყო, რაც ნიშნავს, რომ ვარდნა შეიძლება მხოლოდ შემდეგ გაგრძელდეს დარჩენილი სუსტი რეფ.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// ჩვენ ვაკეთებთ ამ სპეციალიზაციას აქ და არა როგორც ზოგადი ოპტიმიზაცია `&T`- ზე, რადგან ეს სხვაგვარად დაუმატებს ხარჯებს ყველა თანასწორობის შემოწმებას ref- ებზე.
/// ჩვენ ჩავთვლით, რომ `Arc` გამოიყენება დიდი მნიშვნელობების შესანახად, რომლებიც ნელი ხდება კლონირებისთვის, მაგრამ ასევე მძიმეა თანასწორობის შესამოწმებლად, რის შედეგადაც ამ ფასმა უფრო მარტივად გადაიხადოს.
///
/// ასევე, სავარაუდოდ, ორი `Arc` კლონი იქნება, რომლებიც იმავე მნიშვნელობას მიუთითებენ, ვიდრე ორი `&T`.
///
/// ამის გაკეთება მხოლოდ მაშინ შეგვიძლია, როდესაც `T: Eq`, როგორც `PartialEq`, შეიძლება განზრახ არარეფლექსიური იყოს.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// თანასწორობა ორი `Arc` სთვის.
    ///
    /// ორი `Arc` ტოლია, თუ მათი შინაგანი მნიშვნელობები ტოლია, მაშინაც კი, თუ ისინი სხვადასხვა გამოყოფითაა შენახული.
    ///
    /// თუ `T` ახორციელებს `Eq`-ს (თანასწორობის რეფლექსიურობას გულისხმობს), ორი `Arc`, რომელიც მიუთითებს ერთ და იმავე გამოყოფაზე, ყოველთვის ტოლია.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// უთანასწორობა ორი `Arc` სთვის.
    ///
    /// ორი `თაღოვანი არათანაბარია, თუ მათი შინაგანი ღირებულებები არათანაბარია.
    ///
    /// თუ `T` ასევე ახორციელებს `Eq`-ს (რაც გულისხმობს თანასწორობის რეფლექსიურობას), ორი `Arc`, რომლებიც მიუთითებენ ერთსა და იმავე მნიშვნელობაზე, არასოდეს არათანაბარია.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// ნაწილობრივი შედარება ორი `Arc`s-ისთვის.
    ///
    /// ორი შედარებულია `partial_cmp()`- ით დარეკვით მათი შიდა მნიშვნელობებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// ნაკლები შედარება ორი `Arc` სთვის.
    ///
    /// ორი შედარებულია `<`- ით დარეკვით მათი შიდა მნიშვნელობებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'ნაკლებია ან ტოლი' შედარება ორი `Arc`-ისთვის.
    ///
    /// ორი შედარებულია `<=`- ით დარეკვით მათი შიდა მნიშვნელობებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// მეტია ვიდრე ორი `Arc`s-ის შედარება.
    ///
    /// ორი შედარებულია `>`- ით დარეკვით მათი შიდა მნიშვნელობებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'მეტია ან ტოლი' შედარება ორისთვის `Arc`.
    ///
    /// ორი შედარებულია `>=`- ით დარეკვით მათი შიდა მნიშვნელობებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// შედარება ორი `Arc`s-ისთვის.
    ///
    /// ორი შედარებულია `cmp()`- ით დარეკვით მათი შიდა მნიშვნელობებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// ქმნის ახალ `Arc<T>`-ს, `Default` მნიშვნელობით `T`-ისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// გამოყავით მითითებით დათვლილი ნაჭერი და შეავსეთ იგი `v items ნივთების კლონირებით.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// გამოყავით მითითებით დათვლილი `str` და დააკოპირეთ `v` მასში.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// გამოყავით მითითებით დათვლილი `str` და დააკოპირეთ `v` მასში.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// ყუთში გადატანილი ობიექტის ახალ, მითითებით დათვლილ გამოყოფაში გადატანა.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// გამოყავით მითითებით დათვლილი ნაჭერი და გადააადგილეთ `v` მასალები.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // მიეცით საშუალება Vec-ს გაათავისუფლოს მეხსიერება, მაგრამ არ გაანადგუროს მისი შინაარსი
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// იღებს თითოეულ ელემენტს `Iterator` და აგროვებს მას `Arc<[T]>`-ში.
    ///
    /// # შესრულების მახასიათებლები
    ///
    /// ## ზოგადი საქმე
    ///
    /// ზოგადად, `Arc<[T]>`- ში შეგროვება ხდება პირველად `Vec<T>`- ში შეგროვებით.ეს არის შემდეგი დაწერისას:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ეს იქცევა ისე, როგორც ჩვენ დავწერე:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // გამოყოფის პირველი ნაკრები აქ ხდება.
    ///     .into(); // `Arc<[T]>`- ის მეორე გამოყოფა აქ ხდება.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ეს გამოყოფს იმდენჯერ, რამდენიც საჭიროა `Vec<T>`-ის ასაშენებლად და შემდეგ გამოიყოფა ერთხელ `Vec<T>`-ის `Arc<[T]>`-ად გადაქცევისთვის.
    ///
    ///
    /// ## ცნობილი სიგრძის იტერატორები
    ///
    /// როდესაც თქვენი `Iterator` განახორციელებს `TrustedLen`-ს და მისი ზუსტი ზომაა, ერთი გამოყოფა მოხდება `Arc<[T]>`-სთვის.Მაგალითად:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // აქ მხოლოდ ერთი გამოყოფა ხდება.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// სპეციალიზაცია trait, რომელიც გამოიყენება `Arc<[T]>`- ში შეგროვებისთვის.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // ეს ასეა `TrustedLen` იტერატორისთვის.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // უსაფრთხოება: ჩვენ უნდა დავრწმუნდეთ, რომ იტერატორს აქვს ზუსტი სიგრძე და გვაქვს.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // დაუბრუნდით ნორმალურ განხორციელებას.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// მიიღეთ კომპენსაცია `ArcInner` ფარგლებში მაჩვენებლის დატვირთვისთვის.
///
/// # Safety
///
/// მანიშნებელმა უნდა მიუთითოს (და ჰქონდეს მოქმედი მეტამონაცემები) T-ს ადრე მოქმედი ინსტანციისა, მაგრამ T-ის დაშვება დაშვებულია.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // გაუაზრებელი მნიშვნელობის გასწორება ArcInner-ის ბოლოს.
    // იმის გამო, რომ RcBox არის repr(C), ის ყოველთვის იქნება მეხსიერების ბოლო ველი.
    // უსაფრთხოება: ვინაიდან მხოლოდ ერთადერთი ზომის ტიპები არის ნაჭრები, trait ობიექტები,
    // და გარე ტიპის, შეყვანის უსაფრთხოების მოთხოვნა ამჟამად საკმარისია იმისათვის, რომ დააკმაყოფილოს alval_of_val_raw მოთხოვნები;ეს არის იმ ენის შესრულების დეტალი, რომელსაც არ შეიძლება დაეყრდნონ std- ის გარეთ.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}