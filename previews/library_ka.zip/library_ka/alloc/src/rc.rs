//! ერთჯერადი ძაფის მითითების თვლის მაჩვენებლები.'Rc' ნიშნავს "Reference"
//! Counted'.
//!
//! ტიპი [`Rc<T>`][`Rc`] უზრუნველყოფს საერთო საკუთრებაში `T` ტიპის მნიშვნელობას, რომელიც გამოიყოფა გროვაში.
//! [`clone`][clone]- ზე [`clone`][clone]- ის გამოძახება ქმნის ახალ მაჩვენებელს იგივე განაწილების გროვაში.
//! როდესაც მოცემული გამოყოფის უკანასკნელი [`Rc`] მაჩვენებელი განადგურებულია, ამ გამოყოფაში შენახული მნიშვნელობა (ხშირად მოიხსენიება როგორც "inner value") ასევე დაეცემა.
//!
//! Rust- ში გაზიარებული მითითებები ნაგულისხმევად არ უშვებს მუტაციას და გამონაკლისი არ არის [`Rc`]: ზოგადად ვერ მიიღებთ mutable მითითებას [`Rc`]- ის შიგნით.
//! თუ თქვენ გჭირდებათ ცვალებადობა, ჩასვით [`Cell`] ან [`RefCell`] შიგნით [`Rc`];იხილეთ [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] იყენებს არაატომური მითითების თვლას.
//! ეს ნიშნავს, რომ ზედნადები ძალიან დაბალია, მაგრამ [`Rc`] ვერ გაიგზავნება ძაფებს შორის და, შესაბამისად, [`Rc`] არ ახორციელებს [`Send`][send]-ს.
//! შედეგად, Rust შემდგენელი შეამოწმებს *შედგენის დროს* რომ არ აგზავნით [`Rc`]-ს ძაფებს შორის.
//! თუ გჭირდებათ მრავალ ძაფიანი, ატომური მითითების დათვლა, გამოიყენეთ [`sync::Arc`][arc].
//!
//! [`downgrade`][downgrade] მეთოდი შეიძლება გამოყენებულ იქნას არაპატრონე [`Weak`] მაჩვენებლის შესაქმნელად.
//! [`Weak`] მაჩვენებელი შეიძლება იყოს ["განახლება"][განახლება] d [`Rc`]- ზე, მაგრამ ეს დააბრუნებს [`None`] თუ გამოყოფაში შენახული მნიშვნელობა უკვე დაეცა.
//! სხვა სიტყვებით რომ ვთქვათ, `Weak` მაჩვენებლები არ ინარჩუნებს მნიშვნელობას გამოყოფის შიგნით;ამასთან, ისინი * ინარჩუნებენ გამოყოფას (შიდა მნიშვნელობის სარეზერვო მაღაზიას).
//!
//! ციკლი [`Rc`] მაჩვენებლებს შორის არასდროს გადანაწილდება.
//! ამ მიზეზით, [`Weak`] გამოიყენება ციკლის შესამტვრევად.
//! მაგალითად, ხე შეიძლება ჰქონდეს ძლიერი [`Rc`] მაჩვენებლები მშობლიური კვანძებიდან შვილებამდე და [`Weak`] მითითებები ბავშვებისგან მშობლებისკენ.
//!
//! `Rc<T>` ავტომატურად გადამისამართება `T`-ზე ([`Deref`] trait-ის საშუალებით), ასე რომ თქვენ შეგიძლიათ დარეკოთ `T` მეთოდებს [`Rc<T>`][`Rc`] ტიპის მნიშვნელობაზე.
//! "T"-ს მეთოდებთან სახელების შეჯახების თავიდან ასაცილებლად, [`Rc<T>`][`Rc`]- ის მეთოდები ასოცირებული ფუნქციებია, რომლებსაც [fully qualified syntax]- ს უწოდებენ:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `რკ<T>traits- ს იმპლემენტაციას, როგორიცაა `Clone`, ასევე შეიძლება ეწოდოს სრულად კვალიფიციური სინტაქსის გამოყენებით.
//! ზოგიერთს ურჩევნია გამოიყენოს სრულად კვალიფიციური სინტაქსი, ზოგი კი ამჯობინებს მეთოდის ზარის სინტაქსის გამოყენებას.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // მეთოდი-ზარის სინტაქსი
//! let rc2 = rc.clone();
//! // სრულად კვალიფიციური სინტაქსი
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] არ ახდენს ავტომატური გადამისამართებას `T`- ზე, რადგან შინაგანი მნიშვნელობა შეიძლება უკვე დაეცა.
//!
//! # ცნობები კლონირებისთვის
//!
//! ახალი მინიშნების შექმნა იმავე განაწილებაზე, როგორც არსებული მითითებით დათვლილი მაჩვენებელი ხორციელდება `Clone` trait-ის გამოყენებით, რომელიც განხორციელებულია [`Rc<T>`][`Rc`] და [`Weak<T>`][`Weak`]-ზე.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // ქვემოთ მოცემული ორი სინტაქსი ექვივალენტურია.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a და b ორივე მითითებულია მეხსიერების იმავე ადგილას, როგორც foo.
//! ```
//!
//! `Rc::clone(&from)` სინტაქსი ყველაზე იდიომატურია, რადგან ის უფრო მკაფიოდ გადმოსცემს კოდის მნიშვნელობას.
//! ზემოთ მოყვანილ მაგალითში, ეს სინტაქსი უფრო აადვილებს იმის გარკვევას, რომ ეს კოდი ქმნის ახალ ცნობას და არა foo-ს მთლიანი შინაარსის კოპირებას.
//!
//! # Examples
//!
//! განვიხილოთ სცენარი, როდესაც `გაჯეტების` ნაკრები ეკუთვნის მოცემულ `Owner`-ს.
//! ჩვენ გვსურს ჩვენი `Gadget` წერტილი მივცეთ მათ `Owner`-ს.ამის გაკეთება უნიკალური საკუთრებით არ შეგვიძლია, რადგან ერთზე მეტი გაჯეტი შეიძლება ეკუთვნოდეს იგივე `Owner`.
//! [`Rc`] საშუალებას გვაძლევს გავუზიაროთ `Owner` მრავალრიცხოვან `გაჯეტს and და დავტოვოთ `Owner` განაწილებული, სანამ მასში ნებისმიერი `Gadget` წერტილია.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... სხვა სფეროები
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... სხვა სფეროები
//! }
//!
//! fn main() {
//!     // შექმენით მითითებით დათვლილი `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // შექმენით `Gadget` რომელიც ეკუთვნის `gadget_owner`-ს.
//!     // `Rc<Owner>`-ის კლონირება გვაძლევს ახალ მაჩვენებელს იგივე `Owner` განაწილებისკენ, ამ პროცესში იზრდება მითითების რაოდენობა.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // განკარგეთ ჩვენი ადგილობრივი ცვლადი `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` ჩაშვების მიუხედავად, ჩვენ კვლავ შეგვიძლია დავბეჭდოთ `Gadget`-ის `Owner`-ის სახელი.
//!     // ეს იმიტომ ხდება, რომ ჩვენ მხოლოდ ერთი `Rc<Owner>` დავუშვით და არა `Owner`, რომელზეც მიუთითებს.
//!     // სანამ არსებობს სხვა `Rc<Owner>`, რომელიც მიუთითებს იმავე `Owner` განაწილებაზე, ის დარჩება პირდაპირ რეჟიმში.
//!     // ველის პროექცია `gadget1.owner.name` მუშაობს იმის გამო, რომ `Rc<Owner>` ავტომატურად გადადის `Owner`- ზე.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // ფუნქციის ბოლოს `gadget1` და `gadget2` განადგურებულია და მათთან ერთად ბოლო დათვლილი ცნობები ჩვენს `Owner`- ზე.
//!     // Gadget Man ახლა ანადგურებს ასევე.
//!     //
//! }
//! ```
//!
//! თუ ჩვენი მოთხოვნები შეიცვლება და ჩვენ ასევე უნდა შეგვეძლოს `Owner`-დან `Gadget`-ის გავლა, პრობლემები შეგვექმნება.
//! [`Rc`] მაჩვენებელი `Owner`- დან `Gadget`- მდე შემოაქვს ციკლი.
//! ეს ნიშნავს, რომ მათი მითითება ვერასოდეს მიაღწევს 0-ს და გამოყოფა არასოდეს განადგურდება:
//! მეხსიერების გაჟონვა.იმისათვის, რომ თავიდან ავიცილოთ ეს, ჩვენ შეგვიძლია გამოვიყენოთ [`Weak`] მაჩვენებლები.
//!
//! Rust სინამდვილეში გარკვეულწილად ართულებს ამ მარყუჟის წარმოებას.იმისათვის, რომ დასრულდეს ორი მნიშვნელობა, რომლებიც ერთმანეთზე მიუთითებს, ერთი მათგანი უნდა იყოს მუტაბოლი.
//! ეს ძნელია, რადგან [`Rc`] ახდენს მეხსიერების უსაფრთხოების დაცვას მხოლოდ გაზიარებული მითითებების მიცემით, რომელსაც იგი ახვევს და ეს არ იძლევა პირდაპირი მუტაციის საშუალებას.
//! ჩვენ უნდა შევახვიოთ ღირებულების ის ნაწილი, რომლის მუტაციაც გვსურს [`RefCell`]- ით, რომელიც უზრუნველყოფს *შინაგან მუტაბელურობას*: მეთოდი მუტაციის მისაღწევად საერთო მითითების საშუალებით.
//! [`RefCell`] ახდენს Rust სესხის წესების შესრულებას დროს.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... სხვა სფეროები
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... სხვა სფეროები
//! }
//!
//! fn main() {
//!     // შექმენით მითითებით დათვლილი `Owner`.
//!     // გაითვალისწინეთ, რომ ჩვენ დავაყენეთ `Gadget`-ის`მფლობელის` vector `RefCell`-ის შიგნით, რომ შეგვიძლია მისი მუტაცია გავაზიაროთ საყოველთაო მითითებით.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // შექმენით `Gadget`, რომელიც `gadget_owner`- ს ეკუთვნის, როგორც ადრე.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // დაამატეთ `Gadget` მის `Owner`-ს.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` დინამიური სესხი აქ მთავრდება.
//!     }
//!
//!     // გაიმეორეთ ჩვენი `გაჯეტი`, ბეჭდეთ მათი დეტალები.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` არის `Weak<Gadget>`.
//!         // ვინაიდან `Weak` მაჩვენებლები ვერ უზრუნველყოფენ განაწილების არსებობას, ჩვენ უნდა დაურეკოთ `upgrade`, რომელიც გვაბრუნებს `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // ამ შემთხვევაში ჩვენ ვიცით, რომ განაწილება ჯერ კიდევ არსებობს, ასე რომ, ჩვენ უბრალოდ `unwrap` `Option`.
//!         // უფრო რთულ პროგრამაში შეიძლება დაგჭირდეთ შეცდომების მოხდენილი დამუშავება `None` შედეგისთვის.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // ფუნქციის ბოლოს განადგურებულია `gadget_owner`, `gadget1` და `gadget2`.
//!     // ახლა გაჯეტებზე არ არის ძლიერი (`Rc`) მითითება, ამიტომ ისინი განადგურებულია.
//!     // ეს ნულოვანია Gadget Man-ზე მითითების საფუძველზე, ამიტომ ის ასევე განადგურდება.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// ეს არის repr(C)- დან future- მდე დაუშვებელია ველის ხელახალი შეცვლის საწინააღმდეგოდ, რაც ხელს უშლის სხვაგვარად უსაფრთხო [into|from]_raw() ტრანსმუტაციის შიდა ტიპებს.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// ერთჯერადი ძაფის მითითების თვლის მაჩვენებელი.'Rc' ნიშნავს "Reference"
/// Counted'.
///
/// დამატებითი ინფორმაციისთვის იხილეთ [module-level documentation](./index.html).
///
/// `Rc`-ის თანდაყოლილი მეთოდები ყველა ასოცირებული ფუნქციაა, რაც ნიშნავს, რომ თქვენ უნდა უწოდოთ მათ, მაგალითად, [`Rc::get_mut(&mut value)`][get_mut] `value.get_mut()`-ის ნაცვლად.
/// ეს თავიდან აიცილებს კონფლიქტს შიდა ტიპის `T` მეთოდებთან.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // ეს უსაფრთხოება კარგადაა, რადგან სანამ ეს Rc ცოცხალია, ჩვენ გარანტირებული გვაქვს, რომ შიდა მაჩვენებელი სწორია.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// აშენებს ახალ `Rc<T>`-ს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // არსებობს ძლიერი სანიშნეების სუსტი მაჩვენებელი, რომელიც უზრუნველყოფს რომ სუსტი დესტრუქტორი არასოდეს ათავისუფლებს განაწილებას ძლიერი დესტრუქტორის მუშაობის დროს, მაშინაც კი, თუ სუსტი მაჩვენებელი ინახება ძლიერში.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// აშენებს ახალ `Rc<T>`- ს, საკუთარ თავზე სუსტი მითითების გამოყენებით.
    /// ამ ფუნქციის დაბრუნებამდე სუსტი მითითების განახლების მცდელობა გამოიწვევს `None` მნიშვნელობას.
    ///
    /// ამასთან, სუსტი ცნობარი შეიძლება თავისუფლად იყოს კლონირებული და შენახული იქნას გამოყენებისთვის მოგვიანებით.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... მეტი ველი
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // ააშენეთ შიდა "uninitialized" მდგომარეობაში ერთი სუსტი მითითებით.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // მნიშვნელოვანია, რომ ჩვენ არ დავთმობთ სუსტი მაჩვენებლის საკუთრებას, თორემ შეიძლება მეხსიერება გათავისუფლდეს `data_fn` დაბრუნების დროს.
        // თუ ჩვენ ნამდვილად გვინდოდა საკუთრების უფლების გადაცემა, შეგვეძლო საკუთარი თავისთვის დამატებითი სუსტი მაჩვენებლის შექმნა, მაგრამ ეს გამოიწვევს სუსტი მითითების რაოდენობის დამატებით განახლებებს, რაც სხვაგვარად შეიძლება არ იყოს საჭირო.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // ძლიერი ცნობარი ერთობლივად უნდა ფლობდეს საერთო სუსტ მითითებას, ასე რომ ნუ გაუშვებთ გამანადგურებელს ჩვენი ძველი სუსტი ცნობარისთვის.
        //
        mem::forget(weak);
        strong
    }

    /// აშენებს ახალ `Rc`-ს არაინციალიზებული შინაარსებით.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// აშენებს ახალ `Rc` არაინიციალიზებულ შინაარსს, მეხსიერება ივსება `0` ბაიტით.
    ///
    ///
    /// იხილეთ [`MaybeUninit::zeroed`][zeroed] ამ მეთოდის სწორი და არასწორი გამოყენების მაგალითებისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// აშენებს ახალ `Rc<T>`-ს, შეცდომას აბრუნებს, თუ გამოყოფა ვერ მოხერხდა
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // არსებობს ძლიერი სანიშნეების სუსტი მაჩვენებელი, რომელიც უზრუნველყოფს რომ სუსტი დესტრუქტორი არასოდეს ათავისუფლებს განაწილებას ძლიერი დესტრუქტორის მუშაობის დროს, მაშინაც კი, თუ სუსტი მაჩვენებელი ინახება ძლიერში.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// აშენებს ახალ `Rc` არაინიციალიზებულ შინაარსს და გამოყოფას ვერ ახერხებს შეცდომის დაბრუნებით
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// აშენებს ახალ `Rc` არაინციალიზებულ შინაარსს, მეხსიერება ივსება `0` ბაიტით, ანაზღაურება ვერ მოხერხდება, თუ გამოყოფა შეუძლებელია
    ///
    ///
    /// იხილეთ [`MaybeUninit::zeroed`][zeroed] ამ მეთოდის სწორი და არასწორი გამოყენების მაგალითებისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// აშენებს ახალ `Pin<Rc<T>>`-ს.
    /// თუ `T` არ განახორციელებს `Unpin`-ს, მაშინ `value` დამაგრდება მეხსიერებაში და მისი გადაადგილება შეუძლებელია.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// აბრუნებს შინაგან მნიშვნელობას, თუ `Rc`- ს აქვს ზუსტად ერთი ძლიერი მითითება.
    ///
    /// წინააღმდეგ შემთხვევაში, [`Err`] უბრუნდება იმავე `Rc`-ს, რომელიც გაიარა.
    ///
    ///
    /// ეს წარმატებას მიაღწევს მაშინაც კი, თუ არსებობს გამოჩენილი სუსტი ცნობები.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // დააკოპირეთ შემცველი ობიექტი

                // მიუთითეთ სუსტ მხარეებზე, რომ მათი დაწინაურება შეუძლებელია ძლიერი რაოდენობის შემცირებით და შემდეგ წაშალეთ ნაგულისხმევი "strong weak" მაჩვენებელი, ხოლო ჩამოსაშლელი ლოგიკის დამუშავება მხოლოდ ყალბი სუსტის შემუშავებით.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// აშენებს მითითებით დათვლილ ახალ ნაკვეთს, არაინციალიზებული შინაარსებით.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// აშენებს მითითებით დათვლილ ახალ ნაჭერს არაინციალიზირებული შინაარსით, მეხსიერება ივსება `0` ბაიტით.
    ///
    ///
    /// იხილეთ [`MaybeUninit::zeroed`][zeroed] ამ მეთოდის სწორი და არასწორი გამოყენების მაგალითებისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// გადადის `Rc<T>`-ზე.
    ///
    /// # Safety
    ///
    /// როგორც [`MaybeUninit::assume_init`]- ს შემთხვევაში, აბონენტის გადასაწყვეტია, რომ შინაგანი ღირებულება ნამდვილად არის თავდაპირველ მდგომარეობაში.
    ///
    /// ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს დაუყოვნებლივ გაურკვეველ ქცევას.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// გადადის `Rc<[T]>`-ზე.
    ///
    /// # Safety
    ///
    /// როგორც [`MaybeUninit::assume_init`]- ს შემთხვევაში, აბონენტის გადასაწყვეტია, რომ შინაგანი ღირებულება ნამდვილად არის თავდაპირველ მდგომარეობაში.
    ///
    /// ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს დაუყოვნებლივ გაურკვეველ ქცევას.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // გადადებული ინიციალიზაცია:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// მოიხმარს `Rc`-ს, დააბრუნებს გახვეულ კურსორს.
    ///
    /// მეხსიერების გაჟონვის თავიდან ასაცილებლად, მაჩვენებელი უნდა გადაკეთდეს `Rc`- ზე [`Rc::from_raw`][from_raw]- ის გამოყენებით.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// უზრუნველყოფს მონაცემთა ნედლ მაჩვენებელს.
    ///
    /// დათვლა არანაირად არ მოქმედებს და `Rc` არ არის მოხმარებული.
    /// მაჩვენებელი მოქმედებს მანამ, სანამ `Rc`- ში არსებობს ძლიერი რიცხვები.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // უსაფრთხოება: ეს არ შეიძლება გაიაროს Deref::deref ან Rc::inner, რადგან
        // ეს საჭიროა raw/mut წარმოშობის შესანარჩუნებლად, რომ მაგ
        // `get_mut` შეუძლია წერა მაჩვენებლის საშუალებით Rc-ის აღდგენის შემდეგ `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// აშენებს `Rc<T>` ნედლეული მაჩვენებლისგან.
    ///
    /// ნედლეული მაჩვენებელი ადრე უნდა დაბრუნდეს [`Rc<U>::into_raw`][into_raw]-ზე დარეკვით, სადაც `U` უნდა ჰქონდეს იგივე ზომა და გასწორება, როგორც `T`.
    /// ეს ტრივიალურად არის მართებული, თუ `U` არის `T`.
    /// გაითვალისწინეთ, რომ თუ `U` არ არის `T`, მაგრამ აქვს იგივე ზომა და გასწორება, ეს ძირითადად ჰგავს სხვადასხვა ტიპის ცნობების ტრანსმუტირებას.
    /// იხილეთ [`mem::transmute`][transmute] დამატებითი ინფორმაციისთვის, თუ რა შეზღუდვები ვრცელდება ამ შემთხვევაში.
    ///
    /// `from_raw` მომხმარებელი უნდა დარწმუნდეს, რომ `T` სპეციფიკური მნიშვნელობა მხოლოდ ერთხელ დაეცა.
    ///
    /// ეს ფუნქცია არ არის უსაფრთხო, რადგან არასათანადო გამოყენებამ შეიძლება გამოიწვიოს მეხსიერების დაუცველობა, მაშინაც კი, თუ დაბრუნებულ `Rc<T>`- ზე არასოდეს შემოდის წვდომა.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // გადაიყვანეთ `Rc`-ზე, რომ არ მოხდეს გაჟონვა.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)`-ზე შემდგომი ზარები მეხსიერებისათვის უსაფრთხო არ იქნება.
    /// }
    ///
    /// // მეხსიერება გათავისუფლდა, როდესაც `x` გავიდა ფარგლებიდან ზემოთ, ამიტომ `x_ptr` ახლა ჩამოკიდებულია!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // შეცვალეთ კომპენსაცია, რომ იპოვოთ ორიგინალი RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// ამ გამოყოფისთვის ქმნის ახალ [`Weak`] მაჩვენებელს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // დარწმუნდით, რომ ჩვენ არ ვქმნით dangling სუსტს
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// იღებს ამ გამოყოფის [`Weak`] მაჩვენებლების რაოდენობას.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// იღებს ამ გამოყოფის ძლიერი (`Rc`) მაჩვენებლების რაოდენობას.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// აბრუნებს `true`-ს, თუ ამ განაწილებას სხვა `Rc` ან [`Weak`] მაჩვენებლები არ აქვს.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// აბრუნებს მუტაბელურ მითითებას მოცემულ `Rc`-ში, თუ არ არსებობს სხვა `Rc` ან [`Weak`] მაჩვენებლები იმავე განაწილებაზე.
    ///
    ///
    /// სხვაგვარად აბრუნებს [`None`]-ს, რადგან გაზიარებული მნიშვნელობის მუტაცია უსაფრთხო არ არის.
    ///
    /// აგრეთვე [`make_mut`][make_mut], რომელიც [`clone`][clone] წარმოადგენს შიდა მნიშვნელობას, როდესაც სხვა მაჩვენებლებია.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// აბრუნებს მუტაბელურ მითითებას მოცემულ `Rc`- ში, ყოველგვარი შემოწმების გარეშე.
    ///
    /// აგრეთვე [`get_mut`], რომელიც უსაფრთხოა და შესაბამის შემოწმებებს აკეთებს.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// ნებისმიერი სხვა `Rc` ან [`Weak`] მაჩვენებლები იმავე განაწილებაზე არ უნდა იქნეს მითითებული დაბრუნებული სესხის განმავლობაში.
    ///
    /// ეს ტრივიალური შემთხვევაა, თუ ასეთი მაჩვენებლები არ არსებობს, მაგალითად `Rc::new`- ის შემდეგ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // ჩვენ ფრთხილად ვცდილობთ * არ შევქმნათ მითითება "count" ველების დასაფარავად, რადგან ეს ეწინააღმდეგება მითითების რაოდენობაზე წვდომას (მაგ.
        // `Weak`-ის მიერ).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// აბრუნებს `true`-ს, თუ ორი `Rc` მიუთითებს იმავე გამოყოფაზე ([`ptr::eq`]-ის მსგავსი ვენაში).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// აკეთებს mutable მითითებას მოცემულ `Rc`-ში.
    ///
    /// თუ იგივე გამოყოფის სხვა `Rc` მაჩვენებლებია, მაშინ `make_mut` იქნება [`clone`] ახალი მნიშვნელობის შიდა მნიშვნელობით, უნიკალური საკუთრების უზრუნველსაყოფად.
    /// ამას ასევე უწოდებენ დაწერის კლონს.
    ///
    /// თუ ამ განაწილებას სხვა `Rc` მაჩვენებლები არ აქვს, მაშინ ამ გამოყოფის [`Weak`] მაჩვენებლები გამოიყოფა.
    ///
    /// აგრეთვე [`get_mut`], რომელიც ვერ მოხერხდება, ვიდრე კლონირება.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // არაფერს კლონირდება
    /// let mut other_data = Rc::clone(&data);    // არ მოხდება შინაგანი მონაცემების კლონირება
    /// *Rc::make_mut(&mut data) += 1;        // ახდენს შიდა მონაცემების კლონირებას
    /// *Rc::make_mut(&mut data) += 1;        // არაფერს კლონირდება
    /// *Rc::make_mut(&mut other_data) *= 2;  // არაფერს კლონირდება
    ///
    /// // ახლა `data` და `other_data` მიუთითებს სხვადასხვა განაწილებაზე.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] მითითებები დაიშლება:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Gotta- ს მონაცემების კლონირება, არსებობს სხვა Rcs.
            // წინასწარ გამოყავით მეხსიერება, რომ მოხდეს კლონირებული მნიშვნელობის პირდაპირ ჩაწერა.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // შეუძლია უბრალოდ მოიპაროს მონაცემები, დარჩენილია მხოლოდ სუსტები
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // წაშალეთ მყარი სუსტი რეფ. (აქ არ არის საჭირო ყალბი სუსტის შემუშავება-ჩვენ ვიცით, რომ სხვა სისუსტეებს შეუძლიათ ჩვენთვის გასუფთავება)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // ეს უსაფრთხოება კარგადაა, რადგან გარანტირებული გვაქვს, რომ დაბრუნებული მაჩვენებელი არის *ერთადერთი* მაჩვენებელი, რომელიც ოდესმე დაუბრუნდება T-ს.
        // ამ ეტაპზე ჩვენი მითითების რაოდენობა გარანტირებული იქნება 1, ხოლო ჩვენ თვითონ `Rc<T>` გვჭირდება `mut`, ამიტომ ჩვენ ვუბრუნებთ გამოყოფის ერთადერთ შესაძლო მითითებას.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` ბეტონის ტიპისკენ ჩამოწევის მცდელობა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// გამოყოფს `RcBox<T>`-ს საკმარისი სივრცის შესაძლო ზომის შიდა მნიშვნელობით, სადაც მნიშვნელობას აქვს განლაგებული.
    ///
    /// ფუნქციას `mem_to_rcbox` ეწოდება მონაცემთა მაჩვენებლის საშუალებით და უნდა დააბრუნოს (პოტენციურად ცხიმიანი) მაჩვენებელი `RcBox<T>`- სთვის.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // გამოთვალეთ განლაგება მოცემული მნიშვნელობის განლაგების გამოყენებით.
        // მანამდე განლაგება გამოითვლებოდა `&*(ptr as* const RcBox<T>)` გამოხატვაზე, მაგრამ ამან შექმნა არასწორად მითითებული მითითება (იხ. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// გამოყოფს `RcBox<T>`-ს საკმარისი სივრცის შესაძლო ზომის შიდა მნიშვნელობისთვის, სადაც მნიშვნელობას აქვს განლაგებული, შეცდომას უბრუნებს გამოყოფის შეუსრულებლობის შემთხვევაში.
    ///
    ///
    /// ფუნქციას `mem_to_rcbox` ეწოდება მონაცემთა მაჩვენებლის საშუალებით და უნდა დააბრუნოს (პოტენციურად ცხიმიანი) მაჩვენებელი `RcBox<T>`- სთვის.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // გამოთვალეთ განლაგება მოცემული მნიშვნელობის განლაგების გამოყენებით.
        // მანამდე განლაგება გამოითვლებოდა `&*(ptr as* const RcBox<T>)` გამოხატვაზე, მაგრამ ამან შექმნა არასწორად მითითებული მითითება (იხ. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // გამოყავით განლაგებისათვის.
        let ptr = allocate(layout)?;

        // ინიცირება RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// გამოყოფს `RcBox<T>`- ს, საკმარისი სივრცის გარეშე ზომის შიდა მნიშვნელობით
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // გამოყავით `RcBox<T>` მოცემული მნიშვნელობის გამოყენებით.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // კოპირება მნიშვნელობით, როგორც ბაიტი
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // გამოყოფის გათავისუფლება მისი შინაარსის ჩაშლის გარეშე
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// გამოყოფს `RcBox<[T]>` მოცემულ სიგრძეს.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// დააკოპირეთ ელემენტები ნაჭერიდან ახლად გამოყოფილ Rc <\[T\]> ში
    ///
    /// არაუსაფრთხოა, რადგან აბონენტმა ან უნდა მიიღოს საკუთრება, ან უნდა დააკავშიროს `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// აშენებს `Rc<[T]>`-ს გარკვეული ზომის იტერატორისგან.
    ///
    /// ქცევა გაურკვეველია, თუ ზომა არასწორია.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic დაცვა T ელემენტების კლონირებისას.
        // panic-ის შემთხვევაში, ელემენტები, რომლებიც დაწერილია ახალ RcBox-ში, ჩამოიშლება და მეხსიერება გათავისუფლდება.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // მაჩვენებელი პირველ ელემენტზე
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Ყველაფერი გასაგებია.დაივიწყეთ დაცვა, რომ არ გაათავისუფლოს ახალი RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// სპეციალიზაცია trait, რომელიც გამოიყენება `From<&[T]>`-სთვის.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// ვარდება `Rc`.
    ///
    /// ეს შეამცირებს ძლიერი მითითების რაოდენობას.
    /// თუ ძლიერი მითითების რაოდენობა ნულს მიაღწევს, მხოლოდ სხვა მითითებები (ასეთის არსებობის შემთხვევაში) არის [`Weak`], ამიტომ ჩვენ `drop` შიდა მნიშვნელობა.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // არაფერს ბეჭდავს
    /// drop(foo2);   // ბეჭდავს "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // განადგურება შეიცავს ობიექტს
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // ახლა წაშალეთ ნაგულისხმევი "strong weak" მაჩვენებელი, როდესაც ჩვენ განადგურებული გვაქვს შინაარსი.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// ქმნის `Rc` მაჩვენებლის კლონს.
    ///
    /// ეს ქმნის სხვა მაჩვენებელს იმავე განაწილებაზე, რაც ზრდის მძლავრი მითითების რაოდენობას.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// ქმნის ახალ `Rc<T>`-ს, `Default` მნიშვნელობით `T`-ისთვის.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack დაუშვით სპეციალიზაცია `Eq`- ზე, მიუხედავად იმისა, რომ `Eq`- ს მეთოდი აქვს.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// ჩვენ ვაკეთებთ ამ სპეციალიზაციას აქ და არა როგორც ზოგადი ოპტიმიზაცია `&T`- ზე, რადგან ეს სხვაგვარად დაუმატებს ხარჯებს ყველა თანასწორობის შემოწმებას ref- ებზე.
/// ჩვენ ჩავთვლით, რომ `Rc` გამოიყენება დიდი მნიშვნელობების შესანახად, რომლებიც ნელი ხდება კლონირებისთვის, მაგრამ ასევე მძიმეა თანასწორობის შესამოწმებლად, რის შედეგადაც ამ ფასმა უფრო მარტივად გადაიხადოს.
///
/// ასევე, სავარაუდოდ, ორი `Rc` კლონი იქნება, რომლებიც იმავე მნიშვნელობას მიუთითებენ, ვიდრე ორი `&T`.
///
/// ამის გაკეთება მხოლოდ მაშინ შეგვიძლია, როდესაც `T: Eq`, როგორც `PartialEq`, შეიძლება განზრახ არარეფლექსიური იყოს.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// თანასწორობა ორი `Rc` სთვის.
    ///
    /// ორი `Rc` ტოლია, თუ მათი შინაგანი მნიშვნელობები ტოლია, მაშინაც კი, თუ ისინი სხვადასხვა გამოყოფითაა შენახული.
    ///
    /// თუ `T` ახორციელებს `Eq`-ს (თანასწორობის რეფლექსიურობას გულისხმობს), ორი `Rc`, რომლებიც მიუთითებენ ერთ და იმავე გამოყოფაზე, ყოველთვის ტოლია.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// უტოლობა ორი `Rc` სთვის.
    ///
    /// ორი `Rc` არათანაბარია, თუ მათი შინაგანი ღირებულებები არათანაბარია.
    ///
    /// თუ `T` ასევე ახორციელებს `Eq`-ს (რაც გულისხმობს თანასწორობის რეფლექსიურობას), ორი `Rc`, რომლებიც მიუთითებენ ერთ და იმავე გამოყოფაზე, არასოდეს არათანაბარია.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// ნაწილობრივი შედარება ორი `Rc` სთვის.
    ///
    /// ორი შედარებულია `partial_cmp()`- ით დარეკვით მათი შიდა მნიშვნელობებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// ნაკლებია ვიდრე ორი `Rc` ს შედარება.
    ///
    /// ორი შედარებულია `<`- ით დარეკვით მათი შიდა მნიშვნელობებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'ნაკლები ან ტოლი' შედარება ორი `Rc` სთვის.
    ///
    /// ორი შედარებულია `<=`- ით დარეკვით მათი შიდა მნიშვნელობებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// მეტია ვიდრე ორი `Rc` ს შედარება.
    ///
    /// ორი შედარებულია `>`- ით დარეკვით მათი შიდა მნიშვნელობებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'მეტი ან ტოლი' შედარება ორი Rc-ისთვის.
    ///
    /// ორი შედარებულია `>=`- ით დარეკვით მათი შიდა მნიშვნელობებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// შედარება ორი `Rc` სთვის.
    ///
    /// ორი შედარებულია `cmp()`- ით დარეკვით მათი შიდა მნიშვნელობებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// გამოყავით მითითებით დათვლილი ნაჭერი და შეავსეთ იგი `v items ნივთების კლონირებით.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// გამოყავით მითითებით დათვლილი სიმების ნაჭერი და გადაწერეთ `v` მასში.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// გამოყავით მითითებით დათვლილი სიმების ნაჭერი და გადაწერეთ `v` მასში.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// გადატანა ყუთში ობიექტი ახალი, მითითებული დათვლილი, გამოყოფა.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// გამოყავით მითითებით დათვლილი ნაჭერი და გადააადგილეთ `v` მასალები.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // მიეცით საშუალება Vec-ს გაათავისუფლოს მეხსიერება, მაგრამ არ გაანადგუროს მისი შინაარსი
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// იღებს თითოეულ ელემენტს `Iterator` და აგროვებს მას `Rc<[T]>`-ში.
    ///
    /// # შესრულების მახასიათებლები
    ///
    /// ## ზოგადი საქმე
    ///
    /// ზოგადად, `Rc<[T]>`- ში შეგროვება ხდება პირველად `Vec<T>`- ში შეგროვებით.ეს არის შემდეგი დაწერისას:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ეს იქცევა ისე, როგორც ჩვენ დავწერე:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // გამოყოფის პირველი ნაკრები აქ ხდება.
    ///     .into(); // `Rc<[T]>`- ის მეორე გამოყოფა აქ ხდება.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ეს გამოყოფს იმდენჯერ, რამდენიც საჭიროა `Vec<T>`-ის ასაშენებლად და შემდეგ გამოიყოფა ერთხელ `Vec<T>`-ის `Rc<[T]>`-ად გადაქცევისთვის.
    ///
    ///
    /// ## ცნობილი სიგრძის იტერატორები
    ///
    /// როდესაც თქვენი `Iterator` განახორციელებს `TrustedLen`-ს და მისი ზუსტი ზომაა, ერთი გამოყოფა მოხდება `Rc<[T]>`-სთვის.Მაგალითად:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // აქ მხოლოდ ერთი გამოყოფა ხდება.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// სპეციალიზაცია trait, რომელიც გამოიყენება `Rc<[T]>`- ში შეგროვებისთვის.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // ეს ასეა `TrustedLen` იტერატორისთვის.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // უსაფრთხოება: ჩვენ უნდა დავრწმუნდეთ, რომ იტერატორს აქვს ზუსტი სიგრძე და გვაქვს.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // დაუბრუნდით ნორმალურ განხორციელებას.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` არის [`Rc`] ვერსია, რომელიც მართავს გამოყოფას არაკუთვნი მითითებით.გამოყოფაზე წვდომა ხდება [`upgrade`] `Weak` მაჩვენებელზე დარეკვით, რომელიც აბრუნებს ["ვარიანტი"] "<" ["Rc"] "<T>>"
///
/// ვინაიდან `Weak` მითითება არ ითვლება საკუთრებაში, ეს ხელს არ შეუშლის გამოყოფაში შენახული ღირებულების ვარდნას, ხოლო `Weak` თავად არ იძლევა გარანტიებს ღირებულების არსებობის შესახებ.
/// ამრიგად, მას შეუძლია დააბრუნოს [`None`], როდესაც ["განახლება"] დ.
/// ამასთან, გაითვალისწინეთ, რომ `Weak` მითითება * ხელს უშლის გამოყოფის (სარეზერვო მაღაზიის) გადანაწილებას.
///
/// `Weak` მაჩვენებელი სასარგებლოა [`Rc`]-ის მიერ მართული განაწილების დროებითი მითითების შესანარჩუნებლად, მისი შიდა მნიშვნელობის ჩამოშლის თავიდან ასაცილებლად.
/// იგი ასევე გამოიყენება [`Rc`] მაჩვენებლებს შორის ცირკულარული ცნობების თავიდან ასაცილებლად, რადგან ურთიერთსაკუთრების ცნობები არასოდეს იძლევა [`Rc`]-ის ჩაშვების საშუალებას.
/// მაგალითად, ხე შეიძლება ჰქონდეს ძლიერი [`Rc`] მაჩვენებლები მშობლიური კვანძებიდან ბავშვებამდე და `Weak` მითითებები ბავშვებისგან მშობლებამდე.
///
/// `Weak` მაჩვენებლის მოპოვების ტიპიური გზაა [`Rc::downgrade`] დარეკვა.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // ეს არის `NonNull`, რათა ამ ტიპის ზომის ოპტიმიზაცია მოხდეს ციფრებში, მაგრამ ეს სულაც არ არის სწორი მაჩვენებელი.
    //
    // `Weak::new` ადგენს ამას `usize::MAX` ისე, რომ მას არ სჭირდება ადგილის გამოყოფა გროვაში.
    // ეს არ არის ნამდვილი მაჩვენებლის მნიშვნელობა, რადგან RcBox- ს მინიმუმ 2 აქვს გასწორება.
    // ეს შესაძლებელია მხოლოდ მაშინ, როდესაც `T: Sized`;არასაკმარისი `T` არასდროს ირევა.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// აშენებს ახალ `Weak<T>`-ს, მეხსიერების გამოყოფის გარეშე.
    /// დაბრუნების მნიშვნელობაზე [`upgrade`] დარეკვა ყოველთვის იძლევა [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// დამხმარის ტიპი, რათა დაშვებული იყოს წვდომა მითითებებზე, მონაცემთა ველთან დაკავშირებით რაიმე მტკიცების გარეშე.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// უბრუნებს ნედლეულ მაჩვენებელს `T` ობიექტზე, რომელსაც მიუთითებს ეს `Weak<T>`.
    ///
    /// მაჩვენებელი ძალაშია მხოლოდ იმ შემთხვევაში, თუ არსებობს ძლიერი მითითება.
    /// სხვაგვარად, მაჩვენებელი შეიძლება იყოს ჩამოკიდებული, შეუსაბამო ან [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // ორივე ერთ ობიექტზე მიუთითებს
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // აქ ძლიერი მას სიცოცხლეს ინარჩუნებს, ამიტომ ობიექტზე წვდომა კვლავ შეგვიძლია.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // მაგრამ აღარ.
    /// // ჩვენ შეგვიძლია გავაკეთოთ weak.as_ptr(), მაგრამ მაჩვენებელზე წვდომა გამოიწვევს განუსაზღვრელ ქცევას.
    /// // assert_eq! ("გამარჯობა", არა უსაფრთხო {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // თუ მაჩვენებელი ჩამოკიდებულია, ჩვენ უბრუნდებით sentinel-ს პირდაპირ.
            // ეს არ შეიძლება იყოს დატვირთვის სწორი მისამართი, რადგან დატვირთვა არანაკლებ გასწორებულია, როგორც RcBox (usize).
            ptr as *const T
        } else {
            // უსაფრთხოება: თუ is_dangling არასწორია, მაშინ მაჩვენებელი ამოღებულია.
            // ამ ეტაპზე დატვირთვა შეიძლება დაეცეს და ჩვენ უნდა შევინარჩუნოთ წარმოშობა, ამიტომ გამოიყენეთ ნედლი მაჩვენებლით მანიპულირება.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// მოიხმარს `Weak<T>`-ს და აქცევს მას ნედლეულ მაჩვენებლად.
    ///
    /// ეს გარდაქმნის სუსტ მაჩვენებელს ნედლეულ მაჩვენებლად, ხოლო შენარჩუნებულია ერთი სუსტი მითითების მფლობელობა (სუსტი რაოდენობა არ შეცვლილა ამ ოპერაციით).
    /// ის შეიძლება ისევ `Weak<T>` გახდეს [`from_raw`].
    ///
    /// მაჩვენებლის სამიზნეზე წვდომის იგივე შეზღუდვები მოქმედებს, როგორც [`as_ptr`]- ით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`]-ის მიერ ადრე შექმნილ ნედლეულ მაჩვენებელს ისევ `Weak<T>`-ად აქცევს.
    ///
    /// ეს შეიძლება გამოყენებულ იქნას ძლიერი მითითების უსაფრთხოდ მისაღებად (მოგვიანებით [`upgrade`] დარეკვით) ან სუსტი რიცხვის გამოსაყოფად `Weak<T>` ვარდნათ.
    ///
    /// იგი ფლობს ერთ სუსტ მითითებას (გარდა [`new`]-ის მიერ შექმნილი მითითებებისა, რადგან ისინი არაფერს ფლობენ; მეთოდი ისევ მუშაობს მათზე).
    ///
    /// # Safety
    ///
    /// მაჩვენებელი უნდა წარმოშობილიყო [`into_raw`]- დან და მაინც უნდა ფლობდეს მის პოტენციურ სუსტ მითითებას.
    ///
    /// დასაშვებია ძლიერი რიცხვი იყოს 0 დარეკვის დროს.
    /// ამის მიუხედავად, ეს ფლობს ერთ სუსტ მითითებას, რომელიც ამჟამად წარმოდგენილია როგორც ნედლი მაჩვენებელი (სუსტი რაოდენობა არ შეცვლილა ამ ოპერაციით) და ამიტომ იგი უნდა დაწყვილდეს [`into_raw`]-ზე წინა ზარისთვის.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // ბოლო სუსტი რაოდენობის შემცირება.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // იხილეთ Weak::as_ptr კონტექსტში, თუ როგორ ხდება შეყვანის მაჩვენებელი.

        let ptr = if is_dangling(ptr as *mut T) {
            // ეს არის dangling სუსტი.
            ptr as *mut RcBox<T>
        } else {
            // წინააღმდეგ შემთხვევაში, ჩვენ გარანტირებული ვართ, რომ მაჩვენებელი მოვიდა არასასურველი სუსტიდან.
            // უსაფრთხოება: data_offset დარეკვა უსაფრთხოა, რადგან ptr მიუთითებს რეალურ (პოტენციურად ჩამოვარდნილ) T-ზე.
            let offset = unsafe { data_offset(ptr) };
            // ამრიგად, ჩვენ ვიცავთ კომპენსაციას, რომ მივიღოთ მთელი RcBox.
            // უსაფრთხოება: მაჩვენებელი წარმოიშვა სუსტიდან, ამიტომ ეს კომპენსაცია უსაფრთხოა.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // უსაფრთხოება: ახლა ჩვენ დავადგინეთ ორიგინალური სუსტი მაჩვენებელი, ამიტომ შეგვიძლია შევქმნათ სუსტი.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` მაჩვენებლის [`Rc`]-ზე განახლების მცდელობები, წარმატების შემთხვევაში შეაფერხებს შიდა მნიშვნელობას.
    ///
    ///
    /// აბრუნებს [`None`] თუ შიდა მნიშვნელობა დაეცა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // გაანადგურეთ ყველა ძლიერი მაჩვენებელი.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// იღებს ძლიერი გამოყოფის (`Rc`) მაჩვენებლებს.
    ///
    /// თუ `self` შეიქმნა [`Weak::new`]- ის გამოყენებით, ეს დაბრუნდება 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// იღებს `Weak` მაჩვენებლების რაოდენობას, რომლებიც მიუთითებს ამ განაწილებაზე.
    ///
    /// თუ ძლიერი მაჩვენებლები არ დარჩება, ეს ნულს დაუბრუნებს.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // გამოვაკლოთ იმპლიციტური სუსტი ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// აბრუნებს `None`-ს, როდესაც მაჩვენებელი ეკიდება და იქ არ არის გამოყოფილი `RcBox`, (მაგ., როდესაც ეს `Weak` შეიქმნა `Weak::new`-ის მიერ).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ჩვენ ფრთხილად ვცდილობთ * არ შევქმნათ მითითება, რომელიც მოიცავს "data" ველს, რადგან ამ სფეროში შეიძლება მუტაცია მოხდეს პარალელურად (მაგალითად, თუ ბოლო `Rc` დაეცა, მონაცემთა ველი ადგილზე დაეცემა).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// აბრუნებს `true`-ს, თუ ორი `სუსტი point მიუთითებს ერთ და იმავე გამოყოფაზე (მსგავსი [`ptr::eq`]), ან თუ ორივე არ მიუთითებს რაიმე გამოყოფაზე (რადგან ისინი შექმნილია `Weak::new()`)-ით).
    ///
    ///
    /// # Notes
    ///
    /// ვინაიდან ეს ადარებს მაჩვენებლებს, ეს ნიშნავს, რომ `Weak::new()` გაუტოლდება ერთმანეთს, მიუხედავად იმისა, რომ ისინი არ მიუთითებენ რაიმე განაწილებაზე.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// შედარება `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// ჩამოაგდებს `Weak` მაჩვენებელს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // არაფერს ბეჭდავს
    /// drop(foo);        // ბეჭდავს "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // სუსტი რაოდენობა იწყება 1 - დან და ნულამდე მივა მხოლოდ იმ შემთხვევაში, თუ ყველა ძლიერი მაჩვენებელი გაქრა.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// ქმნის `Weak` მაჩვენებლის კლონს, რომელიც მიუთითებს იმავე განაწილებაზე.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// აშენებს ახალ `Weak<T>`-ს, გამოყოფს მეხსიერებას `T`-სთვის მისი ინიციალიზაციის გარეშე.
    /// დაბრუნების მნიშვნელობაზე [`upgrade`] დარეკვა ყოველთვის იძლევა [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: ჩვენ გადავამოწმეთ აქ დამატება mem::forget- ს უსაფრთხოდ მოგვარების მიზნით.Კერძოდ
// თუ თქვენ გაქვთ mem::forget Rcs (ან Weaks), ხელახალი დათვლა შეიძლება გადაიზარდოს და შემდეგ შეგიძლიათ გამოყოთ გამოყოფა, სანამ გამოჩენილი Rcs (ან Weaks) არსებობს.
//
// ჩვენ აბორტს ვაკეთებთ, რადგან ეს ისეთი დეგენერატი სცენარია, რომ არ გვაინტერესებს რა ხდება-არცერთ რეალურ პროგრამას ეს არასოდეს უნდა განუცდია.
//
// ამას უნდა ჰქონდეს უმნიშვნელო ზედნადები, ვინაიდან თქვენ ნამდვილად არ გჭირდებათ ამ ყველაფრის კლონირება Rust- ში საკუთრების და გადაადგილების სემანტიკის წყალობით.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // ჩვენ გვინდა შევაჩეროთ გადავსება, ვიდრე არ დავუშვებთ მნიშვნელობას.
        // მითითების რაოდენობა არასოდეს იქნება ნული, როდესაც ამას დარეკავთ;
        // ამის მიუხედავად, ჩვენ აქ ჩადეთ აბორტი, რომ LLVM მივუთითოთ სხვაგვარად გამოტოვებული ოპტიმიზაციის შესახებ.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // ჩვენ გვინდა შევაჩეროთ გადავსება, ვიდრე არ დავუშვებთ მნიშვნელობას.
        // მითითების რაოდენობა არასოდეს იქნება ნული, როდესაც ამას დარეკავთ;
        // ამის მიუხედავად, ჩვენ აქ ჩადეთ აბორტი, რომ LLVM მივუთითოთ სხვაგვარად გამოტოვებული ოპტიმიზაციის შესახებ.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// მიიღეთ კომპენსაცია `RcBox` ფარგლებში მაჩვენებლის დატვირთვისთვის.
///
/// # Safety
///
/// მანიშნებელმა უნდა მიუთითოს (და ჰქონდეს მოქმედი მეტამონაცემები) T-ს ადრე მოქმედი ინსტანციისა, მაგრამ T-ის დაშვება დაშვებულია.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // გაუზომავი მნიშვნელობის გასწორება RcBox-ის ბოლოს.
    // იმის გამო, რომ RcBox არის repr(C), ის ყოველთვის იქნება მეხსიერების ბოლო ველი.
    // უსაფრთხოება: ვინაიდან მხოლოდ ერთადერთი ზომის ტიპები არის ნაჭრები, trait ობიექტები,
    // და გარე ტიპის, შეყვანის უსაფრთხოების მოთხოვნა ამჟამად საკმარისია იმისათვის, რომ დააკმაყოფილოს alval_of_val_raw მოთხოვნები;ეს არის იმ ენის შესრულების დეტალი, რომელსაც არ შეიძლება დაეყრდნონ std- ის გარეთ.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}