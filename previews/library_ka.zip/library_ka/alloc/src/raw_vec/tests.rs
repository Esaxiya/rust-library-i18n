use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // ინტეგრაციის ტესტის დაწერა მესამე მხარის გამყოფებსა და `RawVec`-ს შორის ცოტა რთულია, რადგან `RawVec` API არ გამოყოფს შეცდომების განაწილების მეთოდებს, ამიტომ ვერ ვამოწმებთ რა ხდება, როდესაც ამომწურავი ამოწურულია (panic-ის დადგენას).
    //
    //
    // ამის ნაცვლად, ეს მხოლოდ ამოწმებს, რომ `RawVec` მეთოდები მინიმუმ გადის Allocator API-ს, როდესაც ის ინახავს შენახვას.
    //
    //
    //
    //
    //

    // მუნჯი გამანაწილებელი, რომელიც მოიხმარს ფიქსირებულ რაოდენობას საწვავს, სანამ განაწილების მცდელობები დაიწყებს ჩავარდნას.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (იწვევს გადანაწილებას, ამრიგად იყენებს 50 + 150=200 ერთეულ საწვავს)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // პირველი, `reserve` გამოყოფს, როგორც `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 7-ზე ორმაგზე მეტია, ამიტომ `reserve` უნდა მუშაობდეს როგორც `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 12 - ის ნახევარზე ნაკლებია, ამიტომ `reserve` უნდა გაიზარდოს ექსპონენციალურად.
        // ამ ტესტის წერის დროს ზრდის ფაქტორი არის 2, ამიტომ ახალი სიმძლავრეა 24, თუმცა 1.5 ზრდის ფაქტორიც კარგია.
        //
        // აქედან `>= 18` მტკიცებაში.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}