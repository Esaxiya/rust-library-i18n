//! განსაზღვრავს `IntoIter` საკუთრივ iterator მასივებისთვის.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// საშუალო მნიშვნელობის [array] გამწმენდი.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// ეს არის ის მასივი, რომელზეც ჩვენ ვიმეორებთ.
    ///
    /// `i` ინდექსის მქონე ელემენტები, სადაც `alive.start <= i < alive.end` ჯერ არ არის გამოტანილი და მასივის სწორი ჩანაწერებია.
    /// ელემენტები `i < alive.start` ან `i >= alive.end` ინდექსებით უკვე ამოღებულია და მათზე წვდომა აღარ უნდა მოხდეს!ეს მკვდარი ელემენტები შეიძლება საერთოდ არაინციალიზებულ მდგომარეობაში იყოს!
    ///
    ///
    /// ინვარიანტებია:
    /// - `data[alive]` ცოცხალია (ანუ შეიცავს მოქმედ ელემენტებს)
    /// - `data[..alive.start]` და `data[alive.end..]` მკვდარია (ანუ ელემენტები უკვე წაიკითხეს და აღარ უნდა შეეხოთ!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// ელემენტები `data`- ში, რომლებიც ჯერ არ გამოვიდა.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// ქმნის ახალ იტერატორს მოცემული `array`- ზე.
    ///
    /// *შენიშვნა*: ეს მეთოდი შეიძლება გაბათილდეს future- ში, [`IntoIterator` is implemented for arrays][array-into-iter]- ის შემდეგ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` ტიპის აქ არის `i32`, ნაცვლად `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // უსაფრთხოება: აქ ტრანსმუტა უსაფრთხოა.`MaybeUninit`- ის დოკუმენტები
        // promise:
        //
        // > `MaybeUninit<T>` გარანტირებული აქვს იგივე ზომა და გასწორება
        // > როგორც `T`.
        //
        // დოკუმენტებში ნაჩვენებია ტრანსუტირება `MaybeUninit<T>` მასივიდან `T` მასივამდე.
        //
        //
        // ამით, ეს ინიცირება აკმაყოფილებს უცვლელებს.

        // FIXME(LukasKalbertodt): ფაქტობრივად გამოიყენეთ `mem::transmute` აქ, მას შემდეგ რაც ის მუშაობს gen genics-თან:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // მანამდე, ჩვენ შეგვიძლია გამოვიყენოთ `mem::transmute_copy`, რომ შევქმნათ ცოტათი ასლი, როგორც სხვა ტიპი, შემდეგ დავივიწყოთ `array`, რომ ის არ ჩამოვარდეს.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// აბრუნებს ყველა ელემენტის უცვლელ ნაჭერს, რომელიც ჯერ არ გამოვიდა.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // უსაფრთხოება: ჩვენ ვიცით, რომ `alive`-ის ყველა ელემენტი სწორად არის ინიცირებული.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// აბრუნებს ყველა ელემენტის მუტაბელურ ნაჭერს, რომელიც ჯერ არ გამოვიდა.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // უსაფრთხოება: ჩვენ ვიცით, რომ `alive`-ის ყველა ელემენტი სწორად არის ინიცირებული.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // მიიღეთ შემდეგი ინდექსი წინა მხრიდან.
        //
        // `alive.start`- ით 1-ით გაზრდა ინარჩუნებს უცვლელობას `alive`- ს მიმართ.
        // ამასთან, ამ ცვლილების გამო, მცირე ხნით, ცოცხალი ზონა უკვე არაა `data[alive]`, არამედ `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // წაიკითხეთ ელემენტი მასივიდან.
            // უსაფრთხოება: `idx` არის ინდექსი ყოფილი "alive" რეგიონში
            // მასივიამ ელემენტის წაკითხვა ნიშნავს, რომ `data[idx]` ახლა მკვდარია (მაგ. არ შეეხოთ).
            // რადგან `idx` იყო ცოცხალი ზონის დასაწყისი, ცოცხალი ზონა ახლა ისევ `data[alive]` გახლავთ, აღადგენს ყველა ინვარიანტს.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // მიიღეთ შემდეგი ინდექსი უკნიდან.
        //
        // `alive.end`- ით 1 - ით შემცირება ინარჩუნებს უცვლელობას `alive`- ს მიმართ.
        // ამასთან, ამ ცვლილების გამო, მცირე ხნით, ცოცხალი ზონა უკვე არაა `data[alive]`, არამედ `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // წაიკითხეთ ელემენტი მასივიდან.
            // უსაფრთხოება: `idx` არის ინდექსი ყოფილი "alive" რეგიონში
            // მასივიამ ელემენტის წაკითხვა ნიშნავს, რომ `data[idx]` ახლა მკვდარია (მაგ. არ შეეხოთ).
            // რადგან `idx` იყო ცოცხალი ზონის დასასრული, ცოცხალი ზონა ახლა ისევ `data[alive]` გახდა და აღადგენს ყველა ინვარიანტს.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // უსაფრთხოება: ეს უსაფრთხოა: `as_mut_slice` აბრუნებს ზუსტად ქვენაჭერს
        // იმ ელემენტების, რომლებიც ჯერ არ არის გადატანილი და რჩება გასაშვებად.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // არასდროს დაიწევს ნაკადის უცვლელი `ცოცხალი`. დაწყების <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// იტერატორი აცხადებს სწორ სიგრძეს.
// "alive" ელემენტების რაოდენობა (რომელიც კვლავ მიიღება) არის `alive` დიაპაზონის სიგრძე.
// ეს დიაპაზონი მცირდება სიგრძით ან `next` ან `next_back`.
// ამ მეთოდებში ის ყოველთვის მცირდება 1-ით, მაგრამ მხოლოდ იმ შემთხვევაში, თუ `Some(_)` დაუბრუნდება.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // გაითვალისწინეთ, ჩვენ ნამდვილად არ გვჭირდება ზუსტად იგივე ცოცხალი დიაპაზონის შესატყვისი, ასე რომ, ჩვენ შეგვიძლია მხოლოდ კლონირება გადავწყვიტოთ 0-ზე, მიუხედავად იმისა, თუ სად არის `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // ყველა ცოცხალი ელემენტის კლონირება.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // დაწერეთ კლონი ახალ მასივში და განაახლეთ მისი ცოცხალი დიაპაზონი.
            // თუ panics-ს კლონირება მოხდება, ჩვენ წინა ელემენტებს სწორად ჩამოვაგდებთ.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // მხოლოდ იმ ელემენტების დაბეჭდვა, რომლებიც ჯერ არ არის გამოცემული: ჩვენ აღარ შეგვიძლია მივიღოთ მიღებული ელემენტები.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}