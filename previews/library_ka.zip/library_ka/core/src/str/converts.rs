//! `str`-ის შექმნის გზები ბაიტის ნაჭერიდან.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// ბაიტების ნაჭერს გარდაქმნის სიმების ნაჭრებად.
///
/// ([`&str`]) სიმების ნაკვეთი მზადდება ბაიტის ([`u8`]), ხოლო ბაიტის ნაჭერი ([`&[u8]`][byteslice]) ბაიტისგან, ამიტომ ეს ფუნქცია გარდაიქმნება ორს შორის.
/// ყველა ბაიტის ნაჭერი არ არის სიმების სწორი ნაჭრები, თუმცა: [`&str`] მოითხოვს რომ ის იყოს სწორი UTF-8.
/// `from_utf8()` ამოწმებს რომ ბაიტი არის UTF-8 მართებული და შემდეგ ახდენს გარდაქმნას.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// თუ დარწმუნებული ხართ, რომ ბაიტის ნაკვეთი მართებულია UTF-8 და არ გსურთ მოქმედების შემოწმების ოვერჰედის გაკეთება, არსებობს ამ ფუნქციის არაუსაფრთხო ვერსია [`from_utf8_unchecked`], რომელსაც აქვს იგივე ქცევა, მაგრამ გამოტოვებს შემოწმებას.
///
///
/// თუ თქვენ გჭირდებათ `String` ნაცვლად `&str`, გაითვალისწინეთ [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// იმის გამო, რომ შეგიძლიათ დააწყოთ `[u8; N]` და შეგიძლიათ აიღოთ [`&[u8]`][byteslice], ეს ფუნქცია არის სტეკზე გამოყოფილი სტრიქონის ერთ - ერთი გზა.ამის მაგალითია ქვემოთ მოცემული მაგალითების განყოფილებაში.
///
/// [byteslice]: slice
///
/// # Errors
///
/// აბრუნებს `Err` თუ ნაკვეთი არ არის UTF-8 აღწერით, თუ რატომ არ არის მოცემული ნაკვეთი UTF-8.
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::str;
///
/// // ზოგიერთი ბაიტი, vector-ში
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ჩვენ ვიცით, რომ ეს ბაიტი მართებულია, ამიტომ გამოიყენეთ `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// არასწორი ბაიტი:
///
/// ```
/// use std::str;
///
/// // ზოგიერთი არასწორი ბაიტი, vector-ში
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// იხილეთ [`Utf8Error`]- ის დოკუმენტები დამატებითი ინფორმაციისათვის, თუ რა სახის შეცდომების დაბრუნება შეგიძლიათ.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // ზოგიერთი ბაიტი სტეკით გამოყოფილ მასივში
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // ჩვენ ვიცით, რომ ეს ბაიტი მართებულია, ამიტომ გამოიყენეთ `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // უსაფრთხოება: ახლახან გაიქცა ვალიდაცია.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// გარდაქმნის ბაიტების მუტაბელურ ნაჭერს მუტაბელურ სტრიქონის ნაჭრებად.
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" როგორც მუტაბელური vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // როგორც ვიცით, რომ ეს ბაიტი სწორია, ჩვენ შეგვიძლია გამოვიყენოთ `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// არასწორი ბაიტი:
///
/// ```
/// use std::str;
///
/// // ზოგიერთი არასწორი ბაიტი მუტაბელურ vector-ში
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// იხილეთ [`Utf8Error`]- ის დოკუმენტები დამატებითი ინფორმაციისათვის, თუ რა სახის შეცდომების დაბრუნება შეგიძლიათ.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // უსაფრთხოება: ახლახან გაიქცა ვალიდაცია.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// ბაიტების ნაჭერს გარდაქმნის სტრიქონის ნაჭრებად, იმის შემოწმების გარეშე, რომ სტრიქონი შეიცავს UTF-8-ს.
///
/// დამატებითი ინფორმაციისთვის იხილეთ უსაფრთხო ვერსია [`from_utf8`].
///
/// # Safety
///
/// ეს ფუნქცია არ არის უსაფრთხო, რადგან ის არ ამოწმებს, რომ მასში გადაცემული ბაიტი მოქმედებს UTF-8.
/// თუ ეს შეზღუდვა დაირღვა, განუსაზღვრელი ქცევა გამოიწვევს შედეგს, რადგან Rust- ის დანარჩენი ნაწილი თვლის, რომ [`&str`] s მოქმედებს UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::str;
///
/// // ზოგიერთი ბაიტი, vector-ში
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // უსაფრთხოება: გამრეკელმა უნდა უზრუნველყოს, რომ `v` ბაიტი მოქმედებს UTF-8.
    // ასევე ეყრდნობა `&str` და `&[u8]` იგივე განლაგებას.
    unsafe { mem::transmute(v) }
}

/// ბაიტების ნაჭერს გარდაქმნის სტრიქონის ნაჭრებად, იმის შემოწმების გარეშე, რომ სტრიქონი შეიცავს მართებულ UTF-8;მუტაბელური ვერსია.
///
///
/// დამატებითი ინფორმაციისთვის იხილეთ უცვლელი ვერსია, [`from_utf8_unchecked()`].
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს `v` ბაიტი
    // მოქმედებს UTF-8, ამიტომ `*mut str`- ზე გადატანა უსაფრთხოა.
    // ასევე, მაჩვენებლის გადამისამართება უსაფრთხოა, რადგან ეს მაჩვენებელი მოდის მითითებიდან, რომელიც გარანტირებულია, რომ ძალაშია ჩაწერისთვის.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}