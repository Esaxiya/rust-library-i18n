//! UTF-8 დამტკიცებასთან დაკავშირებული ოპერაციები.

use crate::mem;

use super::Utf8Error;

/// აბრუნებს კოდირების წერტილების პირველ აკუმულატორს პირველი ბაიტისთვის.
/// პირველი ბაიტი განსაკუთრებულია, მხოლოდ ქვედა 5 ბიტი უნდა სიგანეზე 2, 4 ბიტი სიგანეზე 3 და 3 ბიტი სიგანეზე 4.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// აბრუნებს `ch` ღირებულებას, განახლებული ბაიტით `byte`.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// ამოწმებს არის თუ არა ბაიტი UTF-8 გაგრძელების ბაიტი (ანუ იწყება ბიტი `10`).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// კითხულობს შემდეგ კოდის წერტილს ბაიტის იტერატორისგან (ვთქვათ UTF-8 მსგავსი კოდირება).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // გაშიფვრა UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // მულტიბაიტიანი ბაიტის კომბინაციიდან ხდება დეკოდირება: [[[x y] z] w]
    //
    // NOTE: შესრულება მგრძნობიარეა აქ ზუსტი ფორმულირების მიმართ
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] საქმე
        // მე-5 ბიტი 0xE0- ში. 0xEF ყოველთვის გასაგებია, ამიტომ `init` კვლავ მოქმედებს
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] გამოიყენეთ მხოლოდ `init` ქვედა 3 ბიტი
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// კითხულობს ბოლო კოდის წერტილს ბაიტის იტერატორისგან (ვთქვათ UTF-8 მსგავსი კოდირება).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // გაშიფვრა UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // მულტიბიიტიანი ბაიტის კომბინაციიდან ხდება დეკოდირების კოდი: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// გამოიყენეთ truncation, რომ მოათავსოთ u64 გამოყენებაში
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// აბრუნებს `true`-ს, თუ რომელიმე ბაიტი სიტყვა `x`-ში არის nonascii (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// გადის `v`-ს და გადაამოწმებს, რომ ეს სწორია UTF-8 თანმიმდევრობა, ამ შემთხვევაში უბრუნებს `Ok(())`-ს, ან, თუ ის არასწორია, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // ჩვენ მონაცემები გვჭირდებოდა, მაგრამ არცერთი არ ყოფილა: შეცდომა!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2-ბაიტიანი კოდირება არის კოდირების წერტილებისთვის\u {0080} პირველი C2 80 ბოლო DF BF-სთვის
            // 3-ბაიტიანი კოდირება არის კოდირების წერტილებისთვის\u {0800} პირველი E0 A0 80 უკანასკნელი EF BF BF, სუროგატების კოდირების გარეშე\u {d800} ED A0 80 to ED BF BF
            // 4-ბაიტიანი კოდირება არის კოდპოინტებისთვის\u {1000} 0 დან\u {10ff} ჯერ F0 90 80 80 ბოლო F4 8F BF BF
            //
            // გამოიყენეთ UTF-8 სინტაქსი RFC- დან
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8 კუდი UTF8-3= %xE0% xA0-BF UTF8 კუდი/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8 კუდი/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii შემთხვევაში, შეეცადე სწრაფად გამოტოვო წინ.
            // როდესაც მაჩვენებელი გასწორდება, წაიკითხეთ მონაცემების 2 სიტყვა განმეორებით, სანამ არ ვიპოვით სიტყვას, რომელიც შეიცავს არა-ასციტურ ბაიტს.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // უსაფრთხოება: რადგან `align - index` და `ascii_block_size` არის
                    // `usize_bytes`-ის ჯერადი, `block = ptr.add(index)` ყოველთვის შეესაბამება `usize`-ს, ასე რომ უსაფრთხოა `block`-სა და `block.offset(1)`-ისთვის გადაცემა.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // შესვენება, თუ არსებობს არააციალური ბაიტი
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // ნაბიჯი იმ წერტილიდან, სადაც სიტყვასიტყვით მარყუჟი შეჩერდა
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// პირველი ბაიტის გათვალისწინებით, განსაზღვრავს რამდენი ბაიტი არის ამ UTF-8 სიმბოლოში.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// გაგრძელების ბაიტის მნიშვნელობის ბიტების ნიღაბი.
const CONT_MASK: u8 = 0b0011_1111;
/// ტეგის ბიტების მნიშვნელობა (ტეგის ნიღაბი არის !CONT_MASK) გაგრძელებული ბაიტი.
const TAG_CONT_U8: u8 = 0b1000_0000;

// `&str` სიგრძის მაქსიმუმ `max` ტოლი დაუბრუნეთ `true`, თუ ის შემცირდა და ახალი str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}