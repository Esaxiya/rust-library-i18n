#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // ფართოვდება ან `$crate::panic::panic_2015` ან `$crate::panic::panic_2021`- ზე, რაც დამოკიდებულია აბონენტის გამოცემაზე.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// ამტკიცებს, რომ ორი გამონათქვამი ერთმანეთის ტოლია ([`PartialEq`]-ის გამოყენებით).
///
/// panic-ზე, ეს მაკრო დაბეჭდავს გამონათქვამების მნიშვნელობებს მათი გამართვის წარმოდგენებით.
///
///
/// [`assert!`]-ის მსგავსად, ამ მაკროსაც აქვს მეორე ფორმა, სადაც შესაძლებელია მომხმარებლისთვის panic შეტყობინების გაგზავნა.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // ქვემოთ მოქცეული რეპროდუქციები მიზანმიმართულია.
                    // მათ გარეშე, სტეკის სლოტის ინიცირება ხდება მნიშვნელობების შედარებამდეც, რაც საგრძნობლად შენელდება.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // ქვემოთ მოქცეული რეპროდუქციები მიზანმიმართულია.
                    // მათ გარეშე, სტეკის სლოტის ინიცირება ხდება მნიშვნელობების შედარებამდეც, რაც საგრძნობლად შენელდება.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ამტკიცებს, რომ ორი გამონათქვამი ერთმანეთის ტოლი არ არის (გამოყენებით [`PartialEq`]).
///
/// panic-ზე, ეს მაკრო დაბეჭდავს გამონათქვამების მნიშვნელობებს მათი გამართვის წარმოდგენებით.
///
///
/// [`assert!`]-ის მსგავსად, ამ მაკროსაც აქვს მეორე ფორმა, სადაც შესაძლებელია მომხმარებლისთვის panic შეტყობინების გაგზავნა.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // ქვემოთ მოქცეული რეპროდუქციები მიზანმიმართულია.
                    // მათ გარეშე, სტეკის სლოტის ინიცირება ხდება მნიშვნელობების შედარებამდეც, რაც საგრძნობლად შენელდება.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // ქვემოთ მოქცეული რეპროდუქციები მიზანმიმართულია.
                    // მათ გარეშე, სტეკის სლოტის ინიცირება ხდება მნიშვნელობების შედარებამდეც, რაც საგრძნობლად შენელდება.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ამტკიცებს, რომ ლოგიკური გამონათქვამი `true` ა შესრულების დროს.
///
/// ეს გამოიწვევს [`panic!`] მაკროს, თუ მითითებული გამოხატვის შეფასება შეუძლებელია `true`- ით შესრულების დროს.
///
/// [`assert!`]-ის მსგავსად, ამ მაკროსაც აქვს მეორე ვერსია, სადაც შესაძლებელია მომხმარებლისთვის panic შეტყობინების გაგზავნა.
///
/// # Uses
///
/// [`assert!`]-ისგან განსხვავებით, `debug_assert!` დებულებები ჩართულია მხოლოდ არაოპტიმიზირებულ მშენებლობებში.
/// ოპტიმიზირებული აშენება არ შეასრულებს `debug_assert!` დებულებებს, თუ `-C debug-assertions` არ გადაეცემა შემდგენელს.
/// ეს `debug_assert!` გამოსადეგია იმ შემოწმებისთვის, რომლებიც ძალიან ძვირია გამოსაშვების ფორმაში ყოფნისთვის, მაგრამ შეიძლება სასარგებლო იყოს განვითარების დროს.
/// `debug_assert!` გაფართოების შედეგი ყოველთვის შემოწმებულია ტიპის მიხედვით.
///
/// შეუმოწმებელი მტკიცება საშუალებას აძლევს არათანმიმდევრულ მდგომარეობაში მყოფ პროგრამას გააგრძელოს მუშაობა, რასაც შეიძლება მოულოდნელი შედეგები მოჰყვეს, მაგრამ არ შემოაქვს დაუცველობა, რადგან ეს მხოლოდ უსაფრთხო კოდში ხდება.
///
/// ამასთან, მტკიცებების შესრულების ღირებულება, ზოგადად, არ იზომება.
/// ამრიგად, [`assert!`]- ის `debug_assert!`- ით ჩანაცვლება მხოლოდ სრულყოფილი პროფილირების შემდეგ ხდება, რაც მთავარია, მხოლოდ უსაფრთხო კოდში.
///
/// # Examples
///
/// ```
/// // panic გაგზავნა ამ მტკიცებებისთვის არის მოცემული გამოხატვის სტრიქონული მნიშვნელობა.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // ძალიან მარტივი ფუნქცია
/// debug_assert!(some_expensive_computation());
///
/// // მორგებული შეტყობინების გაგზავნით
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// ამტკიცებს, რომ ორი გამოთქმა ერთმანეთის ტოლია.
///
/// panic-ზე, ეს მაკრო დაბეჭდავს გამონათქვამების მნიშვნელობებს მათი გამართვის წარმოდგენებით.
///
/// [`assert_eq!`]-ისგან განსხვავებით, `debug_assert_eq!` დებულებები ჩართულია მხოლოდ არაოპტიმიზირებულ მშენებლობებში.
/// ოპტიმიზირებული აშენება არ შეასრულებს `debug_assert_eq!` დებულებებს, თუ `-C debug-assertions` არ გადაეცემა შემდგენელს.
/// ეს `debug_assert_eq!` გამოსადეგია იმ შემოწმებისთვის, რომლებიც ძალიან ძვირია გამოსაშვების ფორმაში ყოფნისთვის, მაგრამ შეიძლება სასარგებლო იყოს განვითარების დროს.
///
/// `debug_assert_eq!` გაფართოების შედეგი ყოველთვის შემოწმებულია ტიპის მიხედვით.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// ამტკიცებს, რომ ორი გამოთქმა ერთმანეთის ტოლი არ არის.
///
/// panic-ზე, ეს მაკრო დაბეჭდავს გამონათქვამების მნიშვნელობებს მათი გამართვის წარმოდგენებით.
///
/// [`assert_ne!`]-ისგან განსხვავებით, `debug_assert_ne!` დებულებები ჩართულია მხოლოდ არაოპტიმიზირებულ მშენებლობებში.
/// ოპტიმიზირებული აშენება არ შეასრულებს `debug_assert_ne!` დებულებებს, თუ `-C debug-assertions` არ გადაეცემა შემდგენელს.
/// ეს `debug_assert_ne!` გამოსადეგია იმ შემოწმებისთვის, რომლებიც ძალიან ძვირია გამოსაშვების ფორმაში ყოფნისთვის, მაგრამ შეიძლება სასარგებლო იყოს განვითარების დროს.
///
/// `debug_assert_ne!` გაფართოების შედეგი ყოველთვის შემოწმებულია ტიპის მიხედვით.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// აბრუნებს, ემთხვევა თუ არა მოცემული გამოხატვა მოცემულ შაბლონებს.
///
/// `match` გამოხატვის მსგავსად, ნიმუშს შეიძლება სურვილისამებრ მოჰყვეს `if` და დაცვითი გამოხატვა, რომელსაც აქვს წვდომა შაბლონით შეკრულ სახელებს.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// ხსნის შედეგს ან ავრცელებს მის შეცდომას.
///
/// `?` ოპერატორი დაემატა `try!`-ის ნაცვლად და უნდა იქნას გამოყენებული.
/// გარდა ამისა, `try` დაცულია სიტყვა Rust 2018 - ში, ასე რომ, თუ თქვენ უნდა გამოიყენოთ ეს, თქვენ უნდა გამოიყენოთ [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ემთხვევა მოცემულ [`Result`]-ს.`Ok` ვარიანტის შემთხვევაში, გამოხატვას აქვს შეფუთული მნიშვნელობის მნიშვნელობა.
///
/// `Err` ვარიანტის შემთხვევაში, ის იღებს შინაგან შეცდომას.`try!` შემდეგ ასრულებს გარდაქმნას `From` გამოყენებით.
/// ეს უზრუნველყოფს ავტომატურ გადაკეთებას სპეციალიზირებულ შეცდომებსა და ზოგადად შეცდომებს შორის.
/// შედეგად მიღებული შეცდომა დაუყოვნებლივ დაუბრუნდება.
///
/// ადრეული დაბრუნების გამო, `try!` შეიძლება გამოყენებულ იქნას მხოლოდ იმ ფუნქციებში, რომლებიც დააბრუნებს [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // შეცდომების სწრაფი დაბრუნების სასურველი მეთოდი
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // შეცდომების სწრაფი დაბრუნების წინა მეთოდი
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // ეს ექვივალენტურია:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// წერს ფორმატირებულ მონაცემებს ბუფერში.
///
/// ეს მაკრო იღებს 'writer', ფორმატის სტრიქონს და არგუმენტების ჩამონათვალს.
/// არგუმენტები გაფორმდება მითითებული ფორმატის სტრიქონის შესაბამისად და შედეგი გადაეცემა მწერალს.
/// მწერალი შეიძლება იყოს ნებისმიერი მნიშვნელობა `write_fmt` მეთოდით;ზოგადად, ეს გამომდინარეობს [`fmt::Write`] ან [`io::Write`] trait- ის დანერგვიდან.
/// მაკრო აბრუნებს რასაც `write_fmt` მეთოდი დააბრუნებს;ჩვეულებრივ [`fmt::Result`], ან [`io::Result`].
///
/// ფორმატის სიმების სინტაქსის შესახებ დამატებითი ინფორმაციისთვის იხილეთ [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// მოდულს შეუძლია შემოიტანოს როგორც `std::fmt::Write` და `std::io::Write`, ასევე დაურეკოს `write!` იმ ობიექტებზე, რომლებიც არ ახორციელებენ ორივე.
///
/// ამასთან, მოდულმა უნდა შემოიტანოს traits კვალიფიციური, ასე რომ მათი სახელები არ ეწინააღმდეგება:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // იყენებს fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // იყენებს io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: ეს მაკრო შეიძლება გამოყენებულ იქნას `no_std` პარამეტრებშიც.
/// `no_std` პარამეტრში თქვენ ხართ პასუხისმგებელი კომპონენტების განხორციელების დეტალებზე.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// ფორმატირებული მონაცემები ჩაწერეთ ბუფერებში, ახალი ხაზის დამატება.
///
/// ყველა პლატფორმაზე ახალი ხაზი არის LINE FEED პერსონაჟი (`\n`/`U+000A`) (დამატებითი CARRIAGE RETURN (`\r`/`U+000D`) აღარ არის).
///
/// დამატებითი ინფორმაციისთვის იხილეთ [`write!`].ფორმატის სიმების სინტაქსის შესახებ ინფორმაციისთვის იხილეთ [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// მოდულს შეუძლია შემოიტანოს როგორც `std::fmt::Write` და `std::io::Write`, ასევე დაურეკოს `write!` იმ ობიექტებზე, რომლებიც არ ახორციელებენ ორივე.
/// ამასთან, მოდულმა უნდა შემოიტანოს traits კვალიფიციური, ასე რომ მათი სახელები არ ეწინააღმდეგება:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // იყენებს fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // იყენებს io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// მიუთითებს მიუწვდომელ კოდზე.
///
/// ეს სასარგებლოა ნებისმიერ დროს, როდესაც შემდგენელმა ვერ დაადგინა, რომ ზოგიერთი კოდი მიუწვდომელია.Მაგალითად:
///
/// * შეუსაბამეთ იარაღები დაცვის პირობებთან.
/// * მარყუჟები, რომლებიც დინამიურად წყდება.
/// * იტერატორები, რომლებიც დინამიურად წყვეტენ.
///
/// თუ დადგინდა, რომ კოდი მიუწვდომელია, არასწორი აღმოჩნდა, პროგრამა დაუყოვნებლივ წყდება [`panic!`]- ით.
///
/// ამ მაკროს სახიფათო ანალოგურია [`unreachable_unchecked`] ფუნქცია, რომელიც კოდის მიღწევის შემთხვევაში გამოიწვევს განუსაზღვრელ ქცევას.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// ეს ყოველთვის იქნება [`panic!`].
///
/// # Examples
///
/// შესატყვისი იარაღი:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // შეადგინეთ შეცდომა, თუ კომენტარი გაკეთებულია
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3- ის ერთ - ერთი უღარიბესი დანერგვა
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// მიუთითებს დაუსრულებელ კოდს პანიკით "not implemented" შეტყობინებით.
///
/// ეს საშუალებას აძლევს თქვენს კოდს ჩაწეროს შემოწმება, რაც გამოდგება თუ თქვენ ახდენთ trait- ს პროტოტიპს ან განხორციელებას, რომელიც მოითხოვს მრავალ მეთოდს, რომელთა გამოყენებას არ აპირებთ.
///
/// განსხვავება `unimplemented!`-სა და [`todo!`]-ს შორის არის ის, რომ `todo!` გადმოგვცემს ფუნქციონირების შემდგომ განხორციელებას, ხოლო გაგზავნა არის "not yet implemented", მაგრამ `unimplemented!` არ აკეთებს ასეთ პრეტენზიებს.
/// მისი გზავნილია "not implemented".
/// ასევე ზოგიერთი IDE მონიშნავს `todo!` ს.
///
/// # Panics
///
/// ეს ყოველთვის იქნება [`panic!`], რადგან `unimplemented!` არის სტენოგრამი `panic!`- ისთვის, ფიქსირებული, კონკრეტული შეტყობინებით.
///
/// `panic!`-ის მსგავსად, ამ მაკროსაც აქვს მეორე ფორმა საკუთარი მნიშვნელობების ჩვენებისთვის.
///
/// # Examples
///
/// თქვით, რომ ჩვენ გვაქვს trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// ჩვენ გვინდა, რომ განვახორციელოთ `Foo` 'MyStruct'- სთვის, მაგრამ რატომღაც აზრი აქვს მხოლოდ `bar()` ფუნქციის განხორციელებას.
/// `baz()` და `qux()` მაინც უნდა განისაზღვროს `Foo`- ის დანერგვისას, მაგრამ ჩვენ შეგვიძლია გამოვიყენოთ `unimplemented!` მათ განმარტებებში, რათა ჩვენი კოდი შედგეს.
///
/// ჩვენ ჯერ კიდევ გვინდა, რომ ჩვენი პროგრამა შეჩერდეს გაუთვალისწინებელი მეთოდების მიღწევის შემთხვევაში.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` a `MyStruct`- სთვის აზრი არ აქვს, ამიტომ აქ საერთოდ ლოგიკა არ გვაქვს.
/////
///         // ეს გამოჩნდება "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // ჩვენ გვაქვს გარკვეული ლოგიკა, ჩვენ შეგვიძლია დავუმატოთ შეტყობინება განუხორციელებლად!ჩვენი გამოტოვების ჩვენება.
///         // ეს გამოჩნდება: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// მიუთითებს დაუმთავრებელ კოდზე.
///
/// ეს შეიძლება სასარგებლო იყოს, თუ თქვენ ახდენთ პროტოტიპს და უბრალოდ ეძებთ თქვენი კოდის ტიპაჟირებას.
///
/// განსხვავება [`unimplemented!`]-სა და `todo!`-ს შორის არის ის, რომ `todo!` გადმოგვცემს ფუნქციონირების შემდგომ განხორციელებას და გაგზავნა არის "not yet implemented", `unimplemented!` არ აკეთებს ასეთ პრეტენზიებს.
/// მისი გზავნილია "not implemented".
/// ასევე ზოგიერთი IDE მონიშნავს `todo!` ს.
///
/// # Panics
///
/// ეს ყოველთვის იქნება [`panic!`].
///
/// # Examples
///
/// აქ მოცემულია რამდენიმე მიმდინარე კოდის მაგალითი.ჩვენ გვაქვს trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// ჩვენ გვინდა, რომ `Foo` განვახორციელოთ ჩვენს ერთ - ერთ ტიპზე, მაგრამ ჯერ მხოლოდ `bar()`- ზე გვინდა მუშაობა.იმისათვის, რომ ჩვენი კოდი შედგეს, ჩვენ უნდა განვახორციელოთ `baz()`, ასე რომ შეგვიძლია გამოვიყენოთ `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // განხორციელება აქ მიდის
///     }
///
///     fn baz(&self) {
///         // მოდით არ ინერვიულოთ baz()- ის დანერგვაზე
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ჩვენ არც კი ვიყენებთ baz()-ს, ასე რომ, ეს კარგადაა.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// ჩამონტაჟებული მაკროების განმარტება.
///
/// მაკრო თვისებების უმეტესი ნაწილი (სტაბილურობა, ხილვადობა და ა.შ.) აღებულია აქ მოცემული კოდისგან, გარდა გაფართოების ფუნქციებისა, რომლებიც მაკრონაწარმოქმნის შედეგებს გარდაქმნიან, ამ ფუნქციებს უზრუნველყოფს შემდგენელი.
///
///
pub(crate) mod builtin {

    /// იწვევს კომპილაციის წარუმატებლობას მოცემული შეცდომის შეტყობინებასთან დაკავშირებით.
    ///
    /// ეს მაკრო უნდა იქნას გამოყენებული, როდესაც crate იყენებს პირობითი შედგენის სტრატეგიას, შეცდომის პირობებში უკეთესი შეცდომების შეტყობინებების მისაცემად.
    ///
    /// ეს არის შემდგენლის დონის [`panic!`] ფორმა, მაგრამ გამოაქვეყნებს შეცდომას *შედგენის დროს და არა* შესრულების დროს *.
    ///
    /// # Examples
    ///
    /// ორი ასეთი მაგალითია მაკრო და `#[cfg]` გარემო.
    ///
    /// გამოაქვეყნეთ შემდგენლის უკეთესი შეცდომა, თუ მაკრო არასწორი მნიშვნელობებია გადაცემული.
    /// საბოლოო branch- ს გარეშე, შემდგენელი მაინც გამოყოფს შეცდომას, მაგრამ შეცდომის შეტყობინებაში არ იქნება ნახსენები ორი მოქმედი მნიშვნელობა.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// გამოაქვეყნეთ შემდგენლის შეცდომა, თუ რიგი თვისებებიდან ერთი მიუწვდომელია.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// აყალიბებს პარამეტრებს სიმების ფორმატირების სხვა მაკროებისთვის.
    ///
    /// ეს მაკრო ფუნქციონირებს სტრიქონის პირდაპირი მნიშვნელობით, რომელიც შეიცავს `{}` თითოეულ დამატებით არგუმენტს.
    /// `format_args!` ამზადებს დამატებით პარამეტრებს, რათა უზრუნველყოს გამომავალი ტექსტის ინტერპრეტაცია და არგუმენტების კანონიზირება ერთ ტიპად.
    /// ნებისმიერი მნიშვნელობა, რომელიც ახორციელებს [`Display`] trait-ს, შეიძლება გადაეცეს `format_args!`-ს, ისევე როგორც ნებისმიერი [`Debug`] განხორციელება გადადის `{:?}`-ს ფორმატირების სტრიქონში.
    ///
    ///
    /// ეს მაკრო ქმნის [`fmt::Arguments`] ტიპის მნიშვნელობას.ეს მნიშვნელობა შეიძლება გადაეცეს მაკროებს [`std::fmt`] ფარგლებში სასარგებლო გადამისამართების შესასრულებლად.
    /// ყველა სხვა ფორმატირების მაკრო (["ფორმატი!"], [`write!`], [`println!`] და ა.შ.) პროქსირებულია ამ ერთის საშუალებით.
    /// `format_args!`, განსხვავებით მისი წარმოქმნილი მაკროსისგან, თავს არიდებს გროვების გამოყოფას.
    ///
    /// შეგიძლიათ გამოიყენოთ [`fmt::Arguments`] მნიშვნელობა, რომელსაც `format_args!` დააბრუნებს `Debug` და `Display` კონტექსტებში, როგორც ჩანს ქვემოთ.
    /// მაგალითში ასევე ნაჩვენებია, რომ `Debug` და `Display` ფორმატში იგივეა: ინტერპოლირებული ფორმატის სტრიქონი `format_args!`-ში.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// დამატებითი ინფორმაციისთვის იხილეთ დოკუმენტაცია [`std::fmt`]-ში.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// იგივეა, რაც `format_args`, მაგრამ ბოლოს დაამატებს ახალ ხაზს.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// შეამოწმებს გარემოს ცვლადს შედგენის დროს.
    ///
    /// ეს მაკრო გაფართოვდება კომპილირების დროს დასახელებული გარემოს ცვლადის მნიშვნელობამდე და გამოიღებს `&'static str` ტიპის გამოხატვას.
    ///
    ///
    /// თუ არ არის განსაზღვრული გარემოს ცვლადი, მაშინ გამოიყოფა შედგენის შეცდომა.
    /// კომპილირების შეცდომა რომ არ გამოვყოთ, ნაცვლად გამოიყენეთ [`option_env!`] მაკრო.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// შეცდომის შეტყობინების მორგება შეგიძლიათ სტრიქონის მეორე პარამეტრად გავლით:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// თუ `documentation` გარემოს ცვლადი არ არის განსაზღვრული, თქვენ მიიღებთ შემდეგ შეცდომას:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// სურვილისამებრ ამოწმებს გარემოს ცვლადს შედგენის დროს.
    ///
    /// თუ კომპილაციის დროს იმყოფება გარემოს დასახელებული ცვლადი, ეს გაფართოვდება `Option<&'static str>` ტიპის გამოხატულებაში, რომლის მნიშვნელობაა `Some` გარემო ცვლადის მნიშვნელობიდან.
    /// თუ გარემოს ცვლადი არ არის, მაშინ ის გაფართოვდება `None`- მდე.
    /// იხილეთ [`Option<T>`][Option] ამ ტიპის შესახებ დამატებითი ინფორმაციისთვის.
    ///
    /// ამ მაკროს გამოყენებისას კომპილირების დროის შეცდომა არასდროს გამოიყოფა, მიუხედავად იმისა, არის თუ არა გარემოში ცვლადი.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// იდენტიფიკატორებს აერთიანებს ერთ იდენტიფიკატორად.
    ///
    /// ეს მაკრო იღებს მძიმით გამოყოფილ იდენტიფიკატორთა რაოდენობის რაოდენობას და აერთიანებს მათ ყველას ერთში, იძლევა გამოთქმას, რომელიც წარმოადგენს ახალ იდენტიფიკატორს.
    /// გაითვალისწინეთ, რომ ჰიგიენა ხდის მას ისე, რომ ამ მაკროს არ შეუძლია ადგილობრივი ცვლადების აღება.
    /// ასევე, როგორც წესი, მაკროები დაშვებულია მხოლოდ პუნქტში, განცხადებაში ან გამოხატვის პოზიციაში.
    /// ეს ნიშნავს, რომ სანამ შეგიძლიათ გამოიყენოთ ეს მაკრო არსებული ცვლადების, ფუნქციების ან მოდულების მითითებით და ა.შ., მასთან ერთად ახლის განსაზღვრა არ შეგიძლიათ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (ახალი, სახალისო, სახელი) { }//არ გამოდგება ამ გზით!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// აერთიანებს ლიტერატურას სტატიკურ სიმებიან ნაჭრებად.
    ///
    /// ეს მაკრო იღებს მძიმით გამოყოფილ ნებისმიერი რაოდენობის ლიტერატურას, იძლევა `&'static str` ტიპის გამოხატულებას, რომელიც წარმოადგენს მარცხნიდან მარჯვნივ მარჯვნივ შერწყმულ ყველა ლიტერატურას.
    ///
    ///
    /// მთელი და მცურავი წერტილის ასოები სიმებიანი ხდება, რომ გაერთიანდეს.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ვრცელდება ხაზის ნომერზე, რომელზეც იგი გამოძახებულია.
    ///
    /// [`column!`] და [`file!`]- ით ეს მაკროები უზრუნველყოფენ დეველოპერებს გამართვის შესახებ ინფორმაციის წყაროს მდებარეობის შესახებ.
    ///
    /// გაფართოებულ გამოხატვას აქვს `u32` ტიპი და დაფუძნებულია 1-ზე, ამიტომ თითოეულ ფაილში პირველი სტრიქონი აფასებს 1-ს, მეორე-2-ს და ა.შ.
    /// ეს შეესაბამება ჩვეულებრივი შემდგენლების ან პოპულარული რედაქტორების შეცდომების შეტყობინებებს.
    /// დაბრუნებული სტრიქონი *სულაც არ არის*`line!` გამოძახების ხაზი, არამედ პირველი მაკრო გამოძახება `line!` მაკროს გამოძახებამდე.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// აფართოებს სვეტის ნომერს, რომელზეც იგი იქნა გამოძახებული.
    ///
    /// [`line!`] და [`file!`]- ით ეს მაკროები უზრუნველყოფენ დეველოპერებს გამართვის შესახებ ინფორმაციის წყაროს მდებარეობის შესახებ.
    ///
    /// გაფართოებულ გამოხატვას აქვს `u32` ტიპი და დაფუძნებულია 1-ზე, ამიტომ თითოეულ სტრიქონში პირველი სვეტი აფასებს 1-ს, მეორე-2-ს და ა.შ.
    /// ეს შეესაბამება ჩვეულებრივი შემდგენლების ან პოპულარული რედაქტორების შეცდომების შეტყობინებებს.
    /// დაბრუნებული სვეტი *სულაც არ არის* თვით `column!` გამოძახების ხაზი, არამედ პირველი მაკრო გამოძახება, რომელიც იწვევს `column!` მაკროს მოწოდებას.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// აფართოებს ფაილის სახელს, რომელშიც ის გამოძახებულია.
    ///
    /// [`line!`] და [`column!`]- ით ეს მაკროები უზრუნველყოფენ დეველოპერებს გამართვის შესახებ ინფორმაციის წყაროს მდებარეობის შესახებ.
    ///
    /// გაფართოებულ გამოხატვას აქვს `&'static str` ტიპი და დაბრუნებული ფაილი არ არის `file!` მაკრო თავის მოწოდება, არამედ ეს არის პირველი მაკრო გამოძახება, რომელიც იწვევს `file!` მაკროს მოწოდებას.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// სტრიქონულად აყალიბებს თავის არგუმენტებს.
    ///
    /// ეს მაკრო გამოიღებს `&'static str` ტიპის გამოხატულებას, რომელიც წარმოადგენს tokens- ის მაკროზე გადასვლის სტრიქონს.
    /// არანაირი შეზღუდვა არ არის დაწესებული თვით მაკრო მოწვევის სინტაქსზე.
    ///
    /// გაითვალისწინეთ, რომ tokens შეყვანის გაფართოებული შედეგები შეიძლება შეიცვალოს future-ში.ფრთხილად უნდა იყოთ, თუ შედეგს დაეყრდნობით.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// მოიცავს UTF-8 კოდირებულ ფაილს სიმებად.
    ///
    /// ფაილი მდებარეობს ამჟამინდელ ფაილთან შედარებით (ანალოგიურად, თუ როგორ გვხვდება მოდულები).
    /// მოცემული გზა ინტერპრეტირდება პლატფორმის სპეციფიკური გზით, შედგენის დროს.
    /// მაგალითად, Windows ბილიკის გამოძახება, რომელიც შეიცავს უკანა ხაზებს `\`, არ შედგებოდა სწორად Unix-ზე.
    ///
    ///
    /// ეს მაკრო მიიღებს `&'static str` ტიპის გამოხატვას, რომელიც არის ფაილის შინაარსი.
    ///
    /// # Examples
    ///
    /// დავუშვათ, რომ იმავე დირექტორიაში ორი ფაილია შემდეგი შინაარსით:
    ///
    /// ფაილი 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ფაილი 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' შედგენა და შედეგად ორობითი სისტემის გაშვება დაბეჭდავს "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// მოიცავს ფაილს, როგორც მითითება ბაიტის მასივზე.
    ///
    /// ფაილი მდებარეობს ამჟამინდელ ფაილთან შედარებით (ანალოგიურად, თუ როგორ გვხვდება მოდულები).
    /// მოცემული გზა ინტერპრეტირდება პლატფორმის სპეციფიკური გზით, შედგენის დროს.
    /// მაგალითად, Windows ბილიკის გამოძახება, რომელიც შეიცავს უკანა ხაზებს `\`, არ შედგებოდა სწორად Unix-ზე.
    ///
    ///
    /// ეს მაკრო მიიღებს `&'static [u8; N]` ტიპის გამოხატვას, რომელიც არის ფაილის შინაარსი.
    ///
    /// # Examples
    ///
    /// დავუშვათ, რომ იმავე დირექტორიაში ორი ფაილია შემდეგი შინაარსით:
    ///
    /// ფაილი 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ფაილი 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' შედგენა და შედეგად ორობითი სისტემის გაშვება დაბეჭდავს "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ვრცელდება სტრიქონზე, რომელიც წარმოადგენს მიმდინარე მოდულის გზას.
    ///
    /// მიმდინარე მოდულის გზა შეიძლება მივიჩნიოთ, როგორც მოდულების იერარქია, რომლებიც უკან მიდიან crate root-მდე.
    /// დაბრუნებული გეზის პირველი კომპონენტი არის ამჟამად შედგენილ crate-ის სახელი.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// აფასებს კონფიგურაციის დროშების ლოგიკურ კომბინაციებს კომპილირების დროს.
    ///
    /// `#[cfg]` ატრიბუტის გარდა, ეს მაკრო მოცემულია კონფიგურაციის დროშების ლოგიკური გამოხატვის შეფასების დასაშვებად.
    /// ეს ხშირად იწვევს ნაკლებად დუბლირებულ კოდს.
    ///
    /// ამ მაკროსთვის მინიჭებული სინტაქსი იგივე სინტაქსია, როგორც [`cfg`] ატრიბუტი.
    ///
    /// `cfg!`, `#[cfg]`-ისგან განსხვავებით, არ ხსნის რაიმე კოდს და აფასებს მხოლოდ ჭეშმარიტს ან მცდარს.
    /// მაგალითად, if/else გამოხატვის ყველა ბლოკი უნდა იყოს მოქმედი, როდესაც `cfg!` გამოიყენება მდგომარეობისთვის, იმისდა მიუხედავად, რას აფასებს `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// აანალიზებს ფაილს, როგორც გამონათქვამს ან ერთეულს, კონტექსტის შესაბამისად.
    ///
    /// ფაილი მდებარეობს ამჟამინდელ ფაილთან შედარებით (ანალოგიურად, თუ როგორ გვხვდება მოდულები).მოცემული გზა ინტერპრეტირდება პლატფორმის სპეციფიკური გზით, შედგენის დროს.
    /// მაგალითად, Windows ბილიკის გამოძახება, რომელიც შეიცავს უკანა ხაზებს `\`, არ შედგებოდა სწორად Unix-ზე.
    ///
    /// ამ მაკროს გამოყენება ხშირად ცუდი იდეაა, რადგან თუ ფაილი გაანალიზდება, როგორც გამოხატვა, იგი არაჰიგიენურად მოთავსდება მიმდებარე კოდში.
    /// ამან შეიძლება გამოიწვიოს ცვლადების ან ფუნქციების სხვაობა იმისა, რასაც ფაილი მოელოდა, თუ არსებობს ცვლადები ან ფუნქციები, რომლებსაც მიმდინარე ფაილში იგივე სახელი აქვთ.
    ///
    ///
    /// # Examples
    ///
    /// დავუშვათ, რომ იმავე დირექტორიაში ორი ფაილია შემდეგი შინაარსით:
    ///
    /// ფაილი 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// ფაილი 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' შედგენა და შედეგად ორობითი სისტემის გაშვება დაბეჭდავს "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ამტკიცებს, რომ ლოგიკური გამონათქვამი `true` ა შესრულების დროს.
    ///
    /// ეს გამოიწვევს [`panic!`] მაკროს, თუ მითითებული გამოხატვის შეფასება შეუძლებელია `true`- ით შესრულების დროს.
    ///
    /// # Uses
    ///
    /// მტკიცებები ყოველთვის შემოწმდება როგორც გამართვის, ასევე გამოშვების აგებულებებში და მათი გამორთვა შეუძლებელია.
    /// იხილეთ [`debug_assert!`] იმ მტკიცებებისთვის, რომლებიც ნაგულისხმევად არ არის ჩართული გამოშვების სტრუქტურებში.
    ///
    /// არასაიმედო კოდი შეიძლება ეყრდნობოდეს `assert!`-ს გამეორების დროს ინვალიანების აღსასრულებლად, რომელთა დარღვევის შემთხვევაში შეიძლება დაუცველობა გამოიწვიოს.
    ///
    /// `assert!`- ის გამოყენების სხვა შემთხვევებში შედის უსაფრთხო კოდში ინვალიანთა ტესტირება და დაცვა (რომელთა დარღვევამ არ შეიძლება გამოიწვიოს უსაფრთხოება).
    ///
    ///
    /// # მორგებული შეტყობინებები
    ///
    /// ამ მაკროს აქვს მეორე ფორმა, სადაც შესაძლებელია panic შეტყობინების გაგზავნა ფორმატის არგუმენტებით ან მის გარეშე.
    /// ამ ფორმისთვის იხილეთ სინტაქსი [`std::fmt`].
    /// ფორმატის არგუმენტად გამოყენებული გამონათქვამები შეფასდება მხოლოდ იმ შემთხვევაში, თუ მტკიცება ვერ მოხერხდება.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // panic გაგზავნა ამ მტკიცებებისთვის არის მოცემული გამოხატვის სტრიქონული მნიშვნელობა.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // ძალიან მარტივი ფუნქცია
    ///
    /// assert!(some_computation());
    ///
    /// // მორგებული შეტყობინების გაგზავნით
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// ხაზოვანი შეკრება.
    ///
    /// წაიკითხეთ [unstable book] გამოყენებისათვის.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM სტილის ხაზოვანი აწყობა.
    ///
    /// წაიკითხეთ [unstable book] გამოყენებისათვის.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// მოდულის დონის ხაზოვანი აწყობა.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// ბეჭდავს tokens გადაჰქონდა სტანდარტული გამომავალი.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ჩართავს ან გათიშავს მიკვლევის ფუნქციონირებას, რომელიც გამოიყენება სხვა მაკროების გამოსწორების მიზნით.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// ატრიბუტი მაკრო, რომელიც გამოიყენება წარმოებული მაკროს გამოყენებისთვის.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// ფუნქციისთვის გამოყენებულია ატრიბუტის მაკრო, რომელიც უნდა იქცეს ერთეულის ტესტად.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// ატრიბუტის მაკრო გამოიყენეს ფუნქციას, რომ იგი საორიენტაციო ტესტად იქცეს.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` და `#[bench]` მაკროების დანერგვის დეტალი.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// ატრიბუტის მაკრო მიმართა სტატიკას, რომ იგი დარეგისტრირდეს როგორც გლობალური გამანაწილებელი.
    ///
    /// აგრეთვე [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// ინახავს ნივთს, რომელზეც გამოიყენება, თუ გავლილი გზა მიუწვდომელია და სხვაგვარად ხსნის მას.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// აფართოებს ყველა `#[cfg]` და `#[cfg_attr]` ატრიბუტებს კოდის ფრაგმენტში, რომელშიც ის გამოიყენება.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` შემდგენელის არასტაბილური დანერგვის დეტალი, არ გამოიყენოთ.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` შემდგენელის არასტაბილური დანერგვის დეტალი, არ გამოიყენოთ.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}