//! პერსონაჟის გარდაქმნა.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32`-ს გარდაქმნის `char`-ზე.
///
/// გაითვალისწინეთ, რომ ყველა [`char`] მართებულია [`u32`] s და მათი ერთზე გადატანა შესაძლებელია
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ამასთან, პირიქით არ არის სიმართლე: ყველა მოქმედი [`u32`] s არ არის მართებული [`char`] s.
/// `from_u32()` დააბრუნებს `None` თუ შეყვანა არ არის სწორი მნიშვნელობა [`char`]- ისთვის.
///
/// ამ ფუნქციის არასაიმედო ვერსიისთვის, რომელიც უგულებელყოფს ამ შემოწმებებს, იხილეთ [`from_u32_unchecked`].
///
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// `None` დაბრუნებისას, როდესაც შეყვანა არ არის სწორი [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// `u32`- ს გარდაქმნის `char`- ზე, უგულებელყოფს მოქმედებას.
///
/// გაითვალისწინეთ, რომ ყველა [`char`] მართებულია [`u32`] s და მათი ერთზე გადატანა შესაძლებელია
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ამასთან, პირიქით არ არის სიმართლე: ყველა მოქმედი [`u32`] s არ არის მართებული [`char`] s.
/// `from_u32_unchecked()` ამას უგულებელყოფს და ბრმად მიაქცევს [`char`]-ს, შესაძლოა შექმნას არასწორი.
///
///
/// # Safety
///
/// ეს ფუნქცია არ არის უსაფრთხო, რადგან მას შეუძლია შექმნას არასწორი `char` მნიშვნელობები.
///
/// ამ ფუნქციის უსაფრთხო ვერსიისთვის იხილეთ [`from_u32`] ფუნქცია.
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `i` არის სწორი ნახშირბადის მნიშვნელობა.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`]-ს გარდაქმნის [`u32`]-ში.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`]-ს გარდაქმნის [`u64`]-ში.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ნახშირი აისახება კოდის წერტილის მნიშვნელობამდე, შემდეგ ნულოვანი გახდება 64 ბიტი.
        // იხილეთ [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`]-ს გარდაქმნის [`u128`]-ში.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ნახშირბადის კოპირება ხდება კოდის წერტილის მნიშვნელობამდე, შემდეგ ნულოვანი გახანგრძლივება 128 ბიტზე.
        // იხილეთ [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// ასახავს ბაიტს 0x00 ..=0xFF `char`- მდე, რომლის კოდურ წერტილს აქვს იგივე მნიშვნელობა, U + 0000 ..=U + 00FF.
///
/// უნიკოდი შექმნილია ისე, რომ ეს ეფექტურად იშიფრებს ბაიტებს იმ პერსონაჟის კოდირებით, რომელსაც IANA მოუწოდებს ISO-8859-1.
/// ეს კოდირება თავსებადია ASCII- ს.
///
/// გაითვალისწინეთ, რომ ეს განსხვავდება ISO/IEC 8859-1 aka- სგან
/// ISO 8859-1 (ერთი ნაკლები დეფისით), რომელიც ტოვებს ზოგიერთ "blanks", ბაიტის მნიშვნელობებს, რომლებიც არ არის მინიჭებული რაიმე სიმბოლოზე.
/// ISO-8859-1 (IANA) ანიჭებს მათ C0 და C1 კონტროლის კოდებს.
///
/// გაითვალისწინეთ, რომ ეს *ასევე* განსხვავდება Windows-1252 aka- სგან
/// კოდი გვერდი 1252, რომელიც არის სუპერსიტი ISO/IEC 8859-1, რომელიც რამდენიმე (არა ყველა!) ბლანკს ანიჭებს პუნქტუაციას და ლათინურ სიმბოლოებს.
///
/// საგნების შემდგომი აღრევის მიზნით, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` და `windows-1252` არის მეტსახელი Windows-1252 სუპერკომპანიისთვის, რომელიც ავსებს დანარჩენ ბლანკებს შესაბამისი C0 და C1 კონტროლის კოდებით.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`]-ს გარდაქმნის [`char`]-ში.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// შეცდომა, რომლის დაბრუნებაც შესაძლებელია ნაწილის ანალიზისას.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // უსაფრთხოება: შეამოწმა, რომ ეს არის იურიდიული უნიკოდის მნიშვნელობა
            Ok(unsafe { transmute(i) })
        }
    }
}

/// შეცდომის ტიპი დაბრუნდა, როდესაც u32-დან ნახშირზე გადაყვანა ვერ მოხერხდა.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// მოცემულ რადიქსში ციფრს `char`-ად აქცევს.
///
/// 'radix'-ს აქ ზოგჯერ 'base'-ს უწოდებენ.
/// ორი რადიქსი მიუთითებს ორობითი რიცხვი, ათი რადიქსი, ათობითი და თექვსმეტი რადიქსი, თექვსმეტობითი, რომ მისცეს ზოგიერთი საერთო მნიშვნელობა.
///
/// თვითნებური რადიუსი მხარს უჭერს.
///
/// `from_digit()` დააბრუნებს `None` თუ შეყვანა არ არის მოცემული რადიქსის ციფრი.
///
/// # Panics
///
/// Panics თუ მოცემულია 36-ზე მეტი რადიქსი.
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // ათწილადი 11 არის ერთნიშნა რიცხვი 16 ბაზაში
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// `None` დაბრუნებისას, როდესაც შეყვანა არ არის ციფრი:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// დიდი რადიქსის გავლით, რომელიც იწვევს panic-ს:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}