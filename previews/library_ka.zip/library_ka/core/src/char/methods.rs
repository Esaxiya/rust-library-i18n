//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char`- ის უმაღლესი მოქმედი კოდის წერტილი შეიძლება ჰქონდეს.
    ///
    /// `char` არის [Unicode Scalar Value], რაც ნიშნავს, რომ ის არის [Code Point], მაგრამ მხოლოდ ის, ვინც გარკვეულ დიაპაზონშია.
    /// `MAX` არის უმაღლესი მოქმედი კოდის წერტილი, რომელიც მოქმედებს [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () გამოიყენება უნიკოდში დეკოდირების შეცდომის წარმოსადგენად.
    ///
    /// ეს შეიძლება მოხდეს, მაგალითად, ცუდად ფორმირებული UTF-8 ბაიტის [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy)-სთვის მიცემისას.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/) ის ვერსია, რომელსაც ემყარება `char` და `str` მეთოდების უნიკოდის ნაწილები.
    ///
    /// Unicode- ის ახალი ვერსიები რეგულარულად გამოიცემა და შემდეგ განახლდება ყველა მეთოდი სტანდარტულ ბიბლიოთეკაში, რაც დამოკიდებულია Unicode- ზე.
    /// ამიტომ ზოგიერთი `char` და `str` მეთოდების ქცევა და ამ მუდმივის მნიშვნელობა დროთა განმავლობაში იცვლება.
    /// ეს * არ მიიჩნევა დამანგრეველ ცვლილებად.
    ///
    /// ვერსიების ნუმერაციის სქემა განმარტებულია [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// ქმნის იტერატორს UTF-16 კოდირებულ კოდურ წერტილებზე `iter`-ში, უბრუნებს დაწყვილებულ სუროგატებს `Err`.
    ///
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// დანაკარგის დეკოდერის მიღება შესაძლებელია `Err` შედეგების ჩანაცვლების სიმბოლოთი ჩანაცვლებით:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32`-ს გარდაქმნის `char`-ზე.
    ///
    /// გაითვალისწინეთ, რომ ყველა `char`-ის მოქმედი [`u32`] s არის და მათი გამოყენება შესაძლებელია ერთზე
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ამის საწინააღმდეგო არ არის სიმართლე: ყველა მოქმედი [`u32`] არ არის მართებული`char`.
    /// `from_u32()` დააბრუნებს `None` თუ შეყვანა არ არის სწორი მნიშვნელობა `char`- ისთვის.
    ///
    /// ამ ფუნქციის არასაიმედო ვერსიისთვის, რომელიც უგულებელყოფს ამ შემოწმებებს, იხილეთ [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// `None` დაბრუნებისას, როდესაც შეყვანა არ არის სწორი `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// `u32`- ს გარდაქმნის `char`- ზე, უგულებელყოფს მოქმედებას.
    ///
    /// გაითვალისწინეთ, რომ ყველა `char`-ის მოქმედი [`u32`] s არის და მათი გამოყენება შესაძლებელია ერთზე
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ამის საწინააღმდეგო არ არის სიმართლე: ყველა მოქმედი [`u32`] არ არის მართებული`char`.
    /// `from_u32_unchecked()` ამას უგულებელყოფს და ბრმად მიაქცევს `char`-ს, შესაძლოა შექმნას არასწორი.
    ///
    ///
    /// # Safety
    ///
    /// ეს ფუნქცია არ არის უსაფრთხო, რადგან მას შეუძლია შექმნას არასწორი `char` მნიშვნელობები.
    ///
    /// ამ ფუნქციის უსაფრთხო ვერსიისთვის იხილეთ [`from_u32`] ფუნქცია.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // უსაფრთხოება: უსაფრთხოების ხელშეკრულება აბონენტის მიერ უნდა დაიცვას.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// მოცემულ რადიქსში ციფრს `char`-ად აქცევს.
    ///
    /// 'radix'-ს აქ ზოგჯერ 'base'-ს უწოდებენ.
    /// ორი რადიქსი მიუთითებს ორობითი რიცხვი, ათი რადიქსი, ათობითი და თექვსმეტი რადიქსი, თექვსმეტობითი, რომ მისცეს ზოგიერთი საერთო მნიშვნელობა.
    ///
    /// თვითნებური რადიუსი მხარს უჭერს.
    ///
    /// `from_digit()` დააბრუნებს `None` თუ შეყვანა არ არის მოცემული რადიქსის ციფრი.
    ///
    /// # Panics
    ///
    /// Panics თუ მოცემულია 36-ზე მეტი რადიქსი.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // ათწილადი 11 არის ერთნიშნა რიცხვი 16 ბაზაში
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// `None` დაბრუნებისას, როდესაც შეყვანა არ არის ციფრი:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// დიდი რადიქსის გავლით, რომელიც იწვევს panic-ს:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// ამოწმებს, არის თუ არა `char` ციფრი მოცემულ რადიქსში.
    ///
    /// 'radix'-ს აქ ზოგჯერ 'base'-ს უწოდებენ.
    /// ორი რადიქსი მიუთითებს ორობითი რიცხვი, ათი რადიქსი, ათობითი და თექვსმეტი რადიქსი, თექვსმეტობითი, რომ მისცეს ზოგიერთი საერთო მნიშვნელობა.
    ///
    /// თვითნებური რადიუსი მხარს უჭერს.
    ///
    /// [`is_numeric()`]-თან შედარებით, ეს ფუნქცია მხოლოდ ცნობს `0-9`, `a-z` და `A-Z` სიმბოლოებს.
    ///
    /// 'Digit' განისაზღვრება მხოლოდ შემდეგი სიმბოლოებით:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit'- ის უფრო სრულყოფილი გაგებისთვის იხილეთ [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics თუ მოცემულია 36-ზე მეტი რადიქსი.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// დიდი რადიქსის გავლით, რომელიც იწვევს panic-ს:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// გარდაქმნის `char` ციფრს მოცემულ რადიქსში.
    ///
    /// 'radix'-ს აქ ზოგჯერ 'base'-ს უწოდებენ.
    /// ორი რადიქსი მიუთითებს ორობითი რიცხვი, ათი რადიქსი, ათობითი და თექვსმეტი რადიქსი, თექვსმეტობითი, რომ მისცეს ზოგიერთი საერთო მნიშვნელობა.
    ///
    /// თვითნებური რადიუსი მხარს უჭერს.
    ///
    /// 'Digit' განისაზღვრება მხოლოდ შემდეგი სიმბოლოებით:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// აბრუნებს `None`-ს, თუ `char` არ ეხება მოცემულ რადიქსში მყოფ ციფრს.
    ///
    /// # Panics
    ///
    /// Panics თუ მოცემულია 36-ზე მეტი რადიქსი.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// არაციფრის გავლის შედეგია მარცხი:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// დიდი რადიქსის გავლით, რომელიც იწვევს panic-ს:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // კოდი გაყოფილია აქ შესრულების სიჩქარის გასაუმჯობესებლად იმ შემთხვევებში, როდესაც `radix` არის მუდმივი და 10 ან ნაკლები
        //
        let val = if likely(radix <= 10) {
            // თუ არ არის ციფრი, შეიქმნება რადიქსზე მეტი რიცხვი.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// აბრუნებს იტერატორს, რომელიც იძლევა hexadecimal Unicode გაქცევას პერსონაჟის როგორც `char`.
    ///
    /// ეს გაურბის სიმბოლოს Rust ფორმის `\u{NNNNNN}` სიმბოლოს, სადაც `NNNNNN` არის თექვსმეტობითი გამოსახვა.
    ///
    ///
    /// # Examples
    ///
    /// როგორც იტერატორი:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` პირდაპირ გამოყენება:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// ორივე ეკვივალენტურია:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string`- ის გამოყენება:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // ან-1 უზრუნველყოფს c==0 კოდის გამოთვლას, რომ ერთი ციფრი უნდა დაბეჭდეს და (რაც იგივეა) თავიდან აცილებას (31, 32) დაქვემდებარებაში
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ყველაზე მნიშვნელოვანი თექვსმეტი ციფრის ინდექსი
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug` გაფართოებული ვერსია, რომელიც სურვილისამებრ იძლევა გაფართოებული გრაფემის კოდირების წერტილების გაქცევას.
    /// ეს საშუალებას გვაძლევს უკეთესად გავაფორმოთ სიმბოლოები, როგორიცაა არასასურველი ნიშნები, როდესაც ისინი სტრიქონის დასაწყისში არიან.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// აბრუნებს იტერატორს, რომელიც იძლევა სიმბოლოს სიტყვასიტყვით გაქცევის კოდს, როგორც `char`.
    ///
    /// ეს გაექცევა `str` ან `char` `Debug` დანერგვის მსგავსი სიმბოლოებისგან.
    ///
    ///
    /// # Examples
    ///
    /// როგორც იტერატორი:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` პირდაპირ გამოყენება:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// ორივე ეკვივალენტურია:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string`- ის გამოყენება:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// აბრუნებს იტერატორს, რომელიც იძლევა სიმბოლოს სიტყვასიტყვით გაქცევის კოდს, როგორც `char`.
    ///
    /// ნაგულისხმევი ვარიანტი აირჩევა სხვადასხვა ენაზე იურიდიული ლიტერატურის წარმოებისადმი მიკერძოებით, მათ შორის C++ 11 და მსგავსი C-ოჯახის ენებზე.
    /// ზუსტი წესებია:
    ///
    /// * ჩანართი გაქცეულია, როგორც `\t`.
    /// * ვაგონის დაბრუნება გაქცეულია, როგორც `\r`.
    /// * ხაზის სიხშირე გაიქცა როგორც `\n`.
    /// * ერთი ციტირება გაქცეულია, როგორც `\'`.
    /// * ორმაგი ციტირება გაქცეულია, როგორც `\"`.
    /// * უკანა ხაზი გაქცეულია, როგორც `\\`.
    /// * "დასაბეჭდი ASCII" დიაპაზონის `0x20` .. `0x7e` ჩათვლით ნებისმიერი სიმბოლო არ გაექცევა.
    /// * ყველა სხვა სიმბოლოს ეძლევა თექვსმეტობითი უნიკოდის გაქცევა;იხილეთ [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// როგორც იტერატორი:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` პირდაპირ გამოყენება:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// ორივე ეკვივალენტურია:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string`- ის გამოყენება:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// აბრუნებს ამ `char`-ს ბაიტის რაოდენობას, თუ იგი კოდირებულია UTF-8-ში.
    ///
    /// ეს ბაიტი ყოველთვის არის 1-დან 4-მდე, მათ შორის.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` ტიპის გარანტიას იძლევა, რომ მისი შინაარსი UTF-8 არის და, ასე რომ, ჩვენ შეგვიძლია შევადაროთ ის სიგრძე, რომელიც დაგვჭირდებოდა, თუ თითოეული კოდი წერტილი წარმოდგენილი იქნებოდა `char` vs `&str`- ში:
    ///
    ///
    /// ```
    /// // როგორც სიმბოლოები
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ორივე შეიძლება წარმოდგენილი იყოს როგორც სამი ბაიტი
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // როგორც &str, ეს ორი კოდირებულია UTF-8-ში
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // ვხედავთ, რომ ისინი სულ ექვს ბაიტს იღებენ ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... ისევე, როგორც &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// აბრუნებს 16 ბიტიანი კოდის ერთეულების რაოდენობას, რაც ამ `char`- ს დასჭირდება, თუ კოდირებულია UTF-16- ში.
    ///
    ///
    /// იხილეთ [`len_utf8()`] დოკუმენტაცია ამ კონცეფციის მეტი განმარტებისთვის.
    /// ეს ფუნქცია არის სარკე, მაგრამ UTF-16- ის ნაცვლად UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// კოდირებს ამ სიმბოლოს, როგორც UTF-8, მოცემულ ბაიტის ბუფერში და შემდეგ აბრუნებს ბუფერის ქვედა ნაწილს, რომელიც შეიცავს კოდირებულ სიმბოლოს.
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ ბუფერი არ არის საკმარისად დიდი.
    /// ოთხი სიგრძის ბუფერი საკმარისად დიდია ნებისმიერი `char` კოდირებისთვის.
    ///
    /// # Examples
    ///
    /// ორივე ამ მაგალითში, 'ß' იღებს ორ ბაიტს კოდირებისთვის.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// ძალიან მცირე ზომის ბუფერი:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // უსაფრთხოება: `char` არ არის სუროგატი, ამიტომ ეს მოქმედებს UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// კოდირებს ამ სიმბოლოს როგორც UTF-16 მოწოდებულ `u16` ბუფერში და შემდეგ აბრუნებენ ბუფერის ქვესახეებს, რომელიც შეიცავს კოდირებულ სიმბოლოს.
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ ბუფერი არ არის საკმარისად დიდი.
    /// 2 სიგრძის ბუფერი საკმარისად დიდია ნებისმიერი `char` კოდირებისთვის.
    ///
    /// # Examples
    ///
    /// ორივე ამ მაგალითში, '𝕊' ორი `u16` სჭირდება კოდირებისთვის.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// ძალიან მცირე ზომის ბუფერი:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// აბრუნებს `true`-ს, თუ ამ `char`-ს აქვს `Alphabetic` თვისება.
    ///
    /// `Alphabetic` აღწერილია [Unicode Standard]- ის მე -4 თავში (პერსონაჟის თვისებები) და მითითებულია [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]- ში.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // სიყვარული არის ბევრი რამ, მაგრამ ეს არ არის ანბანური
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// აბრუნებს `true`-ს, თუ ამ `char`-ს აქვს `Lowercase` თვისება.
    ///
    /// `Lowercase` აღწერილია [Unicode Standard]- ის მე -4 თავში (პერსონაჟის თვისებები) და მითითებულია [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]- ში.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // სხვადასხვა ჩინურ დამწერლობას და პუნქტუაციას არ აქვს მნიშვნელობა და ა.შ.
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// აბრუნებს `true`-ს, თუ ამ `char`-ს აქვს `Uppercase` თვისება.
    ///
    /// `Uppercase` აღწერილია [Unicode Standard]- ის მე -4 თავში (პერსონაჟის თვისებები) და მითითებულია [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]- ში.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // სხვადასხვა ჩინურ დამწერლობას და პუნქტუაციას არ აქვს მნიშვნელობა და ა.შ.
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// აბრუნებს `true`-ს, თუ ამ `char`-ს აქვს `White_Space` თვისება.
    ///
    /// `White_Space` მითითებულია [Unicode Character Database][ucd] [`PropList.txt`]-ში.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // გაუტეხავი სივრცე
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// აბრუნებს `true`-ს, თუ ეს `char` აკმაყოფილებს ან [`is_alphabetic()`] ან [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// აბრუნებს `true`-ს, თუ ამ `char`-ს აქვს ზოგადი კატეგორია კონტროლის კოდებისათვის.
    ///
    /// საკონტროლო კოდები (კოდური წერტილები `Cc` ზოგადი კატეგორიით) აღწერილია [Unicode Standard]- ის მე -4 თავში (პერსონაჟის მახასიათებლები) და მითითებულია [Unicode Character Database][ucd] [`UnicodeData.txt`]- ში.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// // U + 009C, STRING ტერმინატორი
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// აბრუნებს `true`-ს, თუ ამ `char`-ს აქვს `Grapheme_Extend` თვისება.
    ///
    /// `Grapheme_Extend` აღწერილია [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] და მითითებულია [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// აბრუნებს `true`-ს, თუ ამ `char`-ს აქვს ნომრების ზოგადი კატეგორია.
    ///
    /// ციფრების ზოგადი კატეგორიები (`Nd` ათობითი ციფრებისთვის, `Nl` ასოების მსგავსი რიცხვითი სიმბოლოებისთვის და `No` სხვა რიცხვითი სიმბოლოებისთვის) მითითებულია [Unicode Character Database][ucd] [`UnicodeData.txt`]-ში.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// აბრუნებს იტერატორს, რომელიც იძლევა ამ `char`- ის მცირე რუკას, როგორც ერთს ან მეტს
    /// `char`s.
    ///
    /// თუ ამ `char`-ს არ აქვს მცირე ზომის ასახვა, iterator იძლევა იგივე `char`-ს.
    ///
    /// თუ ამ `char`-ს აქვს თითო-თითო მცირე გამოსახვა, რომელიც მოცემულია [Unicode Character Database][ucd] [`UnicodeData.txt`]-ის მიერ, iterator იძლევა ამ `char`-ს.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// თუ ეს `char` მოითხოვს სპეციალურ მოსაზრებებს (მაგ., მრავალრიცხოვანი `char`), iterator გამოაქვს [`SpecialCasing.txt`]-ის მიერ მოცემულ`char` (ებ) ს.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ეს ოპერაცია ასრულებს უპირობო რუკას მკერავის გარეშე.ანუ, გარდაქმნა დამოუკიდებელია კონტექსტისა და ენისგან.
    ///
    /// [Unicode Standard]- ში მე -4 თავში (პერსონაჟის თვისებები) განხილულია ზოგადად საქმის ასახვა, ხოლო მე -3 თავში (Conformance) განიხილება ნაგულისხმევი ალგორითმი კაზუსის გადაკეთებისთვის.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// როგორც იტერატორი:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` პირდაპირ გამოყენება:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// ორივე ეკვივალენტურია:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string`- ის გამოყენება:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // ზოგჯერ შედეგი ერთზე მეტი სიმბოლოა:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // სიმბოლოები, რომლებსაც არ აქვთ ორივე დიდი და მცირე, გარდაიქმნებიან საკუთარ თავში.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// აბრუნებს იტერატორს, რომელიც იძლევა ამ `char`- ის ზედა რუკას, როგორც ერთს ან მეტს
    /// `char`s.
    ///
    /// თუ ამ `char`-ს არ აქვს დიდი რუკები, iterator იძლევა იგივე `char`-ს.
    ///
    /// თუ ამ `char`-ს აქვს ერთი-ერთი დიდი კაპიტალიზაცია მოცემული [Unicode Character Database][ucd] [`UnicodeData.txt`]-ის მიერ, iterator იძლევა `char`-ს.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// თუ ეს `char` მოითხოვს სპეციალურ მოსაზრებებს (მაგ., მრავალრიცხოვანი `char`), iterator გამოაქვს [`SpecialCasing.txt`]-ის მიერ მოცემულ`char` (ებ) ს.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ეს ოპერაცია ასრულებს უპირობო რუკას მკერავის გარეშე.ანუ, გარდაქმნა დამოუკიდებელია კონტექსტისა და ენისგან.
    ///
    /// [Unicode Standard]- ში მე -4 თავში (პერსონაჟის თვისებები) განხილულია ზოგადად საქმის ასახვა, ხოლო მე -3 თავში (Conformance) განიხილება ნაგულისხმევი ალგორითმი კაზუსის გადაკეთებისთვის.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// როგორც იტერატორი:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` პირდაპირ გამოყენება:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// ორივე ეკვივალენტურია:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string`- ის გამოყენება:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // ზოგჯერ შედეგი ერთზე მეტი სიმბოლოა:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // სიმბოლოები, რომლებსაც არ აქვთ ორივე დიდი და მცირე, გარდაიქმნებიან საკუთარ თავში.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # შენიშვნა ლოკალზე
    ///
    /// თურქულად ლათინურად 'i'-ის ექვივალენტი ორი ფორმის ნაცვლად ხუთი ფორმისაა:
    ///
    /// * 'Dotless': I/ı, ზოგჯერ დაწერილი
    /// * 'Dotted': İ/მე
    ///
    /// გაითვალისწინეთ, რომ პატარა წერტილოვანი 'i' იგივეა, რაც ლათინური.ამიტომ:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// `upper_i` მნიშვნელობა აქ ეყრდნობა ტექსტის ენას: თუ ჩვენ ვართ `en-US`, ეს უნდა იყოს `"I"`, მაგრამ თუ ჩვენ `tr_TR` ვართ, ეს უნდა იყოს `"İ"`.
    /// `to_uppercase()` არ ითვალისწინებს ამას და ა.შ.
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// ფლობს ენებს.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// ამოწმებს არის თუ არა მნიშვნელობა ASCII დიაპაზონში.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// ქმნის მნიშვნელობის ასლს ASCII- ის ზედა ეკვივალენტში.
    ///
    /// ASCII ასოები 'a'-დან 'z'-მდე დატანილია 'A'-დან 'Z'-მდე, მაგრამ არა ASCII ასოები უცვლელია.
    ///
    /// მნიშვნელობის ადგილზე დიდი ასლის დასადგენად გამოიყენეთ [`make_ascii_uppercase()`].
    ///
    /// ASCII სიმბოლოების გარდა, რომ არა ASCII სიმბოლოები, გამოიყენეთ [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// ქმნის მნიშვნელობის ასლს ASCII- ის მცირე ეკვივალენტში.
    ///
    /// ASCII ასოები 'A'-დან 'Z'-მდე დატანილია 'a'-დან 'z'-მდე, მაგრამ არა ASCII ასოები უცვლელია.
    ///
    /// იმისათვის, რომ ადგილზე ჩამოაყალიბოთ მნიშვნელობა, გამოიყენეთ [`make_ascii_lowercase()`].
    ///
    /// იმისათვის, რომ მცირე ASCII სიმბოლოები გამოიყენოთ, არა ASCII სიმბოლოების გარდა, გამოიყენეთ [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// ამოწმებს, რომ ორი მნიშვნელობა არის ASCII შემთხვევითი - მგრძნობიარე შესატყვისი.
    ///
    /// ექვივალენტურია `to_ascii_lowercase(a) == to_ascii_lowercase(b)`- ს.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// ამ ტიპს აქცევს ASCII- ის ზედა ექვივალენტის ადგილზე.
    ///
    /// ASCII ასოები 'a'-დან 'z'-მდე დატანილია 'A'-დან 'Z'-მდე, მაგრამ არა ASCII ასოები უცვლელია.
    ///
    /// ახალი დიდი მნიშვნელობის დასაბრუნებლად არსებული შეცვლის გარეშე გამოიყენეთ [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// ამ ტიპს აქცევს ASCII- ის მცირე ზომის ეკვივალენტურ ადგილზე.
    ///
    /// ASCII ასოები 'A'-დან 'Z'-მდე დატანილია 'a'-დან 'z'-მდე, მაგრამ არა ASCII ასოები უცვლელია.
    ///
    /// ახალი ქვედა მნიშვნელობის დასაბრუნებლად არსებული შეცვლის გარეშე გამოიყენეთ [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// ამოწმებს არის თუ არა მნიშვნელობა ASCII ანბანური სიმბოლო:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ან
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// ამოწმებს არის თუ არა მნიშვნელობა ASCII დიდი ზომის სიმბოლოს:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// ამოწმებს არის თუ არა მნიშვნელობა ASCII მცირე ზომის სიმბოლო:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// ამოწმებს არის თუ არა მნიშვნელობა ASCII ალფანუმერული სიმბოლო:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ან
    /// - U + 0061 'a' ..=U + 007A 'z', ან
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// ამოწმებს არის თუ არა მნიშვნელობა ASCII ათობითი ციფრი:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// ამოწმებს არის თუ არა მნიშვნელობა ASCII თექვსმეტობითი ციფრი:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', ან
    /// - U + 0041 'A' ..=U + 0046 'F', ან
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// ამოწმებს არის თუ არა მნიშვნელობა ASCII პუნქტუაციის ხასიათი:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, ან
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, ან
    /// - U + 005B ..=U + 0060 "[\] ^ _" ``, ან
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// ამოწმებს არის თუ არა მნიშვნელობა ASCII გრაფიკული პერსონაჟი:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// ამოწმებს არის თუ არა მნიშვნელობა ASCII თეთრი სივრცის სიმბოლოს:
    /// U + 0020 SPACE, U + 0009 ჰორიზონტალური TAB, U + 000A LINE FEED, U + 000C FORM FEED, ან U + 000D CARRIAGE RETURN.
    ///
    /// Rust იყენებს WhatWG Infra Standard- ის [definition of ASCII whitespace][infra-aw].არსებობს კიდევ რამდენიმე განმარტება, რომლებიც ფართო გამოყენებაშია.
    /// მაგალითად, [the POSIX locale][pct] მოიცავს U + 000B ვერტიკალურ TAB-ს, ისევე როგორც ყველა ზემოთ ჩამოთვლილ სიმბოლოს, მაგრამ-იგივე დაზუსტებით-["field splitting"-ის ნაგულისხმევი წესი Bourne shell-ში][bfs] ითვალისწინებს *მხოლოდ* სივრცეს, ჰორიზონტალურ ტაბსა და LINE FEED როგორც თეთრი სივრცე.
    ///
    ///
    /// თუ თქვენ წერთ პროგრამას, რომელიც დაამუშავებს არსებულ ფაილის ფორმატს, შეამოწმეთ რა არის ამ ფორმატის განმარტება თეთრ სივრცეში ამ ფუნქციის გამოყენებამდე.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// ამოწმებს არის თუ არა მნიშვნელობა ASCII კონტროლის სიმბოლო:
    /// U + 0000 NUL ..=U + 001F ერთეულის გამყოფი, ან U + 007F წაშლა.
    /// გაითვალისწინეთ, რომ ASCII თეთრი სივრცის სიმბოლოების უმეტესობა წარმოადგენს კონტროლის სიმბოლოებს, მაგრამ SPACE არა
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// კოდირებს ნედლეულის u32 მნიშვნელობას, როგორც UTF-8, მოწოდებულ ბაიტის ბუფერში და შემდეგ აბრუნებს ბუფერის ქვედა ნაწილს, რომელიც შეიცავს კოდირებულ სიმბოლოს.
///
///
/// `char::encode_utf8`-ისგან განსხვავებით, ეს მეთოდი ასევე ამუშავებს სუროგატი დიაპაზონის კოდპოინტებს.
/// (სუროგატის დიაპაზონში `char`-ის შექმნა არის UB.) შედეგი მოქმედებს [generalized UTF-8], მაგრამ არ მოქმედებს UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics თუ ბუფერი არ არის საკმარისად დიდი.
/// ოთხი სიგრძის ბუფერი საკმარისად დიდია ნებისმიერი `char` კოდირებისთვის.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// კოდირებს ნედლეულის u32 მნიშვნელობას, როგორც UTF-16 მოწოდებულ `u16` ბუფერში და შემდეგ აბრუნებს ბუფერის ქვესახეებს, რომელიც შეიცავს კოდირებულ სიმბოლოს.
///
///
/// `char::encode_utf16`-ისგან განსხვავებით, ეს მეთოდი ასევე ამუშავებს სუროგატი დიაპაზონის კოდპოინტებს.
/// (სუროგატის დიაპაზონში `char`-ის შექმნა არის UB.)
///
/// # Panics
///
/// Panics თუ ბუფერი არ არის საკმარისად დიდი.
/// 2 სიგრძის ბუფერი საკმარისად დიდია ნებისმიერი `char` კოდირებისთვის.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // უსაფრთხოება: თითოეული მკლავი ამოწმებს არის საკმარისი ბიტები დასაწერად
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP იშლება
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // დამატებითი თვითმფრინავები სუროგატებში ხვდებიან.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}