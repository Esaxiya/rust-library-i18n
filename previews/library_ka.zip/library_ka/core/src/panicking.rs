//! Panic libcore-ს მხარდაჭერა
//!
//! ძირითადი ბიბლიოთეკა ვერ განსაზღვრავს პანიკას, მაგრამ *აცხადებს* პანიკის შესახებ.
//! ეს ნიშნავს, რომ libcore-ის შიგნით ფუნქციები დაშვებულია panic-სთვის, მაგრამ იმისთვის რომ სასარგებლო იყოს, crate-მა უნდა განსაზღვროს პანიკა libcore-ს გამოყენებისთვის.
//! პანიკის ამჟამინდელი ინტერფეისია:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! ეს განმარტება საშუალებას გაძლევთ პანიკაში ჩავარდნოთ ნებისმიერი ზოგადი შეტყობინებით, მაგრამ ის არ იძლევა `Box<Any>` მნიშვნელობას.
//! (`PanicInfo` უბრალოდ შეიცავს `&(dyn Any + Send)`-ს, რისთვისაც ჩვენ შეავსებთ ცრუ მნიშვნელობას `PanicInfo: : internal_constructor`). ამის მიზეზი არის ის, რომ libcore-ს გამოყოფა არ არის დაშვებული.
//!
//!
//! ეს მოდული შეიცავს რამდენიმე სხვა პანიკურ ფუნქციას, მაგრამ ეს მხოლოდ აუცილებელი ენების ელემენტებია შემდგენლისთვის.ყველა panics დაკომპლექტებულია ამ ერთი ფუნქციის საშუალებით.
//! ფაქტობრივი სიმბოლო დეკლარირებულია `#[panic_handler]` ატრიბუტის საშუალებით.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Libcore- ს `panic!` მაკროსის ძირითადი განხორციელება, როდესაც ფორმატირება არ არის გამოყენებული.
#[cold]
// არასდროს შემოხაზოთ, თუ არ panic_immediate_abort, რათა თავიდან აიცილოთ კოდის დაბურვა ზარის საიტებზე რაც შეიძლება მეტი
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // კოდეგენს ესაჭიროება panic-სთვის გადავსება და სხვა `Assert` MIR დამთავრებები
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // გამოიყენეთ Arguments::new_v1 ფორმატის_არგების ნაცვლად! ("{}", Expr) ზომა ზევით პოტენციურად შეამციროთ.
    // ფორმატი_არგები!macro იყენებს str's Display trait-ს expr-ის დასაწერად, რომელიც Formatter::pad-ს უწოდებს, რომელიც უნდა შეიცავდეს სტრიქონების შემცირებას და შევსებას (მიუხედავად იმისა, რომ აქ არცერთი არ არის გამოყენებული).
    //
    // Arguments::new_v1- ის გამოყენებამ შეიძლება კომპილატორს საშუალებას მისცეს გამოტოვოთ Formatter::pad გამომავალი ორობიდან, დაზოგავს რამდენიმე კილობაიტს.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // საჭიროა შეფასებული panics-სთვის
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // კოდენს სჭირდება panic OOB array/slice წვდომისთვის
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// ფორმატირებისას გამოიყენება libcore-ის `panic!` მაკროს საფუძველი.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // შენიშვნა ეს ფუნქცია არასოდეს კვეთს FFI საზღვარს;ეს არის Rust-to-Rust ზარი, რომელიც გადაწყდება `#[panic_handler]` ფუნქციაზე.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // უსაფრთხოება: `panic_impl` განისაზღვრება უსაფრთხო Rust კოდში და ამიტომ უსაფრთხოა დარეკვა.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// შიდა ფუნქცია `assert_eq!` და `assert_ne!` მაკროებისთვის
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}