#![stable(feature = "futures_api", since = "1.36.0")]

//! ასინქრონული ღირებულებები.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// ეს ტიპი საჭიროა, რადგან:
///
/// ა) გენერატორებს არ შეუძლიათ `for<'a, 'b> Generator<&'a mut Context<'b>>` დანერგონ, ამიტომ საჭიროა ნედლეული მაჩვენებლის გადაცემა (იხ. <https://github.com/rust-lang/rust/issues/68923>).
///
/// ბ) ნედლეული მაჩვენებლები და `NonNull` არ არის `Send` ან `Sync`, ასე რომ, ეს შექმნის თითოეულ future non-Send/Sync-ს და ეს არ გვინდა.
///
/// იგი ასევე ამარტივებს H00-ის `.await` შემცირებას.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// გადაიტანეთ გენერატორი future-ში.
///
/// ეს ფუნქცია დააბრუნებს `GenFuture`-ს ქვემოთ, მაგრამ მალავს მას `impl Trait`-ში, რომ უკეთესი შეცდომები მისცეს (`impl Future` ვიდრე `GenFuture<[closure.....]>`).
///
// ეს არის `const`, რომ თავიდან ავიცილოთ დამატებითი შეცდომები `const async fn`- დან გამოჯანმრთელების შემდეგ
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // ჩვენ ვენდობით იმ ფაქტს, რომ async/await futures უძრავია, რათა წარმოქმნას თვითრეფერენციული სესხები ფუძემდებლურ გენერატორში.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // უსაფრთხოება: უსაფრთხოა, რადგან ჩვენ ვართ !Unpin + !Drop და ეს მხოლოდ ველის პროექციაა.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // განაახლეთ გენერატორი, გადააქციეთ `&mut Context` `NonNull` ნედლეულ მაჩვენებლად.
            // `.await` დაწევა უსაფრთხოდ მიაქცევს მას `&mut Context`-ს.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `cx.0` სწორი მაჩვენებელია
    // რომელიც აკმაყოფილებს ცვალებადი მითითების ყველა მოთხოვნას.
    unsafe { &mut *cx.0.as_ptr().cast() }
}