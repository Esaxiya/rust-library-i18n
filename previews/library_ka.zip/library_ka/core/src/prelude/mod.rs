//! Libcore prelude
//!
//! ეს მოდული განკუთვნილია libcore-ის მომხმარებლებისთვის, რომლებიც ასევე არ უკავშირდებიან libstd-ს.
//! ამ მოდულის შემოტანა ხდება სტანდარტულად, როდესაც `#![no_std]` გამოიყენება იმავე წესით, როგორც სტანდარტული ბიბლიოთეკის prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// ბირთვი prelude- ის 2015 წლის ვერსია.
///
/// იხილეთ [module-level documentation](self) მეტი.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// ბირთვი prelude-ის 2018 წლის ვერსია.
///
/// იხილეთ [module-level documentation](self) მეტი.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// ძირითადი prelude 2021 ვერსია.
///
/// იხილეთ [module-level documentation](self) მეტი.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: დაამატე მეტი რამ.
}