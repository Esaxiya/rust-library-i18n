use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// დახვეული ნედლეული არა-ნულოვანი `*mut T` გარშემო, რომელიც მიუთითებს იმაზე, რომ ამ შეფუთვის მფლობელი არის რეფერენტი.
/// სასარგებლოა აბსტრაქციების შესაქმნელად, როგორიცაა `Box<T>`, `Vec<T>`, `String` და `HashMap<K, V>`.
///
/// `*mut T`-ისგან განსხვავებით, `Unique<T>` იქცევა "as if", ეს იყო `T`-ის მაგალითი.
/// იგი ახორციელებს `Send`/`Sync`-ს, თუ `T` არის `Send`/`Sync`.
/// ეს ასევე გულისხმობს სახის მკაცრი aliasing გარანტიას, რომ `T`- ის შემთხვევა შეიძლება მოელოდა:
/// მაჩვენებლის მითითება არ უნდა შეიცვალოს უნიკალური გზის გარეშე.
///
/// თუ არ იცით, სწორია თუ არა `Unique` თქვენი მიზნებისათვის გამოყენება, გაითვალისწინეთ `NonNull`-ის გამოყენება, რომელსაც უფრო სუსტი სემანტიკა აქვს.
///
///
/// `*mut T`-ისგან განსხვავებით, მაჩვენებელი ყოველთვის უნდა იყოს ნულოვანი, მაშინაც კი, თუ მაჩვენებელი არასდროს არის მითითებული.
/// ეს ასეა, რომ enum-მა შეიძლება გამოიყენოს ეს აკრძალული მნიშვნელობა, როგორც დისკრიმინაციული-`Option<Unique<T>>` აქვს იგივე ზომა, როგორც `Unique<T>`.
/// თუმცა, მაჩვენებელი კვლავ შეიძლება ჩამოიხრჩო, თუ არ არის მითითებული.
///
/// `*mut T`-ისგან განსხვავებით, `Unique<T>` არის კოვარიანტი `T`-ზე.
/// ეს ყოველთვის უნდა იყოს სწორი ნებისმიერი ტიპისთვის, რომელიც იცავს უნიკის მოთხოვნებს aliasing.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ამ ნიშნულს არ აქვს არანაირი შედეგი ვერიანობაზე, მაგრამ აუცილებელია
    // რომ dropck გაიგოს, რომ ჩვენ ლოგიკურად გვაქვს `T`.
    //
    // დეტალებისთვის იხილეთ:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` მითითებები არის `Send`, თუ `T` არის `Send`, რადგან მონაცემები, რომლებსაც ისინი მიუთითებენ, არ არის ობიექტური.
/// გაითვალისწინეთ, რომ ამ aliasing ინვარიანტი არ არის გაძლიერებული ტიპის სისტემის მიერ;აბსტრაქციამ უნდა გამოიყენოს `Unique`.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` მითითებები არის `Sync`, თუ `T` არის `Sync`, რადგან მონაცემები, რომლებსაც ისინი მიუთითებენ, არ არის ობიექტური.
/// გაითვალისწინეთ, რომ ამ aliasing ინვარიანტი არ არის გაძლიერებული ტიპის სისტემის მიერ;აბსტრაქციამ უნდა გამოიყენოს `Unique`.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// ქმნის ახალ `Unique`-ს, რომელიც არის ჩამოკიდებული, მაგრამ კარგად გასწორებული.
    ///
    /// ეს გამოსადეგია იმ ტიპის ინიციალიზაციისთვის, რომლებიც სიზარმაცე გამოყოფს, როგორც `Vec::new` აკეთებს.
    ///
    /// გაითვალისწინეთ, რომ მაჩვენებლის მნიშვნელობა შესაძლოა წარმოადგენს `T`-ის მოქმედ მაჩვენებელს, რაც იმას ნიშნავს, რომ ეს არ უნდა იქნას გამოყენებული როგორც "not yet initialized" sentinel მნიშვნელობა.
    /// ტიპები, რომლებიც სიზარმაცით გამოყოფენ, უნდა აკონტროლონ ინიცირება სხვა საშუალებებით.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // უსაფრთხოება: mem::align_of() აბრუნებს მოქმედ, არა-ნულოვან მაჩვენებელს.
        // ამრიგად, დაცულია new_unchecked() დარეკვის პირობები.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// ქმნის ახალ `Unique`-ს.
    ///
    /// # Safety
    ///
    /// `ptr` უნდა იყოს არა-ნულოვანი.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `ptr` არ არის ბათილი.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// ქმნის ახალ `Unique`-ს, თუ `ptr` არ არის null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // უსაფრთხოება: მაჩვენებელი უკვე შემოწმებულია და არ არის ნულოვანი.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// იძენს ფუძემდებლურ `*mut` მაჩვენებელს.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// შეცვლის შინაარსს.
    ///
    /// შედეგად მიღებული სიცოცხლე ვალდებულია თვითონ იმოქმედოს, ასე რომ, ის იქცევა "as if". ეს სინამდვილეში იყო T-ს სესხის აღება.
    /// თუ საჭიროა (unbound) სიცოცხლის ხანგრძლივობა, გამოიყენეთ `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `self` აკმაყოფილებს ყველა
        // მოთხოვნები მითითებისთვის.
        unsafe { &*self.as_ptr() }
    }

    /// უცვლელად გადაადგილდება შინაარსი.
    ///
    /// შედეგად მიღებული სიცოცხლე ვალდებულია თვითონ იმოქმედოს, ასე რომ, ის იქცევა "as if". ეს სინამდვილეში იყო T-ს სესხის აღება.
    /// თუ საჭიროა (unbound) სიცოცხლის ხანგრძლივობა, გამოიყენეთ `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `self` აკმაყოფილებს ყველა
        // მუტაბელური მითითების მოთხოვნები.
        unsafe { &mut *self.as_ptr() }
    }

    /// ისვრის სხვა ტიპის მაჩვენებელს.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // უსაფრთხოება: Unique::new_unchecked() ქმნის ახალ უნიკალურ და საჭიროებებს
        // მოცემული მაჩვენებელი არ არის null.
        // მას შემდეგ, რაც ჩვენ თვითონ მივდივართ, როგორც მაჩვენებელი, ის არ შეიძლება იყოს ბათილი.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // უსაფრთხოება: ცვალებადი მითითება არ შეიძლება იყოს ბათილი
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}