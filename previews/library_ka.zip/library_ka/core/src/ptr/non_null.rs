use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` მაგრამ არა ნულოვანი და კოვარიანტული.
///
/// ეს ხშირად სწორია, რომ გამოიყენოთ მონაცემთა სტრუქტურების მშენებლობისას ნედლეული მაჩვენებლების გამოყენებით, მაგრამ საბოლოო ჯამში გამოყენება უფრო საშიშია მისი დამატებითი თვისებების გამო.თუ არ ხართ დარწმუნებული, იყენებთ თუ არა `NonNull<T>`, გამოიყენეთ `*mut T`!
///
/// `*mut T`-ისგან განსხვავებით, კურსორი ყოველთვის უნდა იყოს ნულოვანი, მაშინაც კი, თუ კურსორი არასდროს არის მითითებული.ეს ასეა, რომ enum-მა შეიძლება გამოიყენოს ეს აკრძალული მნიშვნელობა, როგორც დისკრიმინაციული-`Option<NonNull<T>>` აქვს იგივე ზომა, როგორც `* mut T`.
/// თუმცა, მაჩვენებელი კვლავ შეიძლება ჩამოიხრჩო, თუ არ არის მითითებული.
///
/// `*mut T`-ისგან განსხვავებით, `NonNull<T>` აირჩიეს, რომ შეიცვალოს `T`-ზე.ეს საშუალებას გვაძლევს გამოიყენოთ `NonNull<T>` კოვარიანტების ტიპების მშენებლობისას, მაგრამ წარმოიქმნება გაუგებრობის რისკი, თუ ისინი გამოიყენება ტიპებში, რომლებიც სინამდვილეში არ უნდა იყოს კოვარიანტები.
/// (საპირისპირო არჩევანი გაკეთდა `*mut T`- სთვის, მიუხედავად იმისა, რომ ტექნიკურად უვარგისი შეიძლება მხოლოდ საშიში ფუნქციების გამოძახებით იყოს გამოწვეული).
///
/// კოვარიანტობა სწორია ყველაზე უსაფრთხო აბსტრაქციებისთვის, მაგალითად `Box`, `Rc`, `Arc`, `Vec` და `LinkedList`.ეს ასეა, რადგან ისინი უზრუნველყოფენ საჯარო API-ს, რომელიც იცავს Rust-ის ჩვეულებრივ გაზიარებულ XOR მუტაბელურ წესებს.
///
/// თუ თქვენი ტიპი უსაფრთხოდ ვერ იცვლება, დარწმუნდით, რომ იგი შეიცავს დამატებით ველს უცვლელობის უზრუნველსაყოფად.ხშირად ეს ველი იქნება [`PhantomData`] ტიპის, როგორიცაა `PhantomData<Cell<T>>` ან `PhantomData<&'a mut T>`.
///
/// გაითვალისწინეთ, რომ `NonNull<T>` აქვს `From` ინსტანცია `&T`- სთვის.ამასთან, ეს არ ცვლის იმ ფაქტს, რომ (ა - დან მიღებული მაჩვენებლის მეშვეობით) მუტაცია განუსაზღვრელი ქცევაა, თუ მუტაცია არ მოხდება [`UnsafeCell<T>`]- ის შიგნით.იგივე ეხება საზიარო ცნობიდან მუტაბელური მითითების შექმნას.
///
/// როდესაც იყენებთ ამ `From` ინსტანციას `UnsafeCell<T>` გარეშე, თქვენი პასუხისმგებლობაა უზრუნველყოთ, რომ `as_mut` არასოდეს დარეკოს, და `as_ptr` არასოდეს გამოიყენოთ მუტაციისთვის.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` მითითებები არ არის `Send`, რადგან მონაცემები, რომლებსაც ისინი მიუთითებენ, შეიძლება იყოს მეტსახელი.
// გაითვალისწინეთ, ეს მიწოდება არასაჭიროა, მაგრამ უნდა შეიცავდეს უკეთეს შეტყობინებებს.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` მითითებები არ არის `Sync`, რადგან მათ მიერ მითითებული მონაცემები შეიძლება იყოს მეტსახელი.
// გაითვალისწინეთ, ეს მიწოდება არასაჭიროა, მაგრამ უნდა შეიცავდეს უკეთეს შეტყობინებებს.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// ქმნის ახალ `NonNull`-ს, რომელიც არის ჩამოკიდებული, მაგრამ კარგად გასწორებული.
    ///
    /// ეს გამოსადეგია იმ ტიპის ინიციალიზაციისთვის, რომლებიც სიზარმაცე გამოყოფს, როგორც `Vec::new` აკეთებს.
    ///
    /// გაითვალისწინეთ, რომ მაჩვენებლის მნიშვნელობა შესაძლოა წარმოადგენს `T`-ის მოქმედ მაჩვენებელს, რაც იმას ნიშნავს, რომ ეს არ უნდა იქნას გამოყენებული როგორც "not yet initialized" sentinel მნიშვნელობა.
    /// ტიპები, რომლებიც სიზარმაცით გამოყოფენ, უნდა აკონტროლონ ინიცირება სხვა საშუალებებით.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // უსაფრთხოება: mem::align_of() აბრუნებს ნულოვან გამოყენებას, რომელიც შემდეგ იდება
        // ა * მუტ თ-სკენ.
        // ამიტომ, `ptr` არ არის ბათილი და დაცულია პირობები new_unchecked() დარეკვისთვის.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// აბრუნებს გაზიარებულ მითითებებს მნიშვნელობაზე.[`as_ref`]-ისგან განსხვავებით, ეს არ საჭიროებს მნიშვნელობის ინიციალიზაციას.
    ///
    /// მუტაბელური კოლეგისთვის იხილეთ [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// ამ მეთოდის გამოძახებისას უნდა დარწმუნდეთ, რომ ყველა ქვემოთჩამოთვლილი სიმართლეა:
    ///
    /// * მაჩვენებელი სწორად გასწორებული უნდა იყოს.
    ///
    /// * ეს უნდა იყოს "dereferencable" იმ გაგებით, რაც განსაზღვრულია [the module documentation]-ში.
    ///
    /// * თქვენ უნდა შეასრულოთ Rust- ის დამაკავშირებელი წესები, ვინაიდან დაბრუნებული სიცოცხლის ხანგრძლივობა `'a` თვითნებურად არის არჩეული და სულაც არ ასახავს მონაცემთა რეალურ სიცოცხლეს.
    ///
    ///   კერძოდ, ამ სიცოცხლის მანძილზე მეხსიერება, რომელზეც მიუთითებს მაჩვენებელი, არ უნდა შეიცვალოს (გარდა `UnsafeCell`- ის შიგნით).
    ///
    /// ეს ეხება მაშინაც კი, თუ ამ მეთოდის შედეგი გამოუყენებელია!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `self` აკმაყოფილებს ყველა
        // მოთხოვნები მითითებისთვის.
        unsafe { &*self.cast().as_ptr() }
    }

    /// აბრუნებს ღირებულების უნიკალურ მითითებებს.[`as_mut`]-ისგან განსხვავებით, ეს არ საჭიროებს მნიშვნელობის ინიციალიზაციას.
    ///
    /// გაზიარებული კოლეგისთვის იხილეთ [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// ამ მეთოდის გამოძახებისას უნდა დარწმუნდეთ, რომ ყველა ქვემოთჩამოთვლილი სიმართლეა:
    ///
    /// * მაჩვენებელი სწორად გასწორებული უნდა იყოს.
    ///
    /// * ეს უნდა იყოს "dereferencable" იმ გაგებით, რაც განსაზღვრულია [the module documentation]-ში.
    ///
    /// * თქვენ უნდა შეასრულოთ Rust- ის დამაკავშირებელი წესები, ვინაიდან დაბრუნებული სიცოცხლის ხანგრძლივობა `'a` თვითნებურად არის არჩეული და სულაც არ ასახავს მონაცემთა რეალურ სიცოცხლეს.
    ///
    ///   კერძოდ, ამ სიცოცხლის განმავლობაში, მეხსიერებაზე, რომელზეც მიუთითებს მაჩვენებელი, არ უნდა იქნეს ხელმისაწვდომი (წაკითხული ან დაწერილი) ნებისმიერი სხვა მაჩვენებლის მეშვეობით.
    ///
    /// ეს ეხება მაშინაც კი, თუ ამ მეთოდის შედეგი გამოუყენებელია!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `self` აკმაყოფილებს ყველა
        // მოთხოვნები მითითებისთვის.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// ქმნის ახალ `NonNull`-ს.
    ///
    /// # Safety
    ///
    /// `ptr` უნდა იყოს არა-ნულოვანი.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `ptr` არ არის ბათილი.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// ქმნის ახალ `NonNull`-ს, თუ `ptr` არ არის null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // უსაფრთხოება: მაჩვენებელი უკვე შემოწმებულია და არ არის ნულოვანი
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// ასრულებს იგივე ფუნქციონირებას, როგორც [`std::ptr::from_raw_parts`], გარდა იმისა, რომ `NonNull` მაჩვენებელი დააბრუნებს, განსხვავებით ნედლეული `*const` მაჩვენებლისგან.
    ///
    ///
    /// დამატებითი ინფორმაციისთვის იხილეთ [`std::ptr::from_raw_parts`] დოკუმენტაცია.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // უსაფრთხოება: `ptr::from::raw_parts_mut`- ის შედეგი ნულოვანია, რადგან `data_address` არის.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// (შესაძლოა ფართო) მაჩვენებლის დაშლა არის მისამართის და მეტამონაცემების კომპონენტები.
    ///
    /// შემდეგ მაჩვენებლის აღდგენა შესაძლებელია [`NonNull::from_raw_parts`]-ით.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// იძენს ფუძემდებლურ `*mut` მაჩვენებელს.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// აბრუნებს მნიშვნელობას გაზიარებულ მითითებას.თუ მნიშვნელობა შეიძლება იყოს არაინციალიზებული, მის ნაცვლად უნდა იქნას გამოყენებული [`as_uninit_ref`].
    ///
    /// მუტაბელური კოლეგისთვის იხილეთ [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// ამ მეთოდის გამოძახებისას უნდა დარწმუნდეთ, რომ ყველა ქვემოთჩამოთვლილი სიმართლეა:
    ///
    /// * მაჩვენებელი სწორად გასწორებული უნდა იყოს.
    ///
    /// * ეს უნდა იყოს "dereferencable" იმ გაგებით, რაც განსაზღვრულია [the module documentation]-ში.
    ///
    /// * მაჩვენებელმა უნდა მიუთითოს `T`-ის საწყისი ვერსია.
    ///
    /// * თქვენ უნდა შეასრულოთ Rust- ის დამაკავშირებელი წესები, ვინაიდან დაბრუნებული სიცოცხლის ხანგრძლივობა `'a` თვითნებურად არის არჩეული და სულაც არ ასახავს მონაცემთა რეალურ სიცოცხლეს.
    ///
    ///   კერძოდ, ამ სიცოცხლის მანძილზე მეხსიერება, რომელზეც მიუთითებს მაჩვენებელი, არ უნდა შეიცვალოს (გარდა `UnsafeCell`- ის შიგნით).
    ///
    /// ეს ეხება მაშინაც კი, თუ ამ მეთოდის შედეგი გამოუყენებელია!
    /// (ნაწილი, რომლის ინიცირება ჯერ კიდევ სრულად არ არის გადაწყვეტილი, მაგრამ სანამ ეს გაკეთდება, ერთადერთი უსაფრთხო მიდგომაა იმის უზრუნველყოფა, რომ ისინი მართლაც შედგეს.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `self` აკმაყოფილებს ყველა
        // მოთხოვნები მითითებისთვის.
        unsafe { &*self.as_ptr() }
    }

    /// აბრუნებს მნიშვნელობას უნიკალურ მითითებას.თუ მნიშვნელობა შეიძლება იყოს არაინციალიზებული, მის ნაცვლად უნდა იქნას გამოყენებული [`as_uninit_mut`].
    ///
    /// გაზიარებული კოლეგისთვის იხილეთ [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// ამ მეთოდის გამოძახებისას უნდა დარწმუნდეთ, რომ ყველა ქვემოთჩამოთვლილი სიმართლეა:
    ///
    /// * მაჩვენებელი სწორად გასწორებული უნდა იყოს.
    ///
    /// * ეს უნდა იყოს "dereferencable" იმ გაგებით, რაც განსაზღვრულია [the module documentation]-ში.
    ///
    /// * მაჩვენებელმა უნდა მიუთითოს `T`-ის საწყისი ვერსია.
    ///
    /// * თქვენ უნდა შეასრულოთ Rust- ის დამაკავშირებელი წესები, ვინაიდან დაბრუნებული სიცოცხლის ხანგრძლივობა `'a` თვითნებურად არის არჩეული და სულაც არ ასახავს მონაცემთა რეალურ სიცოცხლეს.
    ///
    ///   კერძოდ, ამ სიცოცხლის განმავლობაში, მეხსიერებაზე, რომელზეც მიუთითებს მაჩვენებელი, არ უნდა იქნეს ხელმისაწვდომი (წაკითხული ან დაწერილი) ნებისმიერი სხვა მაჩვენებლის მეშვეობით.
    ///
    /// ეს ეხება მაშინაც კი, თუ ამ მეთოდის შედეგი გამოუყენებელია!
    /// (ნაწილი, რომლის ინიცირება ჯერ კიდევ სრულად არ არის გადაწყვეტილი, მაგრამ სანამ ეს გაკეთდება, ერთადერთი უსაფრთხო მიდგომაა იმის უზრუნველყოფა, რომ ისინი მართლაც შედგეს.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `self` აკმაყოფილებს ყველა
        // მუტაბელური მითითების მოთხოვნები.
        unsafe { &mut *self.as_ptr() }
    }

    /// ისვრის სხვა ტიპის მაჩვენებელს.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // უსაფრთხოება: `self` არის `NonNull` მაჩვენებელი, რომელიც აუცილებლად არ არის ნულოვანი
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// ქმნის არა-ნულოვან დაუმუშავებელ ნაჭერს თხელი მაჩვენებლისა და სიგრძისგან.
    ///
    /// `len` არგუმენტი არის **ელემენტების** რაოდენობა და არა ბაიტების რაოდენობა.
    ///
    /// ეს ფუნქცია უსაფრთხოა, მაგრამ დაბრუნების მნიშვნელობის გადამისამართება არ არის უსაფრთხო.
    /// [`slice::from_raw_parts`]- ის დოკუმენტაცია იხილეთ უსაფრთხოების უსაფრთხოების მოთხოვნებისთვის.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // შექმენით ნაჭერი მაჩვენებელი პირველი ელემენტის მაჩვენებლის დაწყებისას
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (გაითვალისწინეთ, რომ ეს მაგალითი ხელოვნურად აჩვენებს ამ მეთოდის გამოყენებას, მაგრამ `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // უსაფრთხოება: `data` არის `NonNull` მაჩვენებელი, რომელიც აუცილებლად არ არის ნულოვანი
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// აბრუნებს ნულოვანი ნედლი ნაჭრის სიგრძეს.
    ///
    /// დაბრუნებული მნიშვნელობა არის **ელემენტების** რიცხვი და არა ბაიტების რაოდენობა.
    ///
    /// ეს ფუნქცია უსაფრთხოა, მაშინაც კი, როდესაც ნულოვანი ნედლი ნაჭრის ნაწყვეტის გადაცემა შეუძლებელია, რადგან მაჩვენებელს არ აქვს სწორი მისამართი.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// უბრუნებს არასამთავრობო null მაჩვენებელს ნაჭრის ბუფერზე.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // უსაფრთხოება: ჩვენ ვიცით, რომ `self` არ არის ნულოვანი.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// უბრუნებს ნედლეულის მაჩვენებელს ნაჭრის ბუფერში.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// აბრუნებს გაზიარებულ მითითებას შესაძლოა არაუნიციალიზებული მნიშვნელობების ნაჭერზე.[`as_ref`]-ისგან განსხვავებით, ეს არ საჭიროებს მნიშვნელობის ინიციალიზაციას.
    ///
    /// მუტაბელური კოლეგისთვის იხილეთ [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// ამ მეთოდის გამოძახებისას უნდა დარწმუნდეთ, რომ ყველა ქვემოთჩამოთვლილი სიმართლეა:
    ///
    /// * მაჩვენებელი უნდა იყოს [valid], რომ წაიკითხოს `ptr.len() * mem::size_of::<T>()` მრავალი ბაიტი და ის სწორად უნდა იყოს გასწორებული.ეს განსაკუთრებით ნიშნავს:
    ///
    ///     * ამ ნაჭრის მეხსიერების მთელი დიაპაზონი უნდა შეიცავდეს ცალკე გამოყოფილ ობიექტს!
    ///       ნაჭრები ვერასოდეს გადაფარავს მრავალ გამოყოფილ ობიექტს.
    ///
    ///     * მაჩვენებელი გასწორებული უნდა იყოს ნულოვანი სიგრძის ნაჭრებისთვისაც კი.
    ///     ამის ერთი მიზეზი არის ის, რომ enum განლაგების ოპტიმიზაცია შეიძლება დაეყრდნოს მითითებებს (ნებისმიერი სიგრძის ნაჭრების ჩათვლით) გასწორებულ და არასასურველი, რომ განასხვაოს ისინი სხვა მონაცემებისგან.
    ///
    ///     შეგიძლიათ მიიღოთ მაჩვენებელი, რომელიც გამოსაყენებელია როგორც `data` ნულოვანი სიგრძის ნაჭრებისთვის [`NonNull::dangling()`].
    ///
    /// * ნაჭრის საერთო ზომა `ptr.len() * mem::size_of::<T>()` არ უნდა აღემატებოდეს `isize::MAX`.
    ///   იხილეთ [`pointer::offset`] უსაფრთხოების დოკუმენტაცია.
    ///
    /// * თქვენ უნდა შეასრულოთ Rust- ის დამაკავშირებელი წესები, ვინაიდან დაბრუნებული სიცოცხლის ხანგრძლივობა `'a` თვითნებურად არის არჩეული და სულაც არ ასახავს მონაცემთა რეალურ სიცოცხლეს.
    ///   კერძოდ, ამ სიცოცხლის მანძილზე მეხსიერება, რომელზეც მიუთითებს მაჩვენებელი, არ უნდა შეიცვალოს (გარდა `UnsafeCell`- ის შიგნით).
    ///
    /// ეს ეხება მაშინაც კი, თუ ამ მეთოდის შედეგი გამოუყენებელია!
    ///
    /// აგრეთვე [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // უსაფრთხოება: აბონენტმა უნდა დაიცვას უსაფრთხოების კონტრაქტი `as_uninit_slice`- სთვის.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// აბრუნებს უნიკალურ მითითებას შესაძლოა არაუნიციალიზებული მნიშვნელობების ნაჭერზე.[`as_mut`]-ისგან განსხვავებით, ეს არ საჭიროებს მნიშვნელობის ინიციალიზაციას.
    ///
    /// გაზიარებული კოლეგისთვის იხილეთ [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// ამ მეთოდის გამოძახებისას უნდა დარწმუნდეთ, რომ ყველა ქვემოთჩამოთვლილი სიმართლეა:
    ///
    /// * მაჩვენებელი უნდა იყოს [valid] წაკითხვისთვის და წერს `ptr.len() * mem::size_of::<T>()` მრავალი ბაიტისთვის და ის სწორად უნდა იყოს გასწორებული.ეს განსაკუთრებით ნიშნავს:
    ///
    ///     * ამ ნაჭრის მეხსიერების მთელი დიაპაზონი უნდა შეიცავდეს ცალკე გამოყოფილ ობიექტს!
    ///       ნაჭრები ვერასოდეს გადაფარავს მრავალ გამოყოფილ ობიექტს.
    ///
    ///     * მაჩვენებელი გასწორებული უნდა იყოს ნულოვანი სიგრძის ნაჭრებისთვისაც კი.
    ///     ამის ერთი მიზეზი არის ის, რომ enum განლაგების ოპტიმიზაცია შეიძლება დაეყრდნოს მითითებებს (ნებისმიერი სიგრძის ნაჭრების ჩათვლით) გასწორებულ და არასასურველი, რომ განასხვაოს ისინი სხვა მონაცემებისგან.
    ///
    ///     შეგიძლიათ მიიღოთ მაჩვენებელი, რომელიც გამოსაყენებელია როგორც `data` ნულოვანი სიგრძის ნაჭრებისთვის [`NonNull::dangling()`].
    ///
    /// * ნაჭრის საერთო ზომა `ptr.len() * mem::size_of::<T>()` არ უნდა აღემატებოდეს `isize::MAX`.
    ///   იხილეთ [`pointer::offset`] უსაფრთხოების დოკუმენტაცია.
    ///
    /// * თქვენ უნდა შეასრულოთ Rust- ის დამაკავშირებელი წესები, ვინაიდან დაბრუნებული სიცოცხლის ხანგრძლივობა `'a` თვითნებურად არის არჩეული და სულაც არ ასახავს მონაცემთა რეალურ სიცოცხლეს.
    ///   კერძოდ, ამ სიცოცხლის განმავლობაში, მეხსიერებაზე, რომელზეც მიუთითებს მაჩვენებელი, არ უნდა იქნეს ხელმისაწვდომი (წაკითხული ან დაწერილი) ნებისმიერი სხვა მაჩვენებლის მეშვეობით.
    ///
    /// ეს ეხება მაშინაც კი, თუ ამ მეთოდის შედეგი გამოუყენებელია!
    ///
    /// აგრეთვე [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // ეს უსაფრთხოა, რადგან `memory` მოქმედებს `memory.len()` მრავალი ბაიტის კითხვასა და წერაში.
    /// // გაითვალისწინეთ, რომ აქ დაუშვებელია `memory.as_mut()` დარეკვა, რადგან შინაარსი შეიძლება იყოს არაინციალიზებული.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // უსაფრთხოება: აბონენტმა უნდა დაიცვას უსაფრთხოების კონტრაქტი `as_uninit_slice_mut`- სთვის.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// უბრუნებს ნედლეულ მაჩვენებელს ელემენტს ან ქვესახეობას, საზღვრების შემოწმების გარეშე.
    ///
    /// ამ მეთოდის გამოძახება საზღვარგარეთ ინდექსით ან როდესაც `self` არ არის მოხსენიებული არის *[განუსაზღვრელი ქცევა]* მაშინაც კი, თუ მიღებული მაჩვენებელი არ არის გამოყენებული.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // უსაფრთხოება: აბონენტი უზრუნველყოფს `self` მოხსენიებას და `index` საზღვრებში.
        // შედეგად, მიღებული მაჩვენებელი არ შეიძლება იყოს NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // უსაფრთხოება: უნიკალური მაჩვენებელი არ შეიძლება იყოს ნულოვანი, ამიტომ პირობები
        // new_unchecked() პატივს სცემენ.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // უსაფრთხოება: ცვალებადი მითითება არ შეიძლება იყოს ბათილი.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // უსაფრთხოება: მითითება არ შეიძლება იყოს ნულოვანი, ამიტომ პირობები
        // new_unchecked() პატივს სცემენ.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}