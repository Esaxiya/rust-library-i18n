#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// გთავაზობთ მაჩვენებლის მეტამონაცემების ტიპს ნებისმიერი მითითებული ტიპისთვის.
///
/// # მაჩვენებლის მეტამონაცემები
///
/// ნედლეულის მაჩვენებლის ტიპები და მითითების ტიპები Rust- ში შეიძლება მივიჩნიოთ ორი ნაწილისგან:
/// მონაცემთა მაჩვენებელი, რომელიც შეიცავს მნიშვნელობის მეხსიერების მისამართს და ზოგიერთ მეტამონაცემს.
///
/// სტატიკური ზომის ტიპებისთვის (რომლებიც ახორციელებენ `Sized` traits) ასევე `extern` ტიპებისთვის, მითითებულია რომ `წვრილი` მითითებულია: მეტამონაცემები ნულოვანი ზომისაა და მისი ტიპი `()`.
///
///
/// [dynamically-sized types][dst] მითითებულ მითითებებზე ნათქვამია "ფართო" ან "ცხიმიანი", მათ აქვთ ნულოვანი ზომის მეტამონაცემები:
///
/// * სტრეტებისთვის, რომელთა ბოლო ველია DST, მეტამონაცემები არის მეტადა მონაცემები ბოლო ველისთვის
/// * `str` ტიპისთვის მეტამონაცემების სიგრძეა ბაიტებში `usize`
/// * `[T]` ტიპის ნაჭრებისთვის მეტამონაცემების სიგრძე ერთეულებში არის `usize`
/// * trait ობიექტებისთვის, როგორიცაა `dyn SomeTrait`, მეტამონაცემები არის [`DynMetadata<Self>`][DynMetadata] (მაგ. `DynMetadata<dyn SomeTrait>`)
///
/// future-ში Rust ენამ შეიძლება შეიძინოს ახალი ტიპის ტიპები, რომლებსაც აქვთ სხვადასხვა მაჩვენებლის მეტამონაცემები.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// ამ trait-ის წერტილი არის მისი `Metadata` ასოცირებული ტიპი, რომელიც არის `()` ან `usize` ან `DynMetadata<_>`, როგორც ზემოთ არის აღწერილი.
/// ის ავტომატურად ხორციელდება ყველა ტიპისთვის.
/// შეიძლება ვივარაუდოთ, რომ იგი უნდა განხორციელდეს ზოგად კონტექსტში, შესაბამისი ნიშნების გარეშეც.
///
/// # Usage
///
/// ნედლეული მითითების დაშლა შესაძლებელია მონაცემთა მისამართსა და მეტამონაცემების კომპონენტებში მათი [`to_raw_parts`] მეთოდით.
///
/// გარდა ამისა, მხოლოდ მეტადატის მოპოვება შეიძლება [`metadata`] ფუნქციით.
/// მითითება შეიძლება გადაეცეს [`metadata`]- ს და მინიშნებით აიძულოს.
///
/// (possibly-wide) მაჩვენებლის დაყენება შესაძლებელია მისი მისამართიდან და მეტამონაცემები [`from_raw_parts`] ან [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// მეტამონაცემების ტიპი მითითებებში და მითითებები `Self`-ზე.
    #[lang = "metadata_type"]
    // NOTE: შეინახეთ trait bounds `static_assert_expected_bounds_for_metadata`- ში
    //
    // `library/core/src/ptr/metadata.rs`- ში სინქრონიზებული აქაურებთან:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// trait ზედმეტსახელის განმახორციელებელი ტიპების მითითებები "წვრილი"ა.
///
/// ეს მოიცავს სტატისტიკურად "ზომის" ტიპებს და `extern` ტიპებს.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: არ მოახდინოთ სტაბილიზაცია, სანამ trait მეტსახელები სტაბილურია ენაში?
pub trait Thin = Pointee<Metadata = ()>;

/// ამოიღეთ მაჩვენებლის მეტამონაცემების კომპონენტი.
///
/// `*mut T`, `&T` ან `&mut T` ტიპის მნიშვნელობები შეიძლება პირდაპირ გადაეცეს ამ ფუნქციას, რადგან ისინი ირიბად იძულებიან `* const T`-ს.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // უსაფრთხოება: `PtrRepr` კავშირის მნიშვნელობაზე წვდომა უსაფრთხოა, რადგან * const T
    // და PtrComponents<T>მეხსიერების იგივე განლაგებები აქვთ.
    // მხოლოდ std- ს შეუძლია ამ გარანტიის გაკეთება.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// ქმნის (possibly-wide) დაუმუშავებელ მაჩვენებელს მონაცემთა მისამართისა და მეტამონაცემებისგან.
///
/// ეს ფუნქცია უსაფრთხოა, მაგრამ დაბრუნებული მაჩვენებელი სულაც არ არის უსაფრთხო გადამისამართებისთვის.
/// ნაჭრებისთვის, უსაფრთხოების მოთხოვნებისათვის იხილეთ [`slice::from_raw_parts`] დოკუმენტაცია.
/// trait ობიექტებისთვის მეტამონაცემები უნდა მოვიდეს მაჩვენებელიდან იმავე ძირითად გამსწორებულ ტიპზე.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // უსაფრთხოება: `PtrRepr` კავშირის მნიშვნელობაზე წვდომა უსაფრთხოა, რადგან * const T
    // და PtrComponents<T>მეხსიერების იგივე განლაგებები აქვთ.
    // მხოლოდ std- ს შეუძლია ამ გარანტიის გაკეთება.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// ასრულებს იგივე ფუნქციურობას, როგორც [`from_raw_parts`], გარდა იმისა, რომ ნედლეული `*mut` მაჩვენებელი უბრუნდება, განსხვავებით ნედლეული `* const` მაჩვენებლისგან.
///
///
/// დამატებითი ინფორმაციისთვის იხილეთ [`from_raw_parts`] დოკუმენტაცია.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // უსაფრთხოება: `PtrRepr` კავშირის მნიშვნელობაზე წვდომა უსაფრთხოა, რადგან * const T
    // და PtrComponents<T>მეხსიერების იგივე განლაგებები აქვთ.
    // მხოლოდ std- ს შეუძლია ამ გარანტიის გაკეთება.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// საჭიროა სახელმძღვანელო მითითება, რომ თავიდან იქნას აცილებული `T: Copy` შეკრული.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// საჭიროა სახელმძღვანელო მითითება, რომ თავიდან იქნას აცილებული `T: Clone` შეკრული.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// მეტამონაცემები `Dyn = dyn SomeTrait` trait ობიექტის ტიპისთვის.
///
/// ეს არის მაგიდის მიმანიშნებელი (ვირტუალური ზარის ცხრილი), რომელიც წარმოადგენს ყველა საჭირო ინფორმაციას trait ობიექტის შიგნით შენახული ბეტონის ტიპის მანიპულირებისთვის.
/// განსაკუთრებით მნიშვნელოვანია ის:
///
/// * ტიპის ზომა
/// * ტიპის გასწორება
/// * ტიპის `drop_in_place` impl-ის მაჩვენებელი (შეიძლება იყოს ძველი-ძველი მონაცემების აკრძალვა)
/// * მიუთითებს trait ტიპის განხორციელების ყველა მეთოდზე
///
/// გაითვალისწინეთ, რომ პირველი სამი განსაკუთრებულია, რადგან ისინი აუცილებელია ნებისმიერი trait ობიექტის გამოყოფისთვის, ჩამოსაშლელად და გამოყოფისთვის.
///
/// შესაძლებელია ამ სტრუქტურის დასახელება პარამეტრით, რომელიც არ არის `dyn` trait ობიექტი (მაგალითად `DynMetadata<u64>`), მაგრამ არ მიიღოს ამ სტრუქტურის მნიშვნელოვანი მნიშვნელობა.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// ყველა vtables-ის საერთო პრეფიქსი.მას მოჰყვება ფუნქციის მითითებები trait მეთოდებისთვის.
///
/// `DynMetadata::size_of`- ის პირადი განხორციელების დეტალები და ა.შ.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// აბრუნებს ამ ზომის მაგიდასთან დაკავშირებული ტიპის ზომას.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// აბრუნებს ამ vtable-სთან დაკავშირებული ტიპის გასწორებას.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// აბრუნებს ზომას და მისწორებას ერთად, როგორც `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // უსაფრთხოება: შემდგენელმა გამოაქვეყნა ეს მაგიდა კონკრეტული Rust ტიპისთვის
        // ცნობილია, რომ აქვს სწორი განლაგება.იგივე საფუძველი, როგორც `Layout::for_value`-ში.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// სახელმძღვანელო გულისხმობს `Dyn: $Trait` საზღვრების თავიდან ასაცილებლად.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}