#![stable(feature = "duration_core", since = "1.25.0")]

//! დროებითი რაოდენობრივი განსაზღვრა.
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // ორივე დეკლარაცია ეკვივალენტურია
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// `Duration` ტიპი წარმოადგენს დროის ხანგრძლივობას, რომელიც ჩვეულებრივ გამოიყენება სისტემის შეყოვნებისთვის.
///
/// თითოეული `Duration` შედგება წამების მთლიანი რაოდენობისა და ნანოწამებში წარმოდგენილი ფრაქციული ნაწილისაგან.
/// თუ ფუძემდებლური სისტემა არ უჭერს მხარს ნანოწამების დონის სიზუსტეს, API-ები, რომლებიც აკავშირებენ სისტემის შეყოვნებას, ჩვეულებრივ შეამცირებენ ნანოწამების რაოდენობას.
///
/// ["ხანგრძლივობა"] ახორციელებს ბევრ გავრცელებულ traits-ს, მათ შორის [`Add`], [`Sub`] და სხვა [`ops`] traits.იგი ახორციელებს [`Default`]-ს ნულოვანი სიგრძის `Duration` დაბრუნებით.
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # `Duration` მნიშვნელობების ფორმატირება
///
/// `Duration` განზრახ არ აქვს `Display` impl, რადგან არსებობს დროის ამოხსნის მრავალფეროვანი გზა ადამიანის წაკითხვისთვის.
/// `Duration` უზრუნველყოფს `Debug` მნიშვნელობას, რომელიც აჩვენებს მნიშვნელობის სრულ სიზუსტეს.
///
/// `Debug` გამომავალი იყენებს არა ASCII "µs" სუფიქსს მიკროწამისთვის.
/// თუ თქვენი პროგრამის გამომუშავება შეიძლება აღმოჩნდეს კონტექსტში, რომელსაც არ შეუძლია დაეყრდნოს უნიკოდის სრულ თავსებადობას, თქვენ მოისურვებთ თვითონ დააფორმატოთ `Duration` ობიექტი ან გამოიყენოთ crate ამისათვის.
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // ყოველთვის 0 <=ნანო <NANOS_PER_SEC
}

impl Duration {
    /// ხანგრძლივობა ერთი წამი.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// ხანგრძლივობა ერთი მილიწამი.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// ხანგრძლივობა ერთი მიკროწამი.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// ხანგრძლივობა ერთი ნანოწამი.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// ნულოვანი დროის ხანგრძლივობა.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// მაქსიმალური ხანგრძლივობა.
    ///
    /// იგი უდრის 584,942,417,355 წლის ხანგრძლივობას.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// ქმნის ახალ `Duration`-ს მთელი წამების და დამატებითი ნანოწამების მითითებული რაოდენობიდან.
    ///
    /// თუ ნანოწამების რაოდენობა 1 მილიარდზე მეტია (ნანოწამების რაოდენობა წამში), მაშინ ის გადაეცემა მოცემულ წამებში.
    ///
    ///
    /// # Panics
    ///
    /// ეს კონსტრუქტორი panic იქნება, თუ ნანოწამების გადატანა წამის მრიცხველს გადაფენს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// ქმნის ახალ `Duration`-ს მთელი წამების მითითებული რაოდენობიდან.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// ქმნის ახალ `Duration` მილიწამების მითითებული რაოდენობიდან.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// ქმნის ახალ `Duration`-ს მიკროწამების მითითებული რაოდენობიდან.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// ქმნის ახალ `Duration` ნანოწამების მითითებული რაოდენობიდან.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// აბრუნებს ჭეშმარიტს, თუ ეს `Duration` დრო არ დაგრჩება.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// აბრუნებს ამ `Duration` შეიცავს _whole_ წამის რაოდენობას.
    ///
    /// დაბრუნებული მნიშვნელობა არ შეიცავს ხანგრძლივობის ფრაქციულ (nanosecond) ნაწილს, რომლის მიღება შესაძლებელია [`subsec_nanos`] გამოყენებით.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// `Duration`-ით წარმოდგენილი წამების საერთო რაოდენობის დასადგენად გამოიყენეთ `as_secs` [`subsec_nanos`]-თან ერთად:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// აბრუნებს ამ `Duration`-ის ფრაქციულ ნაწილს, მთელ მილიწამებში.
    ///
    /// ეს მეთოდი ** არ უბრუნებს ხანგრძლივობის ხანგრძლივობას, როდესაც მილიწამებით არის წარმოდგენილი.
    /// დაბრუნებული რიცხვი ყოველთვის წარმოადგენს წამის წილადობრივ ნაწილს (ანუ ის ათასზე ნაკლებია).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// აბრუნებს ამ `Duration`-ის ფრაქციულ ნაწილს, მთელ მიკროწამებში.
    ///
    /// ეს მეთოდი ** არ უბრუნებს ხანგრძლივობის ხანგრძლივობას, როდესაც წარმოდგენილია მიკროწამებით.
    /// დაბრუნებული რიცხვი ყოველთვის წარმოადგენს წამის წილადობრივ ნაწილს (ანუ ის ერთ მილიონზე ნაკლებია).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// აბრუნებს ამ `Duration`- ის ფრაქციულ ნაწილს, ნანოწამებში.
    ///
    /// ეს მეთოდი ** არ უბრუნებს ხანგრძლივობის ხანგრძლივობას, როდესაც წარმოდგენილია ნანოწამებით.
    /// დაბრუნებული რიცხვი ყოველთვის წარმოადგენს წამის წილადობრივ ნაწილს (ეს არის ერთ მილიარდზე ნაკლები).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// აბრუნებს მთლიანი მილიწამების მთლიან რაოდენობას, რომელიც შეიცავს ამ `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// აბრუნებს ამ მიკროწამების მთლიან რაოდენობას, რომელსაც შეიცავს ამ `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// აბრუნებს ამ `Duration` შეიცავს ნანოწამების საერთო რაოდენობას.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// შემოწმდა `Duration` დამატება.
    /// გამოთვლის `self + other`-ს, უბრუნებს [`None`]-ს, თუ გადავსება მოხდა.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// `Duration` დამატების გაჯერება.
    /// გამოთვლის `self + other`-ს, უბრუნებს [`Duration::MAX`]-ს, თუ გადავსება მოხდა.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// შემოწმებულია `Duration` გამოკლება.
    /// გამოთვლის `self - other`-ს, უბრუნებს [`None`]-ს, თუ შედეგი უარყოფითი იქნება ან მოხდა გადავსება.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// `Duration` გამოკლების გაჯერება.
    /// გამოთვლის `self - other`-ს, უბრუნებს [`Duration::ZERO`]-ს, თუ შედეგი უარყოფითი იქნება ან მოხდა გადავსება.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// შემოწმებულია `Duration` გამრავლება.
    /// გამოთვლის `self * other`-ს, უბრუნებს [`None`]-ს, თუ გადავსება მოხდა.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // გამრავლებული ნანოწამები u64- ით, რადგან მას ასე არ შეუძლია გადაფრენა.
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// `Duration` გამრავლების გაჯერება.
    /// გამოთვლის `self * other`-ს, უბრუნებს [`Duration::MAX`]-ს, თუ გადავსება მოხდა.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// შემოწმებულია `Duration` განყოფილება.
    /// გამოთვლის `self / other`-ს, უბრუნებს [`None`]-ს, თუ `other == 0`-ს.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// აბრუნებს ამ `Duration`- ში მოცემული წამების რაოდენობას, როგორც `f64`.
    /// დაბრუნებული მნიშვნელობა მოიცავს ხანგრძლივობის ფრაქციულ (nanosecond) ნაწილს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// აბრუნებს ამ `Duration`- ში მოცემული წამების რაოდენობას, როგორც `f32`.
    /// დაბრუნებული მნიშვნელობა მოიცავს ხანგრძლივობის ფრაქციულ (nanosecond) ნაწილს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// ქმნის ახალ `Duration`-ს მითითებული წამებიდან `f64`-ით.
    ///
    /// # Panics
    /// ეს კონსტრუქტორი panic იქნება, თუ `secs` არ არის სასრული, უარყოფითი ან გადავსებულია `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// ქმნის ახალ `Duration`-ს მითითებული წამებიდან `f32`-ით.
    ///
    /// # Panics
    /// ეს კონსტრუქტორი panic იქნება, თუ `secs` არ არის სასრული, უარყოფითი ან გადავსებულია `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// ამრავლებს `Duration`- ს `f64`- ზე.
    /// # Panics
    /// ეს მეთოდი panic იქნება, თუ შედეგი არ არის სასრული, უარყოფითი ან გადავსებულია `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// ამრავლებს `Duration`- ს `f32`- ზე.
    /// # Panics
    /// ეს მეთოდი panic იქნება, თუ შედეგი არ არის სასრული, უარყოფითი ან გადავსებულია `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // გაითვალისწინეთ, რომ დამრგვალების შეცდომების გამო შედეგი ოდნავ განსხვავდება 8.478 და 847800.0- ისგან
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// `Duration` გაყავით `f64`.
    /// # Panics
    /// ეს მეთოდი panic იქნება, თუ შედეგი არ არის სასრული, უარყოფითი ან გადავსებულია `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // გაითვალისწინეთ, რომ გამოიყენება დამსხვრევა და არა დამრგვალება
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// `Duration` გაყავით `f32`.
    /// # Panics
    /// ეს მეთოდი panic იქნება, თუ შედეგი არ არის სასრული, უარყოფითი ან გადავსებულია `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // გაითვალისწინეთ, რომ დამრგვალების შეცდომების გამო შედეგი ოდნავ განსხვავდება 0.859_872_611- ისგან
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // გაითვალისწინეთ, რომ გამოიყენება დამსხვრევა და არა დამრგვალება
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// დაიყოს `Duration` `Duration` და დააბრუნე `f64`.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// დაიყოს `Duration` `Duration` და დააბრუნე `f32`.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// აყალიბებს მცურავი წერტილის რიცხვს ათობითი აღნიშვნით.
        ///
        /// ნომერი მოცემულია როგორც `integer_part` და ფრაქციული ნაწილი.
        /// ფრაქციული ნაწილის ღირებულებაა `fractional_part / divisor`.
        /// ასე რომ, `integer_part` =3, `fractional_part` =12 და `divisor` =100 წარმოადგენს რიცხვს `3.012`.
        /// უკან გამოტოვებული ნულები გამოტოვებულია.
        ///
        /// `divisor` არ უნდა იყოს 100_000_000 ზე მეტი.
        /// ეს ასევე უნდა იყოს 10 - ის ძალა, ყველა დანარჩენს აზრი არ აქვს.
        /// `fractional_part` უნდა იყოს `10 * divisor`- ზე ნაკლები!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // ფრაქციული ნაწილის კოდირება დროებით ბუფერში.
            // ბუფერს მხოლოდ 9 ელემენტის გამართვა სჭირდება, რადგან `fractional_part` უნდა იყოს 10 ^ 9-ზე ნაკლები.
            //
            // ქვემოთ მოცემული კოდის გასამარტივებლად ბუფერი ივსება '0' ციფრებით.
            let mut buf = [b'0'; 9];

            // შემდეგი პოზიცია იწერება ამ პოზიციაზე
            let mut pos = 0;

            // ჩვენ ვაგრძელებთ ბუფერულ ციფრებში ჩაწერას, ხოლო ნულოვანი ციფრებია დარჩენილი და ჯერ საკმარისი ციფრები არ გვაქვს დაწერილი.
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // ჩაწერეთ ახალი ციფრი ბუფერში
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // თუ სიზუსტე <9 იყო მითითებული, შეიძლება დარჩეს ნულოვანი ციფრები, რომლებიც არ იყო დაწერილი ბუფერულში.
            // ამ შემთხვევაში უნდა შევასრულოთ დამრგვალება, რომ ემთხვეოდეს ნორმალური მცურავი წერტილების ციფრების დაბეჭდვის სემანტიკას.
            // ამასთან, სამუშაოს შესრულება მხოლოდ და მხოლოდ დამრგვალების დროს გვჭირდება.
            // ეს ხდება, თუ დარჩენილი ციფრების პირველი ციფრია>=5.
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // დამრგვალეთ ბუფერში მოთავსებული ნომერი.
                // ჩვენ ბუფერულს უკან მივდივართ და თვალყურს ვადევნებთ გადაზიდვას.
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // თუ ბუფერული ციფრი არ არის '9', ჩვენ უბრალოდ უნდა გავზარდოთ იგი და შეგვიძლია შეჩერება (რადგან გადაზიდვა აღარ გვაქვს).
                    // წინააღმდეგ შემთხვევაში, ჩვენ დავაყენეთ '0' (overflow) და გავაგრძელებთ.
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // თუ მაინც გვაქვს გადასატანი ბიტის სიმრავლე, ეს ნიშნავს, რომ მთელი ბუფერი დავაყენეთ '0-ზე და საჭიროა მთელი ნაწილის გაზრდა.
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // განსაზღვრეთ ბუფერის დასასრული: თუ სიზუსტეა მითითებული, ჩვენ მხოლოდ იმდენ ციფრს ვიყენებთ ბუფერიდან (9-მდე).
            // თუ ის დაყენებული არ არის, ჩვენ ვიყენებთ მხოლოდ ყველა ციფრს ბოლო არა ნულოვანამდე.
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // თუ ჩვენ არ გამოვუშვით ერთი ფრაქციული ციფრი და სიზუსტე არ არის მითითებული ნულოვანი მნიშვნელობით, ჩვენ არ ვბეჭდავთ ათობითი წერტილს.
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // უსაფრთხოება: ჩვენ მხოლოდ ASCII ციფრებს ვწერთ ბუფერში და ეს იყო
                // ინიცირებული იყო 0-ით, ასე რომ, იგი შეიცავს მოქმედი UTF8.
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // თუ მომხმარებელი ითხოვს სიზუსტეს> 9-ს, ჩვენ ბოლოში ვათავსებთ "0-ს".
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // მოთხოვნის შემთხვევაში დაბეჭდეთ წამყვანი '+' ნიშანი
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}