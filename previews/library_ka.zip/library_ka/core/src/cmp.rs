//! ფუნქციონირების შეკვეთა და შედარება.
//!
//! ეს მოდული შეიცავს სხვადასხვა ინსტრუმენტებს მნიშვნელობების შეკვეთისა და შედარებისთვის.Ჯამში:
//!
//! * [`Eq`] და [`PartialEq`] არის traits, რომელიც საშუალებას გაძლევთ განსაზღვროთ ტოტალური და ნაწილობრივი თანასწორობა ღირებულებებს შორის, შესაბამისად.
//! მათი განხორციელება გადატვირთავს `==` და `!=` ოპერატორებს.
//! * [`Ord`] და [`PartialOrd`] არის traits, რომლის საშუალებითაც შეგიძლიათ განსაზღვროთ ტოტალური და ნაწილობრივი შეკვეთები მნიშვნელობებს შორის, შესაბამისად.
//!
//! მათი განხორციელება გადატვირთავს `<`, `<=`, `>` და `>=` ოპერატორებს.
//! * [`Ordering`] არის [`Ord`] და [`PartialOrd`] ძირითადი ფუნქციების მიერ დაბრუნებული enum და აღწერს შეკვეთას.
//! * [`Reverse`] არის სტრუქტურა, რომელიც საშუალებას გაძლევთ მარტივად შეცვალოთ შეკვეთა.
//! * [`max`] და [`min`] არის ფუნქციები, რომლებიც აშენებენ [`Ord`]- ს და საშუალებას გაძლევთ იპოვოთ მაქსიმალური ან მინიმალური ორი მნიშვნელობა.
//!
//! დამატებითი ინფორმაციისთვის იხილეთ თითოეული პუნქტის შესაბამისი დოკუმენტაცია სიაში.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait თანასწორობის შედარებისთვის, რომელიც არის [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// ეს trait იძლევა ნაწილობრივ თანასწორობას, იმ ტიპებისთვის, რომლებსაც არ აქვთ სრული ეკვივალენტობის კავშირი.
/// მაგალითად, მცურავი წერტილების რიცხვებში `NaN != NaN`, ასე რომ მცურავი წერტილების ტიპები ახორციელებენ `PartialEq`- ს, მაგრამ არა [`trait@Eq`]- ს.
///
/// ფორმალურად, თანასწორობა უნდა იყოს (ყველა `a`, `b`, `c` ტიპის `A`, `B`, `C`):
///
/// - **სიმეტრიული**: თუ `A: PartialEq<B>` და `B: PartialEq<A>`, მაშინ **`a==b` გულისხმობს`b==a`**;და
///
/// - **ტრანზიტული**: თუ `A: PartialEq<B>` და `B: PartialEq<C>` და `A:
///   ნაწილობრივი ეკ<C>`, მაშინ **` a==b`და `b == c` გულისხმობს`a==c`**.
///
/// გაითვალისწინეთ, რომ `B: PartialEq<A>` (symmetric) და `A: PartialEq<C>` (transitive) იმპულსები იძულებითი არ არის, მაგრამ ეს მოთხოვნები ვრცელდება, როდესაც ისინი არსებობენ.
///
/// ## Derivable
///
/// ეს trait შეიძლება გამოყენებულ იქნას `#[derive]`.როდესაც სტრიქონებზე `გამომდინარეობს`, ორი ინსტანცია ტოლია, თუ ყველა ველი ტოლია, და არ არის ტოლი, თუ რომელიმე ველი არ არის ტოლი.როდესაც `წარმოიქმნება d enum-ზე, თითოეული ვარიანტი ტოლია თავისთავად და არ უდრის სხვა ვარიანტებს.
///
/// ## როგორ შემიძლია განვახორციელო `PartialEq`?
///
/// `PartialEq` საჭიროა მხოლოდ [`eq`] მეთოდის დანერგვა;[`ne`] სტანდარტულად განისაზღვრება მისი თვალსაზრისით.[`ne`]*-ის ნებისმიერი ხელით შესრულება* უნდა იცავდეს წესს, რომ [`eq`] არის [`ne`]- ის მკაცრი ინვერსია;ეს არის `!(a == b)` თუ მხოლოდ `a != b`.
///
/// `PartialEq`, [`PartialOrd`] და [`Ord`]*-ის დანერგვები* უნდა შეთანხმდნენ ერთმანეთთან.ადვილია შემთხვევით დაათანხმო მათ, რომ არ დაეთანხმონ traits- ის ზოგიერთი ნაწილის გამოყოფით და სხვების ხელით განხორციელებით.
///
/// იმ დომენის იმპლემენტაციის მაგალითი, რომელშიც ორი წიგნი ითვლება ერთნაირ წიგნად, თუ მათი ISBN ემთხვევა, მაშინაც კი, თუ ფორმატები განსხვავდება:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## როგორ შემიძლია შევადარო ორი განსხვავებული ტიპი?
///
/// ტიპს, რომლის შედარებაც შეგიძლიათ, ხორციელდება `PartialEq` ტიპის პარამეტრით.
/// მაგალითად, მოდით ცოტათი მოვაგვაროთ ჩვენი წინა კოდი:
///
/// ```
/// // Derive ახორციელებს<BookFormat>==<BookFormat>შედარებები
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // განხორციელება<Book>==<BookFormat>შედარებები
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // განხორციელება<BookFormat>==<Book>შედარებები
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book`- ით `impl PartialEq<BookFormat> for Book`- ით შეცვლით ჩვენ საშუალებას გვაძლევს `BookFormat` შედარდეს`Book's`.
///
/// ზემოთ მოყვანილი შედარება, რომელიც სტრუქტურის ზოგიერთ სფეროს უგულებელყოფს, შეიძლება საშიში იყოს.მას შეუძლია ადვილად გამოიწვიოს ნაწილობრივი ეკვივალენტობის მიმართების მოთხოვნების არასასურველი დარღვევა.
/// მაგალითად, თუ ჩვენ შევინარჩუნეთ `PartialEq<Book>`- ის ზემოთ მოყვანილი დანერგვა `BookFormat`- სთვის და დავამატეთ `PartialEq<Book>`- ის `Book`- ის განხორციელება (ან `#[derive]`- ის საშუალებით ან პირველი მაგალითის სახელმძღვანელო გამოყენებით), მაშინ ეს დაარღვევს ტრანზიტულობას:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// ეს მეთოდი ამოწმებს `self` და `other` მნიშვნელობების ტოლობას და გამოიყენება `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// ეს მეთოდი ტესტებს `!=`- ს.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq`-ის გავლენის წარმოქმნის მაკრო.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait თანასწორობის შედარებისთვის, რომელიც არის [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// ეს ნიშნავს, რომ გარდა იმისა, რომ `a == b` და `a != b` მკაცრი ინვერსია, თანასწორობა უნდა იყოს (ყველა `a`, `b` და `c`):
///
/// - reflexive: `a == a`;
/// - სიმეტრიული: `a == b` გულისხმობს `b == a`;და
/// - ტრანზიტული: `a == b` და `b == c` გულისხმობს `a == c`.
///
/// შემდგენელს არ შეუძლია შეამოწმოს ეს თვისება, ამიტომ `Eq` გულისხმობს [`PartialEq`]-ს და მას არ აქვს დამატებითი მეთოდები.
///
/// ## Derivable
///
/// ეს trait შეიძლება გამოყენებულ იქნას `#[derive]`.
/// `გამომდინარეობს`d, რადგან `Eq` არ აქვს ზედმეტი მეთოდები, იგი მხოლოდ აცნობებს შემდგენელს, რომ ეს არის ეკვივალენტობის მიმართება და არა ნაწილობრივი ეკვივალენტობის მიმართება.
///
/// გაითვალისწინეთ, რომ `derive` სტრატეგია მოითხოვს, რომ ყველა ველი `Eq` იყოს, რაც ყოველთვის არ არის სასურველი.
///
/// ## როგორ შემიძლია განვახორციელო `Eq`?
///
/// თუ არ შეგიძლიათ გამოიყენოთ `derive` სტრატეგია, მიუთითეთ, რომ თქვენი ტიპი ახორციელებს `Eq`-ს, რომელსაც არ აქვს მეთოდები:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // ამ მეთოდს იყენებს მხოლოდ#[წარმოება] იმის დასადასტურებლად, რომ ტიპის ყველა კომპონენტი ახორციელებს#[წარმოებულს], ამჟამინდელი წარმოებული ინფრასტრუქტურა ნიშნავს ამ მტკიცების გაკეთებას trait- ზე მეთოდის გამოყენების გარეშე, თითქმის შეუძლებელია.
    //
    //
    // ეს არასოდეს უნდა განხორციელდეს ხელით.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq`-ის გავლენის წარმოქმნის მაკრო.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: ამ სტრუქტურას იყენებს მხოლოდ#[გამომდინარე]
// ამტკიცებენ, რომ ტიპის ყველა კომპონენტი ახორციელებს Eq.
//
// ეს სტრუქტურა არასოდეს უნდა გამოჩნდეს მომხმარებლის კოდში.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` არის ორი მნიშვნელობის შედარების შედეგი.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// შეკვეთა, სადაც შედარებული მნიშვნელობა სხვაზე ნაკლებია.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// შეკვეთა, სადაც შედარებული მნიშვნელობა უდრის სხვას.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// შეკვეთა, სადაც შედარებული მნიშვნელობა უფრო მეტია, ვიდრე სხვა.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// აბრუნებს `true`-ს, თუ შეკვეთა არის `Equal` ვარიანტი.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// აბრუნებს `true`-ს, თუ შეკვეთა არ არის `Equal` ვარიანტი.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// აბრუნებს `true`-ს, თუ შეკვეთა არის `Less` ვარიანტი.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// აბრუნებს `true`-ს, თუ შეკვეთა არის `Greater` ვარიანტი.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// აბრუნებს `true`-ს, თუ შეკვეთა არის `Less` ან `Equal` ვარიანტი.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// აბრუნებს `true`-ს, თუ შეკვეთა არის `Greater` ან `Equal` ვარიანტი.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// შეცვლის `Ordering`-ს.
    ///
    /// * `Less` ხდება `Greater`.
    /// * `Greater` ხდება `Less`.
    /// * `Equal` ხდება `Equal`.
    ///
    /// # Examples
    ///
    /// ძირითადი ქცევა:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// ეს მეთოდი შეიძლება გამოყენებულ იქნას შედარების შესაცვლელად:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // დაალაგეთ მასივი უდიდესიდან ყველაზე პატარა.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// ჯაჭვებს ორი შეკვეთა.
    ///
    /// აბრუნებს `self`-ს, როდესაც ის არ არის `Equal`.წინააღმდეგ შემთხვევაში აბრუნებს `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// ჯაჭვობს შეკვეთას მოცემული ფუნქციით.
    ///
    /// აბრუნებს `self`-ს, როდესაც ის არ არის `Equal`.
    /// წინააღმდეგ შემთხვევაში დარეკავს `f` და დაუბრუნებს შედეგს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// საპირისპირო შეკვეთის დამხმარე სტრუქტურა.
///
/// ეს სტრუქტურა არის დამხმარე, რომელიც უნდა იქნას გამოყენებული ისეთი ფუნქციებით, როგორიცაა [`Vec::sort_by_key`] და შეიძლება გამოყენებულ იქნას გასაღების ნაწილის შეცვლა.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait ტიპისთვის, რომელიც ქმნის [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// შეკვეთა არის ჯამური შეკვეთა, თუ იგი არის (ყველა `a`, `b` და `c`):
///
/// - საერთო და ასიმეტრიული: `a < b`, `a == b` ან `a > b`- დან ზუსტად ერთია სიმართლე;და
/// - გარდამავალი, `a < b` და `b < c` გულისხმობს `a < c`-ს.იგივე უნდა ეხებოდეს როგორც `==`, ასევე `>`.
///
/// ## Derivable
///
/// ეს trait შეიძლება გამოყენებულ იქნას `#[derive]`.
/// როდესაც სტრიქონებზე `გამომდინარეობს`, ის აწარმოებს [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) შეკვეთას სტრუქტურის წევრების ზემოდან ქვედა დეკლარაციის საფუძველზე.
///
/// Enum-ზე `derive`d, ვარიანტებს ალაგებენ მათი განმასხვავებელი ზემოდან ქვედადან.
///
/// ## ლექსიკოგრაფიული შედარება
///
/// ლექსიკოგრაფიული შედარება არის შემდეგი თვისებების მქონე ოპერაცია:
///  - ორი თანმიმდევრობა შედარებულია ელემენტებით.
///  - პირველი შეუსაბამო ელემენტი განსაზღვრავს რომელი თანმიმდევრობა არის ლექსიკოგრაფიულად ნაკლები ან მეტი ვიდრე სხვა.
///  - თუ ერთი თანმიმდევრობა მეორის პრეფიქსია, უფრო მოკლე მიმდევრობა ლექსიკოგრაფიულად ნაკლებია, ვიდრე სხვა.
///  - თუ ორ მიმდევრობას ექვივალენტური ელემენტები აქვს და ერთი და იგივე სიგრძისაა, მაშინ მიმდევრობები ლექსიკურად ტოლია.
///  - ცარიელი თანმიმდევრობა ლექსიკოგრაფიულად ნაკლებია ვიდრე არა ცარიელი თანმიმდევრობა.
///  - ორი ცარიელი თანმიმდევრობა ლექსიკოგრაფიულად ტოლია.
///
/// ## როგორ შემიძლია განვახორციელო `Ord`?
///
/// `Ord` მოითხოვს, რომ ტიპი ასევე იყოს [`PartialOrd`] და [`Eq`] (რაც მოითხოვს [`PartialEq`]).
///
/// მაშინ თქვენ უნდა განსაზღვროთ [`cmp`]-ის განხორციელება.შეიძლება თქვენთვის სასარგებლო იყოს [`cmp`]-ის გამოყენება თქვენი ტიპის ველებზე.
///
/// [`PartialEq`], [`PartialOrd`] და `Ord`*-ის დანერგვები* უნდა შეთანხმდნენ ერთმანეთთან.
/// ეს არის `a.cmp(b) == Ordering::Equal` თუ და მხოლოდ იმ შემთხვევაში, თუ `a == b` და `Some(a.cmp(b)) == a.partial_cmp(b)` ყველა `a` და `b`.
/// ადვილია შემთხვევით დაათანხმო მათ, რომ არ დაეთანხმონ traits- ის ზოგიერთი ნაწილის გამოყოფით და სხვების ხელით განხორციელებით.
///
/// აქ მოცემულია მაგალითი, სადაც გსურთ ხალხის დალაგება მხოლოდ სიმაღლის მიხედვით, `id` და `name`-ს გათვალისწინებით:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// ეს მეთოდი აბრუნებს [`Ordering`] `self`-სა და `other`-ს შორის.
    ///
    /// კონვენციის მიხედვით, `self.cmp(&other)` აბრუნებს დალაგებას, რომელიც შეესაბამება `self <operator> other` გამოხატვას, თუ სიმართლეა.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// ადარებს და აბრუნებს მაქსიმუმ ორ მნიშვნელობას.
    ///
    /// აბრუნებს მეორე არგუმენტს, თუ შედარების თანახმად, ისინი თანაბარია.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// ადარებს და აბრუნებს ორი მნიშვნელობის მინიმუმს.
    ///
    /// აბრუნებს პირველ არგუმენტს, თუ შედარების თანახმად, ისინი თანაბარია.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// შეზღუდეთ მნიშვნელობა გარკვეული ინტერვალით.
    ///
    /// აბრუნებს `max` თუ `self` მეტია `max` და `min` თუ `self` ნაკლებია `min`.
    /// წინააღმდეგ შემთხვევაში, ეს უბრუნებს `self`-ს.
    ///
    /// # Panics
    ///
    /// Panics თუ `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord`-ის გავლენის წარმოქმნის მაკრო.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait მნიშვნელობებისთვის, რომელთა შედარება შესაძლებელია დალაგების რიგისთვის.
///
/// შედარებამ უნდა დააკმაყოფილოს ყველა `a`, `b` და `c`:
///
/// - ასიმეტრია: თუ `a < b`, მაშინ `!(a > b)`, ისევე როგორც `a > b`, რომელიც გულისხმობს `!(a < b)`;და
/// - ტრანზიტულობა: `a < b` და `b < c` გულისხმობს `a < c`-ს.იგივე უნდა ეხებოდეს როგორც `==`, ასევე `>`.
///
/// გაითვალისწინეთ, რომ ეს მოთხოვნები ნიშნავს, რომ trait თავად უნდა განხორციელდეს სიმეტრიულად და ტრანზიტულად: თუ `T: PartialOrd<U>` და `U: PartialOrd<V>`, მაშინ `U: PartialOrd<T>` და `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// ეს trait შეიძლება გამოყენებულ იქნას `#[derive]`.როდესაც სტრიქონებზე `გამომდინარეობს`, ის აწარმოებს ლექსიკოგრაფიულ მწყობრს, რომელიც ეფუძნება სტრუქტურის წევრების ზემოდან ქვედა დეკლარაციის წესრიგს.
/// Enum-ზე `derive`d, ვარიანტებს ალაგებენ მათი განმასხვავებელი ზემოდან ქვედადან.
///
/// ## როგორ შემიძლია განვახორციელო `PartialOrd`?
///
/// `PartialOrd` საჭიროა მხოლოდ [`partial_cmp`] მეთოდის განხორციელება, დანარჩენებთან ერთად ნაგულისხმევი დანერგვებიდან.
///
/// ამასთან, შესაძლებელია დანარჩენების ცალკე განხორციელება იმ ტიპებისთვის, რომლებსაც არ აქვთ საერთო თანმიმდევრობა.
/// მაგალითად, მცურავი წერტილების ნომრებისთვის `NaN < 0 == false` და `NaN >= 0 == false` (შდრ.
/// IEEE 754-2008 სექცია 5.11).
///
/// `PartialOrd` თქვენი ტიპი უნდა იყოს [`PartialEq`].
///
/// [`PartialEq`], `PartialOrd` და [`Ord`]*-ის დანერგვები* უნდა შეთანხმდნენ ერთმანეთთან.
/// ადვილია შემთხვევით დაათანხმო მათ, რომ არ დაეთანხმონ traits- ის ზოგიერთი ნაწილის გამოყოფით და სხვების ხელით განხორციელებით.
///
/// თუ თქვენი ტიპია [`Ord`], შეგიძლიათ განახორციელოთ [`partial_cmp`] [`cmp`]-ის გამოყენებით:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// ასევე შეიძლება თქვენთვის სასარგებლო აღმოჩნდეს [`partial_cmp`]-ის გამოყენება თქვენი ტიპის ველებზე.
/// აქ მოცემულია `Person` ტიპების მაგალითი, რომლებსაც აქვთ მცურავი წერტილის `height` ველი, რომელიც ერთადერთი ველია, რომელიც გამოიყენება დასალაგებლად:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// ეს მეთოდი უბრუნებს შეკვეთას `self` და `other` მნიშვნელობებს შორის, თუ არსებობს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// როდესაც შედარება შეუძლებელია:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// ეს მეთოდი უფრო ნაკლებ ტესტებს (`self` და `other`-ზე) და იყენებს `<` ოპერატორი.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// ამ მეთოდის ტესტირება ნაკლებია ან ტოლი (`self` და `other`- სთვის) და გამოიყენება `<=` ოპერატორის მიერ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// ეს მეთოდი უფრო მეტია, ვიდრე (`self` და `other`) და გამოიყენება `>` ოპერატორის მიერ.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// ეს მეთოდი ტესტებს აღემატება ან ტოლია (`self` და `other`) და გამოიყენება `>=` ოპერატორის მიერ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd`-ის გავლენის წარმოქმნის მაკრო.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// ადარებს და აბრუნებს ორი მნიშვნელობის მინიმუმს.
///
/// აბრუნებს პირველ არგუმენტს, თუ შედარების თანახმად, ისინი თანაბარია.
///
/// შინაგანად იყენებს მეტსახელად [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// აბრუნებს ორი მნიშვნელობის მინიმუმს მითითებული შედარების ფუნქციის მიმართ.
///
/// აბრუნებს პირველ არგუმენტს, თუ შედარების თანახმად, ისინი თანაბარია.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// აბრუნებს ელემენტს, რომელიც იძლევა მინიმალურ მნიშვნელობას მითითებული ფუნქციიდან.
///
/// აბრუნებს პირველ არგუმენტს, თუ შედარების თანახმად, ისინი თანაბარია.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// ადარებს და აბრუნებს მაქსიმუმ ორ მნიშვნელობას.
///
/// აბრუნებს მეორე არგუმენტს, თუ შედარების თანახმად, ისინი თანაბარია.
///
/// შინაგანად იყენებს მეტსახელად [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// აბრუნებს ორი მნიშვნელობის მაქსიმუმს მითითებული შედარების ფუნქციის მიმართ.
///
/// აბრუნებს მეორე არგუმენტს, თუ შედარების თანახმად, ისინი თანაბარია.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// აბრუნებს ელემენტს, რომელიც აძლევს მაქსიმალურ მნიშვნელობას მითითებული ფუნქციიდან.
///
/// აბრუნებს მეორე არგუმენტს, თუ შედარების თანახმად, ისინი თანაბარია.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// PartialEq, Eq, PartialOrd და Ord-ის განხორციელება პრიმიტიული ტიპებისთვის
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // აქ შეკვეთა მნიშვნელოვანია უფრო ოპტიმალური აწყობის შესაქმნელად.
                    // დამატებითი ინფორმაციისთვის იხილეთ <https://github.com/rust-lang/rust/issues/63758>.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // I8-ზე ჩასმა და სხვაობის შეკვეთით დალაგება წარმოქმნის უფრო ოპტიმალურ შეკრებას.
            //
            // დამატებითი ინფორმაციისთვის იხილეთ <https://github.com/rust-lang/rust/issues/66780>.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // უსაფრთხოება: bool როგორც i8 აბრუნებს 0 ან 1, ასე რომ სხვაობა არ შეიძლება იყოს სხვა
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &მითითებები

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}