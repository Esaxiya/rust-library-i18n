//! შემდგენელი შინაგანი.
//!
//! შესაბამისი განმარტებები მოცემულია `compiler/rustc_codegen_llvm/src/intrinsic.rs`-ში.
//! შესაბამისი კონსტრუქციების განხორციელება არის `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # კონსტრენსი
//!
//! Note: შინაგანი შინაარსის სისწორესთან დაკავშირებული ნებისმიერი ცვლილება უნდა განვიხილოთ ენის ჯგუფთან.
//! ეს მოიცავს ცვლილებებს მდგრადობის სტაბილურობაში.
//!
//! იმისათვის, რომ კომპილირების დროს შინაგანი იყოს გამოსადეგი, საჭიროა კოპირება განხორციელდეს <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs>-დან `compiler/rustc_mir/src/interpret/intrinsics.rs`-ზე და `#[rustc_const_unstable(feature = "foo", issue = "01234")]` დაამატოთ შინაარსს.
//!
//!
//! თუ სავარაუდოდ უნდა იქნას გამოყენებული `const fn` ატრიბუტის მქონე შინაგანი თვისება, ასევე ატრიბუტი უნდა იყოს `rustc_const_stable`.
//! ასეთი ცვლილება არ უნდა განხორციელდეს T-lang კონსულტაციის გარეშე, რადგან ის აყალიბებს იმ მახასიათებელს ენაზე, რომლის გამრავლება შეუძლებელია მომხმარებლის კოდში შემდგენლის მხარდაჭერის გარეშე.
//!
//! # Volatiles
//!
//! არასტაბილური შინაგანი საშუალებები გთავაზობთ ოპერაციებს, რომლებიც მოქმედებს I/O მეხსიერებაზე, რომელთა გარანტირებული არ არის კომპილატორის ხელახლა დალაგება სხვა არასტაბილურ შინაარსში.იხილეთ LLVM დოკუმენტაცია [[volatile]]-ზე.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! ატომური შინაგანი მხარეები წარმოადგენენ საერთო ატომურ ოპერაციებს მანქანურ სიტყვებზე, მეხსიერების მრავალჯერადი შესაძლო დალაგებით.ისინი ემორჩილებიან იგივე სემანტიკას, როგორც C++ 11.იხილეთ LLVM დოკუმენტაცია [[atomics]]-ზე.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! სწრაფი განახლება მეხსიერების შეკვეთის შესახებ:
//!
//! * შეიძინეთ, ბარიერი საკეტის მოსაპოვებლად.შემდეგ კითხვა და წერა ხდება ბარიერის შემდეგ.
//! * გათავისუფლება, დაბრკოლება საკეტის გათავისუფლებისთვის.კითხვა და წერა წინ უსწრებს ბარიერს.
//! * თანმიმდევრულად თანმიმდევრული, თანმიმდევრული თანმიმდევრული ოპერაციები გარანტირებულია, რომ მოხდება წესრიგში.ეს არის სტანდარტული რეჟიმი ატომურ ტიპებთან მუშაობისთვის და ეკვივალენტურია Java's `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// ეს იმპორტი გამოიყენება შიდა Doc კავშირების გამარტივებისთვის
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // უსაფრთხოება: იხილეთ `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // გაითვალისწინეთ, ეს შინაგანი პირები იღებენ ნედლეულ მითითებას, რადგან ისინი ახდენს aliased მეხსიერების მუტაციას, რაც არ არის შესაფერისი არც `&` და არც `&mut`.
    //

    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange` მეთოდით [`Ordering::SeqCst`] გავლით, როგორც `success` და `failure` პარამეტრებით.
    ///
    /// Მაგალითად, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange` მეთოდით [`Ordering::Acquire`] გავლით, როგორც `success` და `failure` პარამეტრებით.
    ///
    /// Მაგალითად, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange` მეთოდით [`Ordering::Release`] როგორც `success` და [`Ordering::Relaxed`] როგორც `failure` პარამეტრების გავლით.
    /// Მაგალითად, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange` მეთოდით [`Ordering::AcqRel`] როგორც `success` და [`Ordering::Acquire`] როგორც `failure` პარამეტრების გავლით.
    /// Მაგალითად, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange` მეთოდით [`Ordering::Relaxed`] გავლით, როგორც `success` და `failure` პარამეტრებით.
    ///
    /// Მაგალითად, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange` მეთოდით [`Ordering::SeqCst`] როგორც `success` და [`Ordering::Relaxed`] როგორც `failure` პარამეტრების გავლით.
    /// Მაგალითად, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange` მეთოდით [`Ordering::SeqCst`] როგორც `success` და [`Ordering::Acquire`] როგორც `failure` პარამეტრების გავლით.
    /// Მაგალითად, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange` მეთოდით [`Ordering::Acquire`] როგორც `success` და [`Ordering::Relaxed`] როგორც `failure` პარამეტრების გავლით.
    /// Მაგალითად, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange` მეთოდით [`Ordering::AcqRel`] როგორც `success` და [`Ordering::Relaxed`] როგორც `failure` პარამეტრების გავლით.
    /// Მაგალითად, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange_weak` მეთოდით [`Ordering::SeqCst`] გავლით, როგორც `success` და `failure` პარამეტრებით.
    ///
    /// Მაგალითად, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange_weak` მეთოდით [`Ordering::Acquire`] გავლით, როგორც `success` და `failure` პარამეტრებით.
    ///
    /// Მაგალითად, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange_weak` მეთოდით [`Ordering::Release`] როგორც `success` და [`Ordering::Relaxed`] როგორც `failure` პარამეტრების გავლით.
    /// Მაგალითად, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange_weak` მეთოდით [`Ordering::AcqRel`] როგორც `success` და [`Ordering::Acquire`] როგორც `failure` პარამეტრების გავლით.
    /// Მაგალითად, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange_weak` მეთოდით [`Ordering::Relaxed`] გავლით, როგორც `success` და `failure` პარამეტრებით.
    ///
    /// Მაგალითად, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange_weak` მეთოდით [`Ordering::SeqCst`] როგორც `success` და [`Ordering::Relaxed`] როგორც `failure` პარამეტრების გავლით.
    /// Მაგალითად, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange_weak` მეთოდით [`Ordering::SeqCst`] როგორც `success` და [`Ordering::Acquire`] როგორც `failure` პარამეტრების გავლით.
    /// Მაგალითად, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange_weak` მეთოდით [`Ordering::Acquire`] როგორც `success` და [`Ordering::Relaxed`] როგორც `failure` პარამეტრების გავლით.
    /// Მაგალითად, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ინახავს მნიშვნელობას, თუ ამჟამინდელი მნიშვნელობა იგივეა, რაც `old` მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `compare_exchange_weak` მეთოდით [`Ordering::AcqRel`] როგორც `success` და [`Ordering::Relaxed`] როგორც `failure` პარამეტრების გავლით.
    /// Მაგალითად, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// იტვირთება მაჩვენებლის მიმდინარე მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `load` მეთოდით [`Ordering::SeqCst`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// იტვირთება მაჩვენებლის მიმდინარე მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `load` მეთოდით [`Ordering::Acquire`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// იტვირთება მაჩვენებლის მიმდინარე მნიშვნელობა.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `load` მეთოდით [`Ordering::Relaxed`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// ინახავს მნიშვნელობას მითითებულ მეხსიერების ადგილას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `store` მეთოდით [`Ordering::SeqCst`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// ინახავს მნიშვნელობას მითითებულ მეხსიერების ადგილას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `store` მეთოდით [`Ordering::Release`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// ინახავს მნიშვნელობას მითითებულ მეხსიერების ადგილას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `store` მეთოდით [`Ordering::Relaxed`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// ინახავს მნიშვნელობას მითითებულ მეხსიერების ადგილას, უბრუნებს ძველ მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `swap` მეთოდით [`Ordering::SeqCst`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// ინახავს მნიშვნელობას მითითებულ მეხსიერების ადგილას, უბრუნებს ძველ მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `swap` მეთოდით [`Ordering::Acquire`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ინახავს მნიშვნელობას მითითებულ მეხსიერების ადგილას, უბრუნებს ძველ მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `swap` მეთოდით [`Ordering::Release`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ინახავს მნიშვნელობას მითითებულ მეხსიერების ადგილას, უბრუნებს ძველ მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `swap` მეთოდით [`Ordering::AcqRel`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ინახავს მნიშვნელობას მითითებულ მეხსიერების ადგილას, უბრუნებს ძველ მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `swap` მეთოდით [`Ordering::Relaxed`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// მიმდინარე მნიშვნელობას ემატება და აბრუნებს წინა მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_add` მეთოდით [`Ordering::SeqCst`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// მიმდინარე მნიშვნელობას ემატება და აბრუნებს წინა მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_add` მეთოდით [`Ordering::Acquire`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// მიმდინარე მნიშვნელობას ემატება და აბრუნებს წინა მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_add` მეთოდით [`Ordering::Release`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// მიმდინარე მნიშვნელობას ემატება და აბრუნებს წინა მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_add` მეთოდით [`Ordering::AcqRel`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// მიმდინარე მნიშვნელობას ემატება და აბრუნებს წინა მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_add` მეთოდით [`Ordering::Relaxed`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// გამოკლება მიმდინარე მნიშვნელობიდან, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_sub` მეთოდით [`Ordering::SeqCst`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// გამოკლება მიმდინარე მნიშვნელობიდან, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_sub` მეთოდით [`Ordering::Acquire`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// გამოკლება მიმდინარე მნიშვნელობიდან, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_sub` მეთოდით [`Ordering::Release`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// გამოკლება მიმდინარე მნიშვნელობიდან, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_sub` მეთოდით [`Ordering::AcqRel`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// გამოკლება მიმდინარე მნიშვნელობიდან, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_sub` მეთოდით [`Ordering::Relaxed`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise და მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_and` მეთოდით [`Ordering::SeqCst`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise და მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_and` მეთოდით [`Ordering::Acquire`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise და მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_and` მეთოდით [`Ordering::Release`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise და მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_and` მეთოდით [`Ordering::AcqRel`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise და მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_and` მეთოდით [`Ordering::Relaxed`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise და მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`AtomicBool`] ტიპის `fetch_nand` მეთოდით [`Ordering::SeqCst`] `order`- ის გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise და მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`AtomicBool`] ტიპის `fetch_nand` მეთოდით [`Ordering::Acquire`] `order`- ის გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise და მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`AtomicBool`] ტიპის `fetch_nand` მეთოდით [`Ordering::Release`] `order`- ის გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise და მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`AtomicBool`] ტიპის `fetch_nand` მეთოდით [`Ordering::AcqRel`] `order`- ის გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise და მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`AtomicBool`] ტიპის `fetch_nand` მეთოდით [`Ordering::Relaxed`] `order`- ის გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise ან მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_or` მეთოდით [`Ordering::SeqCst`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ან მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_or` მეთოდით [`Ordering::Acquire`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ან მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_or` მეთოდით [`Ordering::Release`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ან მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_or` მეთოდით [`Ordering::AcqRel`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ან მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_or` მეთოდით [`Ordering::Relaxed`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_xor` მეთოდით [`Ordering::SeqCst`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_xor` მეთოდით [`Ordering::Acquire`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_xor` მეთოდით [`Ordering::Release`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_xor` მეთოდით [`Ordering::AcqRel`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor მიმდინარე მნიშვნელობით, წინა მნიშვნელობის დაბრუნებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ტიპებზე `fetch_xor` მეთოდით [`Ordering::Relaxed`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// მაქსიმალური მიმდინარე მნიშვნელობით, ხელმოწერილი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოწერილ მთელ ტიპებზე `fetch_max` მეთოდით [`Ordering::SeqCst`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// მაქსიმალური მიმდინარე მნიშვნელობით, ხელმოწერილი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოწერილ მთელ ტიპებზე `fetch_max` მეთოდით [`Ordering::Acquire`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// მაქსიმალური მიმდინარე მნიშვნელობით, ხელმოწერილი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოწერილ მთელ ტიპებზე `fetch_max` მეთოდით [`Ordering::Release`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// მაქსიმალური მიმდინარე მნიშვნელობით, ხელმოწერილი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოწერილ მთელ ტიპებზე `fetch_max` მეთოდით [`Ordering::AcqRel`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// მაქსიმალური მიმდინარე მნიშვნელობით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოწერილ მთელ ტიპებზე `fetch_max` მეთოდით [`Ordering::Relaxed`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// მინიმალური მიმდინარე მნიშვნელობით, ხელმოწერილი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოწერილ მთელ ტიპებზე `fetch_min` მეთოდით [`Ordering::SeqCst`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// მინიმალური მიმდინარე მნიშვნელობით, ხელმოწერილი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოწერილ მთელ ტიპებზე `fetch_min` მეთოდით [`Ordering::Acquire`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// მინიმალური მიმდინარე მნიშვნელობით, ხელმოწერილი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოწერილ მთელ ტიპებზე `fetch_min` მეთოდით [`Ordering::Release`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// მინიმალური მიმდინარე მნიშვნელობით, ხელმოწერილი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოწერილ მთელ ტიპებზე `fetch_min` მეთოდით [`Ordering::AcqRel`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// მინიმალური მიმდინარე მნიშვნელობით, ხელმოწერილი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოწერილ მთელ ტიპებზე `fetch_min` მეთოდით [`Ordering::Relaxed`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// მინიმალური მიმდინარე მნიშვნელობით ხელმოუწერელი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოუწერელი მთელი ტიპის ტიპებისთვის `fetch_min` მეთოდით [`Ordering::SeqCst`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// მინიმალური მიმდინარე მნიშვნელობით ხელმოუწერელი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოუწერელი მთელი ტიპის ტიპებისთვის `fetch_min` მეთოდით [`Ordering::Acquire`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// მინიმალური მიმდინარე მნიშვნელობით ხელმოუწერელი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოუწერელი მთელი ტიპის ტიპებისთვის `fetch_min` მეთოდით [`Ordering::Release`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// მინიმალური მიმდინარე მნიშვნელობით ხელმოუწერელი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოუწერელი მთელი ტიპის ტიპებისთვის `fetch_min` მეთოდით [`Ordering::AcqRel`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// მინიმალური მიმდინარე მნიშვნელობით ხელმოუწერელი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოუწერელი მთელი ტიპის ტიპებისთვის `fetch_min` მეთოდით [`Ordering::Relaxed`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// მაქსიმალური მიმდინარე მნიშვნელობით ხელმოუწერელი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოუწერელი მთელი ტიპის ტიპებისთვის `fetch_max` მეთოდით [`Ordering::SeqCst`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// მაქსიმალური მიმდინარე მნიშვნელობით ხელმოუწერელი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოუწერელი მთელი ტიპის ტიპებისთვის `fetch_max` მეთოდით [`Ordering::Acquire`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// მაქსიმალური მიმდინარე მნიშვნელობით ხელმოუწერელი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოუწერელი მთელი ტიპის ტიპებისთვის `fetch_max` მეთოდით [`Ordering::Release`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// მაქსიმალური მიმდინარე მნიშვნელობით ხელმოუწერელი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოუწერელი მთელი ტიპის ტიპებისთვის `fetch_max` მეთოდით [`Ordering::AcqRel`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// მაქსიმალური მიმდინარე მნიშვნელობით ხელმოუწერელი შედარების გამოყენებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic`] ხელმოუწერელი მთელი ტიპის ტიპებისთვის `fetch_max` მეთოდით [`Ordering::Relaxed`] `order`- ით გავლით.
    /// Მაგალითად, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` შინაარსი კოდის გენერატორის მითითებაა, თუ მხარს უჭერს წინასწარ მითითების ინსტრუქციას;წინააღმდეგ შემთხვევაში, ეს არის no-op.
    /// Prefetches გავლენას არ ახდენს პროგრამის ქცევაზე, მაგრამ შეუძლია შეცვალოს მისი შესრულების მახასიათებლები.
    ///
    /// `locality` არგუმენტი უნდა იყოს მუდმივი მთელი რიცხვი და არის დროებითი ლოკალიზაციის სპეციფიკატორი, დაწყებული (0), არ არის ლოკალიზაცია, (3)- მდე, უკიდურესად ადგილობრივი ინახავს ქეშში.
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` შინაარსი კოდის გენერატორის მითითებაა, თუ მხარს უჭერს წინასწარ მითითების ინსტრუქციას;წინააღმდეგ შემთხვევაში, ეს არის no-op.
    /// Prefetches გავლენას არ ახდენს პროგრამის ქცევაზე, მაგრამ შეუძლია შეცვალოს მისი შესრულების მახასიათებლები.
    ///
    /// `locality` არგუმენტი უნდა იყოს მუდმივი მთელი რიცხვი და არის დროებითი ლოკალიზაციის სპეციფიკატორი, დაწყებული (0), არ არის ლოკალიზაცია, (3)- მდე, უკიდურესად ადგილობრივი ინახავს ქეშში.
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` შინაარსი კოდის გენერატორის მითითებაა, თუ მხარს უჭერს წინასწარ მითითების ინსტრუქციას;წინააღმდეგ შემთხვევაში, ეს არის no-op.
    /// Prefetches გავლენას არ ახდენს პროგრამის ქცევაზე, მაგრამ შეუძლია შეცვალოს მისი შესრულების მახასიათებლები.
    ///
    /// `locality` არგუმენტი უნდა იყოს მუდმივი მთელი რიცხვი და არის დროებითი ლოკალიზაციის სპეციფიკატორი, დაწყებული (0), არ არის ლოკალიზაცია, (3)- მდე, უკიდურესად ადგილობრივი ინახავს ქეშში.
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` შინაარსი კოდის გენერატორის მითითებაა, თუ მხარს უჭერს წინასწარ მითითების ინსტრუქციას;წინააღმდეგ შემთხვევაში, ეს არის no-op.
    /// Prefetches გავლენას არ ახდენს პროგრამის ქცევაზე, მაგრამ შეუძლია შეცვალოს მისი შესრულების მახასიათებლები.
    ///
    /// `locality` არგუმენტი უნდა იყოს მუდმივი მთელი რიცხვი და არის დროებითი ლოკალიზაციის სპეციფიკატორი, დაწყებული (0), არ არის ლოკალიზაცია, (3)- მდე, უკიდურესად ადგილობრივი ინახავს ქეშში.
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// ატომური ღობე.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic::fence`]- ში [`Ordering::SeqCst`]- ის `order`- ით გავლით.
    ///
    ///
    pub fn atomic_fence();
    /// ატომური ღობე.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic::fence`]- ში [`Ordering::Acquire`]- ის `order`- ით გავლით.
    ///
    ///
    pub fn atomic_fence_acq();
    /// ატომური ღობე.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic::fence`]- ში [`Ordering::Release`]- ის `order`- ით გავლით.
    ///
    ///
    pub fn atomic_fence_rel();
    /// ატომური ღობე.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic::fence`]- ში [`Ordering::AcqRel`]- ის `order`- ით გავლით.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// შემდგენელთა მხოლოდ მეხსიერების ბარიერი.
    ///
    /// შემდგენელმა ამ ბარიერის გასწვრივ აღარ შეცვალა მეხსიერების წვდომა, მაგრამ მისთვის არანაირი ინსტრუქცია არ გამოიცემა.
    /// ეს შეესაბამება იმავე ძაფის ოპერაციებს, რომელთა წინასწარ გამოყენებაც შეიძლება, მაგალითად, სიგნალის დამმუშავებლებთან ურთიერთობისას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic::compiler_fence`]- ში [`Ordering::SeqCst`]- ის `order`- ით გავლით.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// შემდგენელთა მხოლოდ მეხსიერების ბარიერი.
    ///
    /// შემდგენელმა ამ ბარიერის გასწვრივ აღარ შეცვალა მეხსიერების წვდომა, მაგრამ მისთვის არანაირი ინსტრუქცია არ გამოიცემა.
    /// ეს შეესაბამება იმავე ძაფის ოპერაციებს, რომელთა წინასწარ გამოყენებაც შეიძლება, მაგალითად, სიგნალის დამმუშავებლებთან ურთიერთობისას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic::compiler_fence`]- ში [`Ordering::Acquire`]- ის `order`- ით გავლით.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// შემდგენელთა მხოლოდ მეხსიერების ბარიერი.
    ///
    /// შემდგენელმა ამ ბარიერის გასწვრივ აღარ შეცვალა მეხსიერების წვდომა, მაგრამ მისთვის არანაირი ინსტრუქცია არ გამოიცემა.
    /// ეს შეესაბამება იმავე ძაფის ოპერაციებს, რომელთა წინასწარ გამოყენებაც შეიძლება, მაგალითად, სიგნალის დამმუშავებლებთან ურთიერთობისას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic::compiler_fence`]- ში [`Ordering::Release`]- ის `order`- ით გავლით.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// შემდგენელთა მხოლოდ მეხსიერების ბარიერი.
    ///
    /// შემდგენელმა ამ ბარიერის გასწვრივ აღარ შეცვალა მეხსიერების წვდომა, მაგრამ მისთვის არანაირი ინსტრუქცია არ გამოიცემა.
    /// ეს შეესაბამება იმავე ძაფის ოპერაციებს, რომელთა წინასწარ გამოყენებაც შეიძლება, მაგალითად, სიგნალის დამმუშავებლებთან ურთიერთობისას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსია ხელმისაწვდომია [`atomic::compiler_fence`]- ში [`Ordering::AcqRel`]- ის `order`- ით გავლით.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// ჯადოსნური შინაგანი, რომელიც თავის მნიშვნელობას იღებს ფუნქციასთან დაკავშირებული ატრიბუტებისგან.
    ///
    /// მაგალითად, მონაცემთა ნაკადი იყენებს ამას სტატიკური მტკიცებების ინექციისთვის ისე, რომ `rustc_peek(potentially_uninitialized)` სინამდვილეში ორმაგად გადაამოწმოს, რომ მონაცემთა ნაკადმა ნამდვილად გამოთვალა, რომ იგი არაინციალიზებულია კონტროლის ნაკადის იმ ეტაპზე.
    ///
    ///
    /// ეს შინაგანი არ უნდა იყოს გამოყენებული შემდგენლის გარეთ.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// წყვეტს პროცესის შესრულებას.
    ///
    /// ამ ოპერაციის უფრო მოსახერხებელი და სტაბილური ვერსიაა [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// აცნობებს ოპტიმიზატორს, რომ კოდის ეს პუნქტი მიუწვდომელია, რაც შემდგომ ოპტიმიზაციას იძლევა.
    ///
    /// NB, ეს ძალიან განსხვავდება `unreachable!()` მაკროსაგან: მაკროსაგან განსხვავებით, რომელიც panics შესრულდება, ეს არის *განუსაზღვრელი ქცევა* ამ ფუნქციით მონიშნულ კოდთან მისვლა.
    ///
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// აცნობებს ოპტიმიზატორს, რომ მდგომარეობა ყოველთვის მართალია.
    /// თუ მდგომარეობა მცდარია, ქცევა განუსაზღვრელია.
    ///
    /// ამ შინაარსისთვის კოდი არ წარმოიქმნება, მაგრამ ოპტიმიზატორი შეეცდება შეინარჩუნოს იგი (და მისი მდგომარეობა) პასებს შორის, რამაც შეიძლება ხელი შეუშალოს მიმდებარე კოდის ოპტიმიზაციას და შეამციროს შესრულება.
    /// ის არ უნდა იქნას გამოყენებული, თუ ინვარიანტი ოპტიმიზატორის მიერ შეიძლება აღმოჩნდეს დამოუკიდებლად, ან თუ ის არ იძლევა რაიმე მნიშვნელოვან ოპტიმიზაციას.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// მიანიშნებს შემდგენელზე, რომ branch მდგომარეობა სავარაუდოდ სიმართლეა.
    /// აბრუნებს მასზე გადაცემულ მნიშვნელობას.
    ///
    /// `if` დებულებების გარდა სხვა გამოყენებას, ალბათ, არ ექნება ეფექტი.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// მიანიშნებს შემდგენელზე, რომ branch მდგომარეობა, სავარაუდოდ, მცდარია.
    /// აბრუნებს მასზე გადაცემულ მნიშვნელობას.
    ///
    /// `if` დებულებების გარდა სხვა გამოყენებას, ალბათ, არ ექნება ეფექტი.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// ახდენს გამშვები პუნქტის ხაფანგს, შემოწმების მიზნით გამართვის სისტემის მიერ.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn breakpoint();

    /// ტიპის ზომა ბაიტებში.
    ///
    /// უფრო კონკრეტულად, ეს არის ბაიტების გადაფარვა იმავე ტიპის თანმიმდევრულ ნივთებს შორის, გასწორების შევსების ჩათვლით.
    ///
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// ტიპის მინიმალური გასწორება.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// ტიპის სასურველი გასწორება.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// მითითებული მნიშვნელობის ზომა ბაიტებში.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// მითითებული მნიშვნელობის საჭირო გასწორება.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// იღებს სტატიკური სიმების ნაჭერს, რომელიც შეიცავს ტიპის სახელს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// იღებს იდენტიფიკატორს, რომელიც გლობალურად უნიკალურია მითითებული ტიპისთვის.
    /// ეს ფუნქცია დაუბრუნებს იმავე მნიშვნელობას ტიპისთვის, განურჩევლად იმისა, თუ რომელ crate- შია იგი გამოყენებული.
    ///
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// სახიფათო ფუნქციების დაცვა, რომელიც ვერასოდეს შესრულდება, თუ `T` არ არის დასახლებული:
    /// ეს სტატიკურად ან panic- ს გახდის, ან არაფერს გააკეთებს.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// საშიში ფუნქციების დაცვა, რომლის შესრულება შეუძლებელია, თუ `T` არ იძლევა ნულოვანი ინიციალიზაციას: ეს სტატიკურად ან panic გახდება, ან არაფერს მოიმოქმედებს.
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn assert_zero_valid<T>();

    /// საშიში ფუნქციების დაცვა, რომლის შესრულება შეუძლებელია, თუ `T`- ს აქვს ბიტის არასწორი შაბლონები: ეს სტატიკურად ან panic- ს გახდის, ან არაფერს მოიმოქმედებს.
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn assert_uninit_valid<T>();

    /// მიიღებს მითითებას სტატიკურ `Location`-ზე, სადაც მითითებულია, თუ სად იწოდებოდა იგი.
    ///
    /// სანაცვლოდ, გამოიყენეთ [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// გადააქვს მნიშვნელობა ფარგლებს გარეთ წვეთოვანი წებოს გაშვების გარეშე.
    ///
    /// ეს მხოლოდ [`mem::forget_unsized`]- სთვის არსებობს;მის ნაცვლად ნორმალური `forget` იყენებს `ManuallyDrop`-ს.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// ახდენს ინტერპრეტაციას ერთი ტიპის მნიშვნელობის ბიტებზე, როგორც სხვა ტიპის.
    ///
    /// ორივე ტიპს უნდა ჰქონდეს იგივე ზომა.
    /// არც ორიგინალი და არც შედეგი არ შეიძლება იყოს [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` სემანტიკურად უდრის ერთი ტიპის ბიტიურად გადაადგილებას სხვაში.იგი კოპირებს ბიტებს საწყისი მნიშვნელობიდან დანიშნულების მნიშვნელობად, შემდეგ ავიწყდება ორიგინალი.
    /// ეს ექვივალენტურია C's `memcpy`-ის კაპოტის ქვეშ, ისევე როგორც `transmute_copy`.
    ///
    /// იმის გამო, რომ `transmute` არის ქვე-მნიშვნელობის ოპერაცია, თავად * გადაკეთებული მნიშვნელობების გასწორება არ აღელვებს.
    /// როგორც ნებისმიერი სხვა ფუნქციისთვის, შემდგენელი უკვე უზრუნველყოფს `T` და `U` სწორად გასწორებას.
    /// ამასთან, მნიშვნელობების ტრანსსუტირებისას, რომელიც *სხვაგან არის მითითებული*(მაგალითად, მითითებები, მითითებები, ველები), გამრეკელმა უნდა უზრუნველყოს მითითებული მნიშვნელობების სწორად გასწორება.
    ///
    /// `transmute` არის **წარმოუდგენლად** უსაფრთხო.ამ ფუნქციით [undefined behavior][ub]-ის გამოწვევის უამრავი მეთოდი არსებობს.`transmute` უნდა იყოს აბსოლუტური უკანასკნელი საშუალება.
    ///
    /// [nomicon](../../nomicon/transmutes.html)- ს აქვს დამატებითი დოკუმენტაცია.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// არსებობს რამდენიმე რამ, რისთვისაც `transmute` ნამდვილად სასარგებლოა.
    ///
    /// მაჩვენებლის ფუნქციურ მაჩვენებლად გადაქცევა.ეს *არ არის* პორტატული მანქანებისთვის, სადაც ფუნქციის მითითებებსა და მონაცემთა მაჩვენებლებს აქვთ სხვადასხვა ზომა.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// სიცოცხლის გახანგრძლივება, ან უცვლელი სიცოცხლის შემცირება.ეს არის მოწინავე, ძალიან სახიფათო Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// არ დაიდარდოთ: `transmute`- ის მრავალი გამოყენების მიღწევა შესაძლებელია სხვა საშუალებებით.
    /// ქვემოთ მოცემულია `transmute`- ის გავრცელებული პროგრამები, რომელთა ჩანაცვლება შეიძლება უფრო უსაფრთხო კონსტრუქციებით.
    ///
    /// ნედლეულის bytes(`&[u8]`) გადაქცევა `u32`, `f64` და ა.შ.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // გამოიყენეთ `u32::from_ne_bytes` მის ნაცვლად
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ან გამოიყენეთ `u32::from_le_bytes` ან `u32::from_be_bytes` დაბოლოების დასაზუსტებლად
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// მაჩვენებლის `usize` გადაქცევა:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // გამოიყენეთ `as` მსახიობი
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T`- ის `&mut T`- ად გადაქცევა:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // გამოიყენეთ reborrow ნაცვლად
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T`- ის `&mut U`- ად გადაქცევა:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // ახლა, შეაერთეთ `as` და ხელახალი შეცვლა, გაითვალისწინეთ, რომ `as` `as`-ის ჯაჭვი არ არის გარდამავალი
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str`- ის `&[u8]`- ად გადაქცევა:
    ///
    /// ```
    /// // ეს არ არის ამის კარგი გზა.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // შეგიძლიათ გამოიყენოთ `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // ან უბრალოდ გამოიყენეთ ბაიტის სტრიქონი, თუ სტრიქონზე კონტროლი გაქვთ
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>`- ის `Vec<Option<&T>>`- ად გადაქცევა.
    ///
    /// კონტეინერის შინაგანი ტიპის შინაგანი სახელის გადასაყვანად, დარწმუნდით, რომ არ დაარღვიოთ კონტეინერის არცერთი ინვარიანტი.
    /// `Vec`- ისთვის ეს ნიშნავს, რომ შიდა ტიპების ზომაც *და გასწორება* უნდა ემთხვეოდეს.
    /// სხვა კონტეინერები შეიძლება დაეყრდნონ ტიპის ზომას, მისწორებას ან თუნდაც `TypeId`- ს, ამ შემთხვევაში ტრანსმუტაცია საერთოდ შეუძლებელი იქნებოდა კონტეინერების ინვარიანტების დარღვევის გარეშე.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // კლონირება მოახდინეთ vector-ზე, რადგან შემდეგში გამოვიყენებთ მათ
    /// let v_clone = v_orig.clone();
    ///
    /// // ტრანსმუტის გამოყენება: ეს ეყრდნობა მონაცემების დაუზუსტებელ განლაგებას `Vec`, რაც ცუდი იდეაა და შეიძლება გამოიწვიოს განუსაზღვრელი ქცევა.
    /////
    /// // ამასთან, ეს არ არის კოპირება.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // ეს არის შემოთავაზებული, უსაფრთხო გზა.
    /// // იგი მართლაც ასლის მთელ vector-ს, ახალ მასივში.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // ეს არის "transmuting" a `Vec`-ის არაკოპირებული, სახიფათო გზა, მონაცემთა განლაგების იმედის გარეშე.
    /// // იმის მაგივრად, რომ სიტყვასიტყვით მოვუწოდოთ `transmute`, ჩვენ ვასრულებთ მაჩვენებლის გადაცემას, მაგრამ ორიგინალი შიდა ტიპის (`&i32`) ახლის (`Option<&i32>`)-ზე გადაკეთების თვალსაზრისით, ამას აქვს იგივე სიგნალები.
    /////
    /// // ზემოთ მოყვანილი ინფორმაციის გარდა, აგრეთვე გაეცანით [`from_raw_parts`] დოკუმენტაციას.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME განაახლეთ ეს, როდესაც vec_into_raw_parts სტაბილიზირდება.
    ///     // დარწმუნდით, რომ ორიგინალი vector არ დაეცა.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// განმახორციელებელი `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // ამის გაკეთების მრავალი გზა არსებობს და მრავალი პრობლემა არსებობს შემდეგ (transmute) გზასთან.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // პირველი: ტრანსმუტი არ არის უსაფრთხო ტიპის;ყველა ის ამოწმებს, რომ T და
    ///         // U იგივე ზომისაა.
    ///         // მეორე, სწორედ აქ, თქვენ გაქვთ ორი ცვალებადი მითითება, რომლებიც ერთ მეხსიერებაზე მიუთითებს.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // ეს ათავისუფლებს უსაფრთხოების ტიპის პრობლემებს;`&mut *`* მხოლოდ *მოგცემთ `&mut T` `&mut T` ან `* mut T`- დან.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // ამასთან, თქვენ ჯერ კიდევ გაქვთ ორი ცვალებადი მითითება, რომლებიც ერთ მეხსიერებაზე მიუთითებს.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // სტანდარტული ბიბლიოთეკა ასე ახდენს ამას.
    /// // ეს საუკეთესო მეთოდია, თუ მსგავსი რამის გაკეთება დაგჭირდებათ
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // ახლა მას აქვს სამი ცვალებადი მითითება, რომლებიც ერთ მეხსიერებაზე მიუთითებს.`slice`, rvalue ret.0 და rvalue ret.1.
    ///         // `slice` `let ptr = ...`- ის შემდეგ არასდროს გამოიყენება და, შესაბამისად, მას შეუძლია "dead"- ით მკურნალობა და, შესაბამისად, თქვენ გაქვთ მხოლოდ ორი რეალური მუტაბელური ნაჭერი.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: მიუხედავად იმისა, რომ ეს ქმნის შიდა სტრუქტურას სტაბილურს, ჩვენ გვაქვს გარკვეული მორგებული კოდი const fn-ში
    // ამოწმებს, რომლებიც ხელს უშლის მის გამოყენებას `const fn` ფარგლებში.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// აბრუნებს `true`-ს, თუ `T` სახით მოცემული ტიპი მოითხოვს წვეთოვანი წებოს;აბრუნებს `false`-ს, თუ `T`-ისთვის გათვალისწინებული რეალური ტიპი ახორციელებს `Copy`-ს.
    ///
    ///
    /// თუ რეალურ ტიპს არც წვეთოვანი წებო ჭირდება და არც `Copy` ახორციელებს, ამ ფუნქციის დაბრუნების მნიშვნელობა არ არის მითითებული.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// ითვლის ოფსეტს მაჩვენებლისგან.
    ///
    /// ეს ხორციელდება როგორც შინაგანი, რომ თავიდან იქნას აცილებული მთელი რიცხვიდან და მისგან გარდაქმნა, რადგან გარდაქმნის შედეგად გადაყრილი იქნება aliasing ინფორმაცია.
    ///
    /// # Safety
    ///
    /// როგორც საწყისი, ასევე მიღებული მაჩვენებელი უნდა იყოს საზღვრებში ან ერთი ბაიტი გამოყოფილი ობიექტის ბოლოს.
    /// თუ რომელიმე მაჩვენებელი არ არის საზღვრები ან არითმეტიკული გადახურვა მოხდება, დაბრუნებული მნიშვნელობის ნებისმიერი შემდგომი გამოყენება გამოიწვევს განუსაზღვრელ ქცევას.
    ///
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// ითვლის ოფსეტს კურსორიდან, პოტენციურად შეფუთვით.
    ///
    /// ეს ხორციელდება როგორც შინაგანი, რათა თავიდან იქნას აცილებული მთელი რიცხვიდან და მისგან, რადგან გარდაქმნა აფერხებს გარკვეულ ოპტიმიზაციებს.
    ///
    /// # Safety
    ///
    /// `offset` შინაგანისგან განსხვავებით, ეს შინაარსი არ ზღუდავს შედეგად მანიშნებლის მითითებას გამოყოფილი ობიექტის ბოლოსკენ ან ერთი ბაიტის გასწვრივ და იგი იხვევს ორი კომპლემენტის არითმეტიკით.
    /// მიღებული მნიშვნელობა სულაც არ არის მართებული, რომ გამოყენებული იქნას მეხსიერებაზე რეალურად წვდომისთვის.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// ექვივალენტურია შესაბამისი `llvm.memcpy.p0i8.0i8.*` შინაგანი, `count`*`size_of::<T>()` ზომის და გასწორება
    ///
    /// `min_align_of::<T>()`
    ///
    /// არასტაბილური პარამეტრი დაყენებულია `true`, ამიტომ ის არ იქნება ოპტიმიზირებული, თუ ზომა არ არის ნულის ტოლი.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// ექვივალენტურია შესაბამისი `llvm.memmove.p0i8.0i8.*` შინაგანი, `count* size_of::<T>()` ზომით და გასწორებით
    ///
    /// `min_align_of::<T>()`
    ///
    /// არასტაბილური პარამეტრი დაყენებულია `true`, ამიტომ ის არ იქნება ოპტიმიზირებული, თუ ზომა არ არის ნულის ტოლი.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// ექვივალენტურია შესაბამისი `llvm.memset.p0i8.*` შინაგანი, `count* size_of::<T>()` ზომის და `min_align_of::<T>()` გასწორება.
    ///
    ///
    /// არასტაბილური პარამეტრი დაყენებულია `true`, ამიტომ ის არ იქნება ოპტიმიზირებული, თუ ზომა არ არის ნულის ტოლი.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// ასრულებს არასტაბილურ დატვირთვას `src` მაჩვენებელიდან.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// ასრულებს არასტაბილურ მაღაზიას `dst` მაჩვენებლისთვის.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// ასრულებს არასტაბილურ დატვირთვას `src` მაჩვენებელიდან არ არის საჭირო მაჩვენებლის გასწორება.
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// ასრულებს არასტაბილურ მაღაზიას `dst` მაჩვენებლისთვის.
    /// მაჩვენებლის გასწორება არ არის საჭირო.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// აბრუნებს `f32` კვადრატულ ფესვს
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// აბრუნებს `f64` კვადრატულ ფესვს
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// ამაღლებს `f32` რიცხვს მთლიან რიცხვში.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// ამაღლებს `f64` რიცხვს მთლიან რიცხვში.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// აბრუნებს `f32`-ის სინუსს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// აბრუნებს `f64`- ის სინუსს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// აბრუნებს `f32`- ის კოსინუსს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// აბრუნებს `f64`- ის კოსინუსს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// ამაღლებს `f32` `f32` ენერგიას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// ამაღლებს `f64` `f64` ენერგიას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// აბრუნებს `f32`- ის ექსპონენციალს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// აბრუნებს `f64`- ის ექსპონენციალს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// აბრუნებს 2-ს `f32`-ის ძალაზე გაზრდილზე.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// აბრუნებს 2-ს `f64`-ის ძალაზე გაზრდილზე.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// აბრუნებს `f32`- ის ბუნებრივ ლოგარითმს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// აბრუნებს `f64`- ის ბუნებრივ ლოგარითმს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// აბრუნებს `f32` ფუძის 10 ლოგარითმს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// აბრუნებს `f64` ფუძის 10 ლოგარითმს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// აბრუნებს `f32` ფუძის 2 ლოგარითმს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// აბრუნებს `f64` ფუძის 2 ლოგარითმს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// აბრუნებს `a * b + c` `f32` მნიშვნელობებს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// აბრუნებს `a * b + c` `f64` მნიშვნელობებს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// აბრუნებს `f32`-ის აბსოლუტურ მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// აბრუნებს `f64`-ის აბსოლუტურ მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// აბრუნებს მინიმუმ `f32` მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// აბრუნებს მინიმუმ `f64` მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// აბრუნებს მაქსიმუმ ორი `f32` მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// აბრუნებს მაქსიმუმ ორი `f64` მნიშვნელობას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// ასლის კოპირებას `y`-დან `x`-მდე `f32` მნიშვნელობებისთვის.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// ასლის კოპირებას `y`-დან `x`-მდე `f64` მნიშვნელობებისთვის.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// აბრუნებს უდიდეს რიცხვს `f32`- ზე ნაკლები ან ტოლი.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// აბრუნებს უდიდეს რიცხვს `f64`- ზე ნაკლები ან ტოლი.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// აბრუნებს `f32`- ზე მეტი ან ტოლი ყველაზე პატარა მთელი რიცხვი.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// აბრუნებს `f64`- ზე მეტი ან ტოლი ყველაზე პატარა მთელი რიცხვი.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// აბრუნებს `f32`- ის მთელ ნაწილს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// აბრუნებს `f64`- ის მთელ ნაწილს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// აბრუნებს უახლოეს მთელ რიცხვს `f32`-ს.
    /// შეიძლება დააყენოს არასწორი მცურავი წერტილის გამონაკლისი, თუ არგუმენტი არ არის მთელი რიცხვი.
    pub fn rintf32(x: f32) -> f32;
    /// აბრუნებს უახლოეს მთელ რიცხვს `f64`-ს.
    /// შეიძლება დააყენოს არასწორი მცურავი წერტილის გამონაკლისი, თუ არგუმენტი არ არის მთელი რიცხვი.
    pub fn rintf64(x: f64) -> f64;

    /// აბრუნებს უახლოეს მთელ რიცხვს `f32`-ს.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn nearbyintf32(x: f32) -> f32;
    /// აბრუნებს უახლოეს მთელ რიცხვს `f64`-ს.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn nearbyintf64(x: f64) -> f64;

    /// აბრუნებს უახლოეს მთელ რიცხვს `f32`-ს.საქმეებს ასრულებს შუა ნაწილში ნულის დაშორებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// აბრუნებს უახლოეს მთელ რიცხვს `f64`-ს.საქმეებს ასრულებს შუა ნაწილში ნულის დაშორებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვარიანტია
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Float დამატება, რომელიც ალგებრული წესების საფუძველზე ოპტიმიზაციას იძლევა.
    /// შეიძლება ვივარაუდოთ, რომ შეტანილი მონაცემები სასრულია.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// ათწილადი გამოკლება, რომელიც ალგებრული წესების საფუძველზე ოპტიმიზაციას იძლევა.
    /// შეიძლება ვივარაუდოთ, რომ შეტანილი მონაცემები სასრულია.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// ათწილადი გამრავლება, რაც ალგებრული წესების საფუძველზე ოპტიმიზაციას იძლევა.
    /// შეიძლება ვივარაუდოთ, რომ შეტანილი მონაცემები სასრულია.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// ათწილადი დაყოფა, რომელიც ალგებრული წესების საფუძველზე ოპტიმიზაციას იძლევა.
    /// შეიძლება ვივარაუდოთ, რომ შეტანილი მონაცემები სასრულია.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// ათწილადი ნაშთი, რომელიც ალგებრული წესების საფუძველზე ოპტიმიზაციას იძლევა.
    /// შეიძლება ვივარაუდოთ, რომ შეტანილი მონაცემები სასრულია.
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// გადააკეთეთ LLVM-ის fptoui/fptosi, რაც შეიძლება დაბრუნდეს undef დიაპაზონის ფარგლებს გარეთ
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// სტაბილიზირებულია როგორც [`f32::to_int_unchecked`] და [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// აბრუნებს მთელი რიგის `T` ტიპის ბიტების რაოდენობას
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `count_ones` მეთოდით.
    /// Მაგალითად,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// აბრუნებს წამყვანი განუსაზღვრელი ბიტების რაოდენობას (zeroes) მთელი ტიპის `T` ტიპისთვის.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `leading_zeros` მეთოდით.
    /// Მაგალითად,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` `0` მნიშვნელობით დააბრუნებს `T` ბიტის სიგანეს.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// ისევე, როგორც `ctlz`, მაგრამ ზედმეტად უსაფრთხო, რადგან ის უბრუნებს `undef`-ს, როდესაც `x` მიიღებს `0` მნიშვნელობით.
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// აბრუნებს უკანასკნელი განუსაზღვრელი ბიტების რაოდენობას (zeroes) მთელი ტიპის `T` ტიპისთვის.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `trailing_zeros` მეთოდით.
    /// Მაგალითად,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` `0` მნიშვნელობით დააბრუნებს `T` ბიტის სიგანეს:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// ისევე, როგორც `cttz`, მაგრამ ზედმეტად უსაფრთხო, რადგან ის უბრუნებს `undef`-ს, როდესაც `x` მიიღებს `0` მნიშვნელობით.
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// შეცვლის ბაიტებს მთელი ტიპის `T` ტიპის მიხედვით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `swap_bytes` მეთოდით.
    /// Მაგალითად,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// შეცვლის ბიტებს მთელი ტიპის `T` ტიპის მიხედვით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `reverse_bits` მეთოდით.
    /// Მაგალითად,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// ასრულებს შემოწმებულ მთელი რიცხვის დამატებას.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `overflowing_add` მეთოდით.
    /// Მაგალითად,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ასრულებს შემოწმებულ მთელი რიცხვის გამოკლებას
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `overflowing_sub` მეთოდით.
    /// Მაგალითად,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ასრულებს შემოწმებულ მთელი რიცხვის გამრავლებას
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `overflowing_mul` მეთოდით.
    /// Მაგალითად,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ახორციელებს ზუსტ დაყოფას, რის შედეგადაც ხდება გაურკვეველი ქცევა, სადაც `x % y != 0` ან `y == 0` ან `x == T::MIN && y == -1`
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// ასრულებს გაუმოწმებელ დაყოფას, რის შედეგადაც ხდება გაურკვეველი ქცევა, სადაც `y == 0` ან `x == T::MIN && y == -1`
    ///
    ///
    /// ამ შინაარსის უსაფრთხო შესაფუთები მთელ პრიმიტივებზე ხელმისაწვდომია `checked_div` მეთოდით.
    /// Მაგალითად,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// აბრუნებს გაუმოწმებელი დანაყოფის დანარჩენ ნაწილს, რის შედეგადაც ხდება გაურკვეველი ქცევა, როდესაც `y == 0` ან `x == T::MIN && y == -1`
    ///
    ///
    /// ამ შინაარსის უსაფრთხო შესაფუთები მთელ პრიმიტივებზე ხელმისაწვდომია `checked_rem` მეთოდით.
    /// Მაგალითად,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// ასრულებს შეუმოწმებელ მარცხენა ცვლას, რის შედეგადაც ხდება განუსაზღვრელი ქცევა, როდესაც `y < 0` ან `y >= N`, სადაც N არის T სიგანის ბიტი.
    ///
    ///
    /// ამ შინაარსის უსაფრთხო შესაფუთები მთელ პრიმიტივებზე ხელმისაწვდომია `checked_shl` მეთოდით.
    /// Მაგალითად,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// ასრულებს არაკონტროლირებად მარჯვენა ცვლას, რის შედეგადაც ხდება განუსაზღვრელი ქცევა, როდესაც `y < 0` ან `y >= N`, სადაც N არის სიგანე T- ის ბიტებში.
    ///
    ///
    /// ამ შინაარსის უსაფრთხო შესაფუთები მთელ პრიმიტივებზე ხელმისაწვდომია `checked_shr` მეთოდით.
    /// Მაგალითად,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// აბრუნებს გაუმოწმებელი დამატების შედეგს, რის შედეგადაც ხდება გაურკვეველი ქცევა, როდესაც `x + y > T::MAX` ან `x + y < T::MIN`.
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// აბრუნებს შეუმოწმებელი გამოკლების შედეგს, რის შედეგადაც ხდება გაურკვეველი ქცევა, როდესაც `x - y > T::MAX` ან `x - y < T::MIN`.
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// აბრუნებს შეუმოწმებელი გამრავლების შედეგს, რის შედეგადაც ხდება გაურკვეველი ქცევა, როდესაც `x *y > T::MAX` ან `x* y < T::MIN`.
    ///
    ///
    /// ამ შინაარსს არ აქვს სტაბილური კოლეგა.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// ასრულებს როტაციას მარცხნივ.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `rotate_left` მეთოდით.
    /// Მაგალითად,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// ასრულებს როტაციას მარჯვნივ.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `rotate_right` მეთოდით.
    /// Მაგალითად,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// აბრუნებს (a + b) mod 2 <sup>N</sup>, სადაც N არის სიგანე T- ის ბიტებში.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `wrapping_add` მეთოდით.
    /// Მაგალითად,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// აბრუნებს (a, b) mod 2 <sup>N</sup>, სადაც N არის სიგანე T- ის ბიტებში.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `wrapping_sub` მეთოდით.
    /// Მაგალითად,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// აბრუნებს (a * b) mod 2 <sup>N</sup>, სადაც N არის სიგანე T- ის ბიტებში.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `wrapping_mul` მეთოდით.
    /// Მაგალითად,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// გამოთვლის `a + b`-ს, იჯერებს რიცხვითი საზღვრებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `saturating_add` მეთოდით.
    /// Მაგალითად,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// გამოთვლის `a - b`-ს, იჯერებს რიცხვითი საზღვრებით.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიები მთელ პრიმიტივებზე ხელმისაწვდომია `saturating_sub` მეთოდით.
    /// Მაგალითად,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// აბრუნებს დისკრიმინატორის მნიშვნელობას 'v' ვარიანტისთვის;
    /// თუ `T`- ს არ აქვს განსხვავება, აბრუნებს `0`- ს.
    ///
    /// ამ შინაარსის სტაბილიზირებული ვერსიაა [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// აბრუნებს `T` ტიპის ტიპის `T` ტიპის ვარიანტების რაოდენობას;
    /// თუ `T` არ აქვს ვარიანტები, აბრუნებს `0`.დაითვლება დაუსახლებელი ვარიანტები.
    ///
    /// ამ შინაარსის სტაბილიზირებადი ვერსიაა [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust-ის "try catch" კონსტრუქცია, რომელიც იძახებს ფუნქციის მაჩვენებელს `try_fn` მონაცემთა მაჩვენებელთან `data`.
    ///
    /// მესამე არგუმენტი არის ფუნქცია, რომელსაც ეწოდება panic.
    /// ეს ფუნქცია მონაცემების მაჩვენებელს და კურსორს მიაქვს სამიზნე სპეციფიკური გამონაკლისის ობიექტში, რომელიც დაიჭირეს.
    ///
    /// დამატებითი ინფორმაციისთვის იხილეთ შემდგენლის წყარო და std- ის დაჭერის განხორციელება.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// გამოდის `!nontemporal` მაღაზია LLVM- ის შესაბამისად (იხილეთ მათი დოკუმენტები).
    /// ალბათ არასდროს გახდება სტაბილური.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// დეტალებისთვის იხილეთ `<*const T>::offset_from`- ის დოკუმენტაცია.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// დეტალებისთვის იხილეთ `<*const T>::guaranteed_eq`- ის დოკუმენტაცია.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// დეტალებისთვის იხილეთ `<*const T>::guaranteed_ne`- ის დოკუმენტაცია.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// განაწილება შედგენის დროს.არ უნდა დარეკოთ დროს.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// ზოგიერთი ფუნქცია აქ განისაზღვრება, რადგან ისინი შემთხვევით გახდნენ ხელმისაწვდომი ამ მოდულში სტაბილურზე.
// იხილეთ <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` ასევე განეკუთვნება ამ კატეგორიას, მაგრამ მისი შეფუთვა შეუძლებელია იმის გამო, რომ `T` და `U` ერთნაირია.)
//

/// ამოწმებს სწორად შეესაბამება `ptr` `align_of::<T>()`- სთან დაკავშირებით.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// ასლის `count *size_of::<T>()` ბაიტს `src`-დან `dst`-მდე.წყარო და დანიშნულების ადგილი* არ უნდა ემთხვეოდეს ერთმანეთს.
///
/// მეხსიერების იმ რეგიონებისთვის, რომლებიც შეიძლება გადახურდეს, ნაცვლად გამოიყენეთ [`copy`].
///
/// `copy_nonoverlapping` სემანტიკურად ეკვივალენტურია C's [`memcpy`]- ს, მაგრამ არგუმენტის თანმიმდევრობით შეიცვალა.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// ქცევა განუსაზღვრელია, თუ დარღვეულია შემდეგი პირობებიდან რომელიმე:
///
/// * `src` უნდა იყოს [valid] `count * size_of::<T>()` ბაიტის წაკითხვისთვის.
///
/// * `dst` უნდა იყოს [valid] `count * size_of::<T>()` ბაიტის დასაწერად.
///
/// * `src` და `dst` უნდა იყოს სწორად გასწორებული.
///
/// * მეხსიერების რეგიონი, რომელიც იწყება `src`-ზე, `რაოდენობის` ზომით *
///   ზომა: :<T>() `ბაიტი *არ* უნდა ემთხვეოდეს მეხსიერების რეგიონს, რომელიც იწყება `dst` იგივე ზომით.
///
/// [`read`]-ის მსგავსად, `copy_nonoverlapping` ქმნის `T`-ის ბიტიურად ასლს, მიუხედავად იმისა არის თუ არა `T` [`Copy`].
/// თუ `T` არ არის [`Copy`], გამოიყენეთ *ორივე* მნიშვნელობები რეგიონში, რომელიც იწყება `*src` და რეგიონის დასაწყისში `* dst` შეიძლება [violate memory safety][read-ownership].
///
///
/// გაითვალისწინეთ, რომ მაშინაც კი, თუ ეფექტურად გადაწერილი ზომაა (`count * size_of: :<T>()") არის `0`, მითითებები უნდა იყოს არა NULL და სწორად გასწორებული.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// ხელით განახორციელეთ [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// `src`- ის ყველა ელემენტს გადააქვს `dst`- ში, დატოვებს `src` ცარიელს.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // დარწმუნდით, რომ `dst`- ს აქვს საკმარისი ტევადობა, რომ იტევს ყველა `src`- ს.
///     dst.reserve(src_len);
///
///     unsafe {
///         // კომპენსაციაზე ზარი ყოველთვის უსაფრთხოა, რადგან `Vec` არასოდეს გამოყოფს `isize::MAX` ბაიტზე მეტს.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // `src` შეკვეცით მისი შინაარსის ჩაშვების გარეშე.
///         // პირველ რიგში ამას ვაკეთებთ, პრობლემების თავიდან ასაცილებლად panics-ის კიდევ უფრო შემცირების შემთხვევაში.
///         src.set_len(0);
///
///         // ორი რეგიონი ვერ გადაფარავს, რადგან ცვლადი ცნობარი არ არის მეტსახელი და ორი განსხვავებული vectors ვერ ფლობს ერთსა და იმავე მეხსიერებას.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // აცნობეთ `dst`-ს, რომ ის ახლა ინახავს `src`-ის შინაარსს.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: შეამოწმეთ მხოლოდ შემოწმების დრო
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // პანიკა არ არის, რომ კოდეგენის გავლენა მცირე იყოს.
        abort();
    }*/

    // უსაფრთხოება: უსაფრთხოების კონტრაქტი `copy_nonoverlapping`- სთვის უნდა შედგეს
    // მხარს უჭერს აბონენტს.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// ასლის `count * size_of::<T>()` ბაიტს `src`-დან `dst`-მდე.წყარო და დანიშნულების ადგილი შეიძლება ემთხვეოდეს ერთმანეთს.
///
/// თუ წყარო და დანიშნულების ადგილი *არასოდეს* გადაფარავს, მის ნაცვლად შეგიძლიათ გამოიყენოთ [`copy_nonoverlapping`].
///
/// `copy` სემანტიკურად ეკვივალენტურია C's [`memmove`]- ს, მაგრამ არგუმენტის თანმიმდევრობით შეიცვალა.
/// კოპირება ხდება ისე, თითქოს ბაიტები გადაწერილია `src`- დან დროებით მასივში და შემდეგ გადაწერილ იქნა მასივიდან `dst`- ზე.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// ქცევა განუსაზღვრელია, თუ დარღვეულია შემდეგი პირობებიდან რომელიმე:
///
/// * `src` უნდა იყოს [valid] `count * size_of::<T>()` ბაიტის წაკითხვისთვის.
///
/// * `dst` უნდა იყოს [valid] `count * size_of::<T>()` ბაიტის დასაწერად.
///
/// * `src` და `dst` უნდა იყოს სწორად გასწორებული.
///
/// [`read`]-ის მსგავსად, `copy` ქმნის `T`-ის ბიტიურად ასლს, მიუხედავად იმისა არის თუ არა `T` [`Copy`].
/// თუ `T` არ არის [`Copy`], გამოიყენეთ როგორც მნიშვნელობები რეგიონში, რომელიც იწყება `*src`-ზე და რეგიონში, რომელიც იწყება `* src`-ზე, შეიძლება [violate memory safety][read-ownership].
///
///
/// გაითვალისწინეთ, რომ მაშინაც კი, თუ ეფექტურად გადაწერილი ზომაა (`count * size_of: :<T>()") არის `0`, მითითებები უნდა იყოს არა NULL და სწორად გასწორებული.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// ეფექტურად შექმნათ Rust vector არაუსაფრთხო ბუფერულიდან:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` უნდა იყოს სწორად გასწორებული მისი ტიპისთვის და არა ნულოვანი.
/// /// * `ptr` მოქმედი უნდა იყოს X001 ტიპის `elts` მომიჯნავე ელემენტების წაკითხვისთვის.
/// /// * ამ ელემენტების გამოყენება არ შეიძლება ამ ფუნქციის გამოძახების შემდეგ, გარდა `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // უსაფრთხოება: ჩვენი წინაპირობა უზრუნველყოფს წყაროს შესაბამისობას და მართებას,
///     // და `Vec::with_capacity` უზრუნველყოფს, რომ ჩვენ გვაქვს გამოსადეგი სივრცე მათ დასაწერად.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // უსაფრთხოება: ჩვენ ამდენი შესაძლებლობით ადრე შევქმენით,
///     // და წინა `copy`- მა ამ ელემენტების ინიციალიზაცია მოახდინა.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: შეამოწმეთ მხოლოდ შემოწმების დრო
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // პანიკა არ არის, რომ კოდეგენის გავლენა მცირე იყოს.
        abort();
    }*/

    // უსაფრთხოება: აბონენტის მიერ დაცული უნდა იყოს უსაფრთხოების კონტრაქტი `copy`- ზე.
    unsafe { copy(src, dst, count) }
}

/// ადგენს მეხსიერების `count * size_of::<T>()` ბაიტს, დაწყებული `dst`-დან `val`-მდე.
///
/// `write_bytes` მსგავსია C's [`memset`], მაგრამ ადგენს `count * size_of::<T>()` ბაიტებს `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// ქცევა განუსაზღვრელია, თუ დარღვეულია შემდეგი პირობებიდან რომელიმე:
///
/// * `dst` უნდა იყოს [valid] `count * size_of::<T>()` ბაიტის დასაწერად.
///
/// * `dst` სწორად გასწორებული უნდა იყოს.
///
/// დამატებით, გამრეკელმა უნდა უზრუნველყოს, რომ მეხსიერების მოცემულ რეგიონში `count * size_of::<T>()` ბაიტის ჩაწერას `T` მოქმედი მნიშვნელობა აქვს.
/// `T`- ით აკრეფილი მეხსიერების რეგიონის გამოყენება, რომელიც შეიცავს `T`- ის არასწორ მნიშვნელობას, არ არის განსაზღვრული ქცევა.
///
/// გაითვალისწინეთ, რომ მაშინაც კი, თუ ეფექტურად გადაწერილი ზომაა (`count * size_of: :<T>()") არის `0`, მაჩვენებელი უნდა იყოს არა NULL და სწორად გასწორებული.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// არასწორი მნიშვნელობის შექმნა:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // გაჟონავს ადრე დაცულ მნიშვნელობას `Box<T>` ნულოვანი მაჩვენებლის გადაწერით.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // ამ ეტაპზე, `v`- ის გამოყენება ან ვარდნა იწვევს გაურკვეველ ქცევას.
/// // drop(v); // ERROR
///
/// // `v` "uses"- ის გაჟონვაც კი, და შესაბამისად, გაურკვეველი ქცევაა.
/// // mem::forget(v); // ERROR
///
/// // სინამდვილეში, `v` არასწორია ძირითადი ტიპის განლაგების ინვარიანტების მიხედვით, ასე რომ * მასთან დაკავშირებული ნებისმიერი ოპერაცია განუსაზღვრელი ქცევაა.
/////
/// // მოდით v2 =v;//შეცდომა
///
/// unsafe {
///     // ამის ნაცვლად, ჩადეთ სწორი მნიშვნელობა
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // ახლა ყუთი კარგად არის
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // უსაფრთხოება: აბონენტის მიერ დაცული უნდა იყოს უსაფრთხოების კონტრაქტი `write_bytes`- ზე.
    unsafe { write_bytes(dst, val, count) }
}