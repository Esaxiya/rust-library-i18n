//! Traits ტიპებს შორის კონვერტაციისთვის.
//!
//! traits ამ მოდულში გთავაზობთ ერთი ტიპისაგან მეორე ტიპის გადასაყვანად.
//! თითოეული trait განსხვავებულ მიზანს ემსახურება:
//!
//! - განახორციელეთ [`AsRef`] trait იაფი მითითების მითითებაზე გადასაყვანად
//! - განახორციელეთ [`AsMut`] trait იაფი ცვლადიდან მუტაბელური კონვერტაციისთვის
//! - განახორციელეთ [`From`] trait მნიშვნელობა-ღირებულების კონვერტაციისთვის
//! - განახორციელეთ [`Into`] trait მნიშვნელობა-მნიშვნელობიანი კონვერტაციისთვის, ამჟამად არსებული crate-ის გარეშე
//! - [`TryFrom`] და [`TryInto`] traits იქცევიან ისე, როგორც [`From`] და [`Into`], მაგრამ უნდა განხორციელდეს, როდესაც გარდაქმნა ვერ მოხდება.
//!
//! traits ამ მოდულში ხშირად გამოიყენება როგორც trait bounds ზოგადი ფუნქციებისათვის, რომლითაც მრავალი ტიპის არგუმენტებია მხარდაჭერილი.მაგალითებისათვის იხილეთ თითოეული trait დოკუმენტაცია.
//!
//! როგორც ბიბლიოთეკის ავტორი, თქვენ ყოველთვის უნდა გირჩევნიათ [`From<T>`][`From`] ან [`TryFrom<T>`][`TryFrom`], ვიდრე [`Into<U>`][`Into`] ან [`TryInto<U>`][`TryInto`], რადგან [`From`] და [`TryFrom`] უზრუნველყოფს მეტ მოქნილობას და გთავაზობთ ეკვივალენტურ [`Into`] ან [`TryInto`] რეალიზაციებს, სტანდარტული ბიბლიოთეკაში საბნის განხორციელების წყალობით.
//! Rust 1.41-ზე ადრე ვერსიის სამიზნისას შეიძლება საჭირო გახდეს [`Into`] ან [`TryInto`] უშუალოდ დანერგვა, როდესაც მიმდინარე crate-ს გარეთ იმყოფება ტიპის.
//!
//! # ზოგადი განხორციელება
//!
//! - [`AsRef`] და [`AsMut`] ავტო-გადამისამართება, თუ შიდა ტიპი არის მითითება
//! - [`From`]`<U>T` გულისხმობს [`Into`]-ს</u><T><U>U`-სთვის</u>
//! - [`TryFrom`]`<U>T`გულისხმობს [`TryInto`] `</u><T><U>U`-სთვის</u>
//! - [`From`] და [`Into`] არის რეფლექსური, რაც ნიშნავს, რომ ყველა ტიპს შეუძლია `into` თვითონ და `from` თავად
//!
//! გამოყენების მაგალითებისთვის იხილეთ თითოეული trait.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// პირადობის ფუნქცია.
///
/// ორი რამ მნიშვნელოვანია აღინიშნოს ამ ფუნქციის შესახებ:
///
/// - ეს ყოველთვის არ არის `|x| x`- ის მსგავსი დახურვის ექვივალენტი, რადგან დახურვამ შეიძლება `x` სხვა ტიპის იძულებითი გახადოს.
///
/// - ის გადააქვს `x` შეყვანილ ფუნქციას.
///
/// მიუხედავად იმისა, რომ შეიძლება უცნაურად გამოიყურებოდეს ფუნქციის არსებობა, რომელიც მხოლოდ უკან აბრუნებს შეყვანას, არსებობს რამდენიმე საინტერესო გამოყენება
///
///
/// # Examples
///
/// გამოიყენეთ `identity`, რომ არაფერი გააკეთოთ სხვა, საინტერესო, ფუნქციების თანმიმდევრობით:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // მოდით ვიმოქმედოთ, რომ მისი დამატება საინტერესო ფუნქციაა.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity`- ის გამოყენება როგორც "do nothing" ძირითადი შემთხვევა პირობითად:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // გააკეთე უფრო საინტერესო პერსონალი ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `identity`- ის გამოყენება `Option<T>`- ის იტერატორის `Some` ვარიანტების შესანარჩუნებლად:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// გამოიყენება იაფი მითითების მითითების გარდაქმნის გასაკეთებლად.
///
/// ეს trait ჰგავს [`AsMut`]-ს, რომელიც გამოიყენება მუტაბელურ ცნობებს შორის გადასაყვანად.
/// თუ თქვენ გჭირდებათ ძვირადღირებული კონვერტაციის გაკეთება, უმჯობესია [`From`] ტიპის `&T` ტიპის გამოყენებით გამოიყენოთ ან დაწეროთ საკუთარი ფუნქცია.
///
/// `AsRef` აქვს იგივე ხელმოწერა, როგორც [`Borrow`], მაგრამ [`Borrow`] განსხვავდება რამდენიმე ასპექტით:
///
/// - `AsRef`-ისგან განსხვავებით, [`Borrow`]-ს აქვს პერანგი ნებისმიერი `T`-სთვის და ის შეიძლება გამოყენებულ იქნას როგორც მითითების, ასევე მნიშვნელობის მისაღებად.
/// - [`Borrow`] ასევე მოითხოვს, რომ [`Hash`], [`Eq`] და [`Ord`] ნასესხები ღირებულებისთვის ეკვივალენტურია საკუთრების ღირებულების.
/// ამ მიზეზით, თუ გსურთ სტრუქტურის მხოლოდ ერთი ველის სესხის აღება, შეგიძლიათ განახორციელოთ `AsRef`, მაგრამ არა [`Borrow`].
///
/// **Note: ეს trait არ უნდა ჩავარდეს **.თუ გარდაქმნა ვერ მოხერხდა, გამოიყენეთ გამოყოფილი მეთოდი, რომელიც აბრუნებს [`Option<T>`] ან [`Result<T, E>`].
///
/// # ზოგადი განხორციელება
///
/// - `AsRef` ავტომატური გადამისამართებები, თუ შიდა ტიპი არის მითითება ან ცვალებადი მითითება (მაგ.: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds-ის გამოყენებით ჩვენ შეგვიძლია მივიღოთ სხვადასხვა ტიპის არგუმენტები, სანამ ისინი შეიძლება გადაკეთდეს მითითებულ `T` ტიპში.
///
/// მაგალითად: ზოგადი ფუნქციის შექმნით, რომელიც იღებს `AsRef<str>`-ს, გამოვთქვამთ, რომ არგუმენტად უნდა მივიღოთ ყველა მითითება, რომელთა გადაყვანა შეიძლება [`&str`]-ში.
/// მას შემდეგ, რაც [`String`] და [`&str`] ახორციელებენ `AsRef<str>`, ჩვენ შეგვიძლია ორივე მივიღოთ, როგორც შეყვანის არგუმენტი.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// ასრულებს გარდაქმნას.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// გამოიყენება იაფი ცვლადიდან მუტაბელური რეფერენციის გადასაკეთებლად.
///
/// ეს trait ჰგავს [`AsRef`]-ს, მაგრამ გამოიყენება მუტაბელურ ცნობებს შორის გადასაყვანად.
/// თუ თქვენ გჭირდებათ ძვირადღირებული კონვერტაციის გაკეთება, უმჯობესია [`From`] ტიპის `&mut T` ტიპის გამოყენებით გამოიყენოთ ან დაწეროთ საკუთარი ფუნქცია.
///
/// **Note: ეს trait არ უნდა ჩავარდეს **.თუ გარდაქმნა ვერ მოხერხდა, გამოიყენეთ გამოყოფილი მეთოდი, რომელიც აბრუნებს [`Option<T>`] ან [`Result<T, E>`].
///
/// # ზოგადი განხორციელება
///
/// - `AsMut` ავტომატური გადამისამართება, თუ შინაგანი ტიპი ცვალებადი მითითებაა (მაგ.: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// `AsMut`, როგორც trait bound ზოგადი ფუნქციისთვის, ჩვენ შეგვიძლია მივიღოთ ყველა ცვალებადი მითითება, რომელიც შეიძლება გადაკეთდეს `&mut T` ტიპად.
/// იმის გამო, რომ [`Box<T>`] ახორციელებს `AsMut<T>`-ს, ჩვენ შეგვიძლია დავწეროთ ფუნქცია `add_one`, რომელიც აიღებს ყველა არგუმენტს, რომლის გადაკეთებაც შეიძლება `&mut u64`.
/// იმის გამო, რომ [`Box<T>`] ახორციელებს `AsMut<T>`-ს, `add_one` იღებს `&mut Box<u64>` ტიპის არგუმენტებს:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// ასრულებს გარდაქმნას.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// მნიშვნელობა ღირებულებიდან გარდაქმნა, რომელიც ხარჯავს შეყვანის მნიშვნელობას.[`From`]-ის საპირისპირო.
///
/// თავიდან უნდა აიცილოთ [`Into`]- ის დანერგვა და ნაცვლად ამისა, განხორციელდეს [`From`].
/// [`From`]- ის განხორციელება ავტომატურად უზრუნველყოფს [`Into`]- ის დანერგვას სტანდარტულ ბიბლიოთეკაში პლედის დანერგვის წყალობით.
///
/// trait bounds ზოგად ფუნქციაზე მითითებისას ამჯობინეთ [`Into`]-ს გამოყენება [`From`]-ზე, იმის უზრუნველსაყოფად, რომ ტიპების გამოყენება, რომლებიც მხოლოდ [`Into`]-ს ახორციელებენ, შეიძლება გამოყენებულ იქნას.
///
/// **Note: ეს trait არ უნდა ჩავარდეს **.თუ გარდაქმნა ვერ მოხერხდა, გამოიყენეთ [`TryInto`].
///
/// # ზოგადი განხორციელება
///
/// - [```` ```<T>რადგან U` გულისხმობს `Into<U> for T`-ს
/// - [`Into`] არის რეფლექსური, რაც ნიშნავს, რომ `Into<T> for T` ხორციელდება
///
/// # [`Into`]- ის განხორციელება Rust- ის ძველ ვერსიებში გარე ტიპებზე გადასასვლელად
///
/// Rust 1.41-მდე, თუ დანიშნულების ტიპი არ იყო ამჟამინდელი crate-ის ნაწილი, მაშინ თქვენ ვერ განახორციელებდით [`From`] პირდაპირ.
/// მაგალითად, აიღეთ ეს კოდი:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// ეს ვერ მოხერხდება ენის ძველ ვერსიებში შედგენაში, რადგან ადრე Rust-ს ობოლი წესები ოდნავ უფრო მკაცრი იყო.
/// ამის გვერდის ავლით, თქვენ შეგიძლიათ განახორციელოთ [`Into`] პირდაპირ:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// მნიშვნელოვანია გვესმოდეს, რომ [`Into`] არ იძლევა [`From`] განხორციელებას (როგორც [`From`] აკეთებს [`Into`]-ს).
/// ამიტომ, თქვენ ყოველთვის უნდა ეცადოთ [`From`]-ის დანერგვას და შემდეგ დაბრუნდეთ [`Into`]-ზე, თუ [`From`] ვერ განხორციელდება.
///
/// # Examples
///
/// [`String`] ახორციელებს ["Into"] "<" ["Vec"] "<" ["u8"] ">>:
///
/// იმისთვის, რომ გამოვხატოთ, რომ ზოგადი ფუნქცია უნდა მიიღოს ყველა არგუმენტს, რომელიც შეიძლება გადაკეთდეს მითითებულ `T` ტიპზე, შეგვიძლია გამოვიყენოთ trait bound ["Into"]-დან<T>`
///
/// მაგალითად: `is_hello` ფუნქცია იღებს ყველა არგუმენტს, რომელთა გადაქცევაც შეიძლება გახდეს [`Vec`]``` ```` ```` ```` ```` ``;
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// ასრულებს გარდაქმნას.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// გამოიყენება მნიშვნელობიდან მნიშვნელობად გადაქცევისას შეყვანის მნიშვნელობის ხარჯვის დროს.ეს არის საპასუხო [`Into`].
///
/// ყოველთვის უნდა ამჯობინონ `From`- ის დანერგვა [`Into`]- ზე, რადგან `From`- ის დანერგვა ავტომატურად უზრუნველყოფს [`Into`]- ის დანერგვას სტანდარტულ ბიბლიოთეკაში საბნის დანერგვის წყალობით.
///
///
/// განახორციელეთ [`Into`] მხოლოდ Rust 1.41-ზე ადრე ვერსიის სამიზნედ და ამჟამინდელი crate-ის გარეთ ტიპზე გადასაყვანად.
/// `From` მან ვერ შეძლო ამ ტიპის კონვერტაციების ჩატარება ადრეულ ვერსიებში, Rust ობოლი წესების გამო.
/// დამატებითი ინფორმაციისთვის იხილეთ [`Into`].
///
/// trait bounds ზოგადი ფუნქციის მითითებისას გირჩევნიათ გამოიყენოთ [`Into`] ვიდრე `From`.
/// ამ გზით, არგუმენტებად შეიძლება გამოყენებულ იქნას ტიპები, რომლებიც უშუალოდ ახორციელებენ [`Into`]-ს.
///
/// `From` ასევე ძალიან სასარგებლოა შეცდომების დამუშავებისას.ფუნქციის აგებისას, რომელსაც შეუძლია წარუმატებლობა, დაბრუნების ტიპი ძირითადად იქნება `Result<T, E>` ფორმის.
/// `From` trait ამარტივებს შეცდომების დამუშავებას და საშუალებას აძლევს ფუნქციას დააბრუნოს შეცდომის ერთი ტიპი, რომელიც მოიცავს მრავალი შეცდომის ტიპს.დაწვრილებითი ინფორმაციისთვის იხილეთ "Examples" სექცია და [the book][book].
///
/// **Note: ეს trait არ უნდა ჩავარდეს **.თუ გარდაქმნა ვერ მოხერხდა, გამოიყენეთ [`TryFrom`].
///
/// # ზოგადი განხორციელება
///
/// - `From<T> for U` გულისხმობს [`Into`]`<U>T`-სთვის</u>
/// - `From` არის რეფლექსური, რაც ნიშნავს, რომ `From<T> for T` ხორციელდება
///
/// # Examples
///
/// [`String`] ახორციელებს `From<&str>`:
///
/// აშკარა გარდაქმნა `&str`- დან სიმებად ხდება შემდეგნაირად:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// შეცდომების გატარებისას ხშირად სასარგებლოა `From` საკუთარი შეცდომის ტიპისთვის.
/// ძირითადი შეცდომის ტიპების საკუთარი შეცდომის მორგებული ტიპით გადაკეთებით, რომელიც მოიცავს ძირითადი შეცდომის ტიპს, შეგვიძლია დავაბრუნოთ ერთი შეცდომის ტიპი, ძირითადი მიზეზების შესახებ ინფორმაციის დაკარგვის გარეშე.
/// '?' ოპერატორი ავტომატურად გარდაქმნის ძირითადი შეცდომის ტიპს ჩვენს ჩვეულ შეცდომის ტიპზე, დარეკვით `Into<CliError>::into`, რომელიც ავტომატურად არის მოწოდებული `From`- ის დანერგვისას.
/// შემდგენელი შემდეგ გამოდის, რომ `Into`- ის რომელი დანერგვა უნდა იქნას გამოყენებული.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// ასრულებს გარდაქმნას.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// კონვერტაციის მცდელობა, რომელიც მოიხმარს `self`-ს, რაც შეიძლება ძვირი იყოს ან არ იყოს ძვირი.
///
/// ბიბლიოთეკის ავტორებს, როგორც წესი, პირდაპირ არ უნდა განახორციელონ ეს trait, მაგრამ ურჩევნიათ [`TryFrom`] trait-ის დანერგვა, რომელიც უფრო მეტ მოქნილობას გვთავაზობს და ექვივალენტურ `TryInto` განხორციელებას უზრუნველყოფს სტანდარტულ ბიბლიოთეკაში საბნის განხორციელების წყალობით.
/// ამის შესახებ დამატებითი ინფორმაციისთვის იხილეთ [`Into`] დოკუმენტაცია.
///
/// # განმახორციელებელი `TryInto`
///
/// ეს განიცდის იგივე შეზღუდვებს და მსჯელობას, როგორც [`Into`]- ის განხორციელება, დეტალებისთვის იხილეთ იქ.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// ტიპი დაბრუნდა გარდაქმნის შეცდომის შემთხვევაში.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ასრულებს გარდაქმნას.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// მარტივი და უსაფრთხო ტიპის კონვერტაციები, რომლებიც შეიძლება კონტროლირებად ვერ მოხდეს გარკვეულ ვითარებაში.ეს არის საპასუხო [`TryInto`].
///
/// ეს გამოდგება მაშინ, როდესაც თქვენ აკეთებთ ტიპის გარდაქმნას, რომელსაც შეიძლება ტრივიალური წარმატებით მიაღწიოს, მაგრამ შეიძლება ასევე განსაკუთრებული დამუშავება დაგჭირდეთ.
/// მაგალითად, არ არსებობს [`i64`] [`i32`]-ში [`From`] trait-ის გადაქცევის საშუალება, რადგან [`i64`] შეიძლება შეიცავდეს მნიშვნელობას, რომელსაც [`i32`] ვერ წარმოადგენს და ამიტომ გარდაქმნა დაკარგავს მონაცემებს.
///
/// ამის მოგვარება შესაძლებელია [`i64`]- ის [`i32`]- ზე შეკვეთით (არსებითად [i64 »-ის მნიშვნელობის მოდულის [`i32::MAX`] მიცემით) ან უბრალოდ [`i32::MAX`] დაბრუნებით, ან რაიმე სხვა მეთოდით.
/// [`From`] trait განკუთვნილია სრულყოფილი კონვერტაციისთვის, ამიტომ `TryFrom` trait აცნობებს პროგრამისტს, როდის შეიძლება ცუდი შეცვალოს ტიპი და საშუალებას აძლევს მათ გადაწყვიტონ, თუ როგორ უნდა მოიქცნენ.
///
/// # ზოგადი განხორციელება
///
/// - `TryFrom<T> for U` გულისხმობს [`TryInto`]`<U>T`-სთვის</u>
/// - [`try_from`] არის რეფლექსური, რაც ნიშნავს, რომ `TryFrom<T> for T` არის დანერგილი და ვერ ჩავარდება-ასოცირებული `Error` ტიპის `T::try_from()` დარეკვისთვის `T` ტიპის მნიშვნელობაზე არის [`Infallible`].
/// [`!`] ტიპის სტაბილიზაციის შემთხვევაში, [`Infallible`] და [`!`] ექვივალენტური იქნება.
///
/// `TryFrom<T>` შეიძლება განხორციელდეს შემდეგნაირად:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// როგორც აღწერილია, [`i32`] ახორციელებს `TryFrom <` [`i64`]`>>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // ჩუმად იკვეცება `big_number`, მოითხოვს ფაქტის შემდეგ მოსარჩევის გამოვლენასა და დამუშავებას.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // აბრუნებს შეცდომას, რადგან `big_number` ძალიან დიდია `i32`- ში ჩასატარებლად.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // აბრუნებს `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// ტიპი დაბრუნდა გარდაქმნის შეცდომის შემთხვევაში.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ასრულებს გარდაქმნას.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ზოგადი დებულებები
////////////////////////////////////////////////////////////////////////////////

// როგორც ლიფტები და
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// როგორც ლიფტები &mut- ზე
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): შეცვალეთ ზემოთ მოცემული სიტყვები&/&mut-ით შემდეგი უფრო ზოგადით:
// // როგორც ლიფტები დერეფზე
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? ზომის> AsRef <U>D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut მოხსნის &mut-ს
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): შეცვალეთ ზემოთ მითითებული &mut- ით შემდეგი უფრო ზოგადით:
// // AsMut მოხსნის DerefMut-ს
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? ზომის> AsMut <U>D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// დან გულისხმობს Into-ს
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// დან (და ამით Into) არის რეფლექსური
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **სტაბილურობის აღნიშვნა:** ეს გავლენა ჯერ არ არსებობს, მაგრამ ჩვენ ვართ "reserving space", რომ დაამატოთ იგი future.
/// დეტალებისთვის იხილეთ [rust-lang/rust#64715][#64715].
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ამის ნაცვლად გააკეთეთ პრინციპული გამოსწორება.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom გულისხმობს TryInto-ს
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// უტყუარი გარდაქმნები სემანტიკურად უდრის შეცდომით გადაქცევას, დაუსახლებელი შეცდომის ტიპის მქონე.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// ბეტონის იმპლ
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// შეცდომების შეცდომის ტიპი
////////////////////////////////////////////////////////////////////////////////

/// შეცდომის ტიპი შეცდომებისთვის, რომელიც არასდროს შეიძლება მოხდეს.
///
/// მას შემდეგ, რაც ამ enum-ს არა აქვს ვარიანტი, ამ ტიპის მნიშვნელობა რეალურად ვერასოდეს იარსებებს.
/// ეს შეიძლება სასარგებლო იყოს ზოგადი API-ებისთვის, რომლებიც იყენებენ [`Result`] და პარამეტრირებენ შეცდომის ტიპს, რომ მიუთითონ, რომ შედეგი ყოველთვის არის [`Ok`].
///
/// მაგალითად, [`TryFrom`] trait (კონვერტაცია, რომელიც აბრუნებს [`Result`]) აქვს პლედის განხორციელება ყველა ტიპისთვის, სადაც საპირისპირო [`Into`] განხორციელება არსებობს.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future თავსებადობა
///
/// ამ enum- ს იგივე როლი აქვს, როგორც [the `!`“never”type][never], რომელიც არასტაბილურია Rust- ის ამ ვერსიაში.
/// როდესაც `!` სტაბილიზირდება, ჩვენ ვაპირებთ, რომ `Infallible` გახდეს მისთვის დამახასიათებელი სახელი:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// Eventually და საბოლოოდ გააუქმეთ `Infallible`.
///
/// ამასთან, არსებობს ერთი შემთხვევა, როდესაც `!` სინტაქსი შეიძლება გამოყენებულ იქნას, სანამ `!` არ გახდება სტაბილური, როგორც სრულფასოვანი ტიპი: ფუნქციის დაბრუნების ტიპის პოზიციაში.
/// კერძოდ, შესაძლებელია განხორციელდეს ორი სხვადასხვა ფუნქციური მაჩვენებლის ტიპი:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// თუ `Infallible` არის enum, ეს კოდი მოქმედებს.
/// ამასთან, როდესაც `Infallible` გახდება მეტსახელი never type-სთვის, ორი "impl" დაიწყებს გადახურვას და, შესაბამისად, მათ ენაზე trait თანმიმდევრულობის წესები არ მიიღებენ.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}