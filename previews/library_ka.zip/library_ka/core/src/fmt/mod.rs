//! სტრიქონების ფორმატირებისა და ბეჭდვის საშუალებები.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align`-ით დაბრუნებული შესაძლო გასწორებები
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// მითითება, რომ შინაარსი გასწორებული უნდა იყოს მარცხნივ.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// მითითება, რომ შინაარსი უნდა იყოს სწორხაზოვანი.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// მითითება, რომ შინაარსი უნდა იყოს გასწორებული ცენტრში.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// ფორმატირების მეთოდებით დაბრუნებული ტიპი.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// შეცდომის ტიპი, რომელიც უბრუნდება შეტყობინებას სტრიმიდან ფორმატისგან.
///
/// ეს ტიპი მხარს არ უჭერს შეცდომის გარდა შეცდომას.
/// ნებისმიერი დამატებითი ინფორმაცია უნდა იყოს მოწყობილი, რომ გადაეცეს სხვა საშუალებებით.
///
/// მნიშვნელოვანია გვახსოვდეს, რომ ტიპი `fmt::Error` არ უნდა აგვერიოს [`std::io::Error`] ან [`std::error::Error`]- ში, რაც შეიძლება ასევე გქონდეს მოცულობით.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// trait უნიკოდის მიმღებ ბუფერებში ან ნაკადებში დასაწერად ან ფორმატისთვის.
///
/// ეს trait იღებს მხოლოდ UTF-8 დაშიფრულ მონაცემებს და არ არის [flushable].
/// თუ გსურთ მხოლოდ Unicode-ის მიღება და არ გჭირდებათ ჩამორეცხვა, უნდა გამოიყენოთ ეს trait;
/// წინააღმდეგ შემთხვევაში თქვენ უნდა დანერგოთ [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// წერს ამ მწერლს სიმების ნაჭერს და უბრუნებს წარმატების მიღწევას.
    ///
    /// ამ მეთოდს წარმატების მიღწევა მხოლოდ მაშინ შეუძლია, თუ სიმების მთელი ნაკვეთი წარმატებით იქნა დაწერილი, და ეს მეთოდი არ დაბრუნდება მანამ, სანამ ყველა მონაცემები არ დაიწერება ან შეცდომა არ მოხდება.
    ///
    ///
    /// # Errors
    ///
    /// ეს ფუნქცია დააბრუნებს [`Error`] ინსტანციას შეცდომით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// წერს [`char`] ამ მწერალს, უბრუნებს თუ არა წარწერა წარმატებას.
    ///
    /// ერთი [`char`] შეიძლება დაშიფრული იყოს როგორც ერთზე მეტი ბაიტი.
    /// ამ მეთოდს წარმატება მხოლოდ მაშინ შეუძლია, თუ მთელი ბაიტის მიმდევრობა წარმატებით იქნა დაწერილი და ეს მეთოდი არ დაბრუნდება მანამ, სანამ ყველა მონაცემები არ დაიწერება ან შეცდომა არ მოხდება.
    ///
    ///
    /// # Errors
    ///
    /// ეს ფუნქცია დააბრუნებს [`Error`] ინსტანციას შეცდომით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// წებო [`write!`] მაკროსათვის ამ trait- ის განმახორციელებლებთან ერთად.
    ///
    /// ზოგადად, ეს მეთოდი არ უნდა იქნას გამოყენებული ხელით, არამედ თავად [`write!`] მაკროთი.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// კონფიგურაცია ფორმატირებისთვის.
///
/// `Formatter` წარმოადგენს ფორმატირებასთან დაკავშირებულ სხვადასხვა ვარიანტებს.
/// მომხმარებლები არ აშენებენ `Formatter`-ს პირდაპირ;მუტაციის მითითება გადაეცემა `fmt` მეთოდს traits ფორმატის ყველა ფორმატში, როგორიცაა [`Debug`] და [`Display`].
///
///
/// `Formatter`-თან ურთიერთობისთვის თქვენ დაურეკავთ სხვადასხვა მეთოდებს, რათა შეცვალოთ სხვადასხვა ვარიანტები, რომლებიც დაკავშირებულია ფორმატირებასთან.
/// მაგალითებისთვის, იხილეთ ქვემოთ მოცემული `Formatter` მითითებული მეთოდების დოკუმენტაცია.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// არგუმენტი არსებითად ოპტიმიზირებულია ნაწილობრივ გამოყენებული ფორმატირების ფუნქციით, ექვივალენტურია `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// ეს სტრუქტურა წარმოადგენს ზოგად "argument"-ს, რომელსაც იღებს Xprintf ფუნქციების ოჯახი.იგი შეიცავს ფუნქციას მოცემული მნიშვნელობის ფორმატისთვის.
/// შედგენის დროს დარწმუნებულია, რომ ფუნქციასა და მნიშვნელობას აქვს სწორი ტიპები, შემდეგ კი ეს სტრუქტურა გამოიყენება არგუმენტების კანონიზირებისთვის ერთ ტიპზე.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// ეს უზრუნველყოფს ერთიანი სტაბილური მნიშვნელობას ფორმატირების ინფრასტრუქტურაში indices/counts-სთან ასოცირებული ფუნქციის მაჩვენებლისთვის.
//
// გაითვალისწინეთ, რომ ასეთად განსაზღვრული ფუნქცია არ იქნება სწორი, რადგან ფუნქციები ყოველთვის იწერება unnamed_addr და მიმდინარეობს LLVM IR- მდე, ამიტომ მათი მისამართი LLVM- სთვის მნიშვნელოვნად არ არის მიჩნეული და როგორც asusus cast შეიძლება არასწორად იყოს შედგენილი.
//
// პრაქტიკაში, ჩვენ არასდროს მოვუწოდებთ as_usize მონაცემებს, რომლებიც არ იყენებენ მონაცემებს (როგორც ფორმატირების არგუმენტების სტატიკური წარმოქმნა), ამიტომ ეს მხოლოდ დამატებითი შემოწმებაა.
//
// ჩვენ, პირველ რიგში, გვინდა დავრწმუნდეთ, რომ `USIZE_MARKER` ფუნქციის მაჩვენებელს აქვს მისამართი *მხოლოდ* იმ ფუნქციებთან, რომლებიც `&usize`-ს პირველ არგუმენტად მიიღებს.
// Read_volatile აქ უზრუნველყოფს, რომ ჩვენ შეგვიძლია უსაფრთხოდ მოვამზადოთ მიღებული მონაცემები მიღებული მითითებიდან და რომ ეს მისამართი არ მიუთითებს არაგამოყენების მიღების ფუნქციაზე.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // უსაფრთხოება: ptr არის მითითება
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // უსაფრთხოება: `mem::transmute(x)` უსაფრთხოა, რადგან
        //     1. `&'b T` ინახავს სიცოცხლის ხანგრძლივობას `'b`- ით (ისე, რომ არ ჰქონდეს უსაზღვრო სიცოცხლე)
        //     2.
        //     `&'b T` და `&'b Opaque` მეხსიერების ერთნაირი განლაგება აქვთ (როდესაც `T` არის `Sized`, როგორც აქ არის) `mem::transmute(f)` უსაფრთხოა, რადგან `fn(&T, &mut Formatter<'_>) -> Result` და `fn(&Opaque, &mut Formatter<'_>) -> Result` აქვს იგივე ABI (რადგან `T` არის `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // უსაფრთხოება: `formatter` ველი მხოლოდ დაყენებულია USIZE_MARKER, თუ
            // მნიშვნელობა არის გამოყენება, ასე რომ ეს უსაფრთხოა
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// დროშები ხელმისაწვდომია format_args-ის v1 ფორმატში
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Format_args! () მაკროს გამოყენებისას, ეს ფუნქცია გამოიყენება არგუმენტების სტრუქტურის შესაქმნელად.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// ეს ფუნქცია გამოიყენება არასტანდარტული ფორმატირების პარამეტრების დასაზუსტებლად.
    /// `pieces` მასივი უნდა იყოს არანაკლებ `fmt` გრძელი, რომ შეიქმნას სწორი არგუმენტების სტრუქტურა.
    /// ასევე, ნებისმიერი `Count` `fmt`-ის ფარგლებში, რომელიც არის `CountIsParam` ან `CountIsNextParam`, უნდა მიუთითოს `argumentusize`-ით შექმნილი არგუმენტი.
    ///
    /// ამასთან, ამის შეუსრულებლობა არ იწვევს უსაფრთხოებას, მაგრამ უგულებელყოფს ძალას.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// აფასებს ფორმატირებული ტექსტის სიგრძეს.
    ///
    /// ეს მიზნად ისახავს გამოიყენოს `String` თავდაპირველი სიმძლავრის დასაყენებლად.
    /// Note: ეს არც ქვედა და არც ზედა საზღვარი არ არის.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // თუ ფორმატის სტრიქონი არგუმენტით იწყება, ნუ გამოყოფთ ნურაფერს, გარდა იმ შემთხვევისა, როდესაც ცალი სიგრძეა მნიშვნელოვანი.
            //
            //
            0
        } else {
            // არსებობს რამდენიმე არგუმენტი, ამიტომ ნებისმიერი დამატებითი ბიძგი გადაანაწილებს სტრიქონს.
            //
            // ამის თავიდან ასაცილებლად, აქ "pre-doubling" შესაძლებლობები გვაქვს.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// ეს სტრუქტურა წარმოადგენს ფორმატის სტრიქონის და მისი არგუმენტების უსაფრთხოდ შედგენილი ვერსიას.
/// ამის გამომუშავება ვერ ხერხდება დროს, რადგან მისი უსაფრთხოდ გაკეთება შეუძლებელია, ამიტომ არ არის მოცემული კონსტრუქტორი, ხოლო ველები პირადია, რათა თავიდან აიცილოთ მოდიფიკაცია.
///
///
/// [`format_args!`] მაკრო უსაფრთხოდ შექმნის ამ სტრუქტურის მაგალითს.
/// მაკრო ამოწმებს ფორმატის სტრიქონს შედგენის დროს, ასე რომ, უსაფრთხოდ შეიძლება შესრულდეს [`write()`] და [`format()`] ფუნქციების გამოყენება.
///
/// შეგიძლიათ გამოიყენოთ `Arguments<'a>`, რომ [`format_args!`] დააბრუნებს `Debug` და `Display` კონტექსტებში, როგორც ეს ქვემოთ ჩანს.
/// მაგალითში ასევე ნაჩვენებია, რომ `Debug` და `Display` ფორმატში იგივეა: ინტერპოლირებული ფორმატის სტრიქონი `format_args!`-ში.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // სტრიქონის ნაჭრების ფორმატირება დასაბეჭდად.
    pieces: &'a [&'static str],

    // ადგილის შემცველის სპეციფიკაციები, ან `None`, თუ ყველა სპეციფიკაცია ნაგულისხმევია (როგორც "{}{}"- ში).
    fmt: Option<&'a [rt::v1::Argument]>,

    // დინამიური არგუმენტები ინტერპოლაციისთვის, რომელიც უნდა იქნეს აყვანილი სიმების ნაწილებით.
    // (ყველა არგუმენტს წინ უძღვის სტრიქონი.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// მიიღეთ ფორმატირებული სტრიქონი, თუ მას არ აქვს ფორმატირების არგუმენტები.
    ///
    /// ამის გამოყენება შესაძლებელია ყველაზე ტრივიალურ შემთხვევაში გამოყოფის თავიდან ასაცილებლად.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` უნდა დააფორმატოს გამომავალი პროგრამისტის წინაშე მყოფი, გამართვის კონტექსტში.
///
/// ზოგადად რომ ვთქვათ, თქვენ მხოლოდ `derive` უნდა გამოიყენოთ `Debug`.
///
/// როდესაც გამოიყენება ალტერნატიული ფორმატის მითითებით `#?`, გამომავალი საკმაოდ დაბეჭდილია.
///
/// ფორმატატორების შესახებ დამატებითი ინფორმაციისთვის იხილეთ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// ეს trait შეიძლება გამოყენებულ იქნას `#[derive]`- ით, თუ ყველა ველი ახორციელებს `Debug`- ს.
/// როდესაც სტრიქონებისთვის `წარმოიქმნება`, ის გამოიყენებს `struct`-ს სახელს, შემდეგ `{`-ს, შემდეგ მძიმით გამოყოფილ სიას თითოეული ველის სახელისა და `Debug` მნიშვნელობის, შემდეგ `}`.
/// `Enum` ის გამოიყენებს ვარიანტის სახელს და, საჭიროების შემთხვევაში, `(`, შემდეგ ველების `Debug` მნიშვნელობებს, შემდეგ `)`.
///
/// # Stability
///
/// მიღებული `Debug` ფორმატები არ არის სტაბილური და შეიძლება შეიცვალოს future Rust ვერსიებით.
/// გარდა ამისა, სტანდარტული ბიბლიოთეკის მიერ მოწოდებული ტიპის `Debug` განხორციელება (`libstd`, `libcore`, `liballoc` და ა.შ.) არ არის სტაბილური და შეიძლება შეიცვალოს future Rust ვერსიით.
///
///
/// # Examples
///
/// განხორციელების შედეგი:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// ხელით განხორციელება:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`Formatter`] სტრუქტურაზე არსებობს დამხმარე მრავალი მეთოდი, რომლებიც დაგეხმარებათ ხელით განხორციელებაში, მაგალითად [`debug_struct`].
///
/// `Debug` ან `derive` ან შეცდომების შემქმნელის API გამოყენებით [`Formatter`] განახორციელებს ალტერნატიული დროშის გამოყენებით საკმაოდ დაბეჭდვას: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// საკმაოდ დაბეჭდვა `#?`- ით:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// აყალიბებს მნიშვნელობას მოცემული ფორმატორის გამოყენებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// ცალკეული მოდული `Debug` მაკროდან prelude-დან trait `Debug` გარეშე.
pub(crate) mod macros {
    /// trait `Debug`-ის გავლენის წარმოქმნის მაკრო.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// ფორმატი trait ცარიელი ფორმატისთვის, `{}`.
///
/// `Display` [`Debug`] მსგავსია, მაგრამ `Display` მომხმარებლისთვის გამომავალია და ამიტომ მისი მიღება არ შეიძლება.
///
///
/// ფორმატატორების შესახებ დამატებითი ინფორმაციისთვის იხილეთ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `Display` ტიპის განხორციელება:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// აყალიბებს მნიშვნელობას მოცემული ფორმატორის გამოყენებით.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait- მა უნდა გამოაქვეყნოს თავისი გამომავალი, როგორც რიცხვი base-8- ში.
///
/// პრიმიტიული ხელმოწერილი მთელი რიცხვებისთვის (`i8`- დან `i128`- მდე და `isize`), უარყოფითი მნიშვნელობები ფორმატირებულია, როგორც ორივეს კომპლემენტის წარმოდგენა.
///
///
/// ალტერნატიული დროშა, `#`, დასძენს `0o` გამოსასვლელის წინ.
///
/// ფორმატატორების შესახებ დამატებითი ინფორმაციისთვის იხილეთ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ძირითადი გამოყენება `i32`- ით:
///
/// ```
/// let x = 42; // 42 არის '52' ოქტალში
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// `Octal` ტიპის განხორციელება:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // დელეგატი i32-ის განხორციელებაში
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// აყალიბებს მნიშვნელობას მოცემული ფორმატორის გამოყენებით.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait- მა უნდა გამოაქვეყნოს თავისი გამომავალი, როგორც რიცხვი ორობით.
///
/// პრიმიტიული ხელმოწერილი მთელი რიცხვებისთვის ([`i8`]- დან [`i128`]- მდე და [`isize`]), უარყოფითი მნიშვნელობები ფორმატირებულია, როგორც ორივეს კომპლემენტის წარმოდგენა.
///
///
/// ალტერნატიული დროშა, `#`, დასძენს `0b` გამოსასვლელის წინ.
///
/// ფორმატატორების შესახებ დამატებითი ინფორმაციისთვის იხილეთ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ძირითადი გამოყენება [`i32`]- ით:
///
/// ```
/// let x = 42; // 42 არის '101010' ორობითი
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// `Binary` ტიპის განხორციელება:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // დელეგატი i32-ის განხორციელებაში
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// აყალიბებს მნიშვნელობას მოცემული ფორმატორის გამოყენებით.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait- მა უნდა გამოაქვეყნოს თავისი გამომავალი, როგორც რიცხვი თექვსმეტობით, ხოლო მცირე ასოებით `a`- დან `f`- მდე.
///
/// პრიმიტიული ხელმოწერილი მთელი რიცხვებისთვის (`i8`- დან `i128`- მდე და `isize`), უარყოფითი მნიშვნელობები ფორმატირებულია, როგორც ორივეს კომპლემენტის წარმოდგენა.
///
///
/// ალტერნატიული დროშა, `#`, დასძენს `0x` გამოსასვლელის წინ.
///
/// ფორმატატორების შესახებ დამატებითი ინფორმაციისთვის იხილეთ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ძირითადი გამოყენება `i32`- ით:
///
/// ```
/// let x = 42; // 42 არის '2a' თექვსმეტი
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// `LowerHex` ტიპის განხორციელება:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // დელეგატი i32-ის განხორციელებაში
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// აყალიბებს მნიშვნელობას მოცემული ფორმატორის გამოყენებით.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait- მა უნდა გამოაქვეყნოს თავისი გამომავალი, როგორც რიცხვი თექვსმეტობით, ხოლო `A`- დან `F`- მდე დიდი ასოებით.
///
/// პრიმიტიული ხელმოწერილი მთელი რიცხვებისთვის (`i8`- დან `i128`- მდე და `isize`), უარყოფითი მნიშვნელობები ფორმატირებულია, როგორც ორივეს კომპლემენტის წარმოდგენა.
///
///
/// ალტერნატიული დროშა, `#`, დასძენს `0x` გამოსასვლელის წინ.
///
/// ფორმატატორების შესახებ დამატებითი ინფორმაციისთვის იხილეთ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ძირითადი გამოყენება `i32`- ით:
///
/// ```
/// let x = 42; // 42 არის '2A' თექვსმეტი
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// `UpperHex` ტიპის განხორციელება:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // დელეგატი i32-ის განხორციელებაში
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// აყალიბებს მნიშვნელობას მოცემული ფორმატორის გამოყენებით.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait- მა უნდა გამოაქვეყნოს თავისი გამომავალი, როგორც მეხსიერების ადგილმდებარეობა.
/// ეს ჩვეულებრივ წარმოდგენილია როგორც თექვსმეტობითი.
///
/// ფორმატატორების შესახებ დამატებითი ინფორმაციისთვის იხილეთ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ძირითადი გამოყენება `&i32`- ით:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // ეს აწარმოებს დაახლოებით '0x7f06092ac6d0'-ს
/// ```
///
/// `Pointer` ტიპის განხორციელება:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // გამოიყენეთ `as` `*const T`-ზე გადასაკეთებლად, რომელიც ახორციელებს Pointer-ს, რომლის გამოყენებაც შეგვიძლია
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// აყალიბებს მნიშვნელობას მოცემული ფორმატორის გამოყენებით.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait- მა უნდა გამოაქვეყნოს თავისი გამომავალი სამეცნიერო აღნიშვნით მცირე ზომის `e`- ით.
///
/// ფორმატატორების შესახებ დამატებითი ინფორმაციისთვის იხილეთ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ძირითადი გამოყენება `f64`- ით:
///
/// ```
/// let x = 42.0; // 42.0 არის '4.2e1' სამეცნიერო აღნიშვნებში
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// `LowerExp` ტიპის განხორციელება:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // დელეგატი f64- ის განხორციელებაში
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// აყალიბებს მნიშვნელობას მოცემული ფორმატორის გამოყენებით.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait- მა უნდა გამოაქვეყნოს თავისი გამომავალი სამეცნიერო აღნიშვნით დიდი ასო `E`- ით.
///
/// ფორმატატორების შესახებ დამატებითი ინფორმაციისთვის იხილეთ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ძირითადი გამოყენება `f64`- ით:
///
/// ```
/// let x = 42.0; // 42.0 არის '4.2E1' სამეცნიერო აღნიშვნებში
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// `UpperExp` ტიპის განხორციელება:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // დელეგატი f64- ის განხორციელებაში
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// აყალიბებს მნიშვნელობას მოცემული ფორმატორის გამოყენებით.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` ფუნქცია იღებს გამომავალ ნაკადს და `Arguments` სტრუქტურას, რომელიც შეიძლება წინასწარ შედგეს `format_args!` მაკროსთან.
///
///
/// არგუმენტები გაფორმდება მითითებული ფორმატის სტრიქონის შესაბამისად, მოცემულ გამომავალ ნაკადში.
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// გთხოვთ გაითვალისწინოთ, რომ სასურველია [`write!`]- ის გამოყენება.მაგალითი:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // ჩვენ შეგვიძლია გამოვიყენოთ სტანდარტული ფორმატირების პარამეტრები ყველა არგუმენტისთვის.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // ყველა სპექტრს აქვს შესაბამისი არგუმენტი, რომელსაც წინ უძღვის სიმებიანი ნაჭერი.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // უსაფრთხოება: arg და args.args მოდის იგივე არგუმენტებიდან,
                // რაც უზრუნველყოფს ინდექსების ყოველთვის ჩარჩოებს.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // შეიძლება დარჩეს მხოლოდ ერთი უკანა სტრიქონი.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // უსაფრთხოება: არგუმენტები და არგენტები მოდის იგივე არგუმენტებიდან,
    // რაც უზრუნველყოფს ინდექსების ყოველთვის ჩარჩოებს.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // გამოიტანეთ სწორი არგუმენტი
    debug_assert!(arg.position < args.len());
    // უსაფრთხოება: არგუმენტები და არგენტები მოდის იგივე არგუმენტებიდან,
    // რაც უზრუნველყოფს მის ინდექსს ყოველთვის არის საზღვრებში.
    let value = unsafe { args.get_unchecked(arg.position) };

    // შემდეგ რეალურად დაბეჭდეთ
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // უსაფრთხოება: cnt და args მოდის იგივე არგუმენტებიდან,
            // რაც უზრუნველყოფს ამ ინდექსს ყოველთვის არის საზღვრებში.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// რაიმეს დასრულების შემდეგ შევსება.დაბრუნდა `Formatter::padding`-ით.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// დაწერეთ ამ პოსტის შევსება.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // ჩვენ გვინდა ეს შევცვალოთ
            buf: wrap(self.buf),

            // და შეინარჩუნე ეს
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // დამხმარე მეთოდები, რომლებიც გამოიყენება არგუმენტების ფორმატის დასაფარად და დამუშავებისთვის, რომელთა გამოყენება შეუძლია ყველა ფორმატირებულ traits-ს.
    //

    /// ასრულებს სწორ შევსებას მთელი რიცხვისთვის, რომელიც უკვე გამოვიდა სტრიქონში.
    /// სტრიქონი * არ უნდა შეიცავდეს ნიშანს მთელი რიცხვისთვის, რომელიც დაემატება ამ მეთოდით.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, იყო თუ არა ორიგინალი მთელი რიცხვი დადებითი ან ნულოვანი.
    /// * პრეფიქსი, თუ მოცემულია '#' სიმბოლო (Alternate), ეს არის პრეფიქსი, რომელსაც რიცხვის წინაშე დააყენებთ.
    ///
    /// * buf, ბაიტის მასივი, რომელშიც ნომერი ფორმატირებულია
    ///
    /// ეს ფუნქცია სწორად გაითვალისწინებს მოცემულ დროშებსა და მინიმალურ სიგანეს.
    /// ეს არ გაითვალისწინებს სიზუსტეს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // ჩვენ უნდა ამოვიღოთ "-" რიცხვიდან.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // წერს ნიშანს, თუ ის არსებობს, შემდეგ კი პრეფიქსს, თუ იგი მოითხოვა
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // `width` ველი ამ ეტაპზე უფრო `min-width` პარამეტრია.
        match self.width {
            // თუ არ არსებობს მინიმალური სიგრძის მოთხოვნები, ჩვენ შეგვიძლია უბრალოდ დავწეროთ ბაიტები.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // შეამოწმეთ, მინიმალური სიგანეზე მეტი გვაქვს თუ არა, მაშინ შეგვიძლია უბრალოდ ბაიტები დავწეროთ.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // ნიშანი და პრეფიქსი მიდის შევსებამდე, თუ შევსების ხასიათი ნულოვანია
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // წინააღმდეგ შემთხვევაში, ნიშანი და პრეფიქსი მიდის შევსების შემდეგ
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// ეს ფუნქცია იღებს სტრიქონის ნაჭერს და გადასცემს მას შიდა ბუფერულს, მითითებული ფორმატირების შესაბამისი დროშების გამოყენების შემდეგ.
    /// ზოგადი სტრიქონებისთვის აღიარებული დროშებია:
    ///
    /// * სიგანე, მინიმალური სიგანე, თუ რა უნდა გამოყოს
    /// * fill/align - რა უნდა გამოვიდეს და სად უნდა გამოვიდეს, თუ მითითებული სტრიქონის შევსება უნდა
    /// * სიზუსტე, მაქსიმალური გამოსასვლელი სიგრძე, სტრიქონი იჭრება, თუ იგი ამ სიგრძეზე გრძელია
    ///
    /// აღსანიშნავია, რომ ეს ფუნქცია უგულებელყოფს `flag` პარამეტრებს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // დარწმუნდით, რომ წინ სწრაფი გზაა
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` ველი შეიძლება ინტერპრეტირებული იყოს, როგორც `max-width` ფორმატირებული სტრიქონისთვის.
        //
        let s = if let Some(max) = self.precision {
            // თუ ჩვენი სტრიქონი უფრო გრძელია ვიდრე სიზუსტე, მაშინ უნდა გვქონდეს შემცირება.
            // ამასთან, სხვა დროშები, როგორიცაა `fill`, `width` და `align`, უნდა მოქმედებდეს როგორც ყოველთვის.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // აქ LLVM ვერ დაამტკიცებს, რომ `..i` არ panic `&s[..i]`, მაგრამ ჩვენ ვიცით, რომ მას არ შეუძლია panic.
                // გამოიყენეთ `get` + `unwrap_or`, რომ თავიდან აიცილოთ `unsafe` და წინააღმდეგ შემთხვევაში აქ არ გამოაქვეყნოთ panic დაკავშირებული კოდი.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // `width` ველი ამ ეტაპზე უფრო `min-width` პარამეტრია.
        match self.width {
            // თუ ჩვენ მაქსიმალური სიგრძის ქვეშ ვართ და მინიმალური სიგრძის მოთხოვნები არ არსებობს, მაშინ ჩვენ შეგვიძლია უბრალოდ გამოვყოთ სტრიქონი
            //
            None => self.buf.write_str(s),
            // თუ ჩვენ მაქსიმალური სიგანე გვაქვს, შეამოწმეთ მინიმალური სიგანეზე მეტია, თუ ეს ასე მარტივია, როგორც უბრალოდ სტრიქონის გამოცემა.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // თუ ჩვენ მაქსიმალური და მინიმალური სიგანე გვაქვს, შეავსეთ მინიმალური სიგანე მითითებული სტრიქონით + რამდენიმე გასწორება.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// დაწერეთ წინასწარი შევსება და დააბრუნეთ დაუწერელი პოსტ - შევსება.
    /// აბონენტები პასუხისმგებელნი არიან იმაზე, რომ შევსების შემდეგ იწერება საგნის შევსების შემდეგ.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// იღებს ფორმატირებულ ნაწილებს და იყენებს შევსებას.
    /// მიიჩნევს, რომ აბონენტმა უკვე გააკეთა ნაწილები საჭირო სიზუსტით, ისე, რომ `self.precision` იგნორირებული იყოს.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // ნიშნისთვის ცნობილი ნულოვანი საცავისთვის, ჩვენ პირველ რიგში გავაკეთებთ ნიშანს და ისე ვიქცევით, თითქოს თავიდანვე ნიშანი არ გვქონდა.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ნიშანი ყოველთვის პირველია
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // ამოიღეთ ნიშანი ფორმატირებული ნაწილებიდან
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // დარჩენილი ნაწილები ჩვეულებრივი შევსების პროცესს გადიან.
            let len = formatted.len();
            let ret = if width <= len {
                // არ ივსება
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // ეს ჩვეულებრივი შემთხვევაა და მალსახმობას ვიღებთ
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // უსაფრთხოება: ეს გამოიყენება `flt2dec::Part::Num` და `flt2dec::Part::Copy`.
            // უსაფრთხოა მისი გამოყენება `flt2dec::Part::Num`-სთვის, რადგან ყველა ნახშირბადის `c` არის `b'0'` და `b'9'` შორის, რაც ნიშნავს, რომ `s` მოქმედებს UTF-8.
            // ეს ასევე ალბათ უსაფრთხოა პრაქტიკაში `flt2dec::Part::Copy(buf)`- ისთვის, რადგან `buf` უნდა იყოს უბრალო ASCII, მაგრამ შესაძლებელია ვინმეს გადასცდეს `buf`- ის ცუდი მნიშვნელობა `flt2dec::to_shortest_str`- ში, რადგან ეს არის საჯარო ფუნქცია.
            //
            // FIXME: დაადგინეთ, შეიძლება თუ არა ამან გამოიწვიოს UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 ნული
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// წერს გარკვეულ მონაცემებს ამ ფორმატორში მოთავსებული ძირითადი ბუფერისთვის.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // ეს ექვივალენტურია:
    ///         // დაწერე! (ფორმატი, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// წერს გარკვეულ ფორმატირებულ ინფორმაციას ამ ინსტანციაში.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// დროშები ფორმატისთვის
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// სიმბოლო გამოიყენება როგორც 'fill', როდესაც გასწორება ხდება.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // ჩვენ დავაყენეთ სწორება მარჯვნივ ">"-ით.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// დროშა მიუთითებს, თუ რა ფორმის გასწორება იყო მოთხოვნილი.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// სურვილისამებრ მითითებულია მთელი სიგანის სიგანე, რომელიც უნდა იყოს გამომავალი.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // თუ სიგანე მივიღეთ, მას ვიყენებთ
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // წინააღმდეგ შემთხვევაში ჩვენ განსაკუთრებულს არაფერს ვაკეთებთ
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// ნებაყოფლობითი სიზუსტით რიცხვითი ტიპებისთვის.
    /// გარდა ამისა, სიმების ტიპების მაქსიმალური სიგანე.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // თუ სიზუსტე მივიღეთ, მას ვიყენებთ.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // წინააღმდეგ შემთხვევაში, ჩვენ ვაყენებთ 2-ს.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// განსაზღვრავს იყო მითითებული `+` დროშა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// განსაზღვრავს მითითებული იყო თუ არა `-` დროშა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // მინუს ნიშანი გსურთ?Მიირთვი!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// განსაზღვრავს მითითებული იყო თუ არა `#` დროშა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// განსაზღვრავს მითითებული იყო თუ არა `0` დროშა.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // ჩვენ უგულებელვყოფთ ფორმატორის პარამეტრებს.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: გადაწყვიტეთ, რომელი საჯარო API გვინდა ამ ორი დროშისთვის.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// ქმნის [`DebugStruct`] კონსტრუქტორს, რომელიც შექმნილია ჩარჩოებისთვის [`fmt::Debug`] რეალიზებების შექმნაში.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// ქმნის `DebugTuple` კონსტრუქტორს, რომელიც შექმნილია იმისათვის, რომ დაეხმაროს `fmt::Debug` დანერგვის შექმნას სამკუთხედისთვის.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// ქმნის `DebugList` შემქმნელს, რომელიც შექმნილია სიის მსგავსი სტრუქტურების `fmt::Debug` დანერგვების შექმნაში.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// ქმნის `DebugSet` შემქმნელს, რომელიც შექმნილია დასახმარებლად მსგავსი სტრუქტურებისთვის `fmt::Debug` დანერგვების შექმნაში.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// ამ უფრო რთულ მაგალითში, ჩვენ ვიყენებთ [`format_args!`] და `.debug_set()` შესატყვისი მკლავების სიის შესაქმნელად:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// ქმნის `DebugMap` შემქმნელს, რომელიც დაეხმარება `fmt::Debug` განხორციელების შექმნას რუკის მსგავსი სტრუქტურებისთვის.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// traits ძირითადი ფორმატირების განხორციელება

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // თუ ჩარტს გაქცევა სჭირდება, გადატვირთეთ აქამდე და დაწერეთ, სხვაგან გამოტოვეთ
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // ალტერნატიული დროშა LowerHex- ს უკვე განიხილავს, როგორც სპეციალურს-ის ნიშნავს თუ არა პრეფიქსი 0x- ით.
        // ჩვენ ვიყენებთ მას ნულოვანი მასშტაბის გაფართოების დასადგენად, შემდეგ კი უპირობოდ ვაყენებთ მას პრეფიქსით.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Display/Debug- ის განხორციელება სხვადასხვა ძირითადი ტიპისთვის

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell ურთიერთდახმარებით არის ნასესხები, ამიტომ მის ღირებულებას აქ ვერ ვხედავთ.
                // სამაგიეროდ აჩვენეთ ჩანაცვლების ველი
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// თუ ტესტები აქ იქნებოდა, გადახედეთ core/tests/fmt.rs ფაილს, ეს ბევრად უფრო ადვილია, ვიდრე აქ ყველა rt::Piece სტრუქტურის შექმნა.
//
// ასევე არსებობს ტესტები გამოყოფის crate-ში, მათთვის, ვისაც გამოყოფა სჭირდება.