//! ეს არის შიდა მოდული, რომელსაც იყენებს ifmt!დროეს სტრუქტურები გამოიყოფა სტატიკურ მასივებზე, რათა დროზე ადრე შეადგინონ ფორმატის სტრიქონები.
//!
//! ეს განმარტებები მსგავსია მათი `ct` ეკვივალენტებისა, მაგრამ განსხვავდება იმით, რომ ეს შეიძლება იყოს სტატიკურად გამოყოფილი და ოდნავ ოპტიმიზირებულია ხანგრძლივობისთვის
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// შესაძლო გასწორებები, რომელთა მოთხოვნა შესაძლებელია ფორმატის დირექტივის ნაწილად.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// მითითება, რომ შინაარსი გასწორებული უნდა იყოს მარცხნივ.
    Left,
    /// მითითება, რომ შინაარსი უნდა იყოს სწორხაზოვანი.
    Right,
    /// მითითება, რომ შინაარსი უნდა იყოს გასწორებული ცენტრში.
    Center,
    /// გასწორება არ მოითხოვა.
    Unknown,
}

/// გამოიყენება [width](https://doc.rust-lang.org/std/fmt/#width) და [precision](https://doc.rust-lang.org/std/fmt/#precision) სპეციფიკატორების მიერ.
#[derive(Copy, Clone)]
pub enum Count {
    /// მითითებულია პირდაპირი მნიშვნელობით, ინახავს მნიშვნელობას
    Is(usize),
    /// მითითებულია `$` და `*` სინტაქსების გამოყენებით, ინახავს ინდექსს `args`-ში
    Param(usize),
    /// Მითითებული არ არის
    Implied,
}