//! `Clone` trait იმ ტიპებისთვის, რომელთა "შეძენილი კოპირება" შეუძლებელია.
//!
//! Rust- ში, ზოგიერთი მარტივი ტიპია "implicitly copyable" და როდესაც მათ მიანიჭებთ ან არგუმენტად გადასცემთ, მიმღები მიიღებს ასლს და დატოვებს თავდაპირველ მნიშვნელობას.
//! ამ ტიპებს არ სჭირდებათ გამოყოფა კოპირებისთვის და არ აქვთ დამამთავრებელი საშუალებები (მაგ., ისინი არ შეიცავს საკუთრივ ყუთებს ან ახორციელებენ [`Drop`]- ს), ამიტომ შემდგენელი მიიჩნევს მათ იაფი და უსაფრთხო კოპირებისთვის.
//!
//! სხვა ტიპის ასლები უნდა გაკეთდეს მკაფიოდ, [`Clone`] trait-ის კონვენციის გამოყენებით და [`clone`] მეთოდის გამოძახებით.
//!
//! [`clone`]: Clone::clone
//!
//! ძირითადი გამოყენების მაგალითი:
//!
//! ```
//! let s = String::new(); // სიმების ტიპი ახორციელებს Clone-ს
//! let copy = s.clone(); // ასე რომ, ჩვენ შეგვიძლია მისი კლონირება
//! ```
//!
//! Clone trait მარტივად განსახორციელებლად, ასევე შეგიძლიათ გამოიყენოთ `#[derive(Clone)]`.მაგალითი:
//!
//! ```
//! #[derive(Clone)] // ჩვენ ვუმატებთ Clone trait-ს მორფეუსის სტრუქტურას
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // და ახლა ჩვენ შეგვიძლია მისი კლონირება!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// ჩვეულებრივი trait ობიექტის მკაფიოდ დუბლირების შესაძლებლობისთვის.
///
/// [`Copy`]- ისგან განსხვავებით [`Copy`] არის აშკარა და ძალიან იაფი, ხოლო `Clone` ყოველთვის მკაფიოა და შეიძლება ძვირი იყოს ან არ იყოს ძვირი.
/// ამ მახასიათებლების აღსრულების მიზნით, Rust არ გაძლევთ [`Copy`]-ის ხელახლა განხორციელების საშუალებას, მაგრამ შეიძლება `Clone`-ის ხელახლა შესრულება და თვითნებური კოდის გაშვება.
///
/// ვინაიდან `Clone` უფრო ზოგადია ვიდრე [`Copy`], თქვენ ავტომატურად შეგიძლიათ გააკეთოთ ნებისმიერი [`Copy`] `Clone`.
///
/// ## Derivable
///
/// ეს trait შეიძლება გამოყენებულ იქნას `#[derive]`- ით, თუ ყველა ველია `Clone`.[`Clone`]- ის `გამომდინარე` დ დანერგვა [`clone`]-ს უწოდებს თითოეულ ველს.
///
/// [`clone`]: Clone::clone
///
/// ზოგადი სტრუქტურისთვის, `#[derive]` ახორციელებს `Clone`-ს პირობითად და დაამატებს შეკრული `Clone` ზოგად პარამეტრებს.
///
/// ```
/// // `derive` ახორციელებს Clone for Reading-ს<T>როდესაც T არის კლონი.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## როგორ შემიძლია განვახორციელო `Clone`?
///
/// [`Copy`] ტიპის ტიპებს უნდა ჰქონდეთ ტრივიალური `Clone` განხორციელება.უფრო ფორმალურად:
/// თუ `T: Copy`, `x: T` და `y: &T`, მაშინ `let x = y.clone();` ექვივალენტურია `let x = *y;`.
/// სახელმძღვანელო განხორციელება უნდა იყოს ფრთხილად, რომ ეს უცვლელი იყოს;ამასთან, საშიში კოდი მას არ უნდა დაეყრდნოს მეხსიერების უსაფრთხოების უზრუნველსაყოფად.
///
/// მაგალითად, არის ზოგადი სტრუქტურა, რომელიც შეიცავს ფუნქციის მაჩვენებელს.ამ შემთხვევაში, `Clone`- ის დანერგვა არ შეიძლება "გამომდინარე იქნეს", მაგრამ შეიძლება განხორციელდეს შემდეგნაირად:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## დამატებითი განმახორციელებლები
///
/// [implementors listed below][impls]-ის გარდა, შემდეგი ტიპები ასევე ახორციელებენ `Clone`-ს:
///
/// * ფუნქციის ელემენტის ტიპები (ე.ი. თითოეული ფუნქციისთვის განსაზღვრული მკაფიო ტიპები)
/// * ფუნქციის მაჩვენებლის ტიპები (მაგ., `fn() -> i32`)
/// * მასივის ტიპები, ყველა ზომისთვის, თუ საქონლის ტიპი ასევე ახორციელებს `Clone`-ს (მაგ., `[i32; 123456]`)
/// * მრავალრიცხოვანი ტიპები, თუ თითოეული კომპონენტი ასევე ახორციელებს `Clone`-ს (მაგ., `()`, `(i32, bool)`)
/// * დახურვის ტიპები, თუ ისინი არავითარ მნიშვნელობას არ იპყრობენ გარემოდან ან თუ ყველა ასეთი აღებული მნიშვნელობები თავად ახორციელებს `Clone`-ს.
///   გაითვალისწინეთ, რომ საერთო ცნობის მიერ აღბეჭდილი ცვლადები ყოველთვის ახორციელებენ `Clone`-ს (მაშინაც კი, თუ რეფერენტი არ იყენებს), ხოლო ცვლადი ცნობის მიერ აღებული ცვლადები არასდროს ახორციელებენ `Clone`-ს.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// აბრუნებს მნიშვნელობის ასლს.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ახორციელებს კლონს
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// ასრულებს ასლის დავალებას `source`- დან.
    ///
    /// `a.clone_from(&b)` ფუნქციონალურია `a = b.clone()`- ის ეკვივალენტურია, მაგრამ მისი გადალახვა შესაძლებელია `a`- ის რესურსების ხელახლა გამოყენებისთვის, რათა თავიდან იქნას აცილებული ზედმეტი განაწილებები.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone`-ის გავლენის წარმოქმნის მაკრო.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ამ სტრიქონებს იყენებს მხოლოდ#[derive] იმის დასადასტურებლად, რომ ტიპის ყველა კომპონენტი ახორციელებს Clone ან Copy.
//
//
// ეს სტრიქონები არასდროს უნდა გამოჩნდეს მომხმარებლის კოდში.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Clone`- ის დანერგვები პრიმიტიული ტიპებისთვის.
///
/// იმპლემენტაციები, რომელთა აღწერა არ შეიძლება Rust- ში, ხორციელდება `traits::SelectionContext::copy_clone_conditions()`- ში `rustc_trait_selection`- ში.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// შეიძლება გაზიარებული ცნობების კლონირება მოხდეს, მაგრამ ცვლადი ცნობების * ** შეუძლებელია!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// შეიძლება გაზიარებული ცნობების კლონირება მოხდეს, მაგრამ ცვლადი ცნობების * ** შეუძლებელია!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}