#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! შეიცავს სტრუქტურულ განმარტებებს შემდგენლის ჩამონტაჟებული ტიპების განლაგებისათვის.
//!
//! ისინი შეიძლება გამოყენებულ იქნეს ტრანსუტატების სამიზნეებად არაუსაფრთხო კოდში ნედლი წარმოდგენების პირდაპირ მანიპულირებისთვის.
//!
//!
//! მათი განმარტება ყოველთვის უნდა ემთხვეოდეს `rustc_middle::ty::layout`-ით განსაზღვრულ ABI-ს.
//!

/// `&dyn SomeTrait`-ის მსგავსი trait ობიექტის წარმოდგენა.
///
/// ამ სტრუქტურას აქვს იგივე განლაგება, როგორც ტიპები, როგორიცაა `&dyn SomeTrait` და `Box<dyn AnotherTrait>`.
///
/// `TraitObject` გარანტირებულია, რომ ემთხვევა განლაგებებს, მაგრამ ეს არ არის trait ობიექტის ტიპი (მაგ., ველები არ არის პირდაპირ ხელმისაწვდომი `&dyn SomeTrait`- ზე) და არც ის აკონტროლებს ამ განლაგებას (დეფინიციის შეცვლა არ შეცვლის `&dyn SomeTrait`- ის განლაგებას).
///
/// იგი შექმნილია მხოლოდ სახიფათო კოდის მიერ გამოსაყენებლად, რომელიც საჭიროებს დაბალი დონის დეტალების მანიპულირებას.
///
/// არ არსებობს გზა trait ობიექტის ზოგადად მოხსენიების მეთოდი, ამიტომ ამ ტიპის მნიშვნელობების შექმნის ერთადერთი გზაა ისეთი ფუნქციები, როგორიცაა [`std::mem::transmute`][transmute].
/// ანალოგიურად, `TraitObject` მნიშვნელობიდან ნამდვილი trait ობიექტის შექმნის ერთადერთი გზაა `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// trait ობიექტის სინთეზირება შეუსაბამო ტიპებით-ის, სადაც vtable არ შეესაბამება იმ მნიშვნელობის ტიპს, რომელზეც მიუთითებს მონაცემთა მაჩვენებელი, ძალიან იწვევს გაურკვეველ ქცევას.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // მაგალითი trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // შეადგინეთ შემდგენელმა trait ობიექტი
/// let object: &dyn Foo = &value;
///
/// // გადახედეთ ნედლეულ წარმომადგენლობას
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // მონაცემთა მაჩვენებელი არის `value` მისამართი
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // ააშენეთ ახალი ობიექტი, რომელიც მიუთითებს სხვა `i32`- ზე, ფრთხილად იყენებთ `i32`- ს Xtax- ის Vtable- ს
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ეს უნდა იმუშაოს ისე, თითქოს ჩვენ trait ობიექტი ავაშენეთ უშუალოდ `other_value`- დან
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}