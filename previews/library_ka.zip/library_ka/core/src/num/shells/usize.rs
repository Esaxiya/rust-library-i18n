//! მუდმივი მაჩვენებლის ზომის ხელმოუწერელი მთელი რიცხვის ტიპისთვის.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! ახალ კოდში უნდა იყოს გამოყენებული ასოცირებული მუდმივები პირდაპირ პრიმიტიულ ტიპზე.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }