//! შეცდომის ტიპები ინტეგრალურ ტიპებზე გადასასვლელად.

use crate::convert::Infallible;
use crate::fmt;

/// შეცდომის ტიპი დაბრუნდა, როდესაც შემოწმებული ინტეგრალური ტიპის გარდაქმნა ვერ ხერხდება.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // თანხვედრა და არა იძულებითი დავრწმუნდეთ, რომ კოდი, როგორიცაა `From<Infallible> for TryFromIntError`, გააგრძელებს მუშაობას, როდესაც `Infallible` გახდება მეტსახელად `!`.
        //
        //
        match never {}
    }
}

/// შეცდომა, რომლის დაბრუნებაც შეიძლება მთელი რიცხვის ანალიზისას.
///
/// ეს შეცდომა გამოიყენება როგორც შეცდომის ტიპი `from_str_radix()` ფუნქციებისთვის პრიმიტიული მთელი რიცხვების ტიპებზე, მაგალითად [`i8::from_str_radix`].
///
/// # პოტენციური მიზეზები
///
/// სხვა მიზეზებთან ერთად, `ParseIntError` შეიძლება ჩააგდონ სტრიქონში არსებული თავისუფალი სივრცის წამყვანი ან უკან მიყოლებით, მაგალითად, როდესაც ის მიიღება სტანდარტული შეყვანიდან.
///
/// [`str::trim()`] მეთოდის გამოყენება უზრუნველყოფს, რომ გარჩევის დაწყებამდე თეთრი სივრცე არ დარჩება.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum შეინახეთ სხვადასხვა ტიპის შეცდომები, რამაც შეიძლება გამოიწვიოს მთელი რიცხვის გაანალიზება.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// ანალიზის ღირებულება ცარიელია.
    ///
    /// სხვა მიზეზებთან ერთად, ეს ვარიანტი შეიქმნება ცარიელი სტრიქონის ანალიზისას.
    Empty,
    /// თავის კონტექსტში შეიცავს არასწორ ციფრს.
    ///
    /// სხვა მიზეზებთან ერთად, ეს ვარიანტი შეიქმნება სტრიქონის ანალიზისას, რომელიც შეიცავს არა ASCII სიმბოლოს.
    ///
    /// ეს ვარიანტი ასევე აგებულია, როდესაც `+` ან `-` არასწორად არის განთავსებული სტრიქონში, როგორც საკუთარი, ისე რიცხვის შუაში.
    ///
    ///
    InvalidDigit,
    /// მთელი რიცხვი ძალიან დიდია სამიზნე მთელი ტიპის ტიპის შესანახად.
    PosOverflow,
    /// მთელი რიცხვი ძალიან მცირეა სამიზნე მთელი ტიპის ტიპის შესანახად.
    NegOverflow,
    /// მნიშვნელობა იყო ნული
    ///
    /// ეს ვარიანტი გამოიცემა, როდესაც სიმებიანი სტრიქონი ნულის ტოლია, რაც არალეული ტიპისთვის იქნება არალეგალური.
    ///
    Zero,
}

impl ParseIntError {
    /// გამოაქვს მთელი რიცხვის გაანალიზების დეტალური მიზეზი.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}