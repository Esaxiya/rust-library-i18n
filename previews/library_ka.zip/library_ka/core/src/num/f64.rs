//! `f64` ორმაგი სიზუსტით მცურავი წერტილის ტიპის დამახასიათებელი მუდმივები.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! მათემატიკურად მნიშვნელოვანი რიცხვები მოცემულია `consts` ქვემოდულში.
//!
//! უშუალოდ ამ მოდულში განსაზღვრული კონსტანტებისათვის (განსხვავებით `consts` ქვემოდულში მითითებული მათგან), ახალ კოდში უნდა გამოყენებულ იქნას ასოცირებული მუდმივები, რომლებიც განისაზღვრება უშუალოდ `f64` ტიპზე.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f64`-ის შიდა წარმომადგენლობის რადიქსი ან ფუძე.
/// მის ნაცვლად გამოიყენეთ [`f64::RADIX`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // განკუთვნილი გზა
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// მნიშვნელოვანი ციფრების რაოდენობა 2 ბაზაში.
/// მის ნაცვლად გამოიყენეთ [`f64::MANTISSA_DIGITS`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // განკუთვნილი გზა
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// მნიშვნელოვანი ციფრების მიახლოებითი რაოდენობა 10 ბაზაში.
/// მის ნაცვლად გამოიყენეთ [`f64::DIGITS`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // განკუთვნილი გზა
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] მნიშვნელობა `f64`.
/// მის ნაცვლად გამოიყენეთ [`f64::EPSILON`].
///
/// ეს არის განსხვავება `1.0`-სა და შემდეგ უფრო დიდ გამოსახულ რიცხვს შორის.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // განკუთვნილი გზა
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// მცირე სასრული `f64` მნიშვნელობა.
/// მის ნაცვლად გამოიყენეთ [`f64::MIN`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // განკუთვნილი გზა
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// ყველაზე მცირე დადებითი ნორმალური `f64` მნიშვნელობა.
/// მის ნაცვლად გამოიყენეთ [`f64::MIN_POSITIVE`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // განკუთვნილი გზა
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// უდიდესი სასრული `f64` მნიშვნელობა.
/// მის ნაცვლად გამოიყენეთ [`f64::MAX`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // განკუთვნილი გზა
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// მინიმალური შესაძლო ნორმალური სიმძლავრეზე მეტია 2 მაჩვენებელი.
/// მის ნაცვლად გამოიყენეთ [`f64::MIN_EXP`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // განკუთვნილი გზა
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// მაქსიმალური სიმძლავრე 2 ექსპონენტი.
/// მის ნაცვლად გამოიყენეთ [`f64::MAX_EXP`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // განკუთვნილი გზა
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// მინიმალური შესაძლო ნორმალური სიმძლავრეა 10 ექსპონენტი.
/// მის ნაცვლად გამოიყენეთ [`f64::MIN_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // განკუთვნილი გზა
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// მაქსიმალური სიმძლავრე 10 ექსპონენტი.
/// მის ნაცვლად გამოიყენეთ [`f64::MAX_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // განკუთვნილი გზა
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// არ არის ნომერი (NaN).
/// მის ნაცვლად გამოიყენეთ [`f64::NAN`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // განკუთვნილი გზა
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// მის ნაცვლად გამოიყენეთ [`f64::INFINITY`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // განკუთვნილი გზა
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// უარყოფითი უსასრულობა (−∞).
/// მის ნაცვლად გამოიყენეთ [`f64::NEG_INFINITY`].
///
/// # Examples
///
/// ```rust
/// // ამორტიზებული გზა
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // განკუთვნილი გზა
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// ძირითადი მათემატიკური მუდმივები.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: შეცვალეთ მათემატიკური მუდმივებით cmath- დან.

    /// არქიმედეს მუდმივი (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// სრული წრის მუდმივი (τ)
    ///
    /// ტოლია 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// ოილერის ნომერი (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// `f64`-ის შიდა წარმომადგენლობის რადიქსი ან ფუძე.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// მნიშვნელოვანი ციფრების რაოდენობა 2 ბაზაში.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// მნიშვნელოვანი ციფრების მიახლოებითი რაოდენობა 10 ბაზაში.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] მნიშვნელობა `f64`.
    ///
    /// ეს არის განსხვავება `1.0`-სა და შემდეგ უფრო დიდ გამოსახულ რიცხვს შორის.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// მცირე სასრული `f64` მნიშვნელობა.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// ყველაზე მცირე დადებითი ნორმალური `f64` მნიშვნელობა.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// უდიდესი სასრული `f64` მნიშვნელობა.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// მინიმალური შესაძლო ნორმალური სიმძლავრეზე მეტია 2 მაჩვენებელი.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// მაქსიმალური სიმძლავრე 2 ექსპონენტი.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// მინიმალური შესაძლო ნორმალური სიმძლავრეა 10 ექსპონენტი.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// მაქსიმალური სიმძლავრე 10 ექსპონენტი.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// არ არის ნომერი (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// უარყოფითი უსასრულობა (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// აბრუნებს `true`-ს, თუ ეს მნიშვნელობა არის `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` საჯაროდ მიუწვდომელია libcore-ში, პორტაბელურობის შესახებ შეშფოთების გამო, ამიტომ ეს პროგრამა შინაგანად კერძო გამოყენებისთვისაა.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// აბრუნებს `true` თუ ეს მნიშვნელობა არის დადებითი უსასრულობა ან უარყოფითი უსასრულობა, ხოლო `false` სხვაგვარად.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// აბრუნებს `true`-ს, თუ ეს რიცხვი არც უსასრულოა და არც `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // არ არის საჭირო NaN ცალკე მუშავება: თუ თვით NaN არის, შედარება არ არის ჭეშმარიტი, ზუსტად ისე, როგორც სასურველია.
        //
        self.abs_private() < Self::INFINITY
    }

    /// აბრუნებს `true` თუ ნომერი [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // `0` და `min` შორის მნიშვნელობები სუბნორმალურია.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// აბრუნებს `true` თუ ნომერი არც ნულოვანია, უსასრულო, [subnormal] ან `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // `0` და `min` შორის მნიშვნელობები სუბნორმალურია.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// აბრუნებს რიცხვის მცურავი წერტილის კატეგორიას.
    /// თუ მხოლოდ ერთი თვისების შემოწმებას აპირებს, ზოგადად უფრო სწრაფია კონკრეტული პრედიკატის გამოყენება.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// აბრუნებს `true`-ს, თუ `self`-ს აქვს დადებითი ნიშანი, მათ შორის `+0.0`, `NaN` პოზიტიური ნიშნის ბიტითა და დადებითი უსასრულობით.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// აბრუნებს `true`-ს, თუ `self`-ს აქვს უარყოფითი ნიშანი, მათ შორის `-0.0`, `NaN` უარყოფითი ნიშნის ბიტითა და უარყოფითი უსასრულობით.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// იღებს რიცხვის საპასუხო (inverse), `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// რადიანს გარდაქმნის გრადუსზე.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // დაყოფა სწორად არის მომრგვალებული 180/π ჭეშმარიტი მნიშვნელობის მიმართ.
        // (ეს განსხვავდება f32- ისგან, სადაც უნდა იქნას გამოყენებული მუდმივი, რათა უზრუნველყოს სწორად მომრგვალო შედეგი.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// გრადუსებს რადიანად გარდაქმნის.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// აბრუნებს ორი რიცხვის მაქსიმუმს.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// თუ ერთ-ერთი არგუმენტია NaN, მეორე არგუმენტი უბრუნდება.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// აბრუნებს ორი რიცხვის მინიმუმს.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// თუ ერთ-ერთი არგუმენტია NaN, მეორე არგუმენტი უბრუნდება.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// მრგვალდება ნულისკენ და გარდაიქმნება ნებისმიერი პრიმიტიული მთელი რიცხვის ტიპზე, თუ ჩავთვლით, რომ მნიშვნელობა სასრულია და შეესაბამება ამ ტიპს.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// მნიშვნელობა უნდა:
    ///
    /// * არ იყოს `NaN`
    /// * არ იყოს უსასრულო
    /// * წარმოადგენენ დაბრუნების ტიპს `Int`, მისი ფრაქციული ნაწილის შემცირების შემდეგ
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // უსაფრთხოება: აბონენტმა უნდა დაიცვას უსაფრთხოების კონტრაქტი `FloatToInt::to_int_unchecked`- სთვის.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// ნედლი ტრანსმუტაცია `u64`- ზე.
    ///
    /// ეს ამჟამად იდენტურია `transmute::<f64, u64>(self)`- ის ყველა პლატფორმაზე.
    ///
    /// იხილეთ `from_bits` ამ ოპერაციის პორტაბელურობის შესახებ ზოგიერთი განხილვისთვის (თითქმის არანაირი საკითხი არ არსებობს).
    ///
    /// გაითვალისწინეთ, რომ ეს ფუნქცია განსხვავდება `as` კასტინგისგან, რომელიც ცდილობს შეინარჩუნოს *რიცხვითი* მნიშვნელობა და არა ბიტიანი მნიშვნელობა.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() არ არის კასტინგი!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // უსაფრთხოება: `u64` არის ძველი ძველი მონაცემთა ტიპი, ასე რომ ჩვენ ყოველთვის შეგვიძლია გადავიდეთ მასში
        unsafe { mem::transmute(self) }
    }

    /// ნედლი ტრანსმუტაცია `u64`- დან.
    ///
    /// ეს ამჟამად იდენტურია `transmute::<u64, f64>(v)`- ის ყველა პლატფორმაზე.
    /// აღმოჩნდა, რომ ეს წარმოუდგენლად პორტატულია, ორი მიზეზის გამო:
    ///
    /// * Float- სა და Ints- ს აქვს იგივე endianness ყველა მხარდაჭერილ პლატფორმაზე.
    /// * IEEE-754 ზუსტად განსაზღვრავს floats-ის ბიტიან განლაგებას.
    ///
    /// ამასთან, არსებობს ერთი შენიშვნა: IEEE-754- ის 2008 წლის ვერსიამდე, NaN სასიგნალო ბიტის ინტერპრეტაცია რეალურად არ იყო მითითებული.
    /// პლატფორმების უმეტესობამ (განსაკუთრებით x86 და ARM) აირჩია ინტერპრეტაცია, რომელიც საბოლოოდ სტანდარტიზებული იქნა 2008 წელს, მაგრამ ზოგიერთმა არ გააკეთა ეს (განსაკუთრებით MIPS).
    /// შედეგად, ყველა სასიგნალო NaNs MIPS- ზე არის მშვიდი NaNs x86- ზე და პირიქით.
    ///
    /// იმის ნაცვლად, რომ ცდილობენ შეინარჩუნონ სიგნალიზაციის ჯვარი პლატფორმა, ეს განხორციელება ხელს უწყობს ზუსტი ბიტების შენარჩუნებას.
    /// ეს ნიშნავს, რომ NaN- ში დაშიფრული ნებისმიერი დატვირთვა დაცული იქნება მაშინაც კი, თუ ამ მეთოდის შედეგი ქსელში გაიგზავნება x86 აპარატიდან MIPS- ზე.
    ///
    ///
    /// თუ ამ მეთოდის შედეგები მანიპულირდება მხოლოდ იმავე არქიტექტურით, რამაც წარმოშვა ისინი, მაშინ პორტაბელურობის საკითხი არ არის.
    ///
    /// თუ შეყვანა NaN არ არის, მაშინ პორტაბელურობის პრობლემა არ არის.
    ///
    /// თუ თქვენ არ ზრუნავთ სიგნალზე სიზუსტეზე (ძალიან სავარაუდოა), მაშინ პორტაბელურობის პრობლემა არ არის.
    ///
    /// გაითვალისწინეთ, რომ ეს ფუნქცია განსხვავდება `as` კასტინგისგან, რომელიც ცდილობს შეინარჩუნოს *რიცხვითი* მნიშვნელობა და არა ბიტიანი მნიშვნელობა.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // უსაფრთხოება: `u64` არის ძველი ძველი მონაცემთა ტიპი, ასე რომ ჩვენ ყოველთვის შეგვიძლია გადავიდეთ მისგან
        // აღმოჩნდა, რომ უსაფრთხოების საკითხები sNaN- ს გადაჭარბებულია!უი!
        unsafe { mem::transmute(v) }
    }

    /// დააბრუნეთ ამ მცურავი წერტილის ნომრის მეხსიერების გამოსახვა, როგორც ბაიტის მასივი, დიდი endian (network) ბაიტის თანმიმდევრობით.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// დააბრუნეთ ამ მცურავი წერტილის ნომრის მეხსიერების გამოსახვა, როგორც ბაიტის მასივი, პატარა ენდიანური ბაიტის თანმიმდევრობით.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// დააბრუნეთ ამ მცურავი წერტილის ნომრის მეხსიერების გამოსახვა, როგორც ბაიტის მასივი, მშობლიურ ბაიტის თანმიმდევრობით.
    ///
    /// როგორც სამიზნე პლატფორმის ბუნებრივი ენდინალის გამოყენება, პორტატულ კოდში უნდა გამოყენებულ იქნას [`to_be_bytes`] ან [`to_le_bytes`], როგორც საჭიროა, ამის ნაცვლად.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// დააბრუნეთ ამ მცურავი წერტილის ნომრის მეხსიერების გამოსახვა, როგორც ბაიტის მასივი, მშობლიურ ბაიტის თანმიმდევრობით.
    ///
    ///
    /// [`to_ne_bytes`] ეს სასურველი უნდა იყოს მასზე, როცა ეს შესაძლებელია.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // უსაფრთხოება: `f64` არის ძველი ძველი მონაცემთა ტიპი, ასე რომ ჩვენ ყოველთვის შეგვიძლია შევცვალოთ იგი
        unsafe { &*(self as *const Self as *const _) }
    }

    /// შექმნათ მცურავი წერტილის მნიშვნელობა მისი წარმოდგენიდან, როგორც ბაიტის მასივი დიდ ენდშიანში.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// შექმნათ მცურავი წერტილის მნიშვნელობა მისი წარმოდგენიდან, როგორც ბაიტის მასივი პატარა ენდშიანში.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// შექმნათ მცურავი წერტილის მნიშვნელობა მისი წარმოდგენიდან, როგორც ბაიტის მასივი მშობლიურ ენდიანში.
    ///
    /// როგორც სამიზნე პლატფორმის ადგილობრივი endianness გამოიყენება, პორტატული კოდი, სავარაუდოდ, სურს გამოიყენოს [`from_be_bytes`] ან [`from_le_bytes`], როგორც შესაბამისი, ნაცვლად.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// აბრუნებს შეკვეთას თვითმმართველობასა და სხვა ღირებულებებს შორის.
    /// მცურავი წერტილის ციფრებს შორის სტანდარტული ნაწილობრივი შედარებისგან განსხვავებით, ეს შედარება ყოველთვის წარმოქმნის შეკვეთას ჯამური შეკვეთის მიხედვით, როგორც ეს განსაზღვრულია IEEE 754 (2008 წლის გადასინჯვა) მცურავი წერტილის სტანდარტში.
    /// მნიშვნელობები შეკვეთილია შემდეგი თანმიმდევრობით:
    /// - უარყოფითი მშვიდი NaN
    /// - ნეგატიური სიგნალი NaN
    /// - უარყოფითი უსასრულობა
    /// - უარყოფითი რიცხვები
    /// - ნეგატიური სუბნორმალური რიცხვები
    /// - უარყოფითი ნულოვანი
    /// - პოზიტიური ნულოვანი
    /// - პოზიტიური სუბნორმალური რიცხვები
    /// - პოზიტიური რიცხვები
    /// - პოზიტიური უსასრულობა
    /// - პოზიტიური სიგნალი NaN
    /// - პოზიტიური მშვიდი NaN
    ///
    /// გაითვალისწინეთ, რომ ეს ფუნქცია ყოველთვის არ ეთანხმება `f64`-ის [`PartialOrd`] და [`PartialEq`] განხორციელებას.კერძოდ, ისინი ნეგატიურ და დადებით ნულს თვლიან თანაბრად, ხოლო `total_cmp` არა.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // ნეგატივების შემთხვევაში, გადაატრიალეთ ყველა ბიტი, გარდა ნიშნისა, რომ მიიღოთ მსგავსი განლაგება, როგორც ორი კომპლიმენტის მთელი რიცხვი
        //
        // რატომ მუშაობს ეს?IEEE 754 მოძრავი შედგება სამი ველისგან:
        // ნიშანი bit, exponent და mantissa.მთლიანი ექსპონატისა და mantissa ველების ერთობლიობას აქვს თვისება, რომ მათი ბიტური რიგითობა ტოლია რიცხვითი სიდიდის, სადაც განისაზღვრება სიდიდე.
        // სიდიდე ჩვეულებრივ არ განისაზღვრება NaN მნიშვნელობებზე, მაგრამ IEEE 754 totalOrder განსაზღვრავს NaN მნიშვნელობებს ასევე ბიტური რიგის შესაბამისად.ეს იწვევს წესრიგის განმარტებას დოკუმენტის კომენტარში.
        // ამასთან, სიდიდის გამოსახულება იგივეა უარყოფითი და პოზიტიური რიცხვებისთვის-განსხვავებულია მხოლოდ ნიშნის ბიტი.
        // ათწილადი, როგორც ხელმოწერილი მთელი რიცხვების მარტივად შედარების მიზნით, უარყოფითი რიცხვების შემთხვევაში უნდა გადავაფაროთ ექსპონენტის და მანტისას ბიტი.
        // ჩვენ ეფექტურად ვაქცევთ ციფრებს "two's complement" ფორმაში.
        //
        // ფლიპინგის გასაკეთებლად, ჩვენ ვაშენებთ ნიღაბს და XOR მის წინააღმდეგ.
        // ჩვენ განუყოფლად გამოვთვლით "all-ones except for the sign bit" ნიღაბს უარყოფითი ხელმოწერილი მნიშვნელობებისაგან: მარჯვნივ გადატანილი ნიშანი აგრძელებს მთელ რიცხვს, ასე რომ, ჩვენ "fill" ნიღაბი გავაფორმებთ ნიშნის ბიტებით, შემდეგ კი გადავცემთ ხელმოუწერელს, რომ კიდევ ერთი ნულოვანი ბიტი დავიჭიროთ.
        //
        // პოზიტიურ მნიშვნელობებზე, ნიღაბი არის ყველა ნული, ასე რომ, ის არ არის op-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// შეზღუდეთ მნიშვნელობა გარკვეული ინტერვალით, თუ ის NaN არ არის.
    ///
    /// აბრუნებს `max` თუ `self` მეტია `max` და `min` თუ `self` ნაკლებია `min`.
    /// წინააღმდეგ შემთხვევაში, ეს უბრუნებს `self`-ს.
    ///
    /// გაითვალისწინეთ, რომ ეს ფუნქცია აბრუნებს NaN თუ საწყისი მნიშვნელობა იყო NaN.
    ///
    /// # Panics
    ///
    /// Panics თუ `min > max`, `min` არის NaN, ან `max` არის NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}