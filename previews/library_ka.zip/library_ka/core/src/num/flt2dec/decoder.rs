//! მოძრავი წერტილის მნიშვნელობის დეკოდირება ხდება ცალკეულ ნაწილებად და შეცდომების დიაპაზონში.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// გაშიფრული უსასრულო მნიშვნელობა, ისეთი, რომ:
///
/// - თავდაპირველი მნიშვნელობა უდრის `mant * 2^exp`.
///
/// - ნებისმიერი რიცხვი `(mant - minus)*2^exp`-დან `(mant + plus)* 2^exp`-მდე მრგვალდება თავდაპირველ მნიშვნელობამდე.
/// დიაპაზონი მოიცავს მხოლოდ მაშინ, როდესაც `inclusive` არის `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// მასშტაბური მანტისა.
    pub mant: u64,
    /// ქვედა შეცდომების დიაპაზონი.
    pub minus: u64,
    /// შეცდომების ზედა დიაპაზონი.
    pub plus: u64,
    /// გაზიარებული ექსპონატი 2 ბაზაში.
    pub exp: i16,
    /// მართალია, როდესაც შეცდომების დიაპაზონი მოიცავს.
    ///
    /// IEEE 754-ში ეს მართალია, როდესაც ორიგინალი მანტისა ლუწი იყო.
    pub inclusive: bool,
}

/// გაუშიფრავი მნიშვნელობა.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// უსასრულობა, დადებითი ან უარყოფითი.
    Infinite,
    /// ნულოვანი, ან დადებითი ან უარყოფითი.
    Zero,
    /// სასრული რიცხვები შემდგომი დეკოდირებული ველებით.
    Finite(Decoded),
}

/// მცურავი წერტილის ტიპი, რომელიც შეიძლება იყოს `დეკოდირება`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// მინიმალური დადებითი ნორმალიზებული მნიშვნელობა.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// აბრუნებს ნიშანს (მართალია, როდესაც უარყოფითი) და `FullDecoded` მნიშვნელობას მოცემული მცურავი წერტილის რიცხვიდან.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // მეზობლები: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode ყოველთვის ინარჩუნებს ექსპონენტს, ამიტომ mantissa მასშტაბურია subnormals-ისთვის.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // მეზობლები: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // სადაც maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // მეზობლები: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}