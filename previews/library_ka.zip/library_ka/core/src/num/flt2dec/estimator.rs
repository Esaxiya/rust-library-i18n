//! ექსპონენტის შემფასებელი.

/// პოულობს `k_0`-ს ისეთი, რომ `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// ეს გამოიყენება დაახლოებით `k = ceil(log_10 (mant * 2^exp))`;
/// ნამდვილი `k` არის `k_0` ან `k_0+1`.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits თუ mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) ამიტომ ეს ყოველთვის აფასებს (ან ზუსტია), მაგრამ არც ისე ბევრი.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}