//! თითქმის სწრაფად (მაგრამ ოდნავ ოპტიმიზირებული) Rust თარგმანი "მცურავი წერტილების ციფრების სწრაფად და ზუსტად დაბეჭდვა"-ის ნახაზზე 3 [^ 1].
//!
//!
//! [^1]: Burger, RG და Dybvig, RK 1996. მცურავი წერტილების ციფრების ბეჭდვა
//!   სწრაფად და ზუსტად.SIGPLAN არა.31, 5 (მაისი. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// `ციფრის` წინასწარ გათვლილი მასივები 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// გამოსადეგია მხოლოდ მაშინ, როდესაც `x < 16 * scale`;`scaleN` უნდა იყოს `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Dragon-ის უმოკლესი რეჟიმის განხორციელება.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ცნობილია, რომ ფორმატი `v` ნომერია:
    // - `mant * 2^exp` ტოლია;
    // - თავდაპირველი ტიპის `(mant - 2 *minus)* 2^exp` წინ უსწრებს;და
    // - ორიგინალ ტიპში მოყვება `(mant + 2 *plus)* 2^exp`.
    //
    // ცხადია, `minus` და `plus` არ შეიძლება იყოს ნული.(უსასრულობისთვის, ჩვენ ვიყენებთ დიაპაზონის გარეთ არსებულ მნიშვნელობებს.) ასევე ვივარაუდებთ, რომ გენერირდება მინიმუმ ერთი ციფრი, ანუ `mant` არ შეიძლება იყოს ნულიც.
    //
    // ეს ასევე ნიშნავს, რომ ნებისმიერი რიცხვი `low = (mant - minus)*2^exp`-სა და `high = (mant + plus)* 2^exp`-ს მიუთითებს ამ ზუსტი მცურავი წერტილის ნომერზე, ჩათვლით საზღვრებით, როდესაც ორიგინალი მანსისი იყო ლუწი (მაგ., `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` არის `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // შეაფასეთ `k_0` საწყისი მონაცემებიდან, რომელიც აკმაყოფილებს `10^(k_0-1) < high <= 10^(k_0+1)`.
    // მჭიდროდ შეკრული `k` დამაკმაყოფილებელი `10^(k-1) < high <= 10^k` გამოითვლება მოგვიანებით.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` გადააქციეთ ფრაქციულ ფორმაში ისე, რომ:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // გაყოფა `mant` `10^k`.ახლა `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // გამოსწორება, როდესაც `mant + plus > scale` (ან `>=`).
    // ჩვენ რეალურად არ ვცვლით `scale`-ს, ვინაიდან ამის ნაცვლად შეგვიძლია გამოტოვოთ საწყისი გამრავლება.
    // ახლა `scale < mant + plus <= scale * 10` და ჩვენ მზად ვართ ციფრების შესაქმნელად.
    //
    // გაითვალისწინეთ, რომ `d[0]`*შეიძლება* იყოს ნულოვანი, როდესაც `scale - plus < mant < scale`.
    // ამ შემთხვევაში დამრგვალების მდგომარეობა (ქვემოთ მოცემული `up`) დაუყოვნებლივ ამოქმედდება.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // ექვივალენტურია `scale`- ის 10 - ით მასშტაბირება
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` ციფრების წარმოქმნისთვის.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // ინვარიანტები, სადაც `d[0..n-1]` არის ჯერჯერობით გენერირებული ციფრები:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (ამრიგად `mant / scale < 10`) სადაც `d[i..j]` არის სტენოგრამა `d [i] * 10 ^ (ji) +-ისთვის ...
        // + d [j-1] * 10 + d[j]`.

        // გენერირება ერთი ციფრი: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ეს არის შეცვლილი Dragon ალგორითმის გამარტივებული აღწერა.
        // მრავალი შუალედური წარმოება და სისრულის არგუმენტები გამოტოვებულია მოხერხებულობისთვის.
        //
        // დაიწყეთ შეცვლილი ინვარიანტებით, რადგან ჩვენ განაახლეთ `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // ჩათვალეთ, რომ `d[0..n-1]` არის უმოკლესი გამოსახულება `low`-სა და `high`-ს შორის, ანუ `d[0..n-1]` აკმაყოფილებს ორივე შემდეგს, მაგრამ `d[0..n-2]` არ აკმაყოფილებს:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (ბიექტურობა: ციფრები მრგვალი `v`);და
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (ბოლო ციფრი სწორია).
        //
        // მეორე მდგომარეობა ამარტივებს `2 * mant <= scale`- ს.
        // ინვარიანტების გადაჭრა `mant`, `low` და `high` თვალსაზრისით იძლევა პირველი პირობის უფრო მარტივ ვერსიას: `-plus < mant < minus`.
        // `-plus < 0 <= mant`-ის შემდეგ, ჩვენ გვაქვს უმოკლესი გამოსახულება, როდესაც `mant < minus` და `2 * mant <= scale`.
        // (პირველი ხდება `mant <= minus`, როდესაც ორიგინალური mantissa არის ლუწი.)
        //
        // როდესაც მეორე არ იკავებს (`2 * mant> მასშტაბი`), ჩვენ უნდა გავზარდოთ ბოლო ციფრი.
        // ეს საკმარისია ამ მდგომარეობის აღსადგენად: ჩვენ უკვე ვიცით, რომ ციფრების წარმოქმნა იძლევა გარანტიას `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // ამ შემთხვევაში, პირველი მდგომარეობა ხდება `-plus < mant - scale < minus`.
        // `mant < scale` თაობის შემდეგ, ჩვენ გვაქვს `scale < mant + plus`.
        // (კიდევ ერთხელ, ეს ხდება `scale <= mant + plus`, როდესაც ორიგინალური mantissa გაათანაბრდება.)
        //
        // მოკლედ:
        // - გაჩერება და მრგვალი `down` (შეინახეთ ციფრები ისე, როგორც არის), როდესაც `mant < minus` (ან `<=`).
        // - გაჩერება და მრგვალი `up` (ბოლო ციფრის გაზრდა) როდესაც `scale < mant + plus` (ან `<=`).
        // - განაგრძეთ სხვაგვარად გამომუშავება.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // ჩვენ გვაქვს უმოკლესი წარმომადგენლობა, გადადით დამრგვალებაზე

        // ინვარიანტების აღდგენა.
        // ეს ალგორითმს ყოველთვის წყვეტს: `minus` და `plus` ყოველთვის იზრდება, მაგრამ `mant` იჭრება მოდული `scale` და `scale` ფიქსირდება.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // დამრგვალება ხდება მაშინ, როდესაც ი) მხოლოდ დამრგვალების პირობა იყო ჩართული, ან ii) ორივე პირობა იყო გააქტიურებული და ჰალსტუხის გატეხვა ურჩევნია დამრგვალებას.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // თუ დამრგვალება შეცვლის სიგრძეს, ასევე უნდა შეიცვალოს ექსპონატი.
        // როგორც ჩანს, ამ პირობის დაკმაყოფილება ძალზე ძნელია (შესაძლოა შეუძლებელიც), მაგრამ ჩვენ აქ მხოლოდ დაცულები და უსაფრთხოები ვართ.
        //
        // უსაფრთხოება: ეს მეხსიერება ზემოთ დავიწყეთ.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // უსაფრთხოება: ეს მეხსიერება ზემოთ დავიწყეთ.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ზუსტი და ფიქსირებული რეჟიმის განხორციელება Dragon-ისთვის.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // შეაფასეთ `k_0` საწყისი მონაცემებიდან, რომელიც აკმაყოფილებს `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // გაყოფა `mant` `10^k`.ახლა `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // ფიქსაცია, როდესაც `mant + plus >= scale`, სადაც `plus / scale = 10^-buf.len() / 2`.
    // იმისათვის, რომ შევინარჩუნოთ ფიქსირებული ზომის bignum, ჩვენ რეალურად ვიყენებთ `mant + floor(plus) >= scale`.
    // ჩვენ რეალურად არ ვცვლით `scale`-ს, ვინაიდან ამის ნაცვლად შეგვიძლია გამოტოვოთ საწყისი გამრავლება.
    // ისევ უმოკლესი ალგორითმით, `d[0]` შეიძლება იყოს ნული, მაგრამ საბოლოოდ მომრგვალდება.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // ექვივალენტურია `scale`- ის 10 - ით მასშტაბირება
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // თუ ჩვენ ვმუშაობთ ბოლო ციფრის შეზღუდვით, ჩვენ უნდა შევამციროთ ბუფერი რეალურ გატარებამდე, რათა თავიდან ავიცილოთ ორმაგი დამრგვალება.
    //
    // გაითვალისწინეთ, რომ დამრგვალება უნდა მოხდეს, რომ კვლავ გავაზარდოთ ბუფერი!
    let mut len = if k < limit {
        // უი, ჩვენ *ერთი* ციფრის წარმოებაც კი არ შეგვიძლია.
        // ეს შესაძლებელია, როდესაც ვთქვათ, ჩვენ გვაქვს მსგავსი 9.5 და ის მრგვალდება 10-მდე.
        // ჩვენ ვაბრუნებთ ცარიელ ბუფერულს, გარდა მოგვიანებით დამრგვალების შემთხვევისა, რომელიც ხდება `k == limit`- ზე და მან უნდა შექმნას ზუსტად ერთი ციფრი.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` ციფრების წარმოქმნისთვის.
        // (ეს შეიძლება იყოს ძვირი, ასე რომ არ გამოთვალოთ ისინი, როდესაც ბუფერი ცარიელია.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // შემდეგი ციფრები ყველა ნულოვანია, ჩვენ აქ ვჩერდებით *ნუ* ვცდილობთ შევასრულოთ დამრგვალება!უფრო მეტიც, შეავსეთ დარჩენილი ციფრები.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // უსაფრთხოება: ეს მეხსიერება ზემოთ დავიწყეთ.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // დამრგვალება, თუ ციფრების შუაში შევჩერდებით, თუ შემდეგი ციფრები ზუსტად 5000-ია ..., შეამოწმეთ წინა ციფრი და შეეცადეთ დამრგვალება (მაგ., თავიდან ავიცილოთ დამრგვალება, როდესაც წინა ციფრი გაათანაბრდება).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // უსაფრთხოება: `buf[len-1]` ინიცირებულია.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // თუ დამრგვალება შეცვლის სიგრძეს, ასევე უნდა შეიცვალოს ექსპონატი.
        // მაგრამ ჩვენ ციფრების ფიქსირებული რაოდენობა მოგვთხოვეს, ამიტომ ნუ შეცვლით ბუფერს ...
        // უსაფრთხოება: ეს მეხსიერება ზემოთ დავიწყეთ.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... თუ სამაგიეროდ არ მოგვთხოვენ ფიქსირებული სიზუსტით.
            // ჩვენ ასევე უნდა შეამოწმოთ, რომ თუ ორიგინალი ბუფერი ცარიელი იყო, დამატებითი ციფრი შეიძლება დაემატოს მხოლოდ მაშინ, როდესაც `k == limit` (edge შემთხვევაში).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // უსაფრთხოება: ეს მეხსიერება ზემოთ დავიწყეთ.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}