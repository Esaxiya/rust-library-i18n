//! კომუნალური ფუნქციები bignums- ისთვის, რომლებსაც ძალიან დიდი აზრი არ აქვს მეთოდებად გადასაქცევად.

// FIXME ამ მოდულის სახელი ოდნავ სამწუხაროა, რადგან სხვა მოდულები ასევე შემოაქვთ `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// შეამოწმეთ, შემოაქვს თუ არა ყველა ბიტის ნაკლები მნიშვნელობა, ვიდრე `ones_place`, შედარებით ნაკლები შეცდომა, ტოლი ან მეტი 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // თუ ყველა დარჩენილი ბიტი ნულოვანია, ეს= 0.5 ULP, წინააღმდეგ შემთხვევაში> 0.5 თუ მეტი ბიტი აღარ არის (half_bit==0), ქვემოთ მოცემულიც სწორად აბრუნებს ტოლს.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// გარდაქმნის ASCII სტრიქონს, რომელიც შეიცავს მხოლოდ ათობითი ციფრებს `u64`.
///
/// არ ასრულებს გადავსების ან არასწორი სიმბოლოების შემოწმებას, ასე რომ, თუ აბონენტი ფრთხილად არ არის, შედეგი არის ყალბი და შეიძლება panic (თუმცა ეს არ იქნება `unsafe`).
/// გარდა ამისა, ცარიელი სიმები განიხილება, როგორც ნულოვანი.
/// ეს ფუნქცია არსებობს იმიტომ
///
/// 1. `FromStr`- ის გამოყენება `&[u8]`- ზე საჭიროა `from_utf8_unchecked`, რაც ცუდია და
/// 2. `integral.parse()` და `fractional.parse()` შედეგების დანაწევრება უფრო რთულია, ვიდრე მთელი ეს ფუნქცია.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// გარდაქმნის ASCII ციფრების სტრიქონს ბინგუმში.
///
/// `from_str_unchecked`-ის მსგავსად, ეს ფუნქცია ეყრდნობა ანალიზატორს, რომ ამოიღოს არანიშნა რიცხვები.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// ხსნის ბიგნუმს 64 ბიტიან მთელ რიცხვში.Panics თუ ნომერი ძალიან დიდია.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// ამოიღებს ბიტების სპექტრს.

/// ინდექსი 0 ყველაზე ნაკლებად მნიშვნელოვანი ბიტია და დიაპაზონი ჩვეულებრივ ნახევრად გახსნილია.
/// Panics თუ ითხოვენ უფრო მეტი ბიტის ამოღებას, ვიდრე ჯდება დაბრუნების ტიპში.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}