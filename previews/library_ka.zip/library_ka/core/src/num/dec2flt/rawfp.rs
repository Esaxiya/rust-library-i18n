//! ბიტ - ფიდინგი პოზიტიურ IEEE 754 მცურავზე.უარყოფითი რიცხვები არ არის დამუშავებული და საჭირო არ არის.
//! ნორმალური მცურავი წერტილების რიცხვებს აქვთ კანონიკური გამოსახულება, როგორც (frac, exp) ისეთი, რომ მნიშვნელობა არის 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), სადაც N არის ბიტების რაოდენობა.
//!
//! სუბნორმალები ოდნავ განსხვავებული და უცნაურია, მაგრამ იგივე პრინციპი მოქმედებს.
//!
//! ამასთან, აქ ჩვენ წარმოვადგენთ მათ (sig, k) f პოზიტიურით, ისეთი, რომ მნიშვნელობა f *
//! 2 <sup>ე</sup>გარდა იმისა, რომ "hidden bit" აშკარაა, ეს ცვლის ექსპონენტს ე.წ. მანტისას ცვლაში.
//!
//! სხვაგვარად რომ ვთქვათ, ჩვეულებრივ floats იწერება (1), მაგრამ აქ ისინი დაწერილია (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! ჩვენ (1) ვუწოდებთ **ფრაქციულ წარმოდგენას** და (2)**ინტეგრალურ წარმოდგენას**.
//!
//! ამ მოდულის მრავალი ფუნქცია მხოლოდ ნორმალურ ციფრებს მართავს.Dec2flt რუტინები კონსერვატიულად მიდის უნივერსალურად სწორ ნელ გზაზე (ალგორითმი M) ძალიან მცირე და ძალიან დიდი რიცხვებისთვის.
//! ამ ალგორითმს სჭირდება მხოლოდ next_float(), რომელიც ამუშავებს ქვენორმალურ და ნულებს.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// trait დამხმარე, რომ თავიდან იქნას აცილებული `f32` და `f64` ყველა გადამყვანი კოდის კოპირება.
///
/// იხილეთ მშობლის მოდულის დოკუმენტის კომენტარი, თუ რატომ არის ეს აუცილებელი.
///
/// **არასოდეს უნდა იყოს** გამოყენებული სხვა ტიპისთვის ან გამოყენებული იქნას dec2flt მოდულის გარეთ.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// ტიპი, რომელსაც იყენებენ `to_bits` და `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// ახორციელებს ნედლ ტრანსმუტაციას მთელი რიცხვიდან.
    fn to_bits(self) -> Self::Bits;

    /// ახორციელებს ნედლ ტრანსმუტაციას მთელი რიცხვიდან.
    fn from_bits(v: Self::Bits) -> Self;

    /// აბრუნებს კატეგორიას, რომელშიც ეს რიცხვი მოხვდება.
    fn classify(self) -> FpCategory;

    /// აბრუნებს mantissa, exponent და sign როგორც მთელი რიცხვები.
    fn integer_decode(self) -> (u64, i16, i8);

    /// ათწილადი ათწილადი.
    fn unpack(self) -> Unpacked;

    /// ნაწყვეტები პატარა მთელი რიცხვიდან, რომელიც შეიძლება ზუსტად იყოს წარმოდგენილი.
    /// Panic თუ მთელი რიცხვის წარმოდგენა შეუძლებელია, ამ მოდულის სხვა კოდი დარწმუნებულია, რომ ეს არასდროს მოხდება.
    fn from_int(x: u64) -> Self;

    /// წინასწარ გამოთვლილი ცხრილიდან იღებს 10 <sup>e</sup> მნიშვნელობას.
    /// Panics `e >= CEIL_LOG5_OF_MAX_SIG`-სთვის.
    fn short_fast_pow10(e: usize) -> Self;

    /// რას ამბობს სახელი.
    /// ხისტი კოდის მიღება უფრო ადვილია, ვიდრე შინაგან საქმეთა ჟონგლიორობა და LLVM მუდმივი დაკეცვის იმედი.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // კონსერვატორი მიმაგრებულია შეყვანის ათობითი ციფრებზე, რომელსაც არ შეუძლია აწარმოოს გადავსება ან ნულოვანი ან
    /// ქვენორმალები.ალბათ მაქსიმალური ნორმალური მნიშვნელობის ათობითი გამომხატველი, შესაბამისად, სახელიც.
    const MAX_NORMAL_DIGITS: usize;

    /// როდესაც ყველაზე მნიშვნელოვან ათობითი ციფრს აქვს ამაზე მეტი ადგილის მნიშვნელობა, რიცხვი მრგვალდება უსასრულობამდე.
    ///
    const INF_CUTOFF: i64;

    /// როდესაც ყველაზე მნიშვნელოვან ათობითი ციფრს აქვს ამაზე ნაკლები ადგილის მნიშვნელობა, რიცხვი, რა თქმა უნდა, დამრგვალებულია ნულზე.
    ///
    const ZERO_CUTOFF: i64;

    /// ექსპონენტში ბიტების რაოდენობა.
    const EXP_BITS: u8;

    /// მნიშვნელობის ბიტების რაოდენობა, * დამალული ბიტის ჩათვლით.
    const SIG_BITS: u8;

    /// მნიშვნელობის ბიტების რაოდენობა და * დაფარული ბიტის გამოკლებით.
    const EXPLICIT_SIG_BITS: u8;

    /// ფრაქციული წარმომადგენლობის მაქსიმალური იურიდიული წარმომადგენელი.
    const MAX_EXP: i16;

    /// ფრაქციული წარმოდგენის მინიმალური იურიდიული ექსპონატი, ქვენორმალების გარდა.
    const MIN_EXP: i16;

    /// `MAX_EXP` ინტეგრალური წარმოდგენისთვის, ანუ გამოყენებული ცვლისთვის.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` დაშიფრული (ანუ ოფსეტური მიკერძოებით)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` ინტეგრალური წარმოდგენისთვის, ანუ გამოყენებული ცვლისთვის.
    const MIN_EXP_INT: i16;

    /// მაქსიმალური ნორმალიზებული მნიშვნელობა და ინტეგრალური წარმოდგენა.
    const MAX_SIG: u64;

    /// მინიმალური ნორმალიზებული მნიშვნელობა და ინტეგრალური წარმოდგენა.
    const MIN_SIG: u64;
}

// ძირითადად, #34344- ს გადაკეთება.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// აბრუნებს mantissa, exponent და sign როგორც მთელი რიცხვები.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // ექსპონენტის მიკერძოება + მანტისას ცვლა
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe გაურკვეველია, სწორად ტრიალებს თუ არა `as` ყველა პლატფორმაზე.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// აბრუნებს mantissa, exponent და sign როგორც მთელი რიცხვები.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // ექსპონენტის მიკერძოება + მანტისას ცვლა
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe გაურკვეველია, სწორად ტრიალებს თუ არა `as` ყველა პლატფორმაზე.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` გარდაქმნის უახლოეს მანქანაში float ტიპის.
/// არ უმკლავდება სუბნორმალურ შედეგებს.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 ბიტიანია, ამიტომ xe-ს აქვს 63 mantissa ცვლა
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64-ბიტიანი მნიშვნელობის დამრგვალება და T::SIG_BITS ბიტზე მრგვალდება ნახევრად გათანაბრებით.
/// არ უმკლავდება ექსპონენტის გადავსებას.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // შეცვალეთ მანტისას ცვლა
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// `RawFloat::unpack()`- ის ინვერსია ნორმალიზებული რიცხვებისთვის.
/// Panics თუ მნიშვნელი ან ექსპონატი არ არის მართებული ნორმალიზებული რიცხვებისთვის.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // ამოიღეთ ფარული ბიტი
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // შეცვალეთ ექსპონენტი ექსპონენტის მიკერძოებისა და მანტისას ცვლისთვის
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // დატოვეთ ნიშანი 0-ზე 0 ("+"), ჩვენი რიცხვები დადებითია
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// აშენების subnormal.ნებადართულია 0 mantissa და აშენებს ნულს.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // დაშიფრული ექსპონატი არის 0, ნიშნის ბიტი არის 0, ასე რომ, ჩვენ მხოლოდ ბიტების ახსნა გვჭირდება.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ბიგნუმის მიახლოება Fp- ით.0.5 ULP ფარგლებში მრგვალდება ნახევრად გათანაბრებით.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // ჩვენ გავთიშეთ ყველა ბიტი `start` ინდექსამდე, ანუ, ჩვენ ეფექტურად ვაქცევთ მარჯვნივ `start` რაოდენობით, ამიტომ ესეც ჩვენ გვჭირდება.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // მრგვალი (half-to-even) დამოკიდებულია შეკვეცილ ბიტებზე.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// პოულობს უდიდეს მცურავი წერტილის რიცხვს, რომელიც მკაცრად მცირეა ვიდრე არგუმენტი.
/// არ უმკლავდება სუბნორმალურ, ნულოვან ან ექსპონენტურ ნაკადს.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// იპოვნეთ მცირე მცურავი წერტილის რიცხვი, რომელიც მკაცრად აღემატება არგუმენტს.
// ეს ოპერაცია სავსეა, ანუ next_float(inf) ==ინფ.
// ამ მოდულის კოდის უმეტესობისგან განსხვავებით, ეს ფუნქცია უმკლავდება ნულს, ქვენორმალურებს და უსასრულობებს.
// ამასთან, აქ ისევე როგორც ყველა სხვა კოდი, ეს არ ეხება NaN და უარყოფით რიცხვებს.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // ეს, როგორც ჩანს, ძალიან კარგია სიმართლედ, მაგრამ მუშაობს.
        // 0.0 დაშიფრულია, როგორც ნულოვანი სიტყვა.ქვე ნორმალურია 0x000 მ ... მ, სადაც მ არის მანტისა.
        // კერძოდ, ყველაზე მცირე სუბნორმალურია 0x0 ... 01 და ყველაზე დიდია 0x000F ... F.
        // ყველაზე პატარა ნორმალური რიცხვია 0x0010 ... 0, ამიტომ ამ კუთხის კორპუსიც მუშაობს.
        // თუ ნამატი გადაფარავს მანტისას, ტარების ბიტი ზრდის ექსპონენტს, როგორც ჩვენ გვინდა, და მანტისის ბიტი ნულის ტოლია.
        // ფარული ბიტის კონვენციის გამო, ეს არის ის, რაც ჩვენ გვსურს!
        // დაბოლოს, f64::MAX + 1=7 eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}