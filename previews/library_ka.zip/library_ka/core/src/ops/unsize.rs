use crate::marker::Unsize;

/// Trait, რომელიც მიუთითებს იმაზე, რომ ეს არის მაჩვენებელი ან შესაფუთი ერთისთვის, სადაც ზომის შეცვლის შესრულება შესაძლებელია შეფუთვაზე.
///
/// დამატებითი ინფორმაციისთვის იხილეთ [DST coercion RFC][dst-coerce] და [the nomicon entry on coercion][nomicon-coerce].
///
/// ჩამონტაჟებული მაჩვენებლის ტიპებისთვის, `T` მინიშნებები იძულებითი იქნება `U` მაჩვენებლებზე, თუ `T: Unsize<U>` წვრილი მაჩვენებელიდან ცხიმის მაჩვენებელზე გადაკეთებით.
///
/// მორგებული ტიპებისთვის აქ იძულებითი მოქმედება ხდება `Foo<T>`- დან `Foo<U>`- ით იძულებითი პირობით, თუ არსებობს `CoerceUnsized<Foo<U>> for Foo<T>` გავლენა.
/// ასეთი მითითება მხოლოდ მაშინ შეიძლება დაიწეროს, თუ `Foo<T>`- ს აქვს მხოლოდ ერთი არაფანტმოტ მონაცემთა ველი, რომელშიც ჩართულია `T`.
/// თუ ამ ველის ტიპია `Bar<T>`, `CoerceUnsized<Bar<U>> for Bar<T>`- ის განხორციელება უნდა არსებობდეს.
/// იძულებითი იმოქმედებს `Bar<T>` ველის `Bar<U>` იძულებით და `Foo<T>`- დან დანარჩენი ველების შევსებით `Foo<U>`- ის შესაქმნელად.
/// ეს ეფექტურად გაწვება მაჩვენებლის ველს და აიძულებს ამას.
///
/// საერთოდ, ჭკვიანი მაჩვენებლებისთვის თქვენ განახორციელებთ `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`-ს, სურვილისამებრ `?Sized` მიბმული იქნება `T`-ზე.
/// შესაფუთი ტიპისთვის, რომელიც პირდაპირ შეიცავს `T`-ს, როგორიცაა `Cell<T>` და `RefCell<T>`, შეგიძლიათ პირდაპირ განახორციელოთ `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// ეს საშუალებას მისცემს იმ ტიპის იძულებითი მოქმედება.
///
/// [`Unsize`][unsize] გამოიყენება ტიპების აღსანიშნავად, რომელთა იძულებაც DST-ებს შეიძლება, თუ მაჩვენებლების უკან დგას.მას ავტომატურად ახორციელებს შემდგენელი.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * კონსტ. U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * კონსტ. U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// ეს გამოიყენება ობიექტის უსაფრთხოების მიზნით, იმის შესამოწმებლად, რომ შესაძლებელია მეთოდის მიმღების ტიპის გაგზავნა.
///
/// trait-ის განხორციელების მაგალითი:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}