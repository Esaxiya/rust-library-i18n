/// გამოიყენება უცვლელი გადამისამართების ოპერაციებისთვის, მაგალითად `*v`.
///
/// გარდა იმისა, რომ იგი გამოიყენება უცვლელი კონტექსტში (unary) `*` ოპერატორთან (unary) `*` ოპერატორთან აშკარად მოხსენიების ოპერაციებისთვის, `Deref` ასევე გამოიყენება ნაგულისხმევად შემდგენელის მიერ მრავალ გარემოებაში.
/// ამ მექანიზმს ['`Deref` coercion'][more] ეწოდება.
/// მუტაბელურ კონტექსტებში გამოიყენება [`DerefMut`].
///
/// `Deref`- ის განხორციელება ჭკვიანი მაჩვენებლებისთვის ხდის მოსახერხებელ მონაცემებზე წვდომას, რის გამოც ისინი ახორციელებენ `Deref`- ს დანერგვას.
/// მეორეს მხრივ, წესები `Deref` და [`DerefMut`]- ს შესახებ შეიქმნა სპეციალურად იმისთვის, რომ განათავსოს ჭკვიანი მითითებები.
/// ამის გამო,**`Deref` უნდა განხორციელდეს მხოლოდ ჭკვიანი მაჩვენებლებისთვის**, რათა არ მოხდეს დაბნეულობა.
///
/// მსგავსი მიზეზების გამო,**ეს trait არასდროს არ უნდა ჩავარდეს**.მოხსენების დროს წარუმატებლობა შეიძლება უკიდურესად დამაბნეველი აღმოჩნდეს, როდესაც `Deref` იძახიან.
///
/// # მეტი `Deref` იძულების შესახებ
///
/// თუ `T` ახორციელებს `Deref<Target = U>`-ს, და `x` არის `T` ტიპის მნიშვნელობა, მაშინ:
///
/// * უცვლელ კონტექსტებში `*x` (სადაც `T` არც მითითებაა და არც ნედლეული მაჩვენებელი) ექვივალენტურია `* Deref::deref(&x)`.
/// * `&T` ტიპის მნიშვნელობები იძულებითია `&U` ტიპის მნიშვნელობებზე
/// * `T` ნაგულისხმევად ახორციელებს `U` ტიპის ყველა (immutable) მეთოდს.
///
/// დამატებითი ინფორმაციისთვის ეწვიეთ [the chapter in *The Rust Programming Language*][book]-ს, აგრეთვე მითითებებს სექციებში [the dereference operator][ref-deref-op], [method resolution] და [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// სტრუქტურა ერთი ველით, რომელიც ხელმისაწვდომია სტრუქტურის მოხსენიებით.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// მიღებული ტიპი გადამისამართების შემდეგ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// აკლებს მნიშვნელობას.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// გამოიყენება ცვლადი გადამისამართების ოპერაციებისთვის, როგორც `*v = 1;`- ში.
///
/// გარდა იმისა, რომ იგი გამოიყენება მკაფიო გადამისამართების ოპერაციებისთვის (unary) `*` ოპერატორთან მუტაბელურ კონტექსტებში, `DerefMut` ასევე გამოიყენება ნაგულისხმევად შემდგენელის მიერ მრავალ გარემოებაში.
/// ამ მექანიზმს ['`Deref` coercion'][more] ეწოდება.
/// უცვლელ კონტექსტებში გამოიყენება [`Deref`].
///
/// `DerefMut`- ის განხორციელება ჭკვიანი მაჩვენებლებისთვის ხელსაყრელს ხდის მათ უკან არსებული მონაცემების მუტაციას, რის გამოც ისინი ახორციელებენ `DerefMut`- ს დანერგვას.
/// მეორეს მხრივ, წესები [`Deref`] და `DerefMut`- ს შესახებ შეიქმნა სპეციალურად იმისთვის, რომ განათავსოს ჭკვიანი მითითებები.
/// ამის გამო,**`DerefMut` უნდა განხორციელდეს მხოლოდ ჭკვიანი მითითებებისთვის**, დაბნეულობის თავიდან ასაცილებლად.
///
/// მსგავსი მიზეზების გამო,**ეს trait არასდროს არ უნდა ჩავარდეს**.მოხსენების დროს წარუმატებლობა შეიძლება უკიდურესად დამაბნეველი აღმოჩნდეს, როდესაც `DerefMut` იძახიან.
///
/// # მეტი `Deref` იძულების შესახებ
///
/// თუ `T` ახორციელებს `DerefMut<Target = U>`-ს, და `x` არის `T` ტიპის მნიშვნელობა, მაშინ:
///
/// * მუტაბელურ კონტექსტში `*x` (სადაც `T` არც მითითებაა და არც ნედლეული მაჩვენებელი) ექვივალენტურია `* DerefMut::deref_mut(&mut x)`.
/// * `&mut T` ტიპის მნიშვნელობები იძულებითია `&mut U` ტიპის მნიშვნელობებზე
/// * `T` ნაგულისხმევად ახორციელებს `U` ტიპის ყველა (mutable) მეთოდს.
///
/// დამატებითი ინფორმაციისთვის ეწვიეთ [the chapter in *The Rust Programming Language*][book]-ს, აგრეთვე მითითებებს სექციებში [the dereference operator][ref-deref-op], [method resolution] და [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// სტრუქტურა ერთი ველით, რომელიც შეიცვლება სტრუქტურის მოხსენიებით.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// ცვალებად გამორიცხავს მნიშვნელობას.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// მიუთითებს, რომ სტრუქტურა შეიძლება გამოყენებულ იქნას როგორც მეთოდის მიმღები, `arbitrary_self_types` მახასიათებლის გარეშე.
///
/// ამას ახორციელებენ stdlib მაჩვენებლის ტიპები, როგორიცაა `Box<T>`, `Rc<T>`, `&T` და `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}