//! გადატვირთული ოპერატორები.
//!
//! ამ traits- ის განხორციელება საშუალებას გაძლევთ გადატვირთოთ გარკვეული ოპერატორები.
//!
//! ზოგიერთი traits იმპორტირებულია prelude- ს მიერ, ამიტომ ისინი ხელმისაწვდომია ყველა Rust პროგრამაში.მხოლოდ O0traits0Z მხარდაჭერით ოპერატორებს შეუძლიათ გადატვირთონ.
//! მაგალითად, დამატების ოპერატორი (`+`) შეიძლება გადატვირთული იყოს [`Add`] trait- ს საშუალებით, მაგრამ რადგან დავალების ოპერატორს (`=`) არ აქვს ზურგამტარი trait, მისი სემანტიკის გადატვირთვის გზა არ არსებობს.
//! დამატებით, ეს მოდული არ შეიცავს რაიმე მექანიზმს ახალი ოპერატორების შესაქმნელად.
//! თუ საჭიროა უღირსი გადატვირთვა ან მორგებული ოპერატორები, Rust სინტაქსის გასაზრდელად უნდა მიმართოთ მაკროებს ან შემდგენელთა დანამატებს.
//!
//! ოპერატორის traits- ს განხორციელება გასაკვირი არ უნდა იყოს მათ შესაბამის კონტექსტში, გაითვალისწინეთ მათი ჩვეულებრივი მნიშვნელობები და [operator precedence].
//! მაგალითად, [`Mul`]- ის დანერგვისას, ოპერაციას უნდა ჰქონდეს გარკვეული მსგავსება გამრავლებასთან (და უნდა გაიზიაროს მოსალოდნელი თვისებები, როგორიცაა ასოცირება).
//!
//! გაითვალისწინეთ, რომ `&&` და `||` ოპერატორების მოკლე ჩართვა, ანუ ისინი აფასებენ თავიანთ მეორე ოპერანდს მხოლოდ იმ შემთხვევაში, თუ ეს ხელს უწყობს შედეგს.ვინაიდან ეს ქცევა არ არის აღსასრულებელი traits- ს მიერ, `&&` და `||` არ არის მხარდაჭერილი, როგორც გადატვირთული ოპერატორები.
//!
//! ბევრი ოპერატორი იღებს თავის ოპერანდებს მნიშვნელობით.არა Generic კონტექსტში, რომელიც მოიცავს ჩაშენებულ ტიპებს, ეს ჩვეულებრივ არ წარმოადგენს პრობლემას.
//! ამასთან, ამ ოპერატორების ზოგად კოდში გამოყენება გარკვეულ ყურადღებას მოითხოვს, თუ მნიშვნელობები ხელახლა უნდა იქნას გამოყენებული, ვიდრე ოპერატორებმა მათ მოიხმარონ.ერთი ვარიანტია ზოგჯერ გამოიყენოთ [`clone`].
//! კიდევ ერთი ვარიანტია დაეყრდნოთ ტიპებს, რომლებიც მოიცავს დამატებითი ოპერატორის გამოყენებას მითითებებისთვის.
//! მაგალითად, მომხმარებლის მიერ განსაზღვრული ტიპის `T`, რომელიც სავარაუდოდ დამატებას ემსახურება, ალბათ კარგი იდეაა, რომ `T` და `&T` განახორციელონ traits [`Add<T>`][`Add`] და [`Add<&T>`][`Add`] ისე, რომ ზოგადი კოდი დაიწეროს ზედმეტი კლონირების გარეშე.
//!
//!
//! # Examples
//!
//! ეს მაგალითი ქმნის `Point` სტრუქტურას, რომელიც ახორციელებს [`Add`] და [`Sub`] და შემდეგ აჩვენებს ორი `Point's წერტილის დამატებასა და გამოკლებას.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! განხორციელების მაგალითზე იხილეთ თითოეული trait- ს დოკუმენტაცია.
//!
//! [`Fn`], [`FnMut`] და [`FnOnce`] traits ხორციელდება ტიპების მიხედვით, რომელთა გამოძახებაც შეიძლება ფუნქციების მსგავსად.გაითვალისწინეთ, რომ [`Fn`] იღებს `&self`, [`FnMut`] იღებს `&mut self` და [`FnOnce`] იღებს `self`.
//! ეს შეესაბამება სამი სახის მეთოდს, რომელთა გამოყენება შეიძლება მაგალითად: ზარის მითითებით, ზარის მიხედვით მუტაბელური მითითებით და ზარის მიხედვით მნიშვნელობით.
//! ამ traits- ის ყველაზე გავრცელებული გამოყენება არის უფრო მაღალი დონის ფუნქციების საზღვრების როლი, რომლებიც არგუმენტებად იღებენ ფუნქციებს ან დახურვას.
//!
//! [`Fn`] პარამეტრის მიღება:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`] პარამეტრის მიღება:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`] პარამეტრის მიღება:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` მოიხმარს მის აღბეჭდილ ცვლადებს, ამიტომ მისი გაშვება ერთზე მეტჯერ არ შეიძლება
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` კვლავ გამოძახების მცდელობა გამოიწვევს `use of moved value` შეცდომას `func`-სთვის
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ამ ეტაპზე აღარ შეიძლება გამოყენებული იქნას
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;