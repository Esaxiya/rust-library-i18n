use crate::fmt;
use crate::hash::Hash;

/// შეუზღუდავი დიაპაზონი (`..`).
///
/// `RangeFull` ძირითადად გამოიყენება როგორც [slicing index], მისი სტენოგრამაა `..`.
/// ის ვერ იქნება [`Iterator`], რადგან მას არ აქვს ამოსავალი წერტილი.
///
/// # Examples
///
/// `..` სინტაქსი არის `RangeFull`:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// მას არ აქვს [`IntoIterator`] განხორციელება, ასე რომ თქვენ პირდაპირ ვერ გამოიყენებთ `for` მარყუჟს.
/// ეს არ შეიკრიბება:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// გამოიყენება როგორც [slicing index], `RangeFull` აწარმოებს სრულ მასივს, როგორც ნაჭრებს.
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // ეს არის `RangeFull`
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// (half-open) დიაპაზონი შემოფარგლულია (`start..end`) ქვემოთ და მხოლოდ ზემოთ.
///
///
/// დიაპაზონი `start..end` შეიცავს ყველა მნიშვნელობას `start <= x < end`-ით.
/// ცარიელია, თუ `start >= end`.
///
/// # Examples
///
/// `start..end` სინტაქსი არის `Range`:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // ეს არის `Range`
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // არ არის კოპირება-იხილეთ #27186
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// (inclusive) დიაპაზონის ქვედა ზღვარი.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// დიაპაზონის ზედა ზღვარი (exclusive).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// აბრუნებს `true`-ს, თუ `item` შეიცავს დიაპაზონს.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// აბრუნებს `true` თუ დიაპაზონი არ შეიცავს ერთეულებს.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// დიაპაზონი ცარიელია, თუ რომელიმე მხარე შეუდარებელია:
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// დიაპაზონი შემოსაზღვრულია მხოლოდ (`start..`) ქვემოთ.
///
/// `RangeFrom` `start..` შეიცავს ყველა მნიშვნელობას `x >= start`- ით.
///
/// *შენიშვნა*: [`Iterator`] დანერგვაში გადავსება (როდესაც მონაცემთა ტიპის ტიპი მიაღწევს თავის ციფრულ ლიმიტს) ნებადართულია panic, შეფუთვა ან გაჯერება.
/// ეს ქცევა განისაზღვრება [`Step`] trait-ის დანერგვით.
/// პრიმიტიული მთლიანი რიცხვისთვის ეს იცავს ჩვეულებრივ წესებს და პატივს სცემს გადავსების შემოწმების პროფილს (panic გამართვაში, შეფუთვა გათავისუფლებაში).
/// გაითვალისწინეთ ისიც, რომ გადავსება ხდება უფრო ადრე ვიდრე შეიძლება იფიქროთ: გადავსება ხდება `next`-ის ზარში, რომელიც იძლევა მაქსიმალურ მნიშვნელობას, რადგან დიაპაზონი უნდა იყოს მითითებული მდგომარეობაში შემდეგი მნიშვნელობის მისაღებად.
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` სინტაქსი არის `RangeFrom`:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // ეს არის `RangeFrom`
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // არ არის კოპირება-იხილეთ #27186
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// (inclusive) დიაპაზონის ქვედა ზღვარი.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// აბრუნებს `true`-ს, თუ `item` შეიცავს დიაპაზონს.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// დიაპაზონი შემოიფარგლება მხოლოდ (`..end`) ზემოთ.
///
/// `RangeTo` `..end` შეიცავს ყველა მნიშვნელობას `x < end`- ით.
/// ის ვერ იქნება [`Iterator`], რადგან მას არ აქვს ამოსავალი წერტილი.
///
/// # Examples
///
/// `..end` სინტაქსი არის `RangeTo`:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// მას არ აქვს [`IntoIterator`] განხორციელება, ასე რომ თქვენ პირდაპირ ვერ გამოიყენებთ `for` მარყუჟს.
/// ეს არ შეიკრიბება:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// როდესაც გამოიყენება როგორც [slicing index], `RangeTo` აწარმოებს მასივის ყველა ელემენტის ნაჭერს `end`-ით მითითებულ ინდექსამდე.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // ეს არის `RangeTo`
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// დიაპაზონის ზედა ზღვარი (exclusive).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// აბრუნებს `true`-ს, თუ `item` შეიცავს დიაპაზონს.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// დიაპაზონი შემოსაზღვრულია (`start..=end`) ქვემოთ და ზემოთ.
///
/// `RangeInclusive` `start..=end` შეიცავს ყველა მნიშვნელობას `x >= start` და `x <= end`.ცარიელია, თუ არა `start <= end`.
///
/// ეს განმეორებაა [fused], მაგრამ გამეორების დასრულების შემდეგ `start` და `end`- ის კონკრეტული მნიშვნელობები **დაუზუსტებელია** გარდა იმისა, რომ [`.is_empty()`] დააბრუნებს `true` მას შემდეგ, რაც აღარ მიიღება მნიშვნელობები.
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` სინტაქსი არის `RangeInclusive`:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // ეს არის `RangeInclusive`
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // არ არის კოპირება-იხილეთ #27186
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // გაითვალისწინეთ, რომ აქ მოცემული ველები არ არის საჯარო, რომ future-ში წარმომადგენლობის შეცვლა მოხდეს;კერძოდ, მართალია, ჩვენ შეგვიძლია წარმოვადგინოთ start/end, მაგრამ მათმა შეცვლამ (future/current) კერძო ველის შეცვლის გარეშე შეიძლება გამოიწვიოს არასწორი ქცევა, ამიტომ ამ რეჟიმის მხარდაჭერა არ გვინდა.
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // ეს სფეროა:
    //  - `false` მშენებლობისთანავე
    //  - `false` როდესაც იტერაციამ ელემენტი გამოიღო და იტერატორი არ ამოწურა
    //  - `true` როდესაც განმეორება იქნა გამოყენებული იტერატორის ამოწურვისთვის
    //
    // ეს საჭიროა PartialEq-ისა და Hash-ის მხარდასაჭერად PartialOrd შეკრული ან სპეციალიზაციის გარეშე.
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// ქმნის ახალ ინკლუზიურ დიაპაზონს.`start..=end` წერის ტოლფასია.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// აბრუნებს (inclusive) დიაპაზონის ქვედა საზღვარს.
    ///
    /// იტერაციისთვის ინკლუზიური დიაპაზონის გამოყენებისას, `start()` და [`end()`] მნიშვნელობები განისაზღვრება განმეორების დასრულების შემდეგ.
    /// იმის დასადგენად, ცარიელია თუ არა ჩართული დიაპაზონი, გამოიყენეთ [`is_empty()`] მეთოდი `start() > end()` შედარების ნაცვლად.
    ///
    /// Note: ამ მეთოდით დაბრუნებული მნიშვნელობა განუსაზღვრელია დიაპაზონის ამოწურვის შემდეგ.
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// აბრუნებს (inclusive) დიაპაზონის ზედა ზღვარს.
    ///
    /// იტერაციისთვის ინკლუზიური დიაპაზონის გამოყენებისას, [`start()`] და `end()` მნიშვნელობები განისაზღვრება განმეორების დასრულების შემდეგ.
    /// იმის დასადგენად, ცარიელია თუ არა ჩართული დიაპაზონი, გამოიყენეთ [`is_empty()`] მეთოდი `start() > end()` შედარების ნაცვლად.
    ///
    /// Note: ამ მეთოდით დაბრუნებული მნიშვნელობა განუსაზღვრელია დიაპაზონის ამოწურვის შემდეგ.
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// ანადგურებს `RangeInclusive`-ს (ქვედა ზღვარი, ზედა (inclusive) ზღვარი).
    ///
    /// Note: ამ მეთოდით დაბრუნებული მნიშვნელობა განუსაზღვრელია დიაპაზონის ამოწურვის შემდეგ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// გარდაიქმნება ექსკლუზიურ `Range`-ზე `SliceIndex` განსახორციელებლად.
    /// აბონენტი პასუხისმგებელია `end == usize::MAX`- ს მოგვარებაზე.
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // თუ არ დაგვცლია, ჩვენ გვინდა უბრალოდ გავჭრათ `start..end + 1`.
        // თუ გადაღლილი ვართ, `end + 1..end + 1`- ით დაჭრა გვაძლევს ცარიელ დიაპაზონს, რომელიც კვლავ ექვემდებარება შემოწმებას ამ საბოლოო წერტილისთვის.
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// აბრუნებს `true`-ს, თუ `item` შეიცავს დიაპაზონს.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// ეს მეთოდი ყოველთვის ბრუნდება `false` გამეორების დასრულების შემდეგ:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // ზუსტი ველის მნიშვნელობები აქ არ არის განსაზღვრული
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// აბრუნებს `true` თუ დიაპაზონი არ შეიცავს ერთეულებს.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// დიაპაზონი ცარიელია, თუ რომელიმე მხარე შეუდარებელია:
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// ეს მეთოდი უბრუნებს `true` გამეორების დასრულების შემდეგ:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // ზუსტი ველის მნიშვნელობები აქ არ არის განსაზღვრული
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// დიაპაზონი შემოსაზღვრულია მხოლოდ (`..=end`) ზემოთ.
///
/// `RangeToInclusive` `..=end` შეიცავს ყველა მნიშვნელობას `x <= end`- ით.
/// ის ვერ იქნება [`Iterator`], რადგან მას არ აქვს ამოსავალი წერტილი.
///
/// # Examples
///
/// `..=end` სინტაქსი არის `RangeToInclusive`:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// მას არ აქვს [`IntoIterator`] განხორციელება, ასე რომ თქვენ პირდაპირ ვერ გამოიყენებთ `for` მარყუჟს.ეს არ შეიკრიბება:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// როდესაც გამოიყენება როგორც [slicing index], `RangeToInclusive` აწარმოებს მასივის ყველა ელემენტის ნაჭერს, `end`-ით მითითებულ ინდექსთან ერთად.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // ეს არის `RangeToInclusive`
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// დიაპაზონის ზედა ზღვარი (inclusive)
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// აბრუნებს `true`-ს, თუ `item` შეიცავს დიაპაზონს.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// RangeToInclusive<Idx>არ შეიძლება impl საწყისი <RangeTo<Idx>> რადგან ნაკადის დაწევა შესაძლებელი იქნებოდა (..0).into()- ით
//

/// გასაღებების სპექტრის წერტილი.
///
/// # Examples
///
/// `Bound`s არის დიაპაზონის საბოლოო წერტილები:
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// `Bound`s`-ის ტოლის გამოყენება [`BTreeMap::range`]-ის არგუმენტად.
/// გაითვალისწინეთ, რომ უმეტეს შემთხვევაში, ჯობია გამოიყენოთ დიაპაზონის სინტაქსი (`1..5`).
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// ინკლუზიური სავალდებულო.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// ექსკლუზიური შეკრული.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// უსასრულო საბოლოო წერტილი.მიუთითებს, რომ ამ მიმართულებით კავშირი არ არის.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// `&Bound<T>`-დან `Bound<&T>`-ზე გადადის.
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// `&mut Bound<T>`-დან `Bound<&T>`-ზე გადადის.
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// ასახეთ `Bound<&T>` `Bound<T>`-ზე შეკრული შინაარსის კლონირებით.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` ხორციელდება Rust-ის ჩაშენებული დიაპაზონის ტიპების მიერ, წარმოებული დიაპაზონის სინტაქსის საშუალებით, როგორიცაა `..`, `a..`, `..b`, `..=c`, `d..e` ან `f..=g`.
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// დაწყება ინდექსი სავალდებულოა.
    ///
    /// აბრუნებს საწყისი მნიშვნელობას `Bound`- ით.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// დაბოლოებულია ინდექსი.
    ///
    /// აბრუნებს საბოლოო მნიშვნელობას `Bound` სახით.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// აბრუნებს `true`-ს, თუ `item` შეიცავს დიაპაზონს.
    ///
    /// # Examples
    ///
    /// ```
    /// ამტკიცებენ! ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// ამტკიცებენ! ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // როდესაც იტერატორი ამოიწურება, ჩვენ ჩვეულებრივ გვაქვს start==end, მაგრამ ჩვენ გვინდა, რომ დიაპაზონი ცარიელი აღმოჩნდეს, არაფერი შეიცავდეს.
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}