/// trait `?` ოპერატორის ქცევის პერსონალურად მოსაწყობად.
///
/// `Try` განმახორციელებელი ტიპია ის, რომელსაც აქვს კანონიკური გზა მისი გადახედვისათვის success/failure დიქოტომიის თვალსაზრისით.
/// ეს trait საშუალებას იძლევა მოპოვებული იქნას წარმატების ან წარუმატებლობის მნიშვნელობები არსებული ინსტანციიდან და შეიქმნას ახალი ინსტანცია წარმატების ან წარუმატებლობის მნიშვნელობიდან.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// ამ მნიშვნელობის ტიპი წარმატებულად შეფასების შემთხვევაში.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// ამ მნიშვნელობის ტიპი ვერ ჩაითვლება.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// იყენებს "?" ოპერატორს.`Ok(t)`-ის დაბრუნება ნიშნავს, რომ შესრულება ჩვეულებრივ უნდა გაგრძელდეს და `?`-ის შედეგია `t` მნიშვნელობა.
    /// `Err(e)`-ის დაბრუნება ნიშნავს, რომ შესრულება უნდა branch შიგნით შემოსაზღვრულ `catch`-ზე, ან დაბრუნდეს ფუნქციიდან.
    ///
    /// თუ `Err(e)` შედეგი დაუბრუნდება, `e` მნიშვნელობა იქნება "wrapped" თანდართული მოცულობის დაბრუნების ტიპში (რომელიც თავად უნდა ახორციელებდეს `Try`).
    ///
    /// კერძოდ, `X::from_error(From::from(e))` მნიშვნელობა უბრუნდება, სადაც `X` არის თანდართული ფუნქციის დაბრუნების ტიპი.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// გადაიტანეთ შეცდომის მნიშვნელობა კომპოზიტური შედეგის შესაქმნელად.
    /// მაგალითად, `Result::Err(x)` და `Result::from_error(x)` ეკვივალენტურია.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// შეავსეთ კარგი მნიშვნელობა კომპოზიტური შედეგის შესაქმნელად.
    /// მაგალითად, `Result::Ok(x)` და `Result::from_ok(x)` ეკვივალენტურია.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}