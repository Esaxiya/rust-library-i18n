/// ზარის ოპერატორის ვერსია, რომელიც იღებს უცვლელ მიმღებს.
///
/// `Fn` ინსტანციებს შეიძლება განმეორებით ეწოდოს მუტაციის გარეშე.
///
/// *ეს trait (`Fn`) არ უნდა აგვერიოს [function pointers] (`fn`)- ში.*
///
/// `Fn` ხორციელდება ავტომატურად დახურვის საშუალებით, რომელიც მხოლოდ უცვლელ მითითებებს იღებს აღბეჭდილ ცვლადებზე ან საერთოდ არ აღბეჭდავს არაფერს, ისევე როგორც (safe) [function pointers] (ზოგიერთი სიფრთხილით, იხილეთ მათი დოკუმენტაცია მეტი ინფორმაციისთვის).
///
/// გარდა ამისა, ნებისმიერი ტიპის `F`, რომელიც ახორციელებს `Fn`-ს, `&F` ახორციელებს `Fn`-ს, ასევე.
///
/// რადგან [`FnMut`] და [`FnOnce`] არის `Fn` სუპერტრაიტი, `Fn` ნებისმიერი ინსტანცია შეიძლება გამოყენებულ იქნას როგორც პარამეტრი, სადაც მოსალოდნელია [`FnMut`] ან [`FnOnce`].
///
/// გამოიყენეთ `Fn` როგორც სავალდებულო, როდესაც გსურთ მიიღოთ ფუნქციის მსგავსი პარამეტრის პარამეტრი და მისი დარეკვა საჭიროა განმეორებით და მუტაციის გარეშე (მაგ., ერთდროულად დარეკვისას).
/// თუ ასეთი მკაცრი მოთხოვნები არ გჭირდებათ, გამოიყენეთ [`FnMut`] ან [`FnOnce`], როგორც საზღვრები.
///
/// იხილეთ [chapter on closures in *The Rust Programming Language*][book] ამ თემაზე მეტი ინფორმაციისთვის.
///
/// ასევე აღსანიშნავია სპეციალური სინტაქსი `Fn` traits- სთვის (მაგ
/// `Fn(usize, bool) -> გამოიყენეთ`).ამის ტექნიკური დეტალებით დაინტერესებულ პირებს შეუძლიათ მიმართონ [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## დახურვას ეძახის
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` პარამეტრის გამოყენება
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ისე, რომ regex დაეყრდნოს `&str: !FnMut`-ს
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// ასრულებს ზარის ოპერაციას.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// ზარის ოპერატორის ვერსია, რომელიც იღებს მუტაბელურ მიმღებს.
///
/// `FnMut` ინსტანციებს შეიძლება განმეორებით ეწოდოს და შეიძლება შეიცვალოს მდგომარეობა.
///
/// `FnMut` ხორციელდება ავტომატურად დახურვის საშუალებით, რომელიც იღებს ცვალებადი ცვლადების ცვალებად მითითებას, ისევე როგორც ყველა იმ ტიპს, რომელიც ახორციელებს [`Fn`]- ს, მაგ., (safe) [function pointers] (რადგან `FnMut` არის [`Fn`] ზედმეტი სრუტე).
/// გარდა ამისა, ნებისმიერი ტიპის `F`, რომელიც ახორციელებს `FnMut`-ს, `&mut F` ახორციელებს `FnMut`-ს, ასევე.
///
/// მას შემდეგ, რაც [`FnOnce`] არის სუპერტრაიტი `FnMut`, `FnMut` ნებისმიერი ინსტანცია შეიძლება გამოყენებულ იქნას იქ, სადაც მოსალოდნელია [`FnOnce`], და რადგან [`Fn`] არის `FnMut` ქვეტყი, [`Fn`] ნებისმიერი ინსტანციის გამოყენება შეიძლება იქ, სადაც მოსალოდნელია `FnMut`.
///
/// გამოიყენეთ `FnMut`, როგორც სავალდებულო, როდესაც გსურთ მიიღოთ ფუნქციის მსგავსი პარამეტრის პარამეტრი და საჭიროა მას განმეორებით დარეკვა, ხოლო მას საშუალებას მისცემს შეცვალოს მდგომარეობა.
/// თუ არ გსურთ პარამეტრის მუტაცია, გამოიყენეთ [`Fn`] როგორც შეკრული;თუ მასზე განმეორებით დარეკვა არ გჭირდებათ, გამოიყენეთ [`FnOnce`].
///
/// იხილეთ [chapter on closures in *The Rust Programming Language*][book] ამ თემაზე მეტი ინფორმაციისთვის.
///
/// ასევე აღსანიშნავია სპეციალური სინტაქსი `Fn` traits- სთვის (მაგ
/// `Fn(usize, bool) -> გამოიყენეთ`).ამის ტექნიკური დეტალებით დაინტერესებულ პირებს შეუძლიათ მიმართონ [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## მოუწოდებლად mutely აღების დახურვის
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` პარამეტრის გამოყენება
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ისე, რომ regex დაეყრდნოს `&str: !FnMut`-ს
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// ასრულებს ზარის ოპერაციას.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// ზარის ოპერატორის ვერსია, რომელიც იღებს ქვედა მნიშვნელობის მიმღებს.
///
/// `FnOnce` ინსტანციის გამოძახება შეიძლება, მაგრამ მისი აკრეფა რამდენჯერმე შეუძლებელია.ამის გამო, თუ ტიპის შესახებ მხოლოდ ის არის ცნობილი, რომ იგი ახორციელებს `FnOnce`-ს, მას მხოლოდ ერთხელ შეიძლება დარეკვა.
///
/// `FnOnce` ხორციელდება ავტომატურად იმ დახურვის საშუალებით, რომელიც შეიძლება მოიხმარდეს აღბეჭდილ ცვლადებს, ისევე როგორც ყველა იმ ტიპს, რომელიც ახორციელებს [`FnMut`]- ს, მაგ., (safe) [function pointers] (რადგან `FnOnce` არის სუპერტრაიტი [`FnMut`]).
///
///
/// მას შემდეგ, რაც ორივე [`Fn`] და [`FnMut`] არის `FnOnce` ქვეტრეიტები, [`Fn`] ან [`FnMut`] ნებისმიერი ინსტანციის გამოყენება შესაძლებელია იქ, სადაც მოსალოდნელია `FnOnce`.
///
/// გამოიყენეთ `FnOnce` როგორც სავალდებულო, როდესაც გსურთ მიიღოთ ფუნქციის მსგავსი პარამეტრის პარამეტრი და მხოლოდ ერთხელ დარეკვა გჭირდებათ.
/// თუ საჭიროა პარამეტრზე განმეორებით დარეკვა, გამოიყენეთ [`FnMut`], როგორც შეკრული;თუ ის ასევე გჭირდებათ, რომ არ მოხდეს მდგომარეობის მუტაცია, გამოიყენეთ [`Fn`].
///
/// იხილეთ [chapter on closures in *The Rust Programming Language*][book] ამ თემაზე მეტი ინფორმაციისთვის.
///
/// ასევე აღსანიშნავია სპეციალური სინტაქსი `Fn` traits- სთვის (მაგ
/// `Fn(usize, bool) -> გამოიყენეთ`).ამის ტექნიკური დეტალებით დაინტერესებულ პირებს შეუძლიათ მიმართონ [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` პარამეტრის გამოყენება
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` მოიხმარს მის აღბეჭდილ ცვლადებს, ამიტომ მისი გაშვება ერთზე მეტჯერ არ შეიძლება.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` კვლავ გამოძახების მცდელობა გამოიწვევს `use of moved value` შეცდომას `func`-სთვის.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ამ ეტაპზე აღარ შეიძლება გამოყენებული იქნას
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ისე, რომ regex დაეყრდნოს `&str: !FnMut`-ს
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// ზარის ოპერატორის გამოყენების შემდეგ დაბრუნებული ტიპი.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// ასრულებს ზარის ოპერაციას.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}