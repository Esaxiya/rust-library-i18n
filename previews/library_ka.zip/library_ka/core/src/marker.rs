//! პრიმიტიული traits და ტიპები, რომლებიც წარმოადგენს ტიპების ძირითად თვისებებს.
//!
//! Rust ტიპების კლასიფიკაცია შესაძლებელია სხვადასხვა სასარგებლო მეთოდით მათი შინაგანი თვისებების მიხედვით.
//! ეს კლასიფიკაცია წარმოდგენილია როგორც traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// ტიპები, რომელთა გადატანა შესაძლებელია ძაფის საზღვრებში.
///
/// ეს trait ავტომატურად ხორციელდება, როდესაც შემდგენელი განსაზღვრავს მის შესაბამისობას.
///
/// არა "გაგზავნის" ტიპის მაგალითია მითითების თვლის მაჩვენებელი [`rc::Rc`][`Rc`].
/// თუ ორი ძაფი ცდილობს ['Rc']-ს კლონირებას, რომელიც მიუთითებს იმავე მითითებით დათვლილ მნიშვნელობაზე, ისინი შეიძლება შეეცადონ განაახლონ მითითების რაოდენობა ერთდროულად, რაც [undefined behavior][ub] არის, რადგან [`Rc`] არ იყენებს ატომურ ოპერაციებს.
///
/// მისი ბიძაშვილი [`sync::Arc`][arc] იყენებს ატომურ ოპერაციებს (ზედნადები ხდება) და, შესაბამისად, არის `Send`.
///
/// დამატებითი ინფორმაციისთვის იხილეთ [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// ტიპები მუდმივი ზომით, რომლებიც ცნობილია შედგენის დროს.
///
/// ყველა ტიპის პარამეტრს აქვს ნაგულისხმევი `Sized` ველი.სპეციალური სინტაქსი `?Sized` შეიძლება გამოყენებულ იქნას ამ შებოჭილიდან ამოღების მიზნით, თუ ეს არ არის შესაბამისი.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // სტრუქტურა FooUse(Foo<[i32]>);//შეცდომა: ზომა არ არის დანერგილი [i32]- ისთვის
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// გამონაკლისი არის trait-ის ნაგულისხმევი `Self` ტიპი.
/// trait- ს არ აქვს ნაგულისხმევი `Sized` შეკრული, რადგან იგი შეუსაბამოა [trait ობიექტის] ობიექტებთან, სადაც, განსაზღვრებით, trait- ს სჭირდება მუშაობა ყველა შესაძლო განმახორციელებელთან და, შესაბამისად, იგი შეიძლება იყოს ნებისმიერი ზომის.
///
///
/// მიუხედავად იმისა, რომ Rust საშუალებას მოგცემთ დააკავშიროთ `Sized` trait-სთან, თქვენ მის გამოყენებას მოგვიანებით ვერ შეძლებთ trait ობიექტის შესაქმნელად:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // მოდით y: &dyn ბარი= &Impl;//შეცდომა: trait `Bar` არ შეიძლება გახდეს ობიექტი
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // მაგალითად, ნაგულისხმევისთვის, რომელიც მოითხოვს, რომ `[T]: !Default` შეფასდეს
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// ტიპები, რომლებიც შეიძლება იყოს "unsized" დინამიკური ზომის ტიპზე.
///
/// მაგალითად, ზომის მასივის ტიპი `[i8; 2]` ახორციელებს `Unsize<[i8]>` და `Unsize<dyn fmt::Debug>`.
///
/// `Unsize`- ის ყველა დანერგვა ავტომატურად მოწოდებულია შემდგენლის მიერ.
///
/// `Unsize` ხორციელდება:
///
/// - `[T; N]` არის `Unsize<[T]>`
/// - `T` არის `Unsize<dyn Trait>`, როდესაც `T: Trait`
/// - `Foo<..., T, ...>` არის `Unsize<Foo<..., U, ...>>` თუ:
///   - `T: Unsize<U>`
///   - Foo არის სტრუქტურა
///   - `Foo`- ის მხოლოდ ბოლო ველს აქვს `T`- ის ტიპი
///   - `T` არ არის სხვა სფეროების ტიპის ნაწილი
///   - `Bar<T>: Unsize<Bar<U>>`, თუ `Foo`-ის ბოლო ველს აქვს `Bar<T>` ტიპი
///
/// `Unsize` გამოიყენება [`ops::CoerceUnsized`]-სთან ერთად, რათა "user-defined" კონტეინერები, როგორიცაა [`Rc`], შეიცავდეს დინამიურად ზომის ტიპებს.
/// დამატებითი ინფორმაციისთვის იხილეთ [DST coercion RFC][RFC982] და [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// საჭიროა trait იმ კონსტანტებისთვის, რომლებიც გამოიყენება ნიმუშების თანხვედრაში.
///
/// ნებისმიერი ტიპი, რომელიც იღებს `PartialEq`-ს, ავტომატურად ახორციელებს ამ trait-ს, * იმისდა მიუხედავად, აქვს თუ არა მისი ტიპის პარამეტრები `Eq`-ს.
///
/// თუ `const` ელემენტი შეიცავს ზოგიერთ ტიპს, რომელიც არ ახორციელებს ამ trait-ს, მაშინ ეს ტიპი ან (1.) არ ახორციელებს `PartialEq`-ს (რაც ნიშნავს, რომ მუდმივი არ იძლევა შედარების იმ მეთოდს, რომლის კოდის წარმოქმნა ვარაუდობს, რომ შესაძლებელია), ან (2.) იგი ახორციელებს *საკუთარ*`PartialEq` ვერსია (რომელიც, ჩვენი აზრით, არ შეესაბამება სტრუქტურულ-თანასწორობის შედარებას).
///
///
/// ზემოთ მოცემულ ორ სცენარში ან ერთში, ჩვენ უარვყოფთ ასეთი მუდმივის გამოყენებას ნიმუშის შესატყვისობაში.
///
/// აგრეთვე [structural match RFC][RFC1445] და [issue 63438], რომლებიც ატრიბუტებზე დაფუძნებული დიზაინიდან ამ trait- ზე გადადიან.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// საჭიროა trait იმ კონსტანტებისთვის, რომლებიც გამოიყენება ნიმუშების თანხვედრაში.
///
/// ნებისმიერი ტიპი, რომელიც იღებს `Eq`-ს, ავტომატურად ახორციელებს ამ trait-ს, * მიუხედავად იმისა, არის თუ არა მისი ტიპის პარამეტრები `Eq`.
///
/// ეს არის ჰაკი, რომელიც მუშაობს ჩვენი ტიპის სისტემის შეზღუდვების გარშემო.
///
/// # Background
///
/// ჩვენ გვინდა მოვითხოვოთ, რომ კონსტების ტიპებს, რომლებსაც იყენებენ ნიმუშების შესატყვისებში, აქვთ ატრიბუტი `#[derive(PartialEq, Eq)]`.
///
/// უფრო იდეალურ სამყაროში, ჩვენ შეგვიძლია შეამოწმოთ ეს მოთხოვნა მხოლოდ იმის შემოწმებით, რომ მოცემული ტიპი ახორციელებს როგორც `StructuralPartialEq` trait *და*`Eq` trait.
/// ამასთან, თქვენ შეიძლება გქონდეთ ADT, რომელიც *აკეთებს*`derive(PartialEq, Eq)`, და ის შემთხვევაა, რომლის მიღებაც გვსურს შემდგენელმა, მაგრამ მუდმივის ტიპი ვერ ახორციელებს `Eq`- ს განხორციელებას.
///
/// კერძოდ, მსგავსი შემთხვევა:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (ზემოხსენებულ კოდში პრობლემაა ის, რომ `Wrap<fn(&())>` არ ახორციელებს `PartialEq`-ს და არც `Eq`-ს, რადგან "for <" a> fn(&'a _)` does not implement those traits.)
///
/// ამიტომ, ჩვენ არ შეგვიძლია დავეყრდნოთ გულუბრყვილო შემოწმებას `StructuralPartialEq` და მხოლოდ `Eq`.
///
/// ამის გასარკვევად, ჩვენ ვიყენებთ ორ ცალკეულ traits-ს, რომელსაც გაუკეთეს თითოეული ორი (`#[derive(PartialEq)]` და `#[derive(Eq)]`) და ვამოწმებთ, რომ ორივე მათგანი იმყოფება სტრუქტურული შესატყვისობის შემოწმების ფარგლებში.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// ტიპები, რომელთა მნიშვნელობების დუბლირება შესაძლებელია მხოლოდ ბიტების კოპირებით.
///
/// ნაგულისხმევად, ცვლადის სავალდებულოებს აქვთ " მოძრავი სემანტიკა`.Სხვა სიტყვებით:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` გადავიდა `y`-ში და მისი გამოყენება შეუძლებელია
///
/// // println! ("{: ?}", x);//შეცდომა: გადატანილი მნიშვნელობის გამოყენება
/// ```
///
/// ამასთან, თუ ტიპი ახორციელებს `Copy`-ს, მას აქვს "ასლის სემანტიკა":
///
/// ```
/// // ჩვენ შეგვიძლია გამოვიყვანოთ `Copy` განხორციელება.
/// // `Clone` ასევე საჭიროა, რადგან ეს არის სუპერტრაიტი `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` არის `x`-ის ასლი
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// მნიშვნელოვანია აღინიშნოს, რომ ამ ორ მაგალითში განსხვავება მხოლოდ ისაა, დაუშვებელია თუ არა წვდომა `x` დავალების შემდეგ.
/// კაპოტის ქვეშ, როგორც ასლი, ისე გადაადგილება შეიძლება გამოიწვიოს ბიტების მეხსიერებაში კოპირებას, თუმცა ზოგჯერ ეს ოპტიმიზირებულია.
///
/// ## როგორ შემიძლია განვახორციელო `Copy`?
///
/// თქვენს ტიპის `Copy` დანერგვის ორი გზა არსებობს.უმარტივესი არის `derive`-ის გამოყენება:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// ასევე შეგიძლიათ ხელით დანერგოთ `Copy` და `Clone`:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// ამ ორს შორის მცირე განსხვავებაა: `derive` სტრატეგიაში ასევე განთავსდება `Copy` მიბმული ტიპის პარამეტრებზე, რაც ყოველთვის არ არის სასურველი.
///
/// ## რა განსხვავებაა `Copy` და `Clone` შორის?
///
/// ასლები ხდება არაპირდაპირი გზით, მაგალითად, `y = x` დავალების ნაწილი.`Copy` ქცევა არ არის გადატვირთული;ეს ყოველთვის არის მარტივი ბიტუმიანი ასლი.
///
/// კლონირება არის აშკარა მოქმედება, `x.clone()`.[`Clone`]- ის დანერგვამ შეიძლება უზრუნველყოს ნებისმიერი ტიპის სპეციფიკური ქცევა, რომელიც აუცილებელია მნიშვნელობების უსაფრთხოდ დუბლირებისთვის.
/// მაგალითად, [`Clone`]- ის [`String`]- ს დანერგვამ საჭიროა მწკრივში მითითებული სტრიქონის ბუფერის კოპირება.
/// [`String`] მნიშვნელობების მარტივი ბიტიური ასლი მხოლოდ კოპირებას ახდენს, რაც ხაზში გაორმაგდება.
/// ამ მიზეზით, [`String`] არის [`Clone`], მაგრამ არა `Copy`.
///
/// [`Clone`] არის `Copy` სუპერტრაიტი, ამიტომ ყველაფერი, რაც `Copy` არის, ასევე უნდა ახორციელებდეს [`Clone`].
/// თუ ტიპი არის `Copy`, მაშინ მისი [`Clone`] დანერგვა მხოლოდ `*self`-ის დაბრუნებას საჭიროებს (იხილეთ ზემოთ მოყვანილი მაგალითი).
///
/// ## როდის შეიძლება ჩემი ტიპი იყოს `Copy`?
///
/// ტიპს შეუძლია `Copy`-ის დანერგვა, თუ მისი ყველა კომპონენტი ახდენს `Copy`-ის დანერგვას.მაგალითად, ეს სტრუქტურა შეიძლება იყოს `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// სტრუქტურა შეიძლება იყოს `Copy` და [`i32`] არის `Copy`, ამიტომ `Point` უფლებამოსილია იყოს `Copy`.
/// ამის საპირისპიროდ, გაითვალისწინეთ
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` სტრუქტურას არ შეუძლია `Copy` დანერგოს, რადგან [`Vec<T>`] არ არის `Copy`.თუ ჩვენ ვცდილობთ გამოვიყენოთ `Copy` დანერგვა, მივიღებთ შეცდომას:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// გაზიარებული ცნობები (`&T`) ასევე არის `Copy`, ამიტომ ტიპი შეიძლება იყოს `Copy`, მაშინაც კი, თუ ის ინახავს `T` ტიპის გაზიარებულ ცნობებს, რომლებიც *არ არის*`Copy`.
/// გაითვალისწინეთ შემდეგი სტრუქტურა, რომელსაც შეუძლია `Copy`-ის დანერგვა, რადგან იგი შეიცავს მხოლოდ *გაზიარებულ მითითებას* ჩვენი არაკოპირებული ტიპის `PointList` ზემოდან:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## როდის *არ შეიძლება* ჩემი ტიპი იყოს `Copy`?
///
/// ზოგიერთი ტიპის უსაფრთხო გადაწერა შეუძლებელია.მაგალითად, `&mut T`- ის კოპირება ქმნის alias mutable მითითებას.
/// [`String`] კოპირება პასუხისმგებლობას გაუტოლდება [`სიმებიანი`] ბუფერის მართვაზე, რაც ორმაგად უფასო გახდება.
///
/// ამ საქმის განზოგადება, ნებისმიერი ტიპის [`Drop`] განმახორციელებელი არ შეიძლება იყოს `Copy`, რადგან ის მართავს გარკვეულ რესურსს, გარდა საკუთარი [`size_of::<T>`] ბაიტისა.
///
/// თუ თქვენ ცდილობთ `Copy` დანერგოთ არა-კოპირებული მონაცემების შემცველ სტრუქტურაზე ან enum-ზე, თქვენ მიიღებთ შეცდომას [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## როდის *ჩემი* უნდა იყოს `Copy`?
///
/// საერთოდ, თუ თქვენი ტიპი _can_ ახორციელებს `Copy`-ს, ეს ასეც უნდა მოხდეს.
/// გაითვალისწინეთ, რომ `Copy`- ის განხორციელება თქვენი ტიპის საჯარო API- ს ნაწილია.
/// თუ ტიპი future- ში შეიძლება გახდეს არა - კოპირება, ეს შეიძლება იყოს გონივრული, რომ ახლა `Copy` დანერგვა გამოტოვოთ, API- ს დარღვევის თავიდან ასაცილებლად.
///
/// ## დამატებითი განმახორციელებლები
///
/// [implementors listed below][impls]-ის გარდა, შემდეგი ტიპები ასევე ახორციელებენ `Copy`-ს:
///
/// * ფუნქციის ელემენტის ტიპები (ე.ი. თითოეული ფუნქციისთვის განსაზღვრული მკაფიო ტიპები)
/// * ფუნქციის მაჩვენებლის ტიპები (მაგ., `fn() -> i32`)
/// * მასივის ტიპები, ყველა ზომისთვის, თუ საქონლის ტიპი ასევე ახორციელებს `Copy`-ს (მაგ., `[i32; 123456]`)
/// * მრავალრიცხოვანი ტიპები, თუ თითოეული კომპონენტი ასევე ახორციელებს `Copy`-ს (მაგ., `()`, `(i32, bool)`)
/// * დახურვის ტიპები, თუ ისინი არავითარ მნიშვნელობას არ იპყრობენ გარემოდან ან თუ ყველა ასეთი აღებული მნიშვნელობები თავად ახორციელებს `Copy`-ს.
///   გაითვალისწინეთ, რომ გაზიარებული ცნობარის მიერ აღბეჭდილი ცვლადები ყოველთვის ახორციელებენ `Copy`-ს (მაშინაც კი, თუ რეფერენტი არ იყენებს), ხოლო ცვლადი ცნობის მიერ აღებული ცვლადები არასოდეს ახორციელებენ `Copy`-ს.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) ეს საშუალებას გვაძლევს დააკოპიროთ ტიპი, რომელიც არ ახორციელებს `Copy`- ს, სიცოცხლის განმავლობაში დაუკმაყოფილებელი საზღვრების გამო (კოპირება `A<'_>` მხოლოდ `A<'static>: Copy` და `A<'_>: Clone`).
// ეს ატრიბუტი აქ ახლა გვაქვს მხოლოდ იმიტომ, რომ `Copy`- ზე არსებობს უამრავი სპეციალიზაცია, რომლებიც სტანდარტულ ბიბლიოთეკაში უკვე არსებობს და ამ ქცევის უსაფრთხოდ გამოყენების საშუალება ახლა არ არსებობს.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy`-ის გავლენის წარმოქმნის მაკრო.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// ტიპები, რომელთათვისაც უსაფრთხოა ცნობების გაზიარება ძაფებს შორის.
///
/// ეს trait ავტომატურად ხორციელდება, როდესაც შემდგენელი განსაზღვრავს მის შესაბამისობას.
///
/// ზუსტი განმარტებაა: ტიპი `T` არის [`Sync`] თუ და მხოლოდ იმ შემთხვევაში, თუ `&T` არის [`Send`].
/// სხვა სიტყვებით რომ ვთქვათ, თუ ძაფებს შორის `&T` მითითების გავლისას არ არსებობს [undefined behavior][ub] (მონაცემთა რასის ჩათვლით) შესაძლებლობა.
///
/// როგორც მოველოდით, პრიმიტიული ტიპები, როგორიცაა [`u8`] და [`f64`], ყველანი [`Sync`] არიან და ასევე მარტივი აგრეგატული ტიპები, რომლებიც შეიცავს მათ, მაგალითად, ტიპები, სტრიქონები და ენუმები.
/// [`Sync`] ძირითადი ტიპების სხვა მაგალითებში შედის "immutable" ტიპები, როგორიცაა `&T`, და ისეთებიც, რომლებსაც აქვთ მარტივი მემკვიდრეობითი ცვალებადობა, როგორიცაა [`Box<T>`][box], [`Vec<T>`][vec] და სხვა მრავალი კოლექციის ტიპი.
///
/// (ზოგადი პარამეტრები უნდა იყოს [`Sync`], რომ მათი კონტეინერი [`სინქრონიზაცია`] იყოს.)
///
/// განმარტების გარკვეულწილად გასაკვირი შედეგია ის, რომ `&mut T` არის `Sync` (თუ `T` არის `Sync`) მიუხედავად იმისა, რომ როგორც ჩანს, ამან შეიძლება უზრუნველყოს არასინქრონიზებული მუტაცია.
/// ხრიკია ის, რომ საზიარო მითითების (ანუ `& &mut T`) მიღმა ცვლადი მითითება ხდება მხოლოდ წაკითხვისთვის, თითქოს ეს იყოს `& &T`.
/// ამრიგად, მონაცემთა შეჯიბრის რისკი არ არსებობს.
///
/// ისეთი ტიპები, რომლებიც არ არიან `Sync`, არის ისეთები, რომელთაც აქვთ "interior mutability" არა ძაფისგან დაცული ფორმით, როგორიცაა [`Cell`][cell] და [`RefCell`][refcell].
/// ამ ტიპების საშუალებით შესაძლებელია მათი შინაარსის მუტაცია შეუცვლელი, გაზიარებული მითითების საშუალებითაც.
/// მაგალითად, `set` მეთოდი [`Cell<T>`][cell]- ზე იღებს `&self`- ს, ამიტომ ის მხოლოდ გაზიარებულ მითითებას [`&Cell<T>`][cell] სჭირდება.
/// მეთოდი არ ასრულებს სინქრონიზაციას, ამიტომ [`Cell`][cell] არ შეიძლება იყოს `Sync`.
///
/// არა-სინქრონიზირებული ტიპის კიდევ ერთი მაგალითია მითითების თვლის მაჩვენებელი [`Rc`][rc].
/// ნებისმიერი მითითების [`&Rc<T>`][rc] გათვალისწინებით, თქვენ შეგიძლიათ კლონირება მოახდინოთ ახალი [`Rc<T>`][rc], შეცვალოთ მითითებების რაოდენობა არაატომური გზით.
///
/// იმ შემთხვევებისთვის, როდესაც საჭიროა შინაგან მუწუკების უსაფრთხო დაცვა, Rust უზრუნველყოფს [atomic data types] და ასევე მკაფიოდ დაბლოკვას [`sync::Mutex`][mutex] და [`sync::RwLock`][rwlock] საშუალებით.
/// ეს ტიპები უზრუნველყოფენ, რომ ნებისმიერმა მუტაციამ არ შეიძლება გამოიწვიოს მონაცემთა რასის გამოწვევა, შესაბამისად, ტიპები არის `Sync`.
/// ანალოგიურად, [`sync::Arc`][arc] უზრუნველყოფს ძაფის დაცვით [`Rc`][rc] ანალოგს.
///
/// შინაგან მუტაბელურობის მქონე ყველა ტიპმა ასევე უნდა გამოიყენოს [`cell::UnsafeCell`][unsafecell] შესაფუთი value(s) ირგვლივ, რომლის მუტირება შესაძლებელია საერთო მითითების საშუალებით.
/// ვერ შესრულდება ეს არის [undefined behavior][ub].
/// მაგალითად, ['transmute `][transmute]-ing `&T`-დან `&mut T` არასწორია.
///
/// იხილეთ [the Nomicon][nomicon-send-and-sync] მეტი ინფორმაცია `Sync`- ს შესახებ.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): ერთხელ მხარდაჭერა დაამატოთ შენიშვნები `rustc_on_unimplemented` მიწაში ბეტა რეჟიმში, და იგი გაფართოვდა იმის შესამოწმებლად, არის თუ არა დახურვა სადმე მოთხოვნის ჯაჭვში, გააგრძელეთ იგი, როგორც ასეთი (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// ნულოვანი ტიპის ტიპი გამოიყენება ისეთი საგნების აღსანიშნავად, რომ "act like" მათ `T` ფლობენ.
///
/// `PhantomData<T>` ველის დამატება თქვენს ტიპზე ეუბნება შემდგენელს, რომ თქვენი ტიპი მოქმედებს ისე, თითქოს ინახავს `T` ტიპის მნიშვნელობას, მიუხედავად იმისა, რომ სინამდვილეში ეს არ არის.
/// ეს ინფორმაცია გამოიყენება უსაფრთხოების გარკვეული მახასიათებლების გამოთვლისას.
///
/// `PhantomData<T>`-ის გამოყენების შესახებ უფრო ღრმად განმარტეთ, იხილეთ [the Nomicon](../../nomicon/phantom-data.html).
///
/// # ამაზრზენი შენიშვნა
///
/// მიუხედავად იმისა, რომ მათ ორივეს საშინელი სახელი აქვთ, `PhantomData` და "მოჩვენებითი ტიპები" ნათესაური ურთიერთობებია, მაგრამ არა იდენტური.ფანტომური ტიპის პარამეტრი უბრალოდ ტიპის პარამეტრია, რომელიც არასდროს გამოიყენება.
/// Rust- ში, ეს ხშირად იწვევს შემდგენლის პრეტენზიებს და გამოსავალია X001- ის გამოყენებით "dummy" გამოყენების დამატება.
///
/// # Examples
///
/// ## სიცოცხლის გამოუყენებელი პარამეტრები
///
/// `PhantomData`- ს ალბათ ყველაზე ხშირად გამოყენებული შემთხვევაა სტრუქტურა, რომელსაც აქვს გამოუყენებელი სიცოცხლის პარამეტრი, როგორც წესი, ზოგიერთი არაუსაფრთხო კოდის ნაწილი.
/// მაგალითად, აქ არის `Slice` სტრუქტურა, რომელსაც აქვს `*const T` ტიპის ორი მანიშნებელი, სავარაუდოდ მითითებულია მასივში სადმე:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// მიზანი ისაა, რომ ძირითადი მონაცემები მოქმედებს მხოლოდ სიცოცხლის განმავლობაში `'a`, ამიტომ `Slice` არ უნდა აღემატებოდეს `'a`-ს.
/// ამასთან, ეს განზრახვა კოდექსში არ არის გამოხატული, ვინაიდან არ არსებობს სიცოცხლის განმავლობაში გამოყენებული `'a` და, შესაბამისად, გაუგებარია რა მონაცემებს ის ეხება.
/// ამის გამოსწორება შეგვიძლია, შემდგენელს ვუთხრათ მოიქცეს *ისე, თითქოს*`Slice` სტრუქტურა შეიცავს მითითებას `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// ეს თავის მხრივ მოითხოვს `T: 'a` ანოტაციას, რაც მიუთითებს იმაზე, რომ `T`- ში ნებისმიერი მითითება მოქმედებს `'a` სიცოცხლის განმავლობაში.
///
/// `Slice` ინიციალიზაციისას თქვენ უბრალოდ მიუთითებთ `PhantomData` მნიშვნელობას `phantom` ველისთვის:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## გამოუყენებელი ტიპის პარამეტრები
///
/// ზოგჯერ ხდება ისე, რომ თქვენ გაქვთ გამოუყენებელი ტიპის პარამეტრები, რომლებიც მიუთითებს, თუ რომელი ტიპის მონაცემებს წარმოადგენს სტრუქტურა "tied", მიუხედავად იმისა, რომ ეს მონაცემები თავად სტრუქტურაში არ არის ნაპოვნი.
/// აქ არის მაგალითი, სადაც ეს წარმოიქმნება [FFI]-ით.
/// უცხო ინტერფეისი იყენებს `*mut ()` ტიპის სახელურებს, სხვადასხვა ტიპის Rust მნიშვნელობებზე გადასასვლელად.
/// ჩვენ თვალყურს ვადევნებთ Rust ტიპს ფანტომური ტიპის პარამეტრის გამოყენებით სტრუქტურულ `ExternalResource`- ზე, რომელიც ახვევს სახელურს.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## მფლობელობა და ვარდნა
///
/// `PhantomData<T>` ტიპის ველის დამატება მიუთითებს, რომ თქვენი ტიპი ფლობს `T` ტიპის მონაცემებს.ეს თავის მხრივ გულისხმობს, რომ როდესაც თქვენი ტიპი დაეცემა, მას შეუძლია ჩამოაგდოს `T` ტიპის ერთი ან მეტი მაგალითი.
/// ეს გავლენას ახდენს Rust შემდგენლის [drop check] ანალიზზე.
///
/// თუ თქვენი სტრუქტურა ნამდვილად არ ფლობს *`T` ტიპის მონაცემებს, უმჯობესია გამოიყენოთ მითითების ტიპი, მაგალითად `PhantomData<&'a T>` (ideally) ან `PhantomData<* const T>` (თუ სიცოცხლის ხანგრძლივობა არ ვრცელდება), ისე რომ არ მიუთითოთ საკუთრების უფლება.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// შემდგენელი შიდა trait გამოიყენება enum დისკრიმინატორების ტიპის აღსადგენად.
///
/// ეს trait ავტომატურად ხორციელდება ყველა ტიპისთვის და [`mem::Discriminant`]- ს არ აძლევს რაიმე გარანტიას.
/// ეს არის **განუსაზღვრელი ქცევა** ტრანსპორტირება `DiscriminantKind::Discriminant` და `mem::Discriminant` შორის.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// დისკრიმინაციის ტიპი, რომელიც უნდა აკმაყოფილებდეს 0trait bounds, რომელიც მოითხოვს `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// შემდგენელი შიდა trait გამოიყენება იმის დასადგენად, შეიცავს თუ არა ტიპი რაიმე შინაარსს `UnsafeCell`, მაგრამ არა indirection.
///
/// ეს გავლენას ახდენს, მაგალითად, მოთავსებულია თუ არა ამ ტიპის `static` მხოლოდ წასაკითხი სტატიკურ მეხსიერებაში ან დაწერილი სტატიკური მეხსიერება.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// ტიპები, რომელთა უსაფრთხო გადატანა შეიძლება ჩამაგრების შემდეგ.
///
/// Rust თავისთავად არ აქვს ცნება უძრავი ტიპების შესახებ და მიიჩნევს, რომ მოძრაობები (მაგ., დავალების მეშვეობით ან [`mem::replace`]) ყოველთვის უსაფრთხოა.
///
/// ამის ნაცვლად გამოიყენება [`Pin`][Pin] ტიპი ტიპის სისტემაში გადაადგილების თავიდან ასაცილებლად.[`Pin<P<T>>`][Pin] შეფუთვაში გახვეული მითითებების `P<T>` გადატანა შეუძლებელია.
/// დამაგრების შესახებ დამატებითი ინფორმაციისთვის იხილეთ [`pin` module] დოკუმენტაცია.
///
/// `Unpin` trait-ის განხორციელება `T`-სთვის მოხსნის შეზღუდვებს ტიპის ჩამოტვირთვისას, რაც შემდეგ საშუალებას გვაძლევს `T` გადაადგილდეს [`Pin<P<T>>`][Pin]-დან ისეთი ფუნქციებით, როგორიცაა [`mem::replace`].
///
///
/// `Unpin` საერთოდ არ აქვს არანაირი შედეგი არაპინფიცირებულ მონაცემებს.
/// კერძოდ, [`mem::replace`] სიხარულით გადააქვს `!Unpin` მონაცემები (ის მუშაობს ნებისმიერ `&mut T`- ზე, არა მხოლოდ `T: Unpin`- ზე).
/// ამასთან, თქვენ არ შეგიძლიათ გამოიყენოთ [`mem::replace`] [`Pin<P<T>>`][Pin] შიგნით შეფუთულ მონაცემებზე, რადგან ვერ მიიღებთ თქვენთვის საჭირო `&mut T`, და *ეს* არის ის, რაც ამ სისტემას მუშაობს.
///
/// მაგალითად, ეს შეიძლება გაკეთდეს მხოლოდ `Unpin`-ის განმახორციელებელ ტიპებზე:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // ჩვენ გვჭირდება mutable მითითება `mem::replace` დარეკვისთვის.
/// // ასეთი მითითების მიღება შეგვიძლია (implicitly)- ით `Pin::deref_mut`- ის გამოყენებით, მაგრამ ეს მხოლოდ იმიტომ არის შესაძლებელი, რომ `String` ახორციელებს `Unpin`- ს.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// ეს trait ავტომატურად ხორციელდება თითქმის ყველა ტიპისთვის.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// მარკერის ტიპი, რომელიც არ ახორციელებს `Unpin`-ს.
///
/// თუ ტიპი შეიცავს `PhantomPinned`-ს, ის სტანდარტულად არ განახორციელებს `Unpin`-ს.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// `Copy`- ის დანერგვები პრიმიტიული ტიპებისთვის.
///
/// იმპლემენტაციები, რომელთა აღწერა არ შეიძლება Rust- ში, ხორციელდება `traits::SelectionContext::copy_clone_conditions()`- ში `rustc_trait_selection`- ში.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// გაზიარებული ცნობების კოპირება შესაძლებელია, მაგრამ ცვლადი ცნობების * * არ * შესაძლებელია!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}