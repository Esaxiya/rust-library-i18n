//! ეს მოდული ახორციელებს `Any` trait-ს, რაც საშუალებას იძლევა ნებისმიერი ტიპის `'static` ტიპის დინამიური აკრეფა ასახვის დროს.
//!
//! `Any` თავისთავად შეიძლება გამოყენებულ იქნას `TypeId`-ის მისაღებად და აქვს მეტი ფუნქცია, როდესაც იგი გამოიყენება trait ობიექტად.
//! როგორც `&dyn Any` (ნასესხები trait ობიექტი), მას აქვს `is` და `downcast_ref` მეთოდები, რომ შეამოწმოს არის თუ არა მოცემული ტიპის მოცემული ტიპი და მიიღოს მითითება შიდა მნიშვნელობის ტიპად.
//! როგორც `&mut dyn Any`, ასევე არსებობს `downcast_mut` მეთოდი, შინაგანი მნიშვნელობის ცვალებადი მითითების მისაღებად.
//! `Box<dyn Any>` ამატებს `downcast` მეთოდს, რომელიც `Box<T>`- ზე გადაკეთებას ცდილობს.
//! სრული ინფორმაციისთვის იხილეთ [`Box`] დოკუმენტაცია.
//!
//! გაითვალისწინეთ, რომ `&dyn Any` შემოიფარგლება თუ არა მნიშვნელობა განსაზღვრული ბეტონის ტიპისა და მისი გამოყენება არ შეიძლება იმისთვის, რომ შეამოწმოთ, ახორციელებს თუ არა ტიპი trait-ს.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # ჭკვიანი მითითებები და `dyn Any`
//!
//! ქცევის ერთი ნაწილი, რომელიც უნდა გახსოვდეთ, როდესაც იყენებთ `Any` trait ობიექტად, განსაკუთრებით ისეთ ტიპებში, როგორიცაა `Box<dyn Any>` ან `Arc<dyn Any>`, არის ის, რომ უბრალოდ `.type_id()` მნიშვნელობით დარეკვით წარმოიქმნება *კონტეინერის*`TypeId` და არა trait ობიექტის საფუძველი.
//!
//! ამის თავიდან აცილება შესაძლებელია ჭკვიანი მაჩვენებლის `&dyn Any`-ად გადაქცევით, რაც დაუბრუნებს ობიექტის `TypeId`-ს.
//! Მაგალითად:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // თქვენ ეს უფრო მოგინდებათ:
//! let actual_id = (&*boxed).type_id();
//! // ... ვიდრე ეს:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! განვიხილოთ სიტუაცია, როდესაც გვინდა გამოვყოთ ფუნქციაზე გადატანილი მნიშვნელობა.
//! ჩვენ ვიცით, რა მნიშვნელობაზეც ვმუშაობთ, ახორციელებს Debug-ს, მაგრამ არ ვიცით მისი კონკრეტული ტიპი.ჩვენ გვინდა, რომ განსაკუთრებული მკურნალობა დავუთმოთ გარკვეულ ტიპებს: ამ შემთხვევაში String მნიშვნელობების სიგრძის დაბეჭდვა მათი მნიშვნელობამდე.
//! ჩვენ არ ვიცით ჩვენი მნიშვნელობის კონკრეტული ტიპი შედგენის დროს, ამიტომ ამის ნაცვლად უნდა გამოვიყენოთ ხანგრძლივობის რეფლექსია.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger ფუნქცია ნებისმიერი ტიპისთვის, რომელიც ახორციელებს Debug-ს.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // შეეცადეთ ჩვენი მნიშვნელობა გადააკეთოთ `String`.
//!     // წარმატების შემთხვევაში, ჩვენ გვსურს გამოვყოთ String`-ის სიგრძე და ასევე მისი მნიშვნელობა.
//!     // თუ არა, ეს სხვა ტიპისაა: უბრალოდ დაბეჭდეთ იგი გარეშე მორთული.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // ამ ფუნქციას უნდა მოაწეროს თავისი პარამეტრი მასთან მუშაობის დაწყებამდე.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... სხვა საქმის შესრულება
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// ნებისმიერი trait
///////////////////////////////////////////////////////////////////////////////

/// trait დინამიური აკრეფის იმიტაციისთვის.
///
/// ტიპების უმეტესობა ახორციელებს `Any`-ს.ამასთან, ნებისმიერი ტიპი, რომელიც შეიცავს არასტატიკური სტატიას, არ შეიცავს.
/// დამატებითი ინფორმაციისთვის იხილეთ [module-level documentation][mod].
///
/// [mod]: crate::any
// ეს trait არ არის სახიფათო, თუმცა ჩვენ ვეყრდნობით მისი ერთადერთი impl's `type_id` ფუნქციის სპეციფიკას არაუსაფრთხო კოდში (მაგ., `downcast`).ჩვეულებრივ, ეს პრობლემა იქნებოდა, მაგრამ იმის გამო, რომ `Any`-ის ერთადერთი გავლენა არის პლედის განხორციელება, სხვა კოდს არ შეუძლია `Any`-ის განხორციელება.
//
// ჩვენ შეგვიძლია, სავარაუდოდ, ეს trait არაუსაფრთხო გახდეს-ეს არ გამოიწვევს მოტეხილობას, ვინაიდან ჩვენ ვაკონტროლებთ ყველა იმპლემენტაციას-მაგრამ ჩვენ ვირჩევთ ამას, რადგან ეს არც არის საჭირო და შესაძლოა მომხმარებლებს აღრეულიყოს არასაიმედო traits და სახიფათო მეთოდების განმასხვავებლად (მაგ., `type_id` დარეკვა მაინც უსაფრთხო იქნებოდა, მაგრამ ჩვენ, სავარაუდოდ, გვინდა მითითებული იყოს დოკუმენტაციაში).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// იღებს `self`-ის `TypeId`-ს.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// გაფართოების მეთოდები ნებისმიერი trait ობიექტისთვის.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// დარწმუნდით, რომ ძაფის შეერთების შედეგი შეიძლება დაბეჭდილი იყოს და ამიტომ გამოიყენოთ `unwrap`.
// საბოლოოდ შეიძლება აღარ იყოს საჭირო, თუ დისპეტჩერი მუშაობს გაუმჯობესებასთან.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// აბრუნებს `true`-ს, თუ უჯრის ტიპი იგივეა, რაც `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // მიიღეთ `TypeId` ტიპის, რომლითაც ამ ფუნქციას ასრულებენ.
        let t = TypeId::of::<T>();

        // მიიღეთ ტიპის `TypeId` trait ობიექტში (`self`).
        let concrete = self.type_id();

        // შეადარე ორივე `TypeId` თანასწორობაზე.
        t == concrete
    }

    /// აბრუნებს გარკვეულ მითითებას უჯრაში მოცემულ მნიშვნელობას, თუ ის `T` ტიპისაა, ან `None` თუ არა.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // უსაფრთხოება: ახლახანს გადავამოწმეთ, მივუთითებთ თუ არა სწორ ტიპს და შეიძლება ვენდოთ მას
            // რომ გადაამოწმონ მეხსიერების უსაფრთხოება, რადგან ჩვენ განვახორციელეთ ნებისმიერი ნებისმიერი ტიპისთვის;სხვა იმპულსების არსებობა არ შეიძლება, რადგან ისინი ეწინააღმდეგებიან ჩვენს გავლენას.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// აბრუნებს გარკვეულ მუტაბელურ მითითებას უჯრაში მოცემულ მნიშვნელობას, თუ ის `T` ტიპისაა, ან `None` თუ არა.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // უსაფრთხოება: ახლახანს გადავამოწმეთ, მივუთითებთ თუ არა სწორ ტიპს და შეიძლება ვენდოთ მას
            // რომ გადაამოწმონ მეხსიერების უსაფრთხოება, რადგან ჩვენ განვახორციელეთ ნებისმიერი ნებისმიერი ტიპისთვის;სხვა იმპულსების არსებობა არ შეიძლება, რადგან ისინი ეწინააღმდეგებიან ჩვენს გავლენას.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` ტიპზე განსაზღვრულ მეთოდზე გადადის.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` ტიპზე განსაზღვრულ მეთოდზე გადადის.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` ტიპზე განსაზღვრულ მეთოდზე გადადის.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` ტიპზე განსაზღვრულ მეთოდზე გადადის.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` ტიპზე განსაზღვრულ მეთოდზე გადადის.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` ტიპზე განსაზღვრულ მეთოდზე გადადის.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID და მისი მეთოდები
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` წარმოადგენს გლობალურად უნიკალურ იდენტიფიკატორს ტიპისთვის.
///
/// თითოეული `TypeId` არის გაუმჭვირვალე ობიექტი, რომელიც არ იძლევა შიგნით არსებულ შემოწმებას, მაგრამ საშუალებას იძლევა ისეთი ძირითადი ოპერაციების ჩატარება, როგორიცაა კლონირება, შედარება, ბეჭდვა და ჩვენება.
///
///
/// `TypeId` ამჟამად ხელმისაწვდომია მხოლოდ იმ ტიპისთვის, რომლებიც მიეკუთვნებიან `'static`-ს, მაგრამ ეს შეზღუდვა შეიძლება მოიხსნას future-ში.
///
/// მიუხედავად იმისა, რომ `TypeId` ახორციელებს `Hash`, `PartialOrd` და `Ord`, აღსანიშნავია, რომ ჰეშები და შეკვეთა იცვლება Rust გამოცემებს შორის.
/// ფრთხილად იყავით თქვენი კოდის შინაგან იმედზე.
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// აბრუნებს `TypeId` ტიპის ამ ზოგადი ფუნქციის ინსტანტირებისთვის.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// აბრუნებს ტიპის სახელს სიმების ფრაგმენტად.
///
/// # Note
///
/// ეს განკუთვნილია დიაგნოსტიკური გამოყენებისათვის.
/// დაზუსტებული სტრიქონის ზუსტი შინაარსი და ფორმატი მითითებული არ არის, გარდა იმისა, რომ ეს არის საუკეთესო ტიპის აღწერა.
/// მაგალითად, `type_name::<Option<String>>()`-ის სტრიქონებს შორის არის `"Option<String>"` და `"std::option::Option<std::string::String>"`.
///
///
/// დაბრუნებული სტრიქონი არ უნდა ჩაითვალოს ტიპის უნიკალურ იდენტიფიკატორად, რადგან მრავალ ტიპს შეუძლია იმავე ტიპის სახელს ასახავდეს.
/// ანალოგიურად, არ არსებობს გარანტია, რომ ტიპის ყველა ნაწილი დაბრუნებულ სტრიქონში გამოჩნდება: მაგალითად, სიცოცხლის ხანგრძლივობის შემდგენები ამჟამად არ შედის.
/// გარდა ამისა, გამომავალი შეიძლება შეიცვალოს შემდგენლის ვერსიებს შორის.
///
/// ამჟამინდელი დანერგვა იყენებს იგივე ინფრასტრუქტურას, როგორც შემდგენლის დიაგნოზს და გამართვას, მაგრამ ეს არ არის გარანტირებული.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// აბრუნებს წერტილოვანი მნიშვნელობის ტიპის სახელს სიმების ნაჭრად.
/// ეს იგივეა, რაც `type_name::<T>()`, მაგრამ მისი გამოყენება შესაძლებელია იქ, სადაც ცვლადის ტიპი არ არის ადვილად ხელმისაწვდომი.
///
/// # Note
///
/// ეს განკუთვნილია დიაგნოსტიკური გამოყენებისათვის.სტრიქონის ზუსტი შინაარსი და ფორმატი მითითებული არ არის, გარდა იმისა, რომ ეს არის საუკეთესო ტიპის აღწერა.
/// მაგალითად, `type_name_of_val::<Option<String>>(None)` შეიძლება დაბრუნდეს `"Option<String>"` ან `"std::option::Option<std::string::String>"`, მაგრამ არა `"foobar"`.
///
/// გარდა ამისა, გამომავალი შეიძლება შეიცვალოს შემდგენლის ვერსიებს შორის.
///
/// ეს ფუნქცია არ წყვეტს trait ობიექტებს, რაც ნიშნავს, რომ `type_name_of_val(&7u32 as &dyn Debug)` შეიძლება დააბრუნოს `"dyn Debug"`, მაგრამ არა `"u32"`.
///
/// ტიპის სახელი არ უნდა ჩაითვალოს ტიპის უნიკალურ იდენტიფიკატორად;
/// მრავალ ტიპს შეიძლება ჰქონდეს იგივე ტიპის სახელი.
///
/// ამჟამინდელი დანერგვა იყენებს იგივე ინფრასტრუქტურას, როგორც შემდგენლის დიაგნოზს და გამართვას, მაგრამ ეს არ არის გარანტირებული.
///
/// # Examples
///
/// ბეჭდავს მთლიანი და float ნაგულისხმევ ტიპებს.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}