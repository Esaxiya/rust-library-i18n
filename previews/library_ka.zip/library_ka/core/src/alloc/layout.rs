use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// მიუხედავად იმისა, რომ ეს ფუნქცია ერთ ადგილას არის გამოყენებული და მისი განხორციელება შეიძლება მოხდეს, ამის წინა მცდელობამ rustc შეანელა:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// მეხსიერების ბლოკის განლაგება.
///
/// `Layout` ინსტანცია აღწერს მეხსიერების კონკრეტულ განლაგებას.
/// თქვენ აშენებთ `Layout`-ს, როგორც შენატანი, რომ მიანიჭოთ გამანაწილებელს.
///
/// ყველა განლაგებას აქვს ასოცირებული ზომა და ორი-ის სიმძლავრის გასწორება.
///
/// (გაითვალისწინეთ, რომ განლაგებას *არ აქვს* ნულოვანი ზომა, მიუხედავად იმისა, რომ `GlobalAlloc` მოითხოვს მეხსიერების ყველა მოთხოვნის ზომა იყოს ნულოვანი.
/// აბონენტმა უნდა უზრუნველყოს მსგავსი პირობების დაკმაყოფილება, გამოიყენოს სპეციფიკური გამანაწილებლები უფრო ფხვიერი მოთხოვნებით ან გამოიყენოს უფრო მსუბუქი `Allocator` ინტერფეისი.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // მოთხოვნილი მეხსიერების ბლოკის ზომა, იზომება ბაიტებში.
    size_: usize,

    // მოთხოვნილი მეხსიერების ბლოკის გასწორება, ბაიტებში გაზომული.
    // ჩვენ ვზრუნავთ, რომ ეს ყოველთვის არის ორის ენერგია, რადგან API- ს მსგავსი `posix_memalign` მოითხოვს და ეს გონივრული შეზღუდვაა Layout- ის კონსტრუქტორებისთვის.
    //
    //
    // (ამასთან, ჩვენ ანალოგიურად არ საჭიროებს `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// აშენებს `Layout` მოცემულ `size` და `align`- სგან, ან უბრუნებს `LayoutError`- ს, თუ რომელიმე შემდეგი პირობა არ არის შესრულებული:
    ///
    /// * `align` არ უნდა იყოს ნული,
    ///
    /// * `align` უნდა იყოს ორი,
    ///
    /// * `size`, როდესაც დამრგვალებულია `align`- ის უახლოეს ჯერადამდე, არ უნდა გადაფაროთ (მაგ., მომრგვალებული მნიშვნელობა უნდა იყოს `usize::MAX`- ზე ნაკლები ან ტოლი).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (ორიდან ორი გულისხმობს გასწორებას!=0.)

        // მომრგვალებული ზომაა:
        //   size_rounded_up=(ზომა + გასწორება, 1)&! (გასწორება, 1);
        //
        // ზემოდან ვიცით, რომ გასწორება!=0.
        // თუ დამატება (გასწორება, 1) არ გადავსდება, მაშინ დამრგვალება კარგად იქნება.
        //
        // პირიქით, და-მასკირება! (გასწორება, 1) გამოკლებს მხოლოდ დაბალი რიგის ბიტებს.
        // ამრიგად, თუ გადავსება ხდება თანხით,&-მასკს არ შეუძლია გამოაკლოს საკმარისი, რომ გაუქმდეს ეს გადავსება.
        //
        //
        // ზემოთ ნათქვამია, რომ ჯამური ატმოსფეროს შემოწმება როგორც საჭირო, ისე საკმარისია.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // უსაფრთხოება: შეიქმნა პირობები `from_size_align_unchecked`- ზე
        // ზემოთ შემოწმებულია.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// ქმნის განლაგებას, გვერდის ავლით ყველა შემოწმებას.
    ///
    /// # Safety
    ///
    /// ეს ფუნქცია არ არის უსაფრთხო, რადგან ის არ ამოწმებს წინაპირობებს [`Layout::from_size_align`]- დან.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `align` ნულზე მეტია.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// მინიმალური ზომა ბაიტებში ამ განლაგების მეხსიერების ბლოკისთვის.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// მინიმალური ბაიტის გასწორება ამ განლაგების მეხსიერების ბლოკისთვის.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// აშენებს `Layout`, რომელიც შესაფერისია `T` ტიპის მნიშვნელობის დასაკავებლად.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // უსაფრთხოება: გასწორება გარანტირებულია Rust- ით, რომ იყოს ორი და
        // ზომა + გასწორება კომბინირებულია ჩვენი მისამართების სივრცეში.
        // შედეგად, გამოიყენეთ აქ გაუმოწმებელი კონსტრუქტორი, რათა თავიდან აიცილოთ კოდი, რომელიც panics არის, თუ ის საკმარისად ოპტიმიზირებული არ არის.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// აწარმოებს ჩანაწერს, რომელიც აღწერს ჩანაწერს, რომელიც შეიძლება გამოყენებულ იქნეს `T`-ის სარეზერვო სტრუქტურის გამოყოფისთვის (რომელიც შეიძლება იყოს trait ან სხვა ზომის ზომა, როგორიცაა ნაჭერი).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // უსაფრთხოება: იხილეთ `new`- ის ლოგიკა, თუ რატომ იყენებს ეს სახიფათო ვარიანტს
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// აწარმოებს ჩანაწერს, რომელიც აღწერს ჩანაწერს, რომელიც შეიძლება გამოყენებულ იქნეს `T`-ის სარეზერვო სტრუქტურის გამოყოფისთვის (რომელიც შეიძლება იყოს trait ან სხვა ზომის ზომა, როგორიცაა ნაჭერი).
    ///
    /// # Safety
    ///
    /// ამ ფუნქციისთვის უსაფრთხოა დარეკვა მხოლოდ იმ შემთხვევაში, თუ მოქმედებს შემდეგი პირობები:
    ///
    /// - თუ `T` არის `Sized`, ამ ფუნქციასთან დაკავშირება ყოველთვის უსაფრთხოა.
    /// - თუ `T`- ის დიდი ზომის კუდი არის:
    ///     - a [slice], მაშინ ნაჭრის კუდის სიგრძე უნდა იყოს intialized მთელი რიცხვი, და *მთელი მნიშვნელობის*(დინამიური კუდის სიგრძე + სტატიკური ზომის პრეფიქსი) ზომა უნდა შეესაბამებოდეს `isize`.
    ///     - a [trait object], მაშინ მაჩვენებლის vtable ნაწილმა უნდა მიუთითოს არაიზოლიზირებელი კოროზიით შეძენილი `T` ტიპის ნამდვილ მაგიდაზე და *მთელი მნიშვნელობის* ზომა (დინამიური კუდის სიგრძე + სტატიკური ზომის პრეფიქსი) უნდა შეესაბამებოდეს `isize`.
    ///
    ///     - (unstable) [extern type], ამ ფუნქციაზე ყოველთვის უსაფრთხო დარეკვაა, მაგრამ შეიძლება panic ან სხვაგვარად დააბრუნოს არასწორი მნიშვნელობა, რადგან არ არის ცნობილი გარე ტიპის განლაგება.
    ///     ეს არის იგივე ქცევა, როგორც [`Layout::for_value`] გარე ტიპის კუდის მითითებაზე.
    ///     - წინააღმდეგ შემთხვევაში, დაუშვებელია ამ ფუნქციის დარეკვა.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // უსაფრთხოება: ამ ფუნქციების წინაპირობების გასწვრივ გადავდივართ აბონენტთან
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // უსაფრთხოება: იხილეთ `new`- ის ლოგიკა, თუ რატომ იყენებს ეს სახიფათო ვარიანტს
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ქმნის `NonNull`, რომელიც ჩამოკიდებულია, მაგრამ კარგად არის გასწორებული ამ განლაგებისათვის.
    ///
    /// გაითვალისწინეთ, რომ მაჩვენებლის მნიშვნელობა შეიძლება წარმოადგენდეს მართებულ მაჩვენებელს, რაც ნიშნავს, რომ ეს არ უნდა იქნას გამოყენებული, როგორც "not yet initialized" ფრონტალური მნიშვნელობა.
    /// ტიპები, რომლებიც სიზარმაცით გამოყოფენ, უნდა აკონტროლონ ინიცირება სხვა საშუალებებით.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // უსაფრთხოება: გასწორება გარანტირებულია, რომ არ იყოს ნულოვანი
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// ქმნის ჩანაწერს, რომელიც აღწერს ჩანაწერს, რომელსაც შეუძლია ჰქონდეს იგივე განლაგების მნიშვნელობა, როგორც `self`, მაგრამ ის ასევე შეესაბამება `align` განლაგებას (იზომება ბაიტებში).
    ///
    ///
    /// თუ `self` უკვე აკმაყოფილებს დანიშნულ გასწორებას, მაშინ დააბრუნებს `self`.
    ///
    /// გაითვალისწინეთ, რომ ეს მეთოდი არ ზრდის დამატებას მთლიან ზომას, იმისდა მიუხედავად, აქვს თუ არა დაბრუნებული განლაგება განსხვავებულ თანხვედრას.
    /// სხვა სიტყვებით რომ ვთქვათ, თუ `K`- ს აქვს 16 ზომა, `K.align_to(32)`- ს * მაინც ექნება 16 ზომა.
    ///
    /// აბრუნებს შეცდომას, თუ `self.size()` და მოცემული `align` კომბინაცია არღვევს [`Layout::from_size_align`]-ში ჩამოთვლილ პირობებს.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// აბრუნებს შევსების რაოდენობას, რომელიც უნდა ჩავსვათ `self`- ის შემდეგ, რათა დავრწმუნდეთ, რომ შემდეგი მისამართი დააკმაყოფილებს `align`- ს (იზომება ბაიტებში).
    ///
    /// მაგ., თუ `self.size()` არის 9, მაშინ `self.padding_needed_for(4)` აბრუნებს 3-ს, რადგან ეს არის ბაიტის მინიმალური რაოდენობა, რომელიც საჭიროა 4 გასწორებული მისამართის მისაღებად (ვთქვათ, რომ შესაბამისი მეხსიერების ბლოკი იწყება 4 გასწორებული მისამართით).
    ///
    ///
    /// ამ ფუნქციის დაბრუნების მნიშვნელობას მნიშვნელობა არ აქვს, თუ `align` არ არის ორი-ენერგია.
    ///
    /// გაითვალისწინეთ, რომ დაბრუნებული მნიშვნელობის სარგებლიანობა მოითხოვს `align` იყოს ნაკლები ან ტოლი საწყისი მისამართის გასწორებაზე მთლიანი გამოყოფილი მეხსიერების ბლოკისთვის.ამ შეზღუდვის დასაკმაყოფილებლად ერთი გზაა `align <= self.align()`-ის უზრუნველყოფა.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // დამრგვალებული მნიშვნელობაა:
        //   len_rounded_up=(len + გასწორება, 1)&! (გასწორება, 1);
        // და შემდეგ დავბრუნდებით ავსების სხვაობას: `len_rounded_up - len`.
        //
        // ჩვენ ვიყენებთ მოდულურ არითმეტიკას მთელი პერიოდის განმავლობაში:
        //
        // 1. გასწორება გარანტირებული იქნება> 0, ამიტომ გასწორება, 1 ყოველთვის მოქმედებს.
        //
        // 2.
        // `len + align - 1` შეიძლება გადავსდეს მაქსიმუმ `align - 1`- ით, ასე რომ&-მასკა `!(align - 1)`- ით უზრუნველყოფს, რომ გადავსების შემთხვევაში, `len_rounded_up` თავისთავად იქნება 0.
        //
        //    ამრიგად, დაბრუნებული შევსება, როდესაც დაემატება `len`, იძლევა 0-ს, რაც ტრივიალურად აკმაყოფილებს `align` განლაგებას.
        //
        // (რა თქმა უნდა, მეხსიერების ბლოკების გამოყოფის მცდელობამ, რომელთა ზომა და ბალიშები გადავსებულია ზემოთ მოყვანილი წესით, უნდა გამოიწვიოს, რომ გამანაწილებელმა მაინც გამოიწვიოს შეცდომა.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// ქმნის განლაგებას ამ განლაგების ზომის მომრგვალებით, განლაგების გასწორების ჯერადად.
    ///
    ///
    /// ეს ექვივალენტურია `padding_needed_for` შედეგის დამატება განლაგების ამჟამინდელ ზომასთან.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // ეს არ შეიძლება გადავსდეს.ციტატა განლაგების ინვარიანტიდან:
        // > `size`, როდესაც მრგვალდება `align`-ის უახლოეს ჯერადამდე,
        // > არ უნდა გადავსდეს (ანუ მომრგვალებული მნიშვნელობა უნდა იყოს ნაკლები
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// ქმნის განლაგებას, რომელიც აღწერს `self` ინსტანციის `n` ინსტანციის ჩანაწერს, თითოეულს შორის შესაფერისი რაოდენობის შევსება, რათა უზრუნველყოს, რომ თითოეულ ინსტანციას მიენიჭა მოთხოვნილი ზომა და გასწორება.
    /// წარმატების შემთხვევაში, უბრუნდება `(k, offs)`, სადაც `k` არის მასივის განლაგება და `offs` არის მანძილი მასივის თითოეული ელემენტის დაწყებას შორის.
    ///
    /// არითმეტიკული გადატვირთვისას უბრუნებს `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // ეს არ შეიძლება გადავსდეს.ციტატა განლაგების ინვარიანტიდან:
        // > `size`, როდესაც მრგვალდება `align`-ის უახლოეს ჯერადამდე,
        // > არ უნდა გადავსდეს (ანუ მომრგვალებული მნიშვნელობა უნდა იყოს ნაკლები
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // უსაფრთხოება: self.align უკვე ცნობილია, რომ მართებულია და ადევს ზომა
        // padded უკვე.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// ქმნის განლაგებას, რომელშიც აღწერილია ჩანაწერი `self`, რომელსაც მოჰყვება `next`, მათ შორის, ნებისმიერი აუცილებელი შევსება იმისთვის, რომ `next` სწორად იყოს გასწორებული, მაგრამ *უკანა მხარეს არ არის*.
    ///
    /// იმისათვის, რომ ემთხვეოდეს C წარმომადგენლობის განლაგებას `repr(C)`, თქვენ უნდა დაურეკოთ `pad_to_align`-ს განლაგების გაფართოების შემდეგ ყველა ველთან.
    /// (არ არსებობს გზა Rust-ის ნაგულისხმევი განლაგების `repr(Rust)`, as it is unspecified.) შესაბამისობისთვის
    ///
    /// გაითვალისწინეთ, რომ მიღებული განლაგების განლაგება იქნება მაქსიმალური `self` და `next`- ის, რათა უზრუნველყოს ორივე ნაწილის გასწორება.
    ///
    /// აბრუნებს `Ok((k, offset))`-ს, სადაც `k` არის შერწყმული ჩანაწერის განლაგება და `offset` არის შედარებითი ჩანაწერის შიგნით ჩაშენებული `next`-ის დაწყების ფარდობითი ადგილმდებარეობა ბაიტებში (ვთქვათ, რომ ჩანაწერი იწყება 0 კომპენსაციისგან).
    ///
    ///
    /// არითმეტიკული გადატვირთვისას უბრუნებს `LayoutError`.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` სტრუქტურის განლაგების და ველების განლაგების გამოთვლა მისი ველების განლაგებიდან:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // გახსოვდეთ, რომ საბოლოოდ დაასრულეთ `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // შეამოწმე რომ მუშაობს
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// ქმნის განლაგებას, რომელშიც აღწერილია ჩანაწერი `n` `self` ინსტანციისთვის, ყოველ ინსტანციას შორის არ ივსება.
    ///
    /// გაითვალისწინეთ, რომ `repeat`-ისგან განსხვავებით, `repeat_packed` არ იძლევა გარანტიას, რომ `self` განმეორებითი შემთხვევები სწორად იქნება გასწორებული, თუნდაც `self` მოცემული ინსტანციის სწორად გასწორება.
    /// სხვა სიტყვებით რომ ვთქვათ, თუ `repeat_packed` მიერ დაბრუნებული განლაგება გამოიყენება მასივის გამოყოფისთვის, გარანტირებული არ არის, რომ მასივის ყველა ელემენტი სწორად იქნება გასწორებული.
    ///
    /// არითმეტიკული გადატვირთვისას უბრუნებს `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// ქმნის განლაგებას, რომელშიც აღწერილია ჩანაწერი `self`- ისთვის, რასაც მოჰყვება `next`, დამატებით არ ავსებს მათ შორის.
    /// ვინაიდან არ არის ჩასმული შევსება, `next`-ის გასწორება შეუსაბამოა და საერთოდ არ არის შეყვანილი * მის განლაგებაში.
    ///
    ///
    /// არითმეტიკული გადატვირთვისას უბრუნებს `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// ქმნის განლაგებას, რომელიც აღწერს ჩანაწერს `[T; n]`-სთვის.
    ///
    /// არითმეტიკული გადატვირთვისას უბრუნებს `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` ან სხვა `Layout` კონსტრუქტორისთვის მოცემული პარამეტრები არ აკმაყოფილებს მის დოკუმენტირებულ შეზღუდვებს.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ეს ჩვენ გვჭირდება trait შეცდომის დაბლოკვის მიზნით)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}