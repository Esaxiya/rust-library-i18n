//! მეხსიერების გამოყოფის API

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` შეცდომა მიუთითებს განაწილების უკმარისობაზე, რომელიც შეიძლება გამოწვეული იყოს რესურსის ამოწურვით ან რაიმე არასწორით, როდესაც მოცემული შეყვანის არგუმენტები ამ გამანაწილებელთან ერთად გაერთიანდება.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (ეს ჩვენ გვჭირდება trait შეცდომის დაბლოკვის მიზნით)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator`- ის გამოყენებას შეუძლია [`Layout`][]- ით აღწერილი მონაცემების თვითნებური ბლოკების გამოყოფა, ზრდა, შემცირება და გადანაწილება.
///
/// `Allocator` შექმნილია ZST-ებზე, ცნობებზე ან სმარტ მაჩვენებლებზე გასატარებლად, რადგან `MyAlloc([u8; N])` მსგავსი ალაგატორის ქონა შეუძლებელია გადაადგილებულიყო მითითებული მეხსიერებაზე მითითების განახლების გარეშე.
///
/// [`GlobalAlloc`][]-ისგან განსხვავებით, ნულოვანი ზომის გამოყოფა დაშვებულია `Allocator`-ში.
/// თუ ფუძემდებლური გამანაწილებელი ამას მხარს არ უჭერს (მაგალითად, jemalloc) ან ნულოვანი მაჩვენებელი არ დააბრუნებს (მაგალითად, `libc::malloc`), ეს უნდა დაიჭიროთ განხორციელებამ.
///
/// ### ამჟამად გამოყოფილი მეხსიერება
///
/// ზოგიერთი მეთოდი მოითხოვს მეხსიერების ბლოკის *ამჟამად გამოყოფას* გამოყოფის საშუალებით.Ეს ნიშნავს რომ:
///
/// * ამ მეხსიერების ბლოკის საწყისი მისამართი ადრე დაუბრუნდა [`allocate`], [`grow`] ან [`shrink`] და
///
/// * მოგვიანებით მეხსიერების ბლოკი არ გადანაწილებულა, სადაც ბლოკები ან გამოიყოფა უშუალოდ [`deallocate`]- ზე გადასვლის გზით ან შეიცვალა [`grow`]- ზე ან [`shrink`]- ზე გადასვლით, რაც `Ok` აბრუნებს.
///
/// თუ `grow` ან `shrink` დააბრუნეს `Err`, გადაცემული მაჩვენებელი ძალაში რჩება.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### მეხსიერების იარაღი
///
/// ზოგიერთი მეთოდი მოითხოვს, რომ განლაგება *მოერგოს* მეხსიერების ბლოკს.
/// "fit" განლაგებისათვის რას ნიშნავს მეხსიერების ბლოკი (ან ეკვივალენტურად, მეხსიერების ბლოკი "fit"- ს განლაგებისათვის) არის ის, რომ უნდა არსებობდეს შემდეგი პირობები:
///
/// * ბლოკი უნდა გამოიყოს იმავე განლაგებით, როგორც [`layout.align()`] და
///
/// * მოცემული [`layout.size()`] უნდა მოხვდეს `min ..= max` დიაპაზონში, სადაც:
///   - `min` არის განლაგების ზომა, რომელიც ბოლოს გამოიყენეს ბლოკის გამოსაყოფად და
///   - `max` არის უახლესი რეალური ზომა, რომელიც დაბრუნდა [`allocate`], [`grow`] ან [`shrink`]- დან.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * ალოკატორიდან დაბრუნებული მეხსიერების ბლოკები უნდა მიუთითებდეს მოქმედი მეხსიერებისკენ და შეინარჩუნონ მათი მოქმედება, სანამ ინსტანცია და მისი ყველა კლონი არ დაეცემა,
///
/// * გამანაწილებლის კლონირებამ ან გადატანამ არ უნდა გააუქმოს მეხსიერების ბლოკები, რომლებიც დაბრუნებულია ამ გამანაწილებლისგან.კლონირებული გამანაწილებელი უნდა მოიქცეს ისევე, როგორც იგივე გამანაწილებელი და
///
/// * მეხსიერების ბლოკის ნებისმიერი მაჩვენებელი, რომელიც [*currently allocated*] არის, შეიძლება გადაეცეს გამანაწილებლის ნებისმიერ სხვა მეთოდს.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// მეხსიერების ბლოკის გამოყოფის მცდელობები.
    ///
    /// წარმატების შემთხვევაში, უბრუნებს [`NonNull<[u8]>`][NonNull] შეხვედრას `layout`- ის ზომის და გასწორების გარანტიებით.
    ///
    /// დაბრუნებულ ბლოკს შეიძლება ჰქონდეს უფრო დიდი ზომა, ვიდრე მითითებულია `layout.size()`- ით, და შეიძლება ჰქონდეს ან არ ჰქონდეს შინაარსის საწყისი.
    ///
    /// # Errors
    ///
    /// `Err` დაბრუნებისას მიუთითებს, რომ ან მეხსიერება ამოწურულია, ან `layout` არ აკმაყოფილებს გამანაწილებლის ზომის ან გასწორების შეზღუდვებს.
    ///
    /// დანერგვას ვურჩევთ დაუბრუნოთ `Err` მეხსიერების ამოწურვას, ვიდრე პანიკაში ჩავარდნას ან აბორტს, მაგრამ ეს არ არის მკაცრი მოთხოვნა.
    /// (კერძოდ: ეს * კანონიერია) trait-ის დანერგვა ძირითადი გამოყოფის ბიბლიოთეკის თავზე, რომელიც ხსნის მეხსიერების ამოწურვას.)
    ///
    /// გამოყოფის შეცდომის საპასუხოდ, გამოთვლის შეწყვეტის მსურველ კლიენტებს ურჩევენ [`handle_alloc_error`] ფუნქციის გამოძახებას, ვიდრე უშუალოდ `panic!`- ს ან მის მსგავსი გამოყენებას.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// იქცევა როგორც `allocate`, მაგრამ ასევე უზრუნველყოფს დაბრუნებული მეხსიერების ნულოვანი ინიცირება.
    ///
    /// # Errors
    ///
    /// `Err` დაბრუნებისას მიუთითებს, რომ ან მეხსიერება ამოწურულია, ან `layout` არ აკმაყოფილებს გამანაწილებლის ზომის ან გასწორების შეზღუდვებს.
    ///
    /// დანერგვას ვურჩევთ დაუბრუნოთ `Err` მეხსიერების ამოწურვას, ვიდრე პანიკაში ჩავარდნას ან აბორტს, მაგრამ ეს არ არის მკაცრი მოთხოვნა.
    /// (კერძოდ: ეს * კანონიერია) trait-ის დანერგვა ძირითადი გამოყოფის ბიბლიოთეკის თავზე, რომელიც ხსნის მეხსიერების ამოწურვას.)
    ///
    /// გამოყოფის შეცდომის საპასუხოდ, გამოთვლის შეწყვეტის მსურველ კლიენტებს ურჩევენ [`handle_alloc_error`] ფუნქციის გამოძახებას, ვიდრე უშუალოდ `panic!`- ს ან მის მსგავსი გამოყენებას.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // უსაფრთხოება: `alloc` აბრუნებს მოქმედი მეხსიერების ბლოკს
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// გამოყოფს `ptr`-ის მიერ მითითებულ მეხსიერებას.
    ///
    /// # Safety
    ///
    /// * `ptr` უნდა აღინიშნოს მეხსიერების ბლოკი [*currently allocated*] ამ გამანაწილებლის საშუალებით და
    /// * `layout` უნდა [*fit*] მეხსიერების ეს ბლოკი.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// მეხსიერების ბლოკის გაფართოების მცდელობები.
    ///
    /// აბრუნებს ახალ [`NonNull<[u8]>`][NonNull]-ს, რომელიც შეიცავს მაჩვენებელს და გამოყოფილი მეხსიერების რეალურ ზომას.მაჩვენებელი განკუთვნილია `new_layout`-ის მიერ აღწერილი მონაცემების დასაცავად.
    /// ამ მიზნის მისაღწევად, გამანაწილებელმა შეიძლება განაგრძოს განაწილება, რომელსაც მითითებულია `ptr`, ახალი განლაგების შესაბამისად.
    ///
    /// თუ ეს დააბრუნებს `Ok`, მაშინ მეხსიერების ბლოკის საკუთრება `ptr` მიერ მითითებული გადაეცა ამ გამყოფს.
    /// მეხსიერება შეიძლება გათავისუფლდეს ან არ იყოს გამოთავისუფლებული, და იგი ჩაითვალოს გამოუსადეგარად, თუ ის ამ მეთოდის დაბრუნებული მნიშვნელობით კვლავ არ დაუბრუნდება აბონენტს.
    ///
    /// თუ ეს მეთოდი დააბრუნებს `Err`, მაშინ მეხსიერების ბლოკის საკუთრება არ არის გადაცემული ამ გამანაწილებელზე და მეხსიერების ბლოკის შინაარსი უცვლელია.
    ///
    /// # Safety
    ///
    /// * `ptr` უნდა აღინიშნოს მეხსიერების ბლოკი [*currently allocated*] ამ გამანაწილებლის საშუალებით.
    /// * `old_layout` უნდა [*fit*] მეხსიერების ეს ბლოკი (`new_layout` არგუმენტი საჭირო არ არის.)
    /// * `new_layout.size()` უნდა იყოს `old_layout.size()`- ზე მეტი ან ტოლი.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// აბრუნებს `Err`-ს, თუ ახალი განლაგება არ აკმაყოფილებს გამანაწილებლის ზომისა და ალაგატორის გასწორების შეზღუდვებს, ან თუ სხვაგვარად ზრდა ვერ მოხერხდება.
    ///
    /// დანერგვას ვურჩევთ დაუბრუნოთ `Err` მეხსიერების ამოწურვას, ვიდრე პანიკაში ჩავარდნას ან აბორტს, მაგრამ ეს არ არის მკაცრი მოთხოვნა.
    /// (კერძოდ: ეს * კანონიერია) trait-ის დანერგვა ძირითადი გამოყოფის ბიბლიოთეკის თავზე, რომელიც ხსნის მეხსიერების ამოწურვას.)
    ///
    /// გამოყოფის შეცდომის საპასუხოდ, გამოთვლის შეწყვეტის მსურველ კლიენტებს ურჩევენ [`handle_alloc_error`] ფუნქციის გამოძახებას, ვიდრე უშუალოდ `panic!`- ს ან მის მსგავსი გამოყენებას.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // უსაფრთხოება: რადგან `new_layout.size()` უნდა იყოს მეტი ან ტოლი
        // `old_layout.size()`, ძველი და ახალი მეხსიერების განაწილება მოქმედებს `old_layout.size()` ბაიტისთვის კითხვისა და წერისთვის.
        // ასევე, იმის გამო, რომ ძველი განაწილება ჯერ კიდევ არ იყო გადატანილი, მას არ შეუძლია გადაფაროს `new_ptr`.
        // ამრიგად, `copy_nonoverlapping`-ზე ზარი უსაფრთხოა.
        // აბონენტის მიერ დაცული უნდა იყოს უსაფრთხოების კონტრაქტი `dealloc`- ზე.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// იქცევა როგორც `grow`, მაგრამ ასევე უზრუნველყოფს ახალი შინაარსის დაყენებას ნულის დაბრუნებამდე.
    ///
    /// მეხსიერების ბლოკი შეიცავს შემდეგ შინაარსს წარმატებული გამოძახების შემდეგ
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` შემონახულია თავდაპირველი განაწილებისგან.
    ///   * ბაიტი `old_layout.size()..old_size` ან შენარჩუნდება, ან ნულოვანი იქნება, ეს დამოკიდებულია გამანაწილებლის შესრულებაზე.
    ///   `old_size` ეხება მეხსიერების ბლოკის ზომას `grow_zeroed` ზარის დაწყებამდე, რომელიც შეიძლება აღემატებოდეს იმ ზომას, რომელიც თავდაპირველად მოითხოვეს მისი გამოყოფისას.
    ///   * `old_size..new_size` ბაიტები ნულდება.`new_size` ეხება მეხსიერების ბლოკის ზომას, რომელიც დაუბრუნდა `grow_zeroed` ზარს.
    ///
    /// # Safety
    ///
    /// * `ptr` უნდა აღინიშნოს მეხსიერების ბლოკი [*currently allocated*] ამ გამანაწილებლის საშუალებით.
    /// * `old_layout` უნდა [*fit*] მეხსიერების ეს ბლოკი (`new_layout` არგუმენტი საჭირო არ არის.)
    /// * `new_layout.size()` უნდა იყოს `old_layout.size()`- ზე მეტი ან ტოლი.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// აბრუნებს `Err`-ს, თუ ახალი განლაგება არ აკმაყოფილებს გამანაწილებლის ზომისა და ალაგატორის გასწორების შეზღუდვებს, ან თუ სხვაგვარად ზრდა ვერ მოხერხდება.
    ///
    /// დანერგვას ვურჩევთ დაუბრუნოთ `Err` მეხსიერების ამოწურვას, ვიდრე პანიკაში ჩავარდნას ან აბორტს, მაგრამ ეს არ არის მკაცრი მოთხოვნა.
    /// (კერძოდ: ეს * კანონიერია) trait-ის დანერგვა ძირითადი გამოყოფის ბიბლიოთეკის თავზე, რომელიც ხსნის მეხსიერების ამოწურვას.)
    ///
    /// გამოყოფის შეცდომის საპასუხოდ, გამოთვლის შეწყვეტის მსურველ კლიენტებს ურჩევენ [`handle_alloc_error`] ფუნქციის გამოძახებას, ვიდრე უშუალოდ `panic!`- ს ან მის მსგავსი გამოყენებას.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // უსაფრთხოება: რადგან `new_layout.size()` უნდა იყოს მეტი ან ტოლი
        // `old_layout.size()`, ძველი და ახალი მეხსიერების განაწილება მოქმედებს `old_layout.size()` ბაიტისთვის კითხვისა და წერისთვის.
        // ასევე, იმის გამო, რომ ძველი განაწილება ჯერ კიდევ არ იყო გადატანილი, მას არ შეუძლია გადაფაროს `new_ptr`.
        // ამრიგად, `copy_nonoverlapping`-ზე ზარი უსაფრთხოა.
        // აბონენტის მიერ დაცული უნდა იყოს უსაფრთხოების კონტრაქტი `dealloc`- ზე.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// მეხსიერების ბლოკის შემცირების მცდელობები.
    ///
    /// აბრუნებს ახალ [`NonNull<[u8]>`][NonNull]-ს, რომელიც შეიცავს მაჩვენებელს და გამოყოფილი მეხსიერების რეალურ ზომას.მაჩვენებელი განკუთვნილია `new_layout`-ის მიერ აღწერილი მონაცემების დასაცავად.
    /// ამ მიზნის მისაღწევად, გამანაწილებელმა შეიძლება შეამციროს განაწილება, რომელსაც მითითებულია `ptr`, ახალი განლაგების შესაბამისად.
    ///
    /// თუ ეს დააბრუნებს `Ok`, მაშინ მეხსიერების ბლოკის საკუთრება `ptr` მიერ მითითებული გადაეცა ამ გამყოფს.
    /// მეხსიერება შეიძლება გათავისუფლდეს ან არ იყოს გამოთავისუფლებული, და იგი ჩაითვალოს გამოუსადეგარად, თუ ის ამ მეთოდის დაბრუნებული მნიშვნელობით კვლავ არ დაუბრუნდება აბონენტს.
    ///
    /// თუ ეს მეთოდი დააბრუნებს `Err`, მაშინ მეხსიერების ბლოკის საკუთრება არ არის გადაცემული ამ გამანაწილებელზე და მეხსიერების ბლოკის შინაარსი უცვლელია.
    ///
    /// # Safety
    ///
    /// * `ptr` უნდა აღინიშნოს მეხსიერების ბლოკი [*currently allocated*] ამ გამანაწილებლის საშუალებით.
    /// * `old_layout` უნდა [*fit*] მეხსიერების ეს ბლოკი (`new_layout` არგუმენტი საჭირო არ არის.)
    /// * `new_layout.size()` უნდა იყოს ნაკლები ან ტოლი `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// აბრუნებს `Err`-ს, თუ ახალი განლაგება არ აკმაყოფილებს გამანაწილებლის ზომისა და ალაგატორის გასწორების შეზღუდვებს, ან თუ შემცირება სხვაგვარად ვერ ხერხდება.
    ///
    /// დანერგვას ვურჩევთ დაუბრუნოთ `Err` მეხსიერების ამოწურვას, ვიდრე პანიკაში ჩავარდნას ან აბორტს, მაგრამ ეს არ არის მკაცრი მოთხოვნა.
    /// (კერძოდ: ეს * კანონიერია) trait-ის დანერგვა ძირითადი გამოყოფის ბიბლიოთეკის თავზე, რომელიც ხსნის მეხსიერების ამოწურვას.)
    ///
    /// გამოყოფის შეცდომის საპასუხოდ, გამოთვლის შეწყვეტის მსურველ კლიენტებს ურჩევენ [`handle_alloc_error`] ფუნქციის გამოძახებას, ვიდრე უშუალოდ `panic!`- ს ან მის მსგავსი გამოყენებას.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // უსაფრთხოება: რადგან `new_layout.size()` უნდა იყოს დაბალი ან ტოლი მას
        // `old_layout.size()`, ძველი და ახალი მეხსიერების განაწილება მოქმედებს `new_layout.size()` ბაიტისთვის კითხვისა და წერისთვის.
        // ასევე, იმის გამო, რომ ძველი განაწილება ჯერ კიდევ არ იყო გადატანილი, მას არ შეუძლია გადაფაროს `new_ptr`.
        // ამრიგად, `copy_nonoverlapping`-ზე ზარი უსაფრთხოა.
        // აბონენტის მიერ დაცული უნდა იყოს უსაფრთხოების კონტრაქტი `dealloc`- ზე.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// ქმნის "by reference" ადაპტერს `Allocator`-ის ამ ინსტანციისთვის.
    ///
    /// დაბრუნებული ადაპტერი ახორციელებს `Allocator`- ს და ამას უბრალოდ ისესხებს.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // უსაფრთხოება: უსაფრთხოების ხელშეკრულება აბონენტის მიერ უნდა დაიცვას
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // უსაფრთხოება: უსაფრთხოების ხელშეკრულება აბონენტის მიერ უნდა დაიცვას
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // უსაფრთხოება: უსაფრთხოების ხელშეკრულება აბონენტის მიერ უნდა დაიცვას
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // უსაფრთხოება: უსაფრთხოების ხელშეკრულება აბონენტის მიერ უნდა დაიცვას
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}