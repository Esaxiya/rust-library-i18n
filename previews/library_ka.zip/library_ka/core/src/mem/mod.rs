//! მეხსიერების მოგვარების ძირითადი ფუნქციები.
//!
//! ეს მოდული შეიცავს ფუნქციებს ზომისა და ტიპების გასწორების, მეხსიერების ინიციალიზაციისა და მანიპულირებისთვის.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// იღებს საკუთრებას და "forgets" მნიშვნელობას **მისი დესტრუქტორის გაშვების გარეშე**.
///
/// ნებისმიერი რესურსი, რომელსაც მართავს მნიშვნელობა, მაგალითად, ბევრი მეხსიერება ან ფაილის სახელური, სამუდამოდ დარჩება მიუწვდომელ მდგომარეობაში.ამასთან, ეს არ იძლევა გარანტიას, რომ ამ მეხსიერების მითითებები ძალაში დარჩება.
///
/// * თუ გსურთ მეხსიერების გაჟონვა, იხილეთ [`Box::leak`].
/// * თუ გსურთ მეხსიერების ნედლეული მაჩვენებლის მიღება, იხილეთ [`Box::into_raw`].
/// * თუ გსურთ ფასის სწორად განკარგვა, მისი დესტრუქტორის გაშვება, იხილეთ [`mem::drop`].
///
/// # Safety
///
/// `forget` არ არის მითითებული, როგორც `unsafe`, რადგან Rust უსაფრთხოების გარანტიები არ შეიცავს გარანტიას, რომ დესტრუქტორები ყოველთვის მუშაობენ.
/// მაგალითად, პროგრამას შეუძლია შექმნას მითითების ციკლი [`Rc`][rc]- ის გამოყენებით, ან დარეკოთ [`process::exit`][exit]- ზე გასასვლელად დესტრუქტორების გაშვების გარეშე.
/// ამრიგად, უსაფრთხო კოდისგან `mem::forget` დაშვება ძირეულად არ ცვლის Rust უსაფრთხოების გარანტიებს.
///
/// როგორც ითქვა, რესურსების გაჟონვა, როგორიცაა მეხსიერება ან I/O ობიექტი, ჩვეულებრივ არასასურველია.
/// ზოგიერთ სპეციალიზირებულ შემთხვევებში გვხვდება საჭიროება FFI ან არაუსაფრთხო კოდი, მაგრამ მაშინაც კი, [`ManuallyDrop`] ჩვეულებრივ სასურველია.
///
/// რადგან მნიშვნელობის დავიწყება ნებადართულია, თქვენს მიერ დაწერილი ნებისმიერი `unsafe` კოდი უნდა იძლევა ამ შესაძლებლობის შესაძლებლობას.თქვენ ვერ დაბრუნებთ მნიშვნელობას და ელით, რომ აბონენტი აუცილებლად აწარმოებს მნიშვნელობის გამანადგურებელს.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget`-ის კანონიკური უსაფრთხო გამოყენებაა `Drop` trait-ის მიერ გამოყენებული მნიშვნელობის დესტრუქტორის გვერდის ავლით.მაგალითად, ეს გაჟონავს `File`, ე.ი.
/// შეცვალეთ ცვლადის მიერ მიღებული სივრცე, მაგრამ არასდროს დახუროთ სისტემის ძირითადი რესურსი:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// ეს გამოდგება მაშინ, როდესაც ძირითადი რესურსის საკუთრება ადრე გადაეცა კოდს Rust- ს გარეთ, მაგალითად, ნედლი ფაილის აღწერილის C კოდზე გადაცემით.
///
/// # ურთიერთობა `ManuallyDrop`-თან
///
/// მიუხედავად იმისა, რომ `mem::forget` ასევე შეიძლება გამოყენებულ იქნას *მეხსიერების* საკუთრების გადასაცემად, ამის გაკეთება არის შეცდომა.
/// [`ManuallyDrop`] ამის ნაცვლად უნდა იქნას გამოყენებული.მაგალითად, განვიხილოთ ეს კოდი:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // ააშენეთ `String` `v` შინაარსის გამოყენებით
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // გაჟონა `v`, რადგან მის მეხსიერებას ახლა მართავს `s`
/// mem::forget(v);  // შეცდომა, v არასწორია და არ უნდა გადაეცეს ფუნქციას
/// assert_eq!(s, "Az");
/// // `s` ირიბად ვარდება და მისი მეხსიერება გადანაწილებულია.
/// ```
///
/// არსებობს ორი საკითხი, ზემოთ მოყვანილ მაგალითთან დაკავშირებით:
///
/// * თუ მეტი კოდი დაემატება `String`-ის კონსტრუქციასა და `mem::forget()`-ის გამოყენებას შორის, მის შიგნით panic გამოიწვევს ორმაგ თავისუფლებას, რადგან ერთსა და იმავე მეხსიერებას ამუშავებს როგორც `v`, ისე `s`.
/// * `v.as_mut_ptr()`-ზე დარეკვისა და მონაცემების საკუთრების `s`-ზე გადაცემის შემდეგ, `v` მნიშვნელობა არასწორია.
/// მაშინაც კი, როდესაც მნიშვნელობა `mem::forget`-შია გადატანილი (რაც მას არ შეამოწმებს), ზოგიერთ ტიპს მკაცრი მოთხოვნები აქვს მათი მნიშვნელობების მიმართ, რაც მათ ბათილად აქცევს ჩამოკიდებისას ან აღარ ფლობს მათ.
/// არასწორი მნიშვნელობების გამოყენება ნებისმიერი ფორმით, მათ ჩათვლით ან ფუნქციონიდან მათი დაბრუნება, წარმოადგენს განუსაზღვრელ ქცევას და შეიძლება დაარღვიოს შემდგენლის მიერ გაკეთებული დაშვებები.
///
/// `ManuallyDrop`- ზე გადასვლა თავიდან აიცილებს ორივე საკითხს:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // სანამ `v` მის ნედლეულ ნაწილებს დავშლით, დარწმუნდით, რომ ის არ დაეცემა!
/////
/// let mut v = ManuallyDrop::new(v);
/// // ახლა დაიშალა `v`.ამ ოპერაციებს არ შეუძლიათ panic, ამიტომ არ შეიძლება მოხდეს გაჟონვა.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // დაბოლოს, ააშენეთ `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ირიბად ვარდება და მისი მეხსიერება გადანაწილებულია.
/// ```
///
/// `ManuallyDrop` მკაცრად ხელს უშლის ორმაგ თავისუფლებას, რადგან ჩვენ ვთიშავთ `v-ის დესტრუქტორს, სანამ რაიმე სხვას გავაკეთებთ.
/// `mem::forget()` არ იძლევა ამის საშუალებას, რადგან იგი არგუმენტს მოიხმარს და გვაიძულებს მას მხოლოდ მას შემდეგ დაურეკოთ, რაც `v`- დან დაგვჭირდება.
/// მაშინაც კი, თუ panic დაინერგება `ManuallyDrop`- ის კონსტრუქციასა და სტრიქონის აგებას შორის (რაც არ შეიძლება მოხდეს კოდექსში, როგორც ეს ნაჩვენებია), ეს გამოიწვევს გაჟონვას და არა ორმაგად თავისუფალს.
/// სხვა სიტყვებით რომ ვთქვათ, `ManuallyDrop` ცდება გაჟონვის მხარეს, შეცდომის ნაცვლად (ორმაგი) ვარდნის მხარეს.
///
/// ასევე, `ManuallyDrop` ხელს უშლის "touch" `v`- ს საჭიროებას `s`- ზე საკუთრების გადაცემის შემდეგ-`v`- თან ურთიერთობის საბოლოო ნაბიჯი მისი განადგურების გარეშე მისი განკარგვისთვის თავიდან აიცილეთ.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// ისევე, როგორც [`forget`], მაგრამ ასევე იღებს არადიდურ მნიშვნელობებს.
///
/// ეს ფუნქცია არის მხოლოდ shim, რომლის ამოღება `unsized_locals` მახასიათებლის სტაბილიზაციის დროს ხდება.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// უბრუნებს ტიპის ზომას ბაიტებში.
///
/// უფრო კონკრეტულად, ეს არის ბაიტებში გადანაწილება მასივის თანმიმდევრულ ელემენტებს შორის ამ ელემენტის ტიპთან, გასწორების შევსების ჩათვლით.
///
/// ამრიგად, ნებისმიერი ტიპის `T` და სიგრძის `n`, `[T; n]`- ს აქვს `n * size_of::<T>()` ზომა.
///
/// ზოგადად, ტიპის ზომა არ არის სტაბილური კოლექციებში, მაგრამ კონკრეტული ტიპები, როგორიცაა პრიმიტიული, არის.
///
/// შემდეგ ცხრილში მოცემულია პრიმიტივების ზომა.
///
/// ტიპი |ზომა: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// გარდა ამისა, `usize` და `isize` აქვს იგივე ზომა.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` და `Option<Box<T>>` ტიპებს ერთი და იგივე ზომა აქვთ.
/// თუ `T` ზომისაა, ყველა ამ ტიპს აქვს იგივე ზომა, როგორც `usize`.
///
/// მაჩვენებლის ცვალებადობა არ ცვლის მის ზომას.როგორც ასეთი, `&T` და `&mut T` აქვს იგივე ზომა.
/// ანალოგიურად `*const T` და `* mut T`.
///
/// # `#[repr(C)]` ნივთის ზომა
///
/// ნივთების `C` წარმომადგენლობას აქვს განსაზღვრული განლაგება.
/// ამ განლაგებით, ნივთების ზომაც სტაბილურია, რადგან ყველა ველს აქვს სტაბილური ზომა.
///
/// ## სტრუქტურის ზომა
///
/// `structs`- სთვის ზომა განისაზღვრება შემდეგი ალგორითმით.
///
/// დეკლარაციის ბრძანებით შეკვეთილი სტრუქტურის თითოეული დონისთვის:
///
/// 1. დაამატეთ ველის ზომა.
/// 2. ახლეთ მიმდინარე ზომა შემდეგი ველის [alignment]-ის უახლოეს ჯერადად.
///
/// დაბოლოს, სტრუქტურის ზომა მრგვალდება მისი [alignment] უახლოეს ჯერადად.
/// სტრუქტურის სწორება, როგორც წესი, მისი ყველა ველის უდიდესი გასწორებაა;ეს შეიძლება შეიცვალოს `repr(align(N))`- ის გამოყენებით.
///
/// `C`-ისგან განსხვავებით, ნულოვანი ზომის დარტყმები არ არის მომრგვალებული ერთი ბაიტის ზომით.
///
/// ## Enums-ის ზომა
///
/// Enum-ებს, რომლებიც დისკრიმინატორის გარდა სხვა მონაცემებს არ ატარებენ, აქვთ იგივე ზომა, რაც C enum-ები იმ პლატფორმაზე, რომლისთვისაც შედგენილია.
///
/// ## კავშირების ზომა
///
/// კავშირის ზომა არის მისი უდიდესი ველის ზომა.
///
/// `C`-ისგან განსხვავებით, ნულოვანი ზომის გაერთიანებები არ მრგვალდება ერთ ბაიტამდე.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // ზოგიერთი პრიმიტიული
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // ზოგიერთი მასივი
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // მაჩვენებლის ზომის თანასწორობა
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]`- ის გამოყენება.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // პირველი ველის ზომაა 1, ამიტომ ზომაზე დაამატეთ 1.ზომა არის 1.
/// // მეორე ველის გასწორება არის 2, ამიტომ შეავსეთ ზომა 1 padding-ისთვის.ზომა არის 2.
/// // მეორე ველის ზომაა 2, ამიტომ ზომას დაამატეთ 2.ზომა არის 4.
/// // მესამე ველის გასწორება არის 1, ასე რომ, padding-ის ზომაზე დაამატეთ 0.ზომა არის 4.
/// // მესამე ველის ზომაა 1, ამიტომ ზომაზე დაამატეთ 1.ზომა არის 5.
/// // დაბოლოს, სტრუქტურის გასწორება არის 2 (რადგან მის ველებს შორის ყველაზე დიდი გასწორება არის 2), ამიტომ შეავსეთ ზომა 1 padding-ისთვის.
/// // ზომა არის 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple-ის დარტყმები იმავე წესებს იცავს.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // გაითვალისწინეთ, რომ ველების გადალახვას შეუძლია ზომის შემცირება.
/// // ჩვენ შეგვიძლია ამოვიღოთ ორივე padding ბაიტი `third`- ის `second`- მდე დაყენებით.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // კავშირის ზომა არის უდიდესი ველის ზომა.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// აბრუნებს მითითებული მნიშვნელობის ზომას ბაიტებში.
///
/// ეს ჩვეულებრივ იგივეა, რაც `size_of::<T>()`.
/// ამასთან, როდესაც `T` *-ს არ აქვს სტატისტიკურად ცნობილი ზომა, მაგალითად, ნაჭერი [`[T]`][slice] ან [trait object], მაშინ დინამიურად ცნობილი ზომის მისაღებად შეიძლება გამოყენებულ იქნას `size_of_val`.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // უსაფრთხოება: `val` არის მითითება, ამიტომ ის მოქმედებს დაუმუშავებელი მაჩვენებელი
    unsafe { intrinsics::size_of_val(val) }
}

/// აბრუნებს მითითებული მნიშვნელობის ზომას ბაიტებში.
///
/// ეს ჩვეულებრივ იგივეა, რაც `size_of::<T>()`.ამასთან, როდესაც `T` *-ს არ აქვს სტატისტიკურად ცნობილი ზომა, მაგალითად, ნაჭერი [`[T]`][slice] ან [trait object], მაშინ დინამიურად ცნობილი ზომის მისაღებად შეიძლება გამოყენებულ იქნას `size_of_val_raw`.
///
/// # Safety
///
/// ამ ფუნქციისთვის უსაფრთხოა დარეკვა მხოლოდ იმ შემთხვევაში, თუ მოქმედებს შემდეგი პირობები:
///
/// - თუ `T` არის `Sized`, ამ ფუნქციასთან დაკავშირება ყოველთვის უსაფრთხოა.
/// - თუ `T`- ის დიდი ზომის კუდი არის:
///     - a [slice], მაშინ ნაჭრის კუდის სიგრძე უნდა იყოს ინიცირებული მთელი რიცხვი, და *მთლიანი მნიშვნელობის* ზომა (დინამიური კუდის სიგრძე + სტატიკური ზომის პრეფიქსი) უნდა იყოს `isize`.
///     - a [trait object], მაშინ მაჩვენებლის vtable ნაწილმა უნდა მიუთითოს არაიზოლიზირებული იძულებითი საშუალებით შეძენილი მოქმედი მაგიდა, ხოლო *მთლიანი მნიშვნელობის* ზომა (დინამიური კუდის სიგრძე + სტატიკური ზომის პრეფიქსი) უნდა იყოს `isize`.
///
///     - (unstable) [extern type], ამ ფუნქციაზე ყოველთვის უსაფრთხო დარეკვაა, მაგრამ შეიძლება panic ან სხვაგვარად დააბრუნოს არასწორი მნიშვნელობა, რადგან არ არის ცნობილი გარე ტიპის განლაგება.
///     ეს არის იგივე ქცევა, როგორც [`size_of_val`], გარე ტიპის კუდის ტიპზე მითითებისას.
///     - წინააღმდეგ შემთხვევაში, დაუშვებელია ამ ფუნქციის დარეკვა.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს მოქმედი ნედლეულის მაჩვენებელი
    unsafe { intrinsics::size_of_val(val) }
}

/// აბრუნებს ტიპის [ABI] მოთხოვნილ მინიმალურს.
///
/// `T` ტიპის მნიშვნელობის ყველა მითითება უნდა იყოს ამ რიცხვის ჯერადი.
///
/// ეს არის გასწორება, რომელიც გამოიყენება სტრუქტურული ველებისთვის.ეს შეიძლება იყოს უფრო მცირე ვიდრე სასურველი გასწორება.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// აბრუნებს იმ მნიშვნელობის ტიპის [ABI] მოთხოვნილ მინიმალურ გასწორებას, რომელზეც `val` მიუთითებს.
///
/// `T` ტიპის მნიშვნელობის ყველა მითითება უნდა იყოს ამ რიცხვის ჯერადი.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // უსაფრთხოება: val მითითებაა, ამიტომ ის მოქმედებს დაუმუშავებელი მაჩვენებელი
    unsafe { intrinsics::min_align_of_val(val) }
}

/// აბრუნებს ტიპის [ABI] მოთხოვნილ მინიმალურს.
///
/// `T` ტიპის მნიშვნელობის ყველა მითითება უნდა იყოს ამ რიცხვის ჯერადი.
///
/// ეს არის გასწორება, რომელიც გამოიყენება სტრუქტურული ველებისთვის.ეს შეიძლება იყოს უფრო მცირე ვიდრე სასურველი გასწორება.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// აბრუნებს იმ მნიშვნელობის ტიპის [ABI] მოთხოვნილ მინიმალურ გასწორებას, რომელზეც `val` მიუთითებს.
///
/// `T` ტიპის მნიშვნელობის ყველა მითითება უნდა იყოს ამ რიცხვის ჯერადი.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // უსაფრთხოება: val მითითებაა, ამიტომ ის მოქმედებს დაუმუშავებელი მაჩვენებელი
    unsafe { intrinsics::min_align_of_val(val) }
}

/// აბრუნებს იმ მნიშვნელობის ტიპის [ABI] მოთხოვნილ მინიმალურ გასწორებას, რომელზეც `val` მიუთითებს.
///
/// `T` ტიპის მნიშვნელობის ყველა მითითება უნდა იყოს ამ რიცხვის ჯერადი.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// ამ ფუნქციისთვის უსაფრთხოა დარეკვა მხოლოდ იმ შემთხვევაში, თუ მოქმედებს შემდეგი პირობები:
///
/// - თუ `T` არის `Sized`, ამ ფუნქციასთან დაკავშირება ყოველთვის უსაფრთხოა.
/// - თუ `T`- ის დიდი ზომის კუდი არის:
///     - a [slice], მაშინ ნაჭრის კუდის სიგრძე უნდა იყოს ინიცირებული მთელი რიცხვი, და *მთლიანი მნიშვნელობის* ზომა (დინამიური კუდის სიგრძე + სტატიკური ზომის პრეფიქსი) უნდა იყოს `isize`.
///     - a [trait object], მაშინ მაჩვენებლის vtable ნაწილმა უნდა მიუთითოს არაიზოლიზირებული იძულებითი საშუალებით შეძენილი მოქმედი მაგიდა, ხოლო *მთლიანი მნიშვნელობის* ზომა (დინამიური კუდის სიგრძე + სტატიკური ზომის პრეფიქსი) უნდა იყოს `isize`.
///
///     - (unstable) [extern type], ამ ფუნქციაზე ყოველთვის უსაფრთხო დარეკვაა, მაგრამ შეიძლება panic ან სხვაგვარად დააბრუნოს არასწორი მნიშვნელობა, რადგან არ არის ცნობილი გარე ტიპის განლაგება.
///     ეს არის იგივე ქცევა, როგორც [`align_of_val`], გარე ტიპის კუდის ტიპზე მითითებისას.
///     - წინააღმდეგ შემთხვევაში, დაუშვებელია ამ ფუნქციის დარეკვა.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს მოქმედი ნედლეულის მაჩვენებელი
    unsafe { intrinsics::min_align_of_val(val) }
}

/// აბრუნებს `true`-ს, თუ `T` ტიპის მნიშვნელობებს აქვს მნიშვნელობა.
///
/// ეს არის მხოლოდ ოპტიმიზაციის მინიშნება და შეიძლება განხორციელდეს კონსერვატიულად:
/// მას შეუძლია დააბრუნოს `true` იმ ტიპებისთვის, რომელთა რეალურად დაცემა არ არის საჭირო.
/// როგორც ასეთი, ყოველთვის `true` დაბრუნება იქნებოდა ამ ფუნქციის მართებული განხორციელება.თუმცა, თუ ეს ფუნქცია სინამდვილეში დააბრუნებს `false`-ს, მაშინ დარწმუნებული იქნებით, რომ `T`-ს არ აქვს გვერდითი ეფექტი.
///
/// ისეთი დაბალი დონის დანერგვა, როგორიცაა კოლექციები, რომლებსაც სჭირდებათ მონაცემთა ხელით ჩაგდება, უნდა გამოიყენონ ეს ფუნქცია, რათა თავიდან აიცილონ ზედმეტი მცდელობა მათი შინაარსის განადგურებისას.
///
/// ამან შეიძლება არ შეიტანოს განსხვავება გამოშვების აგებულებებში (სადაც მარყუჟი, რომელსაც არ აქვს გვერდითი მოვლენები, ადვილად გამოვლენილია და აღმოფხვრილი), მაგრამ ეს ხშირად დიდი მოგებაა გამართვის შეცდომებისთვის.
///
/// გაითვალისწინეთ, რომ [`drop_in_place`] უკვე ასრულებს ამ შემოწმებას, ასე რომ, თუ თქვენი დატვირთვა შეიძლება შემცირდეს [`drop_in_place`] ზარის მცირე რაოდენობაზე, ამის გამოყენება არ არის საჭირო.
/// კერძოდ, გაითვალისწინეთ, რომ შეგიძლიათ [`drop_in_place`] ნაჭერი, და ეს გააკეთებს ერთჯერადი need_drop შემოწმებას ყველა მნიშვნელობისთვის.
///
/// Vec- ის მსგავსი ტიპები მხოლოდ `drop_in_place(&mut self[..])`- ს `needs_drop`- ის პირდაპირ გამოყენების გარეშე.
/// მეორეს მხრივ, [`HashMap`]-ის მსგავსი ტიპები ერთ ჯერზე უნდა ჩამოაგდონ და უნდა გამოიყენონ ეს API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// ეს არის მაგალითი იმისა, თუ როგორ შეიძლება გამოიყენოს კოლექციამ `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ჩამოაგდეს მონაცემები
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// აბრუნებს `T` ტიპის მნიშვნელობას, წარმოდგენილია ნულოვანი ბაიტის ნიმუშით.
///
/// ეს ნიშნავს, რომ, მაგალითად, padding ბაიტი `(u8, u16)` სულაც არ არის ნულოვანი.
///
/// არ არსებობს გარანტია, რომ ნულოვანი ბაიტის ნიმუში წარმოადგენს ზოგიერთი ტიპის `T`-ის მართებულ მნიშვნელობას.
/// მაგალითად, ნულოვანი ბაიტის ნიმუში არ არის სწორი მნიშვნელობა მითითების ტიპებისთვის (`&T`, `&mut T`) და ფუნქციების მაჩვენებლებისთვის.
/// `zeroed`- ის გამოყენება ასეთ ტიპებზე იწვევს დაუყოვნებლივ [undefined behavior][ub]- ს, რადგან [the Rust compiler assumes][inv] ყოველთვის არის მოქმედი მნიშვნელობა ცვლადში, რომლის ინიცირებადაც მიიჩნევს.
///
///
/// ამას აქვს იგივე ეფექტი, რაც [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// ეს ზოგჯერ სასარგებლოა FFI- სთვის, მაგრამ ზოგადად თავიდან უნდა იქნას აცილებული.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// ამ ფუნქციის სწორი გამოყენება: მთელი რიცხვის ნულოვანი პარამეტრი.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *ამ ფუნქციის არასწორი* გამოყენება: მითითების ინიცირება ნულით.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // გაურკვეველი საქციელი!
/// let _y: fn() = unsafe { mem::zeroed() }; // Და ისევ!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ ნულოვანი მნიშვნელობა არის `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// გვერდის ავლით Rust- ის მეხსიერების ნორმალიზებას ახდენს `T` ტიპის მნიშვნელობის მოჩვენებით, ხოლო საერთოდ არაფერს აკეთებს.
///
/// **ეს ფუნქცია მოძველებულია.** გამოიყენეთ [`MaybeUninit<T>`] მის ნაცვლად.
///
/// ამორტიზაციის მიზეზი არის ის, რომ ძირითადად ფუნქციის სწორად გამოყენება შეუძლებელია: მას აქვს იგივე ეფექტი, რაც [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// როგორც [`assume_init` documentation][assume_init] განმარტავს, [the Rust compiler assumes][inv] რომ მნიშვნელობები სწორად არის ინიცირებული.
/// შედეგად, დარეკვა მაგ
/// `mem::uninitialized::<bool>()` იწვევს დაუყოვნებლივ გაურკვეველ ქცევას `bool`-ის დასაბრუნებლად, რომელიც ნამდვილად არ არის არც `true` და არც `false`.
/// უარესი, ჭეშმარიტად არაინციალიზებული მეხსიერება, როგორიცაა აქ დაბრუნებული, განსაკუთრებული იმითაა, რომ შემდგენელმა იცის, რომ მას არ აქვს ფიქსირებული მნიშვნელობა.
/// ეს განუსაზღვრელ ქცევას ქმნის არაინიციალიზებული მონაცემების ცვლაში, მაშინაც კი, თუ ამ ცვლადს აქვს მთელი ტიპის ტიპი.
/// (გაითვალისწინეთ, რომ არაინციალიზებული მთელი რიცხვების შესახებ წესები ჯერ დასრულებული არ არის, მაგრამ სანამ ისინი დასრულდება, სასურველია, რომ თავიდან აიცილოთ ისინი.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ ერთეული მნიშვნელობით მოქმედებს `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// ცვლის მნიშვნელობებს ორ მუტაბელურ ადგილას, არც ერთის დენინიალიზაციის გარეშე.
///
/// * თუ გსურთ შეცვალოთ ნაგულისხმევი ან დემური მნიშვნელობით, იხილეთ [`take`].
/// * თუ გსურთ გაცვლითი მნიშვნელობით შეცვლა, ძველი მნიშვნელობის დაბრუნებით, იხილეთ [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // უსაფრთხოება: ნედლეული მაჩვენებლები შეიქმნა უსაფრთხო მუტაბელური ცნობარიდან, რომელიც აკმაყოფილებს ყველა
    // შეზღუდვები `ptr::swap_nonoverlapping_one`-ზე
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// ანაცვლებს `dest`- ს `T`- ის ნაგულისხმევი მნიშვნელობით, უბრუნებს წინა `dest` მნიშვნელობას.
///
/// * თუ გსურთ შეცვალოთ ორი ცვლადის მნიშვნელობები, იხილეთ [`swap`].
/// * თუ ნაგულისხმევი მნიშვნელობის ნაცვლად შეცვლით გადაცემული მნიშვნელობით, იხილეთ [`replace`].
///
/// # Examples
///
/// მარტივი მაგალითი:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` საშუალებას გაძლევთ მიიღოთ სტრუქტურული ველი საკუთრებაში "empty" მნიშვნელობით ჩანაცვლებით.
/// `take`- ის გარეშე შეიძლება შეგხვდეთ შემდეგ საკითხებში:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// გაითვალისწინეთ, რომ `T` სულაც არ ახორციელებს [`Clone`]- ს დანერგვას, ასე რომ, ის ვერც კი ახდენს `self.buf`- ის კლონირებას და გადატვირთვას.
/// მაგრამ `take` შეიძლება გამოყენებულ იქნას `self.buf`- ის საწყისი მნიშვნელობის `self`- დან გამოყოფისთვის, რაც საშუალებას მისცემს დაბრუნდეს:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// გადააქვს `src` მითითებულ `dest`-ში, უბრუნებს წინა `dest` მნიშვნელობას.
///
/// არც მნიშვნელობა არ დაეცა.
///
/// * თუ გსურთ შეცვალოთ ორი ცვლადის მნიშვნელობები, იხილეთ [`swap`].
/// * თუ გსურთ შეცვალოთ ნაგულისხმევი მნიშვნელობით, იხილეთ [`take`].
///
/// # Examples
///
/// მარტივი მაგალითი:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` საშუალებას იძლევა სტრუქტურული ველის მოხმარება სხვა მნიშვნელობით ჩანაცვლებით.
/// `replace`- ის გარეშე შეიძლება შეგხვდეთ შემდეგ საკითხებში:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// გაითვალისწინეთ, რომ `T` სულაც არ იყენებს [`Clone`]- ს, ამიტომ გადაადგილების თავიდან ასაცილებლად `self.buf[i]`- ის კლონირებაც კი არ შეგვიძლია.
/// მაგრამ `replace` შეიძლება გამოყენებულ იქნას ორიგინალის მნიშვნელობის გამოყოფა ამ ინდექსში `self`- დან, რაც საშუალებას მისცემს დაბრუნდეს:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // უსაფრთხოება: ჩვენ ვკითხულობთ `dest`- დან, მაგრამ მას შემდეგ პირდაპირ ვწერთ `src`- ს,
    // ისეთი, რომ ძველი მნიშვნელობა არ არის დუბლირებული.
    // არაფერი ჩამოვარდა და აქ არაფერი არ შეიძლება panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// განკარგავს მნიშვნელობას.
///
/// ამას აკეთებს არგუმენტის [`Drop`][drop] განხორციელების გამოძახებით.
///
/// ეს ეფექტურად არაფერს აკეთებს იმ ტიპისთვის, რომელიც ახორციელებს `Copy`- ს, მაგ
/// integers.
/// ამგვარი მნიშვნელობების კოპირება ხდება და _then_ გადადის ფუნქციაში, ამიტომ მნიშვნელობა შენარჩუნებულია ამ ფუნქციის გამოძახების შემდეგ.
///
///
/// ეს ფუნქცია არ არის მაგია;იგი ფაქტიურად განმარტებულია, როგორც
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// იმის გამო, რომ `_x` გადადის ფუნქციაში, ის ავტომატურად დაეცემა ფუნქციის დაბრუნებამდე.
///
/// [drop]: Drop
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // აშკარად ჩამოაგდეს vector
/// ```
///
/// მას შემდეგ, რაც [`RefCell`] ახორციელებს სესხის აღების წესებს დროულად შესრულების დროს, `drop`- ს შეუძლია გაათავისუფლოს [`RefCell`] სესხი:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // უარი თქვით ამ სლოტზე მუტაბელურ სესხზე
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// მთელი რიცხვები და [`Copy`] განმახორციელებელი სხვა ტიპები გავლენას არ ახდენს `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x`- ის ასლი გადაადგილდება და დაეცემა
/// drop(y); // `y`- ის ასლი გადაადგილდება და დაეცემა
///
/// println!("x: {}, y: {}", x, y.0); // ჯერ კიდევ ხელმისაწვდომია
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// განმარტავს `src`-ს, როგორც `&U` ტიპის, და შემდეგ კითხულობს `src`-ს, მოცემული მნიშვნელობის გადაადგილების გარეშე.
///
/// ეს ფუნქცია არასაიმედოდ მიიჩნევს, რომ `src` მაჩვენებელი მოქმედებს [`size_of::<U>`][size_of] ბაიტისთვის `&T`-დან `&U`-ზე ტრანსმუტირებით და შემდეგ `&U`-ით წაკითხვით (გარდა იმ შემთხვევისა, როდესაც ეს ხდება სწორი გზით, მაშინაც კი, როდესაც `&U` უფრო მკაცრ მოთხოვნებს გასწორებს ვიდრე `&T`).
/// ის ასევე უსაფრთხოდ შექმნის შემცველი მნიშვნელობის ასლს `src`- დან გადაადგილების ნაცვლად.
///
/// ეს არ არის კომპილირების დროის შეცდომა, თუ `T` და `U` განსხვავებული ზომაა, მაგრამ სასურველია ამ ფუნქციის გამოყენება მხოლოდ იქ, სადაც `T` და `U` ერთნაირია.ეს ფუნქცია იწვევს [undefined behavior][ub]-ს, თუ `U` უფრო დიდია ვიდრე `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // დააკოპირეთ მონაცემები 'foo_array'- დან და განიხილეთ იგი, როგორც 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // შეცვალეთ გადაწერილი მონაცემები
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array'-ის შინაარსი არ უნდა შეცვლილიყო
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // თუ U- ს უფრო სწორად გასწორების მოთხოვნა აქვს, src შეიძლება არ იყოს სწორად გასწორებული.
    if align_of::<U>() > align_of::<T>() {
        // უსაფრთხოება: `src` არის მითითება, რომელიც გარანტირებულია, რომ ძალაშია წაკითხვისთვის.
        // აბონენტმა უნდა უზრუნველყოს რეალური ტრანსმუტაციის უსაფრთხოება.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // უსაფრთხოება: `src` არის მითითება, რომელიც გარანტირებულია, რომ ძალაშია წაკითხვისთვის.
        // ჩვენ უბრალოდ გადავამოწმეთ, რომ `src as *const U` სწორად იყო გასწორებული.
        // აბონენტმა უნდა უზრუნველყოს რეალური ტრანსმუტაციის უსაფრთხოება.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// გაუმჭვირვალე ტიპი, რომელიც წარმოადგენს enum-ის დისკრიმინატორს.
///
/// დამატებითი ინფორმაციისთვის იხილეთ ამ მოდულში [`discriminant`] ფუნქცია.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. ამ trait დანერგვები ვერ მიიღება, რადგან ჩვენ არ გვინდა რაიმე შეზღუდვა T-ზე.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// აბრუნებს მნიშვნელობას, რომელიც ცალსახად განსაზღვრავს enum ვარიანტს `v`-ში.
///
/// თუ `T` არ არის enum, ამ ფუნქციის გამოძახება არ გამოიწვევს განუსაზღვრელ ქცევას, მაგრამ დაბრუნების მნიშვნელობა არ არის განსაზღვრული.
///
///
/// # Stability
///
/// Enum- ის ვარიანტის დისკრიმინატორი შეიძლება შეიცვალოს, თუ enum- ის განმარტება შეიცვლება.
/// ზოგიერთი ვარიანტის დისკრიმინატორი არ შეიცვლება იმავე შემდგენელ კომპოზიციებს შორის.
///
/// # Examples
///
/// ეს შეიძლება გამოყენებულ იქნეს მონაცემების შედარების შესაფასებლად, ხოლო რეალური მონაცემების უგულებელყოფა:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// აბრუნებს enum ტიპის `T` ვარიანტების რაოდენობას.
///
/// თუ `T` არ არის enum, ამ ფუნქციის გამოძახება არ გამოიწვევს განუსაზღვრელ ქცევას, მაგრამ დაბრუნების მნიშვნელობა არ არის განსაზღვრული.
/// თანაბრად, თუ `T` არის enum, რომელსაც აქვს მეტი ვარიანტი, ვიდრე `usize::MAX`, დაბრუნების მნიშვნელობა არ არის მითითებული.
/// დაითვლება დაუსახლებელი ვარიანტები.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}