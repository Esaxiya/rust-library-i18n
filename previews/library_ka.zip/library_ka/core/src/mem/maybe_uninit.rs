use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// შეფუთვის ტიპი `T` არაინციალიზირებული შემთხვევების შესაქმნელად.
///
/// # ინიციალიზაცია უცვლელია
///
/// შემდგენელი, ზოგადად, მიიჩნევს, რომ ცვლადის სწორად ინიცირება ხდება ცვლადის ტიპის მოთხოვნების შესაბამისად.მაგალითად, მითითების ტიპის ცვლადი უნდა იყოს გასწორებული და არა NULL.
/// ეს არის უცვლელი, რომელიც * ყოველთვის უნდა დაიცვას, თუნდაც არაუსაფრთხო კოდში.
/// შედეგად, მითითების ტიპის ცვლადის ნულოვანი ინიცირება იწვევს მყისიერ [undefined behavior][ub]-ს, არ აქვს მნიშვნელობა გამოიყენება თუ არა ეს მითითება მეხსიერების შესასვლელად:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // გაურკვეველი საქციელი!⚠️
/// // ექვივალენტი კოდი `MaybeUninit<&i32>`- ით:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // გაურკვეველი საქციელი!⚠️
/// ```
///
/// ამას იყენებს კომპილატორი სხვადასხვა ოპტიმიზაციებისთვის, როგორიცაა გამშვები პუნქტის ამოწმებს და `enum` განლაგების ოპტიმიზაციას.
///
/// ანალოგიურად, მთლიანად არანიციალიზებულ მეხსიერებას შეიძლება ჰქონდეს რაიმე შინაარსი, ხოლო `bool` ყოველთვის უნდა იყოს `true` ან `false`.აქედან გამომდინარე, uninitialized `bool`-ის შექმნა განუსაზღვრელი ქცევაა:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // გაურკვეველი საქციელი!⚠️
/// // ექვივალენტი კოდი `MaybeUninit<bool>`- ით:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // გაურკვეველი საქციელი!⚠️
/// ```
///
/// უფრო მეტიც, არაინციალიზებული მეხსიერება განსაკუთრებული იმითაა, რომ მას არ გააჩნია ფიქსირებული მნიშვნელობა ("fixed" ნიშნავს "it won't change without being written to").ერთი და იგივე არაინციალიზებული ბაიტის მრავალჯერ წაკითხვას განსხვავებული შედეგი შეუძლია.
/// ეს განუსაზღვრელ ქცევას ქმნის არაინიციალიზებული მონაცემების ცვლაში მაშინაც კი, თუ ამ ცვლადს აქვს მთელი ტიპის ტიპი, რომელსაც სხვაგვარად შეუძლია შეინახოს *ფიქსირებული* ბიტის ნიმუში:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // გაურკვეველი საქციელი!⚠️
/// // ექვივალენტი კოდი `MaybeUninit<i32>`- ით:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // გაურკვეველი საქციელი!⚠️
/// ```
/// (გაითვალისწინეთ, რომ არაინციალიზებული მთელი რიცხვების შესახებ წესები ჯერ დასრულებული არ არის, მაგრამ სანამ ისინი დასრულდება, სასურველია, რომ თავიდან აიცილოთ ისინი.)
///
/// ამასთანავე, გახსოვდეთ, რომ ტიპების უმეტესობას აქვს დამატებითი ინვარიანტები, მხოლოდ იმის გათვალისწინებით, რომ ინიცირებულია ტიპის დონეზე.
/// მაგალითად, `1`-ის ინიცირებული [`Vec<T>`] ითვლება თავდაპირველად (მიმდინარე განხორციელების პირობებში; ეს არ წარმოადგენს სტაბილურ გარანტიას), რადგან ამის შესახებ შემდგენელმა იცის ერთადერთი მოთხოვნა, რომ მონაცემთა მაჩვენებელი არ იყოს ნულოვანი.
/// ასეთი `Vec<T>`- ის შექმნა არ იწვევს *დაუყოვნებლივ* განუსაზღვრელ ქცევას, მაგრამ გამოიწვევს განუსაზღვრელ ქცევას ყველაზე უსაფრთხო ოპერაციებით (ჩათვლით მისი ჩაშვებით).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` ემსახურება არაუსაფრთხო კოდის გააქტიურებას არაინციალიზებულ მონაცემებთან.
/// ეს არის სიგნალი შემდგენელისთვის, რომელიც მიუთითებს იმაზე, რომ აქ მონაცემები შეიძლება *არ იყოს* ინიცირებული:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // აშკარად uninitialized მითითების შექმნა.
/// // შემდგენელმა იცის, რომ `MaybeUninit<T>`- ის მონაცემები შეიძლება არასწორი იყოს, ამიტომ ეს არ არის UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // დააყენეთ იგი სწორ მნიშვნელობად.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // ამოიღეთ საწყისი მონაცემები-ეს ნებადართულია მხოლოდ * `x`- ის სათანადო ინიციალიზაციის შემდეგ!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// შემდგენელმა იცის რომ არ გააკეთოს არასწორი დაშვება ან ოპტიმიზაცია ამ კოდექსზე.
///
/// თქვენ შეიძლება წარმოიდგინოთ, რომ `MaybeUninit<T>` ოდნავ ჰგავს `Option<T>`-ს, მაგრამ ყოველგვარი გაშვების დროს თვალყურისდევნების გარეშე და უსაფრთხოების რაიმე შემოწმების გარეშე.
///
/// ## out-pointers
///
/// შეგიძლიათ გამოიყენოთ `MaybeUninit<T>` "out-pointers"- ის განსახორციელებლად: ფუნქციის მონაცემების დაბრუნების ნაცვლად, მიუთითეთ ის მაჩვენებელი რომელიმე (uninitialized) მეხსიერებას, რომ შედეგი მოათავსოთ.
/// ეს შეიძლება სასარგებლო იყოს, როდესაც აბონენტისთვის მნიშვნელოვანია იმის კონტროლი, თუ როგორ ინახება მეხსიერებაში გამოყოფილი შედეგი და გსურთ თავიდან აიცილოთ ზედმეტი ნაბიჯები.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` არ ჩამოაგდებს ძველ შინაარსს, რაც მნიშვნელოვანია.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // ახლა ვიცით, რომ `v` ინიცირებულია!ეს ასევე დარწმუნებულია, რომ vector სწორად ვარდება.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## მასივის ელემენტ-ელემენტის ინიციალიზაცია
///
/// `MaybeUninit<T>` შეიძლება გამოყენებულ იქნას დიდი მასივის ელემენტ-ელემენტის ინიციალიზაციისთვის:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // შექმენით არაინციალიზებული მასივი `MaybeUninit`.
///     // `assume_init` უსაფრთხოა, რადგან ის ტიპი, რომლის პრეტენზიაც აქ გვაქვს ინიცირებული, არის `იქნებ Uninit` ის რამოდენიმე, რომელიც არ საჭიროებს ინიციალიზაციას.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit`-ის ვარდნა არაფერს აკეთებს.
///     // ამრიგად, `ptr::write`-ის ნაცვლად, მაჩვენებლის დაუმუშავებელი დანიშვნის გამოყენება არ იწვევს ძველი არაინციალიზებული მნიშვნელობის დაცემას.
/////
///     // ასევე, თუ ამ მარყუჟის დროს არის panic, მეხსიერების გაჟონვა გვაქვს, მაგრამ მეხსიერების უსაფრთხოების საკითხი არ არსებობს.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // ყველაფერი ინიციალიზებულია.
///     // შეცვალეთ მასივი საწყისი ფორმაში.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// ასევე შეგიძლიათ იმუშაოთ ნაწილობრივ ინიცირებულ მასივებთან, რომელთა პოვნა შესაძლებელია დაბალი დონის მონაცემთა სტრუქტურებში.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // შექმენით არაინციალიზებული მასივი `MaybeUninit`.
/// // `assume_init` უსაფრთხოა, რადგან ის ტიპი, რომლის პრეტენზიაც აქ გვაქვს ინიცირებული, არის `იქნებ Uninit` ის რამოდენიმე, რომელიც არ საჭიროებს ინიციალიზაციას.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // ითვლიან ჩვენს მიერ მინიჭებული ელემენტების რაოდენობა.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // მასივის თითოეული ელემენტისთვის ჩამოაგდეთ, თუ ის გამოვყოთ.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## დარგის მიხედვით დარგის ინიცირება
///
/// თქვენ შეგიძლიათ გამოიყენოთ `MaybeUninit<T>` და [`std::ptr::addr_of_mut`] მაკრო, სტრიქების ინიციალიზაციისთვის ველი სფეროთი:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` ველის ინიციალიზაცია
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` ველის ინიციალიზაცია თუ აქ არის panic, მაშინ `String` `name` ველში იჟღინთება.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // ყველა ველი ინიცირებულია, ამიტომ ჩვენ ვეძახით `assume_init`-ს, რომ მიიღოთ თავდაპირველი Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` გარანტირებული აქვს იგივე ზომა, გასწორება და ABI, როგორც `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// ამასთან, გახსოვდეთ, რომ * `MaybeUninit<T>` შემცველი ტიპი სულაც არ არის იგივე განლაგება;Rust ზოგადად არ იძლევა იმის გარანტიას, რომ `Foo<T>` ველებს აქვთ იგივე თანმიმდევრობა, როგორც `Foo<U>`, მაშინაც კი, თუ `T` და `U` ერთნაირი ზომა და გასწორება აქვთ.
///
/// უფრო მეტიც, რადგან ნებისმიერი ბიტის მნიშვნელობა მოქმედებს `MaybeUninit<T>`- სთვის, შემდგენელს არ შეუძლია გამოიყენოს non-zero/niche-filling ოპტიმიზაცია, რის შედეგადაც შეიძლება უფრო დიდი ზომა იყოს:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// თუ `T` არის FFI-უსაფრთხო, მაშინ `MaybeUninit<T>` ასევე უსაფრთხოა.
///
/// მიუხედავად იმისა, რომ `MaybeUninit` არის `#[repr(transparent)]` (მიუთითებს, რომ იგი იძლევა იგივე ზომის, გასწორების და ABI- ს გარანტიას, როგორც `T`), ეს * * არ შეცვლის არცერთ წინა სიგნალს.
/// `Option<T>` და `Option<MaybeUninit<T>>` შეიძლება მაინც ჰქონდეს განსხვავებული ზომა და ტიპები, რომლებიც შეიცავს `T` ტიპის ველს, შეიძლება ასახული იყოს (და ზომის) განსხვავებულად, ვიდრე ეს ველი `MaybeUninit<T>` იყოს.
/// `MaybeUninit` არის კავშირის ტიპი და `#[repr(transparent)]` პროფკავშირებზე არასტაბილურია (იხ. [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// დროთა განმავლობაში, პროფკავშირებზე `#[repr(transparent)]`-ის ზუსტი გარანტიები შეიძლება განვითარდეს და `MaybeUninit` შეიძლება დარჩეს ან დარჩეს `#[repr(transparent)]`.
/// როგორც ნათქვამია, `MaybeUninit<T>`*ყოველთვის* გარანტირებს, რომ მას აქვს იგივე ზომა, გასწორება და ABI, როგორც `T`;უბრალოდ, `MaybeUninit` გარანტიის განხორციელების გზით შეიძლება განვითარდეს.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// ლანგარი, ასე რომ მასში შეგვიძლია სხვა ტიპების შეფუთვა.ეს სასარგებლოა გენერატორებისთვის.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // არ ვურეკავთ `T::clone()`- ს, არ შეგვიძლია ვიცოდეთ, ვართ თუ არა ინიცირებული საკმარისი ამისთვის.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// ქმნის ახალ `MaybeUninit<T>`-ს, რომელიც ინიცირებულია მოცემული მნიშვნელობით.
    /// უსაფრთხოა დარეკვა [`assume_init`] ამ ფუნქციის დაბრუნების მნიშვნელობაზე.
    ///
    /// გაითვალისწინეთ, რომ `MaybeUninit<T>`-ის ვარდნა არასოდეს დარეკავს `T`-ის ვარდნაზე.
    /// თქვენი პასუხისმგებლობაა დარწმუნდეთ, რომ `T` დაეცემა, თუ იგი ინიციალიზებული იქნა.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// ქმნის ახალ `MaybeUninit<T>` არაინციალიზებულ მდგომარეობაში.
    ///
    /// გაითვალისწინეთ, რომ `MaybeUninit<T>`-ის ვარდნა არასოდეს დარეკავს `T`-ის ვარდნაზე.
    /// თქვენი პასუხისმგებლობაა დარწმუნდეთ, რომ `T` დაეცემა, თუ იგი ინიციალიზებული იქნა.
    ///
    /// იხილეთ რამდენიმე მაგალითი [type-level documentation][MaybeUninit].
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// შექმენით ახალი მასივი `MaybeUninit<T>` ერთეულში, არაინციალიზებულ მდგომარეობაში.
    ///
    /// Note: future Rust ვერსიაში ეს მეთოდი შეიძლება გახდეს ზედმეტი, როდესაც მასივის პირდაპირი სინტაქსი საშუალებას იძლევა [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// ქვემოთ მოყვანილ მაგალითში შეიძლება გამოყენებულ იქნას `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// აბრუნებს მონაცემების (შესაძლოა უფრო მცირე) ნაჭერს, რომელიც რეალურად წაკითხულია
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // უსაფრთხოება: არაინციალიზებული `[MaybeUninit<_>; LEN]` მოქმედებს.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// ქმნის ახალ `MaybeUninit<T>` არაინციალიზებულ მდგომარეობაში, მეხსიერება ივსება `0` ბაიტით.ეს დამოკიდებულია `T`- ზე, არის თუ არა ეს სათანადო ინიციალიზაცია.
    ///
    /// მაგალითად, `MaybeUninit<usize>::zeroed()` ინიცირებულია, მაგრამ `MaybeUninit<&'static i32>::zeroed()` იმიტომ არ არის, რომ მითითებები არ უნდა იყოს ნულოვანი.
    ///
    /// გაითვალისწინეთ, რომ `MaybeUninit<T>`-ის ვარდნა არასოდეს დარეკავს `T`-ის ვარდნაზე.
    /// თქვენი პასუხისმგებლობაა დარწმუნდეთ, რომ `T` დაეცემა, თუ იგი ინიციალიზებული იქნა.
    ///
    /// # Example
    ///
    /// ამ ფუნქციის სწორი გამოყენება: სტრუქტურის ინიცირება ნულოვანით, სადაც სტრუქტურის ყველა ველს შეუძლია გამართოს ბიტის ნიმუში 0, როგორც სწორი მნიშვნელობა.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *ამ ფუნქციის არასწორი* გამოყენება: `x.zeroed().assume_init()` დარეკვა, როდესაც `0` არ არის სწორი ბიტის ნიმუში ტიპისთვის:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // წყვილის შიგნით, ჩვენ ვქმნით `NotZero`, რომელსაც არ გააჩნია სწორი დისკრიმინატორი.
    /// // ეს არის გაურკვეველი საქციელი.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // უსაფრთხოება: `u.as_mut_ptr()` წერტილები გამოიყოფა მეხსიერებაში.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// ადგენს `MaybeUninit<T>` მნიშვნელობას.
    /// ეს გადაწერს წინა მნიშვნელობას ჩაშვების გარეშე, ამიტომ ფრთხილად იყავით, რომ არ გამოიყენოთ იგი ორჯერ, თუ არ გსურთ გამოტოვოთ გამანადგურებლის გაშვება.
    ///
    /// თქვენი მოხერხებულობისთვის, ეს ასევე აბრუნებს `self`-ის (ახლა უსაფრთხოდ ინიცირებულ) შინაარსს მუდამ მითითებით.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // უსაფრთხოება: ჩვენ ახლახანს ჩამოვაყალიბეთ ეს მნიშვნელობა.
        unsafe { self.assume_init_mut() }
    }

    /// იღებს მაჩვენებელს მოცემულ მნიშვნელობამდე.
    /// ამ მაჩვენებლის წაკითხვა ან მისი მითითებად გადაქცევა განუსაზღვრელი ქცევაა, თუ `MaybeUninit<T>` არ არის ინიცირებული.
    /// მეხსიერების ჩაწერა, რომელზეც მიუთითებს ეს მაჩვენებელი (non-transitively), არ არის განსაზღვრული ქცევა (გარდა `UnsafeCell<T>`- ის შიგნით).
    ///
    /// # Examples
    ///
    /// ამ მეთოდის სწორი გამოყენება:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // შექმენით მითითება `MaybeUninit<T>`- ში.ეს კარგია, რადგან ჩვენ ის ვიწყეთ.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *არასწორი* ამ მეთოდის გამოყენება:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // ჩვენ შევქმენით მითითება არაინიციალიზებულ vector- ზე!ეს არის გაურკვეველი საქციელი.⚠️
    /// ```
    ///
    /// (გაითვალისწინეთ, რომ ჯერ არაა დასრულებული არაინიციალიზებული მონაცემების მითითების წესები, მაგრამ სანამ ისინი დასრულდება, მიზანშეწონილია მათი თავიდან აცილება).
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` და `ManuallyDrop` ორივე `repr(transparent)` არის, ასე რომ ჩვენ შეგვიძლია მაჩვენებლის ჩართვა.
        self as *const _ as *const T
    }

    /// მიიღებს მუტაბელურ მაჩვენებელს მოცემულ მნიშვნელობამდე.
    /// ამ მაჩვენებლის წაკითხვა ან მისი მითითებად გადაქცევა განუსაზღვრელი ქცევაა, თუ `MaybeUninit<T>` არ არის ინიცირებული.
    ///
    /// # Examples
    ///
    /// ამ მეთოდის სწორი გამოყენება:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // შექმენით მითითება `MaybeUninit<Vec<u32>>`- ში.
    /// // ეს კარგია, რადგან ჩვენ ის ვიწყეთ.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *არასწორი* ამ მეთოდის გამოყენება:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // ჩვენ შევქმენით მითითება არაინიციალიზებულ vector- ზე!ეს არის გაურკვეველი საქციელი.⚠️
    /// ```
    ///
    /// (გაითვალისწინეთ, რომ ჯერ არაა დასრულებული არაინიციალიზებული მონაცემების მითითების წესები, მაგრამ სანამ ისინი დასრულდება, მიზანშეწონილია მათი თავიდან აცილება).
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` და `ManuallyDrop` ორივე `repr(transparent)` არის, ასე რომ ჩვენ შეგვიძლია მაჩვენებლის ჩართვა.
        self as *mut _ as *mut T
    }

    /// გამოაქვს მნიშვნელობა `MaybeUninit<T>` კონტეინერიდან.ეს შესანიშნავი გზაა იმის უზრუნველსაყოფად, რომ მონაცემები დაეცემა, რადგან შედეგად `T` ექვემდებარება ვარდნის ჩვეულებრივ დამუშავებას.
    ///
    /// # Safety
    ///
    /// აბონენტის გადასაწყვეტია, რომ `MaybeUninit<T>` ნამდვილად არის თავდაპირველ მდგომარეობაში.ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს დაუყოვნებლივ გაურკვეველ ქცევას.
    /// [type-level documentation][inv] შეიცავს მეტ ინფორმაციას ამ ინიცირების ინვარიანტის შესახებ.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// ამასთანავე, გახსოვდეთ, რომ ტიპების უმეტესობას აქვს დამატებითი ინვარიანტები, მხოლოდ იმის გათვალისწინებით, რომ ინიცირებულია ტიპის დონეზე.
    /// მაგალითად, `1`-ის ინიცირებული [`Vec<T>`] ითვლება თავდაპირველად (მიმდინარე განხორციელების პირობებში; ეს არ წარმოადგენს სტაბილურ გარანტიას), რადგან ამის შესახებ შემდგენელმა იცის ერთადერთი მოთხოვნა, რომ მონაცემთა მაჩვენებელი არ იყოს ნულოვანი.
    ///
    /// ასეთი `Vec<T>`- ის შექმნა არ იწვევს *დაუყოვნებლივ* განუსაზღვრელ ქცევას, მაგრამ გამოიწვევს განუსაზღვრელ ქცევას ყველაზე უსაფრთხო ოპერაციებით (ჩათვლით მისი ჩაშვებით).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// ამ მეთოდის სწორი გამოყენება:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *არასწორი* ამ მეთოდის გამოყენება:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ჯერ არ იყო ინიცირებული, ამიტომ ამ ბოლო ხაზმა გამოიწვია განუსაზღვრელი ქცევა.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს `self`- ის ინიცირება.
        // ეს ასევე ნიშნავს, რომ `self` უნდა იყოს `value` ვარიანტი.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// კითხულობს მნიშვნელობას `MaybeUninit<T>` კონტეინერიდან.შედეგად მიღებული `T` ექვემდებარება ვარდნის ჩვეულებრივ დამუშავებას.
    ///
    /// შეძლებისდაგვარად სასურველია გამოიყენოთ [`assume_init`], რაც ხელს უშლის `MaybeUninit<T>` შინაარსის დუბლირებას.
    ///
    /// # Safety
    ///
    /// აბონენტის გადასაწყვეტია, რომ `MaybeUninit<T>` ნამდვილად არის თავდაპირველ მდგომარეობაში.ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს გაურკვეველ ქცევას.
    /// [type-level documentation][inv] შეიცავს მეტ ინფორმაციას ამ ინიცირების ინვარიანტის შესახებ.
    ///
    /// უფრო მეტიც, ეს იგივე მონაცემების ასლს ტოვებს `MaybeUninit<T>`-ს.
    /// მონაცემთა მრავალი ასლის გამოყენებისას (`assume_init_read` რამდენჯერმე დარეკვით, ან პირველად `assume_init_read` და შემდეგ [`assume_init`] დარეკვით), თქვენი პასუხისმგებლობაა, დარწმუნდეთ, რომ ეს მონაცემები შეიძლება მართლაც იქნეს დუბლირებული.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ამ მეთოდის სწორი გამოყენება:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` არის `Copy`, ამიტომ შეიძლება რამდენჯერმე წავიკითხოთ.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` მნიშვნელობის დუბლირება კარგია, ამიტომ შეიძლება რამდენჯერმე წავიკითხოთ.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *არასწორი* ამ მეთოდის გამოყენება:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // ახლა ჩვენ შევქმენით ერთი და იგივე vector- ის ორი ეგზემპლარი, რაც ორმაგად უფასო გახდის ⚠️ როდესაც ორივე დაეცემა!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს `self`- ის ინიცირება.
        // `self.as_ptr()`- დან კითხვა უსაფრთხოა, რადგან `self` უნდა იყოს ინიცირებული.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// ჩამოყრის მოცემულ მნიშვნელობას ადგილზე.
    ///
    /// თუ თქვენ ფლობთ `MaybeUninit`-ს, მის ნაცვლად შეგიძლიათ გამოიყენოთ [`assume_init`].
    ///
    /// # Safety
    ///
    /// აბონენტის გადასაწყვეტია, რომ `MaybeUninit<T>` ნამდვილად არის თავდაპირველ მდგომარეობაში.ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს გაურკვეველ ქცევას.
    ///
    /// ამას გარდა, უნდა დაკმაყოფილდეს `T` ტიპის ყველა დამატებითი ინვარიანტი, რადგან `T` (ან მისი წევრების) `Drop` განხორციელება შეიძლება ამას დაეყრდნოს.
    /// მაგალითად, `1`-ის ინიცირებული [`Vec<T>`] ითვლება თავდაპირველად (მიმდინარე განხორციელების პირობებში; ეს არ წარმოადგენს სტაბილურ გარანტიას), რადგან ამის შესახებ შემდგენელმა იცის ერთადერთი მოთხოვნა, რომ მონაცემთა მაჩვენებელი არ იყოს ნულოვანი.
    ///
    /// ამგვარი `Vec<T>`- ის ვარდნა გაურკვეველ ქცევას გამოიწვევს.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `self` არის ინიცირებული და
        // აკმაყოფილებს `T`- ის ყველა ინვარიანტს.
        // მნიშვნელობის ადგილზე ვარდნა უსაფრთხოა, თუ ეს ასეა.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// იღებს გაზიარებულ მნიშვნელობას.
    ///
    /// ეს შეიძლება სასარგებლო იყოს, როდესაც ჩვენ გვინდა წვდომა იქონიოს `MaybeUninit`, რომელიც ინიცირებულია, მაგრამ არ გვაქვს `MaybeUninit`-ის საკუთრება (ხელს უშლის `.assume_init()`)-ს გამოყენებას).
    ///
    /// # Safety
    ///
    /// ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს განუსაზღვრელ ქცევას: აბონენტის გადასაწყვეტია, რომ `MaybeUninit<T>` ნამდვილად არის თავდაპირველ მდგომარეობაში.
    ///
    ///
    /// # Examples
    ///
    /// ### ამ მეთოდის სწორი გამოყენება:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` ინიციალიზაცია:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // ახლა, როდესაც ცნობილია, რომ ჩვენი `MaybeUninit<_>` ინიციალიზებულია, კარგია, რომ შევქმნათ მასზე საერთო მითითება:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // უსაფრთხოება: `x` ინიცირებულია.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *არასწორი* ამ მეთოდის გამოყენება:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // ჩვენ შევქმენით მითითება არაინიციალიზებულ vector- ზე!ეს არის გაურკვეველი საქციელი.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `MaybeUninit`- ის ინიცირება `Cell::set`- ის გამოყენებით:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // მითითება არაინციალიზებული `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს `self`- ის ინიცირება.
        // ეს ასევე ნიშნავს, რომ `self` უნდა იყოს `value` ვარიანტი.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// იღებს mutable (unique) მითითებას მოცემულ მნიშვნელობაზე.
    ///
    /// ეს შეიძლება სასარგებლო იყოს, როდესაც ჩვენ გვინდა წვდომა იქონიოს `MaybeUninit`, რომელიც ინიცირებულია, მაგრამ არ გვაქვს `MaybeUninit`-ის საკუთრება (ხელს უშლის `.assume_init()`)-ს გამოყენებას).
    ///
    /// # Safety
    ///
    /// ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს განუსაზღვრელ ქცევას: აბონენტის გადასაწყვეტია, რომ `MaybeUninit<T>` ნამდვილად არის თავდაპირველ მდგომარეობაში.
    /// მაგალითად, `.assume_init_mut()` არ შეიძლება გამოყენებულ იქნას `MaybeUninit`-ის ინიცირება.
    ///
    /// # Examples
    ///
    /// ### ამ მეთოდის სწორი გამოყენება:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// ინიციალებს შეყვანის ბუფერის *ყველა* ბაიტს.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` ინიციალიზაცია:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // ახლა ჩვენ ვიცით, რომ `buf` ინიცირებულია, ასე რომ, ჩვენ შეგვიძლია `.assume_init()` შევიტანოთ იგი.
    /// // ამასთან, `.assume_init()`-ის გამოყენებამ შეიძლება გამოიწვიოს 2048 ბაიტის `memcpy`.
    /// // იმის დასადასტურებლად, რომ ჩვენი ბუფერი ინიცირებულია, მისი კოპირების გარეშე, ჩვენ ვაახლებთ `&mut MaybeUninit<[u8; 2048]>`-ს `&mut [u8; 2048]`-ზე:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // უსაფრთხოება: `buf` ინიცირებულია.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // ახლა ჩვენ შეგვიძლია გამოვიყენოთ `buf` როგორც ჩვეულებრივი ნაჭერი:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *არასწორი* ამ მეთოდის გამოყენება:
    ///
    /// თქვენ არ შეგიძლიათ გამოიყენოთ `.assume_init_mut()` მნიშვნელობის დასაწყისისთვის:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // ჩვენ შევქმენით (mutable) მითითება არაციონალიზებული `bool`- ზე!
    ///     // ეს არის გაურკვეველი საქციელი.⚠️
    /// }
    /// ```
    ///
    /// მაგალითად, თქვენ არ შეგიძლიათ [`Read`] არაინიციალიზირებულ ბუფერად:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) მითითება არაინციალიზებულ მეხსიერებაზე!
    ///                             // ეს არის გაურკვეველი საქციელი.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// ასევე არ შეგიძლიათ გამოიყენოთ პირდაპირი საველე წვდომა სფეროში-სფეროთი ეტაპობრივი ინიციალიზაციისთვის:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) მითითება არაინციალიზებულ მეხსიერებაზე!
    ///                  // ეს არის გაურკვეველი საქციელი.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) მითითება არაინციალიზებულ მეხსიერებაზე!
    ///                  // ეს არის გაურკვეველი საქციელი.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): ამჟამად ჩვენ ვეყრდნობით ზემოთქმულის არასწორობას, ანუ გვაქვს მითითებები არაინციალიზებულ მონაცემებზე (მაგ., `libcore/fmt/float.rs`).
    // სტაბილიზაციამდე საბოლოო გადაწყვეტილება უნდა მივიღოთ წესების შესახებ.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს `self`- ის ინიცირება.
        // ეს ასევე ნიშნავს, რომ `self` უნდა იყოს `value` ვარიანტი.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// გამოაქვს მნიშვნელობები `MaybeUninit` კონტეინერების მასივიდან.
    ///
    /// # Safety
    ///
    /// აბონენტზეა დამოკიდებული, რომ მასივის ყველა ელემენტი თავდაპირველ მდგომარეობაშია.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // უსაფრთხოება: ახლა უსაფრთხოა, რადგან ყველა ელემენტის ინიციალიზაცია მოხდა
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * აბონენტი უზრუნველყოფს მასივის ყველა ელემენტის ინიციალიზაციას
        // * `MaybeUninit<T>` და T გარანტირებულია, რომ ერთნაირი განლაგება აქვთ
        // * MaybeUnint არ დაეცემა, ამიტომ არ არსებობს ორმაგი უფასო და, შესაბამისად, გადაკეთება უსაფრთხოა
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// ვთქვათ, რომ ყველა ელემენტია ინიცირებული, მიიღე ნაჭერი.
    ///
    /// # Safety
    ///
    /// აბონენტის გადასაწყვეტია, რომ `MaybeUninit<T>` ელემენტები ნამდვილად არიან თავდაპირველ მდგომარეობაში.
    ///
    /// ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს გაურკვეველ ქცევას.
    ///
    /// დამატებითი ინფორმაციისთვის იხილეთ [`assume_init_ref`].
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // უსაფრთხოება: `*const [T]`- ზე ნაჭრის გადატანა უსაფრთხოა, რადგან აბონენტი ამის გარანტიას იძლევა
        // `slice` ინიციალიზებულია და `იქნებ Uninit` გარანტირებულად ჰქონდეს იგივე განლაგება, როგორც `T`.
        // მიღებული მაჩვენებელი მოქმედებს, ვინაიდან იგი ეხება `slice`-ის საკუთრებაში არსებულ მეხსიერებას, რომელიც წარმოადგენს მითითებას და, ამრიგად, გარანტირებულია, რომ მოქმედებს კითხვისთვის.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// თუ ვივარაუდებთ ყველა ელემენტის ინიციალიზაციას, მიიღეთ მათ მუტაბელური ნაჭერი.
    ///
    /// # Safety
    ///
    /// აბონენტის გადასაწყვეტია, რომ `MaybeUninit<T>` ელემენტები ნამდვილად არიან თავდაპირველ მდგომარეობაში.
    ///
    /// ამის გამოძახება, როდესაც შინაარსი ჯერ არ არის სრულად ინიცირებული, იწვევს გაურკვეველ ქცევას.
    ///
    /// დამატებითი ინფორმაციისთვის იხილეთ [`assume_init_mut`].
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // უსაფრთხოება: მსგავსია უსაფრთხოების შენიშვნებისთვის `slice_get_ref`, მაგრამ ჩვენ გვაქვს
        // ცვალებადი მითითება, რომელიც ასევე გარანტირებულია, რომ ძალაშია წერისთვის.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// იღებს მასივს მასივის პირველ ელემენტზე.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// მიიღება mutable მაჩვენებელი მასივის პირველ ელემენტზე.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// კოპირებს ელემენტებს `src`-დან `this`-მდე, უბრუნებს ცვალებად მითითებას `this`-ის ახლა ინცილირებულ შინაარსზე.
    ///
    /// თუ `T` არ ახორციელებს `Copy`-ს, გამოიყენეთ [`write_slice_cloned`]
    ///
    /// ეს მსგავსია [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია იქნება panic, თუ ორ ნაჭერს აქვს სხვადასხვა სიგრძე.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // უსაფრთხოება: ჩვენ უბრალოდ გადავწერეთ ლენის ყველა ელემენტი თავისუფალ შესაძლებლობებში
    /// // vec-ის პირველი src.len() ელემენტები ახლა მოქმედებს.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // უსაფრთხოება: &[T] და&[MaybeUninit<T>] აქვს იგივე განლაგება
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // უსაფრთხოება: სწორი ელემენტები ახლახან გადაწერა `this`-ში, ამიტომ იგი ინიციალიზებულია
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// ახდენს ელემენტების კლონირებას `src`-დან `this`-მდე და უბრუნებს `this`-ის ახლა ინცილირებულ შინაარსს.
    /// ნებისმიერი უკვე ინიცირებული ელემენტები არ ჩამოაგდეს.
    ///
    /// თუ `T` ახორციელებს `Copy`-ს, გამოიყენეთ [`write_slice`]
    ///
    /// ეს მსგავსია [`slice::clone_from_slice`]- ის, მაგრამ არ ჩამოაგდებს არსებულ ელემენტებს.
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია იქნება panic, თუ ორ ნაჭერს აქვს სხვადასხვა სიგრძე, ან თუ განხორციელდება `Clone` panics.
    ///
    /// თუ არსებობს panic, უკვე კლონირებული ელემენტები ჩამოიშლება.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // უსაფრთხოება: ჩვენ ახლახან შევაჯგუფეთ len-ის ყველა ელემენტი სათადარიგო შესაძლებლობებში
    /// // vec-ის პირველი src.len() ელემენტები ახლა მოქმედებს.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice-სგან განსხვავებით, ეს არ მოუწოდებს ნაჭერს clone_from_slice-ს, ეს იმიტომ ხდება, რომ `MaybeUninit<T: Clone>` არ ახორციელებს Clone-ს.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // უსაფრთხოება: ეს ნედლი ნაჭერი შეიცავს მხოლოდ ინიცირებულ ობიექტებს
                // ამის გამო დაშვება დაშვებულია.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: ჩვენ მკაფიოდ უნდა დავჭრათ ისინი იმავე სიგრძეზე
        // საზღვრების შემოწმების გასასუფთავებლად და ოპტიმიზატორი გამოიმუშავებს დამახსოვრებას მარტივი შემთხვევებისთვის (მაგალითად T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // დაცვაა საჭირო b/c panic შეიძლება მოხდეს კლონის დროს
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // უსაფრთხოება: ძალაში შესული ელემენტები ახლახან იქნა დაწერილი `this`- ში, ამიტომ იგი ინციტირდება
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}