use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// შეფუთვა, რომელიც აფერხებს შემდგენელს ავტომატურად დარეკვისთვის `T` დესტრუქტორი.
/// ეს შესაფუთი არის 0 ღირებულება.
///
/// `ManuallyDrop<T>` ექვემდებარება განლაგების იმავე ოპტიმიზაციას, როგორც `T`.
/// შედეგად, მას *არანაირი გავლენა არ აქვს* იმ დაშვებებზე, რასაც შემდგენელი აკეთებს მისი შინაარსის შესახებ.
/// მაგალითად, `ManuallyDrop<&mut T>`- ის [`mem::zeroed`]- ით ინიცირება გაურკვეველი ქცევაა.
/// თუ არაინციალიზებული მონაცემების მოგვარება გჭირდებათ, მის ნაცვლად გამოიყენეთ [`MaybeUninit<T>`].
///
/// გაითვალისწინეთ, რომ `ManuallyDrop<T>`-ის შიგნით მნიშვნელობის წვდომა უსაფრთხოა.
/// ეს ნიშნავს, რომ `ManuallyDrop<T>`, რომლის შინაარსიც დაეცა, არ უნდა გამოვლინდეს საზოგადოებრივი უსაფრთხო API- ს საშუალებით.
/// შესაბამისად, `ManuallyDrop::drop` არ არის უსაფრთხო.
///
/// # `ManuallyDrop` და ვარდნა ბრძანებით.
///
/// Rust- ს აქვს კარგად განსაზღვრული მნიშვნელობები [drop order].
/// იმისათვის, რომ დარწმუნდეთ, რომ ველები ან ადგილობრივები ჩამოყრილია კონკრეტული თანმიმდევრობით, გადაალაგეთ დეკლარაციები ისე, რომ ნაგულისხმევი ვარდნის ბრძანება იყოს სწორი.
///
/// წვეთი ბრძანების გასაკონტროლებლად შესაძლებელია `ManuallyDrop`-ის გამოყენება, მაგრამ ამისათვის საჭიროა უსაფრთხო კოდი და განტვირთვისას რთულია სწორად გაკეთება.
///
///
/// მაგალითად, თუ გსურთ დარწმუნდეთ, რომ კონკრეტული ველი ჩამოიშლება სხვების შემდეგ, გახადეთ სტრუქტურის ბოლო ველი:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` დაეცემა `children` შემდეგ.
///     // Rust იძლევა გარანტიას, რომ ველები ჩამოიშლება დეკლარაციის თანმიმდევრობით.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// გადაიტანეთ მნიშვნელობა, ხელით რომ ჩამოაგდეს.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // თქვენ კვლავ შეგიძლიათ უსაფრთხოდ იმოქმედოთ ამ მნიშვნელობაზე
    /// assert_eq!(*x, "Hello");
    /// // მაგრამ `Drop` აქ არ გაშვება
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// გამოაქვს მნიშვნელობა `ManuallyDrop` კონტეინერიდან.
    ///
    /// ეს საშუალებას იძლევა კვლავ დაეცეს მნიშვნელობა.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // ეს ჩამოაგდებს `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// გამოაქვს მნიშვნელობა `ManuallyDrop<T>` კონტეინერიდან.
    ///
    /// ეს მეთოდი პირველ რიგში მიზნად ისახავს წვეთოვანი მნიშვნელობების გადაადგილებას.
    /// იმის ნაცვლად, რომ გამოიყენოთ [`ManuallyDrop::drop`], რომ ხელით დააგდოთ მნიშვნელობა, შეგიძლიათ გამოიყენოთ ეს მეთოდი, რომ აიღოთ მნიშვნელობა და გამოიყენოთ, როგორც სასურველია.
    ///
    /// შეძლებისდაგვარად სასურველია გამოიყენოთ [`into_inner`][`ManuallyDrop::into_inner`], რაც ხელს უშლის `ManuallyDrop<T>` შინაარსის დუბლირებას.
    ///
    ///
    /// # Safety
    ///
    /// ეს ფუნქცია სემანტიკურად გადაადგილდება შემცველ მნიშვნელობას შემდგომი გამოყენების თავიდან ასაცილებლად, ამ კონტეინერის მდგომარეობა უცვლელი რჩება.
    /// თქვენი პასუხისმგებლობაა, დარწმუნდეთ, რომ ეს `ManuallyDrop` აღარ გამოიყენება.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // უსაფრთხოება: ჩვენ ვკითხულობთ მითითებიდან, რომელიც გარანტირებულია
        // ძალაშია წაკითხვისთვის.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// ხელით ჩამოყრის მოცემულ მნიშვნელობას.ეს ზუსტად უდრის [`ptr::drop_in_place`] დარეკვას მითითებული მნიშვნელობის მაჩვენებელი.
    /// როგორც ასეთი, თუ მოცემული მნიშვნელობა არ არის შეფუთული სტრუქტურა, დესტრუქტორს მოუწოდებენ ადგილზე მნიშვნელობის გადაადგილების გარეშე, და ამრიგად ის შეიძლება გამოყენებულ იქნას [pinned] მონაცემების უსაფრთხოდ ჩამოსაგდებად.
    ///
    /// თუ თქვენ ფლობთ ღირებულებას, შეგიძლიათ გამოიყენოთ [`ManuallyDrop::into_inner`] მის ნაცვლად.
    ///
    /// # Safety
    ///
    /// ეს ფუნქცია აწარმოებს მოცემული მნიშვნელობის დესტრუქტორს.
    /// თვით დესტრუქტორის მიერ შეტანილი ცვლილებების გარდა, მეხსიერება უცვლელი რჩება და რაც შეეხება შემდგენელს, კვლავ აქვს ბიტიანი ნიმუში, რომელიც მოქმედებს `T` ტიპისთვის.
    ///
    ///
    /// ამასთან, ამ "zombie" მნიშვნელობას არ უნდა დაექვემდებაროს უსაფრთხო კოდი და ამ ფუნქციის გამოძახება არ უნდა განხორციელდეს ერთზე მეტჯერ.
    /// მნიშვნელობის გამოყენებას ჩამოშლის შემდეგ, ან მნიშვნელობას რამდენჯერმე ჩამოაგდებენ, შეიძლება გამოიწვიოს განუსაზღვრელი ქცევა (დამოკიდებულია იმაზე, თუ რას აკეთებს `drop`).
    /// ჩვეულებრივ, ამას ხელს უშლის ტიპის სისტემა, მაგრამ `ManuallyDrop`- ის მომხმარებლებმა უნდა დაიცვან ეს გარანტიები შემდგენლის დახმარების გარეშე.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // უსაფრთხოება: ჩვენ ვუშვებთ მნიშვნელობას, რომელსაც მიუთითებს ცვალებადი მითითება
        // რაც გარანტირებულია, რომ ძალაშია წერისთვის.
        // აბონენტს ევალება დარწმუნდეს, რომ `slot` აღარ დაეცა.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}