/// კონვერტაცია [`Iterator`]-დან.
///
/// `FromIterator` ტიპის გამოყენებით, თქვენ განსაზღვრავთ თუ როგორ შეიქმნება იგი იტერატორისგან.
/// ეს ჩვეულებრივია იმ ტიპებისთვის, რომლებიც აღწერს რაიმე სახის კოლექციას.
///
/// [`FromIterator::from_iter()`] მას იშვიათად უწოდებენ აშკარად და მის ნაცვლად გამოიყენება [`Iterator::collect()`] მეთოდით.
///
/// მეტი მაგალითისთვის იხილეთ [`Iterator::collect()`]'s დოკუმენტაცია.
///
/// Იხილეთ ასევე: [`IntoIterator`].
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// [`Iterator::collect()`]-ის გამოყენება `FromIterator`-ის ირიბი გამოყენებისათვის:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator`-ის დანერგვა თქვენი ტიპისთვის:
///
/// ```
/// use std::iter::FromIterator;
///
/// // კოლექციის ნიმუში, ეს მხოლოდ Vec- ის შესაფუთია<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // მოდით მივცეთ მას რამდენიმე მეთოდი, რათა შევქმნათ და დავამატოთ მას.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // და ჩვენ განვახორციელებთ FromIterator-ს
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // ახლა ჩვენ შეგვიძლია გავაკეთოთ ახალი იტერატორი ...
/// let iter = (0..5).into_iter();
///
/// // ... და გააკეთე MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // შეაგროვეთ ნამუშევრებიც!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// ქმნის მნიშვნელობას იტერატორისგან.
    ///
    /// იხილეთ [module-level documentation] მეტი.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`]- ში გადაყვანა.
///
/// `IntoIterator` ტიპის გამოყენებით, თქვენ განსაზღვრავთ, თუ როგორ გადაიქცევა იგი iterator-ში.
/// ეს ჩვეულებრივია იმ ტიპებისთვის, რომლებიც აღწერს რაიმე სახის კოლექციას.
///
/// `IntoIterator`- ის დანერგვის ერთი უპირატესობა ის არის, რომ თქვენი ტიპი იქნება [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Იხილეთ ასევე: [`FromIterator`].
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// `IntoIterator`-ის დანერგვა თქვენი ტიპისთვის:
///
/// ```
/// // კოლექციის ნიმუში, ეს მხოლოდ Vec- ის შესაფუთია<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // მოდით მივცეთ მას რამდენიმე მეთოდი, რათა შევქმნათ და დავამატოთ მას.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // და ჩვენ განვახორციელებთ IntoIterator-ს
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // ახლა შეგვიძლია გავაკეთოთ ახალი კოლექცია ...
/// let mut c = MyCollection::new();
///
/// // ... დაამატეთ მას რამდენიმე რამ ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... და შემდეგ გადააქციე itterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator`- ის გამოყენება trait bound- ით არის ჩვეულებრივი.ეს საშუალებას აძლევს შეყვანის შეგროვების ტიპი შეიცვალოს, სანამ ის კვლავ იტერატორია.
/// დამატებითი საზღვრების დაზუსტება შესაძლებელია შეზღუდვით
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// ელემენტების ტიპი განმეორდება.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// რომელ იტერატორად ვაქცევთ ამას?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// ქმნის iterator მნიშვნელობიდან.
    ///
    /// იხილეთ [module-level documentation] მეტი.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// კოლექციის გაფართოება იტერატორის შინაარსით.
///
/// Iterator აწარმოებს მთელ რიგ ღირებულებებს, ხოლო კოლექციები ასევე შეიძლება მივიჩნიოთ როგორც ღირებულებების სერია.
/// `Extend` trait ხიდის ამ ხვრელს, საშუალებას გაძლევთ გააგრძელოთ კოლექცია ამ იტერატორის შინაარსის ჩათვლით.
/// კოლექციის გაფართოებისას უკვე არსებული გასაღებით განახლდება ეს ჩანაწერი, ან იმ კოლექციების შემთხვევაში, რომლებიც საშუალებას აძლევს მრავალჯერადი ჩანაწერს თანაბარი გასაღებით, ჩასმულია ჩანაწერი.
///
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// // შეგიძლიათ გააგრძელოთ სიმებიანი რამდენიმე სიმბოლოთი:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// განმახორციელებელი `Extend`:
///
/// ```
/// // კოლექციის ნიმუში, ეს მხოლოდ Vec- ის შესაფუთია<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // მოდით მივცეთ მას რამდენიმე მეთოდი, რათა შევქმნათ და დავამატოთ მას.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // მას შემდეგ, რაც MyCollection-ს აქვს i32-ების სია, ჩვენ ვახორციელებთ Extend for i32-ს
/// impl Extend<i32> for MyCollection {
///
///     // ეს ცოტათი მარტივია კონკრეტული ტიპის ხელმოწერით: ჩვენ შეგვიძლია ვუწოდოთ ვრცელდება ყველაფერზე, რაც შეიძლება გადაიქცეს Iterator-ით, რომელიც გვაძლევს i32-ებს.
///     // იმიტომ, რომ ჩვენ გვჭირდება i32s, რომ ჩავდოთ MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // განხორციელება ძალიან მარტივია: განლაგდით იტერატორის საშუალებით და add() თითოეული ელემენტისთვის.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // მოდით გავაფართოვოთ ჩვენი კოლექცია კიდევ სამი ნომრით
/// c.extend(vec![1, 2, 3]);
///
/// // ჩვენ დავამატეთ ეს ელემენტები ბოლომდე
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// ავრცელებს კრებულს იტერატორის შინაარსთან ერთად.
    ///
    /// რადგან ეს არის ერთადერთი საჭირო მეთოდი ამ trait- სთვის, [trait-level] დოკუმენტები შეიცავს უფრო დეტალებს.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// // შეგიძლიათ გააგრძელოთ სიმებიანი რამდენიმე სიმბოლოთი:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// აფართოებს კოლექციას ზუსტად ერთი ელემენტით.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// იტოვებს მოცულობას კოლექციაში მოცემული რაოდენობის დამატებითი ელემენტებისთვის.
    ///
    /// ნაგულისხმევი განხორციელება არაფერს აკეთებს.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}