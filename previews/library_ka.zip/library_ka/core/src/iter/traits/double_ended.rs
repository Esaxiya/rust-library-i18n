use crate::ops::{ControlFlow, Try};

/// იტერატორს შეუძლია ელემენტები გამოიღოს ორივე ბოლოდან.
///
/// ის, რაც ახორციელებს `DoubleEndedIterator`-ს, აქვს ერთი დამატებითი შესაძლებლობა, რაც ახორციელებს [`Iterator`]-ს: შესაძლებლობა აიღოს `საქონელიც უკანა მხრიდან, ისევე როგორც წინა.
///
///
/// მნიშვნელოვანია აღინიშნოს, რომ ორივე უკან და უკან ერთი და იგივე დიაპაზონში მუშაობს და არ გადაიკვეთება: განმეორება მთავრდება, როდესაც ისინი შუაზე ხვდებიან.
///
/// [`Iterator`] პროტოკოლის მსგავსი მეთოდით, ერთხელ `DoubleEndedIterator` დააბრუნებს [`None`] [`next_back()`]- დან, ისევ დარეკვით შეიძლება აღარ დაბრუნდეს [`Some`].
/// [`next()`] და [`next_back()`] ამ მიზნის შესაცვლელია.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// ამოიღებს და აბრუნებს ელემენტს იტერატორის ბოლოდან.
    ///
    /// აბრუნებს `None`-ს, როდესაც ელემენტები აღარ არის.
    ///
    /// [trait-level] დოკუმენტები შეიცავს უფრო დეტალებს.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// "DoubleEndedIterator"-ის მეთოდების მიერ მიღებული ელემენტები შეიძლება განსხვავდებოდეს ["Iterator"]-ის მეთოდების მიერ მოცემული ელემენტებისგან:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// იტერატორს უკანა მხრიდან მიჰყავს `n` ელემენტებით.
    ///
    /// `advance_back_by` არის [`advance_by`]-ის საპირისპირო ვერსია.ეს მეთოდი მოუთმენლად გამოტოვებს `n` ელემენტებს უკნიდან, [`next_back`] მდე `n` ჯერ დარეკვით, სანამ [`None`] არ გამოჩნდება.
    ///
    /// `advance_back_by(n)` დააბრუნებს [`Ok(())`] თუ iterator წარმატებით მიიწევს `n` ელემენტებით, ან [`Err(k)`] თუ [`None`] შეხვდება, სადაც `k` არის ელემენტების რაოდენობა, რომლითაც იტერატორი მიიწევს ელემენტების ამოწურვამდე (მაგ.
    /// იტერატორის სიგრძე).
    /// გაითვალისწინეთ, რომ `k` ყოველთვის ნაკლებია ვიდრე `n`.
    ///
    /// `advance_back_by(0)` დარეკვით არ მოიხმარს რაიმე ელემენტს და ყოველთვის დააბრუნებს [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // მხოლოდ `&3` გამოტოვეს
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// აბრუნებს `n` მე-9 ელემენტს იტერატორის ბოლოდან.
    ///
    /// ეს არსებითად არის [`Iterator::nth()`]-ის საპირისპირო ვერსია.
    /// მიუხედავად იმისა, რომ ინდექსაციის ოპერაციების უმეტესობა, დათვლა იწყება ნულიდან, ამიტომ `nth_back(0)` დააბრუნებს პირველ მნიშვნელობას ბოლოდან, `nth_back(1)` მეორე და ა.შ.
    ///
    ///
    /// გაითვალისწინეთ, რომ ყველა ელემენტი დასრულდება და დაბრუნებულ ელემენტს შორის მოხმარდება, მათ შორის დაბრუნებული ელემენტი.
    /// ეს ასევე ნიშნავს, რომ `nth_back(0)` რამდენჯერმე დარეკვისას იგივე iterator დააბრუნებს სხვადასხვა ელემენტებს.
    ///
    /// `nth_back()` დააბრუნებს [`None`] თუ `n` მეტია ან ტოლია იტერატორის სიგრძეზე.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` დარეკვით რამდენჯერმე არ შეცვლის ინტერატორს:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `None` დაბრუნების შემთხვევაში, თუ `n + 1` ელემენტზე ნაკლებია:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// ეს არის [`Iterator::try_fold()`]-ის საპირისპირო ვერსია: იგი იღებს ელემენტებს, დაწყებული იტერატორის უკანა მხრიდან.
    ///
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // იმის გამო, რომ იგი მოკლედ შეირთო, დარჩენილი ელემენტები კვლავ ხელმისაწვდომია იტერატორის მეშვეობით.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iterator მეთოდი, რომელიც ამცირებს iterator-ის ელემენტებს ერთ, საბოლოო მნიშვნელობამდე, დაწყებული უკნიდან.
    ///
    /// ეს არის [`Iterator::fold()`]-ის საპირისპირო ვერსია: იგი იღებს ელემენტებს, დაწყებული იტერატორის უკანა მხრიდან.
    ///
    /// `rfold()` იღებს ორ არგუმენტს: საწყისი მნიშვნელობა და დახურვა ორი არგუმენტით: 'accumulator' და ელემენტი.
    /// დახურვა აბრუნებს მნიშვნელობას, რომელიც უნდა ჰქონდეს აკუმულატორს შემდეგი გამეორებისთვის.
    ///
    /// საწყისი მნიშვნელობა არის მნიშვნელობა, რომელიც აკუმულატორს ექნება პირველ ზარზე.
    ///
    /// ამ დახურვის გამოყენების შემდეგ, იტერატორის ყველა ელემენტზე, `rfold()` აბრუნებს აკუმულატორს.
    ///
    /// ამ ოპერაციას ზოგჯერ 'reduce' ან 'inject' უწოდებენ.
    ///
    /// დასაკეცი სასარგებლოა, როდესაც თქვენ გაქვთ რაიმეს კოლექცია და გსურთ მისგან ერთი ღირებულების წარმოება.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ყველა ელემენტის ჯამი
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ეს მაგალითი ქმნის სტრიქონს, საწყისი მნიშვნელობით დაწყებული და თითოეული ელემენტით უკანა მხრიდან წინა მხარეს გაგრძელდება:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// უკანა მხრიდან ეძებს იტერატორის ელემენტს, რომელიც აკმაყოფილებს პრედიკატს.
    ///
    /// `rfind()` იღებს დახურვას, რომელიც აბრუნებს `true` ან `false`.
    /// იგი იყენებს ამ დახურვას იტერატორის თითოეულ ელემენტზე, დასასრულიდან დაწყებული, და თუ რომელიმე მათგანი დააბრუნებს `true`, მაშინ `rfind()` აბრუნებს [`Some(element)`].
    /// თუ ისინი დააბრუნებენ `false`-ს, ის უბრუნებს [`None`]-ს.
    ///
    /// `rfind()` არის მოკლე ჩართვა;სხვა სიტყვებით რომ ვთქვათ, იგი შეწყვეტს დამუშავებას, როგორც კი დახურვა დაუბრუნდება `true`.
    ///
    /// იმის გამო, რომ `rfind()` იღებს მითითებას და მრავალი განმეორება ახსენებს ცნობებს, ეს იწვევს დამაბნეველ სიტუაციას, როდესაც არგუმენტი წარმოადგენს ორმაგ მითითებას.
    ///
    /// ეს ეფექტი შეგიძლიათ ნახოთ ქვემოთ მოყვანილ მაგალითებში, `&&x`- ით.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// პირველ `true`-ზე შეჩერება:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // ჩვენ კვლავ შეგვიძლია გამოვიყენოთ `iter`, რადგან უფრო მეტი ელემენტია.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}