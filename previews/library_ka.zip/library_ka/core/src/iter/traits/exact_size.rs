/// იტერატორი, რომელმაც იცის მისი ზუსტი სიგრძე.
///
/// ბევრმა არ იცის რამდენჯერ გაიმეორებს, მაგრამ ზოგიერთმა იცის.
/// თუ იტერატორმა იცის რამდენჯერ შეუძლია გამეორება, ამ ინფორმაციის ხელმისაწვდომობის უზრუნველყოფა შეიძლება სასარგებლო იყოს.
/// მაგალითად, თუ გსურთ უკან გამეორება, კარგი დასაწყისია იცოდეთ სად არის დასასრული.
///
/// `ExactSizeIterator`-ის დანერგვისას, თქვენ ასევე უნდა განახორციელოთ [`Iterator`].
/// ამის გაკეთებისას, [`Iterator::size_hint`] *-ის დანერგვამ უნდა დააბრუნოს იტერატორის ზუსტი ზომა.
///
/// [`len`] მეთოდს აქვს ნაგულისხმევი განხორციელება, ასე რომ თქვენ ის ჩვეულებრივ არ უნდა გამოიყენოთ.
/// ამასთან, შეიძლება შეძლოთ უფრო შესრულებული შესრულების უზრუნველყოფა, ვიდრე ნაგულისხმევი, ასე რომ, ამ შემთხვევაში მისი გადაჭარბებას აზრი აქვს.
///
///
/// გაითვალისწინეთ, რომ ეს trait არის უსაფრთხო trait და, როგორც ასეთი *არ* და *ვერ იძლევა* გარანტიას, რომ დაბრუნებული სიგრძე არის სწორი.
/// ეს ნიშნავს, რომ `unsafe` კოდი ** არ უნდა დაეყრდნოს [`Iterator::size_hint`]- ის სისწორეს.
/// არასტაბილური და არაუსაფრთხო [`TrustedLen`](super::marker::TrustedLen) trait იძლევა ამ დამატებით გარანტიას.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// // სასრულმა სპექტრმა ზუსტად იცის რამდენჯერ გაიმეორებს მას
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs]- ში ჩვენ განვახორციელეთ [`Iterator`], `Counter`.
/// მოდით განვახორციელოთ `ExactSizeIterator` ამისთვისაც:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // ჩვენ შეგვიძლია მარტივად გამოვთვალოთ განმეორების დარჩენილი რაოდენობა.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // ახლა კი მისი გამოყენება შეგვიძლია!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// აბრუნებს იტერატორის ზუსტ სიგრძეს.
    ///
    /// დანერგვა უზრუნველყოფს, რომ iterator დააბრუნებს `len()` მნიშვნელობას ზუსტად `len()` ჯერ, ვიდრე [`None`] დაბრუნდება.
    ///
    /// ამ მეთოდს აქვს ნაგულისხმევი განხორციელება, ასე რომ თქვენ ის ჩვეულებრივ არ უნდა განახორციელოთ პირდაპირ.
    /// ამასთან, თუ თქვენ შეგიძლიათ უზრუნველყოთ უფრო ეფექტური განხორციელება, ამის გაკეთება შეგიძლიათ.
    /// მაგალითისთვის იხილეთ [trait-level] დოკუმენტები.
    ///
    /// ამ ფუნქციას აქვს იგივე უსაფრთხოების გარანტიები, რაც [`Iterator::size_hint`] ფუნქციას.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// // სასრულმა სპექტრმა ზუსტად იცის რამდენჯერ გაიმეორებს მას
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: ეს მტკიცება ზედმეტად თავდაცვითია, მაგრამ ის ამოწმებს უცვლელს
        // გარანტირებულია trait- ით.
        // თუ ეს trait იყო rust-შიდა, ჩვენ შეგვიძლია გამოვიყენოთ debug_assert !;აცხადებენ_ eq!შეამოწმებს Rust მომხმარებლის ყველა იმპლემენტაციას.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// აბრუნებს `true` თუ iterator ცარიელია.
    ///
    /// ამ მეთოდს აქვს ნაგულისხმევი განხორციელება [`ExactSizeIterator::len()`]- ის გამოყენებით, ასე რომ თქვენ აღარ გჭირდებათ მისი განხორციელება.
    ///
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}