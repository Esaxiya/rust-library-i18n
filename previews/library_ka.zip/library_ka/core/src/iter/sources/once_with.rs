use crate::iter::{FusedIterator, TrustedLen};

/// ქმნის იტერატორს, რომელიც ზარმაცით წარმოქმნის მნიშვნელობას ზუსტად ერთხელ, მოწოდებული დახურვის გამოძახებით.
///
/// ეს ჩვეულებრივ გამოიყენება ერთი მნიშვნელობის გენერატორის ადაპტაციისთვის [`chain()`] სხვა სახის განმეორებით.
/// შეიძლება თქვენ გაქვთ იტერატორი, რომელიც თითქმის ყველაფერს ფარავს, მაგრამ გჭირდებათ დამატებითი განსაკუთრებული შემთხვევა.
/// შეიძლება თქვენ გაქვთ ფუნქცია, რომელიც მუშაობს იტერატორებზე, მაგრამ საჭიროა მხოლოდ ერთი მნიშვნელობის დამუშავება.
///
/// [`once()`]-ისგან განსხვავებით, ეს ფუნქცია ზარმაცად გამოიმუშავებს მნიშვნელობას მოთხოვნის შემთხვევაში.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::iter;
///
/// // ერთი ყველაზე მარტოხელა რიცხვია
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // მხოლოდ ერთი, სულ ეს არის ის, რასაც ვიღებთ
/// assert_eq!(None, one.next());
/// ```
///
/// ჯაჭვის შედგენა სხვა იტერატორთან ერთად.
/// ვთქვათ, რომ ჩვენ გვინდა განმეორდეს `.foo` დირექტორიის თითოეული ფაილი, ასევე კონფიგურაციის ფაილი,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ჩვენ უნდა გადავიყვანოთ DirEntry-s-ის iterator-დან PathBufs-ის iterator-ით, ამიტომ გამოვიყენებთ რუკას
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ახლა ჩვენი iterator მხოლოდ ჩვენი კონფიგურაციის ფაილისთვის
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // ჯაჭვი ორი iterators ერთად ერთ დიდ iterator
/// let files = dirs.chain(config);
///
/// // ეს მოგვცემს .foo და .foorc ფაილების ყველა ფაილს
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// იტერატორი, რომელიც იძლევა `A` ტიპის ერთ ელემენტს, მოცემული დახურვის `F: FnOnce() -> A` გამოყენებით.
///
///
/// ეს `struct` იქმნება [`once_with()`] ფუნქციით.
/// იხილეთ მეტი მისი დოკუმენტაცია.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}