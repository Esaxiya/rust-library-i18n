use crate::iter::{FusedIterator, TrustedLen};

/// ქმნის ახალ იტერატორს, რომელიც `A` ტიპის ელემენტებს უსასრულოდ იმეორებს მოწოდებული დახურვის გამოყენებით, გამეორება, `F: FnMut() -> A`.
///
/// `repeat_with()` ფუნქცია განმეორებით რეკავს განმეორებით.
///
/// `repeat_with()`-ის მსგავსი უსასრულო განმეორება ხშირად გამოიყენება ადაპტერებთან, როგორიცაა [`Iterator::take()`], რათა მათ სასრული გახდეს.
///
/// თუ თქვენ გჭირდებათ iterator-ის ელემენტი, ახორციელებს [`Clone`]-ს, ხოლო წყაროს ელემენტის მეხსიერებაში შენახვა კარგია, ამის ნაცვლად უნდა გამოიყენოთ [`repeat()`] ფუნქცია.
///
///
/// `repeat_with()`-ის მიერ წარმოებული იტერატორი არ არის [`DoubleEndedIterator`].
/// თუ თქვენ გჭირდებათ `repeat_with()` [`DoubleEndedIterator`]-ის დასაბრუნებლად, გახსენით GitHub-ის საკითხი, რომელიც განმარტავს თქვენი გამოყენების შემთხვევას.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::iter;
///
/// // დავუშვათ, ჩვენ გვაქვს ტიპის გარკვეული მნიშვნელობა, რომელიც არ არის `Clone` ან რომელსაც ჯერ არ სურს მეხსიერებაში, რადგან ის ძვირია:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // განსაკუთრებული მნიშვნელობა სამუდამოდ:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// მუტაციის გამოყენება და სასრული წასვლა:
///
/// ```rust
/// use std::iter;
///
/// // ნულოვანიდან მესამეზე მესამე ძალა:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... და ახლა ჩვენ დასრულდა
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// იტერატორი, რომელიც `A` ტიპის ელემენტებს უსასრულოდ იმეორებს `F: FnMut() -> A` დახურვის გამოყენებით.
///
///
/// ეს `struct` იქმნება [`repeat_with()`] ფუნქციით.
/// იხილეთ მეტი მისი დოკუმენტაცია.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}