use crate::fmt;

/// ქმნის ახალ iterator-ს, სადაც თითოეული iteration მოუწოდებს დახურულ `F: FnMut() -> Option<T>`-ს.
///
/// ეს საშუალებას გვაძლევს შევქმნათ მორგებული იტერატორი ნებისმიერი ქცევით, უფრო გამოკვეთილი სინტაქსის გამოყენების გარეშე, სპეციალური ტიპის შექმნისა და მისთვის [`Iterator`] trait განხორციელების გარეშე.
///
/// გაითვალისწინეთ, რომ `FromFn` გამხსნელი არ აკეთებს დაშვებებს დახურვის ქცევის შესახებ და, შესაბამისად, კონსერვატიულად არ ახორციელებს [`FusedIterator`]-ს, ან [`Iterator::size_hint()`]-ს გადააჭარბებს მის სტანდარტულ `(0, None)`-ს.
///
///
/// დახურვას შეუძლია გამოიყენოს გადაღებები და მისი გარემო, განმეორებით განავრცოს მდგომარეობა.იმისდა მიხედვით, თუ როგორ გამოიყენება იტერატორი, ამან შეიძლება მოითხოვოს დახურვისას [`move`] საკვანძო სიტყვის მითითება.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// მოდით განვახორციელოთ მრიცხველის იტერატორი [module-level documentation]- დან:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // ჩვენი რაოდენობის გაზრდა.სწორედ ამიტომ დავიწყეთ ნულიდან.
///     count += 1;
///
///     // შეამოწმეთ, დასრულდა თუ არა თვლა.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// იტერატორი, სადაც თითოეული გამეორება მოუწოდებს დახურულ `F: FnMut() -> Option<T>`-ს.
///
/// ეს `struct` იქმნება [`iter::from_fn()`] ფუნქციით.
/// იხილეთ მეტი მისი დოკუმენტაცია.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}