use crate::iter::{FusedIterator, TrustedLen};

/// ქმნის ახალ იტერატორს, რომელიც უსასრულოდ იმეორებს ერთ ელემენტს.
///
/// `repeat()` ფუნქცია განმეორებით იმეორებს ერთ მნიშვნელობას.
///
/// `repeat()`-ის მსგავსი უსასრულო განმეორება ხშირად გამოიყენება ადაპტერებთან, როგორიცაა [`Iterator::take()`], რათა მათ სასრული გახდეს.
///
/// თუ თქვენ გჭირდებათ iterator-ის ელემენტის ტიპი არ ახორციელებს `Clone`-ს, ან თუ არ გსურთ განმეორებითი ელემენტის მეხსიერებაში შენარჩუნება, ამის ნაცვლად შეგიძლიათ გამოიყენოთ [`repeat_with()`] ფუნქცია.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// ძირითადი გამოყენება:
///
/// ```
/// use std::iter;
///
/// // ნომერი ოთხი 4
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // დიახ, ჯერ კიდევ ოთხი
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`]- ით სასრული მიდის:
///
/// ```
/// use std::iter;
///
/// // რომ ბოლო მაგალითი ძალიან ბევრი იყო.მოდით მხოლოდ ოთხი ოთხი გვქონდეს.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... და ახლა ჩვენ დასრულდა
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// იტერატორი, რომელიც უსასრულოდ იმეორებს ელემენტს.
///
/// ეს `struct` იქმნება [`repeat()`] ფუნქციით.იხილეთ მეტი მისი დოკუმენტაცია.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}