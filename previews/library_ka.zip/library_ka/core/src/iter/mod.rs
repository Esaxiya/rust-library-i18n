//! კომპოზიციური გარე განმეორება.
//!
//! თუ თქვენ აღმოჩნდა გარკვეული კოლექცია და გჭირდებათ ოპერაციის შესრულება აღნიშნული კოლექციის ელემენტებზე, თქვენ სწრაფად გადაეყრებით 'iterators'-ს.
//! იტერატორები ძლიერ გამოიყენება იდიომატურ Rust კოდში, ამიტომ მათი გაცნობა ღირს.
//!
//! უფრო მეტის ახსნამდე მოდით ვისაუბროთ იმაზე, თუ როგორ არის სტრუქტურირებული ეს მოდული:
//!
//! # Organization
//!
//! ეს მოდული ძირითადად ორგანიზებულია ტიპის მიხედვით:
//!
//! * [Traits] ძირითადი ნაწილია: ეს traits განსაზღვრავს თუ რა სახის ინტერატორები არსებობს და რისი გაკეთება შეგიძლიათ მათთან.ამ traits- ის მეთოდების გათვალისწინებით ღირს დამატებითი სასწავლო დრო.
//! * [Functions] რამდენიმე სასარგებლო განმეორების შესაქმნელად გამოსადეგი გზები.
//! * [Structs] ხშირად ამ მეთოდის traits სხვადასხვა მეთოდების დასაბრუნებელი ტიპებია.თქვენ ჩვეულებრივ გსურთ გაეცნოთ `struct`-ს შექმნის მეთოდს, ვიდრე `struct`-ს.
//! რატომ დაწვრილებითი ინფორმაციისთვის იხილეთ "[განმახორციელებელი იტერატორი](#ახორციელებს-iterator)".
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Ის არის!მოდით განვახორციელოთ iterators.
//!
//! # Iterator
//!
//! ამ მოდულის გული და სულია [`Iterator`] trait.[`Iterator`]- ის ბირთვი ასე გამოიყურება:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! იტერატორს აქვს მეთოდი, [`next`], რომელიც დარეკვისას უბრუნებს [`ვარიანტს`]<Item>`
//! [`next`] დააბრუნებს [`Some(Item)`] მანამ, სანამ ელემენტებია, და როდესაც ისინი ამოიწურება, `None` დააბრუნებს და მიუთითებს, რომ გამეორება დასრულებულია.
//! ინდივიდუალურ iterators-ს შეუძლია აირჩიოს განმეორების განახლება, ამიტომ [`next`]-ზე დარეკვამ შეიძლება საბოლოოდ დაიწყოს [`Some(Item)`]-ის დაბრუნება რაღაც მომენტში (მაგალითად, იხილეთ [`TryIter`]).
//!
//!
//! [`Iterator`]-ის სრული განმარტება ასევე შეიცავს უამრავ სხვა მეთოდს, მაგრამ ისინი სტანდარტული მეთოდებია, აგებული [`next`] თავზე და ასე უფასოდ მიიღებთ მათ.
//!
//! იტერატორები ასევე კომპოზიციურია და საერთოა მათი ჯაჭვის დაყენება დამუშავების უფრო რთული ფორმების გასაკეთებლად.დამატებითი ინფორმაციისთვის იხილეთ ქვემოთ მოცემული [Adapters](#adapters) განყოფილება.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # იტერაციის სამი ფორმა
//!
//! არსებობს სამი საერთო მეთოდი, რომელსაც შეუძლია შექმნას განმეორებითი კოლექციიდან:
//!
//! * `iter()`, რომელიც განმეორდება `&T`- ზე.
//! * `iter_mut()`, რომელიც განმეორდება `&mut T`- ზე.
//! * `into_iter()`, რომელიც განმეორდება `T`- ზე.
//!
//! სტანდარტული ბიბლიოთეკის სხვადასხვა ნივთმა შეიძლება გამოიყენოს სამიდან ერთი ან მეტი, საჭიროების შემთხვევაში.
//!
//! # განმახორციელებელი Iterator
//!
//! საკუთარი iterator-ის შექმნა მოიცავს ორ ნაბიჯს: `struct`-ის შექმნა iterator-ის მდგომარეობის შესანარჩუნებლად და შემდეგ [`Iterator`]-ის განხორციელება ამ `struct`-სთვის.
//! ამიტომ ამ მოდულში ამდენი სტრუქტურაა: თითოეული iterator და iterator adapter არის ერთი.
//!
//! მოდით გავაკეთოთ iterator სახელად `Counter`, რომელიც ითვლის `1`-დან `5`-მდე:
//!
//! ```
//! // პირველი, სტრუქტურა:
//!
//! /// იტერატორი, რომელიც ითვლის ერთიდან ხუთამდე
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ჩვენ გვსურს ჩვენი რიცხვი ერთზე დავიწყოთ, მოდით დავამატოთ new() მეთოდი.
//! // ეს არ არის მკაცრად საჭირო, მაგრამ მოსახერხებელია.
//! // გაითვალისწინეთ, რომ `count`- ს ნულიდან ვიწყებთ, ქვემოთ მოყვანილ `next()`'s- ის განხორციელებისას ვნახავთ რატომ.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // შემდეგ, ჩვენ ვატარებთ `Iterator`-ს ჩვენი `Counter`-სთვის:
//!
//! impl Iterator for Counter {
//!     // ჩვენ ვიანგარიშებთ usize-ით
//!     type Item = usize;
//!
//!     // next() ერთადერთი საჭირო მეთოდია
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // ჩვენი რაოდენობის გაზრდა.სწორედ ამიტომ დავიწყეთ ნულიდან.
//!         self.count += 1;
//!
//!         // შეამოწმეთ, დასრულდა თუ არა თვლა.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // ახლა კი მისი გამოყენება შეგვიძლია!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`] ამ გზით დარეკვა განმეორდება.Rust- ს აქვს კონსტრუქცია, რომელსაც შეუძლია თქვენს იტერატორზე დარეკოს [`next`], სანამ არ მიაღწევს `None`.მოდით, გადავიდეთ შემდეგზე.
//!
//! ასევე გაითვალისწინეთ, რომ `Iterator` უზრუნველყოფს ნაგულისხმევი მეთოდების დანერგვას, როგორიცაა `nth` და `fold`, რომლებიც შინაგანად უწოდებენ `next`-ს.
//! ამასთან, ასევე შესაძლებელია დაწეროთ ისეთი მეთოდების მორგებული განხორციელება, როგორიცაა `nth` და `fold`, თუ იტერატორს შეუძლია უფრო ეფექტურად გამოთვალოს ისინი `next` დარეკვის გარეშე.
//!
//! # `for` მარყუჟები და `IntoIterator`
//!
//! Rust-ის `for` მარყუჟის სინტაქსი სინამდვილეში არის შაქარი განმეორებისათვის.აი `for`- ის ძირითადი მაგალითი:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! ეს დაბეჭდავს ციფრებს ერთიდან ხუთამდე, თითოეული თავის ხაზზე.მაგრამ აქ რაღაცას შეამჩნევთ: ჩვენ vector- ზე არასდროს არავის არაფერი დაურეკავს იტერატორის წარმოებისთვის.რა იძლევა?
//!
//! სტანდარტულ ბიბლიოთეკაში არის trait, რომ რაღაც გადაიქცეს იტერატორად: [`IntoIterator`].
//! ამ trait- ს აქვს ერთი მეთოდი, [`into_iter`], რომელიც [`IntoIterator`]- ის განმახორციელებელ ნივთს აქცევს iterator- ში.
//! მოდით კიდევ ერთხელ გადავხედოთ ამ `for` მარყუჟს და რას გარდაქმნის შემდგენელი:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust შაქრის შემცველობა შემდეგნაირად:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! პირველი, ჩვენ `into_iter()`-ს ვუწოდებთ მნიშვნელობას.შემდეგ, ჩვენ ემთხვევა იტერატორს, რომელიც ბრუნდება და ვეძახით [`next`]-ს, სანამ არ ვნახავთ `None`-ს.
//! ამ ეტაპზე, ჩვენ `break` გამოვდივართ მარყუჟიდან და განმეორებით დავასრულეთ.
//!
//! აქ კიდევ ერთი დახვეწილი ბიტია: სტანდარტული ბიბლიოთეკა შეიცავს [`IntoIterator`]-ის საინტერესო დანერგვას:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! სხვა სიტყვებით რომ ვთქვათ, ყველა [`Iterator`] ახორციელებს [`IntoIterator`]-ს, საკუთარი თავის დაბრუნებით.ეს ნიშნავს ორ რამეს:
//!
//! 1. თუ თქვენ წერთ [`Iterator`], შეგიძლიათ გამოიყენოთ იგი `for` მარყუჟით.
//! 2. თუ კოლექციას ქმნით, მისი [`IntoIterator`] დანერგვა საშუალებას მოგცემთ გამოიყენოთ თქვენი კოლექცია `for` მარყუჟით.
//!
//! # Iterating მითითებით
//!
//! მას შემდეგ, რაც [`into_iter()`] იღებს `self`- ს მნიშვნელობით, `for` მარყუჟის გამოყენებით კოლექციაზე გადასატანად, ამ კოლექციას მოიხმარს.ხშირად, შეიძლება დაგჭირდეთ კოლექციის განმეორება, მისი მოხმარების გარეშე.
//! მრავალი კოლექცია გთავაზობთ მეთოდებს, რომლებიც უზრუნველყოფს რეპერტუარების მითითებებს, პირობითად `iter()` და `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` კვლავ ეკუთვნის ამ ფუნქციას.
//! ```
//!
//! თუ კოლექციის ტიპი `C` უზრუნველყოფს `iter()`-ს, ის ჩვეულებრივ ახორციელებს `IntoIterator`-ს `&C`-სთვის, იმ პროგრამით, რომელიც მხოლოდ `iter()`-ს უწოდებს.
//! ანალოგიურად, `C` კოლექცია, რომელიც უზრუნველყოფს `iter_mut()`- ს, ჩვეულებრივ ახორციელებს `IntoIterator`- ს `&mut C`- სთვის დელეგირებით `iter_mut()`- ზე.ეს საშუალებას იძლევა მოსახერხებელი სტენოგრამი:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // იგივე `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // იგივე `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! მიუხედავად იმისა, რომ მრავალი კოლექცია გთავაზობთ `iter()`-ს, ყველა არ გვთავაზობს `iter_mut()`-ს.
//! მაგალითად, [`HashSet<T>`] ან [`HashMap<K, V>`] კლავიშების მუტაციამ შეიძლება კოლექცია არათანმიმდევრულ მდგომარეობაში ჩააყენოს, თუ გასაღების ჰეშები შეიცვლება, ამიტომ ამ კოლექციებში მხოლოდ `iter()` არის შემოთავაზებული.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! ფუნქციებს, რომლებიც იღებენ [`Iterator`] და აბრუნებენ სხვა [`Iterator`], ხშირად უწოდებენ 'iterator adapters', რადგან ისინი 'ადაპტერის ფორმაა.
//! pattern'.
//!
//! ჩვეულებრივი iterator ადაპტერებია [`map`], [`take`] და [`filter`].
//! დამატებითი ინფორმაციისთვის იხილეთ მათი დოკუმენტაცია.
//!
//! თუ iterator ადაპტერი panics, iterator იქნება დაუზუსტებელი (მაგრამ მეხსიერების უსაფრთხო) მდგომარეობა.
//! ამ მდგომარეობაში ასევე არ არის გარანტირებული იგივე დარჩეს Rust ვერსიებში, ასე რომ თავიდან უნდა აიცილოთ ინტენსივობის მიერ დაბრუნებული ზუსტი მნიშვნელობების იმედი, რომლებიც პანიკაში ჩავარდა.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterator-ები (და iterator [adapters](#adapters)) არის *ზარმაცი*. ეს ნიშნავს, რომ მხოლოდ iterator-ის შექმნა _do_ არ არის ძალიან ბევრი. არაფერი ხდება ისე, სანამ არ დაურეკავთ [`next`].
//! ეს ზოგჯერ დაბნეულობის წყაროა, როდესაც იტერატორი მხოლოდ მისი გვერდითი ეფექტების შესაქმნელად ხდება.
//! მაგალითად, [`map`] მეთოდი მოუწოდებს დახურვას თითოეულ ელემენტზე, რომლის განმეორებით ხდება:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! ეს ვერანაირ მნიშვნელობას არ დაბეჭდავს, რადგან მისი გამოყენება მხოლოდ ჩვენ შევქმენით iterator.შემდგენელი გვაფრთხილებს ამგვარი ქცევის შესახებ:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! [`map`] მისი გვერდითი ეფექტების დასაწერად იდიომატური გზაა `for` მარყუჟის გამოყენება ან [`for_each`] მეთოდის გამოძახება:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! იტერატორის შეფასების კიდევ ერთი საერთო გზაა [`collect`] მეთოდის გამოყენება ახალი კოლექციის წარმოებისთვის.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! განმეორებადი არ უნდა იყოს სასრული.მაგალითად, ღია დიაპაზონი არის უსასრულო გამეორება:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! [`take`] იტერატორის ადაპტერის გამოყენებაა უსასრულო იტერატორი სასრულად გადასაქცევად:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! ეს დაბეჭდავს ნომრებს `0`-დან `4`-მდე, თითოეული თავის ხაზზე.
//!
//! გაითვალისწინეთ, რომ უსასრულო ინტერატორების მეთოდები, თუნდაც ის, რომელთათვისაც შედეგის განსაზღვრა შესაძლებელია მათემატიკურად სასრულ დროში, შეიძლება არ დასრულდეს.
//! კერძოდ, ისეთი მეთოდები, როგორიცაა [`min`], რაც ზოგადად მოითხოვს იტერატორის ყველა ელემენტის გადახედვას, სავარაუდოდ წარმატებით არ დაბრუნდება ნებისმიერი უსასრულო განმეორებისათვის.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ო არა!უსასრულო მარყუჟი!
//! // `ones.min()` იწვევს უსასრულო მარყუჟს, ასე რომ, ჩვენ ამ წერტილს ვერ მივაღწევთ!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;