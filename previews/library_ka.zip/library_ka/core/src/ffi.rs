#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! კომუნალური საშუალებები, რომლებიც დაკავშირებულია საგარეო ფუნქციის ინტერფეისის (FFI) შეერთებასთან.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// ექვივალენტურია C's `void` ტიპის, როდესაც იგი გამოიყენება [pointer].
///
/// სინამდვილეში, `*const c_void` უდრის C's `const void*` და `*mut c_void` უდრის C's `void*`.
/// ნათქვამია, რომ ეს *არ არის* იგივე C-ის `void` დაბრუნების ტიპი, რომელიც არის Rust-ის `()` ტიპი.
///
/// FFI- ში გაუმჭვირვალე ტიპის მაჩვენებლების მოდელირებისთვის, `extern type`- ის სტაბილიზაციამდე, გირჩევთ გამოიყენოთ newtype შეფუთვა ცარიელი ბაიტის მასივის გარშემო.
///
/// დეტალებისთვის იხილეთ [Nomicon].
///
/// შეიძლება გამოყენებულ იქნას `std::os::raw::c_void`, თუ მათ სჭირდებათ ძველი Rust შემდგენლის მხარდაჭერა 1.1.0-მდე.
/// Rust 1.30.0- ის შემდეგ, ამ განმარტებით, იგი რეექსპორტირებულია.
/// დამატებითი ინფორმაციისთვის, გთხოვთ, წაიკითხოთ [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// გაითვალისწინეთ, რომ LLVM ცნობს ბათილი მაჩვენებლის ტიპს და გაფართოების ფუნქციებით, როგორიცაა malloc(), ჩვენ უნდა გვქონდეს წარმოდგენილი როგორც i8 * LLVM ბიტკოდში.
// აქ გამოყენებული enum უზრუნველყოფს ამას და ხელს უშლის "raw" ტიპის ბოროტად გამოყენებას მხოლოდ კერძო ვარიანტების არსებობით.
// ჩვენ ორი ვარიანტი გვჭირდება, რადგან შემდგენელი უკმაყოფილებას გამოთქვამს repr ატრიბუტთან დაკავშირებით და ჩვენ გვჭირდება მინიმუმ ერთი ვარიანტი, რადგან წინააღმდეგ შემთხვევაში enum დაუსახლებელი იქნებოდა და მინიმუმ UB მითითებული მითითებების გადამისამართება იქნებოდა UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list`- ის ძირითადი განხორციელება.
// სახელი არის WIP, ახლა გამოიყენება `VaListImpl`.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f`- ზე უცვლელია, ამიტომ თითოეული `VaListImpl<'f>` ობიექტი მიბმულია იმ ფუნქციის რეგიონში, რომელშიც განსაზღვრულია
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 XIX- ის ABI განხორციელება.
/// დამატებითი ინფორმაციისთვის იხილეთ [AArch64 Procedure Call Standard].
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC XIX- ის ABI განხორციელება.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 XIX- ის ABI განხორციელება.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// შესაფუთი `va_list`-სთვის
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` გადაიყვანეთ `VaList`-ში, რომელიც ორობითაა თავსებადი C's `va_list`-სთან.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` გადაიყვანეთ `VaList`-ში, რომელიც ორობითაა თავსებადი C's `va_list`-სთან.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait უნდა იქნას გამოყენებული საზოგადოებრივ ინტერფეისებში, ამასთან, თავად trait არ უნდა დაიშვას ამ მოდულის გარეთ.
// მომხმარებლებისთვის ახალი ტიპის trait-ის დანერგვის ნებართვა (ამით va_arg შინაარსის გამოყენება ახალი ტიპისთვის), შეიძლება გამოიწვიოს განუსაზღვრელი ქცევა.
//
// FIXME(dlrobertson): იმისათვის, რომ გამოვიყენოთ VaArgSafe trait საზოგადოებრივ ინტერფეისში, მაგრამ ასევე უზრუნველყოთ, რომ იგი არ შეიძლება გამოყენებულ იქნეს სხვაგან, trait უნდა იყოს საჯარო კერძო მოდულის ფარგლებში.
// RFC 2145-ის ამოქმედების შემდეგ გაეცანით ამის გაუმჯობესებას.
//
//
//
//
mod sealed_trait {
    /// Trait, რომელიც საშუალებას იძლევა დაშვებული ტიპების გამოყენება [super::VaListImpl::arg]- ით.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// შემდეგი არგუმენტის წინ.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // უსაფრთხოება: აბონენტმა უნდა დაიცვას უსაფრთხოების კონტრაქტი `va_arg`- სთვის.
        unsafe { va_arg(self) }
    }

    /// ასლის `va_list` მიმდინარე მდებარეობას.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // უსაფრთხოება: აბონენტმა უნდა დაიცვას უსაფრთხოების კონტრაქტი `va_end`- სთვის.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // უსაფრთხოება: ჩვენ მივწერთ `MaybeUninit`-ს, ამიტომ ხდება მისი ინიცირება და `assume_init` იურიდიული
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ეს უნდა დაურეკოს `va_end`, მაგრამ ამის სუფთა გზა არ არსებობს
        // გარანტია იმისა, რომ `drop` ყოველთვის ხვდება თავის აბონენტს, ასე რომ, `va_end` მიიღებს პირდაპირ იმავე ფუნქციას, როგორც შესაბამისი `va_copy`.
        // `man va_end` აცხადებს, რომ C ამას მოითხოვს და LLVM ძირითადად მიჰყვება C სემანტიკას, ამიტომ უნდა დავრწმუნდეთ, რომ `va_end` ყოველთვის იწოდება იმავე ფუნქციიდან, როგორც `va_copy`.
        //
        // დამატებითი ინფორმაციისთვის, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // ეს ახლა მუშაობს, რადგან `va_end` აკრძალულია ყველა მიმდინარე LLVM სამიზნეზე.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// გაანადგურეთ arg0list `ap` `va_start` ან `va_copy` ინიციალიზაციის შემდეგ.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// ასლის არგილისტის `src` მიმდინარე მდებარეობას ასლის სიაში `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// იტვირთება `T` ტიპის არგუმენტი `va_list` `ap`- დან და აძლიერებს `ap` არგუმენტს.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}