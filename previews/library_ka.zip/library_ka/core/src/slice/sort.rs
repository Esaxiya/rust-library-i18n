//! ნაჭრის დახარისხება
//!
//! ეს მოდული შეიცავს დახარისხების ალგორითმს, რომელიც დაფუძნებულია ორსონ პიტერსის ნიმუშის დამამცირებელ კვინკორტზე, გამოქვეყნებულია შემდეგ მისამართზე: <https://github.com/orlp/pdqsort>
//!
//!
//! არასტაბილური დახარისხება თავსებადია libcore-სთან, რადგან იგი არ გამოყოფს მეხსიერებას, განსხვავებით ჩვენი სტაბილური დახარისხების დანერგვისგან.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// ჩამოტვირთვისას, ასლები `src`-დან `dest`-ში.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // უსაფრთხოება: ეს არის დამხმარე კლასი.
        //          გთხოვთ, გაითვალისწინოთ მისი გამოყენება სისწორისთვის.
        //          კერძოდ, დარწმუნებული უნდა იყოს, რომ `src` და `dst` არ ემთხვევა `ptr::copy_nonoverlapping`- ს მოთხოვნებს.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// გადააქვს პირველი ელემენტი მარჯვნივ, სანამ მას არ შეხვდება უფრო დიდი ან ტოლი ელემენტი.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // უსაფრთხოება: ქვემოთ მოყვანილი სახიფათო ოპერაციები მოიცავს ინდექსაციას შეუზღუდავი შემოწმების გარეშე (`get_unchecked` და `get_unchecked_mut`)
    // და მეხსიერების კოპირება (`ptr::copy_nonoverlapping`).
    //
    // აინდექსაცია:
    //  1. ჩვენ შევამოწმე მასივის ზომა>=2-მდე.
    //  2. ყველა ინდექსაცია, რასაც ჩვენ გავაკეთებთ, ყოველთვის არის მაქსიმუმ {0 <= index < len} შორის.
    //
    // ბმეხსიერების კოპირება
    //  1. ჩვენ ვიღებთ მითითებებს მითითებებზე, რომლებიც გარანტირებული იქნება.
    //  2. ისინი ვერ გადაფარავს, რადგან ჩვენ ვიღებთ ნაკვეთის სხვაობის ინდექსების მითითებას.
    //     კერძოდ, `i` და `i-1`.
    //  3. თუ ნაკვეთი სწორად არის გასწორებული, ელემენტები სწორად გასწორებულია.
    //     აბონენტის პასუხისმგებლობაა დარწმუნდეს, რომ ნაჭერი სწორად არის გასწორებული.
    //
    // დამატებითი ინფორმაციისთვის იხილეთ ქვემოთ მოცემული კომენტარები.
    unsafe {
        // თუ პირველი ორი ელემენტი მწყობრიდან გამოდის ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // წაიკითხეთ პირველი ელემენტი სტეკზე გამოყოფილ ცვლადში.
            // თუ შემდეგი შედარების ოპერაცია panics, `hole` დაეცემა და ავტომატურად ჩაწერს ელემენტს ნაჭერში.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // გადაადგილეთ `i`-ის ელემენტი ერთი ადგილიდან მარცხნივ, რითაც ხვრელი გადააქვთ მარჯვნივ.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` დაეცემა და ამით ასლებს `tmp` `v`- ის დარჩენილ ხვრელში.
        }
    }
}

/// გადააქვს ბოლო ელემენტი მარცხნივ, სანამ არ შეხვდება პატარა ან ტოლ ელემენტს.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // უსაფრთხოება: ქვემოთ მოყვანილი სახიფათო ოპერაციები მოიცავს ინდექსაციას შეუზღუდავი შემოწმების გარეშე (`get_unchecked` და `get_unchecked_mut`)
    // და მეხსიერების კოპირება (`ptr::copy_nonoverlapping`).
    //
    // აინდექსაცია:
    //  1. ჩვენ შევამოწმე მასივის ზომა>=2-მდე.
    //  2. ყველა ინდექსაცია, რასაც ჩვენ გავაკეთებთ, ყოველთვის არის მაქსიმუმ `0 <= index < len-1` შორის.
    //
    // ბმეხსიერების კოპირება
    //  1. ჩვენ ვიღებთ მითითებებს მითითებებზე, რომლებიც გარანტირებული იქნება.
    //  2. ისინი ვერ გადაფარავს, რადგან ჩვენ ვიღებთ ნაკვეთის სხვაობის ინდექსების მითითებას.
    //     კერძოდ, `i` და `i+1`.
    //  3. თუ ნაკვეთი სწორად არის გასწორებული, ელემენტები სწორად გასწორებულია.
    //     აბონენტის პასუხისმგებლობაა დარწმუნდეს, რომ ნაჭერი სწორად არის გასწორებული.
    //
    // დამატებითი ინფორმაციისთვის იხილეთ ქვემოთ მოცემული კომენტარები.
    unsafe {
        // თუ ბოლო ორი ელემენტი მწყობრიდან გამოდის ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // წაიკითხეთ ბოლო ელემენტი სტეკით გამოყოფილ ცვლადში.
            // თუ შემდეგი შედარების ოპერაცია panics, `hole` დაეცემა და ავტომატურად ჩაწერს ელემენტს ნაჭერში.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // გადაადგილეთ `i`-ის ელემენტი ერთი ადგილიდან მარჯვნივ, რითაც ხვრელი მარცხნივ გადაიტანეთ.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` დაეცემა და ამით ასლებს `tmp` `v`- ის დარჩენილ ხვრელში.
        }
    }
}

/// ნაწილობრივ ალაგებს ნაჭერს რამდენიმე მწყობრიდან გამოსული ელემენტის გადაადგილებით.
///
/// აბრუნებს `true`-ს, თუ ნაკვეთი დალაგებულია ბოლოს.ეს ფუნქცია არის *O*(*n*) უარეს შემთხვევაში.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // რიგით მეზობელი რიგიდან გამოსული წყვილების მაქსიმალური რაოდენობა.
    const MAX_STEPS: usize = 5;
    // თუ ნაჭერი ამაზე მოკლეა, ნუ გადაიტანთ ელემენტებს.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // უსაფრთხოება: ჩვენ უკვე მკაფიოდ გავაკეთეთ შემოწმება `i < len`- ით.
        // ჩვენი ყველა შემდგომი ინდექსაცია მხოლოდ `0 <= index < len` დიაპაზონშია
        unsafe {
            // იპოვნეთ რიგით მეზობელი მწყობრიდან გამოსული ელემენტების შემდეგი წყვილი.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // დავასრულეთ?
        if i == len {
            return true;
        }

        // ნუ გადაიტანთ ელემენტებს მოკლე მასივებზე, რომელსაც აქვს შესრულების ღირებულება.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // შეცვალეთ ელემენტების წყვილი.ეს მათ სწორ წესრიგში აყენებს.
        v.swap(i - 1, i);

        // გადაიტანეთ პატარა ელემენტი მარცხნივ.
        shift_tail(&mut v[..i], is_less);
        // უფრო დიდი ელემენტის მარჯვნივ გადაწევა.
        shift_head(&mut v[i..], is_less);
    }

    // ვერ მოახერხა ნაკვეთის დალაგება ნაბიჯების შეზღუდულ რაოდენობაში.
    false
}

/// ალაგებს ნაჭერს ჩასმის დალაგების გამოყენებით, რაც არის *O*(*n*^ 2) უარეს შემთხვევაში.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// ალაგებს `v` heapsort- ის გამოყენებით, რაც იძლევა გარანტიას *O*(*n*\*log(* n*)) უარეს შემთხვევაში.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ეს ორობითი გრაფიკი პატივს სცემს უცვლელ `parent >= child`-ს.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node`-ის ბავშვები:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // აირჩიე უფროსი შვილი.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // შეჩერდით, თუ ინვალიდია `node`- ზე.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // შეცვალეთ `node` უფროს შვილთან ერთად, ერთი ნაბიჯით ჩამოიწიეთ და გააგრძელეთ საცდელი.
            v.swap(node, greater);
            node = greater;
        }
    };

    // ააშენეთ გროვა სწორ დროში.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // პოპ მაქსიმალური ელემენტები ბევრიდან.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` დანაყოფები `pivot`- ზე ნაკლები ელემენტებად, შემდეგ მოყვება `pivot`- ზე მეტი ან ტოლი ელემენტები.
///
///
/// აბრუნებს `pivot`- ზე ნაკლები ელემენტების რაოდენობას.
///
/// დანაწევრება ხორციელდება ბლოკ-ბლოკად, ფილიალირების ოპერაციების ღირებულების შემცირების მიზნით.
/// ეს იდეა წარმოდგენილია [BlockQuicksort][pdf] ნაშრომში.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // ელემენტების რაოდენობა ტიპიურ ბლოკში.
    const BLOCK: usize = 128;

    // დაყოფის ალგორითმი იმეორებს შემდეგ ნაბიჯებს დასრულებამდე:
    //
    // 1. მარცხენა მხრიდან ბლოკის მიკვლევა, რათა დადგინდეს კვარცხლბეზე მეტი ან ტოლი ელემენტები.
    // 2. კვარცხლბეკის მარჯვენა ნაწილის კვალი კვარცხლბეკზე ნაკლები ელემენტების დასადგენად.
    // 3. გაცვალეთ იდენტიფიცირებული ელემენტები მარცხენა და მარჯვენა მხარეს შორის.
    //
    // ჩვენ ვინახავთ შემდეგ ცვლადებს ელემენტების ბლოკისთვის:
    //
    // 1. `block` - ელემენტთა რაოდენობა ბლოკში.
    // 2. `start` - დაიწყეთ მაჩვენებელი `offsets` მასივში.
    // 3. `end` - დაასრულეთ მაჩვენებელი `offsets` მასივში.
    // 4. `offsets, ბლოკში არსებული მწყობრიდან გამოსული ელემენტების ინდექსები.

    // ამჟამინდელი ბლოკი მარცხენა მხარეს (`l`-დან `l.add(block_l)`)-მდე).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // ამჟამინდელი ბლოკი მარჯვენა მხარეს (`r.sub(block_r)` to `r`)-დან).
    // უსაფრთხოება: .add()- ის დოკუმენტაციაში აღნიშნულია, რომ `vec.as_ptr().add(vec.len())` ყოველთვის უსაფრთხოა
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: როდესაც VLA-ს მივიღებთ, ვცდილობთ შევქმნათ სიგრძის ერთი მასივი `min(v.len(), 2 * BLOCK) `საკმაოდ
    // ვიდრე `BLOCK` სიგრძის ორი ფიქსირებული ზომის მასივი.VLA შეიძლება იყოს უფრო cache-ეფექტური.

    // აბრუნებს ელემენტების რაოდენობას `l` (inclusive) და `r` (exclusive) მითითებას შორის.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // ჩვენ დავასრულეთ ბლოკ-ბლოკის დანაწილებისას, როდესაც `l` და `r` ძალიან ახლოს მიდიან.
        // შემდეგ ჩვენ გავაკეთებთ პაჩ-პაპის სამუშაოებს, რომ დანარჩენი ელემენტები განვალაგოთ.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // დარჩენილი ელემენტების რაოდენობა (ჯერ კიდევ არ არის შედარებული პიტორთან).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // შეცვალეთ ბლოკის ზომები ისე, რომ მარცხენა და მარჯვენა ბლოკი არ გადაფარონ, მაგრამ იდეალურად გასწორდნენ, რომ დაფაროთ დარჩენილი დარჩენილი ხარვეზი.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // `block_l` ელემენტების კვალი მარცხენა მხრიდან.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // უსაფრთხოება: ქვემოთ მოყვანილი უსაფრთხოება მოიცავს `offset`- ის გამოყენებას.
                //         ფუნქციის მიერ მოთხოვნილი პირობების შესაბამისად, მათ ვაკმაყოფილებთ, რადგან:
                //         1. `offsets_l` არის დასტის გამოყოფილი და, შესაბამისად, განიხილება როგორც ცალკე გამოყოფილი ობიექტი.
                //         2. ფუნქცია `is_less` აბრუნებს `bool`.
                //            `bool`-ის ჩასმა არასოდეს გადაფარავს `isize`-ს.
                //         3. ჩვენ გარანტირებული გვაქვს, რომ `block_l` იქნება `<= BLOCK`.
                //            გარდა ამისა, `end_l` თავდაპირველად დაყენებულია `offsets_`-ის საწყისი მაჩვენებლისთვის, რომელიც გამოცხადებულია სტეკზე.
                //            ამრიგად, ჩვენ ვიცით, რომ უარეს შემთხვევაშიც კი (`is_less`-ის ყველა გამოძახება ცრუა) ჩვენ მხოლოდ 1 ბაიტი ვიქნებით დასასრულს.
                //        აქ კიდევ ერთი უსაფრთხოებაა `elem` მოხსენიება.
                //        ამასთან, `elem` თავდაპირველად იყო ნაჭრის საწყისი მაჩვენებელი, რომელიც ყოველთვის მართებულია.
                unsafe {
                    // განშტოების შედარება.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // `block_r` ელემენტების კვალი მარჯვენა მხრიდან.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // უსაფრთხოება: ქვემოთ მოყვანილი უსაფრთხოება მოიცავს `offset`- ის გამოყენებას.
                //         ფუნქციის მიერ მოთხოვნილი პირობების შესაბამისად, მათ ვაკმაყოფილებთ, რადგან:
                //         1. `offsets_r` არის დასტის გამოყოფილი და, შესაბამისად, განიხილება როგორც ცალკე გამოყოფილი ობიექტი.
                //         2. ფუნქცია `is_less` აბრუნებს `bool`.
                //            `bool`-ის ჩასმა არასოდეს გადაფარავს `isize`-ს.
                //         3. ჩვენ გარანტირებული გვაქვს, რომ `block_r` იქნება `<= BLOCK`.
                //            გარდა ამისა, `end_r` თავდაპირველად დაყენებულია `offsets_`-ის საწყისი მაჩვენებლისთვის, რომელიც გამოცხადებულია სტეკზე.
                //            ამრიგად, ჩვენ ვიცით, რომ ყველაზე ცუდ შემთხვევაშიც კი (`is_less`- ის ყველა გამოძახება ნამდვილია) ჩვენ მხოლოდ 1 ბაიტი ვიქნებით ბოლომდე.
                //        აქ კიდევ ერთი უსაფრთხოებაა `elem` მოხსენიება.
                //        ამასთან, `elem` თავდაპირველად `1 *sizeof(T)` იყო ბოლომდე და ჩვენ შევამცირეთ იგი `1* sizeof(T)`- ით, ვიდრე მასზე წვდომა მოხდებოდა.
                //        გარდა ამისა, `block_r` ამტკიცებდა, რომ `BLOCK`- ზე ნაკლებია და `elem` მაქსიმუმ მიუთითებს ნაკვეთის დასაწყისზე.
                unsafe {
                    // განშტოების შედარება.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // მწყობრიდან გამოსული ელემენტების რაოდენობა მარცხენა და მარჯვენა მხარეს შორის შესაცვლელად.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // ერთდროულად ერთი წყვილის შეცვლის ნაცვლად, უფრო ეფექტურია ციკლური პერმუტაციის შესრულება.
            // ეს არ არის მკაცრად ეკვივალენტური შეცვლა, მაგრამ წარმოშობს მსგავს შედეგს მეხსიერების ნაკლები ოპერაციების გამოყენებით.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // მარცხენა ბლოკში მწყობრიდან გამოსული ყველა ელემენტი გადაადგილდა.გადადით შემდეგ ბლოკში.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // მარჯვენა ბლოკში მწყობრიდან გამოსული ყველა ელემენტი გადატანილია.წინა ბლოკში გადასვლა.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // ახლა რჩება მაქსიმუმ ერთი ბლოკი (მარცხნივ ან მარჯვნივ) მწყობრიდან გამოსული ელემენტებით, რომლებიც უნდა გადაიტანონ.
    // ასეთი დარჩენილი ელემენტები შეიძლება უბრალოდ გადაადგილდეს ბოლომდე მათი ბლოკის შიგნით.
    //

    if start_l < end_l {
        // მარცხენა ბლოკი რჩება.
        // გადაადგილეთ მისი მწყობრიდან გამოსული დარჩენილი ელემენტები უკიდურეს მარჯვნივ.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // რჩება მარჯვენა ბლოკი.
        // გადაადგილეთ მისი მწყობრიდან გამოსული დარჩენილი ელემენტები უკიდურეს მარცხნივ.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // სხვა არაფერი უნდა გავაკეთოთ, ჩვენ დავასრულეთ.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` დანაყოფები `v[pivot]`- ზე ნაკლები ელემენტებად, შემდეგ მოყვება `v[pivot]`- ზე მეტი ან ტოლი ელემენტები.
///
///
/// აბრუნებს ტოპს:
///
/// 1. ელემენტების რაოდენობა `v[pivot]`- ზე ნაკლები.
/// 2. მართალია, თუ `v` უკვე დანაყოფი იყო.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // მოათავსეთ pivot ნაჭრის დასაწყისში.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // ეფექტურობისთვის წაიკითხეთ pivot სტეკებად გამოყოფილ ცვლადში.
        // თუ შემდეგი შედარების ოპერაცია panics, pivot ავტომატურად ჩაიწერება ნაჭერში.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // მოიძიეთ მწყობრიდან გამოსული ელემენტების პირველი წყვილი.
        let mut l = 0;
        let mut r = v.len();

        // უსაფრთხოება: ქვემოთ მოყვანილი დაუცველობა მოიცავს მასივის ინდექსირებას.
        // პირველი: ჩვენ უკვე ვაკეთებთ საზღვრების შემოწმებას აქ `l < r`- ით.
        // მეორისთვის: ჩვენ თავდაპირველად გვაქვს `l == 0` და `r == v.len()` და `l < r` შევამოწმეთ ინდექსაციის ყველა ოპერაციაში.
        //                     აქედან ვიცით, რომ `r` უნდა იყოს მინიმუმ `r == l`, რაც აჩვენა, რომ იგი მართებულია პირველიდან.
        unsafe {
            // იპოვნეთ პირველი ელემენტი, რომელიც აღემატება ან ტოლია კრებსითი.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // იპოვნეთ ბოლო ელემენტი, ვიდრე მცირეა.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` გადის ფარგლებიდან და წერს pivot-ს (რომელიც დასტის გამოყოფილი ცვლადია) ისევ იმ ნაჭერში, სადაც ის თავდაპირველად იყო.
        // ეს ნაბიჯი კრიტიკულია უსაფრთხოების უზრუნველსაყოფად!
        //
    };

    // მოათავსეთ pivot ორ დანაყოფს შორის.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` დანაყოფები `v[pivot]` ტოლის ელემენტებად, რასაც მოყვება `v[pivot]`- ზე მეტი ელემენტები.
///
/// აბრუნებს ელემენტის რაოდენობას, რომელიც ტოლია pivot- ის.
/// ივარაუდება, რომ `v` არ შეიცავს pivot- ზე მცირე ელემენტებს.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // მოათავსეთ pivot ნაჭრის დასაწყისში.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // ეფექტურობისთვის წაიკითხეთ pivot სტეკებად გამოყოფილ ცვლადში.
    // თუ შემდეგი შედარების ოპერაცია panics, pivot ავტომატურად ჩაიწერება ნაჭერში.
    // უსაფრთხოება: აქ მაჩვენებელი მართებულია, რადგან ის მიიღება ნაჭრის მითითებით.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // ახლა დანაყოფი გაანაწილეთ.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // უსაფრთხოება: ქვემოთ მოყვანილი დაუცველობა მოიცავს მასივის ინდექსირებას.
        // პირველი: ჩვენ უკვე ვაკეთებთ საზღვრების შემოწმებას აქ `l < r`- ით.
        // მეორისთვის: ჩვენ თავდაპირველად გვაქვს `l == 0` და `r == v.len()` და `l < r` შევამოწმეთ ინდექსაციის ყველა ოპერაციაში.
        //                     აქედან ვიცით, რომ `r` უნდა იყოს მინიმუმ `r == l`, რაც აჩვენა, რომ იგი მართებულია პირველიდან.
        unsafe {
            // იპოვნეთ პირველი ელემენტი, რომელიც აღემატება კრუნჩხვას.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // იპოვნეთ ბოლო ელემენტი, რომელიც ტოლია pivot- ის.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // დავასრულეთ?
            if l >= r {
                break;
            }

            // შეცვალეთ მწყობრიდან გამოსული ელემენტების წყვილი.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // აღმოვაჩინეთ `l` ელემენტები, რომლებიც ტოლია pivot.დაამატეთ 1, რომ გაითვალისწინოთ თავად პივოტი.
    l + 1

    // `_pivot_guard` გადის ფარგლებიდან და წერს pivot-ს (რომელიც დასტის გამოყოფილი ცვლადია) ისევ იმ ნაჭერში, სადაც ის თავდაპირველად იყო.
    // ეს ნაბიჯი კრიტიკულია უსაფრთხოების უზრუნველსაყოფად!
}

/// ანაწილებს ზოგიერთ ელემენტს, რათა დაანგრიოს ნიმუშები, რამაც შეიძლება გამოიწვიოს დისბალანსირებული ტიხრები quicksort- ში.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // ჯორჯ მარსალიას მიერ Pseudorandom რიცხვის გენერატორი "Xorshift RNGs" ქაღალდიდან.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // მიიღეთ ეს რიცხვი მოდულად.
        // ნომერი ჯდება `usize`-ში, რადგან `len` არ აღემატება `isize::MAX`-ს.
        let modulus = len.next_power_of_two();

        // ზოგიერთი ძირითადი კანდიდატი იქნება ამ ინდექსის მიმდებარე ტერიტორიაზე.მოდით, შემთხვევითი გზით მოვიყვანოთ ისინი.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // შექმენით შემთხვევითი რიცხვის მოდული `len`.
            // ამასთან, ძვირადღირებული ოპერაციების თავიდან აცილების მიზნით, მას პირველად ვიღებთ ორი მოდულის სიმძლავრით, შემდეგ კი ვამცირებთ `len`- ით, სანამ არ ჯდება `[0, len - 1]` დიაპაზონში.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` გარანტირებული იქნება `2 * len`- ზე ნაკლები.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// ირჩევს pivot-ს `v`-ში და აბრუნებს ინდექსს და `true`-ს, თუ ნაკვეთი უკვე დალაგებულია.
///
/// `v` ელემენტების პროცესში შესაძლებელია შეცვლილიყო პროცესში.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // მინიმალური სიგრძე მედიანური მედიანური მეთოდის ასარჩევად.
    // უფრო მოკლე ნაჭრებად გამოიყენება მარტივი სამეული მეთოდი.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // სვოპების მაქსიმალური რაოდენობა, რაც შეიძლება შესრულდეს ამ ფუნქციაში.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // სამი ინდექსი, რომელთა მახლობლად ვაპირებთ აირჩიოთ pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // ითვლის სვოპების საერთო რაოდენობას, რომელთა შესრულებასაც ვაპირებთ ინდექსების დალაგების დროს.
    let mut swaps = 0;

    if len >= 8 {
        // Swaps ინდექსები ისე, რომ `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Swaps ინდექსები ისე, რომ `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // პოულობს `v[a - 1], v[a], v[a + 1]`- ის მედიანას და ინახავს ინდექსს `a`- ში.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // იპოვნეთ მედიანები `a`, `b` და `c` უბნებში.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // იპოვნეთ მედიანა `a`, `b` და `c` შორის.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // განხორციელდა სვოპების მაქსიმალური რაოდენობა.
        // მოსალოდნელია, რომ ნაკვეთი იკლებს ან ძირითადად იწევს, ამიტომ უკუგანვითარება ხელს შეუწყობს მის უფრო სწრაფად დალაგებას.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// ალაგებს `v` რეკურსიულად.
///
/// თუ ნაჭერს ორიგინალ მასივში ჰქონდა წინამორბედი, იგი მითითებულია როგორც `pred`.
///
/// `limit` არის დაშვებული დისბალანსირებული დანაყოფების რაოდენობა `heapsort`-ზე გადასვლამდე.
/// თუ ნულოვანია, ეს ფუნქცია დაუყოვნებლივ გადავა heapsort- ზე.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // ამ სიგრძის ნაჭრები დალაგებულია ჩასმის დალაგების გამოყენებით.
    const MAX_INSERTION: usize = 20;

    // მართალია, თუ ბოლო დანაყოფი გონივრულად დაბალანსებული იყო.
    let mut was_balanced = true;
    // მართალია, თუ ბოლო დანაყოფმა არ შეცვალა ელემენტები (ნაკვეთი უკვე გაყოფილია).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // ძალიან მოკლე ნაჭრები დალაგებულია ჩანართის დალაგების გამოყენებით.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // თუ ძალიან ბევრი ცუდი საყრდენი არჩევანი გაკეთდა, უბრალოდ დაუბრუნდით მწკრივებს, რათა უზრუნველყოთ `O(n * log(n))` ყველაზე ცუდი შემთხვევა.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // თუ ბოლო დანაყოფი გაუწონასწორებელი იყო, შეეცადეთ დაანგრიოთ ნაჭრები შაბლონებში, გადახაზეთ ზოგიერთი ელემენტი.
        // იმედია ამჯერად უკეთეს კერას აირჩევთ.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // აირჩიეთ კერა და შეეცადეთ გამოიცნოთ ნაკვეთი უკვე დალაგებულია.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // თუ ბოლო დანაყოფი იყო წესიერად გაწონასწორებული და არ შეცვლიდა ელემენტებს, და თუ pivot შერჩევა პროგნოზირებს, ნაკვეთი უკვე დალაგებულია ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // სცადეთ მწყობრიდან გამოსული რამდენიმე ელემენტის იდენტიფიცირება და გადატანა სწორი პოზიციებისკენ.
            // თუ ნაჭერი დასრულდება მთლიანად დალაგებული, ჩვენ დავასრულეთ.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // თუ არჩეული pivot უდრის წინამორბედს, მაშინ ის ყველაზე პატარა ელემენტია ნაკვეთში.
        // დაყავით ნაჭერი ელემენტებად ტოლ ელემენტებად და უფრო მეტი ელემენტები, ვიდრე pivot.
        // ეს შემთხვევა ჩვეულებრივ ხვდება მაშინ, როდესაც ნაჭერი შეიცავს ბევრ დუბლირებულ ელემენტს.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // გააგრძელეთ ძირითადი ელემენტების დახარისხება.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // დანაყოფი ნაჭერი.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // ფრაგმენტი გაყავით `left`, `pivot` და `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // დაუბრუნდით უფრო მოკლე მხარეს მხოლოდ იმისათვის, რომ შეამციროთ რეკურსიული ზარების მთლიანი რაოდენობა და ნაკლებ დროში მოიხმაროთ დასტის სივრცეში.
        // შემდეგ უბრალოდ გააგრძელეთ გრძელი მხრით (ეს კუდის რეკურსიას ჰგავს).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// ალაგებს `v` ნიმუშის დამამცირებელი quicksort- ის გამოყენებით, რაც არის *O*(*n*\*log(* n*)) ყველაზე ცუდი შემთხვევა.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // დალაგებას არ აქვს მნიშვნელოვანი ქცევა ნულოვანი ზომის ტიპებზე.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // შეუზღუდავი დანაყოფების რაოდენობის შეზღუდვა `floor(log2(len)) + 1`- ით.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // ამ სიგრძის ნაჭრებისთვის ალბათ უფრო სწრაფია მათი დალაგება.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // აირჩიეთ კერა
        let (pivot, _) = choose_pivot(v, is_less);

        // თუ არჩეული pivot უდრის წინამორბედს, მაშინ ის ყველაზე პატარა ელემენტია ნაკვეთში.
        // დაყავით ნაჭერი ელემენტებად ტოლ ელემენტებად და უფრო მეტი ელემენტები, ვიდრე pivot.
        // ეს შემთხვევა ჩვეულებრივ ხვდება მაშინ, როდესაც ნაჭერი შეიცავს ბევრ დუბლირებულ ელემენტს.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // თუ ჩვენი ინდექსი გავიარეთ, მაშინ კარგები ვართ.
                if mid > index {
                    return;
                }

                // წინააღმდეგ შემთხვევაში, გააგრძელეთ ძირითადი ელემენტების დახარისხება.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // ფრაგმენტი გაყავით `left`, `pivot` და `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // თუ შუა რიცხვებში==ინდექსი, ჩვენ დავასრულეთ, რადგან partition() გარანტირებულია, რომ ყველა ელემენტი შუა რიცხვების შემდეგ უფრო მეტია ან ტოლი შუა რიცხვებში.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // დალაგებას არ აქვს მნიშვნელოვანი ქცევა ნულოვანი ზომის ტიპებზე.Არაფრის კეთება.
    } else if index == v.len() - 1 {
        // იპოვნეთ მაქსიმალური ელემენტი და განათავსეთ იგი მასივის ბოლო პოზიციაში.
        // ჩვენ თავისუფლად შეგვიძლია გამოვიყენოთ `unwrap()` აქ, რადგან ვიცით, რომ v არ უნდა იყოს ცარიელი.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // იპოვნეთ min ელემენტი და განათავსეთ მასივის პირველ პოზიციაზე.
        // ჩვენ თავისუფლად შეგვიძლია გამოვიყენოთ `unwrap()` აქ, რადგან ვიცით, რომ v არ უნდა იყოს ცარიელი.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}