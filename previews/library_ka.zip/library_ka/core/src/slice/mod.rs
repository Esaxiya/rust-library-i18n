// ignore-tidy-filelength

//! ნაჭრების მართვა და მანიპულირება.
//!
//! დამატებითი ინფორმაციისთვის იხილეთ [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// სუფთა rust memchr განხორციელება, აღებული rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// ეს ფუნქცია საჯაროა მხოლოდ იმიტომ, რომ სხვა გზა არ არის ერთეულის საცდელი ჰესპორტის ერთეულისთვის.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// აბრუნებს ელემენტთა რაოდენობას ნაჭერში.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // უსაფრთხოება: ხმოვანია, რადგან სიგრძის ველს ვცვლით, როგორც გამოყენება (რაც უნდა იყოს)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // უსაფრთხოება: ეს უსაფრთხოა, რადგან `&[T]` და `FatPtr<T>` ერთნაირი განლაგება აქვთ.
            // მხოლოდ `std` შეუძლია ამ გარანტიის გაკეთებას.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: შეცვალეთ `crate::ptr::metadata(self)`- ით, როდესაც ეს სტაბილურია.
            // ამ დაწერის შემდეგ ეს იწვევს "Const-stable functions can only call other const-stable functions" შეცდომას.
            //

            // უსაფრთხოება: `PtrRepr` კავშირის მნიშვნელობაზე წვდომა უსაფრთხოა, რადგან * const T
            // და PtrComponents<T>მეხსიერების იგივე განლაგებები აქვთ.
            // მხოლოდ std- ს შეუძლია ამ გარანტიის გაკეთება.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// აბრუნებს `true`-ს, თუ ნაჭრის სიგრძეა 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// აბრუნებს ნაჭრის პირველ ელემენტს, ან `None` თუ იგი ცარიელია.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// აბრუნებს მუტაბელურ მაჩვენებელს ნაჭრის პირველ ელემენტს, ან `None` თუ ცარიელია.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// აბრუნებს ნაჭრის პირველ და დანარჩენ ელემენტებს, ან `None` თუ ცარიელია.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// აბრუნებს ნაჭრის პირველ და დანარჩენ ელემენტებს, ან `None` თუ ცარიელია.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// აბრუნებს ნაჭრის ბოლო და დანარჩენ ელემენტებს, ან `None` თუ ცარიელია.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// აბრუნებს ნაჭრის ბოლო და დანარჩენ ელემენტებს, ან `None` თუ ცარიელია.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// აბრუნებს ნაჭრის ბოლო ელემენტს, ან `None` თუ ცარიელია.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// აბრუნებს მუტაბელურ მაჩვენებელს ნაკვეთის ბოლო ერთეულზე.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// აბრუნებს მითითებას ელემენტზე ან ქვესახეზე, რაც დამოკიდებულია ინდექსის ტიპზე.
    ///
    /// - თუ მოცემულია პოზიცია, უბრუნებს მითითებას ამ პოზიციის ელემენტზე ან `None`, თუ საზღვრებს გარეთ არის.
    ///
    /// - თუ მოცემულია დიაპაზონი, უბრუნებს ამ დიაპაზონის შესაბამის ქვედანაყოფს, ან `None` თუ არ არის საზღვრებში.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// აბრუნებს ცვალებადი მითითებას ელემენტზე ან ქვესახეზე, რაც დამოკიდებულია ინდექსის ტიპზე (იხ. [`get`]) ან `None`, თუ ინდექსი არ არის საზღვრებში.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// აბრუნებს მითითებას ელემენტზე ან ქვეტყეზე, საზღვრების შემოწმების გარეშე.
    ///
    /// უსაფრთხო ალტერნატივისთვის იხილეთ [`get`].
    ///
    /// # Safety
    ///
    /// ამ მეთოდის გამოძახება საზღვარგარეთ ინდექსით არის [[განუსაზღვრელი ქცევა] * მაშინაც კი, თუ მიღებული მითითება არ არის გამოყენებული.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // უსაფრთხოება: აბონენტმა უნდა დაიცვას უსაფრთხოების მოთხოვნები `get_unchecked`- ს მიმართ;
        // ნაკვეთი არის მოხსენიებადი, რადგან `self` უსაფრთხო მითითებაა.
        // დაბრუნებული მაჩვენებელი უსაფრთხოა, რადგან `SliceIndex`-ის პროდუქტებს უნდა ჰქონდეთ მისი გარანტია.
        unsafe { &*index.get_unchecked(self) }
    }

    /// აბრუნებს ცვალებადი მითითებას ელემენტზე ან ქვეტყეზე, საზღვრების შემოწმების გარეშე.
    ///
    /// უსაფრთხო ალტერნატივისთვის იხილეთ [`get_mut`].
    ///
    /// # Safety
    ///
    /// ამ მეთოდის გამოძახება საზღვარგარეთ ინდექსით არის [[განუსაზღვრელი ქცევა] * მაშინაც კი, თუ მიღებული მითითება არ არის გამოყენებული.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // უსაფრთხოება: აბონენტმა უნდა დაიცვას უსაფრთხოების მოთხოვნები `get_unchecked_mut`- ს მიმართ;
        // ნაკვეთი არის მოხსენიებადი, რადგან `self` უსაფრთხო მითითებაა.
        // დაბრუნებული მაჩვენებელი უსაფრთხოა, რადგან `SliceIndex`-ის პროდუქტებს უნდა ჰქონდეთ მისი გარანტია.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// უბრუნებს ნედლეულის მაჩვენებელს ნაჭრის ბუფერში.
    ///
    /// გამრეკელმა უნდა უზრუნველყოს, რომ ნაჭერი აცოცხლებს ამ ფუნქციის მაჩვენებელს, თორემ ბოლოს ნაგვისკენ მიუთითებს.
    ///
    /// აბონენტმა ასევე უნდა უზრუნველყოს, რომ მეხსიერება, რომელზეც (non-transitively) მაჩვენებელი მიუთითებს, არასოდეს დაიწერება (გარდა `UnsafeCell`- ის შიგნით) ამ მაჩვენებლის ან მისგან მომდინარე ნებისმიერი მაჩვენებლის გამოყენებით.
    /// თუ გჭირდებათ ნაჭრის შინაარსის მუტაცია, გამოიყენეთ [`as_mut_ptr`].
    ///
    /// ამ ნაჭრის მიერ მითითებული კონტეინერის შეცვლამ შეიძლება გამოიწვიოს მისი ბუფერის გადანაწილება, რაც ასევე არასწორი იქნება მისი მითითების მითითება.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// უბრუნებს არასაიმედო მუტაბელურ მაჩვენებელს ნაჭრის ბუფერში.
    ///
    /// გამრეკელმა უნდა უზრუნველყოს, რომ ნაჭერი აცოცხლებს ამ ფუნქციის მაჩვენებელს, თორემ ბოლოს ნაგვისკენ მიუთითებს.
    ///
    /// ამ ნაჭრის მიერ მითითებული კონტეინერის შეცვლამ შეიძლება გამოიწვიოს მისი ბუფერის გადანაწილება, რაც ასევე არასწორი იქნება მისი მითითების მითითება.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// აბრუნებს ნაკვეთს გადაფარებულ ორ დაუმუშავებელ მითითებას.
    ///
    /// დაბრუნებული დიაპაზონი ნახევრად ღიაა, რაც ნიშნავს, რომ საბოლოო მაჩვენებელი მიუთითებს ნაკვეთის ბოლო ერთ ელემენტს *ერთ წარსულზე*.
    /// ამ გზით, ცარიელი ნაჭერი წარმოდგენილია ორი ტოლი მაჩვენებლით, ხოლო სხვაობა ორ მითითებას შორის წარმოადგენს ნაჭრის ზომას.
    ///
    /// ამ მითითების გამოყენების შესახებ გაფრთხილებისთვის იხილეთ [`as_ptr`].დასასრული მაჩვენებელი დამატებით სიფრთხილეს მოითხოვს, რადგან ის არ მიუთითებს ნაჭრის მართებულ ელემენტზე.
    ///
    /// ეს ფუნქცია სასარგებლოა უცხოურ ინტერფეისებთან ურთიერთქმედებისათვის, რომლებიც იყენებენ ორ მითითებას მეხსიერების ელემენტების მთელ რიგზე გადასასვლელად, რაც C++ -შია გავრცელებული.
    ///
    ///
    /// ასევე შეიძლება სასარგებლო იყოს იმის შემოწმება, მიუთითებს თუ არა ელემენტის მაჩვენებელი ამ ნაჭრის ელემენტს:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // უსაფრთხოება: `add` აქ უსაფრთხოა, რადგან:
        //
        //   - ორივე მანიშნებელი ერთი და იგივე ობიექტის ნაწილია, რადგან ობიექტის პირდაპირ გასვლასაც ითვლის.
        //
        //   - ნაჭრის ზომა არასოდეს აღემატება isize::MAX ბაიტს, როგორც აქ აღნიშნულია:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - აქ არ არის რაიმე სახის შეფუთვა, რადგან ნაჭრები არ ეხვევა მისამართის სივრცის ბოლოს.
        //
        // იხილეთ pointer::add დოკუმენტაცია.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// აბრუნებს ნაჭერს გადაფარულ ორ არასაიმედო მუტაბელურ მითითებას.
    ///
    /// დაბრუნებული დიაპაზონი ნახევრად ღიაა, რაც ნიშნავს, რომ საბოლოო მაჩვენებელი მიუთითებს ნაკვეთის ბოლო ერთ ელემენტს *ერთ წარსულზე*.
    /// ამ გზით, ცარიელი ნაჭერი წარმოდგენილია ორი ტოლი მაჩვენებლით, ხოლო სხვაობა ორ მითითებას შორის წარმოადგენს ნაჭრის ზომას.
    ///
    /// ამ მითითების გამოყენების შესახებ გაფრთხილებისთვის იხილეთ [`as_mut_ptr`].
    /// დასასრული მაჩვენებელი დამატებით სიფრთხილეს მოითხოვს, რადგან ის არ მიუთითებს ნაჭრის მართებულ ელემენტზე.
    ///
    /// ეს ფუნქცია სასარგებლოა უცხოურ ინტერფეისებთან ურთიერთქმედებისათვის, რომლებიც იყენებენ ორ მითითებას მეხსიერების ელემენტების მთელ რიგზე გადასასვლელად, რაც C++ -შია გავრცელებული.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // უსაფრთხოება: იხილეთ as_ptr_range() ზემოთ, თუ რატომ არის `add` აქ უსაფრთხო.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// ცვლის ორ ელემენტს ნაჭერში.
    ///
    /// # Arguments
    ///
    /// * ა, პირველი ელემენტის ინდექსი
    /// * ბ, მეორე ელემენტის ინდექსი
    ///
    /// # Panics
    ///
    /// Panics თუ `a` ან `b` არ არის საზღვრებში.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // ორი vector- დან ორი ცვალებადი სესხის აღება შეუძლებელია, ამიტომ გამოიყენეთ ნედლეული მაჩვენებლები.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // უსაფრთხოება: `pa` და `pb` შეიქმნა უსაფრთხო ცვლადი ცნობებისგან და ეხება მათ
        // ნაჭრის ელემენტებზე და, შესაბამისად, მათი გარანტირებული იქნება სწორი და გასწორებული.
        // გაითვალისწინეთ, რომ `a` და `b` მიღმა მყოფ ელემენტებზე წვდომა მოწმდება და panic იქნება, როდესაც საზღვრები არ იქნება.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// შეცვლის ელემენტების მიმდევრობას ნაკვეთში, თავის ადგილზე.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // ძალიან მცირე ტიპებისთვის, ყველა ინდივიდუალური კითხვა ნორმალურ გზაზე ცუდად ასრულებს.
        // ჩვენ შეგვიძლია უკეთესად გავაკეთოთ, ეფექტური არაპირისპირებული load/store გათვალისწინებით, უფრო დიდი ბლოკის ჩატვირთვით და რეგისტრის შეცვლით.
        //

        // იდეალურია LLVM ამის გაკეთება ჩვენთვის, რადგან მან უკეთ იცის ჩვენზე, არის თუ არა უსწორმასწორო კითხვები ეფექტური (რამდენადაც ეს შეიცვლება სხვადასხვა ARM ვერსიებს შორის) და რომელი იქნება ბლოკის საუკეთესო ზომა.
        // სამწუხაროდ, LLVM 4.0 (2017-05)- ის მდგომარეობით, იგი მხოლოდ ხსნის მარყუჟს, ამიტომ ჩვენ თვითონ უნდა გავაკეთოთ ეს.
        // (ჰიპოთეზა: საპირისპირო პრობლემაა, რადგან გვერდები შეიძლება განსხვავებულად იყოს გასწორებული-იქნება, როდესაც სიგრძე უცნაური იქნება-ასე რომ, წინა და პოსტლანდების გამოსხივების საშუალება არ არსებობს, რომ გამოიყენოთ სრულად გასწორებული SIMD შუაში).
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // გამოიყენეთ llvm.bswap შინაგანი, რომ შეცვალოთ u8s გამოყენებაში
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // უსაფრთხოება: აქ რამდენიმე რამის შემოწმებაა:
                //
                // - გაითვალისწინეთ, რომ `chunk` არის 4 ან 8, ზემოთ cfg შემოწმების გამო.ასე რომ, `chunk - 1` დადებითია.
                // - ინდექსაცია ინდექსი `i` კარგად არის, რადგან მარყუჟის შემოწმება იძლევა გარანტიას
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - ინდექსაცია ინდექსი `ln - i - chunk = ln - (i + chunk)` კარგად არის:
                //   - `i + chunk > 0` ტრივიალურად არის მართალი.
                //   - მარყუჟის შემოწმება იძლევა გარანტიას:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, ამრიგად, გამოკლება არ იშლება.
                // - `read_unaligned` და `write_unaligned` ზარები კარგად არის:
                //   - `pa` მიუთითებს ინდექსზე `i`, სადაც `i < ln / 2 - (chunk - 1)` (იხ. ზემოთ) და `pb` მიუთითებს ინდექსზე `ln - i - chunk`, ამიტომ ორივე `self`- ის ბოლოდან მინიმუმ `chunk` მრავალი ბაიტითაა დაშორებული.
                //
                //   - ნებისმიერი ინიცირებული მეხსიერება მოქმედებს `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // გამოიყენეთ როტაცია 16-ით, რომ შეცვალოთ u16s u32-ში
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // უსაფრთხოება: შეუსაბამო u32 იკითხება `i`- დან, თუ `i + 1 < ln`
                // (და აშკარად `i < ln`), რადგან თითოეული ელემენტი 2 ბაიტია და ჩვენ 4-ს ვკითხულობთ.
                //
                // `i + chunk - 1 < ln / 2` # ხოლო მდგომარეობა
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // რადგან ეს სიგრძეზე ნაკლებია, რაც გაყოფილია 2-ზე, ეს უნდა იყოს საზღვრებში.
                //
                // ეს ასევე ნიშნავს, რომ მდგომარეობა `0 < i + chunk <= ln` ყოველთვის დაცულია, რაც უზრუნველყოფს `pb` მაჩვენებლის უსაფრთხოდ გამოყენებას.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // უსაფრთხოება: `i` ჩამოუვარდება ნაჭრის სიგრძის ნახევარს, ასე რომ
            // `i` და `ln - i - 1`- ზე წვდომა უსაფრთხოა (`i` იწყება 0 - დან და აღარ წავა `ln / 2 - 1`- ზე მეტი).
            // შესაბამისად, `pa` და `pb` მაჩვენებლები სწორია და გასწორებულია და მათი წაკითხვა და ტექსტში წაკითხვა შესაძლებელია.
            //
            //
            unsafe {
                // უსაფრთხო გაცვლა, რომ არ მოხდეს უსაფრთხო გაცვლის საზღვრების შემოწმება.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// აბრუნებს იტერატორს ნაჭერზე.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// აბრუნებს იტერატორს, რომელიც საშუალებას აძლევს შეცვალოს თითოეული მნიშვნელობა.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// აბრუნებს იტერატორს `size` სიგრძის ყველა მომიჯნავე windows- ზე.
    /// windows გადახურვა.
    /// თუ ნაკვეთი უფრო მოკლეა ვიდრე `size`, iterator არ აბრუნებს მნიშვნელობებს.
    ///
    /// # Panics
    ///
    /// Panics თუ `size` არის 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// თუ ნაკვეთი უფრო მოკლეა ვიდრე `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// აბრუნებს იტერატორს ნაჭრის `chunk_size` ელემენტზე ერთდროულად, ნაკვეთის დასაწყისში დაწყებული.
    ///
    /// ბლოკები ნაჭრებია და ერთმანეთს არ გადაფარავს.თუ `chunk_size` არ ყოფს ნაჭრის სიგრძეს, მაშინ ბოლო ბლოკს არ ექნება სიგრძე `chunk_size`.
    ///
    /// იხილეთ [`chunks_exact`] ამ იტერატორის ვარიანტისთვის, რომელიც აბრუნებს ყოველთვის ზუსტად `chunk_size` ელემენტების ბლოკებს, და [`rchunks`] იგივე იტერატორისთვის, მაგრამ ნაკვეთის ბოლოს დაწყებული.
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ `chunk_size` არის 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// აბრუნებს იტერატორს ნაჭრის `chunk_size` ელემენტზე ერთდროულად, ნაკვეთის დასაწყისში დაწყებული.
    ///
    /// ბლოკები მუტაბელური ნაჭრებია და არ გადაფარავს ერთმანეთს.თუ `chunk_size` არ ყოფს ნაჭრის სიგრძეს, მაშინ ბოლო ბლოკს არ ექნება სიგრძე `chunk_size`.
    ///
    /// იხილეთ [`chunks_exact_mut`] ამ იტერატორის ვარიანტისთვის, რომელიც აბრუნებს ყოველთვის ზუსტად `chunk_size` ელემენტების ბლოკებს, და [`rchunks_mut`] იგივე იტერატორისთვის, მაგრამ ნაკვეთის ბოლოს დაწყებული.
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ `chunk_size` არის 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// აბრუნებს იტერატორს ნაჭრის `chunk_size` ელემენტზე ერთდროულად, ნაკვეთის დასაწყისში დაწყებული.
    ///
    /// ბლოკები ნაჭრებია და ერთმანეთს არ გადაფარავს.
    /// თუ `chunk_size` არ იყოფა ნაჭრის სიგრძეს, მაშინ ბოლო `chunk_size-1` ელემენტები გამოტოვებულია და მისი მიღება შეიძლება განმეორების `remainder` ფუნქციიდან.
    ///
    ///
    /// თითოეული ბლოკის ზუსტად `chunk_size` ელემენტის გამო, შემდგენელს ხშირად შეუძლია კოდის ოპტიმიზაცია უკეთესად, ვიდრე [`chunks`]- ის შემთხვევაში.
    ///
    /// იხილეთ [`chunks`] ამ იტერატორის ვარიანტისთვის, რომელიც ასევე აბრუნებს ნაშთს უფრო მცირე ზომის სახით, და [`rchunks_exact`] იგივე იტერატორისთვის, მაგრამ ნაკვეთის ბოლოს დაწყებული.
    ///
    /// # Panics
    ///
    /// Panics თუ `chunk_size` არის 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// აბრუნებს იტერატორს ნაჭრის `chunk_size` ელემენტზე ერთდროულად, ნაკვეთის დასაწყისში დაწყებული.
    ///
    /// ბლოკები მუტაბელური ნაჭრებია და არ გადაფარავს ერთმანეთს.
    /// თუ `chunk_size` არ იყოფა ნაჭრის სიგრძეს, მაშინ ბოლო `chunk_size-1` ელემენტები გამოტოვებულია და მისი მიღება შეიძლება განმეორების `into_remainder` ფუნქციიდან.
    ///
    ///
    /// თითოეული ბლოკის ზუსტად `chunk_size` ელემენტის გამო, შემდგენელს ხშირად შეუძლია კოდის ოპტიმიზაცია უკეთესად, ვიდრე [`chunks_mut`]- ის შემთხვევაში.
    ///
    /// იხილეთ [`chunks_mut`] ამ იტერატორის ვარიანტისთვის, რომელიც ასევე აბრუნებს ნაშთს უფრო მცირე ზომის სახით, და [`rchunks_exact_mut`] იგივე იტერატორისთვის, მაგრამ ნაკვეთის ბოლოს დაწყებული.
    ///
    /// # Panics
    ///
    /// Panics თუ `chunk_size` არის 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// ანაწილებს ნაჭერს `N` ელემენტის მასივების ნაჭრად, თუ ჩავთვლით, რომ არ არის დარჩენილი.
    ///
    ///
    /// # Safety
    ///
    /// ამას მხოლოდ როდის შეიძლება ეწოდოს
    /// - ნაჭერი გაყოფილია `N` ელემენტის ბლოკებად (aka `self.len() % N == 0`)).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // უსაფრთხოება: 1 ელემენტიან მოცულობებს არასდროს აქვთ დარჩენილი
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // უსაფრთხოება: ნაჭრის სიგრძე (6) არის 3-ის ჯერადი
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // ეს გაუგებარი იქნებოდა:
    /// // მოდით მოცულობით: &[[_;5]]= slice.as_chunks_unchecked()//ნაჭრის სიგრძე არ არის 5 - ის ნამრავლის ჯამი:&[[_ _;0]]= slice.as_chunks_unchecked()//ნულოვანი სიგრძის ბლოკები არასოდეს დაიშვება
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // უსაფრთხოება: ჩვენი წინაპირობაა ზუსტად ის, რისთვისაც საჭიროა ამის დარეკვა
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // უსაფრთხოება: ჩვენ ჩავყარეთ `new_len * N` ელემენტის ნაჭერი
        // `new_len` ნაჭრის მრავალი `N` ელემენტის ბლოკი.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// ანაწილებს ნაჭერს `N` ელემენტის მასივების ნაჭრად, დაწყებული ნაჭრის დასაწყისში და დარჩენილი ნაჭერი სიგრძით, რომელიც მკაცრად ნაკლებია `N`-ზე.
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ `N` არის 0. ეს შემოწმება, სავარაუდოდ, შეიცვლება კომპილირების დროის შეცდომით, სანამ ეს მეთოდი სტაბილიზირდება.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // უსაფრთხოება: ჩვენ უკვე პანიკაში ვიყავით ნულისთვის და ამას ვიღებდით მშენებლობით
        // რომ ქვეტყის სიგრძე არის N- ის ჯერადი.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// ანაწილებს ნაჭერს `N` ელემენტის მასივების ნაჭრად, დაწყებული ნაჭრის ბოლოს და დარჩენილი ნაჭრის სიგრძით, რომელიც მკაცრად ნაკლებია `N`-ზე.
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ `N` არის 0. ეს შემოწმება, სავარაუდოდ, შეიცვლება კომპილირების დროის შეცდომით, სანამ ეს მეთოდი სტაბილიზირდება.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // უსაფრთხოება: ჩვენ უკვე პანიკაში ვიყავით ნულისთვის და ამას ვიღებდით მშენებლობით
        // რომ ქვეტყის სიგრძე არის N- ის ჯერადი.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// აბრუნებს იტერატორს ნაჭრის `N` ელემენტზე ერთდროულად, ნაკვეთის დასაწყისში დაწყებული.
    ///
    /// ბლოკები მასივის ცნობას წარმოადგენს და ერთმანეთს არ გადაფარავს.
    /// თუ `N` არ იყოფა ნაჭრის სიგრძეს, მაშინ ბოლო `N-1` ელემენტები გამოტოვებულია და მისი მიღება შეიძლება განმეორების `remainder` ფუნქციიდან.
    ///
    ///
    /// ეს მეთოდი წარმოადგენს [`chunks_exact`] ზოგად ექვივალენტს.
    ///
    /// # Panics
    ///
    /// Panics თუ `N` არის 0. ეს შემოწმება, სავარაუდოდ, შეიცვლება კომპილირების დროის შეცდომით, სანამ ეს მეთოდი სტაბილიზირდება.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// ანაწილებს ნაჭერს `N` ელემენტის მასივების ნაჭრად, თუ ჩავთვლით, რომ არ არის დარჩენილი.
    ///
    ///
    /// # Safety
    ///
    /// ამას მხოლოდ როდის შეიძლება ეწოდოს
    /// - ნაჭერი გაყოფილია `N` ელემენტის ბლოკებად (aka `self.len() % N == 0`)).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // უსაფრთხოება: 1 ელემენტიან მოცულობებს არასდროს აქვთ დარჩენილი
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // უსაფრთხოება: ნაჭრის სიგრძე (6) არის 3-ის ჯერადი
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // ეს გაუგებარი იქნებოდა:
    /// // მოდით მოცულობით: &[[_;5]]= slice.as_chunks_unchecked_mut()//ნაჭრის სიგრძე არ არის 5 - ის ნამრავლის ჯამი:&[[_ _;0]]= slice.as_chunks_unchecked_mut()//ნულოვანი სიგრძის ბლოკები არასოდეს დაიშვება
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // უსაფრთხოება: ჩვენი წინაპირობაა ზუსტად ის, რისთვისაც საჭიროა ამის დარეკვა
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // უსაფრთხოება: ჩვენ ჩავყარეთ `new_len * N` ელემენტის ნაჭერი
        // `new_len` ნაჭრის მრავალი `N` ელემენტის ბლოკი.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// ანაწილებს ნაჭერს `N` ელემენტის მასივების ნაჭრად, დაწყებული ნაჭრის დასაწყისში და დარჩენილი ნაჭერი სიგრძით, რომელიც მკაცრად ნაკლებია `N`-ზე.
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ `N` არის 0. ეს შემოწმება, სავარაუდოდ, შეიცვლება კომპილირების დროის შეცდომით, სანამ ეს მეთოდი სტაბილიზირდება.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // უსაფრთხოება: ჩვენ უკვე პანიკაში ვიყავით ნულისთვის და ამას ვიღებდით მშენებლობით
        // რომ ქვეტყის სიგრძე არის N- ის ჯერადი.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// ანაწილებს ნაჭერს `N` ელემენტის მასივების ნაჭრად, დაწყებული ნაჭრის ბოლოს და დარჩენილი ნაჭრის სიგრძით, რომელიც მკაცრად ნაკლებია `N`-ზე.
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ `N` არის 0. ეს შემოწმება, სავარაუდოდ, შეიცვლება კომპილირების დროის შეცდომით, სანამ ეს მეთოდი სტაბილიზირდება.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // უსაფრთხოება: ჩვენ უკვე პანიკაში ვიყავით ნულისთვის და ამას ვიღებდით მშენებლობით
        // რომ ქვეტყის სიგრძე არის N- ის ჯერადი.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// აბრუნებს იტერატორს ნაჭრის `N` ელემენტზე ერთდროულად, ნაკვეთის დასაწყისში დაწყებული.
    ///
    /// ბლოკები მასივის ცვალებადი მითითებაა და არ ემთხვევა ერთმანეთს.
    /// თუ `N` არ იყოფა ნაჭრის სიგრძეს, მაშინ ბოლო `N-1` ელემენტები გამოტოვებულია და მისი მიღება შეიძლება განმეორების `into_remainder` ფუნქციიდან.
    ///
    ///
    /// ეს მეთოდი წარმოადგენს [`chunks_exact_mut`] ზოგად ექვივალენტს.
    ///
    /// # Panics
    ///
    /// Panics თუ `N` არის 0. ეს შემოწმება, სავარაუდოდ, შეიცვლება კომპილირების დროის შეცდომით, სანამ ეს მეთოდი სტაბილიზირდება.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// აბრუნებს იტერატორს ნაჭრის windows `N` ელემენტების გადაფარვას, ნაკვეთის დასაწყისში დაწყებული.
    ///
    ///
    /// ეს არის [`windows`]-ის ძირითადი ზოგადი ექვივალენტი.
    ///
    /// თუ `N` აღემატება ნაჭრის ზომას, ის აღარ დაბრუნდება windows.
    ///
    /// # Panics
    ///
    /// Panics თუ `N` არის 0.
    /// ეს შემოწმება, სავარაუდოდ, შეიცვლება კომპილირების დროის შეცდომით, სანამ ეს მეთოდი სტაბილიზირდება.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// აბრუნებს იტერატორს ნაჭრის `chunk_size` ელემენტზე ერთ ჯერზე, ნაკვეთის ბოლოს დაწყებული.
    ///
    /// ბლოკები ნაჭრებია და ერთმანეთს არ გადაფარავს.თუ `chunk_size` არ ყოფს ნაჭრის სიგრძეს, მაშინ ბოლო ბლოკს არ ექნება სიგრძე `chunk_size`.
    ///
    /// იხილეთ [`rchunks_exact`] ამ იტერატორის ვარიანტისთვის, რომელიც აბრუნებს ყოველთვის ზუსტად `chunk_size` ელემენტების ბლოკებს, და [`chunks`] იგივე იტერატორისთვის, მაგრამ ნაკვეთის დასაწყისში.
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ `chunk_size` არის 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// აბრუნებს იტერატორს ნაჭრის `chunk_size` ელემენტზე ერთ ჯერზე, ნაკვეთის ბოლოს დაწყებული.
    ///
    /// ბლოკები მუტაბელური ნაჭრებია და არ გადაფარავს ერთმანეთს.თუ `chunk_size` არ ყოფს ნაჭრის სიგრძეს, მაშინ ბოლო ბლოკს არ ექნება სიგრძე `chunk_size`.
    ///
    /// იხილეთ [`rchunks_exact_mut`] ამ იტერატორის ვარიანტისთვის, რომელიც აბრუნებს ყოველთვის ზუსტად `chunk_size` ელემენტების ბლოკებს, და [`chunks_mut`] იგივე იტერატორისთვის, მაგრამ ნაკვეთის დასაწყისში.
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ `chunk_size` არის 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// აბრუნებს იტერატორს ნაჭრის `chunk_size` ელემენტზე ერთ ჯერზე, ნაკვეთის ბოლოს დაწყებული.
    ///
    /// ბლოკები ნაჭრებია და ერთმანეთს არ გადაფარავს.
    /// თუ `chunk_size` არ იყოფა ნაჭრის სიგრძეს, მაშინ ბოლო `chunk_size-1` ელემენტები გამოტოვებულია და მისი მიღება შეიძლება განმეორების `remainder` ფუნქციიდან.
    ///
    /// თითოეული ბლოკის ზუსტად `chunk_size` ელემენტის გამო, შემდგენელს ხშირად შეუძლია კოდის ოპტიმიზაცია უკეთესად, ვიდრე [`chunks`]- ის შემთხვევაში.
    ///
    /// იხილეთ [`rchunks`] ამ იტერატორის ვარიანტისთვის, რომელიც ასევე აბრუნებს ნაშთს, როგორც პატარა ბლოკს, და [`chunks_exact`] იგივე იტერატორისთვის, მაგრამ ნაკვეთის დასაწყისში.
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ `chunk_size` არის 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// აბრუნებს იტერატორს ნაჭრის `chunk_size` ელემენტზე ერთ ჯერზე, ნაკვეთის ბოლოს დაწყებული.
    ///
    /// ბლოკები მუტაბელური ნაჭრებია და არ გადაფარავს ერთმანეთს.
    /// თუ `chunk_size` არ იყოფა ნაჭრის სიგრძეს, მაშინ ბოლო `chunk_size-1` ელემენტები გამოტოვებულია და მისი მიღება შეიძლება განმეორების `into_remainder` ფუნქციიდან.
    ///
    /// თითოეული ბლოკის ზუსტად `chunk_size` ელემენტის გამო, შემდგენელს ხშირად შეუძლია კოდის ოპტიმიზაცია უკეთესად, ვიდრე [`chunks_mut`]- ის შემთხვევაში.
    ///
    /// იხილეთ [`rchunks_mut`] ამ იტერატორის ვარიანტისთვის, რომელიც ასევე აბრუნებს ნაშთს, როგორც პატარა ბლოკს, და [`chunks_exact_mut`] იგივე იტერატორისთვის, მაგრამ ნაკვეთის დასაწყისში.
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ `chunk_size` არის 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// აბრუნებს იტერატორს ნაჭერზე და ქმნის ელემენტების არაგადაფარვას.
    ///
    /// პრედიკატს ეწოდება ორი ელემენტი, რომელიც თავის თავს მიჰყვება, ეს ნიშნავს რომ პრედიკატს ეწოდება `slice[0]` და `slice[1]` შემდეგ `slice[1]` და `slice[2]` და ა.შ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ეს მეთოდი შეიძლება გამოყენებულ იქნას დახარისხებული ქვეგანყოფილებების ამოსაღებად:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// აბრუნებს იტერატორს ნაჭერზე და ქმნის ელემენტების არაგადაფარვას, მუტაბელურ გაშვებებს, რომლითაც ხდება პრედიკატის გამოყოფა.
    ///
    /// პრედიკატს ეწოდება ორი ელემენტი, რომელიც თავის თავს მიჰყვება, ეს ნიშნავს რომ პრედიკატს ეწოდება `slice[0]` და `slice[1]` შემდეგ `slice[1]` და `slice[2]` და ა.შ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ეს მეთოდი შეიძლება გამოყენებულ იქნას დახარისხებული ქვეგანყოფილებების ამოსაღებად:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// ინდექსში ყოფს ერთ ნაჭერს ორად.
    ///
    /// პირველი შეიცავს ყველა ინდექსს `[0, mid)`- დან (ინდექსის `mid` გამოკლებით) და მეორე შეიცავს ყველა ინდექსს `[mid, len)`- დან (თვითონ ინდექს `len`- ს გამოკლებით).
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // უსაფრთხოება: `[ptr; mid]` და `[mid; len]` არის `self` შიგნით, რაც
        // ასრულებს `from_raw_parts_mut` მოთხოვნებს.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// ინდექსში ყოფს ერთ მუტაბელურ ნაჭერს ორად.
    ///
    /// პირველი შეიცავს ყველა ინდექსს `[0, mid)`- დან (ინდექსის `mid` გამოკლებით) და მეორე შეიცავს ყველა ინდექსს `[mid, len)`- დან (თვითონ ინდექს `len`- ს გამოკლებით).
    ///
    ///
    /// # Panics
    ///
    /// Panics თუ `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // უსაფრთხოება: `[ptr; mid]` და `[mid; len]` არის `self` შიგნით, რაც
        // ასრულებს `from_raw_parts_mut` მოთხოვნებს.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// ანაწილებს ერთ ნაჭერს ორად ინდექსში, საზღვრების შემოწმების გარეშე.
    ///
    /// პირველი შეიცავს ყველა ინდექსს `[0, mid)`- დან (ინდექსის `mid` გამოკლებით) და მეორე შეიცავს ყველა ინდექსს `[mid, len)`- დან (თვითონ ინდექს `len`- ს გამოკლებით).
    ///
    ///
    /// უსაფრთხო ალტერნატივისთვის იხილეთ [`split_at`].
    ///
    /// # Safety
    ///
    /// ამ მეთოდის გამოძახება საზღვარგარეთ ინდექსით არის [[განუსაზღვრელი ქცევა] * მაშინაც კი, თუ მიღებული მითითება არ არის გამოყენებული.აბონენტმა უნდა უზრუნველყოს `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // უსაფრთხოება: აბონენტმა უნდა შეამოწმოს `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// ინდექსში ყოფს ერთ მუტაბელურ ნაჭერს ორად, საზღვრების შემოწმების გარეშე.
    ///
    /// პირველი შეიცავს ყველა ინდექსს `[0, mid)`- დან (ინდექსის `mid` გამოკლებით) და მეორე შეიცავს ყველა ინდექსს `[mid, len)`- დან (თვითონ ინდექს `len`- ს გამოკლებით).
    ///
    ///
    /// უსაფრთხო ალტერნატივისთვის იხილეთ [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// ამ მეთოდის გამოძახება საზღვარგარეთ ინდექსით არის [[განუსაზღვრელი ქცევა] * მაშინაც კი, თუ მიღებული მითითება არ არის გამოყენებული.აბონენტმა უნდა უზრუნველყოს `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // უსაფრთხოება: აბონენტმა უნდა შეამოწმოს `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` და `[mid; len]` არ ემთხვევა ერთმანეთს, ამიტომ მუტაბელური მითითების დაბრუნება კარგია.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// აბრუნებს იტერატორს ქვედანაყოფებზე, რომლებიც გამოყოფილია ელემენტებით, რომლებიც ემთხვევა `pred`.
    /// შესატყვისი ელემენტი არ შეიცავს ქვეთავში.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// თუ პირველი ელემენტი ემთხვევა, ცარიელი ნაჭერი იქნება პირველი ელემენტი, რომელიც იტერატორმა დააბრუნა.
    /// ანალოგიურად, თუ ნაჭრის ბოლო ელემენტი ემთხვევა, ცარიელი ნაჭერი იქნება უკანასკნელი ნივთი, რომელიც ინტერატორმა დააბრუნა:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// თუ ორი შესატყვისი ელემენტი პირდაპირ მომიჯნავეა, მათ შორის ცარიელი ნაჭერი იქნება:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// აბრუნებს იტერატორს მუტაბელურ ქვესადგურებზე გამოყოფილი ელემენტებით, რომლებიც ემთხვევა `pred`.
    /// შესატყვისი ელემენტი არ შეიცავს ქვეთავში.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// აბრუნებს იტერატორს ქვედანაყოფებზე, რომლებიც გამოყოფილია ელემენტებით, რომლებიც ემთხვევა `pred`.
    /// შესატყვისი ელემენტი შეიცავს წინა ქვედანაყოფის ბოლოს, როგორც ტერმინატორი.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// თუ ნაჭრის ბოლო ელემენტი ემთხვევა, ეს ელემენტი ჩაითვლება წინა ნაჭრის დამშლელად.
    ///
    /// ეს ნაჭერი იქნება უკანასკნელი ელემენტი, რომელიც ინტერატორმა დააბრუნა.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// აბრუნებს იტერატორს მუტაბელურ ქვესადგურებზე გამოყოფილი ელემენტებით, რომლებიც ემთხვევა `pred`.
    /// შესატყვისი ელემენტი შეიცავს წინა ქვექვემდებარებას, როგორც ტერმინატორი.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// აბრუნებს იტერატორს ქვედანაყოფებზე, რომლებიც გამოყოფილია ელემენტებით, რომლებიც ემთხვევა `pred`, ნაკვეთის ბოლოს დაწყებული და უკან მუშაობით.
    /// შესატყვისი ელემენტი არ შეიცავს ქვეთავში.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ისევე, როგორც `split()`- ის შემთხვევაში, თუ პირველი ან ბოლო ელემენტი ემთხვევა, ცარიელი ნაჭერი იქნება პირველი (ან უკანასკნელი) ელემენტი, რომელიც უკან დაბრუნდება ინტერატორი.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// აბრუნებს იტერატორს მუტაბელურ ქვეპუნქტებზე, რომლებიც გამოყოფილია ელემენტებით, რომლებიც ემთხვევა `pred`, ნაკვეთის ბოლოს დაწყებული და უკან მუშაობით.
    /// შესატყვისი ელემენტი არ შეიცავს ქვეთავში.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// აბრუნებს იტერატორს ქვესადგურებზე გამოყოფილი ელემენტებით, რომლებიც ემთხვევა `pred`, შემოიფარგლება მაქსიმუმ `n` ერთეულის დაბრუნებით
    /// შესატყვისი ელემენტი არ შეიცავს ქვეთავში.
    ///
    /// უკან დაბრუნებული ბოლო ელემენტი, ასეთის არსებობის შემთხვევაში, შეიცავს ნაჭრის დანარჩენ ნაწილს.
    ///
    /// # Examples
    ///
    /// დაბეჭდეთ ნაჭერი გაყოფილი ერთხელ რიცხვებზე, რომლებიც იყოფა 3-ზე (მაგ., `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// აბრუნებს იტერატორს ქვესადგურებზე გამოყოფილი ელემენტებით, რომლებიც ემთხვევა `pred`, შემოიფარგლება მაქსიმუმ `n` ერთეულის დაბრუნებით
    /// შესატყვისი ელემენტი არ შეიცავს ქვეთავში.
    ///
    /// უკან დაბრუნებული ბოლო ელემენტი, ასეთის არსებობის შემთხვევაში, შეიცავს ნაჭრის დანარჩენ ნაწილს.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// აბრუნებს იტერატორს ქვედანაყოფებზე, რომლებიც გამოყოფილია ელემენტებით, რომლებიც ემთხვევა `pred` შეზღუდულია მაქსიმუმ `n` ერთეულის დაბრუნებით.
    /// ეს იწყება ნაჭრის ბოლოს და მუშაობს უკან.
    /// შესატყვისი ელემენტი არ შეიცავს ქვეთავში.
    ///
    /// უკან დაბრუნებული ბოლო ელემენტი, ასეთის არსებობის შემთხვევაში, შეიცავს ნაჭრის დანარჩენ ნაწილს.
    ///
    /// # Examples
    ///
    /// დაბეჭდეთ ნაჭერი გაყოფილი ერთხელ, ბოლოდან დაწყებული, 3 - ზე გამყოფი რიცხვებით (მაგ., `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// აბრუნებს იტერატორს ქვედანაყოფებზე, რომლებიც გამოყოფილია ელემენტებით, რომლებიც ემთხვევა `pred` შეზღუდულია მაქსიმუმ `n` ერთეულის დაბრუნებით.
    /// ეს იწყება ნაჭრის ბოლოს და მუშაობს უკან.
    /// შესატყვისი ელემენტი არ შეიცავს ქვეთავში.
    ///
    /// უკან დაბრუნებული ბოლო ელემენტი, ასეთის არსებობის შემთხვევაში, შეიცავს ნაჭრის დანარჩენ ნაწილს.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// აბრუნებს `true` თუ ნაჭერი შეიცავს მოცემული მნიშვნელობის ელემენტს.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// თუ თქვენ არ გაქვთ `&T`, მაგრამ მხოლოდ `&U` ისეთი, რომ `T: Borrow<U>` (მაგ
    /// `სიმები: სესხება<str>`), შეგიძლიათ გამოიყენოთ `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // ნაჭერი `String`
    /// assert!(v.iter().any(|e| e == "hello")); // მოძებნეთ `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// აბრუნებს `true`-ს, თუ `needle` არის ნაჭრის პრეფიქსი.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// ყოველთვის აბრუნებს `true`-ს, თუ `needle` ცარიელი ნაჭერია:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// აბრუნებს `true`-ს, თუ `needle` ნაჭრის სუფიქსია.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// ყოველთვის აბრუნებს `true`-ს, თუ `needle` ცარიელი ნაჭერია:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// აბრუნებს ქვესართავს ამოღებული პრეფიქსით.
    ///
    /// თუ ნაჭერი იწყება `prefix`-ით, უბრუნებს ქვესუბანს პრეფიქსით, `Some`-ით გახვეული.
    /// თუ `prefix` ცარიელია, უბრალოდ დააბრუნეთ ორიგინალი ნაჭერი.
    ///
    /// თუ ნაკვეთი არ იწყება `prefix`-ით, უბრუნებს `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // ამ ფუნქციის გადაწერა საჭირო იქნება, თუ და როდესაც SlicePattern უფრო დახვეწილი გახდება.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// აბრუნებს ქვესკნელს ამოღებული სუფიქსით.
    ///
    /// თუ ნაჭერი მთავრდება `suffix`-ით, აბრუნებს ქვესახე სუფიქსის წინ, გახვეული `Some`-ით.
    /// თუ `suffix` ცარიელია, უბრალოდ დააბრუნეთ ორიგინალი ნაჭერი.
    ///
    /// თუ ნაკვეთი არ მთავრდება `suffix`, უბრუნებს `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // ამ ფუნქციის გადაწერა საჭირო იქნება, თუ და როდესაც SlicePattern უფრო დახვეწილი გახდება.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// ორობითი ეძებს მოცემულ ელემენტს ამ დალაგებულ ნაჭერზე.
    ///
    /// თუ მნიშვნელობა ნაპოვნია, [`Result::Ok`] უბრუნდება, რომელიც შეიცავს შესატყვისი ელემენტის ინდექსს.
    /// თუ არსებობს მრავალი მატჩი, მაშინ რომელიმე მატჩის დაბრუნება შეიძლება.
    /// თუ მნიშვნელობა ვერ მოიძებნა, [`Result::Err`] უბრუნდება, რომელიც შეიცავს ინდექსს, სადაც შესატყვისი ელემენტის ჩასმა შესაძლებელია დახარისხებული წესრიგის შენარჩუნებისას.
    ///
    ///
    /// აგრეთვე [`binary_search_by`], [`binary_search_by_key`] და [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ეძებს ოთხი ელემენტის სერიას.
    /// პირველი გვხვდება, ცალსახად განსაზღვრული პოზიციით;მეორე და მესამე არ არის ნაპოვნი;მეოთხე შეიძლება ემთხვეოდეს ნებისმიერ პოზიციას `[1, 4]`-ში.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// თუ გსურთ ჩასვათ ნივთი დახარისხებულ vector-ში, დალაგების წესრიგის დაცვით:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// ორობითი ეძებს ამ დალაგებულ ნაჭერს შედარების ფუნქციით.
    ///
    /// შედარების ფუნქციამ უნდა შეასრულოს ბრძანება, რომელიც შეესაბამება ძირითადი ნაჭრის დალაგების რიგს, დააბრუნებს შეკვეთის კოდს, რომელიც მიუთითებს არის თუ არა მისი არგუმენტი `Less`, `Equal` ან `Greater` სასურველი სამიზნე.
    ///
    ///
    /// თუ მნიშვნელობა ნაპოვნია, [`Result::Ok`] უბრუნდება, რომელიც შეიცავს შესატყვისი ელემენტის ინდექსს.თუ არსებობს მრავალი მატჩი, მაშინ რომელიმე მატჩის დაბრუნება შეიძლება.
    /// თუ მნიშვნელობა ვერ მოიძებნა, [`Result::Err`] უბრუნდება, რომელიც შეიცავს ინდექსს, სადაც შესატყვისი ელემენტის ჩასმა შესაძლებელია დახარისხებული წესრიგის შენარჩუნებისას.
    ///
    /// აგრეთვე [`binary_search`], [`binary_search_by_key`] და [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ეძებს ოთხი ელემენტის სერიას.პირველი გვხვდება, ცალსახად განსაზღვრული პოზიციით;მეორე და მესამე არ არის ნაპოვნი;მეოთხე შეიძლება ემთხვეოდეს ნებისმიერ პოზიციას `[1, 4]`-ში.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // უსაფრთხოება: ზარი უსაფრთხო ხდება შემდეგი ინვარიანტების მიერ:
            // - `mid >= 0`
            // - `mid < size`: `mid` შემოიფარგლება `[left; right)` შეკრულით.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // მიზეზი, რის გამოც ჩვენ if/else კონტროლის ნაკადს ვიყენებთ, ვიდრე შესატყვისს, არის ის, რომ მატჩი ახდენს რიგის შედარების ოპერაციებს, რაც ძალიან მგრძნობიარეა.
            //
            // ეს არის x86 asm u8- სთვის: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// ორობითი ეძებს ამ დალაგებულ ნაჭერს ძირითადი მოპოვების ფუნქციით.
    ///
    /// ჩათვლის რომ ნაჭერი დალაგებულია გასაღების მიხედვით, მაგალითად [`sort_by_key`]- ით იმავე გასაღების მოპოვების ფუნქციის გამოყენებით.
    ///
    /// თუ მნიშვნელობა ნაპოვნია, [`Result::Ok`] უბრუნდება, რომელიც შეიცავს შესატყვისი ელემენტის ინდექსს.
    /// თუ არსებობს მრავალი მატჩი, მაშინ რომელიმე მატჩის დაბრუნება შეიძლება.
    /// თუ მნიშვნელობა ვერ მოიძებნა, [`Result::Err`] უბრუნდება, რომელიც შეიცავს ინდექსს, სადაც შესატყვისი ელემენტის ჩასმა შესაძლებელია დახარისხებული წესრიგის შენარჩუნებისას.
    ///
    ///
    /// აგრეთვე [`binary_search`], [`binary_search_by`] და [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ეძებს ოთხი ელემენტის სერიას წყვილების ნაჭერში, რომლებიც დალაგებულია მათი მეორე ელემენტების მიხედვით.
    /// პირველი გვხვდება, ცალსახად განსაზღვრული პოზიციით;მეორე და მესამე არ არის ნაპოვნი;მეოთხე შეიძლება ემთხვეოდეს ნებისმიერ პოზიციას `[1, 4]`-ში.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links დაშვებულია, რადგან `slice::sort_by_key` არის crate `alloc`-ში, და როგორც ასეთი ჯერ კიდევ არ არსებობს `core`-ის მშენებლობისას.
    //
    // crate-ის დინების მიმართულებით მიმავალი ბმულები: #74481.მას შემდეგ, რაც პრიმიტივები მხოლოდ libstd (#73423)-ში არის დოკუმენტირებული, ეს პრაქტიკაში არასოდეს იწვევს გაწყვეტილ კავშირებს.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// ალაგებს ნაჭერს, მაგრამ შეიძლება არ შეინარჩუნოს თანაბარი ელემენტების თანმიმდევრობა.
    ///
    /// ეს დალაგება არასტაბილურია (ანუ შეიძლება თანაბარი ელემენტების გადალაგება), ადგილზე (ანუ არ გამოყოფს) და *O*(*n*\*log(* n*)) უარეს შემთხვევაში.
    ///
    /// # მიმდინარე განხორციელება
    ///
    /// ამჟამინდელი ალგორითმი ემყარება Orson Peters-ის [pattern-defeating quicksort][pdqsort]-ს, რომელიც აერთიანებს რანდომიზებული quicksort-ის საშუალო საშუალო შემთხვევას და heapsort-ის ყველაზე ცუდ შემთხვევას, ხოლო გარკვეული შაბლონების ნაჭრებზე ხაზოვანი დროის მიღწევას.
    /// იგი იყენებს გარკვეულ რანდომიზაციას, რათა თავიდან აიცილოს გადაგვარებული შემთხვევები, მაგრამ ფიქსირებული seed ყოველთვის უზრუნველყოს დეტერმინირებული ქცევა.
    ///
    /// ეს ჩვეულებრივ უფრო სწრაფია, ვიდრე სტაბილური დახარისხება, გარდა რამდენიმე განსაკუთრებული შემთხვევისა, მაგალითად, როდესაც ნაჭერი შედგება რამდენიმე შერწყმული დალაგებული თანმიმდევრობით.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// ალაგებს ნაჭერს შედარების ფუნქციით, მაგრამ შეიძლება არ შეინარჩუნოს თანაბარი ელემენტების რიგი.
    ///
    /// ეს დალაგება არასტაბილურია (ანუ შეიძლება თანაბარი ელემენტების გადალაგება), ადგილზე (ანუ არ გამოყოფს) და *O*(*n*\*log(* n*)) უარეს შემთხვევაში.
    ///
    /// შედარების ფუნქციამ უნდა განსაზღვროს ნაჭრის ელემენტების სრული შეკვეთა.თუ შეკვეთა არ არის სრული, ელემენტების თანმიმდევრობა არ არის განსაზღვრული.შეკვეთა არის ჯამური შეკვეთა, თუ იგი არის (ყველა `a`, `b` და `c`):
    ///
    /// * საერთო და ანტისმეტრიული: `a < b`, `a == b` ან `a > b`- დან ზუსტად ერთია მართალი და
    /// * გარდამავალი, `a < b` და `b < c` გულისხმობს `a < c`-ს.იგივე უნდა ეხებოდეს როგორც `==`, ასევე `>`.
    ///
    /// მაგალითად, მიუხედავად იმისა, რომ [`f64`] არ ახორციელებს [`Ord`]-ს, რადგან `NaN != NaN`, ჩვენ შეგვიძლია გამოვიყენოთ `partial_cmp`, როგორც დალაგების ფუნქცია, როდესაც ვიცით, რომ ნაკვეთი არ შეიცავს `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # მიმდინარე განხორციელება
    ///
    /// ამჟამინდელი ალგორითმი ემყარება Orson Peters-ის [pattern-defeating quicksort][pdqsort]-ს, რომელიც აერთიანებს რანდომიზებული quicksort-ის საშუალო საშუალო შემთხვევას და heapsort-ის ყველაზე ცუდ შემთხვევას, ხოლო გარკვეული შაბლონების ნაჭრებზე ხაზოვანი დროის მიღწევას.
    /// იგი იყენებს გარკვეულ რანდომიზაციას, რათა თავიდან აიცილოს გადაგვარებული შემთხვევები, მაგრამ ფიქსირებული seed ყოველთვის უზრუნველყოს დეტერმინირებული ქცევა.
    ///
    /// ეს ჩვეულებრივ უფრო სწრაფია, ვიდრე სტაბილური დახარისხება, გარდა რამდენიმე განსაკუთრებული შემთხვევისა, მაგალითად, როდესაც ნაჭერი შედგება რამდენიმე შერწყმული დალაგებული თანმიმდევრობით.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // საპირისპირო დახარისხება
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// ალაგებს ნაჭერს ძირითადი მოპოვების ფუნქციით, მაგრამ შეიძლება არ შეინარჩუნოს თანაბარი ელემენტების რიგი.
    ///
    /// ეს დალაგება არასტაბილურია (ანუ შეიძლება თანაბარი ელემენტების გადალაგება), ადგილზე (ანუ არ გამოყოფს) და *O*(m\* * n *\* log(*n*)) უარეს შემთხვევაში, სადაც ძირითადი ფუნქციაა *O*(*მ*).
    ///
    /// # მიმდინარე განხორციელება
    ///
    /// ამჟამინდელი ალგორითმი ემყარება Orson Peters-ის [pattern-defeating quicksort][pdqsort]-ს, რომელიც აერთიანებს რანდომიზებული quicksort-ის საშუალო საშუალო შემთხვევას და heapsort-ის ყველაზე ცუდ შემთხვევას, ხოლო გარკვეული შაბლონების ნაჭრებზე ხაზოვანი დროის მიღწევას.
    /// იგი იყენებს გარკვეულ რანდომიზაციას, რათა თავიდან აიცილოს გადაგვარებული შემთხვევები, მაგრამ ფიქსირებული seed ყოველთვის უზრუნველყოს დეტერმინირებული ქცევა.
    ///
    /// ძირითადი დარეკვის სტრატეგიის გამო, [`sort_unstable_by_key`](#method.sort_unstable_by_key) სავარაუდოდ ნელი იქნება ვიდრე [`sort_by_cached_key`](#method.sort_by_cached_key), იმ შემთხვევაში, თუ ძირითადი ფუნქცია ძვირია.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// მოაწესრიგეთ ნაკვეთი ისე, რომ `index` ელემენტი იყოს საბოლოოდ დალაგებულ მდგომარეობაში.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// მოაწესრიგეთ ნაკვეთი შედარების ფუნქციით, ისე, რომ `index` ელემენტი საბოლოოდ დალაგდეს.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// მოაწესრიგეთ ნაჭერი მოპოვების გასაღების ფუნქციით, ისე, რომ `index` ელემენტი საბოლოოდ დალაგდეს.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// მოაწესრიგეთ ნაკვეთი ისე, რომ `index` ელემენტი იყოს საბოლოოდ დალაგებულ მდგომარეობაში.
    ///
    /// ამ გადაფორმებას აქვს დამატებითი თვისება, რომ ნებისმიერი მნიშვნელობა `i < index` პოზიციაზე ნაკლები იქნება ან ტოლია `j > index` პოზიციის ნებისმიერ მნიშვნელობას.
    /// გარდა ამისა, ეს შეცვლა არასტაბილურია (ე.ი.
    /// ნებისმიერი რაოდენობის ტოლი ელემენტი შეიძლება აღმოჩნდეს `index` პოზიციაზე), ადგილზე (ე.ი.
    /// არ გამოყოფს) და *O*(*n*) ყველაზე ცუდ შემთხვევაში.
    /// ეს ფუნქცია სხვა ბიბლიოთეკებში ასევე ცნობილია როგორც "kth element".
    /// იგი დააბრუნებს შემდეგი მნიშვნელობების სამეულს: ყველა ელემენტი ნაკლებია მოცემულ ინდექსზე, მნიშვნელობა მოცემულ ინდექსში და ყველა ელემენტი აღემატება მოცემულ ინდექსს.
    ///
    ///
    /// # მიმდინარე განხორციელება
    ///
    /// ამჟამინდელი ალგორითმი დაფუძნებულია [`sort_unstable`]-ისთვის გამოყენებული იმავე quicksort ალგორითმის სწრაფი არჩევის ნაწილზე.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics როდესაც `index >= len()`, რაც იმას ნიშნავს, რომ ის ყოველთვის panics ცარიელი ნაჭრებით.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // იპოვნე საშუალო
    /// v.select_nth_unstable(2);
    ///
    /// // ჩვენ მხოლოდ გარანტირებული გვაქვს, რომ ნაჭერი იქნება ერთ - ერთი შემდეგიდან გამომდინარე, მითითებული ინდექსის დალაგების გზით.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// მოაწესრიგეთ ნაკვეთი შედარების ფუნქციით, ისე, რომ `index` ელემენტი საბოლოოდ დალაგდეს.
    ///
    /// ამ გადაფორმებას აქვს დამატებითი თვისება, რომ ნებისმიერი მნიშვნელობა `i < index` პოზიციაზე ნაკლები იქნება ან ტოლია `j > index` პოზიციის ნებისმიერი მნიშვნელობა შედარების ფუნქციის გამოყენებით.
    /// გარდა ამისა, ეს შეცვლა არასტაბილურია (ანუ ნებისმიერი რაოდენობის თანაბარი ელემენტი შეიძლება აღმოჩნდეს `index` პოზიციაზე), ადგილზე (ანუ არ გამოყოფს) და *O*(*n*) უარეს შემთხვევაში.
    /// ეს ფუნქცია სხვა ბიბლიოთეკებში ასევე ცნობილია როგორც "kth element".
    /// იგი უბრუნებს შემდეგი მნიშვნელობების სამეულს: ყველა ელემენტი ნაკლებია მოცემულ ინდექსზე, მნიშვნელობა მოცემულ ინდექსში და ყველა ელემენტი აღემატება მოცემულ ინდექსს, მოცემული შედარების ფუნქციის გამოყენებით.
    ///
    ///
    /// # მიმდინარე განხორციელება
    ///
    /// ამჟამინდელი ალგორითმი დაფუძნებულია [`sort_unstable`]-ისთვის გამოყენებული იმავე quicksort ალგორითმის სწრაფი არჩევის ნაწილზე.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics როდესაც `index >= len()`, რაც იმას ნიშნავს, რომ ის ყოველთვის panics ცარიელი ნაჭრებით.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // იპოვნეთ მედიანა, თითქოს ნაჭრები დალაგებულია კლებადობით.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // ჩვენ მხოლოდ გარანტირებული გვაქვს, რომ ნაჭერი იქნება ერთ - ერთი შემდეგიდან გამომდინარე, მითითებული ინდექსის დალაგების გზით.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// მოაწესრიგეთ ნაჭერი მოპოვების გასაღების ფუნქციით, ისე, რომ `index` ელემენტი საბოლოოდ დალაგდეს.
    ///
    /// ამ გადაფორმებას აქვს დამატებითი თვისება, რომ ნებისმიერი მნიშვნელობა `i < index` პოზიციაზე ნაკლებია ან ტოლი იქნება ნებისმიერი მნიშვნელობა `j > index` პოზიციაზე გასაღების მოპოვების ფუნქციის გამოყენებით.
    /// გარდა ამისა, ეს შეცვლა არასტაბილურია (ანუ ნებისმიერი რაოდენობის თანაბარი ელემენტი შეიძლება აღმოჩნდეს `index` პოზიციაზე), ადგილზე (ანუ არ გამოყოფს) და *O*(*n*) უარეს შემთხვევაში.
    /// ეს ფუნქცია სხვა ბიბლიოთეკებში ასევე ცნობილია როგორც "kth element".
    /// იგი უბრუნებს შემდეგი მნიშვნელობების სამეულს: ყველა ელემენტი ნაკლებია მოცემულ ინდექსზე, მნიშვნელობა მოცემულ ინდექსში და ყველა ელემენტი აღემატება მოცემულ ინდექსს, მოცემული გასაღების მოპოვების ფუნქციის გამოყენებით.
    ///
    ///
    /// # მიმდინარე განხორციელება
    ///
    /// ამჟამინდელი ალგორითმი დაფუძნებულია [`sort_unstable`]-ისთვის გამოყენებული იმავე quicksort ალგორითმის სწრაფი არჩევის ნაწილზე.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics როდესაც `index >= len()`, რაც იმას ნიშნავს, რომ ის ყოველთვის panics ცარიელი ნაჭრებით.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // დააბრუნე მედიანა, თითქოს მასივი დალაგდეს აბსოლუტური მნიშვნელობის მიხედვით.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // ჩვენ მხოლოდ გარანტირებული გვაქვს, რომ ნაჭერი იქნება ერთ - ერთი შემდეგიდან გამომდინარე, მითითებული ინდექსის დალაგების გზით.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// ყველა თანმიმდევრული განმეორებით ელემენტს გადააქვს ნაჭრის ბოლოს [`PartialEq`] trait განხორციელების შესაბამისად.
    ///
    ///
    /// აბრუნებს ორ ნაჭერს.პირველი არ შეიცავს ზედიზედ განმეორებით ელემენტებს.
    /// მეორე შეიცავს ყველა ეგზემპლარს მითითებული თანმიმდევრობით.
    ///
    /// თუ ნაკვეთი დალაგებულია, პირველი დაბრუნებული ნაკვეთი არ შეიცავს ეგზემპლარებს.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// ზედიზედ ყველა ელემენტს გადააქვს ნაკვეთის ბოლოს, მოცემული თანასწორობის მიმართულების დასაკმაყოფილებლად.
    ///
    /// აბრუნებს ორ ნაჭერს.პირველი არ შეიცავს ზედიზედ განმეორებით ელემენტებს.
    /// მეორე შეიცავს ყველა ეგზემპლარს მითითებული თანმიმდევრობით.
    ///
    /// `same_bucket` ფუნქცია ნაწყვეტიდან გადაეცემა მითითებებს ორ ელემენტზე და უნდა განსაზღვროს, ელემენტები ტოლია თუ არა.
    /// ელემენტები გადადის ნაჭერში მათი ბრძანების საპირისპირო წესრიგში, ასე რომ, თუ `same_bucket(a, b)` დააბრუნებს `true`, `a` გადაადგილდება ნაკვეთის ბოლოს.
    ///
    ///
    /// თუ ნაკვეთი დალაგებულია, პირველი დაბრუნებული ნაკვეთი არ შეიცავს ეგზემპლარებს.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // მიუხედავად იმისა, რომ სადავო მითითება გვაქვს `self`- ზე,*თვითნებური* ცვლილებების შეტანა არ შეგვიძლია.`same_bucket` ზარებს შეიძლება panic ჰქონდეს, ამიტომ ჩვენ უნდა დავრწმუნდეთ, რომ ნაკვეთი ყოველთვის მოქმედი მდგომარეობაშია.
        //
        // გაცნობის გზა არის სვოპების გამოყენება;ჩვენ ვიმეორებთ ყველა ელემენტს, შევცვლით, როდესაც მივდივართ ისე, რომ ბოლოს ის ელემენტები, რომელთა შენახვაც გვსურს, წინ არის, ხოლო რომელთა უარყოფა გვიწევს უკან.
        // შემდეგ ჩვენ შეგვიძლია დავჭრათ ნაჭერი.
        // ეს ოპერაცია ჯერ კიდევ `O(n)` ა.
        //
        // მაგალითი: ჩვენ ვიწყებთ ამ მდგომარეობას, სადაც `r` წარმოადგენს "შემდეგს"
        // წაიკითხეთ "და `w` წარმოადგენს" შემდეგ_დაწერას ".
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // self[r]- ის შედარებისას [w-1], ეს არ არის დუბლიკატი, ასე რომ, ჩვენ ერთმანეთს ვცვლით self[r] და self[w] (არანაირი ეფექტი, როგორც r==w) და შემდეგ ვამაგრებთ r და w, ასე რომ დაგვტოვებს:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r]- ის შედარებისას [w-1], ეს მნიშვნელობა დუბლირებულია, ამიტომ ჩვენ ვამაგრებთ `r`- ს, მაგრამ დანარჩენს ყველაფერს ვტოვებთ უცვლელი:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r]- ის შედარება [w-1]-ის წინააღმდეგ, ეს არ არის დუბლირებული, ამიტომ შეცვალეთ self[r] და self[w] და გადადით r და w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // არ არის დუბლიკატი, გაიმეორეთ:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // დუბლიკატი, ნაჭრის advance r. End.გაყოფილი w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // უსაფრთხოება: `while` მდგომარეობა იძლევა გარანტიას `next_read` და `next_write`
        // `len`- ზე ნაკლებია, ამიტომ `self`- შია.
        // `prev_ptr_write` მიუთითებს ერთ ელემენტზე `ptr_write`-მდე, მაგრამ `next_write` იწყება 1-ით, ამიტომ `prev_ptr_write` არასოდეს არის 0-ზე ნაკლები და ნაკვეთის შიგნით არის.
        // ეს აკმაყოფილებს მოთხოვნებს `ptr_read`, `prev_ptr_write` და `ptr_write` მოხსენიებისთვის და `ptr.add(next_read)`, `ptr.add(next_write - 1)` და `prev_ptr_write.offset(1)` გამოყენებისათვის.
        //
        //
        // `next_write` ასევე იზრდება მაქსიმუმ ერთხელ თითო მარყუჟში, რაც იმას ნიშნავს, რომ არცერთი ელემენტი არ არის გამოტოვებული, როდესაც შეიძლება შეცვალოს.
        //
        // `ptr_read` და `prev_ptr_write` არასოდეს მიუთითებენ იმავე ელემენტზე.ეს საჭიროა `&mut *ptr_read`, `&mut* prev_ptr_write`-ის უსაფრთხოებისთვის.
        // მარტივია, რომ `next_read >= next_write` ყოველთვის მართალია, შესაბამისად `next_read > next_write - 1` ც.
        //
        //
        //
        //
        //
        unsafe {
            // თავიდან აიცილეთ საზღვრების შემოწმება ნედლეული მაჩვენებლების გამოყენებით.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// ზედიზედ ყველა ელემენტს გადააქვს ნაკვეთის ბოლოს, რომელიც გადაადგილდება იმავე გასაღებით.
    ///
    ///
    /// აბრუნებს ორ ნაჭერს.პირველი არ შეიცავს ზედიზედ განმეორებით ელემენტებს.
    /// მეორე შეიცავს ყველა ეგზემპლარს მითითებული თანმიმდევრობით.
    ///
    /// თუ ნაკვეთი დალაგებულია, პირველი დაბრუნებული ნაკვეთი არ შეიცავს ეგზემპლარებს.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// ატრიალებს ნაჭერს ადგილზე ისე, რომ ნაჭრის პირველი `mid` ელემენტები გადადის ბოლომდე, ხოლო ბოლო `self.len() - mid` ელემენტები გადადის წინა მხარეს.
    /// `rotate_left` დარეკვის შემდეგ, `mid` ინდექსში არსებული ელემენტი გახდება ნაჭრის პირველი ელემენტი.
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია იქნება panic, თუ `mid` აღემატება ნაჭრის სიგრძეს.გაითვალისწინეთ, რომ `mid == self.len()` აკეთებს _not_ panic და არის ოპერაციის გარეშე როტაცია.
    ///
    /// # Complexity
    ///
    /// სწორხაზოვანია (`self.len()`) დროში).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// ქვედანაყოფის ბრუნვა:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // უსაფრთხოება: დიაპაზონი `[p.add(mid) - mid, p.add(mid) + k)` ტრივიალურია
        // ძალაშია კითხვასა და წერაში, როგორც ამას მოითხოვს `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// ატრიალებს ნაჭერს ადგილზე ისე, რომ ნაჭრის პირველი `self.len() - k` ელემენტები გადადის ბოლომდე, ხოლო ბოლო `k` ელემენტები გადადის წინა მხარეს.
    /// `rotate_right` დარეკვის შემდეგ, `self.len() - k` ინდექსში არსებული ელემენტი გახდება ნაჭრის პირველი ელემენტი.
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია იქნება panic, თუ `k` აღემატება ნაჭრის სიგრძეს.გაითვალისწინეთ, რომ `k == self.len()` აკეთებს _not_ panic და არის ოპერაციის გარეშე როტაცია.
    ///
    /// # Complexity
    ///
    /// სწორხაზოვანია (`self.len()`) დროში).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// გადააქციეთ ქვესახე:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // უსაფრთხოება: დიაპაზონი `[p.add(mid) - mid, p.add(mid) + k)` ტრივიალურია
        // ძალაშია კითხვასა და წერაში, როგორც ამას მოითხოვს `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// ავსებს `self` ელემენტებს `value` კლონირებით.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// `self`- ს ავსებს ელემენტებით, რომლებიც დაბრუნებულია დახურვის განმეორებით გამოძახებით.
    ///
    /// ეს მეთოდი იყენებს დახურვას ახალი მნიშვნელობების შესაქმნელად.თუ მოცემულ მნიშვნელობას [`Clone`] გირჩევნიათ, გამოიყენეთ [`fill`].
    /// თუ გსურთ გამოიყენოთ [`Default`] trait მნიშვნელობების შესაქმნელად, შეგიძლიათ არგუმენტად გადასცეთ [`Default::default`].
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// კოპირებს ელემენტებს `src`- დან `self`- ში.
    ///
    /// `src` სიგრძე უნდა იყოს იგივე, რაც `self`.
    ///
    /// თუ `T` ახორციელებს `Copy`-ს, [`copy_from_slice`]-ის გამოყენება უფრო შედეგიანი იქნება.
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია იქნება panic, თუ ორ ნაჭერს აქვს სხვადასხვა სიგრძე.
    ///
    /// # Examples
    ///
    /// ორი ელემენტის კლონირება ნაჭერიდან მეორეში:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // იმის გამო, რომ ნაჭრები უნდა იყოს იგივე სიგრძე, ჩვენ ვჭრით წყაროს ნაჭერს ოთხი ელემენტიდან ორამდე.
    /// // ეს panic იქნება, თუ ამას არ გავაკეთებთ.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust აცხადებს, რომ შეიძლება მხოლოდ ერთი ცვალებადი მითითება არსებობდეს, რომელშიაც არ იქნება უცვლელი მითითება კონკრეტული მონაცემების კონკრეტულ სფეროში.
    /// ამის გამო, `clone_from_slice` ერთ ნაჭერზე გამოყენების მცდელობა გამოიწვევს შედგენის უკმარისობას:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ამის ირგვლივ შესაქმნელად, ჩვენ შეგვიძლია გამოვიყენოთ [`split_at_mut`] ნაჭრისგან ორი განსხვავებული ქვენაჭრის შესაქმნელად:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// კოპირებს ყველა ელემენტს `src`- დან `self`- ში, memcpy- ს გამოყენებით.
    ///
    /// `src` სიგრძე უნდა იყოს იგივე, რაც `self`.
    ///
    /// თუ `T` არ ახორციელებს `Copy`-ს, გამოიყენეთ [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია იქნება panic, თუ ორ ნაჭერს აქვს სხვადასხვა სიგრძე.
    ///
    /// # Examples
    ///
    /// ნაჭერიდან ორი ელემენტის კოპირება სხვაში:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // იმის გამო, რომ ნაჭრები უნდა იყოს იგივე სიგრძე, ჩვენ ვჭრით წყაროს ნაჭერს ოთხი ელემენტიდან ორამდე.
    /// // ეს panic იქნება, თუ ამას არ გავაკეთებთ.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust აცხადებს, რომ შეიძლება მხოლოდ ერთი ცვალებადი მითითება არსებობდეს, რომელშიაც არ იქნება უცვლელი მითითება კონკრეტული მონაცემების კონკრეტულ სფეროში.
    /// ამის გამო, `copy_from_slice` ერთ ნაჭერზე გამოყენების მცდელობა გამოიწვევს შედგენის უკმარისობას:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ამის ირგვლივ შესაქმნელად, ჩვენ შეგვიძლია გამოვიყენოთ [`split_at_mut`] ნაჭრისგან ორი განსხვავებული ქვენაჭრის შესაქმნელად:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic კოდის ბილიკი ჩაირთო ცივი ფუნქციით, რომ არ მოხდეს ზარის საიტი.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // უსაფრთხოება: `self` სწორია `self.len()` ელემენტებისთვის, ხოლო `src` იყო
        // შემოწმებულია, რომ ჰქონდეს იგივე სიგრძე.
        // ნაჭრების გადაფარვა შეუძლებელია, რადგან ცვლადი ცნობარი ექსკლუზიურია.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// კოპირებს ელემენტებს ნაჭრის ერთი ნაწილიდან თავის მეორე ნაწილში, მემუმის გამოყენებით.
    ///
    /// `src` არის დიაპაზონი, რომლის კოპირებაც არის `self`.
    /// `dest` არის `self` დიაპაზონის საწყისი ინდექსი, რომლის კოპირებაც იქნება, რომელსაც ექნება იგივე სიგრძე, როგორც `src`.
    /// ორი დიაპაზონი შეიძლება გადაფარონ.
    /// ორი დიაპაზონის ბოლოები უნდა იყოს `self.len()`- ზე ნაკლები ან ტოლი.
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია იქნება panic, თუ რომელიმე დიაპაზონი აჭარბებს ნაჭრის ბოლოს, ან თუ `src`-ის დასასრული დაწყებამდეა.
    ///
    ///
    /// # Examples
    ///
    /// ნაკვეთიდან ოთხი ბაიტის კოპირება:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // უსაფრთხოება: ყველა `ptr::copy` პირობები გადამოწმებულია ზემოთ,
        // როგორც ეს `ptr::add`-სთვის.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// შეცვლის ყველა ელემენტს `self`- ში `other`- ში.
    ///
    /// `other` სიგრძე უნდა იყოს იგივე, რაც `self`.
    ///
    /// # Panics
    ///
    /// ეს ფუნქცია იქნება panic, თუ ორ ნაჭერს აქვს სხვადასხვა სიგრძე.
    ///
    /// # Example
    ///
    /// ორი ელემენტის შეცვლა ნაჭრებზე:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust აცხადებს, რომ შეიძლება მხოლოდ ერთი მუტაბელური მითითება იყოს მოცემული მონაცემების კონკრეტულ სფეროში.
    ///
    /// ამის გამო, `swap_with_slice` ერთ ნაჭერზე გამოყენების მცდელობა გამოიწვევს შედგენის უკმარისობას:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// ამის ირგვლივ შესაქმნელად, ჩვენ შეგვიძლია გამოვიყენოთ [`split_at_mut`] ნაჭრისგან ორი განსხვავებული მუტაბელური ქვენაჭრის შესაქმნელად:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // უსაფრთხოება: `self` სწორია `self.len()` ელემენტებისთვის, ხოლო `src` იყო
        // შემოწმებულია, რომ ჰქონდეს იგივე სიგრძე.
        // ნაჭრების გადაფარვა შეუძლებელია, რადგან ცვლადი ცნობარი ექსკლუზიურია.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}`- ის შუა და უკანა ნაჭრის სიგრძის გამოთვლის ფუნქცია.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // რასაც ჩვენ გავაკეთებთ `rest`- ის შესახებ არის იმის გარკვევა, თუ რა U - ის ჯერადი რიცხვი შეგვიძლია ჩავსვათ T -ების ყველაზე დაბალ რაოდენობაში.
        //
        // რამდენი ჩვენ გვჭირდება თითოეული ასეთი "multiple".
        //
        // განვიხილოთ მაგალითად T=u8 U=u16.შემდეგ შეგვიძლია 1 ც 2 ც-ში ჩავსვათ.მარტივი
        // ახლა განვიხილოთ მაგალითად შემთხვევა, როდესაც size_of: :<T>=16, ზომა::<U>=24.</u>
        // ჩვენ შეგვიძლია დავაყენოთ 2 Us `rest` ნაჭერში ყოველი 3 Ts- ის ნაცვლად.
        // ცოტა უფრო რთული.
        //
        // ამის გამოსათვლელი ფორმულაა:
        //
        // ჩვენ= lcm(size_of::<T>, size_of::<U>)/ზომა: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/ზომა_::</u><T>
        //
        // გაფართოვდა და გამარტივდა:
        //
        // ჩვენთვის=ზომა: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=ზომა_::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // საბედნიეროდ, რადგან ეს ყველაფერი მუდმივად ფასდება ... აქ შესრულებას მნიშვნელობა არა აქვს!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // განმეორებითი სტეინის ალგორითმი ჩვენ მაინც უნდა გავაკეთოთ ეს `const fn` (და თუ გადავიყენებთ რეკურსიულ ალგორითმს), რადგან llvm- ზე დაყრდნობით ყველაფრის განმტკიცება is კარგია, ეს ჩემთვის არასასიამოვნოა.
            //
            //

            // უსაფრთხოება: `a` და `b` მონიშნულია არა ნულოვანი მნიშვნელობებით.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // ამოიღეთ 2-ის ყველა ფაქტორი ბ-დან
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // უსაფრთხოება: `b` მონიშნულია არა ნულოვანი.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // ამ ცოდნით შეიარაღებული, ჩვენ ვხვდებით, თუ რამდენი `U` შეგვიძლია მოვათავსოთ!
        let us_len = self.len() / ts * us;
        // და რამდენი `T` იქნება უკანა ნაწილში!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// გადაიტანეთ ნაჭერი სხვა ტიპის ნაჭერზე, რაც უზრუნველყოფს ტიპების გასწორების შენარჩუნებას.
    ///
    /// ეს მეთოდი ნაჭერს ყოფს სამ განსხვავებულ ნაჭრებად: პრეფიქსი, ახალი ტიპის სწორად გასწორებული შუა ნაკვეთი და სუფიქსის ნაჭერი.
    /// ამ მეთოდმა შეიძლება შუა ნაჭერი გახადოს მოცემული ტიპისა და შეყვანის ნაჭრის უდიდესი სიგრძე, მაგრამ ამაზე უნდა იყოს დამოკიდებული მხოლოდ თქვენი ალგორითმის მოქმედება და არა მის სისწორეზე.
    ///
    /// დასაშვებია ყველა შეყვანის მონაცემები დაუბრუნდეს როგორც პრეფიქსი ან სუფიქსი ნაჭერი.
    ///
    /// ამ მეთოდს არ აქვს მიზანი, როდესაც არც შეყვანის ელემენტი `T` ან გამომავალი ელემენტი `U` არის ნულოვანი ზომის და დააბრუნებს ორიგინალ ნაჭერს რაიმე გაყოფის გარეშე.
    ///
    /// # Safety
    ///
    /// ეს მეთოდი, ძირითადად, `transmute`-ია, დაბრუნებული შუა ნაჭრის ელემენტებთან მიმართებაში, ამიტომ `transmute::<T, U>`-სთან დაკავშირებული ყველა ჩვეულებრივი სიგნალი აქ ასევე გამოიყენება.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // გაითვალისწინეთ, რომ ამ ფუნქციის უმეტესი ნაწილი მუდმივად შეფასდება,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // სპეციალურად გაუმკლავდეთ ZST-ებს, რაც არის-საერთოდ ნუ გაუმკლავდებით მათ.
            return (self, &[], &[]);
        }

        // პირველ რიგში, იპოვნეთ რა ეტაპზე გავყოთ პირველი და მე-2 ნაჭრები.
        // მარტივი ptr.align_offset- ით.
        let ptr = self.as_ptr();
        // უსაფრთხოება: უსაფრთხოების შესახებ დეტალური კომენტარისთვის იხილეთ `align_to_mut` მეთოდი.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // უსაფრთხოება: ახლა `rest` ნამდვილად არის გასწორებული, ამიტომ ქვემოთ მოცემული `from_raw_parts` კარგია,
            // ვინაიდან აბონენტი იძლევა გარანტიას, რომ ჩვენ შეგვიძლია უსაფრთხოდ გადავიყვანოთ `T` `U`- ზე.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// გადაიტანეთ ნაჭერი სხვა ტიპის ნაჭერზე, რაც უზრუნველყოფს ტიპების გასწორების შენარჩუნებას.
    ///
    /// ეს მეთოდი ნაჭერს ყოფს სამ განსხვავებულ ნაჭრებად: პრეფიქსი, ახალი ტიპის სწორად გასწორებული შუა ნაკვეთი და სუფიქსის ნაჭერი.
    /// ამ მეთოდმა შეიძლება შუა ნაჭერი გახადოს მოცემული ტიპისა და შეყვანის ნაჭრის უდიდესი სიგრძე, მაგრამ ამაზე უნდა იყოს დამოკიდებული მხოლოდ თქვენი ალგორითმის მოქმედება და არა მის სისწორეზე.
    ///
    /// დასაშვებია ყველა შეყვანის მონაცემები დაუბრუნდეს როგორც პრეფიქსი ან სუფიქსი ნაჭერი.
    ///
    /// ამ მეთოდს არ აქვს მიზანი, როდესაც არც შეყვანის ელემენტი `T` ან გამომავალი ელემენტი `U` არის ნულოვანი ზომის და დააბრუნებს ორიგინალ ნაჭერს რაიმე გაყოფის გარეშე.
    ///
    /// # Safety
    ///
    /// ეს მეთოდი, ძირითადად, `transmute`-ია, დაბრუნებული შუა ნაჭრის ელემენტებთან მიმართებაში, ამიტომ `transmute::<T, U>`-სთან დაკავშირებული ყველა ჩვეულებრივი სიგნალი აქ ასევე გამოიყენება.
    ///
    /// # Examples
    ///
    /// ძირითადი გამოყენება:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // გაითვალისწინეთ, რომ ამ ფუნქციის უმეტესი ნაწილი მუდმივად შეფასდება,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // სპეციალურად გაუმკლავდეთ ZST-ებს, რაც არის-საერთოდ ნუ გაუმკლავდებით მათ.
            return (self, &mut [], &mut []);
        }

        // პირველ რიგში, იპოვნეთ რა ეტაპზე გავყოთ პირველი და მე-2 ნაჭრები.
        // მარტივი ptr.align_offset- ით.
        let ptr = self.as_ptr();
        // უსაფრთხოება: აქ ჩვენ დარწმუნდებით, რომ გამოვიყენებთ U-სთვის შესაბამისობაში მითითებულ მითითებას
        // დანარჩენი მეთოდი.ეს ხდება მაჩვენებლის&[T]-ზე გადასვლით, U-სთვის მიმართული გასწორებით.
        // `crate::ptr::align_offset` ეწოდება სწორად გასწორებული და მოქმედი მაჩვენებელი `ptr` (ეს ეხება `self` მითითებას) და ზომა, რომელიც არის ორის სიმძლავრე (რადგან ის მოდის U- ს გასწორებისთვის), რაც აკმაყოფილებს მის უსაფრთხოების შეზღუდვებს.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // ამის შემდეგ ჩვენ აღარ შეგვიძლია გამოვიყენოთ `rest`, რაც გააუქმებს მის მეტსახელად `mut_ptr`!უსაფრთხოება: იხილეთ კომენტარები `align_to`- ზე.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// ამოწმებს ამ ნაჭრის ელემენტების დახარისხებას.
    ///
    /// ეს არის `a` თითოეული ელემენტისთვის და მისი შემდეგი `b` ელემენტისთვის, `a <= b` უნდა შეიცავდეს.თუ ნაჭერი იძლევა ზუსტად ნულს ან ერთ ელემენტს, `true` უბრუნდება.
    ///
    /// გაითვალისწინეთ, რომ თუ `Self::Item` არის მხოლოდ `PartialOrd`, მაგრამ არა `Ord`, ზემოთ მოცემული განმარტება გულისხმობს, რომ ეს ფუნქცია დააბრუნებს `false`, თუ რომელიმე ზედიზედ ორი ელემენტი არ შედარებადია.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// ამოწმებს არის თუ არა ამ ნაჭრის ელემენტები დალაგებული მოცემული შედარების ფუნქციის გამოყენებით.
    ///
    /// `PartialOrd::partial_cmp`- ის გამოყენების ნაცვლად, ეს ფუნქცია იყენებს მოცემულ `compare` ფუნქციას ორი ელემენტის მწყობრის დასადგენად.
    /// გარდა ამისა, ეს ექვივალენტურია [`is_sorted`];დამატებითი ინფორმაციისთვის იხილეთ მისი დოკუმენტაცია.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// ამოწმებს მოცემულია გასაღების მოპოვების ფუნქციის გამოყენებით ამ ნაჭრის ელემენტების დახარისხება.
    ///
    /// ნაჭრის ელემენტების უშუალოდ შედარების ნაცვლად, ეს ფუნქცია ადარებს ელემენტების კლავიშებს, როგორც ამას განსაზღვრავს `f`.
    /// გარდა ამისა, ეს ექვივალენტურია [`is_sorted`];დამატებითი ინფორმაციისთვის იხილეთ მისი დოკუმენტაცია.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// აბრუნებს დანაყოფის წერტილის ინდექსს მოცემული პრედიკატის შესაბამისად (მეორე დანაყოფის პირველი ელემენტის ინდექსი).
    ///
    /// ნაჭერი გაყოფილია მოცემული პრედიქტის შესაბამისად.
    /// ეს ნიშნავს, რომ ყველა ელემენტი, რომელთათვისაც პრედიკატი ნამდვილი ბრუნდება, ნაკვეთის დასაწყისშია, ხოლო ყველა ელემენტი, რომლისთვისაც პრედიკატი ცრუა, ბოლოს არის.
    ///
    /// მაგალითად, [7, 15, 3, 5, 4, 12, 6] არის დანაყოფი დანაყოფის ქვეშ x% 2!=0 (ყველა უცნაური რიცხვი არის დასაწყისში, ყველა კი ბოლოს).
    ///
    /// თუ ეს ნაკვეთი არ არის დაყოფილი, დაბრუნებული შედეგი არ არის განსაზღვრული და უაზრო, რადგან ეს მეთოდი ახორციელებს ერთგვარ ორობით ძიებას.
    ///
    /// აგრეთვე [`binary_search`], [`binary_search_by`] და [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // უსაფრთხოება: როდესაც `left < right`, `left <= mid < right`.
            // ამიტომ `left` ყოველთვის იზრდება და `right` ყოველთვის იკლებს და შერჩეულია რომელიმე მათგანი.ორივე შემთხვევაში `left <= right` დაკმაყოფილებულია.ამიტომ, თუ `left < right` ნაბიჯშია, `left <= right` კმაყოფილია შემდეგ ეტაპზე.
            //
            // ამიტომ სანამ `left != right`, `0 <= left < right <= len` კმაყოფილია და თუ ამ შემთხვევაში `0 <= mid < len` ც კმაყოფილია.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: ჩვენ მკაფიოდ უნდა დავჭრათ ისინი იმავე სიგრძეზე
        // ოპტიმიზატორისთვის საზღვრების შემოწმების გამარტივების მიზნით.
        // მაგრამ რადგან მასზე იმედი არ შეიძლება, ჩვენ ასევე გვაქვს T: ასლის აშკარა სპეციალიზაცია.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// ქმნის ცარიელ ნაჭერს.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// ქმნის მუტაბელურ ცარიელ ნაჭერს.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// ნიმუშები ნაჭრებად, ამჟამად გამოიყენება მხოლოდ `strip_prefix` და `strip_suffix`.
/// future წერტილში ვიმედოვნებთ განვაზოგადოთ `core::str::Pattern` (რომელიც დაწერის დროს შემოიფარგლება `str`) ნაჭრებად და შემდეგ ეს trait შეიცვლება ან გაუქმდება.
///
pub trait SlicePattern {
    /// ნაჭრის ელემენტის ტიპი ემთხვევა.
    type Item;

    /// ამჟამად, `SlicePattern` მომხმარებელს სჭირდება ნაჭერი.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}