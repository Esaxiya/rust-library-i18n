//! ფრაგმენტის განმეორების მიერ გამოყენებული მაკროები.

// ხაზგასმა არის_ ცარიელი და len ქმნის მნიშვნელოვან განსხვავებას შესრულებაში
macro_rules! is_empty {
    // ZST იტერატორის სიგრძის კოდირების გზით, ეს მუშაობს როგორც ZST, ისე არა ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// ზოგიერთი საზღვრის შემოწმების თავიდან ასაცილებლად (იხ. `position`), ჩვენ გამოვთვლით სიგრძეს გარკვეულწილად მოულოდნელი გზით.
// (ტესტირება ხდება `codegen/slice-position-bounds-check-` by).
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // ჩვენ ზოგჯერ ვიყენებთ სახიფათო ბლოკში

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // ეს _cannot_ იყენებს `unchecked_sub`-ს, რადგან ჩვენ დამოკიდებულებაზე ვართ დამოკიდებული, რომ წარმოვადგინოთ გრძელი ZST ნაჭრის ინტერატორების სიგრძე.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // ჩვენ ვიცით, რომ `start <= end` უკეთესია, ვიდრე `offset_from`, რომელსაც ხელი უნდა მოაწეროს.
            // აქ შესაბამისი დროშების დაყენებით ჩვენ შეგვიძლია LLVM-ს ვუთხრათ ეს, რაც ეხმარება მას ამოიღოს საზღვრების შემოწმებები.
            // უსაფრთხოება: ინვალიდის ტიპის მიხედვით, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // ასევე LLVM- ს ეუბნება, რომ მითითებები დაშორებულია ტიპის ზუსტი მრავლობით, მას შეუძლია `len() == 0` ოპტიმიზაცია `start == end`- მდე `(end - start) < size`- ის ნაცვლად.
            //
            // უსაფრთხოება: ინვალიდის ტიპის მიხედვით, მაჩვენებლები გასწორებულია ისე
            //         მათ შორის მანძილი უნდა იყოს დაკომპლექტებული ზომის ჯერადი
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` და `IterMut` განმეორების საერთო განმარტება
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // აბრუნებს პირველ ელემენტს და 1-ით გადააქვს iterator-ის დასაწყისი.
        // მნიშვნელოვნად აუმჯობესებს მუშაობას ხაზგასმულ ფუნქციასთან შედარებით.
        // იტერატორი არ უნდა იყოს ცარიელი.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // აბრუნებს უკანასკნელ ელემენტს და 1 - ით უკან გადააქვს იტერატორის ბოლოს.
        // მნიშვნელოვნად აუმჯობესებს მუშაობას ხაზგასმულ ფუნქციასთან შედარებით.
        // იტერატორი არ უნდა იყოს ცარიელი.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // ამცირებს იტერატორს, როდესაც T არის ZST, იტერატორის ბოლოს უკან გადაადგილებით `n`-ით.
        // `n` არ უნდა აღემატებოდეს `self.len()`-ს.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // დამხმარე ფუნქცია იტერატორისგან ნაჭრის შესაქმნელად.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // უსაფრთხოება: იტერატორი შეიქმნა მაჩვენებლის ნაჭერიდან
                // `self.ptr` და სიგრძე `len!(self)`.
                // ეს იძლევა გარანტიას, რომ შესრულებულია `from_raw_parts`- ის ყველა წინაპირობა.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // დამხმარე ფუნქცია იტერატორის დაწყების გადაადგილებისთვის `offset` ელემენტებით, ძველი სტარტის დაბრუნებით.
            //
            // არაუსაფრთხოა, რადგან კომპენსაცია არ უნდა აღემატებოდეს `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // უსაფრთხოება: აბონენტი იძლევა გარანტიას, რომ `offset` არ აღემატება `self.len()`,
                    // ამ ახალი მაჩვენებლის შიგნით არის `self` და ამით გარანტირებულია, რომ ის არ არის ნულოვანი.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // დამხმარე ფუნქცია იტერატორის ბოლოს `offset` ელემენტებით უკან გადაადგილებისთვის, ახალი დასასრულის დასაბრუნებლად.
            //
            // არაუსაფრთხოა, რადგან კომპენსაცია არ უნდა აღემატებოდეს `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // უსაფრთხოება: აბონენტი იძლევა გარანტიას, რომ `offset` არ აღემატება `self.len()`,
                    // რომელიც გარანტირებულია, რომ არ გადავსდება `isize`.
                    // ასევე, მიღებული მაჩვენებელი `slice`- ის საზღვრებშია, რომელიც აკმაყოფილებს `offset`- ის სხვა მოთხოვნებს.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // შეიძლება განხორციელდეს ნაჭრებით, მაგრამ ეს თავიდან აცილებს საზღვრების შემოწმებას

                // უსაფრთხოება: `assume` ზარები უსაფრთხოა, რადგან ნაჭრის საწყისი მაჩვენებელია
                // უნდა იყოს არა-ნული, ხოლო არა-ZST-ების ნაჭრებს ასევე უნდა ჰქონდეს არა-ნულოვანი დაბოლოების მაჩვენებელი.
                // `next_unchecked!`-ზე ზარი უსაფრთხოა, ვინაიდან ჩვენ ვამოწმებთ ჯერ ცარიელია თუ არა iterator.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ეს გამწმენდი ახლა ცარიელია.
                    if mem::size_of::<T>() == 0 {
                        // ჩვენ ეს უნდა გავაკეთოთ ამ გზით, რადგან `ptr` შეიძლება არასდროს იყოს 0, მაგრამ `end` შეიძლება იყოს (შეფუთვის გამო).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // უსაფრთხოება: ბოლო არ შეიძლება იყოს 0, თუ T არ არის ZST, რადგან ptr არ არის 0 და დასრულება>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // უსაფრთხოება: ჩვენ საზღვრებში ვართ.`post_inc_start` სწორად იქცევა ZST-ებისთვისაც კი.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // ჩვენ უგულებელვყოფთ ნაგულისხმევ განხორციელებას, რომელიც იყენებს `try_fold`-ს, რადგან ეს მარტივი განხორციელება ნაკლებად ქმნის LLVM IR-ს და უფრო სწრაფად ხდება მისი შედგენა.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // ჩვენ უგულებელვყოფთ ნაგულისხმევ განხორციელებას, რომელიც იყენებს `try_fold`-ს, რადგან ეს მარტივი განხორციელება ნაკლებად ქმნის LLVM IR-ს და უფრო სწრაფად ხდება მისი შედგენა.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // ჩვენ უგულებელვყოფთ ნაგულისხმევ განხორციელებას, რომელიც იყენებს `try_fold`-ს, რადგან ეს მარტივი განხორციელება ნაკლებად ქმნის LLVM IR-ს და უფრო სწრაფად ხდება მისი შედგენა.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // ჩვენ უგულებელვყოფთ ნაგულისხმევ განხორციელებას, რომელიც იყენებს `try_fold`-ს, რადგან ეს მარტივი განხორციელება ნაკლებად ქმნის LLVM IR-ს და უფრო სწრაფად ხდება მისი შედგენა.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // ჩვენ უგულებელვყოფთ ნაგულისხმევ განხორციელებას, რომელიც იყენებს `try_fold`-ს, რადგან ეს მარტივი განხორციელება ნაკლებად ქმნის LLVM IR-ს და უფრო სწრაფად ხდება მისი შედგენა.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // ჩვენ უგულებელვყოფთ ნაგულისხმევ განხორციელებას, რომელიც იყენებს `try_fold`-ს, რადგან ეს მარტივი განხორციელება ნაკლებად ქმნის LLVM IR-ს და უფრო სწრაფად ხდება მისი შედგენა.
            // ასევე, `assume` თავს არიდებს საზღვრების შემოწმებას.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // უსაფრთხოება: მარყუჟის უცვლელად გარანტირებული ვიქნებით:
                        // როდესაც `i >= n`, `self.next()` დააბრუნებს `None` და მარყუჟი წყდება.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // ჩვენ უგულებელვყოფთ ნაგულისხმევ განხორციელებას, რომელიც იყენებს `try_fold`-ს, რადგან ეს მარტივი განხორციელება ნაკლებად ქმნის LLVM IR-ს და უფრო სწრაფად ხდება მისი შედგენა.
            // ასევე, `assume` თავს არიდებს საზღვრების შემოწმებას.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // უსაფრთხოება: `i` უნდა იყოს დაბალი ვიდრე `n`, რადგან ის იწყება `n`-ით
                        // და მხოლოდ იკლებს.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // უსაფრთხოება: აბონენტმა უნდა უზრუნველყოს, რომ `i` არის საზღვრებში
                // ძირითადი ნაჭერი, ასე რომ, `i` ვერ გადაფენს `isize`-ს, და დაბრუნებული ცნობები გარანტირებულად მიუთითებს ნაჭრის ელემენტზე და, შესაბამისად, მათი მოქმედება გარანტირებულია.
                //
                // ასევე გაითვალისწინეთ, რომ აბონენტი ასევე იძლევა გარანტიას, რომ ჩვენ აღარ დაგვირეკავენ იგივე ინდექსით, და რომ სხვა მეთოდები არ დარეკავს, რომლებიც ამ ქვესახეზე შევა, ამიტომ მართებულია, რომ დაბრუნებული მითითება მუტაბელური იყოს
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // შეიძლება განხორციელდეს ნაჭრებით, მაგრამ ეს თავიდან აცილებს საზღვრების შემოწმებას

                // უსაფრთხოება: `assume` ზარები უსაფრთხოა, ვინაიდან ნაჭრის საწყისი მაჩვენებელი არ არის ნულოვანი,
                // და არა ZST-ების ნაჭრებს ასევე უნდა ჰქონდეს არასასურველი ბოლოს მაჩვენებელი.
                // `next_back_unchecked!`-ზე ზარი უსაფრთხოა, ვინაიდან ჩვენ ვამოწმებთ ჯერ ცარიელი არის თუ არა iterator.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ეს გამწმენდი ახლა ცარიელია.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // უსაფრთხოება: ჩვენ საზღვრებში ვართ.`pre_dec_end` სწორად იქცევა ZST-ებისთვისაც კი.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}