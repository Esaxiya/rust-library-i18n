// ორიგინალი განხორციელება აღებულია rust-memchr-დან.
// საავტორო უფლებები 2015 ენდრიუ გალანტი, bluss და ნიკოლას კოხი

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// გამოიყენეთ truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// აბრუნებს `true`-ს, თუ `x` შეიცავს ნულოვან ბაიტს.
///
/// From *Matters Computational*, ჯ. არნდტი:
///
/// "იდეა არის თითოეული ბაიტიდან გამოკლება და შემდეგ ბაიტების ძებნა, სადაც სესხი ყველაზე მნიშვნელოვნად მიდის
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// აბრუნებს პირველ ინდექსს, რომელიც ემთხვევა `x` ბაიტს `text`-ში.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // სწრაფი გზა მცირე ნაჭრებისთვის
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // დაასკანირეთ ერთი ბაიტიანი მნიშვნელობა ერთდროულად ორი `usize` სიტყვის წაკითხვით.
    //
    // გაყოფილი `text` სამ ნაწილად
    // - შეუსაბამო საწყისი ნაწილი, ტექსტში პირველი სიტყვის გასწორებული მისამართის დაწყებამდე
    // - სხეული, სკანირება ერთდროულად 2 სიტყვით
    // - ბოლო დარჩენილი ნაწილი, <2 სიტყვის ზომა

    // მოძებნეთ გასწორებული საზღვარი
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // ტექსტის კორპუსის ძებნა
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // უსაფრთხოება: ხოლო predict უზრუნველყოფს გარანტიას მინიმუმ 2 * usize_bytes
        // ნაჭრის ოფსეტსა და ბოლოს შორის.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // შესვენება, თუ არსებობს შესაბამისი ბაიტი
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // იპოვეთ ბაიტი სხეულის ციკლის შეჩერების შემდეგ.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// აბრუნებს ბოლო ინდექსს, რომელიც შეესაბამება `x` ბაიტს `text`-ში.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // დაასკანირეთ ერთი ბაიტიანი მნიშვნელობა ერთდროულად ორი `usize` სიტყვის წაკითხვით.
    //
    // გაყოფილი `text` სამ ნაწილად:
    // - შეუსაბამო კუდი ტექსტში ბოლო სიტყვის გასწორებული მისამართის შემდეგ,
    // - სხეული, დასკანირებული ერთდროულად 2 სიტყვით,
    // - პირველი დარჩენილი ბაიტი, <2 სიტყვის ზომა.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // ამას მხოლოდ იმიტომ ვუწოდებთ, რომ მივიღოთ პრეფიქსი და სუფიქსის სიგრძე.
        // შუაში ჩვენ ყოველთვის ვამუშავებთ ორ ერთეულს.
        // უსაფრთხოება: `[u8]`- დან `[usize]`- ით ტრანსმუტაცია უსაფრთხოა, გარდა ზომის სხვაობებისა, რომელსაც ამუშავებს `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // მოძებნეთ ტექსტის ტექსტი, დარწმუნდით, რომ არ გადავკვეთთ min_aligned_offset-ს.
    // ოფსეტური ყოველთვის გასწორებულია, ამიტომ მხოლოდ `>`- ის ტესტირება საკმარისია და თავიდან აიცილებთ შესაძლო გადახურვას.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // უსაფრთხოება: კომპენსაცია იწყება len, suffix.len()-ით, ვიდრე ეს უფრო მეტია, ვიდრე
        // min_aligned_offset (prefix.len()) დარჩენილი მანძილი არის მინიმუმ 2 * ბლოკი_ბაიტი.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // შესვენება, თუ არსებობს შესაბამისი ბაიტი.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // იპოვნეთ ბაიტი სანამ სხეულის ციკლი არ გაჩერდება.
    text[..offset].iter().rposition(|elt| *elt == x)
}