//! ოპერაციები ASCII `[u8]`-ზე.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// ამოწმებს, ამ ფრაგმენტში ყველა ბაიტი არის ASCII დიაპაზონში.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// ამოწმებს, რომ ორი ნაჭერი არის ASCII შემთხვევითი - მგრძნობიარე შესატყვისი.
    ///
    /// იგივეა, რაც `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, მაგრამ არ გამოყოფს და არ გადაწერს თანამედროვეებს.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// გარდაქმნის ამ ნაჭერს ASCII- ის ზედა ექვივალენტის ადგილზე.
    ///
    /// ASCII ასოები 'a'-დან 'z'-მდე დატანილია 'A'-დან 'Z'-მდე, მაგრამ არა ASCII ასოები უცვლელია.
    ///
    /// ახალი დიდი მნიშვნელობის დასაბრუნებლად არსებული შეცვლის გარეშე გამოიყენეთ [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// ამ ნაჭერს აქცევს ASCII- ის მცირედი ეკვივალენტის ადგილზე.
    ///
    /// ASCII ასოები 'A'-დან 'Z'-მდე დატანილია 'a'-დან 'z'-მდე, მაგრამ არა ASCII ასოები უცვლელია.
    ///
    /// ახალი ქვედა მნიშვნელობის დასაბრუნებლად არსებული შეცვლის გარეშე გამოიყენეთ [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// აბრუნებს `true`-ს, თუ რომელიმე ბაიტი სიტყვა `v`-ში არის nonascii (>=128).
/// Snarfed საწყისი `../str/mod.rs`, რომელიც აკეთებს მსგავსი რამ utf8 დადასტურება.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// ოპტიმიზირებული ASCII ტესტი, რომელიც გამოიყენებს ერთჯერადი გამოყენების ოპერაციებს, ერთდროულად ბაიტის ოპერაციების ნაცვლად (როდესაც ეს შესაძლებელია).
///
/// ალგორითმი, რომელსაც აქ ვიყენებთ, საკმაოდ მარტივია.თუ `s` ძალიან მოკლეა, ჩვენ ვამოწმებთ თითოეულ ბაიტს და ამით ვამთავრებთ მას.წინააღმდეგ შემთხვევაში:
///
/// - წაიკითხეთ პირველი სიტყვა უსწორმასწორო დატვირთვით.
/// - გასწორეთ მაჩვენებელი, წაიკითხეთ შემდეგი სიტყვები ბოლომდე გასწორებული დატვირთვით.
/// - წაიკითხეთ ბოლო `usize` `s`- დან შეუსაბამო დატვირთვით.
///
/// თუ ამ დატვირთვებიდან რომელიმეს წარმოქმნის რამე, რისთვისაც `contains_nonascii` (above) ნამდვილი ხდება, მაშინ ვიცით, რომ პასუხი მცდარია.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // თუ სიტყვის ერთჯერადი განხორციელებით ვერაფერს მივიღებდით, დაუბრუნდით სკალარულ მარყუჟს.
    //
    // ამას ჩვენ ასევე ვაკეთებთ არქიტექტურისთვის, სადაც `size_of::<usize>()` არ არის საკმარისი გასწორება `usize`-სთვის, რადგან ეს არის უცნაური edge საქმე.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // ჩვენ ყოველთვის ვკითხულობთ პირველ სიტყვას შეუსაბამოდ, რაც ნიშნავს, რომ `align_offset` არის
    // 0, ჩვენ ისევ იმავე მნიშვნელობას წავიკითხავთ გასწორებული წაკითხვისთვის.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // უსაფრთხოება: ჩვენ ვადასტურებთ `len < USIZE_SIZE` ზემოთ.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // ჩვენ ეს გადავამოწმეთ ზემოთ, გარკვეულწილად ფარულად.
    // გაითვალისწინეთ, რომ `offset_to_aligned` არის `align_offset` ან `USIZE_SIZE`, ორივე ნათლად არის გადამოწმებული ზემოთ.
    //
    debug_assert!(offset_to_aligned <= len);

    // უსაფრთხოება: word_ptr არის (სწორად გასწორებული) ptr, რომელსაც ვიკითხავთ
    // ნაჭრის შუა ნაწილი.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` არის ბაიტის ინდექსი `word_ptr`, რომელიც გამოიყენება მარყუჟის ბოლოს შემოწმებისთვის.
    let mut byte_pos = offset_to_aligned;

    // პარანოია შეამოწმეთ გასწორების შესახებ, ვინაიდან ჩვენ ვაპირებთ გავაკეთოთ რამოდენიმე უსწორმასწორო დატვირთვა.
    // პრაქტიკაში ეს შეუძლებელი იქნება `align_offset`- ის შეცდომით.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // წაიკითხეთ შემდეგი სიტყვები ბოლო გასწორებულ სიტყვამდე, გარდა ბოლო ბოლო გასწორებული სიტყვისა, რომელიც მოგვიანებით უნდა გაკეთდეს კუდის შემოწმებისას, იმის უზრუნველსაყოფად, რომ კუდი ყოველთვის არის ერთი `usize` მაქსიმალური branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // საღი აზრის შემოწმება არის თუ არა წაკითხული საზღვრებში
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // და რომ ჩვენი ვარაუდი `byte_pos`- ს ეხება.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // უსაფრთხოება: ჩვენ ვიცით, რომ `word_ptr` სწორად არის გასწორებული (ამის გამო
        // `align_offset`), და ჩვენ ვიცით, რომ საკმარისი ბაიტი გვაქვს `word_ptr` და ბოლომდე
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // უსაფრთხოება: ჩვენ ვიცით, რომ `byte_pos <= len - USIZE_SIZE`, რაც ნიშნავს იმას
        // ამ `add`-ის შემდეგ, `word_ptr` იქნება მაქსიმუმ ერთი წარსული.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // საღი აზრის შემოწმება იმის დასადასტურებლად, რომ მხოლოდ ერთი `usize` დარჩა.
    // ეს უნდა იყოს გარანტირებული ჩვენი მარყუჟის პირობით.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // უსაფრთხოება: ეს ეყრდნობა `len >= USIZE_SIZE`-ს, რომელსაც თავიდანვე ვამოწმებთ.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}