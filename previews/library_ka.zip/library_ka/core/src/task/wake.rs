#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` საშუალებას აძლევს ამოცანის შემსრულებელს შექმნას [`Waker`], რომელიც უზრუნველყოფს პერსონალურად გაღვიძების ქცევას.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// იგი შედგება მონაცემთა მაჩვენებლისა და [virtual function pointer table (vtable)][vtable]-ისგან, რომელიც აკონტროლებს `RawWaker`-ის ქცევას.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// მონაცემთა მაჩვენებელი, რომელიც შეიძლება გამოყენებულ იქნას თვითნებური მონაცემების შესანახად, როგორც ამას მოითხოვს შემსრულებელი.
    /// ეს შეიძლება იყოს მაგ
    /// `Arc` ტიპის ტიპის წაშლილი მაჩვენებელი, რომელიც ასოცირდება დავალებასთან.
    /// ამ ველის მნიშვნელობა გადადის ყველა ფუნქციაზე, რომლებიც vtable- ის ნაწილია, როგორც პირველი პარამეტრი.
    ///
    data: *const (),
    /// ვირტუალური ფუნქციის მაჩვენებლის ცხრილი, რომელიც მორგებულია ამ გამათბობლის ქცევას.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// ქმნის ახალ `RawWaker`-ს გათვალისწინებული `data` მაჩვენებლისა და `vtable`-ისგან.
    ///
    /// `data` მაჩვენებელი შეიძლება გამოყენებულ იქნას თვითნებური მონაცემების შესანახად, როგორც ამას მოითხოვს შემსრულებელი.ეს შეიძლება იყოს მაგ
    /// `Arc` ტიპის ტიპის წაშლილი მაჩვენებელი, რომელიც ასოცირდება დავალებასთან.
    /// ამ მაჩვენებლის მნიშვნელობა გადაეცემა ყველა ფუნქციას, რომლებიც `vtable`- ის ნაწილია, როგორც პირველი პარამეტრი.
    ///
    /// `vtable` აკონტროლებს `Waker`-ის ქცევას, რომელიც იქმნება `RawWaker`-ისგან.
    /// `Waker`- ზე თითოეული ოპერაციისთვის, გამოძახებული იქნება ძირითადი `RawWaker`- ის `vtable`- ის ასოცირებული ფუნქცია.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// ვირტუალური ფუნქციის მაჩვენებელი (vtable) ცხრილი, რომელიც განსაზღვრავს [`RawWaker`]-ის ქცევას.
///
/// მაჩვენებელი, რომელიც გადადის vtable-ის ყველა ფუნქციას, არის `data` მაჩვენებელი თანდართული [`RawWaker`] ობიექტიდან.
///
/// ამ სტრუქტურის შიგნით ფუნქციები მხოლოდ [`RawWaker`] დანერგვის შიგნიდან უნდა იყოს გამოძახებული სწორად აგებული [`RawWaker`] ობიექტის `data` მაჩვენებელზე.
/// რომელიმე სხვა ფუნქციის რომელიმე სხვა `data` მაჩვენებლის გამოყენებით დარეკვა გამოიწვევს გაურკვეველ ქცევას.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// ამ ფუნქციას დაარქმევენ [`RawWaker`]-ის კლონირებისას, მაგ., როდესაც ხდება [`Waker`]-ის შენახვა [`RawWaker`]-ის კლონირებისას.
    ///
    /// ამ ფუნქციის განხორციელებამ უნდა შეინარჩუნოს ყველა რესურსი, რაც საჭიროა [`RawWaker`] და მასთან დაკავშირებული ამოცანის ამ დამატებითი შემთხვევისთვის.
    /// `wake`- ზე დარეკვის შედეგად [`RawWaker`]- ზე უნდა მოხდეს იგივე ამოცანის გაღვიძება, რაც გაიღვიძებდა თავდაპირველ [`RawWaker`]- ს მიერ.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// ამ ფუნქციას ეძახიან, როდესაც `wake` გამოიძახება [`Waker`].
    /// მან უნდა გააღვიძოს ამ [`RawWaker`]- სთან დაკავშირებული ამოცანა.
    ///
    /// ამ ფუნქციის განხორციელებამ უნდა გაათავისუფლოს ნებისმიერი რესურსი, რომელიც ასოცირდება [`RawWaker`] და მასთან დაკავშირებული ამოცანის ამ ინსტანციასთან.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// ამ ფუნქციას ეძახიან, როდესაც `wake_by_ref` გამოიძახება [`Waker`].
    /// მან უნდა გააღვიძოს ამ [`RawWaker`]- სთან დაკავშირებული ამოცანა.
    ///
    /// ეს ფუნქცია მსგავსია `wake`, მაგრამ არ უნდა მოიხმაროს მოწოდებული მონაცემების მაჩვენებელი.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// ეს ფუნქცია ეწოდება [`RawWaker`] ჩამოშვებისას.
    ///
    /// ამ ფუნქციის განხორციელებამ უნდა გაათავისუფლოს ნებისმიერი რესურსი, რომელიც ასოცირდება [`RawWaker`] და მასთან დაკავშირებული ამოცანის ამ ინსტანციასთან.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// ქმნის ახალ `RawWakerVTable`-ს მოწოდებული `clone`, `wake`, `wake_by_ref` და `drop` ფუნქციებისგან.
    ///
    /// # `clone`
    ///
    /// ამ ფუნქციას დაარქმევენ [`RawWaker`]-ის კლონირებისას, მაგ., როდესაც ხდება [`Waker`]-ის შენახვა [`RawWaker`]-ის კლონირებისას.
    ///
    /// ამ ფუნქციის განხორციელებამ უნდა შეინარჩუნოს ყველა რესურსი, რაც საჭიროა [`RawWaker`] და მასთან დაკავშირებული ამოცანის ამ დამატებითი შემთხვევისთვის.
    /// `wake`- ზე დარეკვის შედეგად [`RawWaker`]- ზე უნდა მოხდეს იგივე ამოცანის გაღვიძება, რაც გაიღვიძებდა თავდაპირველ [`RawWaker`]- ს მიერ.
    ///
    /// # `wake`
    ///
    /// ამ ფუნქციას ეძახიან, როდესაც `wake` გამოიძახება [`Waker`].
    /// მან უნდა გააღვიძოს ამ [`RawWaker`]- სთან დაკავშირებული ამოცანა.
    ///
    /// ამ ფუნქციის განხორციელებამ უნდა გაათავისუფლოს ნებისმიერი რესურსი, რომელიც ასოცირდება [`RawWaker`] და მასთან დაკავშირებული ამოცანის ამ ინსტანციასთან.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// ამ ფუნქციას ეძახიან, როდესაც `wake_by_ref` გამოიძახება [`Waker`].
    /// მან უნდა გააღვიძოს ამ [`RawWaker`]- სთან დაკავშირებული ამოცანა.
    ///
    /// ეს ფუნქცია მსგავსია `wake`, მაგრამ არ უნდა მოიხმაროს მოწოდებული მონაცემების მაჩვენებელი.
    ///
    /// # `drop`
    ///
    /// ეს ფუნქცია ეწოდება [`RawWaker`] ჩამოშვებისას.
    ///
    /// ამ ფუნქციის განხორციელებამ უნდა გაათავისუფლოს ნებისმიერი რესურსი, რომელიც ასოცირდება [`RawWaker`] და მასთან დაკავშირებული ამოცანის ამ ინსტანციასთან.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// ასინქრონული ამოცანის `Context`.
///
/// ამჟამად, `Context` ემსახურება მხოლოდ `&Waker`- ზე წვდომას, რომელიც შეიძლება გამოყენებულ იქნას მიმდინარე ამოცანის გასაღვიძებლად.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // დარწმუნდით, რომ ჩვენ future მტკიცებულება გვაქვს საწინააღმდეგო ცვლილებების წინააღმდეგ, აიძულოთ სიცოცხლის ხანგრძლივობა იყოს უცვლელი (არგუმენტაციის პოზიციის სიცოცხლის ხანგრძლივობა უკუჩვენებადია, ხოლო დაბრუნების პოზიციის სიცოცხლის ხანგრძლივობა არის ცვალებადობა).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// შექმენით ახალი `Context` `&Waker`- დან.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// აბრუნებს მითითებას `Waker` მიმდინარე დავალებისთვის.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` არის დავალების გაღვიძების სახელური, რომ შეატყობინოს მის შემსრულებელს, რომ იგი მზად არის გასაშვებად.
///
/// ეს სახელური შეიცავს [`RawWaker`] ინსტანციას, რომელიც განსაზღვრავს შემსრულებლის სპეციფიკურ გაღვიძების ქცევას.
///
///
/// ახორციელებს [`Clone`], [`Send`] და [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// გაიღვიძეთ ამ `Waker`- სთან დაკავშირებული დავალება.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // გამოღვიძების რეალური ზარი გადაეცემა ვირტუალური ფუნქციის საშუალებით განხორციელებას, რომელსაც განსაზღვრავს შემსრულებელი.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // არ დაურეკოთ `drop`-გამოღვიძებას მოიხმარს `wake`.
        crate::mem::forget(self);

        // უსაფრთხოება: ეს უსაფრთხოა, რადგან ერთადერთი გზაა `Waker::from_raw`
        // `wake` და `data` ინიციალიზაცია, რომელიც მოითხოვს მომხმარებელს აღიაროს, რომ `RawWaker` ხელშეკრულება დაცულია.
        //
        unsafe { (wake)(data) };
    }

    /// გაიღვიძეთ ამ `Waker`- სთან დაკავშირებული დავალება `Waker`- ის მოხმარების გარეშე.
    ///
    /// ეს ჰგავს `wake`-ს, მაგრამ შეიძლება ოდნავ ნაკლებად ეფექტური იყოს იმ შემთხვევაში, თუ საკუთრებაშია `Waker`.
    /// ეს მეთოდი სასურველია `waker.clone().wake()`- ზე დარეკვით.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // გამოღვიძების რეალური ზარი გადაეცემა ვირტუალური ფუნქციის საშუალებით განხორციელებას, რომელსაც განსაზღვრავს შემსრულებელი.
        //

        // უსაფრთხოება: იხილეთ `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// აბრუნებს `true`- ს, თუ ამ `Waker`- მა და სხვა `Waker`- მა იგივე ამოცანა გააღვიძეს.
    ///
    /// ეს ფუნქცია მუშაობს საუკეთესო ძალისხმევის საფუძველზე, და შეიძლება დაბრუნდეს ყალბი მაშინაც კი, როდესაც `Waker` გაიღვიძებს იმავე დავალებას.
    /// ამასთან, თუ ეს ფუნქცია დააბრუნებს `true`-ს, გარანტირებულია, რომ `Waker` გამოაღვიძებს იგივე ამოცანას.
    ///
    /// ეს ფუნქცია ძირითადად გამოიყენება ოპტიმიზაციის მიზნით.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// ქმნის ახალ `Waker` [`RawWaker`]- სგან.
    ///
    /// დაბრუნებული `Waker`- ის ქცევა განუსაზღვრელია, თუ [`RawWaker`]-ისა და [`RawWakerVTable`]-ის დოკუმენტაციაში განსაზღვრული ხელშეკრულება არ დაიცავს.
    ///
    /// ამიტომ ეს მეთოდი არ არის უსაფრთხო.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // უსაფრთხოება: ეს უსაფრთხოა, რადგან ერთადერთი გზაა `Waker::from_raw`
            // `clone` და `data` ინიციალიზაცია, რომელიც მოითხოვს მომხმარებელს აღიაროს, რომ [`RawWaker`] ხელშეკრულება დაცულია.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // უსაფრთხოება: ეს უსაფრთხოა, რადგან ერთადერთი გზაა `Waker::from_raw`
        // `drop` და `data` ინიციალიზაცია, რომელიც მოითხოვს მომხმარებელს აღიაროს, რომ `RawWaker` ხელშეკრულება დაცულია.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}