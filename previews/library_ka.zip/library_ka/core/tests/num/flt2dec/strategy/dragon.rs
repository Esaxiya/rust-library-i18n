use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // მირი ძალიან ნელია
fn exact_sanity_test() {
    // ამ ტესტის დასრულებით იწარმოებს ის, რისიც მე შემიძლია მხოლოდ ვიფიქრო, რომ არის `exp2` ბიბლიოთეკის ფუნქციის რაიმე კუთხური შემთხვევა, რომელიც განსაზღვრულია C პერიოდის განმავლობაში, რომელსაც ვიყენებთ.
    // VS 2013-ში ამ ფუნქციას აშკარად ჰქონდა შეცდომა, რადგან ეს ტესტი ვერ ხერხდება დაკავშირების დროს, მაგრამ VS 2015-სთან ერთად შეცდომა გამოსწორებულია, რადგან ტესტი კარგად მუშაობს.
    //
    // როგორც ჩანს, შეცდომა არის `exp2(-1057)` დაბრუნების მნიშვნელობის სხვაობა, სადაც VS 2013- ში იგი ორმაგად იბრუნებს 0x2 ბიტის ნიმუშით, ხოლო VS 2015 - ში 0x20000.
    //
    //
    // ახლა უბრალოდ უგულებელყოფთ ამ ტესტს მთლიანად MSVC- ზე, რადგან ის სხვაგან არის ტესტირებული და ჩვენ არ ვართ ძალიან დაინტერესებული თითოეული პლატფორმის exp2 განხორციელების ტესტირებით.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}