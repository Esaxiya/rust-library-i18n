# `rustc-std-workspace-std` crate

იხილეთ დოკუმენტაცია `rustc-std-workspace-core` crate-სთვის.