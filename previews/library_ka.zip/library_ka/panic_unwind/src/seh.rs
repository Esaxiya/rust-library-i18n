//! Windows SEH
//!
//! Windows- ზე (ამჟამად მხოლოდ MSVC- ზე), ნაგულისხმევი გამონაკლისის დამუშავების მექანიზმია სტრუქტურირებული გამონაკლისის დამუშავება (SEH).
//! ეს საკმაოდ განსხვავდება, ვიდრე ჯუჯაზე დაფუძნებული გამონაკლისის დამუშავება (მაგ., სხვა unix პლატფორმებს რას იყენებენ) შემდგენელთა შინაგან საქმეთა თვალსაზრისით, ამიტომ LLVM- ს სჭირდება SEH- ს დამატებითი მხარდაჭერა.
//!
//! მოკლედ, რაც აქ ხდება:
//!
//! 1. `panic` ფუნქცია იძახებს სტანდარტულ Windows ფუნქციას `_CxxThrowException` C++ გასაგებად-გამონაკლისის მსგავსად, განტვირთვის პროცესის გააქტიურებისთვის.
//! 2.
//! შემდგენლის მიერ წარმოქმნილი სადესანტო ბალიშები იყენებს პიროვნების ფუნქციას `__CxxFrameHandler3`, ფუნქციას CRT-ში და განტვირთვის კოდს Windows-ში გამოიყენებს ამ პიროვნების ფუნქციას დასტის გასუფთავებელი კოდის შესასრულებლად.
//!
//! 3. შემდგენელთა მიერ გენერირებულ ყველა ზარს `invoke`- ზე აქვს სადესანტო დაყენებული, როგორც `cleanuppad` LLVM ინსტრუქცია, რაც მიუთითებს გაწმენდის რუტინის დაწყებაზე.
//! პიროვნება (CRT- ით განსაზღვრულ მე -2 ეტაპზე) პასუხისმგებელია დასუფთავების პროცესების მართვაზე.
//! 4. საბოლოოდ X001 კოდი `try` შინაარსში (შემქმნელის მიერ წარმოებული) შესრულდება და მიუთითებს, რომ კონტროლი უნდა დაბრუნდეს Rust.
//! ეს ხდება `catchswitch` პლუს `catchpad` ინსტრუქციის საშუალებით LLVM IR ტერმინებით, საბოლოოდ კი პროგრამისთვის ნორმალური კონტროლის დაბრუნებისას `catchret` ინსტრუქციით.
//!
//! gcc- ზე დაფუძნებული გამონაკლისის დამუშავებისგან გარკვეული განსხვავებებია:
//!
//! * Rust არ აქვს ინდივიდუალური პიროვნების ფუნქცია, ის არის *ყოველთვის*`__CxxFrameHandler3`.გარდა ამისა, დამატებითი ფილტრაცია არ ხორციელდება, ასე რომ, ჩვენ საბოლოოდ ვიღებთ C++ გამონაკლისებს, რომლებიც ისე გამოიყურება, როგორც ჩვენ ისვრის.
//! გაითვალისწინეთ, რომ Rust- ში გამონაკლისის მიცემა განუსაზღვრელი ქცევაა, ასე რომ, ეს კარგად იქნება.
//! * ჩვენ გვაქვს გარკვეული მონაცემები გადასაცემად გადასაფარებლის საზღვარზე, კერძოდ `Box<dyn Any + Send>`.ჯუჯა გამონაკლისების მსგავსად, ეს ორი მაჩვენებელი ინახება როგორც დატვირთვა, გამონაკლისის გარდა.
//! ამასთან, MSVC- ზე არ არის საჭირო ზედმეტი გროვების გამოყოფა, რადგან ზარის დასტა დაცულია ფილტრის ფუნქციების შესრულების დროს.
//! ეს ნიშნავს, რომ მანიშნებლები გადაეცემა პირდაპირ `_CxxThrowException`- ს, რომლებიც შემდეგ აღდგება ფილტრის ფუნქციაში, რომელიც უნდა ჩაიწეროს `try` შინაგანი სტეკის ჩარჩოში.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // ეს უნდა იყოს ვარიანტი, რადგან გამონაკლისი მითითებით მიგვაჩნია და მისი გამანადგურებელი ხორციელდება C++ ხანგრძლივობით.
    // როდესაც გამონაკლისიდან ამოვიღებთ ყუთს, გამონაკლისი უნდა დავტოვოთ მოქმედ მდგომარეობაში, რომ მისი გამანადგურებელი მუშაობდეს ყუთის ორმაგად ჩამოშვების გარეშე.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// პირველ რიგში, ტიპის განმარტებების მთელი ჯგუფი.აქ არის რამდენიმე სპეციფიკური პლატფორმის უცნაურობა და ბევრი, რაც უბრალოდ უხეშად არის გადაწერილი LLVM- დან.ამ ყველაფრის დანიშნულებაა ქვემოთ მოყვანილი `panic` ფუნქციის განხორციელება `_CxxThrowException`-ზე ზარის საშუალებით.
//
// ამ ფუნქციას ორი არგუმენტი აქვს.პირველი არის მაჩვენებელი იმ მონაცემების, რომელსაც ჩვენ გადავცემთ, რაც ამ შემთხვევაში არის ჩვენი trait ობიექტი.საკმაოდ ადვილი მოსაძებნია!თუმცა შემდეგი უფრო რთულია.
// ეს არის `_ThrowInfo` სტრუქტურის მანიშნებელი და ის ძირითადად გამიზნულია მხოლოდ იმ გამონაკლისის აღსაწერად.
//
// ამჟამად ამ ტიპის [1] განმარტება ცოტათი ბეწვია და მთავარი უცნაურობა (და განსხვავება ონლაინ სტატიიდან) არის ის, რომ 32-ბიტიან მითითებებზე მითითებულია, მაგრამ 64-ბიტიანზე მითითებულია 32-ბიტიანი კომპენსაციისგან `__ImageBase` სიმბოლო.
//
// ამის გამოსახატავად გამოყენებულია `ptr_t` და `ptr!` მაკრო ქვემოთ მოცემულ მოდულებში.
//
// ტიპის განმარტებების ლაბირინთი ასევე ყურადღებით აკვირდება იმას, რასაც LLVM გამოყოფს ამგვარი ოპერაციისთვის.მაგალითად, თუ ამ C++ კოდს შეადგენთ MSVC- ზე და გამოყოფთ LLVM IR- ს:
//
//      #include <stdint.h>
//
//      ჟანგიანი_პანიკის სტრუქტურა {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      ბათილი foo() { rust_panic a = {0, 1};
//          გადაყარეთ a;}
//
// ეს არსებითად რის მიბაძვას ვცდილობთ.ქვემოთ მოცემული მუდმივი მნიშვნელობების უმეტესობა კოპირებულია LLVM- დან,
//
// ნებისმიერ შემთხვევაში, ეს სტრუქტურები ანალოგიურად არის აგებული და ეს ჩვენთვის გარკვეულწილად სიტყვიერია.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// გაითვალისწინეთ, რომ ჩვენ შეგნებულად ვიცავთ სახელის მანგლინგის წესებს: არ გვინდა C++ -ს Rust panics დაჭერის შესაძლებლობა უბრალოდ `struct rust_panic` დეკლარირებით.
//
//
// შეცვლისას დარწმუნდით, რომ ტიპის სახელის სტრიქონი ზუსტად ემთხვევა `compiler/rustc_codegen_llvm/src/intrinsic.rs`- ში გამოყენებულ სტრიქონს.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // წამყვანი `\x01` ბაიტი აქ არის ჯადოსნური სიგნალი LLVM- სთვის * არ გამოიყენოს სხვა მანგლინგი, როგორიცაა პრეფიქსი `_` სიმბოლოთი.
    //
    //
    // ეს სიმბოლო არის მაგიდა, რომელსაც იყენებს C++ ის `std::type_info`.
    // `std::type_info` ტიპის ობიექტებს, ტიპის აღმწერლებს აქვთ ამ ცხრილის მაჩვენებელი.
    // ტიპის აღმწერი მითითებულია C++ EH სტრუქტურებით, რომლებიც ზემოთ განისაზღვრება და რომელსაც ჩვენ ვაშენებთ ქვემოთ.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// ამ ტიპის აღწერილი მხოლოდ გამონაკლისის გამოყენებისას გამოიყენება.
// დაჭერის ნაწილს ამუშავებს try intrinsic, რომელიც ქმნის საკუთარ TypeDescriptor-ს.
//
// ეს კარგადაა, რადგან MSVC ხანგრძლივობა იყენებს სტრიქონების შედარებას ტიპის სახელზე, რათა შეესაბამებოდეს TypeDescriptors-ს და არა მაჩვენებლის ტოლობას.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// გამანადგურებელი გამოიყენება, თუ C++ კოდი გადაწყვეტს გამონაკლისის აღებას და ჩამოგდებას მისი გამრავლების გარეშე.
// სცადეთ intrinsic ნაწილის დაყენება გამონაკლისის ობიექტის პირველ სიტყვას 0-ზე ისე, რომ იგი გამოტოვდეს გამანადგურებელმა.
//
// გაითვალისწინეთ, რომ x86 Windows იყენებს "thiscall" დარეკვის კონვენციას C++ წევრის ფუნქციებისთვის, ნაგულისხმევი "C" დარეკვის კონვენციის ნაცვლად.
//
// Excence_copy ფუნქცია აქ ცოტა განსაკუთრებულია: იგი იძახება MSVC-ის დროს try/catch ბლოკის დროს და panic, რომელსაც ჩვენ ვაწარმოებთ, გამოყენებული იქნება გამონაკლისის ასლის შედეგად.
//
// ეს გამოიყენება C++ პერიოდის განმავლობაში, std::exception_ptr-ით გამონაკლისების აღების მხარდასაჭერად, რომელსაც ვერ ვუჭერთ მხარს, რადგან Box<dyn Any>არ არის კლონირებადი.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException ასრულებს მთლიანად ამ დასტის ჩარჩოზე, ასე რომ სხვაგვარად არ არის საჭირო `data` გროვაში გადატანა.
    // ჩვენ უბრალოდ ჩავრთავთ სტეკის მაჩვენებელს ამ ფუნქციას.
    //
    // ManualDrop აქ საჭიროა, რადგან არ გვინდა გამონაკლისი ამოღებულ იქნას განტვირთვისას.
    // ამის ნაცვლად, ის ჩამოიშლება გამონაკლისი_წმენდის საშუალებით, რომელსაც მიმართავს C++ ხანგრძლივობა.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // ეს ... შეიძლება გასაკვირი ჩანდეს და გამართლებულიც.32-ბიტიან MSVC-ზე ამ სტრუქტურას შორის მითითებულია მხოლოდ მითითებები.
    // 64-ბიტიან MSVC-ზე, სტრუქტურებს შორის მითითებები უფრო გამოხატულია, როგორც 32-ბიტიანი კომპენსაცია `__ImageBase`-დან.
    //
    // შესაბამისად, 32-ბიტიან MSVC- ზე შეგვიძლია განვაცხადოთ ყველა ეს მაჩვენებელი ზემოთ მოცემულ `სტატიკაში.
    // 64-ბიტიან MSVC- ზე ჩვენ უნდა გამოვხატოთ მაჩვენებლების გამოკლება სტატიკაში, რასაც Rust ამჟამად არ იძლევა, ამიტომ ამის რეალურად გაკეთება არ შეგვიძლია.
    //
    // შემდეგი საუკეთესო რამ, ამ დროს უნდა შეავსოთ ეს სტრუქტურები (პანიკა უკვე "slow path" არის).
    // ამრიგად, ჩვენ ყველა ამ მაჩვენებლის ველის ინტერპრეტაციას ვაკეთებთ, როგორც 32-ბიტიან მთელ რიცხვს და შემდეგ მასში ვინახავთ შესაბამის მნიშვნელობას (ატომურად, რადგან შეიძლება მიმდინარეობდეს panics ერთდროულად).
    //
    // ტექნიკურად ხანგრძლივობა, ალბათ, არაატომიურად წაიკითხავს ამ ველებს, მაგრამ თეორიულად ისინი არასოდეს კითხულობენ *არასწორ* მნიშვნელობას, ასე რომ არ უნდა იყოს ძალიან ცუდი ...
    //
    // ნებისმიერ შემთხვევაში, ძირითადად, ჩვენ მსგავსი რამის გაკეთება გვჭირდება მანამ, სანამ სტატიაში ვერ შევადგენთ უფრო მეტ ოპერაციებს (და შეიძლება ვერასდროს შევძლოთ).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL დატვირთვა აქ ნიშნავს, რომ ჩვენ აქ მივიღეთ __ ნდობის_განწყობის (...).
    // ეს ხდება მაშინ, როდესაც არა Rust უცხოური გამონაკლისი ხდება.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// შემდგენელი ამას მოითხოვს (მაგ., ეს არის ენა), მაგრამ მას სინამდვილეში მას არასოდეს უწოდებს, რადგან __C_specific_handler ან _except_handler3 არის პიროვნების ფუნქცია, რომელიც ყოველთვის გამოიყენება.
//
// ამრიგად, ეს მხოლოდ სტრიქონის შეწყვეტაა.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}