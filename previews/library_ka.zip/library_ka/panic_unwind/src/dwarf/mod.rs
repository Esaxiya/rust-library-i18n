//! კომუნალური საშუალებები DWARF-კოდირებული მონაცემთა ნაკადების ანალიზისთვის.
//! იხილეთ <http://www.dwarfstd.org>, DWARF-4 სტანდარტი, სექცია 7, "Data Representation"
//!

// ამ მოდულს ახლა იყენებს მხოლოდ x86_64-pc-windows-gnu, მაგრამ ჩვენ ყველგან ვადგენთ მას, რომ რეგრესიები არ ავიცილოთ.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF ნაკადები შეფუთულია, ასე რომ, მაგალითად, u32 სულაც არ იქნება გასწორებული 4 ბაიტიან საზღვარზე.
    // ამან შეიძლება გამოიწვიოს პრობლემები პლატფორმებზე გასწორების მკაცრი მოთხოვნებით.
    // მონაცემების "packed" სტრუქტურაში შეფუთვით, ჩვენ ვეუბნებით უკანა მხარეს "misalignment-safe" კოდის გამომუშავებას.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 და SLEB128 კოდირება განისაზღვრება სექციაში 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}