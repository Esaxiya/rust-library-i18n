//! იხსნება panics მირისთვის.
use alloc::boxed::Box;
use core::any::Any;

// დატვირთვის ტიპი, რომელსაც Miri ძრავა ავრცელებს ჩვენთვის განტვირთვის გზით.
// უნდა იყოს მაჩვენებლის ზომა.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// მირით გათვალისწინებული გარე ფუნქცია განტვირთვის დასაწყებად.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // დატვირთვა, რომელსაც ჩვენ `miri_start_panic`- ს გადავცემთ, იქნება ზუსტად ის არგუმენტი, რომელსაც მივიღებთ ქვემოთ მოცემულ `cleanup`- ში.
    // ასე რომ, ჩვენ მხოლოდ ერთხელ ვალაგებთ მას, რომ მივიღოთ საჩვენებელი ზომის.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // აღდგენა ძირითადი `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}