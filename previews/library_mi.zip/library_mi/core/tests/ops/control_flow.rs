use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Ehara tenei i te rohe pumau o te mata, engari he pai tonu te utu mo te `?` i waenga i a raatau, ahakoa kaore e taea e te LLVM te tango painga i tenei wa tonu.
    //
    // (He pouri te hua me te kowhiringa, no reira kaore e taea e te ControlFlow te taarua.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}