use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // He puhoi a Miri
fn exact_sanity_test() {
    // pito tenei whakamātau ake rere te mea anake e ahau e taea e amo ko etahi take kokonga-tangata o te mahi `exp2` whare pukapuka, tautuhia i roto i nga mea katoa C wāhaere e whakamahi tatou.
    // I roto i te VU 2013 āhua i tenei mahi he bug rite tenei whakamātautau kore ka hono, engari ki VU 2015 puta whakaritea te bug rite te whakamātautau rere tika pai.
    //
    // Ko te pepeke he rereke i te uara whakahoki o `exp2(-1057)`, ana i te VS 2013 ka hoki mai he taarua me te tauira moka 0x2 ana i te VS 2015 ka hoki mai a 0x20000.
    //
    //
    // inaianei hoki tau'a ore noa tenei whakamātautau katoa i runga i MSVC rite ngā whakamatauria reira wāhi kē ahakoa a kahore e tatou super paanga i roto i whakamatautau whakatinanatanga exp2 o ia pūhara.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}