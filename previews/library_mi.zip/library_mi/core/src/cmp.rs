//! Taumahinga mō te tono me te whakarite.
//!
//! Kei tenei waahanga nga momo taputapu mo te ota me te whakataurite i nga uara.Hei whakarāpopototanga:
//!
//! * [`Eq`] ko [`PartialEq`] He traits e tukua ki a koe te tautuhi taurite katoa, me te kanohi i waenganui i ngā uara, aua.
//! Ko te whakamahi i a raatau ka nui rawa atu nga kaiwhakahaere `==` me `!=`.
//! * [`Ord`] me te [`PartialOrd`] he traits e ahei ai koe ki te tautuhi i nga ota katoa me te waahanga o nga ota i waenga i nga uara.
//!
//! Whakatinana ratou overloads nga ngā `<`, `<=`, `>`, ko `>=`.
//! * [`Ordering`] Ko te tau e hoki mai e nga mahi matua o [`Ord`] ko [`PartialOrd`], ka whakamārama ana he tono.
//! * [`Reverse`] he hanganga e taea ai e koe te huri ke i to ota ota.
//! * [`max`] ko [`min`] He mahi e hanga atu o [`Ord`] me tukua ki a koutou te rapu i te mōrahi iti ranei o uara e rua.
//!
//! Mo etahi atu taipitopito, tirohia nga tuhinga o ia mea i te raarangi.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait mo nga whakataurite taurite he [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Tenei trait taea mo te taurite wāhanga, mō ngā momo e kore e e whai i te pā ana ōrite tonu.
/// Hei tauira, i roto i tere tau ira `NaN != NaN`, na momo māngi wāhi whakatinana `PartialEq` engari e kore e [`trait@Eq`].
///
/// Ōkawa, me kia te taurite (mo katoa `a`, `b`, `c` o momo `A`, `B`, `C`):
///
/// - **ā hangarite**: ki te `A: PartialEq<B>` ko `B: PartialEq<A>`, ka **`he==b` fakahu'unga` b==Haunui**;me
///
/// - **Whakawhiti**: mena he `A: PartialEq<B>` me `B: PartialEq<C>` me te `A:
///   PartialEq<C>`, Ka **` he b`==me `b == c` titau`he==c`**.
///
/// Note e kore e nga impls `B: PartialEq<A>` (symmetric) me `A: PartialEq<C>` (transitive) takoha ki te tīariari, engari te tono enei whakaritenga nga wa mahi ratou te tīari.
///
/// ## Derivable
///
/// Ka taea te whakamahi i tēnei trait ki `#[derive]`.A, no te `derive`d i runga i structs, e rua wā rite ki te he rite mara katoa, a kahore rite ki te kore e rite tetahi mara.A, no te 'ahu`d i runga i nga haehae, he rereke te rereke o ia momo ki a ia ano kaore e rite ki era atu momo rereke.
///
/// ## Me pehea taku whakatinana i te `PartialEq`?
///
/// `PartialEq` anake titau te tikanga [`eq`] ki kia whakatinana;Ko te [`ne`] kua tautuhia i runga i te tikanga taunoa.Ko nga whakamahinga-a-ringa o te [`ne`]*me* whakaute i te ture ko te [`eq`] he tino hurihuri o te [`ne`];e ko, `!(a == b)` ki a anake, ki te `a != b`.
///
/// Nga whakaritenga o `PartialEq`, [`PartialOrd`], me [`Ord`]*me* whakaae tetahi ki tetahi.E mea ohie ia aitua kia kore ratou e kimi i etahi o te traits me te whakatinana i ā ētahi atu.
///
/// He whakatinanatanga tauira mo te rohe i roto i nei e whakaaro pukapuka e rua i te pukapuka ano ki te ratou kēmu ISBN, ara, ki te rerekē te hōputu:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Me pehea taku whakataurite i nga momo rereke e rua?
///
/// Ko te momo e taea e koe whakarite ki te whakahaeretia e `o PartialEq` momo tawhā.
/// Hei tauira, kia paku ta taatau waehere o mua:
///
/// ```
/// // Nga mea mahi ahu<BookFormat>==<BookFormat>whakataurite
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Whakatinana<Book>==<BookFormat>mau faaauraa
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Whakatinana<BookFormat>==<Book>mau faaauraa
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Na roto i te huri `impl PartialEq for Book` ki `impl PartialEq<BookFormat> for Book`, tukua matou, BookFormat`s ki te whakaritea ki`Book`s.
///
/// Ko te whakataurite penei i runga ake nei, kaore e aro ki etahi waahi o te hanganga, he kino pea.Ka taea e ngāwari te reira i arahi ki te ofatiraa kāore i o nga whakaritenga mo te pā ana ōrite te kanohi.
/// Hei tauira, mena i puritia e tatou te whakamahi i runga ake nei o te `PartialEq<Book>` mo te `BookFormat` me te taapiri i te whakamahinga o te `PartialEq<Book>` mo te `Book` (ma te `#[derive]` ranei ma te whakamahi a-ringa mai i te tauira tuatahi) ka takahi te hua i te whakawhiti.
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Tenei whakamātautau tikanga mo `self` ko `other` uara ki te kia rite, me te whakamahia e `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Ko tenei tikanga ka whakamatautau mo te `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Ka ahu mai i te tonotono e hua ana i te trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait mō whakataurite taurite e he [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Tenei tikanga, e i roto i te tua ki `a == b` me `a != b` he inverses tino, me e te taurite (mo `a` katoa, `b` ko `c`):
///
/// - reflexive: `a == a`;
/// - hangarite: fakahu'unga `a == b` `b == a`;a
/// - whakawhiti: `a == b` me `b == c` e tohu ana i te `a == c`.
///
/// e kore e taea te takina tēnei taonga i te taupatupatu, me titau reira `Eq` [`PartialEq`], a kua kahore tikanga anō.
///
/// ## Derivable
///
/// Ka taea te whakamahi i tenei trait me `#[derive]`.
/// A, no te "ahu`d, na te mea kaore o `Eq` tikanga taapiri, ko te korero noa ki te kaitautu ko tenei te hononga taurite, kaua ki te whanaungatanga taurite.
///
/// Kia mahara e titau te rautaki `derive` mara katoa he `Eq`, e kore e nei hiahiatia tonu.
///
/// ## Me pehea taku whakatinana i te `Eq`?
///
/// Ki te kore koe e taea e te whakamahi i te rautaki `derive`, whakapūtā e koutou momo taputapu `Eq`, e kua kore tikanga:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // whakamahia tenei tikanga e anake e#[kimi] ki te whakapuaki e nga wāhanga o te momo taputapu#[kimi] ano, nga tikanga kimi i hanganga o nāianei mahi tenei whakapae, kahore te whakamahi i te tikanga i runga i tenei trait ko tata e taea.
    //
    //
    // kore kia whakatinana tenei i te ringa.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// tonotono ahu whakaputa he impl o te trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: ko tenei hanganga ka whakamahia noa e#[ahu mai] ki
// whakapuaki e nga wāhanga o te momo taputapu EQ.
//
// Kaua tenei hanganga e puta i te waehere kaiwhakamahi.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// He `Ordering` Ko te hua o te whakarite i waenganui i ngā uara e rua.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// He tikanga kei hea he iti iho i te tetahi he uara whakaritea.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// He tikanga i reira he rite ki tetahi atu te uara whakaritea.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// He ota e nui ake ana te uara whakataurite i era atu.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Whakahoki `true` mena ko te ota ko te `Equal` rereke.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Whakahokia `true` ki te e kore e he te ritenga te kē `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Whakahoki `true` mena ko te ota ko te `Less` rereke.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Whakahoki `true` mena ko te ota ko te `Greater` rereke.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Whakahoki `true` mena ko te ota ko te `Less` ko te `Equal` ranei.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Whakahokia `true` ki he rānei te ritenga te kē `Greater` `Equal` ranei.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Huri whakamuri te `Ordering`.
    ///
    /// * `Less` ka riro hei `Greater`.
    /// * `Greater` riro `Less`.
    /// * `Equal` ka riro hei `Equal`.
    ///
    /// # Examples
    ///
    /// Whanonga taketake:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Ka taea tenei tikanga ki te huri i te whakataurite:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // whakaritehia te raupapa mai i te rahi ki te iti.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Nga mekameka e rua nga ota.
    ///
    /// Returns `self` ka kore te reira `Equal`.Te kore hoki `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Nga mekameka te ota me te mahi kua tohaina.
    ///
    /// Returns `self` ka kore te reira `Equal`.
    /// Ki te kore ka waea atu ki te `f` ka whakahoki i te mutunga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// He hanganga awhina mo te tono whakamuri.
///
/// Tenei struct Ko te kaiawhina ki te kia whakamahia ki ngā mahi rite [`Vec::sort_by_key`] a taea te whakamahi ki te whakataka tikanga he wahi o te kī.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait mō ngā momo e hanga he [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Ko te ota he ota katoa mena (mo te `a` katoa, `b` me `c`):
///
/// - katoa me te hangarite: tino rite tetahi o `a < b`, `a == b` ko `a > b` he pono ranei;a
/// - whakawhiti, `a < b` me `b < c` e tohu ana i te `a < c`.Te mau roa taua mo e rua `==` me `>`.
///
/// ## Derivable
///
/// Ka taea te whakamahi i tenei trait me `#[derive]`.
/// A, no te `derive`d i runga i structs, ka hua te reira i te tono [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) i runga i te tikanga whakapuakanga runga-ki-raro o te mau melo o te struct.
///
/// A, no te 'ahu`d i runga i nga miihini, ka tohua nga rereketanga ma o raatau whakahau whakarakei runga-ki-raro.
///
/// ## Whakataurite kupu
///
/// Ko te whakataurite papakupu tetahi mahi me nga waahanga e whai ake nei:
///  - E whakaritea E rua raupapa huānga i te huānga.
///  - Ko te waahanga tuatahi kaore e taurite te tautuhi ko tehea raupapa he iti ake te papakupu, he rahi ake ranei i tetahi.
///  - Ki te ko te kotahi raupapa he kuhimua o tetahi, he lexicographically iti iho i te tahi atu te raupapa poto.
///  - Mena he ruarua nga huanga e rite ana te raupapa, he orite te roa, ko nga raupapa e taurite ana ki te papakupu.
///  - Ko lexicographically iti iho i tetahi raupapa kore-kau He raupapa kau.
///  - He lexicographically rite E rua ngā raupapa kau.
///
/// ## Me pehea taku whakatinana i te `Ord`?
///
/// `Ord` titau e hoki kia te momo [`PartialOrd`] me [`Eq`] (e titau [`PartialEq`]).
///
/// Na me te tautuhi koe i te whakatinanatanga mō [`cmp`].Akene he pai ki a koe te whakamahi i te [`cmp`] ki nga mara a to momo.
///
/// Nga whakaritenga o [`PartialEq`], [`PartialOrd`], me `Ord`*me* whakaae tetahi ki tetahi.
/// Ko te, `a.cmp(b) == Ordering::Equal` mena ka mena ko `a == b` me `Some(a.cmp(b)) == a.partial_cmp(b)` mo te `a` me te `b` katoa.
/// E mea ohie ia aitua kia kore ratou e kimi i etahi o te traits me te whakatinana i ā ētahi atu.
///
/// Tenei te he tauira te wahi e hiahia ana koe ki te kōmaka iwi i teitei anake, te tau'a ore `id` ko `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// hoki i tēnei aratuka he [`Ordering`] i waenganui `self` me `other`.
    ///
    /// Na te huihuinga, ka whakahokia mai e `self.cmp(&other)` te ota e taurite ana ki te kupu `self <operator> other` mena he pono.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Ka whakataurite ka whakahoki i te rahinga o nga uara e rua.
    ///
    /// Whakahoki ai i te tohenga tuarua mena ka whakatauhia e te whakataurite te orite.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Ka whakataurite ka whakahoki mai i te iti o nga uara e rua.
    ///
    /// Whakahoki ai i te tohenga tuatahi mena ka whakatauhia e te whakataurite te orite.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Whakawhāiti te uara ki tētahi wā.
    ///
    /// Whakahoki ai i te `max` mena he nui ake te `self` i te `max`, me te `min` mena he iti iho te `self` i te `min`.
    /// Ki te kore ka hoki mai tenei `self`.
    ///
    /// # Panics
    ///
    /// Panics ki te `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Ka ahu mai i te tonotono e hua ana i te trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait mo nga uara ka taea te whakarite mo te raupapa-a-momo.
///
/// Me makona te whakataurite, mo te `a`, `b` me te `c` katoa:
///
/// - hangarite: ki te `a < b` ka `!(a > b)`, me te `a > b` e kii ana `!(a < b)`;a
/// - whakawhiti: `a < b` me `b < c` e tohu ana i te `a < c`.Me rite tonu mo te `==` me te `>`.
///
/// Note e te tikanga o enei whakaritenga e me te whakatinana i te trait iho symmetrically me transitively: ki te `T: PartialOrd<U>` ko `U: PartialOrd<V>` ka `U: PartialOrd<T>` me `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Ka taea te whakamahi i tēnei trait ki `#[derive]`.A, no te `derive`d i runga i structs, ka hua te reira i te tono lexicographic i runga i te tikanga whakapuakanga runga-ki-raro o te mau melo o te struct.
/// A, no te 'ahu`d i runga i nga miihini, ka tohua nga rereketanga ma o raatau whakahau whakarakei runga-ki-raro.
///
/// ## Me pehea e taea te whakatinana i ahau `PartialOrd`?
///
/// `PartialOrd` me whakamahi noa te tikanga [`partial_cmp`], me era atu i hangaia mai i nga whakatinana taunoa.
///
/// Heoi ka taea tonu te whakamahi wehe i etahi atu mo nga momo kaore nei o raatau ota.
/// Hei tauira, mō te tere tau ira, `NaN < 0 == false` ko `NaN >= 0 == false` (cf.
/// IEEE 754-2008 waahanga 5.11).
///
/// `PartialOrd` me kii to momo [`PartialEq`].
///
/// whakaae implementations o [`PartialEq`], `PartialOrd`, a [`Ord`]*pau* ki ia atu.
/// E mea ohie ia aitua kia kore ratou e kimi i etahi o te traits me te whakatinana i ā ētahi atu.
///
/// Mena he [`Ord`] to momo, ka taea e koe te whakamahi i te [`partial_cmp`] ma te whakamahi i te [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// kia kitea hoki e koe reira pai ki te whakamahi i [`partial_cmp`] i runga i ngā āpure o tō momo.
/// Tenei ko te tauira o te momo `Person` e whai i te tere-ira `height` mara e he anake te parae ki te kia whakamahia mō te kōmaka:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Ma tenei tikanga e whakahoki te ota i waenga i nga uara `self` me `other` mena kei te kitea tetahi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Ki te kore e taea te whakarite:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Ko tenei tikanga ka iti ake i te (mo te `self` me te `other`) ka whakamahia e te kaiwhakahaere `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Tenei whakamātautau tikanga iti iho i te rite ranei ki (mo `self` ko `other`) me te whakamahia e te kaiwhakahaere `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// whakamatautau nui atu (mo `self` me `other`) tenei tikanga, me te e whakamahia e te kaiwhakahaere `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// whakamatautau nui tenei tikanga atu ranei rite ki (mo `self` ko `other`) me te whakamahia e te kaiwhakahaere `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// tonotono ahu whakaputa he impl o te trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Ka whakataurite ka whakahoki mai i te iti o nga uara e rua.
///
/// Whakahoki ai i te tohenga tuatahi mena ka whakatauhia e te whakataurite te orite.
///
/// Ka whakamahi a-roto i te ingoakapa ki te [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Whakahoki ai i te iti rawa o nga uara e rua mo te mahi whakarite kua whakaritea.
///
/// Whakahoki ai i te tohenga tuatahi mena ka whakatauhia e te whakataurite te orite.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Whakahoki ai i te waahanga e homai ana i te uara iti rawa mai i te mahi kua tohua.
///
/// Whakahoki ai i te tohenga tuatahi mena ka whakatauhia e te whakataurite te orite.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Ka whakataurite ka whakahoki i te rahinga o nga uara e rua.
///
/// Whakahoki ai i te tohenga tuarua mena ka whakatauhia e te whakataurite te orite.
///
/// Ka whakamahi a-roto i te ingoakapa ki te [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Whakahokia te mōrahi o ngā uara e rua ki te faatura ki te mahi whakarite whakaritea.
///
/// Whakahoki ai i te tohenga tuarua mena ka whakatauhia e te whakataurite te orite.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Whakahoki ai i te waahanga e homai ana i te uara nui mai i te mahinga kua tohua.
///
/// Whakahoki ai i te tohenga tuarua mena ka whakatauhia e te whakataurite te orite.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Te Whakatinana i te Wahanga Wae, Wha, Wahanga Whaa me te Ord mo nga momo tawhito
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Ko te ota i konei he mea nui kia nui ake ai te hui.
                    // Tirohia te <https://github.com/rust-lang/rust/issues/63758> mo etahi atu korero.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Maka atu ki te i8 o me te tahuri te rerekētanga ki te Whakaraupapa mahia atu tino pai whakaminenga.
            //
            // Tirohia te <https://github.com/rust-lang/rust/issues/66780> mo etahi atu korero.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // HAUMARU: bool rite i8 hoki 0 1 ranei, kia kore e taea e te rerekētanga hei tetahi atu
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &tohuohu

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}