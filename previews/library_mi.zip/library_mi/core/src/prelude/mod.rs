//! Ko te prelude whakaharahara
//!
//! Ko tenei waahanga ka whakaarohia mo nga kaiwhakamahi ohaoha kaore e hono atu ki te libstd.
//! kawemai ana tēnei kōwae e taunoa ka whakamahia `#![no_std]` te i roto i te taua tikanga rite prelude o te whare pukapuka paerewa.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Ko te 2015 putanga o te prelude matua.
///
/// Tirohia te [module-level documentation](self) mo etahi atu.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Ko te putanga 2018 o te prelude matua.
///
/// Tirohia te [module-level documentation](self) mo etahi atu.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Ko te putanga 2021 o te matua prelude.
///
/// Tirohia te [module-level documentation](self) mo etahi atu.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Taapirihia etahi atu mea.
}