#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Nga taputapu e pa ana ki nga hononga ke o te hononga (FFI) hononga.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Ōrite ki te momo `void` o C ka whakamahia rite te [pointer].
///
/// I roto i te ngako, he ōrite ki `const void *` o C `* const c_void` me he ōrite ki `void *` o C `* mut c_void`.
/// I kii, kaore tenei *kaore* i rite ki te momo whakahoki X a C's, ara ko te Rust's `()` momo.
///
/// Hei whakatauira atatohu ki ngā momo puatakore i FFI, ähuareka ra ano te `extern type`, e tūtohu ana ki te whakamahi i te Uwhi newtype a tawhio noa te ngohi paita kau.
///
/// Tirohia te [Nomicon] mo nga korero taipitopito.
///
/// i taea e tetahi te whakamahi i `std::os::raw::c_void` ki te hiahia ratou ki te tautoko i Rust taupatupatu ki raro tawhito ki 1.1.0.
/// I muri Rust 1.30.0, i anō kaweake-reira e tenei whakamāramatanga.
/// Mo etahi atu korero, panuihia te [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, hoki LLVM ki ite i te momo atatohu kau, me i mahi toronga rite malloc(), Me matou ki te whai kanohi reira rite * i8 i LLVM bitcode.
// Ko te tau e whakamahia konei whakarite tenei a noatia Haukarotia o te momo "raw" e he rerekē tūmataiti anake.
// Me tatou e rua rerekē, no te mea amuamu te taupatupatu e pā ana ki te huanga repr te kore me te hiahia tatou i te iti rawa kia kotahi kē rite te kore e kia nohoia te tau e, me i te iti rawa ingoakē taua atatohu e kia UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Te whakatinanatanga taketake o te `va_list`.
// Ko te ingoa ko te WIP, ma te whakamahi i te `VaListImpl` mo inaianei.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Kaihoko neke atu i te `'f`, na ko ia ahanoa `VaListImpl<'f>` ka herea ki te rohe o te mahinga kua tautuhia ki roto
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Te whakatinanatanga o te ABI o te `va_list`.
/// Tirohia te [AArch64 Procedure Call Standard] mo nga korero taipitopito.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Te whakatinanatanga o te ABI o te `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Te whakatinanatanga o te ABI o te `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// He takai mo te `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Tahuri i te `VaListImpl` ki te `VaList` e he-rua-hototahi ki `va_list` a C.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Tahuri i te `VaListImpl` ki te `VaList` e he-rua-hototahi ki `va_list` a C.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// Me te VaArgSafe trait ki te whakamahi i roto i atanga tūmatanui, Heoi, me kore e whakaaetia te trait ano ki te whakamahi i waho tenei kōwae.
// Whakaaea kaiwhakamahi ki te whakatinana i te trait mo te momo hou (reira tuku i te tūturu va_arg ki te whakamahi i runga i te momo hou) he pea ki te meinga te whanonga kāore.
//
// FIXME(dlrobertson): Hei whakamahi i te VaArgSafe trait i roto i te papaanga a te iwi engari me whakarite kia kore e taea te whakamahi i etahi atu waahi, me noho whanui te trait i roto i tetahi waahanga motuhake.
// Kua Kia RFC 2145 Kua whakatinanahia titiro ki te whakapai ake i tēnei.
//
//
//
//
mod sealed_trait {
    /// Trait e whakaae ana ki nga momo e whakaaetia ana kia whakamahia me te [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Kōkiri ki te arg muri.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Ka kape i te `va_list` i te waahi o naianei.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // HAUMARU: tuhituhi tatou ki te `MaybeUninit`, ko te kupu kua arawhitia reira me he ture `assume_init`
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: kia karanga tenei `va_end`, engari i reira te kahore ara ma ki
        // kī e tonu tangata inlined `drop` ki tona kaiwaea, kia pai te `va_end` kia huaina tika i te mahi taua rite te `va_copy` hāngai.
        // `man va_end` e kii ana ko tenei te mea e hiahiatia ana e C, ana ko te LLVM e whai ana i nga korero a C, no reira me maarama tonu ka karangahia a `va_end` mai i te mahi kotahi me te `va_copy`.
        //
        // Mo etahi atu taipitopito, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Ka mahi tenei mo tenei wa, na te mea `va_end` he kore-mahi mo nga whaainga LLVM katoa o tenei wa.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Whakangaromia te rarangi tautohe `ap` i muri i te arawhiti ki te `va_start` ko te `va_copy` ranei.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Tārua te wāhi o nāianei o arglist `src` ki te arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// He utaina to tautohe mo te momo `T` mai i te `va_list` `ap` me te whakanui ake i te tohenga `ap` tohu ki.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}