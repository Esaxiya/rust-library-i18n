//! Whakahaerehia te maumahara ma te tohu tohu noa.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! He maha nga mahi o tenei waahanga ka tohu tohu hei tautohe, ka panuihia, ka tuhi atu ranei ki a raatau.Kia pai ai tenei, he tika * enei tohu.
//! Mena he tika te tohu ki runga i te mahinga e whakamahia ana (panuihia te tuhi ranei), me te rahinga o te mahara e uru mai ana (ara, e hia nga paita te read/written).
//! Ko te nuinga o nga mahi e whakamahi ana i te `*mut T` me te `* const T` kia uru noa ki te uara kotahi, no reira ka kore te rahi o nga tuhinga ka kii he `size_of::<T>()` paita.
//!
//! Ko nga ture whaitake mo te whaitake kaore ano kia whakatauhia.Ko nga taurangi e tukuna ana i tenei wa he iti rawa:
//!
//! * Ko te atatohu [null] he *kore rawa* e tika, ahakoa mo te whakauru ki te [size zero][zst].
//! * Kia tika ai te tohu, he tika tonu, engari kaore i te wa katoa, kia *manakohia te tohu*: ko te rahinga mahara o te rahinga kua tohua mai i te tohu ka tohu katoa ki roto i nga rohe o tetahi mea tohaina.
//!
//! Kia mahara kei roto i te Rust, ko nga taurangi (stack-allocated) katoa e kiia ana he taonga wehe.
//! * Ahakoa mo nga mahi o [size zero][zst], kaua te tohu e tohu ki te whakamaharatanga kua whakawhitihia, arā, ko te whakawhitiwhitinga he kore noa nga tohu mo nga mahi kore-rahi.
//! Heoi, ko te maka i tetahi tau kore-kore *pono* ki tetahi tohu he tika mo nga urunga kore-rahi, ahakoa he mahara kei te noho tonu ki taua wahitau ka takahi.
//! E pa ana tenei ki te tuhi ki to kaitoha toha: ko te tohatoha i nga taonga kore-rahi ehara i te tino uaua.
//! Ko te huarahi canonical ki te tiki tohu e tika ana mo nga urunga kore-rahi he [`NonNull::dangling`].
//! * Ko nga urunga katoa e mahia ana i tenei waahanga ko te *kore ngota* i runga i te tikanga o [atomic operations] hei honohono i waenga i nga miro.
//! Ko te tikanga he whanonga kore ki te mahi i nga urunga waatea e rua ki te waahi kotahi mai i nga miro rereke mena ka uru mai nga uru e rua ma te maumahara.
//! Panui kei te tino whakaatu tenei i te [`read_volatile`] me te [`write_volatile`]: Kaore e taea te whakamahi i nga urunga tere ki te honohono-a-miro.
//! * Ko te hua o te tuku tohutoro ki te tohu he tika mo te mea e ora ana te mea e whai take ana, kaore hoki he tohutoro (he tohu noa nga tohu) ka uru ki nga mahara ano.
//!
//! Ko enei toki, me te whakamahi tupato i te [`offset`] mo te tohu tohu, he pai ki te whakamahi tika i nga mea whaihua ki te waehere kore haumaru.
//! Ko nga taurangi kaha ake ka tukuna i te mutunga, na te mea kua whakatauhia nga ture [aliasing].
//! Mo etahi atu korero, tirohia te [book] me te waahanga kei roto i te tohutoro kua whakatapua ki [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Ko nga tohu tohu tika e tautuhia ana i runga ake nei kaore i te aata tika (ki te waahanga "proper" e tautuhia ana e te momo tohu, ara, me uru te `*const T` ki te `mem::align_of::<T>()`).
//! Heoi, te nuinga o ngā mahi rapu ratou tohenga ki te kia tika hāngai, a ka āta kī tenei titauraa i roto i to ratou tuhinga.
//! Ko nga mea rereke mo tenei ko [`read_unaligned`] me [`write_unaligned`].
//!
//! Ka tika ana kia tika te mahi o tetahi mahi, ahakoa he rahi te urunga ki te uru 0, ara, ahakoa kaore i pa te mahara.A feruri i te whakamahi i [`NonNull::dangling`] i roto i ngā take pēnei i.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Ka whakahaere i te kaiwhakakahu (ki te mea) o te uara tohu-ki.
///
/// He rite tenei ki te kii i te [`ptr::read`] ka panga atu te otinga, engari ko nga painga e whai ake nei:
///
/// * E hiahiatia ana * kia whakamahia te `drop_in_place` ki te whakataka i nga momo rahinga penei i nga taonga trait, na te mea kaore e taea te panui ki te puranga ka heke noa iho.
///
/// * He pai ake ki te kaitautoko te mahi i tenei i runga i te [`ptr::read`] ka maturuturu ana i te whakamaharatanga o te ringa (hei tauira, i nga whakatinanatanga o `Box`/`Rc`/`Vec`), na te mea kaore e hiahiatia ana e te kaitoha te whakaatu he pai ki te tuku i te kape.
///
///
/// * Ka taea te whakamahi ki te maturuturu i nga raraunga [pinned] kaore te `T` i te `repr(packed)` (kaore e nekehia nga raraunga kua whakaitihia i mua i te panga o te waa).
///
/// Kaore e taea te tuku i nga uara kaore i te haangai ki te waahi, me kape ki tetahi waahi taangata ma te whakamahi i te [`ptr::read_unaligned`].Mo nga waahanga kikii, ko tenei nekehanga ka mahia noa e te kaiwhakaara.
/// Ko te tikanga ko nga maara o nga hikoi kikii kaore i te taka iho i te waahi.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `to_drop` me [valid] mo nga paanui e rua me te tuhi.
///
/// * `to_drop` Me tika kia hāngai.
///
/// * Ko te uara `to_drop` tohu kia tika mo te maturuturu, ko te tikanga me tautoko i etahi atu kaitono, he momo-ti'aturi tenei.
///
/// Hei taapiri, ki te kore ko `T` te [`Copy`], ma te whakamahi i te uara tohu-i muri i te karanga `drop_in_place` ka raru pea te whanonga kore.Kia mahara ko te `*to_drop = foo` e kiia ana he whakamahinga na te mea ka heke ano te uara.
/// [`write()`] ka taea te whakamahi ki te tuhirua raraunga me te kore e tuku kia heke iho.
///
/// Kia mahara ahakoa he rahi `0` te `T`, me tohu te tohu-kore-kore
///
/// [valid]: self#safety
///
/// # Examples
///
/// Tangohia-a-ringa te mea whakamutunga mai i te vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Tikina he tohu tika ki te waahanga whakamutunga o te `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Whakapotohia te `v` kia kore ai e taka te mea whakamutunga.
///     // Ko ta maatau mahi tuatahi, kia kore e raru nga take mena ka tae atu te `drop_in_place` ki raro o te panics.
///     v.set_len(1);
///     // Ki te kore he piiraa `drop_in_place`, kaore e tukuna te taonga whakamutunga, a, ka puta te maumahara e whakahaerehia ana.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Kia mahara kua makahia te mea whakamutunga.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Kia mahara kei te mahi aunoa te kaitautoko i te kape i nga waahanga kikii, ara, kaore koe i te awangawanga mo enei take mena ka waea a-ringa a `drop_in_place`.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Ko te waehere i konei kaore he aha, ka whakakapihia tenei ma te piripiri tino maturuturu na te kaiwhakaputu.
    //

    // SAFETY: tirohia nga korero i runga ake nei
    unsafe { drop_in_place(to_drop) }
}

/// Ka waihanga i tetahi tohu kore noa.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Ka waihanga i te tohu kore noa hei tohu.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Ko te whakamahinga a-ringa hei karo i te `T: Clone` ka herea.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Ko te whakamahinga a-ringa hei karo i te `T: Copy` ka herea.
impl<T> Copy for FatPtr<T> {}

/// Ka hangaia he poro mata mai i te tohu tohu me te roa.
///
/// Ko te tohenga `len` ko te maha o nga **huanga**, kaua ko te maha o nga paita.
///
/// He haumaru tenei mahi, engari ma te whakamahi i te uara whakahoki kaore i te haumaru.
/// Tirohia nga tuhinga o [`slice::from_raw_parts`] mo nga whakaritenga haumaru mo te waahanga.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // hangahia he tohu tohu mo te tiimata me te tohu ki te waahanga tuatahi
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SAFETY: Ko te urunga ki te uara mai i te uniana `Repr` he ahuru mai i te * const [T]
        //
        // me te FatPtr he rite nga whakatakotoranga mahara.Ko te std anake te mea ka taea te whakarite.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// He rite tonu te mahi ki te [`slice_from_raw_parts`], engari ko te waahanga panui e taea ana te whakahoki mai, he rereke ki te poro aarai kore e taea te huri.
///
///
/// Tirohia nga tuhinga o [`slice_from_raw_parts`] mo nga korero taipitopito.
///
/// He haumaru tenei mahi, engari ma te whakamahi i te uara whakahoki kaore i te haumaru.
/// Tirohia nga tuhinga o [`slice::from_raw_parts_mut`] mo nga whakaritenga haumaru mo te waahanga.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // tohua he uara ki te taurangi i te poro
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SAFETY: Ko te urunga ki te uara mai i te uniana `Repr` he ahuru mai i te * mut [T]
        // me te FatPtr he rite nga whakatakotoranga mahara
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Hurihia nga uara i nga waahi e rua ka taea te whakarereke o te momo kotahi, me te kore e whakakorehia te tikanga.
///
/// Engari mo nga waahanga e rua e whai ake nei, he rite te ahua o tenei mahi ki te [`mem::swap`]:
///
///
/// * Ka whakahaerehia i runga i nga tohu tohu hei utu mo nga tohutoro.
/// Ka waatea nga tohutoro, me manakohia te [`mem::swap`].
///
/// * Ko nga uara tohu-e rua nei ka noho pea.
/// Mena ka inaki nga uara, ka whakamahia te rohe inaki o te mahara mai i te `x`.
/// Ka whakaatuhia tenei i te tauira tuarua o raro.
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * Ko te `x` me te `y` me [valid] mo nga panui me te tuhi.
///
/// * Ko nga `x` me te `y` me tika te whakariterite.
///
/// Kia mahara mena he nui te `0` o te `T`, me tohu kore-tohu nga tohu.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Te huri i nga rohe kore-inaki:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // ko te `array[0..2]` tenei
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // ko te `array[2..4]` tenei
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Te huri i nga rohe e rua inaki:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // Ko `array[0..3]` tenei
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // ko te `array[1..4]` tenei
///
/// unsafe {
///     ptr::swap(x, y);
///     // Ko nga tohu `1..3` o te poroaki ka tuhonohono i waenga i te `x` me te `y`.
///     // Ko nga hua whaihua mo `[2, 3]`, na ko nga tohu `0..3` he `[1, 2, 3]` (he taurite `y` i mua o te `swap`);hei `[0, 1]` ranei maana ko nga tohu `1..4` he `[0, 1, 2]` (he rite ki te `x` i mua o te `swap`).
/////
///     // tautuhi ana tēnei whakatinanatanga te ki te hanga i te whiriwhiri muri.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Homai ki a maatau etahi waahi pakaru hei mahi ma maatau.
    // Kaore matou e manukanuka ki nga pata: Kaore he mahi a `MaybeUninit` i te wa ka taka iho.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Te mahi i te SAFETY Huri: me kī i te kaiwaea e he tika mō ngā tuhi, me te tika hāngai `x` me `y`.
    // `tmp` kaore e taea te inaki `x`, `y` ranei na te mea i tohaina noa te `tmp` ki runga i te puranga hei taonga wehewehe motuhake.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` me `y` ka inaki pea
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Hurihia nga paita `count * size_of::<T>()` i waenga i nga rohe whakamahara e rua ka tiimata mai i te `x` me te `y`.
/// Ko nga rohe e rua kaua * e whakaruaki.
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * Ko te `x` me te `y` me [valid] mo nga panui e rua me te tuhi mo te `tatau *
///   rahinga_o: :<T>() `paita.
///
/// * Ko nga `x` me te `y` me tika te whakariterite.
///
/// * Ko te rohe o te mahara timata i `x` ki te rahi o `tatau *
///   rahinga_o: :<T>() `Kaua nga paita *e kore* ka taapiri ki te rohe o te mahara ma te `y` e rite te rahi.
///
/// Kia mahara ahakoa te rahi o te kape kua taarua (`tatau * rahinga_o: :<T>()`) Ko `0`, me kia te atatohu kore i korengia-a tika tiaro.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SAFETY: me tohu te kaiwaea `x` me `y`
    // tika mō te tuhi, me te tika hāngai.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Mo nga momo iti ake i te arotautanga aukati i raro ake nei, whakawhiti tika kia kore e tarai ki te codegen.
    //
    if mem::size_of::<T>() < 32 {
        // SAFETY: me kii te kaikaranga he tika te `x` me te `y`
        // mo nga tuhi, he tika te whakariterite, me te kore-inaki.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Ko te huarahi ki konei ko te whakamahi i te simd ki te whakawhiti x&y kia pai.
    // Ko te whakamatau e whakaatu ana ko te huri i nga 32 paita, e 64 paita ranei i te wa kotahi, he pai ake mo nga tukatuka Intel Haswell E.
    // Ka taea e te LLVM te kaha ki te arotau mena ka whakawhiwhia he #[repr(simd)] ki a tatou, ahakoa kaore tatou e tino whakamahi tika i tenei.
    //
    //
    // FIXME repr(simd) pakaru i runga i te emscripten me te redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Koromeke i roto i x&y, te tārua ratou `Block` i te wa e unroll te mōhinuhinu te koropiko tino mo NB te nuinga o ngā momo
    // Kaore e taea e taatau te whakamahi i te koropiko kia rite ki te karanga a `range` impl `mem::swap` recursively
    //
    let mut i = 0;
    while i + block_size <= len {
        // Hangaia he whakamaharatanga koretake hei waahi mokowhiti Whakapuakihia te `t` i konei ka karo i te taatai i te puranga ka whakamahia ana tenei koropiko
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: I te `i < len`, ana ko te kaikaranga me tohu he tika te `x` me te `y`
        // mo te `len` paita, `x + i` me `y + i` me whai waahi tika, ka tutuki i te kirimana ahuru mo `add`.
        //
        // Ano hoki, me kii te kaikaranga he tika te `x` me te `y` mo nga tuhi, he pai te whakariterite, me te kore-inaki, e tutuki ai te kirimana ahuru mo te `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Whakawhitihia tetahi poraka paita o x&y, ma te whakamahi i te mea he takawaenga poto Me maatua tenei ki nga mahi SIMD whaihua ka watea ana
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Hurihia nga paita e toe ana
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // HAUMARU: kite kōrero haumaru o mua.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Nuku `src` ki te oka `dst`, e hoki ana i te uara `dst` mua.
///
/// Kaore ano kia heke te uara.
///
/// Ko tenei mahinga he rite ki te [`mem::replace`] engari ko te mea e whakahaerea ana i runga i nga tohu tohu kaore hei tohutoro.
/// Ka waatea nga tohutoro, me manakohia te [`mem::replace`].
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `dst` me [valid] mo nga paanui e rua me te tuhi.
///
/// * `dst` Me tika kia hāngai.
///
/// * `dst` me tohu ki te uara tuatahi o te momo `T`.
///
/// Kia mahara ahakoa he rahi `0` te `T`, me tohu te tohu-kore-kore
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` ka peera ano ka kore e hiahiatia te poraka haumaru.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SAFETY: me kii te kaikaranga he tika te `dst` hei
    // maka atu ki te tohutoro ka taea te whakarereke (he tika mo nga tuhi, he taatai, he tiimatanga), kaore e taea te whakakii i te `src` mai i te mea me tohu te `dst` ki tetahi taonga motuhake kua tohaina
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // kaore e taea te inaki
    }
    src
}

/// Ka panuihia te uara mai i `src` me te kore e nekehia.Ka waiho tenei i te maharatanga ki te `src` kaore i whakarereke.
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `src` me [valid] mo nga panui.
///
/// * `src` me tika te whakatika.Whakamahia te [`read_unaligned`] mena kaore tenei i te keehi.
///
/// * `src` me tohu ki te uara tuatahi o te momo `T`.
///
/// Kia mahara ahakoa he rahi `0` te `T`, me tohu te tohu-kore-kore
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Whakahaerehia te [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Hangaia he kape iti o te uara i te `a` i te `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ko te putanga i tenei waa (ma te hoki marama mai, ma te karanga ranei i tetahi mahi na panics) ka heke te uara o te `tmp` i te wa e tohua ana taua uara e `a`.
///         // Ma tenei ka whakaoho pea i nga whanonga kaore i tautuhia mena kaore te `T` i te `Copy`.
/////
/////
///
///         // Hangaia he kape iti o te uara i te `b` i te `a`.
///         // He haumaru tenei na te mea kaore e taea e nga tohutoro hurihuri.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Ka rite ki runga ake, putanga atu i konei i taea e tīmata whanonga kāore no tohutoro te uara taua e `a` me `b`.
/////
///
///         // Nekehia te `tmp` ki te `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` kua nekehia (`write` te mana o tana tohenga tuarua), no reira kaore he mea i taka ki konei.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Rangatira o te Uara Whakahoki
///
/// `read` hangaia he kape iti o `T`, ahakoa ko `T` te [`Copy`].
/// Mena ko `T` ehara i te [`Copy`], ma te whakamahi i te uara i whakahokia mai me te uara i te `*src` ka takahi i te ahuru o te maumahara.
/// Kia mahara ko te toha ki te `*src` ka kiia hei whakamahinga na te mea ka ngana ki te maturuturu i te uara i te `* src`.
///
/// [`write()`] ka taea te whakamahi ki te tuhirua raraunga me te kore e tuku kia heke iho.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` inaianei tohu ki te mahara pūtake taua rite `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Ko te toha atu ki te `s2` ka heke tona uara taketake.
///     // I tua atu i tenei, kaore e tika kia whakamahia te `s`, na te mea kua wetekina te mahara ake.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Ko te toha atu ki te `s` ka heke ano te uara tawhito, ka hua he whanonga kore.
/////
///     // s= String::from("bar");//HAPA
///
///     // `ptr::write` ka taea te whakamahi ki te tuhirua i te uara me te kore e makere iho.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: me kii te kaikaranga he tika te `src` mo nga panui.
    // `src` kaore e taea te taapiri i te `tmp` na te mea kua tohaina a `tmp` ki runga i te puranga hei taonga motuhake kua tohaina.
    //
    //
    // Ano, matou mai i tuhituhi noa i te uara tika ki `tmp`, kua kī taurangi te reira ki te kia tika arawhiti.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Ka panuihia te uara mai i `src` me te kore e nekehia.Ka waiho tenei i te maharatanga ki te `src` kaore i whakarereke.
///
/// Kaore i te [`read`], ka mahi a `read_unaligned` me nga tohu tohu kore.
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `src` me [valid] mo nga panui.
///
/// * `src` me tohu ki te uara tuatahi o te momo `T`.
///
/// Ka rite ki [`read`], ka hangaia e `read_unaligned` tetahi kape iti mo `T`, ahakoa ko `T` te [`Copy`].
/// Mena ko `T` ehara i te [`Copy`], ma te whakamahi i te uara i whakahokia mai me te uara i `*src` ka taea te [violate memory safety][read-ownership].
///
/// Kia mahara mena he nui te `0` o te `T`, me kore-kore te tohu.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## I nga mahinga `packed`
///
/// I tenei wa kaore e taea te hanga tohu maara ki nga mara kaore i te haangai mo te waahanga kikii.
///
/// E ngana ana ki te waihanga i tētahi atatohu raw ki te struct mara `unaligned` ki te faaiteraa pērā i `&packed.unaligned as *const FieldType` hanga he tohutoro unaligned takawaenga i mua i te tahuri taua ki te atatohu raw.
///
/// He poto noa tenei korero, a, ko te whakaari i tenei wa kaore he aha i te wa e hiahia ana te kaiwhakangungu kia tika te whakatika.
/// I te mutunga, ma te whakamahi i te `&packed.unaligned as *const FieldType` ka puta ake ai te* whanonga kore tautuhi * i roto i to papatono
///
/// Ko tetahi tauira o nga mea kaore e mahi ana me te paanga o tenei ki te `read_unaligned` ko:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // I konei ka tarai maatau ki te tango i te wahitau o te integer moka-32 e kore e hangai.
///     let unaligned =
///         // I hangaia he korero mo te wa poto kaore e haangai ana ka hua mai nga whanonga kaore ano kia tautuhia ahakoa te whakamahi o te tohutoro kaore ranei.
/////
///         &packed.unaligned
///         // Ko te maka ki te atatohu mata e kore e pai;kua pa ke te he.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Ko te whakaahei ki nga mara kore kua haangai ki te tauira `packed.unaligned` he ahuru engari.
///
///
///
///
///
///
// FIXME: Whakahōu tuhinga e hāngai ana i runga i putanga o RFC #2582 me hoa.
/// # Examples
///
/// Pānuitia te uara usize i te moka paita:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: me kii te kaikaranga he tika te `src` mo nga panui.
    // `src` kaore e taea te taapiri i te `tmp` na te mea kua tohaina a `tmp` ki runga i te puranga hei taonga motuhake kua tohaina.
    //
    //
    // Ano, matou mai i tuhituhi noa i te uara tika ki `tmp`, kua kī taurangi te reira ki te kia tika arawhiti.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Ka tuhirua i tetahi waahi maumahara me te uara kua whakaritea me te kore e panui, kia heke ranei te uara tawhito.
///
/// `write` kaore e tukuna nga korero o `dst`.
/// He ahuru tenei, engari tera pea ka tohatoha nga tohatoha rauemi ranei, no reira me tupato kaua e tuhirua i tetahi mea kia turakina.
///
///
/// Hei taapiri, kaore e taka te `src`.Hei tauira, `src` ka nekehia ki te waahi i tohua e `dst`.
///
/// He tika tenei hei arahi i te maaramatanga koretake, hei tuhirua mahara ranei kua [`read`] mai i mua.
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `dst` me [valid] mo nga tuhi.
///
/// * `dst` me tika te whakatika.Whakamahia te [`write_unaligned`] mena kaore tenei i te keehi.
///
/// Kia mahara ahakoa he rahi `0` te `T`, me tohu te tohu-kore-kore
///
/// [valid]: self#safety
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Whakahaerehia te [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Hangaia he kape iti o te uara i te `a` i te `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ko te putanga i tenei waa (ma te hoki marama mai, ma te karanga ranei i tetahi mahi na panics) ka heke te uara o te `tmp` i te wa e tohua ana taua uara e `a`.
///         // Ma tenei ka whakaoho pea i nga whanonga kaore i tautuhia mena kaore te `T` i te `Copy`.
/////
/////
///
///         // Hangaia he kape iti o te uara i te `b` i te `a`.
///         // He haumaru tenei na te mea kaore e taea e nga tohutoro hurihuri.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Ka rite ki runga ake, putanga atu i konei i taea e tīmata whanonga kāore no tohutoro te uara taua e `a` me `b`.
/////
///
///         // Nekehia te `tmp` ki te `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` kua nekehia (`write` te mana o tana tohenga tuarua), no reira kaore he mea i taka ki konei.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Kei te karanga tika maatau i nga mea tuuturu kia kaua e waea ki nga waeatanga mahi i te waehere i hangaia ma te mea ko te `intrinsics::copy_nonoverlapping` he mahi takai.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SAFETY: me kii te kaikaranga he tika te `dst` mo nga tuhi.
    // `dst` kaore e taea te taapiri i te `src` na te mea ka taea te piira te uru atu ki te `dst` i te mea ko `src` tenei mahi.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Ka tuhirua i tetahi waahi maumahara me te uara kua whakaritea me te kore e panui, kia heke ranei te uara tawhito.
///
/// Kaore i rite ki te [`write()`], kaore pea te tohu o te tohu i tohu.
///
/// `write_unaligned` kaore e tukuna nga korero o `dst`.Ko tenei haumaru, engari i taea turuturu reira tohatoha rauemi ranei, kia kia tiaki kia tangohia e kore ki te tuhirua i te ahanoa e kia kia maturuturu iho.
///
/// Hei taapiri, kaore e taka te `src`.Hei tauira, `src` ka nekehia ki te waahi i tohua e `dst`.
///
/// He tika tenei hei arahi i te maaramatanga koretake, hei tuhirua ranei i te mahara kua panuihia i mua me te [`read_unaligned`].
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `dst` me [valid] mo nga tuhi.
///
/// Kia mahara mena he nui te `0` o te `T`, me kore-kore te tohu.
///
/// [valid]: self#safety
///
/// ## I nga mahinga `packed`
///
/// I tenei wa kaore e taea te hanga tohu maara ki nga mara kaore i te haangai mo te waahanga kikii.
///
/// E ngana ana ki te waihanga i tētahi atatohu raw ki te struct mara `unaligned` ki te faaiteraa pērā i `&packed.unaligned as *const FieldType` hanga he tohutoro unaligned takawaenga i mua i te tahuri taua ki te atatohu raw.
///
/// He poto noa tenei korero, a, ko te whakaari i tenei wa kaore he aha i te wa e hiahia ana te kaiwhakangungu kia tika te whakatika.
/// I te mutunga, ma te whakamahi i te `&packed.unaligned as *const FieldType` ka puta ake ai te* whanonga kore tautuhi * i roto i to papatono
///
/// Ko tetahi tauira o nga mea kaore e mahi ana me te paanga o tenei ki te `write_unaligned` ko:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // I konei ka tarai maatau ki te tango i te wahitau o te integer moka-32 e kore e hangai.
///     let unaligned =
///         // I hangaia he korero mo te wa poto kaore e haangai ana ka hua mai nga whanonga kaore ano kia tautuhia ahakoa te whakamahi o te tohutoro kaore ranei.
/////
///         &mut packed.unaligned
///         // Ko te maka ki te atatohu mata e kore e pai;kua pa ke te he.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Ko te whakaahei ki nga mara kore kua haangai ki te tauira `packed.unaligned` he ahuru engari.
///
///
///
///
///
///
///
///
///
// FIXME: Whakahōu tuhinga e hāngai ana i runga i putanga o RFC #2582 me hoa.
/// # Examples
///
/// Tuhia he uara whakamahi ki te pararau paita:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SAFETY: me kii te kaikaranga he tika te `dst` mo nga tuhi.
    // `dst` kaore e taea te taapiri i te `src` na te mea ka taea te piira te uru atu ki te `dst` i te mea ko `src` tenei mahi.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Kei te karanga tika maatau i nga kaupapa o roto kia kore e waea ki nga waeatanga mahi i te waehere kua hangaia.
        intrinsics::forget(src);
    }
}

/// Ka mahi i te panui rerekee o te uara mai i te `src` me te kore e nekehia.Tenei rau te mahara i roto i `src` tonu.
///
/// Ko nga mahi koretake te tikanga ki te mahi i runga i te mahara I/O, ana ka tutuki kia kore e tukuna kia whakahoutia, kia whakatauhia ranei e te kaitautoko puta noa i etahi atu mahi ngawari.
///
/// # Notes
///
/// e kore e whai i tēnei wā Rust he tauira mahara tōtikatia a ōkawa tautuhi, na nga semantics pau o te mea "volatile" tikanga konei he kaupapa ki te huringa i runga i te wā.
/// Ko te mea, ka mutu tata tonu nga semantics ake tino rite ki [C11's definition of volatile][c11].
///
/// Kaua te kaiwhakangungu e whakarereke i te raupapa whanaunga, i te maha ranei o nga mahi whakamahara koretake.
/// Heoi, ko nga mahi whakamaumahara ohorere i runga i nga momo kore-rahi (hei tauira, mena ka tukuna he momo kore-rahi ki te `read_volatile`) ka tutakina a kaore pea e aro.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `src` me [valid] mo nga panui.
///
/// * `src` Me tika kia hāngai.
///
/// * `src` me tohu ki te uara tuatahi o te momo `T`.
///
/// Ka rite ki [`read`], ka hangaia e `read_volatile` tetahi kape iti mo `T`, ahakoa ko `T` te [`Copy`].
/// Mena ko `T` ehara i te [`Copy`], ma te whakamahi i te uara i whakahokia mai me te uara i `*src` ka taea te [violate memory safety][read-ownership].
/// Heoi, ko te penapena i nga momo ["Tārua`] i roto i te maharatanga ngawari kaore pea i te he.
///
/// Kia mahara ahakoa he rahi `0` te `T`, me tohu te tohu-kore-kore
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Ka rite tonu ki te C, mena he rerekee te mahi kaore he kaupapa mo nga paatai e uru ana ki nga aho maha.whai ahua whakahihi rite rite whai kore-ngota i roto i taua whakaaro.
///
/// Ina koa, ko te reihi i waenga i te `read_volatile` me tetahi tuhinga tuhi ki te waahi kotahi he whanonga kore.
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Kaore i te awangawanga kia iti ake te pa o te codegen.
        abort();
    }
    // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Ka mahi i tetahi tuhi ngawari mo tetahi waahi maumahara me te uara kua whakaritea me te kore e paanui, ka taka ranei te uara tawhito.
///
/// Ko nga mahi koretake te tikanga ki te mahi i runga i te mahara I/O, ana ka tutuki kia kore e tukuna kia whakahoutia, kia whakatauhia ranei e te kaitautoko puta noa i etahi atu mahi ngawari.
///
/// `write_volatile` kaore e tukuna nga korero o `dst`.Ko tenei haumaru, engari i taea turuturu reira tohatoha rauemi ranei, kia kia tiaki kia tangohia e kore ki te tuhirua i te ahanoa e kia kia maturuturu iho.
///
/// Hei taapiri, kaore e taka te `src`.Hei tauira, `src` ka nekehia ki te waahi i tohua e `dst`.
///
/// # Notes
///
/// e kore e whai i tēnei wā Rust he tauira mahara tōtikatia a ōkawa tautuhi, na nga semantics pau o te mea "volatile" tikanga konei he kaupapa ki te huringa i runga i te wā.
/// Ko te mea, ka mutu tata tonu nga semantics ake tino rite ki [C11's definition of volatile][c11].
///
/// Kaua te kaiwhakangungu e whakarereke i te raupapa whanaunga, i te maha ranei o nga mahi whakamahara koretake.
/// Heoi, ko nga mahi whakamaumahara ohorere i runga i nga momo kore-rahi (hei tauira, mena ka tukuna he momo kore-rahi ki te `write_volatile`) ka tutakina a kaore pea e aro.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `dst` me [valid] mo nga tuhi.
///
/// * `dst` Me tika kia hāngai.
///
/// Kia mahara ahakoa he rahi `0` te `T`, me tohu te tohu-kore-kore
///
/// [valid]: self#safety
///
/// Ka rite tonu ki te C, mena he rerekee te mahi kaore he kaupapa mo nga paatai e uru ana ki nga aho maha.whai ahua whakahihi rite rite whai kore-ngota i roto i taua whakaaro.
///
/// Ina koa, ko te reihi i waenga i te `write_volatile` me etahi atu mahinga (panui, tuhi ranei) i runga i te waahi kotahi he whanonga kore.
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Kaore i te awangawanga kia iti ake te pa o te codegen.
        abort();
    }
    // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Tiangihia te atatohu `p`.
///
/// Tatau taurite (i runga i nga waahanga o te hikoi `stride`) me tono ki te tohu `p` kia pai ai te tohu a te `p` ki te `a`.
///
/// Note: Ko tenei whakatinanatanga kua ata whakaritea kia kaua e panic.Ko te UB mo tenei ki te panic.
/// Kotahi noa te panoni ka taea te hanga i konei ko te panoni o te `INV_TABLE_MOD_16` me nga tikanga e hono ana.
///
/// Mena ka whakatau taatau kia taea te karanga i te ao tuuturu me te `a` ehara i te mea mana-rua, tera pea ka tupato ki te huri noa ki te whakatinanatanga naive tena ki te tarai ki te urutau i tenei kia ea ai te panoni.
///
///
/// Ka haere nga patai ki@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Ma te whakamahi tika i enei mahi whakahiki ka whakapai ake i te codegen i te taumata taumata <=
    // 1, kei hea nga whakaaturanga tikanga o enei mahi kaore e raarangi.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Tatau porowhita takirua takahuri o te `x` modulo `m`.
    ///
    /// whakahāngaitia ana tēnei whakatinanatanga te hoki `align_offset` me kua whai preconditions:
    ///
    /// * `m` he mana-o-rua;
    /// * `x < m`; (mena `x ≥ m`, paahitia `x % m`)
    ///
    /// ka kore whakatinanatanga o tenei mahi panic.Ake.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Whakatauira modular ripanga takahuri modulo 2⁴=16.
        ///
        /// Kia mahara, kaore tenei teepu i roto i nga uara kaore he huriwhare (ara, mo `0⁻¹ mod 16`, `2⁻¹ mod 16`, me etahi atu.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo e hiahiatia ana te `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SAFETY: Ko te `m` e hiahiatia ana hei mana-o-rua, no reira kaore he-kore.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // tukurua matou "up" te whakamahi i te tātai e whai ake nei:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // tae atu ki te 2²ⁿ ≥ m.Na ka taea e taatau te whakaheke i to `m` e hiahiatia ana ma te tango i te hua `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) n mod
                //
                // Kia mahara, kei te whakamahi maatau i nga mahi takai ki konei-ko te tauira taketake hei tauira, ko te tangohanga `mod n`.
                // He pai noa atu te mahi `mod usize::MAX`, na te mea ko te hua ke o te `mod n` i te mutunga.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAFETY: Ko te `a` he mana-o-rua, no reira kaore he-kore.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` te keehi ka taea te tatau ma te `-p (mod a)` noa iho, engari ma te pera ka aukati i te kaha o LLVM ki te kowhiri i nga tohutohu penei i te `lea`.Engari me tatau e maatau
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // e tohatoha ngā mahi huri noa i te utanga-whanau, engari pessimizing `and` feunga mo ki LLVM e taea ki te whakamahi i te ngā optimizations matau reira e pā ana ki.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Kua ea.Aue!
        return 0;
    } else if stride == 0 {
        // Mena kaore i te whakaatuhia te tohu, a he kore-rahi te waahanga, kaore rawa he waahanga o nga waahanga e tautuhi i te tohu.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SAFETY: a he mana-o-rua no reira kaore he-kore.stride==0 te keehi kei runga i runga ake nei.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SAFETY: Kei te gcdpow tetahi rohe o runga rawa atu te maha o nga paraire i roto i te whakamahi.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SAFETY: ko te gcd he nui ake, he rite ranei ki te 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Ko tenei branch e whakatau ana mo nga wharite honohono raina e whai ake nei:
        //
        // ` p + so = 0 mod a `
        //
        // `p` anei te uara tohu, `s`, hikoi o `T`, `o` whakahekehia i roto i te `T`s, me `a`, te whakaurunga e tonoa ana.
        //
        // Ma te `g = gcd(a, s)`, me nga korero i runga ake nei e kii ana ko `p` ka wehehia e `g`, ka taea e taatau te tohu `a' = a/g`, `s' = s/g`, `p' = p/g`, na ka rite tenei ki:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Ko te kupu tuatahi ko te "the relative alignment of `p` to `a`" (ka wehea e te `g`), ko te waa tuarua ko te "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (ka tohaina ano e `g`).
        //
        // Ko te wehenga ma te `g` e tika ana kia pai te poka ke o te `a` me te `s` kaore i te mahi tahi.
        //
        // Ano hoki, ko te hua i puta i tenei otinga ehara i te "minimal", no reira me mau ki te hua `o mod lcm(s, a)`.Ka taea e taatau te whakakapi i te `lcm(s, a)` me te `a'` noa.
        //
        //
        //
        //
        //

        // SAFETY: Ko te `gcdpow` he taunga-teitei kaore e rahi ake i te maha o nga waahanga 0-bit i te `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SAFETY: `a2` he kore-kore.Ko te neke i te `a` na `gcdpow` kaore e taea te neke i nga waahanga kua whakaritea
        // i te `a` (he kotahi te mea kotahi).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SAFETY: Ko te `gcdpow` he taunga-teitei kaore e rahi ake i te maha o nga waahanga 0-bit i te `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SAFETY: Ko te `gcdpow` he taunga-teitei kaore e rahi ake i te maha o nga waahanga 0-paraire kei roto
        // `a`.
        // Ano hoki, kaore e taea te tango i te tangohanga, na te mea ka nui ake te `a2 = a >> gcdpow` i te `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SAFETY: Ko te `a2` he mana-o-rua, kua oti te whakaatu i runga ake nei.Ko te `s2` he iti ake i te `a2`
        // na te mea `(s % a) >> gcdpow` he tino iti iho i te `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Kaore e taea te hono.
    usize::MAX
}

/// Whakatairite ai i nga tohu tohu mo te taurite.
///
/// He rite tenei ki te whakamahi i te `==` kaiwhakahaere, engari he iti ake te whanui:
/// nga tohenga i ki kia `*const T` atatohu raw, e kore tetahi mea e ngā `PartialEq`.
///
/// Ka taea te whakamahi ki te whakataurite i nga tohutoro `&T` (e akiaki ana ki te `*const T` tino) na roto i ta raatau wahitau kaore i te whakataurite i nga uara e tohu ana (koinei te mahi a te `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Ka whakatauritea nga poro ki o raatau roa (tohu momona):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Ko te Traits ka whakatauritea e ta raatau whakamahinga:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Atatohu whai wāhitau rite.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // He rite nga wahitau o nga ahanoa, engari he rereke te whakamahinga a te `Trait`.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Ko te huri i te tohutoro ki te `*const u8` ka whakataurite ma te wahitau.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Tohua he tohu tika.
///
/// Ka taea te whakamahi i tēnei ki te Hash te tohutoro `&T` (e coerces ki `*const T` kakato) e tona wāhitau, nui atu i te uara tohu reira ki (i te mea he aha te whakatinanatanga `Hash for &T` e).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Ka whakamahia mo nga tohu tohu mahi
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Ko te kaiwhakaari takawaenga hei whakamahi i te usize e hiahiatia ana mo te AVR
                // kia tiakina ai te waahi nohoanga o te mahi tohu tohu ki te tohu mahi whakamutunga.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Ko te kaiwhakaari takawaenga hei whakamahi i te usize e hiahiatia ana mo te AVR
                // kia tiakina ai te waahi nohoanga o te mahi tohu tohu ki te tohu mahi whakamutunga.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Kaore he mahi rereke me te 0 taapiri
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Hangaia he tohu atawhai `const` ki tetahi waahi, me te kore e hanga i tetahi tohutoro waenga.
///
/// Ko te hanga i tetahi tohutoro me te `&`/`&mut` ka whakaaetia mena ka tika te tohu o te tohu me te tohu ki nga raraunga tuatahi.
/// Mo nga keehi kaore e mau aua whakaritenga, me whakamahi noa nga tohu tohu kore.
/// Heoi, ka waihangahia e `&expr as *const _` tetahi korero i mua i te maka ki tetahi tohu tika, a ko taua tohutoro he ture ano ki etahi atu tohutoro katoa.
///
/// Ka taea e tenei tonotono te hanga i tetahi tohu kore * me te kore e hanga i tetahi tohutoro i te tuatahi.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` ka waihanga i tetahi tohutoro kaore i te haangai, na reira ka Whanonga Kare i Tautuhia!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Hangaia he tohu atawhai `mut` ki tetahi waahi, me te kore e hanga i tetahi tohutoro waenga.
///
/// Ko te hanga i tetahi tohutoro me te `&`/`&mut` ka whakaaetia mena ka tika te tohu o te tohu me te tohu ki nga raraunga tuatahi.
/// Mo nga keehi kaore e mau aua whakaritenga, me whakamahi noa nga tohu tohu kore.
/// Heoi, ka waihangahia e `&mut expr as *mut _` tetahi korero i mua i te maka ki tetahi tohu tika, a ko taua tohutoro he ture ano ki etahi atu tohutoro katoa.
///
/// Ka taea e tenei tonotono te hanga i tetahi tohu kore * me te kore e hanga i tetahi tohutoro i te tuatahi.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` ka waihanga i tetahi tohutoro kaore i te haangai, na reira ka Whanonga Kare i Tautuhia!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` kaha ki te kape i te mara kaua ki te hanga tohutoro.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}