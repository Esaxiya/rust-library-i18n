use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// He Uwhi huri noa te raw whakakahore-kore `*mut T` e tohu e te nona nei o tenei Uwhi nona te referent.
/// He pai mo te hanga tangohanga penei i te `Box<T>`, `Vec<T>`, `String`, me `HashMap<K, V>`.
///
/// Kaore i rite ki te `*mut T`, ko te `Unique<T>` he "as if" te ahua he `T`.
/// Ka whakamahia te `Send`/`Sync` mena ko `T` te `Send`/`Sync`.
/// Kei te kii hoki ko te ahua o te whakaingoa kaha e kii ana ko `T` te ahua:
/// te kaiwhakauru o te atatohu kaua e whakarereke me te kore he huarahi motuhake hei pupuri i te ahurei.
///
/// Ki te kei pahuhu o ahakoa te reira tika ki te whakamahi i `Unique` mo koutou take koutou, whakaaro te whakamahi i `NonNull`, e kua semantics ngoikore.
///
///
/// Kaore i te ahua o `*mut T`, me tohu tonu te tohu, ahakoa kaore i te whakahekehia te tohu.
/// Ma tenei ka taea ai e nga miihini te whakamahi i tenei uara aukati hei whakahianga-He rite te rahi o te `Option<Unique<T>>` ki te `Unique<T>`.
/// Heoi ka piirangi tonu pea te tohu ki te kore e tukuna.
///
/// Kaore i rite ki te `*mut T`, ko te `Unique<T>` he kotahitanga mo te `T`.
/// He tika tonu tenei ma nga momo katoa e tautoko ana i nga whakaritenga whakarae a Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: e tenei tohu kahore nunu'a mo whawhai, engari he tika
    // kia maarama ai te topetope kei a tatou ano te `T`.
    //
    // Mo nga taipitopito, tirohia:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` nga tohu ki te `Send` mena ko `T` te `Send` na te mea kaore nga tuhinga e tohua ana e ratou.
/// Kia mahara ko tenei kaitautoko whakakeke kaore i te whakatutukihia e te punaha momo;ko te tangohanga ma te whakamahi i te `Unique` me whakamana.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` nga tohu ki te `Sync` mena ko `T` te `Sync` na te mea kaore nga tuhinga e tohua ana e ratou.
/// Kia mahara ko tenei kaitautoko whakakeke kaore i te whakatutukihia e te punaha momo;ko te tangohanga ma te whakamahi i te `Unique` me whakamana.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Ka hangaia he `Unique` hou e piirangi ana, engari he pai te whakariterite.
    ///
    /// He pai tenei hei arahi i nga momo ka mangere ka tohaina, penei i te `Vec::new`.
    ///
    /// Kia mahara ko te uara tohu ka tohu pea i tetahi tohu tohu ki te `T`, ko te tikanga kaua e whakamahia hei uara sentiel "not yet initialized".
    /// Ko nga momo e toha mangere ana me whai i te arawhiti ki etahi atu huarahi.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: Ka whakahokia mai e mem::align_of() tetahi tohu tika, kore-kore.Ko te
        // ko nga tikanga hei karanga i te new_unchecked() e penei ana te whakaute.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Ka hangaia he `Unique` hou.
    ///
    /// # Safety
    ///
    /// `ptr` me kore-kore.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: me kii e te kaiwaea ko `ptr` kaore i te kore.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Ka hangaia he `Unique` hou mena he kore-kore te `ptr`.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: Kua oti te tohu i te tohu me te kore e kore.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Whiwhi ai i te atatohu `*mut` e whaaia ana.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Whakakorea nga korero.
    ///
    /// Ko te wa e ora ana ka herea ki a ia ano na te mea tenei "as if" he ahuatanga no te T kei te tono nama.
    /// Ki te hiahiatia he ora (unbound) roa te, te whakamahi i `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: me tohu te kaiwaea kua tutaki a `self` ki nga mea katoa
        // whakaritenga mo te tohutoro.
        unsafe { &*self.as_ptr() }
    }

    /// Mutably dereferences te ihirangi.
    ///
    /// Ko te wa e ora ana ka herea ki a ia ano na te mea tenei "as if" he ahuatanga no te T kei te tono nama.
    /// Mena he roa te roa o te (unbound) e hiahiatia ana, whakamahia `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: me tohu te kaiwaea kua tutaki a `self` ki nga mea katoa
        // whakaritenga mo te tohutoro mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// Ka tohua ki te tohu o tetahi atu momo.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SAFETY: Ka hangaia e Unique::new_unchecked() tetahi ahurei hou me nga hiahia
        // te atatohu homai ki kore e whakakahore.
        // I te mea e haere ana matou ano he tohu, kaore e kore ka taea.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: Ko te tohutoro ka taea te whakakore
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}