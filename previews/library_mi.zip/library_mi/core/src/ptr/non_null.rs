use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` engari kore-kore me te kawhena.
///
/// Koinei tonu te mea tika hei whakamahi i te hanga hanganga raraunga ma te tohu tohu noa, engari ko te mutunga he morearea rawa atu te whakamahi na te mea he taonga taapiri.Mena kaore koe e tino mohio mena ka whakamahi koe i te `NonNull<T>`, whakamahia noa te `*mut T`!
///
/// Kaore i te ahua ki te `*mut T`, me tohu tonu te tohu, ahakoa kaore i te whakahekehia te tohu.Ko te pera tenei kia whakamahi i enums tenei uara riria rite te discriminant-kua te rahi taua rite `* mut T` `Option<NonNull<T>>`.
/// Heoi ka piirangi tonu pea te tohu ki te kore e tukuna.
///
/// Kaore i rite ki te `*mut T`, I kowhiria a `NonNull<T>` hei kaimanaaki mo te `T`.Ma tenei ka taea te whakamahi i te `NonNull<T>` i te wa e hangaia ana nga momo covariant, engari ka whakaatu i te tuponotanga o te kore ohorere mena ka whakamahia i roto i tetahi momo kaore e tino mohio.
/// (Ko te waahanga ke i hangaia mo `*mut T` ahakoa ko te hangarau noa ko te kore ohorere ka hua mai ma te karanga he mahi kore.)
///
/// He tika te mahi tirotiro mo te nuinga o nga tangohanga haumaru, penei i te `Box`, `Rc`, `Arc`, `Vec`, me `LinkedList`.Koinei te take na te mea i whakawhiwhia e raatau he API a te iwi whanui e whai ana i nga tikanga XOR huri noa o Rust.
///
/// Mena kaore e taea e to momo te noho humarie, me matua whakarite kia nui atu nga waahanga hei whakawhiwhi mahi.I te nuinga o nga wa ko tenei mara he momo [`PhantomData`] penei i te `PhantomData<Cell<T>>` ko te `PhantomData<&'a mut T>` ranei.
///
/// Panui kei te `NonNull<T>` he tauira `From` mo `&T`.Heoi, kaore tenei e whakarereke i te meka ko te whakarereke i tetahi (tohu i ahu mai i te) tohutoro tiritahi he whanonga kore ki te kore e puta te rereketanga i roto i te [`UnsafeCell<T>`].Ko te taua haere hoki te hanga he tohutoro mutable i te tohutoro ngā.
///
/// A, no te whakamahi i tenei tauira `From` kaore he `UnsafeCell<T>`, ko to kawenga ki te whakarite kia kore e karangahia te `as_mut`, a kaore hoki a `as_ptr` e whakamahia mo te whakarereke.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ko nga tohu tohu ehara i te `Send` na te mea ko nga raraunga e tohua ana e ratou kua whakahuatia.
// NB, kaore he take o tenei, engari me pai ake te tuku i nga karere hapa.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ko nga tohu tohu ehara i te `Sync` na te mea ko nga raraunga e tohua ana e ratou kua whakahuatia.
// NB, kaore he take o tenei, engari me pai ake te tuku i nga karere hapa.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Ka hangaia he `NonNull` hou e piirangi ana, engari he pai te whakariterite.
    ///
    /// He pai tenei hei arahi i nga momo ka mangere ka tohaina, penei i te `Vec::new`.
    ///
    /// Kia mahara ko te uara tohu ka tohu pea i tetahi tohu tohu ki te `T`, ko te tikanga kaua e whakamahia hei uara sentiel "not yet initialized".
    /// Ko nga momo e toha mangere ana me whai i te arawhiti ki etahi atu huarahi.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: Ka whakahoki mai a mem::align_of() i te whakamahinga kore-kore ka maka ai
        // ki te * mut T.
        // No reira, kaore te `ptr` e whakakorekore ana ka aro atu ki nga tikanga mo te karanga i te new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Whakahoki ai i nga korero kua tohaina ki te uara.He rereke ki te [`as_ref`], kaore tenei e hiahia kia tiimata te uara.
    ///
    /// Hoki te tauira mutable kite [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ka waea ana koe ki tenei tikanga, me aata whakarite kia pono nga mea katoa e whai ake nei:
    ///
    /// * Me tika te whakatika i te tohu.
    ///
    /// * Me waiho te reira i "dereferencable" i te tikanga tautuhi i [the module documentation].
    ///
    /// * Me matua whakamana e koe nga ture whakamaanamana a Rust, mai i te wa i hoki mai ai `'a` he mea totika te kowhiri me te kore e whakaatu i nga wa katoa o te raraunga.
    ///
    ///   I roto i ngā, mo te roanga o tenei ra, ko te mahara nga ngā atatohu ki pau kore kia mutated (anake roto `UnsafeCell`).
    ///
    /// Ka pa tenei ahakoa kaore te hua o tenei tikanga i te whakamahia!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SAFETY: me tohu te kaiwaea kua tutaki a `self` ki nga mea katoa
        // whakaritenga mo te tohutoro.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Whakahoki ai i nga korero motuhake mo te uara.I roto i te rerekē ki [`as_mut`], e kore tenei e rapua e e kua ki kia arawhiti te uara.
    ///
    /// Mo nga hoa takoha tirohia te [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Ka waea ana koe ki tenei tikanga, me aata whakarite kia pono nga mea katoa e whai ake nei:
    ///
    /// * Me tika te whakatika i te tohu.
    ///
    /// * Me waiho te reira i "dereferencable" i te tikanga tautuhi i [the module documentation].
    ///
    /// * Me matua whakamana e koe nga ture whakamaanamana a Rust, mai i te wa i hoki mai ai `'a` he mea totika te kowhiri me te kore e whakaatu i nga wa katoa o te raraunga.
    ///
    ///   Ina koa, mo te roanga o tenei tau, ko te whakamaharatanga e tohu ana te tohu ki te kore e ahei kia uru atu (panuihia kia tuhia ranei) ma tetahi atu tohu tohu.
    ///
    /// Ka pa tenei ahakoa kaore te hua o tenei tikanga i te whakamahia!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SAFETY: me tohu te kaiwaea kua tutaki a `self` ki nga mea katoa
        // whakaritenga mo te tohutoro.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Ka waihanga te `NonNull` hou.
    ///
    /// # Safety
    ///
    /// `ptr` me kore-kore.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: me kii e te kaiwaea ko `ptr` kaore i te kore.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Ka hangaia he `NonNull` hou mena he kore-kore te `ptr`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: Kua tohua te atatohu kaore ano i te kore
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// He rite tana mahi ki te [`std::ptr::from_raw_parts`], engari ko te tohu `NonNull` ka whakahokia mai, he rereke ki te tohu atawhai `*const` noa.
    ///
    ///
    /// Tirohia nga tuhinga o [`std::ptr::from_raw_parts`] mo nga korero taipitopito.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SAFETY: Ko te hua o `ptr::from::raw_parts_mut` he koretake na te mea `data_address` he.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Tuhia te tohu (pea whanui) hei tohu me nga waahanga metadata.
    ///
    /// I muri mai ka taea te hanga i te tohu ki te [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Whiwhi ai i te atatohu `*mut` e whaaia ana.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Whakahoki ai i tetahi korero tohatoha mo te uara.Ki te te Korearawhiti ai te uara, me te whakamahi hei utu [`as_uninit_ref`].
    ///
    /// Mo te hoa whakarereke tirohia te [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Ka waea ana koe ki tenei tikanga, me aata whakarite kia pono nga mea katoa e whai ake nei:
    ///
    /// * Me tika te whakatika i te tohu.
    ///
    /// * Me waiho te reira i "dereferencable" i te tikanga tautuhi i [the module documentation].
    ///
    /// * Me tohu te tohu ki tetahi tauira tuatahi o `T`.
    ///
    /// * Me matua whakamana e koe nga ture whakamaanamana a Rust, mai i te wa i hoki mai ai `'a` he mea totika te kowhiri me te kore e whakaatu i nga wa katoa o te raraunga.
    ///
    ///   I roto i ngā, mo te roanga o tenei ra, ko te mahara nga ngā atatohu ki pau kore kia mutated (anake roto `UnsafeCell`).
    ///
    /// Ka pa tenei ahakoa kaore te hua o tenei tikanga i te whakamahia!
    /// (Ko te waahanga mo te whakaurutanga kaore ano kia oti te whakatau, engari kia tae ra ano, ko te huarahi haumaru anake ko te whakarite kia tino haangai ratou.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: me tohu te kaiwaea kua tutaki a `self` ki nga mea katoa
        // whakaritenga mo te tohutoro.
        unsafe { &*self.as_ptr() }
    }

    /// Whakahoki ai i tetahi korero motuhake mo te uara.Mena kaore pea i te whakauruhia te uara, me whakamahi ke te [`as_uninit_mut`].
    ///
    /// Mo nga hoa takoha tirohia te [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Ka waea ana koe ki tenei tikanga, me aata whakarite kia pono nga mea katoa e whai ake nei:
    ///
    /// * Me tika te whakatika i te tohu.
    ///
    /// * Me waiho te reira i "dereferencable" i te tikanga tautuhi i [the module documentation].
    ///
    /// * Me tohu te tohu ki tetahi tauira tuatahi o `T`.
    ///
    /// * Me matua whakamana e koe nga ture whakamaanamana a Rust, mai i te wa i hoki mai ai `'a` he mea totika te kowhiri me te kore e whakaatu i nga wa katoa o te raraunga.
    ///
    ///   Ina koa, mo te roanga o tenei tau, ko te whakamaharatanga e tohu ana te tohu ki te kore e ahei kia uru atu (panuihia kia tuhia ranei) ma tetahi atu tohu tohu.
    ///
    /// Ka pa tenei ahakoa kaore te hua o tenei tikanga i te whakamahia!
    /// (Ko te waahanga mo te whakaurutanga kaore ano kia oti te whakatau, engari kia tae ra ano, ko te huarahi haumaru anake ko te whakarite kia tino haangai ratou.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: me tohu te kaiwaea kua tutaki a `self` ki nga mea katoa
        // whakaritenga mo te tohutoro mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// Ka tohua ki te tohu o tetahi atu momo.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SAFETY: `self` he tohu `NonNull` kaore pea i te kore
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Ka hangaia he poro kore-kore mai i te atatohu angiangi me te roa.
    ///
    /// Ko te tohenga `len` ko te maha o nga **huanga**, kaua ko te maha o nga paita.
    ///
    /// He haumaru tenei mahi, engari ko te whakakore i te uara whakahoki kaore i te haumaru.
    /// Tirohia nga tuhinga o [`slice::from_raw_parts`] mo nga whakaritenga haumaru mo te waahanga.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // hangahia he tohu tohu mo te tiimata me te tohu ki te waahanga tuatahi
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Kia maarama ko tenei tauira e whakaatu mai ana i te whakamahinga o tenei tikanga, engari me waiho te poro= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SAFETY: `data` he tohu `NonNull` kaore pea i te kore
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Whakahoki ai i te roa o te poro mata kore-kore.
    ///
    /// Ko te uara i whakahokia ko te maha o nga **huanga**, kaua ko te maha o nga paita.
    ///
    /// He pai tenei mahi, ahakoa kaore e whakakorehia te poro tapatahi-kore mo te poro no te mea kaore he mana o te tohu ki tetahi tohu.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Whakahoki ai i tetahi tohu kore-kore ki te paraoa o te poro.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SAFETY: Kei te mohio matou he kore-kore te `self`.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Whakahokia te atatohu raw ki moka o te wāhanga.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Whakahoki ai i tetahi korero tohatoha ki te waahanga o nga uara kaore pea kia whakauruhia.He rereke ki te [`as_ref`], kaore tenei e hiahia kia tiimata te uara.
    ///
    /// Mo te hoa whakarereke tirohia te [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ka waea ana koe ki tenei tikanga, me aata whakarite kia pono nga mea katoa e whai ake nei:
    ///
    /// * Ko te tohu he [valid] pea mo te panui mo te `ptr.len() * mem::size_of::<T>()` maha paita, a me tika te whakariterite.Ko te tikanga tenei:
    ///
    ///     * Ko te whānuitanga o te whakamahara o tenei poro me uru ki roto i te ahanoa kotahi kua tohaina!
    ///       Kaore e taea e nga poro te toro atu ki nga taonga maha kua tohaina.
    ///
    ///     * Me taatahi te tohu ki nga poro-kore-roa.
    ///     Ko tetahi take mo tenei ko te pai ake o te whakatakotoranga whakatakotoranga whakatakotoranga whakapae ka whakawhirinaki ki nga tohutoro (tae atu ki nga poro o te roa) kia haangai ana kia kaua e whakakorehia ki te wehewehe i etahi atu o nga raraunga.
    ///
    ///     Ka taea e koe te tiki i tetahi tohu tohu ka taea te whakamahi hei `data` mo nga poro-kore-roa te whakamahi i te [`NonNull::dangling()`].
    ///
    /// * Ko te kohinga katoa `ptr.len() * mem::size_of::<T>()` o te poro kaua kia rahi ake i te `isize::MAX`.
    ///   Tirohia nga tuhinga ahuru o [`pointer::offset`].
    ///
    /// * Me matua whakamana e koe nga ture whakamaanamana a Rust, mai i te wa i hoki mai ai `'a` he mea totika te kowhiri me te kore e whakaatu i nga wa katoa o te raraunga.
    ///   I roto i ngā, mo te roanga o tenei ra, ko te mahara nga ngā atatohu ki pau kore kia mutated (anake roto `UnsafeCell`).
    ///
    /// Ka pa tenei ahakoa kaore te hua o tenei tikanga i te whakamahia!
    ///
    /// Tirohia hoki [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Whakahoki ai i tetahi korero motuhake mo te waahanga o nga uara kaore pea kia whakauruhia.He rereke ki te [`as_mut`], kaore tenei e hiahia kia tiimata te uara.
    ///
    /// Hoki te tauira tiritahi kite [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Ka waea ana koe ki tenei tikanga, me aata whakarite kia pono nga mea katoa e whai ake nei:
    ///
    /// * Ko te tohu he [valid] pea mo te panui me te tuhi mo te `ptr.len() * mem::size_of::<T>()` maha paita, a me tika te whakariterite.Te tikanga o tēnei i roto i ngā:
    ///
    ///     * Ko te whānuitanga o te whakamahara o tenei poro me uru ki roto i te ahanoa kotahi kua tohaina!
    ///       Kaore e taea e nga poro te toro atu ki nga taonga maha kua tohaina.
    ///
    ///     * Me taatahi te tohu ki nga poro-kore-roa.
    ///     Ko tetahi take mo tenei ko te pai ake o te whakatakotoranga whakatakotoranga whakatakotoranga whakapae ka whakawhirinaki ki nga tohutoro (tae atu ki nga poro o te roa) kia haangai ana kia kaua e whakakorehia ki te wehewehe i etahi atu o nga raraunga.
    ///
    ///     Ka taea e koe te tiki i tetahi tohu tohu ka taea te whakamahi hei `data` mo nga poro-kore-roa te whakamahi i te [`NonNull::dangling()`].
    ///
    /// * Ko te kohinga katoa `ptr.len() * mem::size_of::<T>()` o te poro kaua kia rahi ake i te `isize::MAX`.
    ///   Tirohia nga tuhinga ahuru o [`pointer::offset`].
    ///
    /// * Me matua whakamana e koe nga ture whakamaanamana a Rust, mai i te wa i hoki mai ai `'a` he mea totika te kowhiri me te kore e whakaatu i nga wa katoa o te raraunga.
    ///   Ina koa, mo te roanga o tenei tau, ko te whakamaharatanga e tohu ana te tohu ki te kore e ahei kia uru atu (panuihia kia tuhia ranei) ma tetahi atu tohu tohu.
    ///
    /// Ka pa tenei ahakoa kaore te hua o tenei tikanga i te whakamahia!
    ///
    /// Tirohia hoki [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // He haumaru tenei na te mea he tika te `memory` mo nga panui me te tuhi mo te `memory.len()` he maha nga paita.
    /// // Kia mahara kaore te piiraa `memory.as_mut()` i whakaaehia i konei na te mea kaore pea nga korero e whakauruhia.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Whakahoki ai i te tohu atawhai ki tetahi waahanga waahanga waahanga ranei, me te kore e tirotiro i nga rohe.
    ///
    /// Ko te waeatanga i tenei tikanga ma te tohu taurangi-kore-kore ka kore e whakakorehia te `self` he *[whanonga kore kua tautuhia]* ahakoa kaore i te whakamahia te tohu ki runga.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: ma te kaikaranga e whakarite kia ngoikore te `self` me te `index`-rohe.
        // Ko te mutunga ake, ko te tohu tohu kaore e taea te NUL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SAFETY: Kaore e taea te whakakore i tetahi tohu motuhake mai i nga tohu mo
        // new_unchecked() e whakaute ana.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: Ko te tohutoro ka taea te whakakore
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SAFETY: Kaore e taea te whakakore i tetahi korero, na ko nga tikanga mo
        // new_unchecked() e whakaute ana.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}