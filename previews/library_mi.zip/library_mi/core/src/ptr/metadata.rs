#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Ka whakarato i te momo tohu tohu metadata o tetahi momo tohu-ki.
///
/// # Metadata atatohu
///
/// Ko nga momo tohu noa me nga momo tohutoro i te Rust ka kiia he waahanga e rua:
/// he atatohu raraunga kei roto te waahi whakamaumahara o te uara, me etahi metadata.
///
/// Mo nga momo taatai-rahi (e whakamahi ana i te `Sized` traits) me nga momo `extern`, e kiia ana he "angiangi" nga tohu: he kore-nui te metadata me tona momo `()`.
///
///
/// Ko nga tohu ki te [dynamically-sized types][dst] e kiia ana he "whanui" "momona" ranei, he metadata kore-rahi to raatau:
///
/// * Mo nga waahanga ko te waahanga whakamutunga he DST, ko nga metadata nga metadata mo te waahanga whakamutunga
/// * Mo te momo `str`, ko te metadata te roa i nga paita hei `usize`
/// * Mo nga momo poro penei i te `[T]`, ko te metadata te roa i nga taonga hei `usize`
/// * Mo nga taonga trait penei i te `dyn SomeTrait`, ko te metadata he [`DynMetadata<Self>`][DynMetadata] (hei tauira `DynMetadata<dyn SomeTrait>`)
///
/// I te future, ka riro pea i te reo Rust nga momo momo hou e rereke ana nga tohu tohu tohu.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Te `Pointee` trait
///
/// Ko te tohu o tenei trait ko tona momo `Metadata` e hono ana, ara ko `()` ko `usize` ko `DynMetadata<_>` ranei e whakaaturia ana i runga ake nei.
/// Ka whakatinanahia aunoahia mo ia momo.
/// Ka taea te riro te reira ki te kia whakatinana i roto i te horopaki kano, ara kahore he e ōrite ana herea.
///
/// # Usage
///
/// Ka taea te whakakore i nga tohu tohu noa ki te wahitau raraunga me nga waahanga metadata me a raatau tikanga [`to_raw_parts`].
///
/// Tērā rānei, ka taea te tangohia raraunga anake ki te mahi [`metadata`].
/// Ka taea te tuku i tetahi korero ki [`metadata`] ka tino akiaki.
///
/// Ka taea te hoatu e te (possibly-wide) atatohu hoki tahi i tona wāhitau, me te raraunga ki [`from_raw_parts`] [`from_raw_parts_mut`] ranei.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Ko te momo mo nga metadata i nga tohu tohu me nga tohutoro ki `Self`.
    #[lang = "metadata_type"]
    // NOTE: Kia mau ki trait bounds i `static_assert_expected_bounds_for_metadata`
    //
    // i te `library/core/src/ptr/metadata.rs` ka honohono me era i konei:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Ko nga tohu ki nga momo e whakamahi ana i tenei ingoakona trait he "kikokore".
///
/// Kei roto i tenei ko nga momo-Tahi`tiki me nga momo `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: kaua e whakapumautia tenei i mua o te pumau o nga ingoa ingoa trait ki te reo?
pub trait Thin = Pointee<Metadata = ()>;

/// Tangohia te waahanga metadata o te tohu.
///
/// Ko nga uara o te momo `*mut T`, `&T`, te `&mut T` ranei ka taea te tuku tika ki tenei mahi na te kaha o te akiaki ki te `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SAFETY: Ko te urunga ki te uara mai i te uniana `PtrRepr` he ahuru mai i te * const T
    // me nga Kamupene PtrCents<T>rite nga whakatakotoranga mahara.
    // Ko te std anake te mea ka taea te whakarite.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Ka hangaia he tohu atawhai (possibly-wide) mai i te wahitau raraunga me te metadata.
///
/// He ahuru tenei mahi engari ko te tohu atawhai kua hoki mai kaore i te pai ki te aukati.
/// Mo nga poro, tirohia te tuhinga o [`slice::from_raw_parts`] mo nga tikanga haumaru.
/// Mo nga taonga trait, ko nga metadata me ahu mai i tetahi tohu ki tetahi momo whakakahoretia.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SAFETY: Ko te urunga ki te uara mai i te uniana `PtrRepr` he ahuru mai i te * const T
    // me nga Kamupene PtrCents<T>rite nga whakatakotoranga mahara.
    // Ko te std anake te mea ka taea te whakarite.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// He rite tana mahi ki te [`from_raw_parts`], engari ko te tohu atawhai `*mut` kua whakahokia mai, he rereke ki te tohu atawhai `* const` noa.
///
///
/// Tirohia nga tuhinga o [`from_raw_parts`] mo nga korero taipitopito.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SAFETY: Ko te urunga ki te uara mai i te uniana `PtrRepr` he ahuru mai i te * const T
    // me nga Kamupene PtrCents<T>rite nga whakatakotoranga mahara.
    // Ko te std anake te mea ka taea te whakarite.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Ko te whakamahinga a-ringa hei karo i te `T: Copy` ka herea.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Ko te whakamahinga a-ringa hei karo i te `T: Clone` ka herea.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Ko nga metadata mo te momo ahanoa `Dyn = dyn SomeTrait` trait.
///
/// He tohu ki te teepu (teepu karanga mariko) e whakaatu ana i nga korero e tika ana hei whakahaere i te momo raima kei roto i te taonga trait.
/// Te kohinga nui kei roto:
///
/// * rahinga momo
/// * whakaoronga momo
/// * he atatohu ki te momo `drop_in_place` impl (akene he kore-op mo te raraunga maarama-tawhito)
/// * tohu ki nga tikanga katoa mo te momo whakamahinga o te trait
///
/// Note e he motuhake te toru tuatahi no te mea kei tika ratou ki te tohatoha, te maturuturunga iho, me te deallocate tetahi ahanoa trait.
///
/// Ka taea te whakaingoa i tenei hanganga ma te momo taatai ehara i te mea `dyn` trait (hei tauira `DynMetadata<u64>`) engari kaua e whiwhi i te uara tino nui o taua hanganga.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Ko te kuhimua noa o nga vtables katoa.Kei te aru te reira e atatohu mahi mō tikanga trait.
///
/// Taipitopito whakatinanatanga tuuturu o `DynMetadata::size_of` etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Whakahoki mai ai i te rahinga o te momo e hono ana ki tenei whare nohoanga.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Whakahoki ai i te haangai o te momo e hono ana ki tenei papa.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Whakahoki ai i te rahinga me te whakahoutanga kia rite ki te `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // HAUMARU: tukuna te taupatupatu tenei vtable mo te momo Rust raima i
        // Kei te mohiotia ki te whai i te tahora tika.He kaupapa whaihua pera i `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Nga taputapu a-ringa hei karo i nga rohe `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}