use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Returns `true` ki he null te atatohu.
    ///
    /// Note e momo unsized i maha atatohu whakakahore taea, pera anake whakaaro te atatohu raraunga raw te, e kore ratou te roa, vtable, me ētahi atu
    /// No reira, e rua pea nga tohu tohu kore he pea hei whakataurite i waenga i a raatau.
    ///
    /// ## Te whanonga i te wā o te aro mātai
    ///
    /// Ka whakamahia ana tenei mahi i te wa o te aromautanga o te kaupapa, akene ka hoki mai pea a `false` mo nga tohu tohu ka kore noa i te waa waatea.
    /// Ina koa, ka tohua te tohu ki tetahi maumahara ki tua atu o ona rohe kia kore ai e tohuhia te tohu, ka hoki tonu te mahi `false`.
    ///
    /// Kahore he ara mo CTFE ki mohio te tūranga tino o taua mahara, kia kore tatou e taea korero ki te ko te atatohu null kore ranei.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Whakatauritea mā te maka ki te atatohu kikokore, e atatohu kia ngako whakaaro anake ratou wahi "data" mō te korenga-huru.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Ka tohua ki te tohu o tetahi atu momo.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Tuhia te tohu (pea whanui) hei tohu me nga waahanga metadata.
    ///
    /// I muri mai ka taea te hanga i te tohu ki te [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Whakahoki ai i te `None` mena he kore noa te tohu, kaore ranei ka hoki mai i tetahi tohanga tiri ki te uara kua takaia ki te `Some`.Ki te te Korearawhiti ai te uara, me te whakamahi hei utu [`as_uninit_ref`].
    ///
    /// Mo te hoa whakarereke tirohia te [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Ka waea ana koe ki tenei tikanga, me whakarite e koe *me* te tohu he NULL *ranei* he pono nga mea katoa e whai ake nei:
    ///
    /// * Me tika te whakatika i te tohu.
    ///
    /// * Me waiho te reira i "dereferencable" i te tikanga tautuhi i [the module documentation].
    ///
    /// * Me tohu te tohu ki tetahi tauira tuatahi o `T`.
    ///
    /// * Me matua whakamana e koe nga ture whakamaanamana a Rust, mai i te wa i hoki mai ai `'a` he mea totika te kowhiri me te kore e whakaatu i nga wa katoa o te raraunga.
    ///   I roto i ngā, mo te roanga o tenei ra, ko te mahara nga ngā atatohu ki pau kore kia mutated (anake roto `UnsafeCell`).
    ///
    /// Ka pa tenei ahakoa kaore te hua o tenei tikanga i te whakamahia!
    /// (Ko te waahanga mo te whakaurutanga kaore ano kia oti te whakatau, engari kia tae ra ano, ko te huarahi haumaru anake ko te whakarite kia tino haangai ratou.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Putanga kore-tirohia
    ///
    /// Ki te ko koe tino kore e taea e te atatohu hei whakakahore, me e rapu mo etahi ahua o `as_ref_unchecked` e hoki te `&T` hei utu o `Option<&T>`, e mohio ana e taea e koe dereference tika te atatohu.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SAFETY: me kii te kaikaranga he tika te `self` mo a
        // tohutoro mena kaore i te kore.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Whakahoki ai i te `None` mena he kore noa te tohu, kaore ranei ka hoki mai i tetahi tohanga tiri ki te uara kua takaia ki te `Some`
    /// He rereke ki te [`as_ref`], kaore tenei e hiahia kia tiimata te uara.
    ///
    /// Hoki te tauira mutable kite [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ka waea ana koe ki tenei tikanga, me whakarite e koe *me* te tohu he NULL *ranei* he pono nga mea katoa e whai ake nei:
    ///
    /// * Me tika te whakatika i te tohu.
    ///
    /// * Me waiho te reira i "dereferencable" i te tikanga tautuhi i [the module documentation].
    ///
    /// * Me matua whakamana e koe nga ture whakamaanamana a Rust, mai i te wa i hoki mai ai `'a` he mea totika te kowhiri me te kore e whakaatu i nga wa katoa o te raraunga.
    ///
    ///   I roto i ngā, mo te roanga o tenei ra, ko te mahara nga ngā atatohu ki pau kore kia mutated (anake roto `UnsafeCell`).
    ///
    /// Ka pa tenei ahakoa kaore te hua o tenei tikanga i te whakamahia!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: me tohu te kaiwaea kua tutaki a `self` ki nga mea katoa
        // whakaritenga mo te tohutoro.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Ka taatau i te whakawhirinaki mai i te tohu tohu.
    ///
    /// `count` Ko roto i ngā wae o T;hei tauira, ko te `count` o te 3 e tohu ana i te tohu atawhai o te `3 * size_of::<T>()` paita.
    ///
    /// # Safety
    ///
    /// Mena kua takahia tetahi o nga tikanga e whai ake nei, ko te mutunga ko te Whanonga Kore i Whakatauhia:
    ///
    /// * Rua kia rānei te atatohu tīmata me te hua i roto i rohe kotahi paita mua te mutunga o te ahanoa tohaina taua ranei.
    /// Kia mahara kei roto i te Rust, ko nga taurangi (stack-allocated) katoa e kiia ana he taonga wehe.
    ///
    /// * Ko te urunga tatau,**i nga paita**, kaore e taea te neke i te `isize`.
    ///
    /// * Ko te whakaheke i nga rohe kaore e taea te whakawhirinaki ki te "wrapping around" te waahi wahitau.Ko, te moni mure-pū,**i roto i paita** Me uru i roto i te usize.
    ///
    /// I te nuinga o te wa ka ngana te kaitoha me te wharepukapuka paerewa ki te whakarite kia kaua rawa e tae te rahinga ki te rahinga kei te awangawanga te waahanga.
    /// Hei tauira, `Vec` me `Box` whakarite kia kore rawa e tohatoha neke atu i te `isize::MAX` paita, na te mea he pai te `vec.as_ptr().add(vec.len())`.
    ///
    /// Ko te nuinga o nga papanga kaore e taea te hanga i tetahi waahanga pera.
    /// Hei tauira, kaore e mohiotia te papa-moka-iti e mohiotia ana ka tono tono mo te 2 <sup>63</sup> paita na te mea he iti ki te whaarangi-teepu te wehewehe i te waahi wahitau ranei.
    /// Heoi, ko etahi waahanga 32-bit me te 16-bit ka pai pea te tono mo te nui atu i te `isize::MAX` paita me nga mea penei i te Toronga Whaangai Tinana.
    ///
    /// I tenei wa, ko nga mahara i tangohia tika mai i nga kaiwhakarato, i nga maapapa maumahara ranei i nga maapepa *pea* he nui rawa hei whakahaere i tenei mahi.
    ///
    /// Whakaarohia te whakamahi i te [`wrapping_offset`] kaore mena he uaua ki te tutuki i enei herenga.
    /// Ko te painga anake o tenei tikanga ko te mea ka kaha ake te kaha o te whakakairite i te kaiwhakaputa.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `offset`.
        // Ko te atatohu kua riro he whaimana mo nga tuhi no te mea me tohu te kaiwaea e tohu ana ki te taonga kua tohaina kia rite ki te `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Ka taatau i te whakawhirinaki mai i te tohu ki te whakamahi i te taatai taatai.
    /// `count` Ko roto i ngā wae o T;hei tauira, ko te `count` o te 3 e tohu ana i te tohu atawhai o te `3 * size_of::<T>()` paita.
    ///
    /// # Safety
    ///
    /// Ko tenei mahinga tonu he haumaru i nga wa katoa, engari ko te whakamahi i te tohu tohu kaore he.
    ///
    /// Ko te toenga atatohu hua piri ki te ahanoa taua tohaina e `self` ngā ki.
    /// Akene *kaore* e whakamahia kia uru atu ki tetahi taonga rereke kua tohaina.Kia mahara kei roto i te Rust, ko nga taurangi (stack-allocated) katoa e kiia ana he taonga wehe.
    ///
    /// I etahi atu kupu, kaore te `let z = x.wrapping_offset((y as isize) - (x as isize))` e *hanga* i te `z` kia rite ki te `y` ahakoa ki te whakaaro he rahi te `T` ki te `1` ana kaore ano he waipuke: Kei te piri tonu a `z` ki te mea `x` e piri ana, ana ka whakakorehia he Whanonga Kare he `x` me te Tohu `y` ki taua taonga ano i tohaina.
    ///
    /// Ki te whakaritea ki [`offset`], ko tenei tikanga ka whakaroa i te whakaritenga o te noho i roto i taua taonga kua tohaina: Ko te [`offset`] tonu te Whanonga Kare e Whakahauhia ina whiti ana i nga rohe ahanoa;Kei te whakaputa a `wrapping_offset` i tetahi tohu tohu engari ka ahu tonu ki te Whanonga Kare e Whakaaehia ana mena ka whakahekehia te tohu tohu i te wa kei waho o te rohe o te mea e piri ana.
    /// [`offset`] ka taea te whakapai ake kia pai ake, me te mea e pai ana ki te waehere mahi-tairongo.
    ///
    /// Ko te haki takaroa e whakaaro noa ana ki te uara o te atatohu i tangohia, kaore i nga uara takawaenga i whakamahia i te wa e tatau ana te otinga whakamutunga.
    /// Hei tauira, ko te `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` he rite tonu ki te `x`.I roto i te mau parau te tahi atu, ka mahue te ahanoa whakaritea me ka anō-tomo te reira i muri mai tukua te.
    ///
    /// Mena me whakawhiti koe i nga rohe ahanoa, maka te tohu ki tetahi tauoti ka mahi i te tatau i konaa.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // Te whakamahi i te atatohu mata hei whakanui i nga waahanga e rua
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: te `arith_offset` intrinsic kaore he mea e hiahiatia ana kia karangahia.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Whakahoki ai i te `None` mena he kore noa te tohu, kaore ranei ka hoki mai he tohu motuhake ki te uara kua takaia ki te `Some`.Ki te te Korearawhiti ai te uara, me te whakamahi hei utu [`as_uninit_mut`].
    ///
    /// Mo nga hoa takoha tirohia te [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Ka waea ana koe ki tenei tikanga, me whakarite e koe *me* te tohu he NULL *ranei* he pono nga mea katoa e whai ake nei:
    ///
    /// * Me tika te whakatika i te tohu.
    ///
    /// * Me waiho te reira i "dereferencable" i te tikanga tautuhi i [the module documentation].
    ///
    /// * Me tohu te tohu ki tetahi tauira tuatahi o `T`.
    ///
    /// * Me matua whakamana e koe nga ture whakamaanamana a Rust, mai i te wa i hoki mai ai `'a` he mea totika te kowhiri me te kore e whakaatu i nga wa katoa o te raraunga.
    ///   Ina koa, mo te roanga o tenei tau, ko te whakamaharatanga e tohu ana te tohu ki te kore e ahei kia uru atu (panuihia kia tuhia ranei) ma tetahi atu tohu tohu.
    ///
    /// Ka pa tenei ahakoa kaore te hua o tenei tikanga i te whakamahia!
    /// (Ko te waahanga mo te whakaurutanga kaore ano kia oti te whakatau, engari kia tae ra ano, ko te huarahi haumaru anake ko te whakarite kia tino haangai ratou.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Ka taia: "[4, 2, 3]".
    /// ```
    ///
    /// # Putanga kore-tirohia
    ///
    /// Mena ka mohio koe kaore rawa e taea te tohu o te tohu me te rapu i tetahi momo `as_mut_unchecked` e whakahoki ana i te `&mut T` hei utu mo te `Option<&mut T>`, kia mohio ka taea e koe te whakakore tika i te tohu.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Ka taia: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SAFETY: me kii te kaikaranga he tika te `self` mo
        // he tohutoro ka taea te whakarereke mena kaore i te kore.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Whakahoki `None` mena he kore te tohu, ka kore ranei ka hoki mai i tetahi korero motuhake ki te uara kua takaia ki te `Some`.
    /// He rereke ki te [`as_mut`], kaore tenei e hiahia kia tiimata te uara.
    ///
    /// Mo nga hoa takoha tirohia te [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Ka waea ana koe ki tenei tikanga, me whakarite e koe *me* te tohu he NULL *ranei* he pono nga mea katoa e whai ake nei:
    ///
    /// * Me tika te whakatika i te tohu.
    ///
    /// * Me waiho te reira i "dereferencable" i te tikanga tautuhi i [the module documentation].
    ///
    /// * Me matua whakamana e koe nga ture whakamaanamana a Rust, mai i te wa i hoki mai ai `'a` he mea totika te kowhiri me te kore e whakaatu i nga wa katoa o te raraunga.
    ///
    ///   Ina koa, mo te roanga o tenei tau, ko te whakamaharatanga e tohu ana te tohu ki te kore e ahei kia uru atu (panuihia kia tuhia ranei) ma tetahi atu tohu tohu.
    ///
    /// Ka pa tenei ahakoa kaore te hua o tenei tikanga i te whakamahia!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: me tohu te kaiwaea kua tutaki a `self` ki nga mea katoa
        // whakaritenga mo te tohutoro.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Whakahoki mena e tohu ana nga tohu e rua kia orite.
    ///
    /// I te waa kua rite tenei mahi ki to `self == other`.
    /// Heoi, i etahi horopaki (hei tauira, te arotake-waahi aromautanga), kaore e taea te whakatau i te orite o nga tohu e rua, na tenei mahi ka hoki mai pea te `false` mo nga tohu ka tohu ka rite tonu.
    ///
    /// Engari ka hoki mai ana `true`, ka tohu nga tohu ki te orite.
    ///
    /// Tenei mahi ko te whakaata o [`guaranteed_ne`], engari e kore e tona kōaro.He whakataurite tohu tohu mo te whakahoki i nga mahi e rua ki te `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// kia huri te uara hoki i runga i te putanga e taupatupatu me te waehere haumaru kore e whakawhirinaki i runga i te hua o tenei mahi mo te ora rānei.
    /// Ko te whakaaro kia whakamahia noa tenei mahi mo nga mahi whakaniko kia kore e raru nga uara o te hokinga `false` na tenei mahi i te otinga, engari ko nga mahi noa iho.
    /// Ko nga hua o te whakamahi i tenei tikanga kia rereke te mahi me te waehere whakahiato-wa kaore ano kia tirotirohia.
    /// Ko tenei tikanga kaua e whakamahia hei whakauru i nga rereketanga pera, ana kaua hoki e whakatuturutia i mua i to taatau maarama pai ki tenei kaupapa.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Whakahoki mena e tohu ana nga tohu e rua he taurite.
    ///
    /// I te wā i tenei mahi ana mahi kia rite ki `self != other`.
    /// Heoi, i etahi horopaki (hei tauira, te arotake-waahi aromautanga), kaore e taea te whakatau i te rereketanga o nga tohu e rua, na tenei mahi ka hoki pea te whakahoki i te `false` mo nga tohu ka tohu ka kore e taurite.
    ///
    /// Engari ka hoki mai ana `true`, ka tohu nga tohu ki te taurite.
    ///
    /// Ko tenei mahi ko te whakaata o [`guaranteed_eq`], engari kaore i te hurihuri.He whakataurite tohu tohu mo te whakahoki i nga mahi e rua ki te `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// kia huri te uara hoki i runga i te putanga e taupatupatu me te waehere haumaru kore e whakawhirinaki i runga i te hua o tenei mahi mo te ora rānei.
    /// Ko te whakaaro kia whakamahia noa tenei mahi mo nga mahi whakaniko kia kore e raru nga uara o te hokinga `false` na tenei mahi i te otinga, engari ko nga mahi noa iho.
    /// Ko nga hua o te whakamahi i tenei tikanga kia rereke te mahi me te waehere whakahiato-wa kaore ano kia tirotirohia.
    /// Ko tenei tikanga kaua e whakamahia hei whakauru i nga rereketanga pera, ana kaua hoki e whakatuturutia i mua i to taatau maarama pai ki tenei kaupapa.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Ka tatau i te tawhiti i waenga i nga tohu tohu e rua.Ko te uara hoki i roto i ngā wae o T: wehea te tawhiti i roto i paita e `mem::size_of::<T>()`.
    ///
    /// Tenei mahi ko te kōaro o [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Mena kua takahia tetahi o nga tikanga e whai ake nei, ko te mutunga ko te Whanonga Kore i Whakatauhia:
    ///
    /// * Me kia rānei rua te tīmatanga me te tahi atu atatohu i roto i rohe ranei kotahi paita mua te mutunga o te ahanoa tohaina taua.
    /// Kia mahara kei roto i te Rust, ko nga taurangi (stack-allocated) katoa e kiia ana he taonga wehe.
    ///
    /// * Ko nga tohu e rua me * ahu mai i te tohu ki tetahi mea kotahi.
    ///   (Tirohia i raro nei hei tauira.)
    ///
    /// * Ko te tawhiti i waenga i nga tohu, i nga paita, kia maha tonu te rahi o te rahi `T`.
    ///
    /// * Ko te tawhiti i waenga i nga tohu,**i nga paita**, kaore e taea te neke i te `isize`.
    ///
    /// * Ko te tawhiti kei roto i nga rohe kaore e taea te whakawhirinaki ki te "wrapping around" te waahi wahitau.
    ///
    /// Ko nga momo Rust kaore e rahi ake i te `isize::MAX` me nga tohatoha Rust kaore e takai i te waahi wahitau, na e rua nga tohu i roto i etahi uara o te momo Rust `T` ka ea i nga tikanga e rua kua hipa.
    ///
    /// Ko te wharepukapuka paerewa hoki e tino whakarite ana kia kaua e tae te rahinga ki te rahinga o te waahanga.
    /// Hoki tauira, `Vec` ko `Box` whakarite ratou kore tohatoha neke atu i ngā paita `isize::MAX`, na tonu `ptr_into_vec.offset_from(vec.as_ptr())` i makona nga tikanga e rua whakamutunga.
    ///
    /// Te nuinga o tüäpapa kore e taea e faufaa ara hanga he taua tohatoha nui.
    /// Hei tauira, kaore e mohiotia te papa-moka-iti e mohiotia ana ka tono tono mo te 2 <sup>63</sup> paita na te mea he iti ki te whaarangi-teepu te wehewehe i te waahi wahitau ranei.
    /// Heoi, ko etahi waahanga 32-bit me te 16-bit ka pai pea te tono mo te nui atu i te `isize::MAX` paita me nga mea penei i te Toronga Whaangai Tinana.
    /// I tenei wa, ko nga mahara i tangohia tika mai i nga kaiwhakarato, i nga maapapa maumahara ranei i nga maapepa *pea* he nui rawa hei whakahaere i tenei mahi.
    /// (Kia mahara he rite ano te herenga a te [`offset`] me te [`add`] na reira kaore e taea te whakamahi i runga i enei waahanga nui.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ko tenei mahi panics mena he `T` he Zero-Rahi Momo ("ZST").
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Hē* whakamahinga:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Mahia te ptr2_tahi "alias" o ptr2, engari i ahu mai i te ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // I te mea ko te ptr2_other me te ptr2 i ahu mai i nga tohu tohu ki nga taonga rereke, ko te taatai i o raatau waahanga he whanonga kore, ahakoa he tohu ano te korero!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Whanonga Kare i Whakahauhia
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Ka tatauhia te utu mai i te tohu tohu (ngawari ki te `.offset(count as isize)`).
    ///
    /// `count` Ko roto i ngā wae o T;hei tauira, ko te `count` o te 3 e tohu ana i te tohu atawhai o te `3 * size_of::<T>()` paita.
    ///
    /// # Safety
    ///
    /// Mena kua takahia tetahi o nga tikanga e whai ake nei, ko te mutunga ko te Whanonga Kore i Whakatauhia:
    ///
    /// * Rua kia rānei te atatohu tīmata me te hua i roto i rohe kotahi paita mua te mutunga o te ahanoa tohaina taua ranei.
    /// Kia mahara kei roto i te Rust, ko nga taurangi (stack-allocated) katoa e kiia ana he taonga wehe.
    ///
    /// * Ko te urunga tatau,**i nga paita**, kaore e taea te neke i te `isize`.
    ///
    /// * Ko te whakaheke i nga rohe kaore e taea te whakawhirinaki ki te "wrapping around" te waahi wahitau.Arā, ko te moni mutunga-mutunga kia uru ki te `usize`.
    ///
    /// I te nuinga o te wa ka ngana te kaitoha me te wharepukapuka paerewa ki te whakarite kia kaua rawa e tae te rahinga ki te rahinga kei te awangawanga te waahanga.
    /// Hei tauira, `Vec` me `Box` whakarite kia kore rawa e tohatoha neke atu i te `isize::MAX` paita, na te mea he pai te `vec.as_ptr().add(vec.len())`.
    ///
    /// Ko te nuinga o nga papanga kaore e taea te hanga i tetahi waahanga pera.
    /// Hei tauira, kaore e mohiotia te papa-moka-iti e mohiotia ana ka tono tono mo te 2 <sup>63</sup> paita na te mea he iti ki te whaarangi-teepu te wehewehe i te waahi wahitau ranei.
    /// Heoi, ko etahi waahanga 32-bit me te 16-bit ka pai pea te tono mo te nui atu i te `isize::MAX` paita me nga mea penei i te Toronga Whaangai Tinana.
    ///
    /// I tenei wa, ko nga mahara i tangohia tika mai i nga kaiwhakarato, i nga maapapa maumahara ranei i nga maapepa *pea* he nui rawa hei whakahaere i tenei mahi.
    ///
    /// Whakaarohia te whakamahi i te [`wrapping_add`] kaore mena he uaua ki te tutuki i enei herenga.
    /// Ko te painga anake o tenei tikanga ko te mea ka kaha ake te kaha o te whakakairite i te kaiwhakaputa.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Ka taatau i te whakawhirinaki mai i te atatohu (haratau mo te `.offset ((tatau kia isize).wrapping_neg())`).
    ///
    /// `count` Ko roto i ngā wae o T;hei tauira, ko te `count` o te 3 e tohu ana i te tohu atawhai o te `3 * size_of::<T>()` paita.
    ///
    /// # Safety
    ///
    /// Mena kua takahia tetahi o nga tikanga e whai ake nei, ko te mutunga ko te Whanonga Kore i Whakatauhia:
    ///
    /// * Rua kia rānei te atatohu tīmata me te hua i roto i rohe kotahi paita mua te mutunga o te ahanoa tohaina taua ranei.
    /// Kia mahara kei roto i te Rust, ko nga taurangi (stack-allocated) katoa e kiia ana he taonga wehe.
    ///
    /// * Kaore e nui ake te utu kua oti te taatai i te `isize::MAX`**paita**.
    ///
    /// * Ko te whakaheke i nga rohe kaore e taea te whakawhirinaki ki te "wrapping around" te waahi wahitau.Ara, ko te moni mutunga-mutunga kia uru ki te wehenga.
    ///
    /// I te nuinga o te wa ka ngana te kaitoha me te wharepukapuka paerewa ki te whakarite kia kaua rawa e tae te rahinga ki te rahinga kei te awangawanga te waahanga.
    /// Hei tauira, `Vec` me `Box` whakarite kia kore rawa e tohatoha neke atu i te `isize::MAX` paita, na te mea he pai te `vec.as_ptr().add(vec.len()).sub(vec.len())`.
    ///
    /// Ko te nuinga o nga papanga kaore e taea te hanga i tetahi waahanga pera.
    /// Hei tauira, kaore e mohiotia te papa-moka-iti e mohiotia ana ka tono tono mo te 2 <sup>63</sup> paita na te mea he iti ki te whaarangi-teepu te wehewehe i te waahi wahitau ranei.
    /// Heoi, ko etahi waahanga 32-bit me te 16-bit ka pai pea te tono mo te nui atu i te `isize::MAX` paita me nga mea penei i te Toronga Whaangai Tinana.
    ///
    /// I tenei wa, ko nga mahara i tangohia tika mai i nga kaiwhakarato, i nga maapapa maumahara ranei i nga maapepa *pea* he nui rawa hei whakahaere i tenei mahi.
    ///
    /// Whakaarohia te whakamahi i te [`wrapping_sub`] kaore mena he uaua ki te tutuki i enei herenga.
    /// Ko te painga anake o tenei tikanga ko te mea ka kaha ake te kaha o te whakakairite i te kaiwhakaputa.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Ka taatau i te whakawhirinaki mai i te tohu ki te whakamahi i te taatai taatai.
    /// (ngawari mo te `.wrapping_offset(count as isize)`)
    ///
    /// `count` Ko roto i ngā wae o T;hei tauira, ko te `count` o te 3 e tohu ana i te tohu atawhai o te `3 * size_of::<T>()` paita.
    ///
    /// # Safety
    ///
    /// Ko tenei mahinga tonu he haumaru i nga wa katoa, engari ko te whakamahi i te tohu tohu kaore he.
    ///
    /// Ko te toenga atatohu hua piri ki te ahanoa taua tohaina e `self` ngā ki.
    /// Akene *kaore* e whakamahia kia uru atu ki tetahi taonga rereke kua tohaina.Kia mahara kei roto i te Rust, ko nga taurangi (stack-allocated) katoa e kiia ana he taonga wehe.
    ///
    /// I etahi atu kupu, kaore te `let z = x.wrapping_add((y as usize) - (x as usize))` e *hanga* i te `z` kia rite ki te `y` ahakoa ki te whakaaro he rahi te `T` ki te `1` ana kaore ano he waipuke: Kei te piri tonu a `z` ki te taonga `x` kua honoa, a ka whakakorehia he Whanonga Kare he `x` me te Tohu `y` ki taua taonga ano i tohaina.
    ///
    /// Ki te whakaritea ki [`add`], ko tenei tikanga ka whakaroa i te whakaritenga o te noho i roto i taua taonga kua tohaina: Ko te [`add`] tonu te Whanonga Kare e Whakahauhia ina whiti ana i nga rohe ahanoa;Kei te whakaputa a `wrapping_add` i tetahi tohu tohu engari ka ahu tonu ki te Whanonga Kare e Whakaaehia ana mena ka whakahekehia te tohu tohu i te wa kei waho o te rohe o te mea e piri ana.
    /// [`add`] ka taea te whakapai ake kia pai ake, me te mea e pai ana ki te waehere mahi-tairongo.
    ///
    /// Ko te haki takaroa e whakaaro noa ana ki te uara o te atatohu i tangohia, kaore i nga uara takawaenga i whakamahia i te wa e tatau ana te otinga whakamutunga.
    /// Hei tauira, ko te `x.wrapping_add(o).wrapping_sub(o)` he rite tonu ki te `x`.I etahi atu, ko te waiho i te mea kua tohaina ka whakauru ano ki muri ka whakaaetia.
    ///
    /// Mena me whakawhiti koe i nga rohe ahanoa, maka te tohu ki tetahi tauoti ka mahi i te tatau i konaa.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // Te whakamahi i te atatohu mata hei whakanui i nga waahanga e rua
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ka taatahia e tenei koropiko "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Ka taatau i te whakawhirinaki mai i te tohu ki te whakamahi i te taatai taatai.
    /// (te waatea mo te `.wrapping_offset ((tatau kia isize).wrapping_neg())`)
    ///
    /// `count` Ko roto i ngā wae o T;hei tauira, ko te `count` o te 3 e tohu ana i te tohu atawhai o te `3 * size_of::<T>()` paita.
    ///
    /// # Safety
    ///
    /// Ko tenei mahinga tonu he haumaru i nga wa katoa, engari ko te whakamahi i te tohu tohu kaore he.
    ///
    /// Ko te toenga atatohu hua piri ki te ahanoa taua tohaina e `self` ngā ki.
    /// Akene *kaore* e whakamahia kia uru atu ki tetahi taonga rereke kua tohaina.Kia mahara kei roto i te Rust, ko nga taurangi (stack-allocated) katoa e kiia ana he taonga wehe.
    ///
    /// I etahi atu kupu, kaore te `let z = x.wrapping_sub((x as usize) - (y as usize))` e *hanga* i te `z` kia rite ki te `y` ahakoa ki te whakaaro he rahi te `T` ki te `1` ana kaore ano he waipuke: Kei te piri tonu a `z` ki te taonga `x` kua honoa, a ka whakakorehia he Whanonga Kare e kore te `x` Tohu `y` ki taua taonga ano i tohaina.
    ///
    /// Ki te whakaritea ki [`sub`], ko tenei tikanga ka whakaroa i te whakaritenga o te noho i roto i taua taonga kua tohaina: Ko te [`sub`] tonu te Whanonga Kare e Whakahauhia ina whiti ana i nga rohe ahanoa;Kei te whakaputa a `wrapping_sub` i tetahi tohu tohu engari ka ahu tonu ki te Whanonga Kare e Whakaaehia ana mena ka whakahekehia te tohu tohu i te wa kei waho o te rohe o te mea e piri ana.
    /// [`sub`] ka taea te whakapai ake kia pai ake, me te mea e pai ana ki te waehere mahi-tairongo.
    ///
    /// Ko te haki takaroa e whakaaro noa ana ki te uara o te atatohu i tangohia, kaore i nga uara takawaenga i whakamahia i te wa e tatau ana te otinga whakamutunga.
    /// Hei tauira, ko te `x.wrapping_add(o).wrapping_sub(o)` he rite tonu ki te `x`.I etahi atu, ko te waiho i te mea kua tohaina ka whakauru ano ki muri ka whakaaetia.
    ///
    /// Mena me whakawhiti koe i nga rohe ahanoa, maka te tohu ki tetahi tauoti ka mahi i te tatau i konaa.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // Tukurua whakamahi i te atatohu raw i roto i ngā āpiti o ngā huānga e rua (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ka taatahia e tenei koropiko "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Ka tautuhia te uara tohu ki `ptr`.
    ///
    /// Mena ko `self` he tohu (fat) ki tetahi momo kore, ka pa noa tenei mahi ki te waahanga tohu, engari mo nga tohu (thin) ki nga momo rahi, he rite tonu te ahua o tenei ki te taumahi ngawari.
    ///
    /// Ko te tohu ka puta he `val`, ara, mo te tohu momona, he rite tonu te ahua o tenei mahi ki te hanga i tetahi tohu tohu momona hou me te uara tohu raraunga o `val` engari ko nga metadata o `self`.
    ///
    ///
    /// # Examples
    ///
    /// Ko te tino whaihua o tenei mahi hei tuku i te tohu tohu paitini ki nga tohu tohu momona pea:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // ka taarua "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // SAFETY: Mena he tohu angiangi, he rite enei mahi
        // ki tetahi taumahi ngawari.
        // Mena he tohu momona, me te whakamahi i te tohu tohu tohu momona inaianei, ko te mara tuatahi o te tohu penei ko te tohu raraunga, kua tohaina hoki.
        //
        unsafe { *thin = val };
        self
    }

    /// Ua tai'oi te uara i `self` waho neke i te reira.
    /// Ma tenei ka waiho te mahara ki te `self` kaore i whakarereke.
    ///
    /// Tirohia te [`ptr::read`] mo nga awangawanga haumaru me nga tauira.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te ``.
        unsafe { read(self) }
    }

    /// Ka mahi i te panui rerekee o te uara mai i te `self` me te kore e nekehia.Ma tenei ka waiho te mahara ki te `self` kaore i whakarereke.
    ///
    /// Ko nga mahi koretake te tikanga ki te mahi i runga i te mahara I/O, ana ka tutuki kia kore e tukuna kia whakahoutia, kia whakatauhia ranei e te kaitautoko puta noa i etahi atu mahi ngawari.
    ///
    ///
    /// Tirohia te [`ptr::read_volatile`] mo nga awangawanga haumaru me nga tauira.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Ua tai'oi te uara i `self` waho neke i te reira.
    /// Ma tenei ka waiho te mahara ki te `self` kaore i whakarereke.
    ///
    /// Kaore i rite ki te `read`, kaore pea te tohu o te tohu i tohu.
    ///
    /// Tirohia te [`ptr::read_unaligned`] mo nga awangawanga haumaru me nga tauira.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Ka kape i nga paita `count * size_of<T>` mai i te `self` ki te `dest`.
    /// Ka inaki pea te putake me te ahunga.
    ///
    /// NOTE: kei a tenei te *taua* raupapa tohenga me [`ptr::copy`].
    ///
    /// Tirohia te [`ptr::copy`] mo nga awangawanga haumaru me nga tauira.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Ka kape i nga paita `count * size_of<T>` mai i te `self` ki te `dest`.
    /// Ko te putake me te ahunga kaore pea * e taupoki.
    ///
    /// NOTE: kei a tenei te *taua* raupapa tohenga me [`ptr::copy_nonoverlapping`].
    ///
    /// Tirohia te [`ptr::copy_nonoverlapping`] mo nga awangawanga haumaru me nga tauira.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Ka kape i nga paita `count * size_of<T>` mai i te `src` ki te `self`.
    /// Ka inaki pea te putake me te ahunga.
    ///
    /// NOTE: kei a tenei te *ritenga* raupapa tohenga o [`ptr::copy`].
    ///
    /// Tirohia te [`ptr::copy`] mo nga awangawanga haumaru me nga tauira.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Ka kape i nga paita `count * size_of<T>` mai i te `src` ki te `self`.
    /// Ko te putake me te ahunga kaore pea * e taupoki.
    ///
    /// NOTE: kei a tenei te *ritenga* raupapa tohenga o [`ptr::copy_nonoverlapping`].
    ///
    /// Tirohia te [`ptr::copy_nonoverlapping`] mo nga awangawanga haumaru me nga tauira.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Ka whakahaere i te kaiwhakakahu (ki te mea) o te uara tohu-ki.
    ///
    /// Tirohia te [`ptr::drop_in_place`] mo nga awangawanga haumaru me nga tauira.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Ka tuhirua i tetahi waahi maumahara me te uara kua whakaritea me te kore e panui, kia heke ranei te uara tawhito.
    ///
    ///
    /// Tirohia te [`ptr::write`] mo nga awangawanga haumaru me nga tauira.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `write`.
        unsafe { write(self, val) }
    }

    /// Ka whakahua i te whakamaarama ki te tohu tohu kua tohua, te whakatau i te paanui mahara `count * size_of::<T>()` ka tiimata mai i te `self` ki te `val`.
    ///
    ///
    /// Tirohia te [`ptr::write_bytes`] mo nga awangawanga haumaru me nga tauira.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Ka mahi i tetahi tuhi ngawari mo tetahi waahi maumahara me te uara kua whakaritea me te kore e paanui, ka taka ranei te uara tawhito.
    ///
    /// Ko nga mahi koretake te tikanga ki te mahi i runga i te mahara I/O, ana ka tutuki kia kore e tukuna kia whakahoutia, kia whakatauhia ranei e te kaitautoko puta noa i etahi atu mahi ngawari.
    ///
    ///
    /// Tirohia te [`ptr::write_volatile`] mō āwangawanga haumaru me tauira.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Ka tuhirua i tetahi waahi maumahara me te uara kua whakaritea me te kore e panui, kia heke ranei te uara tawhito.
    ///
    ///
    /// Kaore i rite ki te `write`, kaore pea te tohu o te tohu i tohu.
    ///
    /// Tirohia te [`ptr::write_unaligned`] mō āwangawanga haumaru me tauira.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Whakakapihia te uara i `self` me `src`, ka whakahokia mai te uara tawhito, kaore ano kia heke tetahi.
    ///
    ///
    /// Tirohia te [`ptr::replace`] mo nga awangawanga haumaru me nga tauira.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `replace`.
        unsafe { replace(self, src) }
    }

    /// Hurihia nga uara i nga waahi e rua ka taea te whakarereke o te momo kotahi, me te kore e whakakorehia te tikanga.
    /// Ka inaki pea, kaore i te `mem::swap` he orite ke.
    ///
    /// Tirohia te [`ptr::swap`] mo nga awangawanga haumaru me nga tauira.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `swap`.
        unsafe { swap(self, with) }
    }

    /// Computes te wāhikē e hiahia ki te kia tono ki te atatohu i roto i te tikanga ki te hanga i hāngai ai ki `align`.
    ///
    /// Mena kaore e taea te whakahua i te tohu, ka hoki mai te whakatinanatanga ki te `usize::MAX`.
    /// Ka whakaaetia kia whakatinana te *hoki tonu* i te `usize::MAX`.
    /// Ko nga mahi a to algorithm anake ka taea te whakawhirinaki kia pai te whakamahi i te utu i konei, kaua ko tona tika.
    ///
    /// Ko te wāhikē te whakahuatia i roto i te maha o ngā huānga `T`, a kore ngā paita.Ko te uara i whakahokia mai ka taea te whakamahi me te tikanga `wrapping_add`.
    ///
    /// Kaore he tohu taurangi ahakoa he aha te whakautu i te atatohu kaore e kaha ki te waipuke, ka neke atu ranei ki tua atu o te waahanga kua tohua e te tohu.
    ///
    /// Kei te kaiwaea te tikanga kia tika te whakahoki mai i nga utu katoa i tua atu i te whakaoronga.
    ///
    /// # Panics
    ///
    /// Ko te mahi panics mena kaore te `align` i te mana-o-rua.
    ///
    /// # Examples
    ///
    /// Whakauru `u8` pātata rite `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // i te mea ka taea te tohu ki te tohu ma te `offset`, ka tohu i waho o te tohatoha
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // HAUMARU: Kua `align` kua takina ki te waiho i te mana o te 2 i runga ake
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Whakahokia te roa o te wāhanga raw.
    ///
    /// Ko te uara i whakahokia ko te maha o nga **huanga**, kaua ko te maha o nga paita.
    ///
    /// He ahuru tenei mahi, ahakoa kaore e taea te tuku i te poro mata ki tetahi tohutoro poro no te mea he koretake, he taurite ranei te tohu.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: he haumaru tenei na te mea he rite te whakatakotoranga o te `*const [T]` me te `FatPtr<T>`.
            // Ma te `std` anake e ahei te kii i tenei oati.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Whakahokia te atatohu raw ki moka o te wāhanga.
    ///
    /// He rite tenei ki te maka `self` ki te `*mut T`, engari ko te momo-haumaru.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Whakahoki ai i te tohu atawhai ki tetahi waahanga waahanga waahanga ranei, me te kore e tirotiro i nga rohe.
    ///
    /// Ko te waeatanga i tenei tikanga ma te tohu taurangi-kore-kore ka kore e whakakorehia te `self` he *[whanonga kore kua tautuhia]* ahakoa kaore i te whakamahia te tohu ki runga.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: ma te kaikaranga e whakarite kia ngoikore te `self` me te `index`-rohe.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Whakahoki ai i te `None` mena he kore noa te tohu, kaore ranei ka hoki mai i tetahi waahanga tohaina ki te uara kua takaia ki te `Some`.
    /// He rereke ki te [`as_ref`], kaore tenei e hiahia kia tiimata te uara.
    ///
    /// Mo te hoa whakarereke tirohia te [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ka waea ana koe ki tenei tikanga, me whakarite e koe *me* te tohu he NULL *ranei* he pono nga mea katoa e whai ake nei:
    ///
    /// * Ko te tohu he [valid] pea mo te panui mo te `ptr.len() * mem::size_of::<T>()` maha paita, a me tika te whakariterite.Ko te tikanga tenei:
    ///
    ///     * Ko te whānuitanga o te whakamahara o tenei poro me uru ki roto i te ahanoa kotahi kua tohaina!
    ///       Kaore e taea e nga poro te toro atu ki nga taonga maha kua tohaina.
    ///
    ///     * Me taatahi te tohu ki nga poro-kore-roa.
    ///     Ko tetahi take mo tenei ko te pai ake o te whakatakotoranga whakatakotoranga whakatakotoranga whakapae ka whakawhirinaki ki nga tohutoro (tae atu ki nga poro o te roa) kia haangai ana kia kaua e whakakorehia ki te wehewehe i etahi atu o nga raraunga.
    ///
    ///     Ka taea e koe te tiki i tetahi tohu tohu ka taea te whakamahi hei `data` mo nga poro-kore-roa te whakamahi i te [`NonNull::dangling()`].
    ///
    /// * Ko te kohinga katoa `ptr.len() * mem::size_of::<T>()` o te poro kaua kia rahi ake i te `isize::MAX`.
    ///   Tirohia nga tuhinga ahuru o [`pointer::offset`].
    ///
    /// * Me matua whakamana e koe nga ture whakamaanamana a Rust, mai i te wa i hoki mai ai `'a` he mea totika te kowhiri me te kore e whakaatu i nga wa katoa o te raraunga.
    ///   I roto i ngā, mo te roanga o tenei ra, ko te mahara nga ngā atatohu ki pau kore kia mutated (anake roto `UnsafeCell`).
    ///
    /// Ka pa tenei ahakoa kaore te hua o tenei tikanga i te whakamahia!
    ///
    /// Tirohia hoki [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Whakahoki ai i te `None` mena he kore te tohu, ka kore ranei ka hoki mai i tetahi waahanga motuhake ki te uara kua takaia ki te `Some`.
    /// He rereke ki te [`as_mut`], kaore tenei e hiahia kia tiimata te uara.
    ///
    /// Hoki te tauira tiritahi kite [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Ka waea ana koe ki tenei tikanga, me whakarite e koe *me* te tohu he NULL *ranei* he pono nga mea katoa e whai ake nei:
    ///
    /// * Ko te tohu he [valid] pea mo te panui me te tuhi mo te `ptr.len() * mem::size_of::<T>()` maha paita, a me tika te whakariterite.Te tikanga o tēnei i roto i ngā:
    ///
    ///     * Ko te whānuitanga o te whakamahara o tenei poro me uru ki roto i te ahanoa kotahi kua tohaina!
    ///       Kaore e taea e nga poro te toro atu ki nga taonga maha kua tohaina.
    ///
    ///     * Me taatahi te tohu ki nga poro-kore-roa.
    ///     Ko tetahi take mo tenei ko te pai ake o te whakatakotoranga whakatakotoranga whakatakotoranga whakapae ka whakawhirinaki ki nga tohutoro (tae atu ki nga poro o te roa) kia haangai ana kia kaua e whakakorehia ki te wehewehe i etahi atu o nga raraunga.
    ///
    ///     Ka taea e koe te tiki i tetahi tohu tohu ka taea te whakamahi hei `data` mo nga poro-kore-roa te whakamahi i te [`NonNull::dangling()`].
    ///
    /// * Ko te kohinga katoa `ptr.len() * mem::size_of::<T>()` o te poro kaua kia rahi ake i te `isize::MAX`.
    ///   Tirohia nga tuhinga ahuru o [`pointer::offset`].
    ///
    /// * Me matua whakamana e koe nga ture whakamaanamana a Rust, mai i te wa i hoki mai ai `'a` he mea totika te kowhiri me te kore e whakaatu i nga wa katoa o te raraunga.
    ///   Ina koa, mo te roanga o tenei tau, ko te whakamaharatanga e tohu ana te tohu ki te kore e ahei kia uru atu (panuihia kia tuhia ranei) ma tetahi atu tohu tohu.
    ///
    /// Ka pa tenei ahakoa kaore te hua o tenei tikanga i te whakamahia!
    ///
    /// Tirohia hoki [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Te tauritenga mo nga tohu tohu
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}