//! Nga momo e tohu ana i nga raraunga ki tona waahi hei maumahara.
//!
//! I etahi wa ka whai kiko ki te whai i nga taonga e kore e neke, i te mea kaore te rereketanga o te mahara ka rereke, ka taea te whakawhirinaki.
//! Ko tetahi tauira pai mo tera ahuatanga ko te hanga i nga ara toro-takitahi, na te neke i tetahi mea me nga tohu ki a ia ano ka kore e ahei, ka kore pea e tautuhi.
//!
//! I te taumata tiketike, ma te [`Pin<P>`] e whakarite kia tau te maataki o tetahi tohu tohu `P`, na te mea kaore e taea te neke ki tetahi atu waahi, kaore hoki e taea te whakawhitiwhiti i tana mahara kia hinga ra ano.E kii ana maatau ko te kaitautoko ko "pinned".Ka tino mohio nga mea ka korerohia nga momo whakauru i nga pine me nga taatai-kore;[see below](#projections-and-structural-pinning) mo etahi atu korero taipitopito.
//!
//! Na te taunoa, ko nga momo katoa i te Rust ka neke.
//! Ma te Rust e tuku nga momo-uara katoa, a ko nga momo tohu-noa penei i te [`Box<T>`] me te `&mut T` ka ahei te whakakapi me te neke i nga uara kei roto: ka taea e koe te neke atu i te [`Box<T>`], ka taea ranei te whakamahi i te [`mem::swap`].
//! [`Pin<P>`] takai ai i te momo atatohu `P`, na [`Pin`]`<`['Pouaka`]`<T>> `rite tonu ki te mahi
//!
//! [`Box<T>`]: when a [`Pin`]`<`[Pouaka`]`<T>> `ka heke, ka pera ano nga korero o roto, ka riro te maumahara
//!
//! whakawhitingaWaihoki, ko te [`Pin`]`<&mut T>` he rite tonu ki te `&mut T`.Heoi, kaore a [`Pin<P>`] e tuku i nga kaihoko kia whiwhi i te [`Box<T>`], i te `&mut T` ranei ki nga raraunga kua taapirihia, e tohu ana kaore e taea e koe te whakamahi i nga whakahaere penei i te [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` hiahia `&mut T`, engari kaore e taea te tiki.
//!     // Kei te piri matou, kaore e taea te huri i nga korero o enei korero.
//!     // Ka taea e maatau te whakamahi i te `Pin::get_unchecked_mut`, engari kaore i te haumaru mo tetahi take:
//!     // kaore e whakaaehia kia whakamahia e maatau mo te neke atu o nga mea mai i te `Pin`.
//! }
//! ```
//!
//! He mea tika kia korero ano ko [`Pin<P>`] kaore *e huri* i te meka e whakaarohia ana e te kaitoha Rust nga momo nekehanga katoa.[`mem::swap`] ka karanga tonu mo tetahi `T`.Engari, [`Pin<P>`] ka aukati i etahi *uara*(i tohua e nga tohu tohu kua takaihia ki te [`Pin<P>`]) mai i te neke ma te kore e taea te karanga i nga tikanga e hiahia ana kia `&mut T` ki a raatau (peera ki te [`mem::swap`]).
//!
//! [`Pin<P>`] ka taea te whakamahi hei takai i tetahi momo atatohu `P`, a na te mea e hono ana ki te [`Deref`] me te [`DerefMut`].He [`Pin<P>`] e whakaarohia ana ko `P: Deref` hei "`P`-style pointer" ki te `P::Target` kua pinea-no reira, he [`Pin`]`<"[Pouaka`]`<T>> `he tohu kei a ia ki te `T` pine, me te [` Pin`]`<"[`Rc`]`<T>> `he tohu tohu-tohuhia ki te `T` titi.
//! Hoki tika, whakawhirinaki [`Pin<P>`] i nga implementations o [`Deref`] ko [`DerefMut`] kore ki te neke i roto i o ratou tawhā `self`, a ake anake ki te hoki mai te atatohu ki raraunga pinea ina e huaina ratou i runga i te atatohu pinea.
//!
//! # `Unpin`
//!
//! He maha nga momo ka neke haere noa, ahakoa ka pinea, na te mea kaore i te whakawhirinaki ki te whai i tetahi wahitau pumau.Kei roto katoa nga momo momo (penei i te [`bool`], [`i32`], me nga tohutoro) tae atu ki nga momo kei roto noa i enei momo.Ko nga momo kaore e aro ki te paina te whakamahi i te [`Unpin`] aunoa-trait, ka whakakore i te paanga o [`Pin<P>`].
//! Mo `T: Unpin`, [`Pin`]`<`[Pouaka`]`<T>> `me te mahi [`Box<T>`] rite, peera i te [` Pin`]`<&mut T>` me `&mut T`.
//!
//! Note e titi me [`Unpin`] anake pā te oka-ki te pato `P::Target`, e kore te momo atatohu `P` ano e Ua takai i [`Pin<P>`].Hei tauira, ahakoa ko te [`Box<T>`] ko te [`Unpin`] kaore he painga ki te whanonga o [`Pin`]`<'[Pouaka`]`<T>>`(konei, `T` te tohu-ki te momo).
//!
//! # Tauira: whaiaro-referential struct
//!
//! I mua i to taipitopito taipitopito hei whakamaarama i nga tohu taurangi me nga whiringa e pa ana ki te `Pin<T>`, ka korerohia e maatau etahi tauira mo te whakamahi.
//! Kia waatea ki [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // He hangahanga korero-whaiaro tenei na te mea e tohu ana te mara poro ki te waahanga raraunga.
//! // Kaore e taea e taatau te whakamohio atu ki te kaitautu mo tera me te tohutoro noa, na te mea kaore e taea te whakaatu i tenei tauira me nga tikanga tuku nama.
//! //
//! // Ka whakamahia he tohu tika, ahakoa tetahi e mohiotia ana kaore i te kore, i te mea e mohio ana taatau kei te tohu ki te aho.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Kia kore e neke nga raraunga ka hoki mai te mahi, ka waiho ki te puranga ka noho mo te wa katoa o te mea, ana ko te huarahi anake kia uru atu ma te tohu tika ki a ia.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // hanga noa tatou i te atatohu i te wa kua pumau nga korero ki te kore kua neke ke i mua o ta maatau tiimata
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // e mohio ana maatau he haumaru tenei na te mea ko te whakarereke i tetahi mara kaore e neke katoa te hanganga
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Me tohu te tohu ki te waahi tika, i te mea kaore ano kia neke te hanganga.
//! //
//! // I tenei wa, ka waatea noa taatau ki te neke haere i te tohu.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Na te mea kaore te momo e whakamahi i te Unpin, ka kore tenei e whakahiato:
//! // kia mut hou_unm oho= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Tauira: rarangi honohono hono-hono
//!
//! I roto i te raarangi whakauru honohono-hono, kaore te kohinga e tohatoha i te mahara mo nga waahanga ake.
//! Ko te tohatoha e whakahaerehia ana e nga kaihoko, ka taea e nga waahanga te noho ki runga i te anga taapiri e poto ake ana te ora i te kohinga.
//!
//! Hei hanga i tenei mahi, he atatohu ki tona mua me te mono i roto i te rārangi katoa huānga.taea anake te tāpiri Elements ina e pinea ratou, no te mea neke te huānga a tawhio noa e whakakahore nga atatohu.Ano hoki, ko te whakatinanatanga o te [`Drop`] o te waahanga hono hono ka taapiri i nga tohu o tona mua me tana kairiwhi ki te tango i a ia mai i te raarangi.
//!
//! He mea nui, me kaha ki te whakawhirinaki ki te [`drop`] e karangahia ana.Mena ka taea te tango i tetahi waahanga, ki te kore ranei e whakakorea me te kore e karanga i te [`drop`], ka tohu nga tohu ki roto mai i ona waahanga tata, ka pakaru te hanganga raraunga.
//!
//! No reira, he tohu taapiri me te [`maturuturunga`] taurangi-hono.
//!
//! # `Drop` guarantee
//!
//! Ko te kaupapa o te pine ko te mea ka taea ki te whakawhirinaki ki te whakanoho i etahi o nga raraunga hei maumahara.
//! Hei mahi i tenei, kaore i te neke noa i nga raraunga ka aukatia;te whakawhitinga, te whakahou, te kore ranei i te whakamaumahara i whakamahia hei penapena i nga raraunga ka aukatihia, ano hoki.
//! Ano hoki, mo nga raraunga kua taapirihia me mau tonu e koe te kaimanaaki *e kore e whakamaumahara, kia whakahoutia ranei tana mahara mai i te wa e titi ana kia tae mai ra ano ka kiia te [`drop`]* Anake kotahi hoki [`drop`] panics ranei, kia makamaka ai te mahara.
//!
//! Ko te maumahara he "invalidated" ma te whakawhitiwhitinga, engari ma te whakakapi i te [`Some(v)`] na [`None`], ka karanga ranei i te [`Vec::set_len`] ki te "kill" etahi waahanga mai i te vector.Ka taea te whakahoki ano ma te whakamahi i te [`ptr::write`] ki te tuhirua me te kore e karanga i te kaiwhakaahua tuatahi.Kaore tetahi o enei e whakaaehia mo nga raraunga kua taatatia kia kore e waea atu ki te [`drop`].
//!
//! Koinei tonu te momo taurangi e tika ana kia mahi tika te raarangi whakauru whakauru mai i te waahanga o mua.
//!
//! Pānui e tenei taurangi e *kore* te tikanga e kore e taua mahara turuturu!Kei te pai tonu te karanga atu ki te [`drop`] i runga i te mea kua titi (hei tauira, ka taea tonu e koe te karanga [`mem::forget`] i runga i te ['Pin`]`<' [Pouaka`]`<T>> `).I roto i nga tauira o te raarangi hono-hono, ka noho noa tera waahanga ki te raarangi.Heoi e kore kia koutou noa ranei whakamahi anō i te rokiroki *kahore karanga [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Ki te titi o koutou whakamahinga momo (pēnei i te tauira e rua i runga ake), whai koe ki te kia tupato, ka whakatinana i [`Drop`].Ko te mahi [`drop`] he `&mut self`, engari ka kiia tenei ko *ahakoa i taatahia to momo*!He rite ki te mea i huaina noa te kaiwhakatautau [`Pin::get_unchecked_mut`].
//!
//! Kaore tenei e raru i roto i te waehere ahuru na te mea ko te whakatinana i tetahi momo e whakawhirinaki ana ki te tarai ka hiahiatia he waehere kore haumaru, engari kia maarama ko te whakatau ki te whakamahi i te pene i to momo (hei tauira ma te whakamahi i tetahi mahi i runga i ["Pin`]"<&Ko koe ano>`or [`Pin`] `<&mut Self>`) he hua ano mo to [`Drop`] whakatinanatanga hoki: mena i taea te pinea tetahi o to momo, me tohu e koe te [`Drop`] me te tango i te [Pin]] "<&mut Whaiaro>`.
//!
//!
//! Hei tauira, i taea e koe te whakatinana i `Drop` e whai ake:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` he pai na te mea e mohio ana taatau kaore e whakamahia ano tenei uara i muri i te tangohanga.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Ko te waehere taka taka ka haere ki konei.
//!         }
//!     }
//! }
//! ```
//!
//! He te mahi `inner_drop` te momo e [`drop`] kia *i*, na tenei hanga tino e kore e koutou tūpono whakamahi `self`/`this` i te ara e kei roto i te pakanga ki te titi.
//!
//! Ano hoki, mena he momo `#[repr(packed)]` to momo, ka huri noa te kaiwhakangungu i nga mara kia taea ai e raatau te maka.Ka oti pea tena mo nga mara e tika ana te whakatika.I te mutunga, kaore e taea e koe te whakamahi i te pene me te momo `#[repr(packed)]`.
//!
//! # Matapae me te Tino Hanga
//!
//! I a koe e mahi ana me nga taera titi, ka puta te patai me pehea e uru ai te tangata ki nga mara o taua waahanga me te tikanga e tika ana te [Pin]] <&Mut Struct>`.
//! Ko te huarahi noa ko te tuhi i nga tikanga kaiawhina (e kiia ana ko *matapae*) ka huri i te ['Pin`]`<&Mut Struct>`hei tohu ki te mara, engari he aha te momo o taua tohutoro?He [`Pin`] '<&mut Field>` `&mut Field` ranei?
//! He rite ano te patai me nga waahi o te `enum`, ana hoki ka whakaarohia nga momo container/wrapper penei i te [`Vec<T>`], [`Box<T>`], te [`RefCell<T>`] ranei.
//! (Ko tenei patai e pa ana ki nga tohutoro e taea ana te whakarereke me te tohatoha, ka whakamahia noa e maatau etahi atu waahanga ka taea te huri i konei hei whakaahua.)
//!
//! Ko te mea ke ma te kaituhi o te hanganga raraunga e whakatau mena ko te tohu i honoa mo tetahi mara kua huri ["Pin`]"<&Mut Struct>`into [`Pin`] "<&mut Field>` or `&mut Field`.Heoi ano etahi herenga, engari ko te mea nui ko te *tutukitanga*:
//! katoa nga mara ka taea te *ka* whakaatuhia ki te tohutoro pine,*me* te tango i te pineo hei waahanga o te matapae.
//! Mena ka mahia nga mea e rua mo te mara kotahi, kaare pea he ngoikore!
//!
//! Ko koe te kaituhi o te hanganga raraunga hei whakatau mo ia mara mena ko te tarai "propagates" ki tenei mara kaore ranei.
//! Ko te pine e toha ana ka kiia ko te "structural", na te mea e whai ana i te hanganga o te momo.
//! I roto i te tekiona e whai ake nei, whakaahua tatou nga whakaaro e whai ki te kia hanga mo rānei kōwhiringa.
//!
//! ## Ko te pine *ehara i te* hanganga mo `field`
//!
//! Te ahua nei he rereke te whakaaro kaore pea i te pinea te mara o te pouherehere, engari koira te kowhiringa maamaa: mena kaore i hangaia tetahi ['Pin`]"<&mut Field>`, kaore he mea e he!No reira, ki te whakaaro koe kaore kau he mahinga a etahi mara, ko taau noa iho kia kaua e hanga e koe he tohu tohu ki taua mara.
//!
//! Ko nga mara kaore he taatai hanganga tera pea he tikanga matapae ka huri i te ["Pin`]" <&Mut Struct>> ki te `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // He pai tenei na te mea kaore te `field` e kiia he pine.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Akene he `impl Unpin for Struct`*ahakoa* ko te momo `field` ehara i te [`Unpin`].Ko nga whakaaro o tera momo mo te taatai kaore e whai kiko ana kaore rawa he [`Pin`]"<&mut Field>` i hangaia.
//!
//! ## Ko te pine *he* hanganga mo `field`
//!
//! Ko tetahi atu kowhiringa ko te whakatau ko te tohu i te "structural" mo te `field`, ko te tikanga mena ka whakairihia te waahanga ka pera ano te mara.
//!
//! Tenei taea tuhi i te ngä e hangaia e te [`Pin`]`<&mut Field>`, ko te kupu whakaatu i pinea te mara te:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // He pai tenei na te mea kua pinea te `field` i te wa e `self` ana.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Heoi, ko te taatai hanganga me etahi whakaritenga taapiri:
//!
//! 1. Me [`Unpin`] noa iho te hanganga mena he [`Unpin`] katoa nga waahanga hanganga.Koinei te taunoa, engari ko te [`Unpin`] he trait haumaru, na te mea ko te kaituhi o te hanganga ko to kawenga *kaua* ki te taapiri i tetahi mea penei i te `impl<T> Unpin for Struct<T>`.
//! (Kia kite koe ko te taapiri i te mahinga whakaari me tohu waehere kore haumaru, na te mea ko te [`Unpin`] he trait haumaru kore e takahi i te kaupapa me awangawanga koe mo tetahi o enei mena ka whakamahi koe i te `kore haumaru`.)
//! 2. Ko te kaiwhakangungu o te hanganga kaua e neke atu i nga waahanga hangahanga mai i tana tautohe.Koinei tonu te tohu i whakaarahia ake i te [previous section][drop-impl]: `drop` e `&mut self`, engari ko te hanganga (ana ko ana mara) kua taatahia i mua atu.
//!     Me oati koe kaore koe e neke i tetahi mara i roto i to whakamahinga [`Drop`].
//!     I roto i ngā, rite faataa mua, tenei tikanga e me to koutou struct *kore* e `#[repr(packed)]`.
//!     Tirohia tera waahanga mo te tuhi [`drop`] kia pai ai te awhina a te kaiwhakaputu kia kore e whatiia e koe te pini.
//! 3. Kia mahara ki te tautoko i te [`Drop` guarantee][drop-guarantee]:
//!     pinea kotahi te tou struct, e kore te mahara e kei roto i te ihirangi he tuhiruatia deallocated ranei kahore karanga destructors o te ihirangi.
//!     He uaua tenei, na [`VecDeque<T>`] i kite: ka kore e taea e te kaipahua o [`VecDeque<T>`] te karanga [`drop`] ki nga waahanga katoa mena ko tetahi o nga kaikorero panics.Ka takahi tenei i te taurangi [`Drop`], na te mea ka taea te neke atu i nga waahanga kaore ano kia karangahia to raatau kaitukino.(Kare he tohu a te [`VecDeque<T>`], na reira kaore tenei e raru.)
//! 4. Kaua e whakaekea e koe etahi atu mahinga ka arahi pea i nga raraunga ka nekehia atu i nga waahanga hanganga ka tohua to momo.Hei tauira, mena he [`Option<T>`] kei roto i te kaihanga me te mea he mahi 'tango` me te momo `fn(Pin<&mut Struct<T>>) -> Option<T>`, ka taea te whakamahi i taua mahi ki te neke i te `T` mai i te `Struct<T>` kua taaina-ko te tikanga kaore e taea te tarai mo te mara e pupuri ana i tenei. raraunga
//!
//!     Mo tetahi tauira uaua ake mo te neke i nga raraunga mai i te momo titi, whakaarohia mena he `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` te tikanga X01.
//!     Ka taea e maatau tenei:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     He parekura tenei, ko te tikanga ka taea e maatau te tohu i nga korero o te [`RefCell<T>`] (ma te whakamahi i te `RefCell::get_pin_mut`) ka neke i taua kaupapa ma te whakamahi i te tohutoro ka taea i muri mai.
//!
//! ## Examples
//!
//! Mo te momo penei i te [`Vec<T>`], ko nga mea e rua e taea ana (taatai hanganga kaore ranei) e whai kiko.
//! Ko te [`Vec<T>`] me te taatai hanganga pea he tikanga `get_pin`/`get_pin_mut` ki te tiki tohu tohu ki nga waahanga.Heoi, i taea *kore* tukua reira karanga [`pop`][Vec::pop] i runga i te [`Vec<T>`] pinea hoki e neke e te (te hanganga pinea) tirotiro!Kaore hoki i taea te tuku [`push`][Vec::push], tera pea ka huri ano ka neke ano nga korero.
//!
//! Ko te [`Vec<T>`] kaore he taatai hanganga ka taea pea te `impl<T> Unpin for Vec<T>`, na te mea kaore i te pinea nga tuhinga me te [`Vec<T>`] ano e pai ana me te neke ano hoki.
//! I taua wa ko te tarai kaore noa iho he painga ki te vector.
//!
//! I roto i te wharepukapuka paerewa, ko nga momo atatohu kaore he pene hanganga, no reira kaore ratou e kii i te matapae i te pini.Koinei te take i mau ai a `Box<T>: Unpin` mo te `T` katoa.
//! He mea tika ki te mahi i tenei mo nga momo tohu, na te mea ko te neke i te `Box<T>` kaore i te neke i te `T`: ka taea te neke noa te [`Box<T>`] (aka `Unpin`) ahakoa kaore te `T`.I roto i te meka, ara [`Pin`]`<`[`Box`] `<T>>`me [`Pin`] `<&mut T>` he [`Unpin`] tonu, mo nga take ano: ko o raatau (te `T`) kua taapirihia, engari ko nga tohu ano ka taea te neke me te kore e neke nga raraunga i titi.
//! Mo te [`Box<T>`] me te [`Pin`]`<'' Pouaka`]`<T>>`, mena ka titi te ihirangi he motuhake motuhake mena kua poua te tohu, ko te tikanga ko te tohu ehara i te * hanganga.
//!
//! A, no te whakamahi i te [`Future`] whakakotahi, ka hiahia koe ki te taatai hanganga mo te futures i ohia, na te mea me tiki e koe he tohutoro tohu ki a raatau kia kiia ko [`poll`].
//! Engari ki te mea kei i to kaiwhakarato etahi atu korero kaore e hiahiatia ana kia pinea, ka taea e koe te hanga aua mara kaore i te hanganga, ka uru noa atu ki a raatau me te korero whakarereke ahakoa kei a koe noa te "Pin" "<&mut Self>" (penei rite i roto i to koutou ake whakatinanatanga [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// He tohu atawhai
///
/// He takai tenei huri noa i te momo tohu tohu hei tohu i taua tohu "pin" hei aarai, kia kore ai e neke te uara kua tohua e taua tohu ahan kia kore e whakamahia te [`Unpin`].
///
///
/// *Tirohia nga tuhinga [`pin` module] mo te whakamaarama o te paina.*
///
/// [`pin` module]: self
///
// Note: ko te `Clone` ka puta i raro ake nei ka puta te koretake i te mea ka taea te whakamahi
// `Clone` mo nga tohutoro mutable.
// Tirohia te <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> mo etahi atu korero taipitopito.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// E kore e nga implementations e whai ake nei i takea i roto i te tikanga ki te karo i ngā take ora.
// `&self.pointer` kaua e uru ki nga whakatinanatanga trait kore whirinaki.
//
// Tirohia te <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> mo etahi atu korero taipitopito.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Hangaia he `Pin<P>` hou huri noa i te tohu ki etahi raraunga o te momo e whakamahi [`Unpin`].
    ///
    /// Kaore i te ahua ki te `Pin::new_unchecked`, he pai tenei tikanga na te mea ka tohu te atatohu `P` ki te momo [`Unpin`], ka whakakorehia nga tohu tohu.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SAFETY: ko te uara i tohua ko `Unpin`, ana kaore he whakaritenga
        // huri noa i te pine.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Ka wetewetehia tenei `Pin<P>` e whakahoki ana i te tohu tohu o raro.
    ///
    /// Ko te tikanga ko nga raraunga kei roto i tenei `Pin` ko te [`Unpin`] kia ahei ai taatau ki te aro atu ki nga kaiwhakawhiwhi pene ka wetekia.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Hangaia he `Pin<P>` hou huri noa i te tohutoro ki etahi raraunga o te momo ka taea te whakamahi `Unpin` kaore ranei.
    ///
    /// Mena ka whakakorehia e `pointer` tetahi momo `Unpin`, me whakamahi ke te `Pin::new`.
    ///
    /// # Safety
    ///
    /// Kaore i te ahuru tenei kaihanga na te mea kaore e taea e taatau te tohu ko nga raraunga i tohua e `pointer` kua taapirihia, te tikanga kaore e nekehia nga raraunga kaore ranei i mana te rokiroki kia taka ra ano.
    /// Mena ko te `Pin<P>` hangaia kaore i te kii ko nga raraunga `P` e tohu ana kua piri, he takahi i te kirimana API a ka arahi pea i te whanonga kore i nga mahi (safe) i muri mai.
    ///
    /// Ma te whakamahi i tenei tikanga, kei te hanga koe i te promise mo nga whakamahinga `P::Deref` me `P::DerefMut`, mena kei te kitea.
    /// Tino nui, e kore me ratou neke atu o ratou tohenga `self`: ka karanga `Pin::as_mut` ko `Pin::as_ref` `DerefMut::deref_mut` ko `Deref::deref`*i runga i te atatohu pinea* ka titau enei tikanga ki te tautokona i te invariants titi.
    /// Ano hoki, ma te karanga i tenei tikanga ka tutakina e koe a promise kaore e neke atu ano te tohutoro `P` ki a koe;ina koa, me kaua e taea te tiki `&mut P::Target` ka neke atu i taua tohutoro (ma te whakamahi, hei tauira [`mem::swap`]).
    ///
    ///
    /// Hei tauira, ko te karanga i te `Pin::new_unchecked` i runga i te `&'a mut T` kaore i te ahuru na te mea ka taea e koe te titi mo te wa katoa `'a`, kaore o mana ki a koe mena ka tiakina kia mutu ana te `'a`:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Ma te tikanga ko te pointee `a` kaore e neke ano.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // I hurihia te wahitau o `a` ki te "b`'s stack stack, no reira ka nekehia te `a` ahakoa kua taatahia e maatau!Kua takahia e matou te kirimana API pinea.
    /////
    /// }
    /// ```
    ///
    /// Ko te uara, ka pinea ana, me noho tonu ki te poua mo te wa katoa (ki te kore te `Unpin` e whakamahi i tana momo).
    ///
    /// Waihoki, ko te karanga i te `Pin::new_unchecked` i runga i te `Rc<T>` kaore i te ahuru na te mea ka taea pea he rerenga ingoa mo nga raraunga kotahi kaore e herea ki nga here tautuhi.
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Ko te tikanga tenei kaore e taea e te tohu te neke ano.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Na, mena ko te `x` anake te tohutoro, ka taea te whakarereke i nga korero i tohua e maatau ki runga, hei whakamahi mo te neke ke i ta tatou i kite ai i roto i te tauira o mua.
    ///     // Kua takahia e matou te kirimana API pinea.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Ka whiwhi tohutoro tiri mai i tenei tohu tohu tohu.
    ///
    /// He tikanga whanui tenei mai i te `&Pin<Pointer<T>>` ki te `Pin<&T>`.
    /// He haumaru na te mea, hei waahanga o te kirimana o `Pin::new_unchecked`, kaore e taea te neke te kaimutu whai muri i te hanganga o te `Pin<Pointer<T>>`.
    ///
    /// "Malicious" Kei te pera ano kingi implementations o `Pointer::Deref` i te taha o te kirimana o `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SAFETY: tirohia nga tuhinga mo tenei mahi
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Ka wetewetehia tenei `Pin<P>` e whakahoki ana i te tohu tohu o raro.
    ///
    /// # Safety
    ///
    /// He haumaru tenei mahi.Me oati koe ka haere tonu koe ki te atawhai i te atatohu `P` hei pinea i muri i to karanga i tenei mahi, kia taea ai te pupuri i nga kaiarahi i te momo `Pin`.
    /// Mena kaore te waehere e whakamahi ana i te `P` e mau tonu ana ki te pupuri i nga kaitautoko peera he takahi i te kirimana API a ka arahi pea i te whanonga kore i roto i nga mahi (safe) i muri mai.
    ///
    ///
    /// Mena he [`Unpin`] nga maataapuna korero, me whakamahi [`Pin::into_inner`] hei utu.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Whiwhi ai i te tohutoro ka taea te huri i te atatohu titi.
    ///
    /// Ko te tikanga kano ki te haere atu i `&mut Pin<Pointer<T>>` ki `Pin<&mut T>` tenei.
    /// He haumaru na te mea, hei waahanga o te kirimana o `Pin::new_unchecked`, kaore e taea te neke te kaimutu whai muri i te hanganga o te `Pin<Pointer<T>>`.
    ///
    /// "Malicious" ko nga whakatinanatanga o `Pointer::DerefMut` ka whakakorehia ano e te kirimana o `Pin::new_unchecked`.
    ///
    /// He whai hua tenei tikanga ina maha ana waea ki nga mahi ka pau i te momo titi.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // rave i te tahi
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` ka pau i te `self`, na utaina te `Pin<&mut Self>` ma te `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SAFETY: tirohia nga tuhinga mo tenei mahi
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Ka tohaina he uara hou ki te maharatanga kei muri o te tohutoro kua pinea.
    ///
    /// Ka taupoki tenei i nga raraunga kua taapirihia, engari e pai ana: ka oma te kaitukino i mua i te tuhinga, no reira kaore he takoha tohu e takahia.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Hangaia he pine hou ma te mahere i te uara o roto.
    ///
    /// Hei tauira, ki te hiahia koe ki te tiki i te `Pin` o tetahi waahanga, ka taea e koe te whakamahi i tenei ki te whakauru ki taua mara i roto i te raina waehere kotahi.
    /// Heoi, i reira e rave rahi gotchas ki enei "pinning projections";
    /// tirohia te tuhinga [`pin` module] mo etahi atu taipitopito mo tera kaupapa.
    ///
    /// # Safety
    ///
    /// He haumaru tenei mahi.
    /// Me oati koe kaore e neke nga korero ka whakahokia mai e koe i te mea kaore e neke te uara tautohe (hei tauira, na te mea koina tetahi o nga mara o taua uara), me te kore hoki e neke atu i nga tohenga e tae atu ana ki a koe te mahi o roto.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SAFETY: ko te kirimana ahuru mo te `new_unchecked` me noho
        // i tautokohia e te kaiwaea.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Ka puta he tohutoro tiri mai i te pine.
    ///
    /// He haumaru tenei na te mea kaore e taea te neke atu i tetahi korero tohanga.
    /// Akene he ahua ano kei konei he raru me te rerekee o roto: ina hoki, ka taea * te neke atu i te `T` mai i te `&RefCell<T>`.
    /// Heoi, ehara tenei i te raru mena kaore ano kia puta he `Pin<&T>` e tohu ana ki nga korero ano, a kaore a `RefCell<T>` e tuku ki a koe ki te hanga tohu tohu ki ona korero.
    ///
    /// Tirohia te te kōrero i runga i ["pinning projections"] mo atu kōrero.
    ///
    /// Note: Ko `Pin` ano hoki te whakamahi i te `Deref` ki te whaainga, ka taea te whakamahi kia uru atu ki te uara o roto.
    /// Heoi, ko te `Deref` anake e whakarato ana i te tohutoro ka ora mo te roa o te nama o te `Pin`, kaore i te wa katoa o te `Pin` ake.
    /// Ma tenei tikanga e taea ai te huri i te `Pin` hei tohutoro me te roanga o te ora ki te `Pin` taketake.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Ka hurihia tenei `Pin<&mut T>` ki te `Pin<&T>` me te wa katoa.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Ka kitea he korero whakarereke ki nga raraunga o roto o tenei `Pin`.
    ///
    /// Ko te tikanga ko nga raraunga kei roto i tenei `Pin` ko te `Unpin`.
    ///
    /// Note: Ko `Pin` ano hoki te whakamahi i te `DerefMut` ki nga raraunga, ka taea te whakamahi kia uru atu ki te uara o roto.
    /// Heoi, ko te `DerefMut` anake e whakarato ana i te tohutoro ka ora mo te roa o te nama o te `Pin`, kaore i te wa katoa o te `Pin` ake.
    ///
    /// Ma tenei tikanga e taea ai te huri i te `Pin` hei tohutoro me te roanga o te ora ki te `Pin` taketake.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Ka kitea he korero whakarereke ki nga raraunga o roto o tenei `Pin`.
    ///
    /// # Safety
    ///
    /// He haumaru tenei mahi.
    /// Me oati koe kaore rawa e nekehia atu e koe nga raraunga mai i te tohutoro ka taea te tango i a koe ka karanga ana koe i tenei mahi, kia taea ai e nga kaitautoko o te momo `Pin` te pupuri.
    ///
    ///
    /// Mena he `Unpin` nga maataapuna korero, me whakamahi `Pin::get_mut` hei utu.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Hangaia he pine hou ma te mahere i te uara o roto.
    ///
    /// Hei tauira, ki te hiahia koe ki te tiki i te `Pin` o tetahi waahanga, ka taea e koe te whakamahi i tenei ki te whakauru ki taua mara i roto i te raina waehere kotahi.
    /// Heoi, i reira e rave rahi gotchas ki enei "pinning projections";
    /// tirohia te tuhinga [`pin` module] mo etahi atu taipitopito mo tera kaupapa.
    ///
    /// # Safety
    ///
    /// He haumaru tenei mahi.
    /// Me oati koe kaore e neke nga korero ka whakahokia mai e koe i te mea kaore e neke te uara tautohe (hei tauira, na te mea koina tetahi o nga mara o taua uara), me te kore hoki e neke atu i nga tohenga e tae atu ana ki a koe te mahi o roto.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SAFETY: ko te kaiwaea te kawenga mo te kore e neke i te
        // Tuhinga o mua.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SAFETY: i te mea ko te uara o `this` e kore e whai
        // Kua oho atu, he haumaru tenei karanga ki a `new_unchecked`.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Tikina mai he tohutoro pine mai i te tohutoro pateko.
    ///
    /// He haumaru tenei, na te mea kua namaa a `T` mo te roanga o te `'static`, kaore nei e mutu.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SAFETY: Ko te 'static loan taurangi kaore nga raraunga e waiho
        // moved/invalidated kia heke ra ano (kaore rawa).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Tikina he tohutoro ka taea te huri i te tohu tohu ka taea te whakarereke.
    ///
    /// He haumaru tenei, na te mea kua namaa a `T` mo te roanga o te `'static`, kaore nei e mutu.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SAFETY: Ko te 'static loan taurangi kaore nga raraunga e waiho
        // moved/invalidated kia heke ra ano (kaore rawa).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: te tikanga ko nga impl o `CoerceUnsized` e ahei ana ki te akiaki i a koe
// he momo e whakauru ana i te `Deref<Target=impl !Unpin>` ki tetahi momo e whakapae ana i te `Deref<Target=Unpin>` he koretake.
// Tetahi ahuatanga tera pea kaore i te pai mo etahi atu take, engari me aata tupato kia kaua e tukua nga kaupapa pera ki uta ki std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}