use crate::iter::FromIterator;

/// Hinga tūemi kōwae katoa i te iterator ki tetahi.
///
/// He pai ake tenei ina ka honoa ki nga tangohanga taumata-teitei, penei i te kohi ki te `Result<(), E>` e whakaaro noa ana koe ki nga hapa:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}