//! He whakatinanatanga o SipHash.

#![allow(deprecated)] // kua kore nga momo o tenei waahanga

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// He whakatinanatanga o SipHash 1-3.
///
/// Ko tēnei wā tenei te mahi hashing taunoa whakamahia e te whare pukapuka paerewa (hei tauira, whakamahia e `collections::HashMap` reira i te taunoa).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// He whakatinanatanga o SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// He whakatinanatanga o SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// Ko te SipHash he mahi whaainga whaainga-whanui: he tere te rere (whakataetae ki a Spooky me te Taone) me te tuku i te _keyed_ hashing kaha.
///
/// taea tenei te matua koe koutou tepu hae i te RNG kaha, pērā i [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// Ahakoa ko te SipHash algorithm e kiia ana he kaha tonu, kaore i te whakaarohia mo nga kaupapa cryptographic.
/// Ka rite ki taua, whakamahinga Tuhimunatanga katoa o tenei whakatinanatanga ko _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // te tini o paita kua tukatuka tatou
    state: State,  // State Hash
    tail: u64,     // te hokotai paita le
    ntail: usize,  // e hia ngā paita o te hiku e whai mana ana
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, Ko te v2 me te v1, ko te v3 e whakaatu takirua ana i roto i te algorithm, a ko nga mahi whakatinana a SipHash ka whakamahi i te vectors o v02 me v13.
    //
    // Ma te whakauru ki a raatau ki tenei ota ki te hanganga, ka taea e te kaitautu te kohikohi i etahi waahanga noa iho e pai ana mo ia.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Kawenga he tau tōpū o te momo e hiahiatia ana i te awa paita, i roto i te raupapa LE.
/// Whakamahia ai te `copy_nonoverlapping` kia waiho ai ma te kaiwhakaputu te whakaputa i tetahi huarahi whaihua ki te uta mai i tetahi wahitau kaore pea e haangai.
///
///
/// Kaore i te haumaru no te mea: kaore i tirohia te tohu tohu i te i..i+size_of(int_ty)
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// Utaina he u64 ma te whakamahi i te 7 paita o te poro paita.
/// He ahua koretake engari ko nga waea `copy_nonoverlapping` ka puta (ma te `load_int_le!`) he rahi te rahi o nga rahi ka kore e karanga i te `memcpy`, he pai mo te tere.
///
///
/// no te mea haumaru: fakahokohoko kore taki i start..start + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // taupū paita onāianei (mai i LSB) i te putanga u64
    let mut out = 0;
    if i + 3 < len {
        // SAFETY: Kaore e nui ake te `i` i te `len`, ana me kii te kaiwaea
        // e tiimata ana te tohu..tiimata + len kei roto i nga rohe.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // SAFETY: he rite ki runga ake nei.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // SAFETY: he rite ki runga ake nei.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Ka waihanga te `SipHasher` hou ki te mau taviri tuatahi e rua whakaturia ki 0.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Ka waihanga te `SipHasher` patopato e te atu te mau taviri whakaratohia.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Ka waihangahia he `SipHasher13` hou me nga ki tuatahi e rua i whakaritea ki te 0.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Ka waihangahia he `SipHasher13` kua kaiponuhia i waho i nga tohu kua hoatuhia.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: kahore tōpū tikanga hashing (`write_u *`, `write_i*`) e tautuhia
    // mo tenei momo.
    // Ka taea e taatau te taapiri, te kape i te whakamahinga `short_write` i te librustc_data_structures/sip128.rs, me te taapiri i nga tikanga `write_u *`/`write_i*` ki `SipHasher`, `SipHasher13`, me `DefaultHasher`.
    //
    // Ma tenei e tere ake ai te haehae totere a aua hasher, he utu mo te whakaheke i te tere whakahiato i etahi tohu.
    // Tirohia te #69152 mo nga korero taipitopito.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // SAFETY: `cmp::min(length, needed)` ka pumau kia kaua e neke ake i te `length`
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Ko te hiku buffered kua werahia inaianei, ka tukatukahia te whakauru hou.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // HAUMARU: no te mea ko `len - left` te maha nui o 8 raro
            // `len`, a no te mea tīmata `i` i `needed` wahi `len` ko `length - needed`, whai `i + 8` te ki kia iti iho i te ranei rite ki `length`.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // HAUMARU: `i` ko inaianei `needed + len.div_euclid(8) * 8`,
        // na `i + left` = `needed + len` = `length`, i te mea i whakamāramatanga rite ki `msg.len()`.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// Ka waihangahia he `Hasher<S>` me nga ki tuatahi e rua i whakaritea ki te 0.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}