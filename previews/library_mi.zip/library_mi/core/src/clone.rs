//! Ko te `Clone` trait mō momo e kore e taea e e e 'kakato tārua'.
//!
//! I te Rust, ko etahi momo maamaa he "implicitly copyable" ana ka tohaina e koe ka tohaina ranei hei tautohe, ka riro i te kaiwhiwhi he kape, ka waiho te uara taketake ki tona waahi.
//! e kore e ēnei momo rapu tohatoha ki te tārua me te kore e whai finalizers (ie, e kore ratou e roto i ngā pouaka puritia ranei whakatinana [`Drop`]), na whakaaro te taupatupatu ratou cheap me haumaru ki te tārua.
//!
//! Mo etahi atu momo me tino marama te kape, ma te huihuinga e whakamahi ana i te [`Clone`] trait me te karanga i te tikanga [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! tauira whakamahinga Basic:
//!
//! ```
//! let s = String::new(); // momo Aho taputapu Tārite
//! let copy = s.clone(); // kia taea e matou ki tou i te reira
//! ```
//!
//! Kia ngawari ai te whakamahi i te Clone trait, ka taea hoki e koe te whakamahi i te `#[derive(Clone)]`.Tauira:
//!
//! ```
//! #[derive(Clone)] // ka taapirihia e maatau te Clone trait ki te Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // a inaianei ka taea e taatau te whakarite!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// He trait noa mo te kaha ki te ata taarua i tetahi mea.
///
/// He rereke mai i te [`Copy`] kei roto i taua [`Copy`] he ngawari, he tino utu hoki, i te wa e marama ana te `Clone`, akene kaore pea he utu.
/// I roto i te tikanga ki te uruhi i enei āhuatanga, e kore e Rust tukua ki a koutou reimplement [`Copy`], engari kia reimplement koutou `Clone` me rere waehere noho.
///
/// I te mea he nui ake te `Clone` i te [`Copy`], ka taea e koe te hanga i tetahi mea [`Copy`] hei `Clone` hoki.
///
/// ## Derivable
///
/// Ka taea te whakamahi i tenei trait me `#[derive]` mena he `Clone` nga mara katoa.Ko te `whakatinanatanga derive`d o [`Clone`] karanga [`clone`] i runga i ia mara.
///
/// [`clone`]: Clone::clone
///
/// Mo te hanganga whanui, ka whakamahia e te `#[derive]` te `Clone` me te taapiri i te `Clone` herea i runga i nga waahanga whanui.
///
/// ```
/// // `derive` taputapu Tārite hoki Reading<T>ina ko T te Kaone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Me pehea taku whakatinana i te `Clone`?
///
/// Ko nga momo [`Copy`] me kaha ki te whakamahi i te `Clone`.More ōkawa:
/// ki te `T: Copy`, `x: T`, ko `y: &T`, ka he ōrite ki `let x = *y;` `let x = y.clone();`.
/// kia implementations ā-tupato ki te tautokona tenei pūmau;heoi, ko te waehere kore haumaru kaua e whakawhirinaki atu ki reira kia maumahara te ahuru o to mahara.
///
/// Ko tetahi tauira ko te hanganga whanui e mau ana i te atatohu mahi.I roto i tenei take, te whakatinanatanga o `Clone` kore e taea e `derive`d, engari e taea te whakatinana rite:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Kaitono whakatinana
///
/// I tua atu ki te [implementors listed below][impls], whakatinana ano hoki te momo e whai ake nei `Clone`:
///
/// * momo Taumahi tūemi (arā, te momo motuhake tautuhia hoki ia mahi)
/// * Nga momo tohu tohu (hei tauira, `fn() -> i32`)
/// * momo ngohi, mo te rahi katoa, ki te whakatinana hoki i te momo tūemi `Clone` (hei tauira, `[i32; 123456]`)
/// * Nga momo tuple, mena ka whakamahia e te waahanga `Clone` (hei tauira, `()`, `(i32, bool)`)
/// * Nga momo kati, mena kaare he uara mai i te taiao, mena ka uia katoahia e nga `Clone` era uara kua mau.
///   Note e taurangi riro e tohutoro ngā whakatinana tonu `Clone` (ara, ki te kahore te referent e), i taurangi riro e tohutoro mutable kore whakatinana `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Whakahokia te kape o te uara.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str taputapu Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// He whakamahi i tārua-taumahi i `source`.
    ///
    /// `a.clone_from(&b)` he rite ki te `a = b.clone()` kei te mahi, engari ka taea te turaki kia whakamahi ano i nga rauemi o `a` kia kore ai e tohatoha.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// tonotono ahu whakaputa he impl o te trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): E whakamahia enei structs anake i te#[ahu] ki te whakapuaki e nga wāhanga o te momo taputapu Tārite Tārua ranei.
//
//
// Ko enei mahinga kaua rawa e puta i te waehere kaiwhakamahi.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Nga Whakatinana o `Clone` mo nga momo tawhito.
///
/// E whakatinana implementations e kore e taea te whakaahuatia i roto i Rust i `traits::SelectionContext::copy_clone_conditions()` i `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Ka taea te mōu tohutoro Tiria, engari tohutoro mutable *taea kore*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Ka taea te mōu tohutoro Tiria, engari tohutoro mutable *taea kore*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}