//! Ka whakatau he uara tohu-tere ki nga waahanga takitahi me nga awhe hapa.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Kua wetewetehia te uara mutunga kore kua hainatia, penei:
///
/// - Ko te uara taketake he rite ki te `mant * 2^exp`.
///
/// - Ko nga nama mai i te `(mant - minus)*2^exp` ki te `(mant + plus)* 2^exp` ka huri ki te uara taketake.
/// Ka whakauruhia te awhe ina `inclusive` ko `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Ko te mantissa tauine.
    pub mant: u64,
    /// Te awhe hapa o raro.
    pub minus: u64,
    /// Te awhe hapa o runga.
    pub plus: u64,
    /// Ko te kaiwhakaari toha i te turanga 2.
    pub exp: i16,
    /// Pono ina he whakauru te awhe hapa.
    ///
    /// I roto i te IEEE 754, he pono tenei i te wa e rite ana te mantissa taketake.
    pub inclusive: bool,
}

/// Kua wetekina te uara kore hainatia.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Nga Infinities, he pai, he kino ranei.
    Infinite,
    /// Kore, he pai, he kino ranei.
    Zero,
    /// Whakamutua nga nama me etahi atu waahanga wetetuhia.
    Finite(Decoded),
}

/// He momo maungatahi e taea ana hei `wetemu`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Ko te uara kua whakaritea mo te iti rawa.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Whakahoki mai ai i te tohu (pono ka he ana) me te uara `FullDecoded` mai i te nama ira tere.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // noho tata: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode tiakina ai te kaiwhakaari i nga wa katoa, no reira ka tohua te mantissa mo nga subnormals.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // noho tata: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // kei hea te maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // noho tata: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}