//! Rust urutaunga o te Grisu3 algorithm e whakaahuatia ana i roto i te "Taarua Tere Ana-Tohu Tau Tere me te Tika ki nga Waoa Utu" [^ 1].
//! Ka whakamahia te 1KB o te teepu kua whakaritea, ana hoki, he tere mo te nuinga o nga whakauru.
//!
//! [^1]: Florian Loitsch.2010. Te taarua i nga tau tere-tere me te
//!   tika ki te tau tōpū.SIGPLAN Kaore.45, 6 (Pipiri 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// tirohia nga korero i te `format_shortest_opt` mo te kaupapa whaitake.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Hoatu `x > 0`, whakahokia `(k, 10^k)` penei i te `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Te whakaritenga aratau poto rawa mo Grisu.
///
/// Ka whakahokia mai e `None` ka whakahoki mai ana i tetahi whakaaturanga kore.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // me toru rawa nga waahanga e tika ana mo taatau

    // tiimata me nga uara kua whakaritea ma te kaiwhakaari toha
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // kitea tetahi `cached = 10^minusk` penei i te `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // mai i te mea kua whakaritea te `plus`, ko te tikanga ko te `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // i te mea kua kowhiria taatau `ALPHA` me `GAMMA`, na tenei ka tukuna te `plus * cached` ki te `[4, 2^32)`.
    //
    // Ko reira mārama e minaminatia ki te whakanui `GAMMA - ALPHA`, kia kore tatou e hiahia maha mana keteroki o te 10, engari i reira e etahi whakaaro:
    //
    //
    // 1. e hiahia ana matou kia mau tonu te `floor(plus * cached)` ki roto i te `u32` mai i te mea me wehe te waahanga nui.
    //    (kaore tenei e tino karohia, ko te toenga e hiahiatia ana mo te whakatau tika.)
    // 2.
    // ko te toenga o te `floor(plus * cached)` ka whakarahihia ki te 10, ana kia kore e waipuke.
    //
    // ko te mea tuatahi he `64 + GAMMA <= 32`, ko te tuarua he `10 * 2^-ALPHA <= 2^64`;
    // -60 a ko te -32 te awhe teitei me tenei herenga, a kei te whakamahia hoki e V8.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // tauine fps.ma tenei ka puta he hapa nui mo te 1 ulp (i whakamatauhia mai i te Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-awhe tino o te tango
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // runga ake `minus`, `v` ko `plus` he *quantized* whakatau tata (hapa <1 ulp).
    // i te mea kaore maatau e mohio he pai, he kino ranei te he, ka whakamahia e maatau nga whakaaro e rua kia rite te waahi ka nui te hapa mo te 2 hapi.
    //
    // te "unsafe region" Ko te wā ohaoha nei tatou te tīmatanga whakaputa.
    // ko te "safe region" he waahi ngawari e whakaae ana maatau.
    // ka tiimata me te repr tika i roto i te rohe haumaru, ka ngana ki te kimi i te repr tata ki `v` kei roto ano i te rohe haumaru.
    // ki te kore e taea e taatau, ka whakarere tatou.
    //
    let plus1 = plus.f + 1;
    // kia plus0 = plus.f, 1;//anake mo te whakamaarama kia minus0 = minus.f + 1;//hei whakamarama anake
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // kaiwhakatairanga tiri

    // wehehia te `plus1` ki nga waahanga haangai me te wehenga.
    // Ko nga waahanga whakauru ka whakamanahia kia uru ki te u32, na te mea ko te mana Keteroki e tohu ana i te `plus < 2^32` me te `plus.f` kua whakaritea he iti ake i te `2^64 - 2^4` na te mea e tika ana.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // tatau i te `10^max_kappa` nui rawa atu i te `plus1` (na `plus1 < 10^(max_kappa+1)`).
    // koinei te rohe o runga o `kappa` i raro.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Kaupapa 6.2: mena he `k` te taupū nui o te tau
    // `0 <= y mod 10^k <= y - x`,              katahi ko `V = floor(y / 10^k) * 10^k` kei roto i te `[x, y]` me tetahi o nga whakaaturanga poto (me te iti o te nama mati) kei taua awhe.
    //
    //
    // kitea te roa mati `kappa` i waenga i te `(minus1, plus1)` kia rite ki te Theorem 6.2.
    // Ko te kaupapa 6.2 ka taea te tango ki te aukati i te `x` ma te tono `y mod 10^k < y - x` hei utu.
    // (Hei tauira, `x` =32000, `y` =32777;. `kappa` =2 mai `y mod 10 ^ 3=777 <y, x=777`) whakawhirinaki te hātepe i runga i te wāhanga whakaū i muri ki te tutakina `y`.
    //
    let delta1 = plus1 - minus1;
    // tukua delta1int=(delta1>> e) hei whakamahi i te whakamahi;//hei whakamarama anake
    let delta1frac = delta1 & ((1 << e) - 1);

    // whakawhiwhia nga waahanga whakauru, i te waa e tirotiro ana mo te tika o ia hikoi.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // kia tae mai ano he mati
    loop {
        // kotahi pea te mati hei toha mai, i te wa e tono ana a `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (e whai ana ko `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // ritehia te `remainder` e te `10^kappa`.ka whakaarahia te rua e te `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; kua kitea e maatau te `kappa` tika.
            let ten_kappa = (ten_kappa as u64) << e; // tauine 10 ^ kappa hoki ki te kaiwhakaari tohaina
            return round_and_weed(
                // SAFETY: i tiimata e maatau taua maumahara i runga ake nei.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // whatiia te koropiko ka oti i a maatau nga waahanga whakauru katoa.
        // te tau tangohia o nga mati ko te `max_kappa + 1` rite te `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // whakahoki mai i nga kaimana
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // whakawhiwhiwhiwhiwhiwhiwhiwhiwhiwhiwhiwhiawhi ai i ia hikoi.
    // tenei wa ka whakawhirinaki maatau ki nga whakareatanga toutou, na te mea ka kore e tino wehe te wehenga.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // kia whai kiko te mati o muri mai na te mea kua whakamatauhia e maatau i mua i te wehenga o nga kaimanaaki, kei reira te `m = max_kappa + 1` (#o nga mati i te waahanga tuuturu):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // e kore e waipuke, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // wehehia te `remainder` ma te `10^kappa`.
        // ka whakaarahia te rua e te `2^e / 10^kappa`, na ko te whakamutunga e whai kiko ana i konei.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // kaiawhina whai kiko
            return round_and_weed(
                // SAFETY: i tiimata e maatau taua maumahara i runga ake nei.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // whakahoki mai i nga kaimana
        kappa -= 1;
        remainder = r;
    }

    // kua hangaia e maatau nga tau nui o te `plus1`, engari kaore e mohio mena ko te mea tino pai.
    // hei tauira, mena ko `minus1` te 3.14153 ... me te `plus1` ko te 3.14158 ..., e 5 nga whakaaturanga poto katoa mai i te 3.14154 ki te 3.14158 engari ko ta maatau anake te mea nui.
    // me aata heke e tatou te mati whakamutunga ka tirotiro mena koinei te repr tino pai.
    // neke atu i te 9 nga kaitono (..1 ki ..9), na he tere tenei.("rounding" waahanga)
    //
    // ka tirotirohia e te mahi mena kei roto tonu tenei repr "optimal" i nga waahanga ulp, ana, ka taea pea ko te "second-to-optimal" repr te mea tino pai na te hapa huri noa.
    // i nga keehi e rua ka hoki mai tenei `None`.
    // ("weeding" waahanga)
    //
    // ko nga tautohe katoa kei konei ka whakatairangahia e te uara noa (engari he uhinga) uara `k`, kia:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (ana hoki, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (ano hoki, `threshold > plus1v` mai i nga kaitono o mua)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // whakaputa kia rua nga taatai ki te `v` (tino `plus1 - v`) i roto i nga 1.5 ulps.
        // ko nga hua ka puta ko nga whakaaturanga tata ki nga mea e rua.
        //
        // i konei ka whakamahia te `plus1 - v` mai i te mea ka oti nga tatauranga mo te `plus1` kia kore ai e taea te overflow/underflow (na ko nga ingoa e kiia nei he whakawhiti).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 hipa)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // whakaitihia te mati whakamutunga ka kati i te whakaaturanga tata ki te `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // mahi matou me nga tatauranga tatauranga `w(n)`, e rite ana ki te `plus1 - plus1 % 10^kappa`.i muri i te whakahaere i te tinana koropiko `n` wa, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // ka whakatauhia e matou te `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (na tenei `toenga= plus1w(0)`) hei whakangawari i nga arowhai.
            // kia mahara kei te piki haere tonu te `plus1w(n)`.
            //
            // e toru nga tikanga hei whakamutu i a maatau.ma tetahi o raatau e kore e taea te koropiko ki te haere tonu, engari kotahi tonu te mangai tika e mohiotia ana tata atu ki te `v + 1 ulp`.
            // ka tohua e maatau ko TC1 ma te TC3 mo te poto.
            //
            // TC1: `w(n) <= v + 1 ulp`, ara, koinei te repr whakamutunga ka taea te mea tata.
            // he rite tenei ki te `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // ka honoa ki te TC2 (ka tirotirohia mena `w(n+1)` is valid), ka aukati tenei i te waipuke i runga i te tatauranga o `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, ara, ko te repr i muri mai kaore e huri ki te `v`.
            // he rite tenei ki te `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // te taha maui ka taea te puhake, engari e mohio ana taatau `threshold > plus1v`, na mena he teka te TC1, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` a ka taea e taatau te whakamatautau mena he `threshold - plus1w(n) < 10^kappa` hei utu.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ara, ko te repr i muri mai
            // kaore e tata atu ki te `v + 1 ulp` i te repr o naianei.
            // homai `z(n) = plus1v_up - plus1w(n)`, ka riro tenei hei `abs(z(n)) <= abs(z(n+1))`.ki te whakaaro he teka te TC1, he `z(n) > 0` taatau.e rua a maatau keehi hei whakaaro ake:
            //
            // - ina `z(n+1) >= 0`: TC3 ka riro hei `z(n) <= z(n+1)`.
            // i te mea kei te piki haere te `plus1w(n)`, me heke te `z(n)` ana ka tino teka tenei.
            // - ina `z(n+1) < 0`:
            //   - TC3a: ko te tikanga he `plus1v_up < plus1w(n) + 10^kappa`.ki te whakaaro he teka te TC2, `threshold >= plus1w(n) + 10^kappa` na te kore e kaha ake.
            //   - TC3b: TC3 ka riro hei `z(n) <= -z(n+1)`, ara, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   ko te TC1 kua whakakahoretia ka whakawhiwhia ki te `plus1v_up > plus1w(n)`, na reira kaore e taea te neke ake, te heke ranei ka honoa ana ki te TC3a
            //
            // no reira, me mutu taatau ina `TC1 || TC2 || (TC3a && TC3b)`.te mea e whai ake nei he orite ki tana porohita, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // ko te repr poto rawa kaare e mutu me `0`
                plus1w += ten_kappa;
            }
        }

        // tirohia mena ko tenei whakaaturanga ano te whakaaturanga tino tata ki te `v - 1 ulp`.
        //
        // he rite tonu tenei ki nga tikanga whakamutu mo `v + 1 ulp`, me te `plus1v_up` katoa i whakakapihia e `plus1v_down` hei utu.
        // tātaritanga kapinga rite pupuri.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // inaianei kua tata ke o taatau whakaaturanga ki `v` i waenga i te `plus1` me te `minus1`.
        // he manawareka rawa tenei, ahakoa, na, ka paopao maatau i tetahi `w(n)` kaore i waenga i te `plus0` me te `minus0`, ara, `plus1 - plus1w(n) <= minus0` me `plus1 - plus1w(n) >= plus0` ranei.
        // ka whakamahia e maatau nga meka e `threshold = plus1 - minus1` me `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Ko te whakamahinga aratau poto rawa mo Grisu me te tarakona tarakona.
///
/// Me whakamahi tenei mo te nuinga o nga keehi.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SAFETY: Ko te kaitaki nama kaore i te mohio ki te tuku i ta `buf`
    // i te tuarua o te branch, na reira ka horoia e maatau te roanga o te tau i konei.
    // Engari ka whakamahia noa e matou te `buf` mena i whakahokia mai e `format_shortest_opt` te `None` na he pai tenei.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Ko te whakamahi me te whakarite i te aratau maau mo Grisu.
///
/// Ka whakahokia mai e `None` ka whakahoki mai ana i tetahi whakaaturanga kore.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // me toru rawa nga waahanga e tika ana mo taatau
    assert!(!buf.is_empty());

    // whakariterite me te tauine `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // wehehia te `v` ki nga waahanga haangai me te wehenga.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // ko te `v` tawhito me te `v` hou (ka whakaarahia e `10^-k`) he hapa <1 ulp (Theorem 5.1).
    // i te mea kaore matou e mohio he pai, he kino ranei te he, ka whakamahia e maatau nga whakaaro e rua kia rite te waahi ka nui te hapa mo te 2 ulps (he rite ki te keehi poto).
    //
    //
    // ko te whainga ko te kimi i nga raupapa mati porowhita rite noa ki te `v - 1 ulp` me te `v + 1 ulp`, kia tino maia ai tatou.
    // ki te kore e taea tenei, kaore maatau e mohio ko tehea te putanga tika mo `v`, no reira ka whakarere atu, ka hinga ano.
    //
    // `err` kua tautuhia hei `1 ulp * 2^e` i konei (he rite ki te ulp i te `vfrac`), a ka whakaarahia e maatau i te wa ka whakairihia te `v`.
    //
    //
    //
    let mut err = 1;

    // tatau i te `10^max_kappa` nui rawa atu i te `v` (na `v < 10^(max_kappa+1)`).
    // koinei te rohe o runga o `kappa` i raro.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // mena kei te mahi maatau me te aukati whakamutunga, me whakapoto e tatou te paepae i mua i te whakamaaramatanga pono kia kore ai e huri porowhita.
    //
    // mōhio e whai tatou ki te whakanui ano i te moka, ka whakaawhiwhi ki runga pehea!
    let len = if exp <= limit {
        // aue, kaore e taea e maatau te whakaputa *kotahi* mati.
        // ka taea tenei ka, ki ana, he mea rite ki a tatou 9.5 ana kua oti te huri ki te 10.
        //
        // i runga i te tikanga ka taea tonu e taatau te karanga `possibly_round` me te miihana kore, engari ko te whakatauine `max_ten_kappa << e` na te 10 ka nui ake te rere.
        //
        // na te mea e noho mangere ana tatou i konei ka whakawhaanui i te whara hapa 10.
        // ma tenei ka piki te reeti kino teka, engari rawa noa,*tino* paku;
        // ka kitea noa atu ka nui ake te mantissa i te 60 paraire.
        //
        // SAFETY: `len=0`, no reira he iti noa iho te utunga o te maaramatanga i tenei maumahara.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // whakawhiwhia nga waahanga whakauru.
    // ko te hapa he hautanga katoa, no reira kaore e tika kia tirohia i tenei waahanga.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // kia tae mai ano he mati
    loop {
        // kotahi tonu te tatauranga mo a maatau ki te tuku kaitoro:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (e whai ana ko `remainder = vint % 10^(kappa+1)`)
        //
        //

        // ritehia te `remainder` e te `10^kappa`.ka whakaarahia te rua e te `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // kua kī te mōkai?Whakahaerehia te huringa porohita me te toenga.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SAFETY: kua tiimata e maatau `len` nga paita maha.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // whatiia te koropiko ka oti i a maatau nga waahanga whakauru katoa.
        // te tau tangohia o nga mati ko te `max_kappa + 1` rite te `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // whakahoki mai i nga kaimana
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // hoatu nga waahanga hautanga.
    //
    // i runga i te tikanga ka taea e taatau te haere tonu ki te mati whakamutunga e waatea ana me te tirotiro mo te tika.
    // heoi kei te mahi maatau me nga integers rahi-rahi, no reira me tohu he paearu kia kitea te taumahatanga.
    // V8 whakamahia te `remainder > err`, ka teka ke ka rereke nga nama `i` tuatahi o `v - 1 ulp` me `v`.
    // heoi ka paopao tenei ki te maha o nga whakaurunga whaimana.
    //
    // mai i te waahanga o muri he tika te kimi rerenga wai, ka kaha ake ta maatau whakamahi i te paearu:
    // kei te haere tonu maatau tae atu ki te `err` nui atu i te `10^kappa / 2`, na ko te awhe i waenga i te `v - 1 ulp` me te `v + 1 ulp` e rua pea neke atu ranei nga whakaaturanga porotaka.
    //
    // he rite tenei ki nga whakataurite tuatahi e rua mai i `possibly_round`, mo te tohutoro.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, i reira `m = max_kappa + 1` (#o ngā mati i roto i te wāhi):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // e kore e waipuke, `2^e * 10 < 2^64`
        err *= 10; // e kore e waipuke, `err * 10 < 2^e * 5 < 2^64`

        // wehehia te `remainder` ma te `10^kappa`.
        // ka whakaarahia te rua e te `2^e / 10^kappa`, na ko te whakamutunga e whai kiko ana i konei.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // kua kī te mōkai?Whakahaerehia te huringa porohita me te toenga.
        if i == len {
            // SAFETY: kua tiimata e maatau `len` nga paita maha.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // whakahoki mai i nga kaimana
        remainder = r;
    }

    // kaore he painga o te tatauranga (`possibly_round` tino kore), na ka tuku.
    return None;

    // i hangaia e matou nga nama katoa o `v`, kia rite ki nga mati e tika ana mo te `v - 1 ulp`.
    // i tenei wa ka tirohia mena he whakaaturanga motuhake e tohaina ana e `v - 1 ulp` me te `v + 1 ulp`;he orite pea tenei ki nga mati i hangaia, ki te waahanga whanui-whakarahi ranei o aua mati.
    //
    // Mena he maha nga whakaaturanga o te awhe he rite te roa, kaore matou e tino mohio me whakahoki `None` hei utu.
    //
    // ko nga tautohe katoa kei konei ka whakatairangahia e te uara noa (engari he uhinga) uara `k`, kia:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SAFETY: ko te paita `len` tuatahi o `buf` me matua arahi.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (mo te tohutoro, ko te raina iraa e tohu ana i te uara tino tika mo nga whakaaturanga i roto i te maha o nga mati.)
        //
        //
        // he nui rawa te hapa ka toru pea nga whakaaturanga i waenga i te `v - 1 ulp` me te `v + 1 ulp`.
        // kaore e taea te whakatau ko wai te mea tika.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // i roto i te meka, 1/2 ulp he nui ki te whakauru i nga whakaaturanga e rua ka taea.
        // (Kia mahara kei te hiahia tatou i tetahi whakaaturanga motuhake mo te `v - 1 ulp` me te "v + 1 ulp`.) kaore tenei e kaha ake, i te mea `ulp < ten_kappa` mai i te haki tuatahi.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // mena he tata atu te `v + 1 ulp` ki te whakaaturanga porotaka-iho (kua oti ke i te `buf`), katahi tatou ka hoki humarie.
        // me maarama ko te `v - 1 ulp`*ka taea* te iti ake i te whakaaturanga o naianei, engari i te `1 ulp < 10^kappa / 2`, kua ea tenei ahua:
        // te tawhiti i waenga i `v - 1 ulp` me nga whakaaturanga onaianei kaore e nui ake i te `10^kappa / 2`.
        //
        // ko te ahuatanga he rite ki te `remainder + ulp < 10^kappa / 2`.
        // mai i tenei ka ngawari tonu te waipuke, tirohia te `remainder < 10^kappa / 2`.
        // kua oti ke i a maatau te `ulp < 10^kappa / 2`, na te mea kaore i pakaru te `10^kappa` i muri i nga mea katoa, kei te pai te haki tuarua.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SAFETY: na to maatau kaiwaea i arahi taua maumahara.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------toenga------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // i etahi atu, mena he tata te `v - 1 ulp` ki te whakaaturanga porotaka-ake, me huri ake tatou ka hoki.
        // mo nga take ano kaore e hiahiatia e maatau te tirotiro i te `v + 1 ulp`.
        //
        // ko te ahuatanga he rite ki te `remainder - ulp >= 10^kappa / 2`.
        // ka tirotirohia ano e maatau mena ko `remainder > ulp` (kia mahara ehara tenei i te `remainder >= ulp`, na te mea ko te `10^kappa` kaore i te kore).
        //
        // kia mahara hoki `remainder - ulp <= 10^kappa`, na ko te haki tuarua kaore i te waipuke.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SAFETY: ko taatau kaiwaea i timata te maumahara.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // taapirihia he taapiri taapiri ina kua paatai mai maatau ki a maatau.
                // me aata tirotiro hoki e tatou, mena he putua te paraoa taketake, ka taea noa te taapiri i te mati taapiri ina `exp == limit` (take edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SAFETY: ko maatau ko te kaiwaea i haangai i taua maharatanga.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // ki te kore kua ngaro tatou (arā, ko etahi uara i waenga i te `v - 1 ulp` me te `v + 1 ulp` e porotaka ana, ko etahi e huri haere ana) ka tuku.
        //
        None
    }
}

/// Ko te whakamahi i te aratau tika me te tuturu mo te Grisu me te tarakona fallback.
///
/// Me whakamahi tenei mo te nuinga o nga keehi.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SAFETY: Ko te kaitaki nama kaore i te mohio ki te tuku i ta `buf`
    // i te tuarua o te branch, na reira ka horoia e maatau te roanga o te tau i konei.
    // Engari ka whakamahia noa e matou te `buf` mena i whakahokia mai e `format_exact_opt` te `None` na he pai tenei.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}