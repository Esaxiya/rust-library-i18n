//! Tata ki te tika (engari he iti ake te whakatika) Rust whakamaoritanga o te Whakaahua 3 o te "Taarua Tere-Ira Tau Tere Ana Tika" [^ 1].
//!
//!
//! [^1]: Burger, RG me Dybvig, RK 1996. Te taarua i nga tohu-reanga
//!   tere me te tika.SIGPLAN Kaore.31, 5 (Mei. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// precalculated huānga o `Digit`s mō te 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// ka taea noa ina `x < 16 * scale`;`scaleN` kia `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Te whakaritenga aratau poto rawa mo te Tarakona.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ko te nama `v` ki te whakatakotoranga e mohiotia ana ko:
    // - he rite ki te `mant * 2^exp`;
    // - i mua i te `(mant - 2 *minus)* 2^exp` i te momo tuuturu;me
    // - aru mai te `(mant + 2 *plus)* 2^exp` i te momo tuuturu.
    //
    // he maarama, `minus` me `plus` kaore e taea te kore.(mo nga infinities, ka whakamahia e taatau nga uara-whanui.) Ka kii hoki maatau kotahi te nama kua hangaia, ara, `mant` kaore e kore he kore.
    //
    // ko te tikanga ko tetahi nama i waenga i te `low = (mant - minus)*2^exp` me te `high = (mant + plus)* 2^exp` ka whakamaherea ki tenei nama tohu tere, me nga taapiri kua whakauruhia i te wa e rite ana te mantissa taketake (ara, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` ko `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // whakaarohia te `k_0` mai i nga whakauru taketake e makona ana te `10^(k_0-1) < high <= 10^(k_0+1)`.
    // ko te here kiki `k` makona `10^(k-1) < high <= 10^k` ka tatauhia i muri ake.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // hurihia te `{mant, plus, minus} * 2^exp` ki te puka hautanga kia:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // ritehia te `mant` e te `10^k`.inaianei `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // whakatika ina `mant + plus > scale` (`>=` ranei).
    // kaore maatau e whakarereke i te `scale`, na te mea ka taea e maatau te peke i te whakareatanga tuatahi.
    // inaianei `scale < mant + plus <= scale * 10` a kua rite matou ki te whakaputa mati.
    //
    // kia mahara ko te `d[0]`*ka taea* hei kore, ina `scale - plus < mant < scale`.
    // i roto i tenei kohinga ahua-huri (`up` i raro iho nei) ka whakaohohia i taua wa tonu.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // he orite ki te whakatauine `scale` na 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // keteroki `(2, 4, 8) * scale` mo te whakatipuranga mati.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // nga kaitono, kei reira te `d[0..n-1]` he mati kua hangaia i tenei wa:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (Ko te kupu `mant / scale < 10`) i reira `d[i..j]` ko te takinga mo `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // whakaputa kotahi mati: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // he whakamarama ngawari tenei mo te algorithm Dragon kua whakarerekehia.
        // he maha nga whakahekenga takawaenga me nga tohenga taupatupatu ka tangohia mo te waatea.
        //
        // tiimata me nga kaitaunaki kua whakarereke, i te mea kua whakahoutia e matou te `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // Ki te whakaaro ko te `d[0..n-1]` te whakaaturanga poto i waenga i te `low` me te `high`, ara, ka ea a `d[0..n-1]` i nga mea e rua e whai ake nei engari kaore a `d[0..n-2]` e whai.
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (koiora: mati huri noa i te `v`);me
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (he tika te mati whakamutunga).
        //
        // ko te tikanga tuarua ka ngawari ki te `2 * mant <= scale`.
        // ko te whakatau i nga kaitautoko mo te `mant`, `low` me te `high` he putanga ngawari ake mo te ahuatanga tuatahi: `-plus < mant < minus`.
        // mai i te `-plus < 0 <= mant`, he tika rawa a maatau whakaaturanga `mant < minus` me `2 * mant <= scale`.
        // (ko te mea o mua ka riro hei `mant <= minus` ka rite ana te mantissa taketake.)
        //
        // ka kore te tuarua e mau (`2 * mant> tauine`), me whakapiki ake i te mati whakamutunga.
        // he nui hoki te whakaora i taua huru tenei: e matau kua tatou e te whakatupuranga mati wakaae `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // i tenei keehi, ko te ahuatanga tuatahi ka riro hei `-plus < mant - scale < minus`.
        // mai i te `mant < scale` i muri o te whakatupuranga, kei a matou te `scale < mant + plus`.
        // (ano, ka riro tenei hei `scale <= mant + plus` ka rite ana te mantissa taketake.)
        //
        // i te poto:
        // - kati me te huri i te `down` (kia mau ki nga mati) ina `mant < minus` (`<=` ranei).
        // - kati me te huri i te `up` (whakapiki i te mati whakamutunga) ka `scale < mant + plus` (ko `<=` ranei).
        // - kia mau ki te whakaputa ke.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // he poto nei o tatou mangai, haere ki te rauna

        // whakaorangia nga kaitautoko.
        // ma tenei ka mutu tonu ai te algorithm: `minus` me `plus` ka piki haere tonu, engari kua topuhia te `mant` modulo `scale` ka mau tonu a `scale`.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ka pa ana te hurihuri i te i) ko te ahuatanga hurihanga-noa anake i puea mai, i ii) ko nga tikanga e rua i puea ake me te herea herea he pai ki te huri porowhita.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // mena ka huri te rauna i te roa, me huri ano te kaiwhakaatu.
        // te ahua nei he uaua rawa tenei ahua ki te makona (kaore pea e taea), engari kei te noho humarie tatou kei konei hoki.
        //
        // SAFETY: i tiimata e maatau taua maumahara i runga ake nei.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SAFETY: i tiimata e maatau taua maumahara i runga ake nei.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Te whakaritenga aratau tika me te pumau mo Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // whakaarohia te `k_0` mai i nga whakauru taketake e makona ana te `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // ritehia te `mant` e te `10^k`.inaianei `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // whakatikatika ka `mant + plus >= scale`, kei hea `plus / scale = 10^-buf.len() / 2`.
    // kia mau ai te bignum rahi-rahi, ka whakamahia e matou te `mant + floor(plus) >= scale`.
    // kaore maatau e whakarereke i te `scale`, na te mea ka taea e maatau te peke i te whakareatanga tuatahi.
    // ano hoki me te algorithm poto rawa, `d[0]` ka kore noa engari ka huri rawa.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // he orite ki te whakatauine `scale` na 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // mena kei te mahi maatau me te aukati whakamutunga, me whakapoto e tatou te paepae i mua i te whakamaaramatanga pono kia kore ai e huri porowhita.
    //
    // mōhio e whai tatou ki te whakanui ano i te moka, ka whakaawhiwhi ki runga pehea!
    let mut len = if k < limit {
        // aue, kaore e taea e maatau te whakaputa *kotahi* mati.
        // ka taea tenei ka, ki ana, he mea rite ki a tatou 9.5 ana kua oti te huri ki te 10.
        // ka whakahokia mai e maatau he paapihi maamaa, haunga ano te keehi a muri ake nei ka puta ka `k == limit` ana kia rite tonu te mati.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // keteroki `(2, 4, 8) * scale` mo te whakatipuranga mati.
        // (Ka taea e kia utu tenei, na e kore e tātai ratou ina he kau te moka.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // ko nga mati e whai ake nei he kore noa iho, ka mutu ta maatau i konei *kaua e* ngana ki te mahi a tawhio noa!engari whakakiihia nga nama e toe ana.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SAFETY: i tiimata e maatau taua maumahara i runga ake nei.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // hurihuri mena ka mutu taatau ki waenga i nga mati mena he 5000 tonu nga mati e whai ake nei ..., tirohia te mati o mua ka ngana ki te hurihuri (ara, karo i te whakaeke i te wa e taurite ana te mati o mua).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SAFETY: `buf[len-1]` kua tiimata.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // mena ka huri te rauna i te roa, me huri ano te kaiwhakaatu.
        // engari kua tonohia maatau ki etahi nama, kia kaua e whakarereke i te ...
        // SAFETY: i tiimata e maatau taua maumahara i runga ake nei.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... ki te kore kua tonoa mai maatau mo tera.
            // me aata tirotiro hoki e tatou, mena he putua te paraoa taketake, ka taea noa te taapiri i te mati taapiri ina `k == limit` (take edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SAFETY: i tiimata e maatau taua maumahara i runga ake nei.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}