//! Nga momo he mo te huri ki nga momo whakauru.

use crate::convert::Infallible;
use crate::fmt;

/// hoki te momo hapa ina hemo te faafariuraa momo wāhi takina.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Whakataurite, kaua ki te akiaki kia mohio ko te waehere penei i te `From<Infallible> for TryFromIntError` i runga ake nei ka mahi tonu ka riro a `Infallible` hei ingoakapa ki `!`.
        //
        //
        match never {}
    }
}

/// He hapa ka taea te whakahoki mai i te wa e tohatoha ana i te tau.
///
/// Ko tenei hapa ka whakamahia hei momo hapa mo nga mahi `from_str_radix()` i runga i nga momo integer tuatahi, penei i te [`i8::from_str_radix`].
///
/// # Nga Take Kaainga
///
/// I roto ano i etahi atu take, ka whiua te `ParseIntError` na te mea he arahi, he takahi ranei te waahi ma i te aho, hei tauira, i te wa i tiki mai ai i te urunga paerewa.
///
/// Ma te whakamahi i te tikanga [`str::trim()`] e whakarite kia kaua e toe tetahi waahi ma i mua i te whakamaatatanga.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Tau e ki rokiroki i te momo ngā o hapa e taea ai te pāhi i te tau tōpū ki te kore.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// He putu te uara hei whiu.
    ///
    /// I roto i etahi atu kaupapa, ka hangaia tenei rereke ka wehe ana i tetahi aho kore.
    Empty,
    /// Kei roto he mati kore e tika ana.
    ///
    /// I roto i etahi atu kaupapa, ka hangaia tenei rereke ka wehe ana koe i tetahi aho kei roto i te kore-ASCII char.
    ///
    /// Ka hangaia ano hoki tenei momo rereke ka hapa ana te `+`, te `-` ranei i roto i te aho, i a ia ano, i waenga ranei o te nama.
    ///
    ///
    InvalidDigit,
    /// He nui rawa te integer ki te penapena i te momo integer kua whaaia.
    PosOverflow,
    /// He iti rawa te integer ki te penapena i te momo integer kua whaaia.
    NegOverflow,
    /// Te Uara he Kore
    ///
    /// Ka tukuna tenei rereke ina he uara te uara o te whiu, e kore e tika mo nga momo kore-kore.
    ///
    Zero,
}

impl ParseIntError {
    /// Ka whakaputa i te take taipitopito o te parsing o te tauoti kore.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}