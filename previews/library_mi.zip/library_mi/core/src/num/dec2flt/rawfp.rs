//! Bit bitdling on positive IEEE 754 floats.Ko nga nama kino kaore e hiahiatia ana me whakahaere.
//! Ko nga nama tohu rererangi noa e whai tohu canonical ana (frac, exp) penei ko te uara ko te 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) ko te N te maha o nga paraire.
//!
//! He rereke te rerekee o nga Subnormals, he rereke ano hoki, engari ko te kaupapa ano tenei e pa ana.
//!
//! I konei, engari, ka tohua e maatau ko (sig, k) me te pai, kia rite ko te wariu ko te f *
//! 2 <sup>e</sup> .Haunga te maarama o te "hidden bit", ka huri tenei i te kaiwhakaatu na te nekehanga mantissa e kiia nei.
//!
//! Me hoatu tetahi atu ara, ko te tikanga o nga rei ka tuhia hei (1) engari i konei ka tuhia hei (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Ka tapaina e matou ko (1) nga **wehenga hautanga** me (2) te **whakaaturanga tuuturu**.
//!
//! He maha nga mahi kei tenei waahanga kei te hapai i nga nama noa.Ko nga mahinga dec2flt ka mau ki te ara huringa-tika-tika (Algorithm M) mo nga tau tino iti me te tino nui.
//! Ko tera algorithm me next_float() anake e whakahaere ana i nga subnormals me nga zero.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// He kaiawhina trait ki te karo i te taarua o te waehere faafariu katoa mo `f32` me `f64`.
///
/// Tirohia te kōrero doc o te kōwae matua mo aha te mea e tika ana tenei.
///
/// Mena **kaore rawa e mahia** mo etahi atu momo, ka whakamahia ranei i waho o te waahanga dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Patohia e `to_bits` me `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Ka mahi i tetahi whakawhitinga mata ki te tau tōpū.
    fn to_bits(self) -> Self::Bits;

    /// Ka mahi i te whakawhitinga tauwehenga mai i te tau tōpū.
    fn from_bits(v: Self::Bits) -> Self;

    /// Whakahoki ai i te waahanga e taka ana tenei nama.
    fn classify(self) -> FpCategory;

    /// Whakahoki ai i te mantissa, kaiwhakatairanga ka haina hei integers.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Ka whakatau i te tere.
    fn unpack(self) -> Unpacked;

    /// Ka tohua mai i te tau tōpū iti ka taea te whakaatu tika.
    /// Panic ki te kore e taea te whakaatu i te integer, ko era atu waehere kei roto i tenei waahanga kia kaua e waiho kia puta.
    fn from_int(x: u64) -> Self;

    /// Ka whiwhi i te uara 10 <sup>e</sup> mai i te teepu kua oti te tatau te tatau.
    /// Panics mo `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// He aha te ingoa o te ingoa.
    /// He maama ki te waehere pakeke atu i te whakakapi i nga hakihaki me te tumanako ka kapi tonu e te LLVM.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // He hereherea e herea ana ki nga mati a-ira o nga whakauru kaore e taea te whakaputa i te waipuke, te kore ranei, te kore ranei
    /// subnormals.Akene ko te kaiwhakatautau ā-ira o te wāriu tino noa, nō reira te ingoa.
    const MAX_NORMAL_DIGITS: usize;

    /// Mena he nui ake te uara o te mati mati ira tino nui atu i tenei, ka huri te tatau ki te mutunga kore.
    ///
    const INF_CUTOFF: i64;

    /// Mena he iti ake te uara o te nama mati tino nui atu i tenei, ka huri te tatau ki te kore.
    ///
    const ZERO_CUTOFF: i64;

    /// Te maha o nga paraire kei roto i te kaiwhakaatu.
    const EXP_BITS: u8;

    /// Te maha o nga paraire i te essand *me* te moka huna.
    const SIG_BITS: u8;

    /// Te maha o nga paraire i te essand,*haunga* te moka huna.
    const EXPLICIT_SIG_BITS: u8;

    /// Ko te kaiwhakautu ture nui mo te whakaaturanga hautanga.
    const MAX_EXP: i16;

    /// Ko te iti rawa o te kaitono ture mo te hautanga hautanga, haunga nga subnormals.
    const MIN_EXP: i16;

    /// `MAX_EXP` mo nga whakaaturanga tuuturu, arā, me te huringa kua whakamahia.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` whakawaeheretia (arā, me te whakaweto)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` mo nga whakaaturanga tuuturu, arā, me te huringa kua whakamahia.
    const MIN_EXP_INT: i16;

    /// Ko te nui kua whakaritea mo te whakahirahira mo te whakaurunga.
    const MAX_SIG: u64;

    /// Ko te iti rawa o te whakahirahira i te waitohu.
    const MIN_SIG: u64;
}

// Te nuinga he mahinga mo #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Whakahoki ai i te mantissa, kaiwhakatairanga ka haina hei integers.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Te whakaheke toto + neke a mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // Kaore a rkruppe e tau mena kei te tika te rauna o te `as` i runga i nga kaupapa katoa.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Whakahoki ai i te mantissa, kaiwhakatairanga ka haina hei integers.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Te whakaheke toto + neke a mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // Kaore a rkruppe e tau mena kei te tika te rauna o te `as` i runga i nga kaupapa katoa.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Ka huri i te `Fp` ki te momo tere tere miihini tata.
/// Kaore e hapai i nga hua o mua.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f he 64 moka, no reira xe he neke mantissa mo te 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Hurihuri i te tohu moka-64 ki te paraire T::SIG_BITS me te haurua-ki-te-kore.
/// Kaore e aro ki te taaputanga o te exponent.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Whakaritehia te nekehanga mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Huripoki o `RawFloat::unpack()` mo nga tau kua whakaritea.
/// Panics ki te kore te whaimana, te kaiwhakataetae ranei e whai mana mo nga tau kua whakaraupapahia.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Tangohia te moka huna
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Whakaritehia te kaiwhakaatu mo te miihini whakaharahara me te nekehanga mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Waiho te tohu tohu i te 0 ("+"), he pai katoa o maatau
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Hangaia he waahi noa.Ko te mantissa o 0 ka whakaaetia ka hanga kore.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Ko te kaiwhakaari whakawaehere te 0, ko te tohu tohu ko te 0, no reira me whakamaarama ano e tatou nga paraire.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Whakatataungia te bignum me te Fp.Rauna i roto i te 0.5 ULP me te haurua-ki-te-ahiahi.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // I tapahia e matou nga paraire katoa i mua i te taupū `start`, arā, ka tika te neke-matau o te `start`, na koinei hoki te kaiwhakaatu e hiahiatia ana e maatau.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Rauna (half-to-even) i runga i nga paraire kua tapahia.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Kitea ai te tau maama nui rawa atu he iti ake i te tautohe.
/// e kore e hapai i subnormals, kore, taupū underflow ranei.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Kimihia te tau mata tere iti tino nui atu i te tautohe.
// Kei te momona tenei mahi, ara, next_float(inf) ==inf.
// Kaore i te rite ki te nuinga o te waehere o tenei waahanga, ko tenei mahi ka whaa, kaore i te taarua, me nga kupu mutunga kore.
// Heoi, peera i etahi atu waehere kei konei, kaore e pa ki nga NaN me nga nama kino.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // He pai rawa tenei hei pono, engari he pai.
        // 0.0 kua whakawaeheretia hei kupu kore-katoa.He 0x000m te wharenui ... m kei reira te mantissa.
        // Ina koa, ko te waahanga iti rawa ko te 0x0 ... 01 ko te mea nui ko te 0x000F ... F.
        // Ko te nama noa iti rawa ko te 0x0010 ... 0, na ko tenei keehi o te kokonga e mahi ana hoki.
        // Mena ka kaha te piki o te mantissa, ka piki te kawe i te kaiwhakaari ki ta maatau e hiahia ana, a ka kore noa nga paraoa mantissa.
        // Na te huihuinga moka huna, koinei hoki te mea e hiahia ana matou!
        // Hei whakamutunga, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}