//! Nga mahi whaihua mo nga bignum kaore e nui te tikanga kia huri hei tikanga.

// FIXME Ko te ingoa o tenei waahanga he tino kino, na te mea ko etahi atu waahanga kawemai i te `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Whakamatauhia ko te whakaiti i nga paraire katoa iti ake te kiko i te `ones_place` ka whakauruhia he hapa iti iho, he rite, he nui ake ranei i te 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Mena ko nga toenga e toe ana kaore he, he= 0.5 ULP, mena> 0.5 Mena kaore he toenga (hawhe_bit==0), ka hoki mai ano i raro nei he alite.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Tahuri ai i te aho ASCII kei roto ko nga mati ira noa ki te `u64`.
///
/// Kaore e mahi i nga arowhai mo te waipuke kaore he huakore ranei, na ki te kore e tupato te kaiwaea, he kino te hua ka taea te panic (ahakoa kaore e `unsafe`).
/// Hei taapiri, ko nga aho kore kau ka kiia he kore.
/// Te vai nei tenei mahi na te mea
///
/// 1. ma te whakamahi i te `FromStr` i te `&[u8]` me `from_utf8_unchecked`, he kino, me te
/// 2. Ko te whakakao i nga hua o `integral.parse()` me `fractional.parse()` he uaua ake i tenei mahi katoa.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Tahuri ai i te aho mati ASCII ki te bignum.
///
/// Ka rite ki te `from_str_unchecked`, ko tenei mahi ka whakawhirinaki ki te parser ki te taru i nga mati-kore.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Ka wewete i te bignum ki te integer 64 moka.Panics mena he nui rawa te nama.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Tangohia ai te maha o nga paraire.

/// Ko te Tohu 0 te iti rawa o te waahanga, a ko te awhe he haurua tuwhera pera i nga wa katoa.
/// Panics mena ka tonohia kia tangohia etahi atu waahanga iti atu i te whakauru ki te momo whakahoki.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}