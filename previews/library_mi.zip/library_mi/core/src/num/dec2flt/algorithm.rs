//! Nga momo algorithms mai i te pepa.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Tuhinga o mua
const P: u32 = 64;

// He penapena noa ta maatau mo te *katoa* kaiwhakatairanga, na reira ka taea te karo i te taurangi "h" me nga tikanga e pa ana.
// Ka hokohoko tenei mahi mo nga kilobytes e rua o te waahi.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// I roto i te nuinga o nga hoahoanga, he maarama te rahi o nga mahi kaukau, no reira ka whakatauhia te maatauranga mo ia mahi.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// I te x86, ka whakamahia te x87 FPU mo nga mahi rewa mena kaore i te waatea nga toronga SSE/SSE2.
// Ko te x87 FPU e mahi ana me nga waahanga 80 o te tika ma te taunoa, ko te tikanga ka huri nga mahi ki te 80 paraire kia rua nga waahanga ka puta ka whakaatuhia ana nga uara hei
//
// 32/64 uara rewa moka.Hei wikitoria i tenei, ka taea te whakatakoto i te kupu whakahaere FPU kia mahia ai nga tatauranga i te waahanga tika e hiahiatia ana.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// He hanganga hei pupuri i te uara taketake o te kupu mana FPU, kia taea ai te whakahoki mai ka heke ana te hanganga.
    ///
    ///
    /// Ko te x87 FPU he rehita 16-paraire ana e whai ake nei:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Ko nga tuhinga mo nga mara katoa e waatea ana i te IA-32 Architectures Software Software Developer's Manual (Volume 1).
    ///
    /// Ko te mara anake e whai kiko ana mo te waehere e whai ake nei ko te PC, te Whakatau Whakatika.
    /// Ma tenei waahanga e whakarite te tika o nga mahi e mahia ana e te FPU.
    /// Ka taea te tautuhi ki:
    ///  - 0b00, kotahi te tikanga, 32-paraire
    ///  - 0b10, e rua taarua ie, 64-paraire
    ///  - i whakatoea 0b11, rua arā pū whānui, 80-paraire (kāwanatanga taunoa) te uara 0b01 te me kore kia whakamahia.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SAFETY: kua oti te arotake te tohutohu `fldcw` kia tika ai te mahi
        // tetahi `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Kei te whakamahia e matou te ATT taarua hei tautoko i te LLVM 8 me te LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Ka tautuhia te waahanga tika o te FPU ki te `T` ka whakahoki i te `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Tuhia te uara mo te Tohu Whakatau Whakatau e tika ana mo te `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 paraire
            8 => 0x0200, // 64 paraire
            _ => 0x0300, // taunoa, 80 paraire
        };

        // Tikina te uara taketake o te kupu mana ki te whakahoki mai a muri ake, ka whakahekehia te hanganga `FPUControlWord` SAFETY: kua arotakehia te tohutohu `fnstcw` kia taea ai te mahi tika me tetahi `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Kei te whakamahia e matou te ATT taarua hei tautoko i te LLVM 8 me te LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Whakatakotoria te kupu whakahaere ki te tika e hiahiatia ana.
        // Ka tutuki tenei ma te maakiri i nga waahanga tawhito (paraire 8 me 9, 0x300) ka whakakapi ki te haki tino taatai i runga ake nei.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Ko te ara tere o Bellerophon ma te whakamahi i nga miihini-rahi me nga taatai.
///
/// Ka tangohia tenei ki tetahi mahi motuhake kia taea ai te whakamatautau i mua i te hanganga o te bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Ka whakaritehia e maatau te uara tino ki MAX_SIG tata atu ki te mutunga, he tere tenei, he paopao iti (a ka whakawatea ano i te toenga o te waehere mai i te manukanuka ki te rerenga).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Ko te ara nohopuku ka whakawhirinaki ki te tatauranga ka huri i te rahinga o nga paraire me te kore porotaka takawaenga.
    // I te x86 (kaore he SSE, he SSE2 ranei) me whakarereke te tika o te puranga x87 FPU kia tika te huri ki te 64/32 moka.
    // Ma te mahi `set_precision` e whakarite te whakatakoto i runga i nga kaihoahoa hei whakarite ma te huri i te ahua o te ao (peera ki te kupu whakahaere mo te x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Ko te keehi e <0 kaore e taea te whakakopa ki etahi atu branch.
    // Ko nga mana kino ka hua te waahanga hautanga o te takirua, ka porotaka, ka hapa (i etahi waa ka nui te nui) he hapa i te otinga whakamutunga.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Ko te Algorithm Bellerophon he waeakore he mea tika na te wetewete tau kore-kore.
///
/// Ka hurihuri "f" ki te reanga me te 64 moka nui ka whakareatia ki te tata atu ki te `10^e` (i roto i te whakatakotoranga tohu taua) He nui tonu tenei kia ea ai nga hua tika.
/// Heoi, ki te tata te otinga o te haurua i waenga i te rua o te kaipuke (ordinary) e piri ana, ko te hapa porotaka whakauru mai i te whakareatanga e rua te tikanga ko te hua ka mate pea i etahi waahanga.
/// Ka pa ana tenei, ka whakatikatikahia e te Algorithm R rererangi nga mea katoa.
///
/// Ko te "close to halfway" ringa-a-ringa e tika ana ma te taatai tau i roto i te pepa.
/// Hei ki ta Clinger:
///
/// > Ko te Slop, ka whakaatuhia i roto i nga waahanga iti iti nei, he mea hono mo te he
/// > i whakaemihia i te wa e tatau ana te tatauranga tere ki te f * 10 ^ e.(Kiri te
/// > ehara i te mea herea mo te he pono, engari me taapiri te rereketanga i waenga i te tata z me te
/// > te whakatau tata rawa atu e taea ana te whakamahi i te paraire p..)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Ko nga keehi abs(e) <log5(2^N) kei te fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // He nui te taunga o te kokoru hei rereketanga ka huri ana ki te n paraire?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// He hātepe iterative e whakapai ake ana i te tohu tere o `f * 10^e`.
///
/// Ko ia korerotanga ka whakatata atu ki tetahi waahanga i te waahi whakamutunga, na te mea he roa tonu te hono mena kua mate a `z0`.
/// Waimarie, ka whakamahia ana hei hokinga whakamuri mo Bellerophon, ko te whakaohooho tiimata ka weto e te nuinga o te ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Rapua nga taurangi pai `x`, `y` penei ko te `x / y` he tino `(f *10^e) / (m* 2^k)`.
        // Kaore tenei e karo i te mahi ki nga tohu o te `e` me te `k`, ka whakakorehia ano hoki te kaha o te rua noa ki te `10^e` me te `2^k` kia iti ake ai nga nama.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // He mea ohorere tenei tuhituhi na te mea kaore o maatau tohu e tautoko i nga tau kino, no reira ka whakamahia e matou nga korero haina uara + haina.
        // Ko te whakareatanga me nga m_digits kaore e taea te taupoki.
        // Mena he nui te `x`, te `y` ranei, me awangawanga tatou mo te waipuke, ka nui hoki na `make_ratio` i whakaheke te hautau ma te waahanga 2 ^ 64 neke atu ranei.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Kaua e hiahia atu x, penapena he clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Me hiahia tonu y, mahi kape.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// I te `x = f` me te `y = m` kei hea te tohu `f` i te mati whakauru rite tonu me te `m` he tohu mo te tatauranga kaute, kia rite ki te `(f *10^e) / (m* 2^k)` te tauwehenga `x / y`, akene ka whakaitihia e te mana o te tokorua.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, engari me whakarite e tatou te hautau ki etahi mana o te rua.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Kaore e taea te neke ake na te mea e tika ana te `e` me te `k` kino, ka tutuki noa mo nga uara tata atu ki te 1, ko te tikanga ko te `e` me te `k` ka iti rawa.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Kaore hoki tenei e kaha ake, tirohia i runga ake nei.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), ka whakaiti ano i te mana noa o te rua.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Ki te whakaaro, ko te Algorithm M te huarahi ngawari ki te huri i te ira ki te reanga.
///
/// Ka waihangahia e matou he wehenga e rite ana ki te `f * 10^e`, ka maka ai i nga mana e rua kia hoatu ra ano he tiu tika whiti.
/// Ko te kaiwhakaatu takirua `k` te maha o nga wa i whakanuia ai e matou te tatauranga, te tohu ranei e rua, ara, i nga wa katoa `f *10^e` he rite ki te `(u / v)* 2^k`.
/// Mena kua mohio taatau, me huri noa ma te tirotiro i te toenga o te wehenga, ka mahia i nga mahi awhina i raro ake nei.
///
///
/// He tino puhoi tenei algorithm, ahakoa ko te arotautanga kua whakaahuatia i te `quick_start()`.
/// Heoi, ko te mea maamaa noa o te algorithms ki te urutau mo te taumaha, te rerenga, me nga hua kaore e tino kitea.
/// Ka riro tenei mahi i te wa e kaha rawa ana a Bellerophon me Algorithm R.
/// He maama te kimi i te rerenga me te taaputanga: Ko te tauwehenga kaore ano i te waahanga-whanui, engari kua tutuki te kaiwhakaari minimum/maximum.
/// I te wa o te waipuke, ka hoki noa taatau kore.
///
/// He uaua ake te whakahaere i te raro me nga subnormals.
/// Ko tetahi raru nui ko te, me te kaiwhakaatu iti, ka nui pea te tatauranga mo te hiranga.
/// Tirohia te underflow() mo nga korero taipitopito.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Whakatikahia te aromautanga ka taea: whanui i te nui_to_fp kia taea ai e taatau te rite ki te fp_to_float(big_to_fp(u)) i konei, me te kore te hurihuri takirua.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Me mutu taatau i te kaiwhakaatu iti rawa, mena ka tatari kia tae ra ano ki te `k < T::MIN_EXP_INT`, katahi ka rua nga waahanga ka wehe atu taatau.
            // Heoi ko te tikanga me motuhake taatau-nga keehi noa me te kaiwhakaatu iti.
            // FIXME kitea he mahinga ataahua ake, engari whakahaerehia te whakamatautau `tiny-pow10` kia mohio he tino tika!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Ka hipa i te nuinga o te taatai M te taarua ma te tirotiro i te roa o te waa.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Ko te roa o te waahanga ko te whakatau tata mo te turanga e rua te hangarite, me te log(u / v) = log(u), log(v).
    // Ko te whakatau tata kua neke atu i te 1, engari he iti tonu te whakatau tata, no reira ko te he o te log(u) me te log(v) he tohu kotahi ka whakakore (mena he nui nga mea e rua).
    // Na reira ko te he mo log(u / v) kei te nuinga kotahi ano hoki.
    // Ko te tauwehenga whaainga ko te mea kei roto a u/v i te-rohe whanui.Na ko to maatau waahanga whakamutu ko te log2(u / v) ko nga waahanga iti, plus/minus kotahi.
    // Whakatikangia Ko te titiro ki te waahanga tuarua ka pai ake te whakatau tata me te karo i etahi waahanga wehewehe.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Raro, whakahouhia ranei.Waiho ki te mahi matua.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Kaha.Waiho ki te mahi matua.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ko te tauwehenga ehara i te-i roto i te waahi nui me te iti rawa o te kaiwhakaputa, no reira me huri rawa te paraire me te whakatika i te kaiwhakaora kia rite.
    // Ko te penei inaianei te tino uara:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q putu (kua tohua e te rem)
    //
    // No reira, ka pau nga paraire porotaka!= 0.5 ULP, ka whakatauhia e ratau ta raatau ake.
    // Ka rite ana, ko te toenga he kore-kore, me noho tonu te uara.
    // Anake ana ko te 1/2 nga paraire kua porotaka, a ko te toenga he kore, he haurua-ki-te-katoa te ahuatanga.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Ko te rauna-a-tae noa ki te, aukatihia ma te huri noa i runga i te toenga o te wehenga.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}