//! Te whakamana me te wetewete i te aho a tekau o te puka:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! I etahi atu kupu, ko te wetewete tohu-tere noa, me nga okotahi e rua: Kaore he tohu, me te kore whakahaere i te "inf" me te "NaN".Ka whakahaerehia enei e te mahi taraiwa (super::dec2flt).
//!
//! Ahakoa he maamaa te mohio ki nga urunga tika, me paopao tenei waahanga ki nga rereketanga hē maha, kaua rawa ki te panic, me te mahi i nga arowhai maha e whakawhirinaki ana etahi atu waahanga ki te kore panic (ka neke atu ranei) ka huri.
//!
//! Ko te mea kino ake, ko nga mea katoa e pa ana ki te huringa kotahi mo te whakauru.
//! Na, kia tupato ki te whakarereke i tetahi mea, me taarua-takirua me etahi atu waahanga.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Nga waahanga whakamere o te aho ira.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Ko te kaiwhakatautau ā-ira, e kī ana kia iti ake i te 18 te mati ā-ira.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Ka tirotirohia mena he whaimana te tohu whakauru ki te aho whakauru mai te mea ana, tirohia te waahanga tuuturu, te waahanga hautanga, me te tohu o roto.
/// Kaore e hapai i nga tohu.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Kaore he mati i mua o te 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Te tikanga kia kotahi te mati kotahi i mua o muri mai ranei.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Ko te paraurehe i muri i te waahanga hautanga
            }
        }
        _ => Invalid, // Paraurehe i muri i te aho mati tuatahi
    }
}

/// Whakairohia nga tohu mati tae noa ki te tohu mati-kore tuatahi.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Tango Exponent me te arowhai hapa.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Paraurehe i muri i te kaiwhakaatu
    }
    if number.is_empty() {
        return Invalid; // Kaitohu Uruhi
    }
    // I tenei wa, he pai ake te aho o taatau.He roa pea te waiho ki te `i64`, engari mena he nui rawa atu, he kore, he mutunga kore ranei te whakauru.
    // I te mea ko te kore o nga mati a-ira e whakarereke ana i te kaiwhakaora ki te +/-1, i te exp=10 ^ 18 ko te whakauru he 17 exabyte (!) o nga iero kia tata atu ki te mutunga.
    //
    // Ehara tenei i te keehi whakamahinga hei whakatutuki maatau.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}