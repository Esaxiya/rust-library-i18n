//! Nga wa katoa mo te momo bit-64 kua hainatia.
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! Ko te waehere hou me whakamahi tika i nga tikanga taapiri ki te momo tawhito.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }