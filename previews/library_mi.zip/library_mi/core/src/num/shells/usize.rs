//! Nga wa katoa mo te momo tohu-kore tohu haukoti-kore.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Ko te waehere hou me whakamahi tika i nga tikanga taapiri ki te momo tawhito.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }