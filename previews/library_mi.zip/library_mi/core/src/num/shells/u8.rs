//! Nga wa katoa mo te momo-tau 8-bit kaore i hainatia.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Ko te waehere hou me whakamahi tika i nga tikanga taapiri ki te momo tawhito.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }