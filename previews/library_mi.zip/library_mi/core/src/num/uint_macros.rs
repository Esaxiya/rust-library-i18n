macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Ko te uara iti rawa ka taea te tohu mo tenei momo integer.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Ko te uara nui rawa atu ka taea e tenei momo taurangi.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Te rahi o tenei momo integer i nga paraire.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Tahuri ai i te poro aho ki te putunga i homai ki te tauoti.
        ///
        /// Ko te tohu ko te tohu `+` kowhiringa ka whai tohu.
        ///
        /// Ko te arahi ma te takahi i te waahi ma e tohu ana he he.
        /// Ko te Digits tetahi waahanga o enei taangata, i te `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Ko tenei mahi panics mena kaore a `radix` i te awhe mai i te 2 ki te 36.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Whakahokia ai te maha o nga mea kei roto i te whakaaturanga ruarua o `self`.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Whakahoki ai i te maha o nga takirua i te whakaaturanga ruarua o `self`.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Whakahoki ai i te maha o nga toenga nui i te whakaaturanga ruarua o `self`.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Whakahoki ai i te maha o nga takoha haerere i te whakaaturanga rua o `self`.
        ///
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Whakahoki ai i te maha o nga kaiarahi i te whakaaturanga ruarua o `self`.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Whakahoki ai i te maha o nga mea e whai ana i te whakaaturanga ruarua o `self`.
        ///
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Ka huri i nga paraire ki te taha maui ma te rahinga kua tohua, `n`, ka takai i nga paraire kua tapahia ki te pito o te kohinga hua.
        ///
        ///
        /// Kia mahara ehara tenei i te mahi rite ki te kaiwhakahaere neke `<<`!
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Ka huri i nga paraire ki te taha matau ma te rahinga kua tohua, `n`, ka takai i nga paraire kua tapahia ki te tiimatanga o te tauoti hua.
        ///
        ///
        /// Kia mahara ehara tenei i te mahi rite ki te kaiwhakahaere neke `>>`!
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Ka huria te ota paita o te tauoti.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// tukua m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Ka huria te ota paraire i te tauoti.
        /// Ko te moka iti rawa ka waiho hei moka nui whakahirahira, ko te waahanga iti iti-nui ka waiho hei waahanga tuarua nui-nui, me etahi atu.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// tukua m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Ka huri i te integer mai i endian nui ki te mutunga o te whaainga.
        ///
        /// I runga i te mutunga nui ko te kore-op tenei.
        /// I runga i te endian iti ka huri nga paita.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ki te cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } atu {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Ka huri i te integer mai i te iti endian ki te mutunga o te whaainga.
        ///
        /// I runga i te endian iti he no-op tenei.
        /// I runga i te endian nui ka huri nga paita.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ki te cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } atu {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Ka huri i te `self` ki te mutunga nui mai i te mutunga o te whaainga.
        ///
        /// I runga i te mutunga nui ko te kore-op tenei.
        /// I runga i te endian iti ka huri nga paita.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ki te cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } atu { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // kaore ranei hei?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Ka huri i te `self` ki te iti o te mutunga o te mutunga o te whaainga.
        ///
        /// I runga i te endian iti he no-op tenei.
        /// I runga i te endian nui ka huri nga paita.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ki te cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } atu { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Kua taapirihia te taapiringa tauoti.
        /// Ka whakaarohia te `self + rhs`, ka whakahoki i te `None` mena i puta mai te waipuke.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Taapiringa tauoti kore kua tirohia.Ka whakaarohia te `self + rhs`, me te whakaaro kaore e taea te puta ake.
        /// Ma tenei ka puta he whanonga kore i te waa
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Kua tangohia te whakawairua tauoti.
        /// Ka whakaarohia te `self - rhs`, ka whakahoki i te `None` mena i puta mai te waipuke.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tangohanga tau tōpū kua taki tirohia.Ka whakaarohia te `self - rhs`, me te whakaaro kaore e taea te puta ake.
        /// Ma tenei ka puta he whanonga kore i te waa
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Takina tōpū whakarea.
        /// Ka whakaarohia te `self * rhs`, ka whakahoki i te `None` mena i puta mai te waipuke.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Whakareatanga tau tōpū taki.Ka whakaarohia te `self * rhs`, me te whakaaro kaore e taea te puta ake.
        /// Ma tenei ka puta he whanonga kore i te waa
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Takina tōpū wehenga.
        /// Ka whakaarohia te `self / rhs`, ka whakahoki i te `None` mena ko `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAFETY: div na te kore kua tirotirohia i runga ake nei me nga momo waitohu kaore he atu
                // nga ahuatanga ngoikore mo te wehewehe
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Kua tirohia te wehenga o Euclidean.
        /// Ka whakaarohia te `self.div_euclid(rhs)`, ka whakahoki i te `None` mena ko `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Kua tohaina te toenga tauoti.
        /// Ka whakaarohia te `self % rhs`, ka whakahoki i te `None` mena ko `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAFETY: div na te kore kua tirotirohia i runga ake nei me nga momo waitohu kaore he atu
                // nga ahuatanga ngoikore mo te wehewehe
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Kua tirohia te tauira Euclidean.
        /// Ka whakaarohia te `self.rem_euclid(rhs)`, ka whakahoki i te `None` mena ko `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Whakakoretanga kua tirohia.Ka tatau i te `-self`, ka whakahoki i te `None` engari mena ko `koe==
        /// 0`.
        ///
        /// Kia mahara, ko te whakakore i nga tau kore totika ka puhake.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Neke huringa maui.
        /// Ka whakaarohia te `self << rhs`, ka whakahoki i te `None` mena he nui ake te `rhs` i te rite ranei ki te maha o nga paraire i te `self`.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// tika neke takina.
        /// Ka whakaarohia te `self >> rhs`, ka whakahoki i te `None` mena he nui ake te `rhs` i te rite ranei ki te maha o nga paraire i te `self`.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kua tirohia te honohonohono.
        /// Ka whakaarohia te `self.pow(exp)`, ka whakahoki i te `None` mena i puta mai te waipuke.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // mai exp!=0, te mutunga ko te exp me 1.
            // Me mahi wehe te waahanga whakamutunga o te kaiwhakaputa, na te mea ko te tapawha i te papa o muri kaore e tika ana kia nui ake ai te rere.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Taapiringa atu o te integer.
        /// Ka tatau i te `self + rhs`, e makona ana i nga rohe kaore e nui ake.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Te tango i te tau tōpū.
        /// Ka tatau i te `self - rhs`, e makona ana i nga rohe kaore e nui ake.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Whakareatanga integer whakarea
        /// Ka tatau i te `self * rhs`, e makona ana i nga rohe kaore e nui ake.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Whakakona tauwehenga tau.
        /// Ka tatau i te `self.pow(exp)`, e makona ana i nga rohe kaore e nui ake.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Te takai (modular) taapiri.
        /// Ka whakauruhia te `self + rhs`, ka takaihia i te rohe o te momo.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Takai (modular) tangohanga.
        /// Ka whakauruhia te `self - rhs`, ka takaihia i te rohe o te momo.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Takai (modular) whakareatanga.
        /// Ka whakauruhia te `self * rhs`, ka takaihia i te rohe o te momo.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// Kia mahara ko tenei tauira ka tohaina ki waenga i nga momo taurangi.
        /// E whakamaarama ana he aha i whakamahia ai te `u8` ki konei.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Tākai (modular) wehenga.Kaute `self / rhs`.
        /// Ko te wehenga kua takai ki nga momo waitohu he wehe noa.
        /// Kaore he huarahi hei takai.
        /// Kei te noho tenei mahi, na ka kiia nga mahi katoa kei roto i nga mahi takai.
        ///
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Te takai i te wehenga Euclidean.Kaute `self.div_euclid(rhs)`.
        /// Ko te wehenga kua takai ki nga momo waitohu he wehe noa.
        /// Kaore he huarahi hei takai.
        /// Kei te noho tenei mahi, na ka kiia nga mahi katoa kei roto i nga mahi takai.
        /// Na te mea, mo nga tau tōpū, he rite katoa nga whakamaaramatanga o te wehenga, he rite tonu tenei ki te `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Te takai i te toenga (modular).Kaute `self % rhs`.
        /// Ko te tatauranga toenga takai ki nga momo kore waitohu ko te tatauranga toenga noa.
        ///
        /// Kaore he huarahi hei takai.
        /// Kei te noho tenei mahi, na ka kiia nga mahi katoa kei roto i nga mahi takai.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Te takai i te Euclidean modulo.Computes `self.rem_euclid(rhs)`.
        /// Ko te tatauranga modulo kua takai ki nga momo kore waitohu ko te tatauranga toenga noa.
        /// Kaore he huarahi hei takai.
        /// Kei te noho tenei mahi, na ka kiia nga mahi katoa kei roto i nga mahi takai.
        /// Na te mea, mo nga tau tōpū, he rite katoa nga whakamaaramatanga o te wehenga, he rite tonu tenei ki te `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Te takai (modular) whakakorekore.
        /// Ka whakauruhia te `-self`, ka takaihia i te rohe o te momo.
        ///
        /// I te mea kaore he taurite o nga momo waitohu kaore e taurite nga tono katoa mo tenei mahi (haunga te `-0`).
        /// Mo nga uara iti ake i te rahinga o te momo hainatanga he rite te mutunga ki te panga i te uara hainatanga e haangai ana
        ///
        /// Ko nga uara nui ake ka rite ki te `MAX + 1 - (val - MAX - 1)` ko te `MAX` te rahinga o te momo hainatanga.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// Kia mahara ko tenei tauira ka tohaina ki waenga i nga momo taurangi.
        /// E whakamaarama ana he aha i whakamahia ai te `i8` ki konei.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-kore huri noa i te taha maui-maui;
        /// hua `self << mask(rhs)`, te wahi `mask` ka tango i nga waahanga teitei-nui o `rhs` ka nui ake te neke ki te bitwidth o te momo.
        ///
        /// Kia mahara ehara tenei *i te* rite ki te takahuri-maui;ko te RHS o te takai-maui-aukati e aukati ana ki te whānuitanga o te momo, kaua ki nga paraire kua nekehia atu i te LHS ka whakahokia ki tetahi atu pito.
        /// Ko nga momo integer primitive e whakamahi katoa ana i te mahi [`rotate_left`](Self::rotate_left), akene koina pea taau e hiahia ana.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SAFETY: ko te maaka ma te paraire o te momo e whakarite kia kaua e neke
            // Tuhinga o mua
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-kore-neke neke-matau;
        /// hua `self >> mask(rhs)`, te wahi `mask` ka tango i nga waahanga teitei-nui o `rhs` ka nui ake te neke ki te bitwidth o te momo.
        ///
        /// Kia mahara ehara tenei *i te* rite ki te takahuri-matau;ko te RHS o te takai-matau takai ka herea ki te whānuitanga o te momo, kaua ki nga paraire kua nekehia atu i te LHS ka whakahokia ki tetahi atu pito.
        /// Ko nga momo integer primitive e whakamahi katoa ana i te mahi [`rotate_right`](Self::rotate_right), akene koina pea taau e hiahia ana.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SAFETY: ko te maaka ma te paraire o te momo e whakarite kia kaua e neke
            // Tuhinga o mua
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Te takai (modular) whakarangatiratanga.
        /// Ka whakauruhia te `self.pow(exp)`, ka takaihia i te rohe o te momo.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // mai exp!=0, te mutunga ko te exp me 1.
            // Me mahi wehe te waahanga whakamutunga o te kaiwhakaputa, na te mea ko te tapawha i te papa o muri kaore e tika ana kia nui ake ai te rere.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Ka tatau `self` + `rhs`
        ///
        /// Whakahokihia he tupiri o te taapiri me te boolean e tohu ana ka puta mai he pikinga arithmetic.
        /// Mena i puta he pareparenga ka whakahokia mai te uara kua takaia.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ka tatau `self`, `rhs`
        ///
        /// Whakahoki ai i te tuple o te tangohanga me te boolean e tohu ana ka puta mai he pikitanga arithmetic.
        /// Mena i puta he pareparenga ka whakahokia mai te uara kua takaia.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ka tatau i te whakarea o `self` me `rhs`.
        ///
        /// Whakahokia ai he tuple o te whakareatanga me te boolean e tohu ana ka puta mai he pikitanga arithmetic.
        /// Mena i puta he pareparenga ka whakahokia mai te uara kua takaia.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// Kia mahara ko tenei tauira ka tohaina ki waenga i nga momo taurangi.
        /// E whakamaarama ana he aha i whakamahia ai te `u32` ki konei.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ka tatau i te kaitoha i te wa ka wehehia a `self` e `rhs`.
        ///
        /// Whakahoki mai i tetahi tuple o te kaiwehe me te boolean e tohu ana mena ka puta te taumaha tau.
        /// Kia mahara mena kaore e puea ake nga tauoti kore waitohu, no reira ko te uara tuarua `false` tonu.
        ///
        /// # Panics
        ///
        /// Ka panic tenei mahi mena ko `rhs` te 0.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Ka taatai i te waahanga o te wehenga Euclidean `self.div_euclid(rhs)`.
        ///
        /// Whakahoki mai i tetahi tuple o te kaiwehe me te boolean e tohu ana mena ka puta te taumaha tau.
        /// Kia mahara mena kaore e puea ake nga tauoti kore waitohu, no reira ko te uara tuarua `false` tonu.
        /// Na te mea, mo nga tau tōpū, he rite katoa nga whakamaaramatanga o te wehenga, he rite tonu tenei ki te `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ka panic tenei mahi mena ko `rhs` te 0.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Ka tatauhia te toenga ka tohaina a `self` e `rhs`.
        ///
        /// Whakahoki mai i te toenga o te toenga i muri o te whakawehe me te boolean e tohu ana mena ka puta he taumaha tau.
        /// Kia mahara mena kaore e puea ake nga tauoti kore waitohu, no reira ko te uara tuarua `false` tonu.
        ///
        /// # Panics
        ///
        /// Ka panic tenei mahi mena ko `rhs` te 0.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Ka tatauhia te toenga `self.rem_euclid(rhs)` me te mea na te wehenga o Euclidean.
        ///
        /// Whakahokia ai he tuple o te modulo i muri i te wehewehe me te boolean e tohu ana ka puea ake te kaha o te tatau.
        /// Kia mahara mena kaore e puea ake nga tauoti kore waitohu, no reira ko te uara tuarua `false` tonu.
        /// I te mea, mo nga tau tōpū, he rite katoa nga whakamaaramatanga o te wehenga, he rite tonu tenei mahinga ki te `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ka panic tenei mahi mena ko `rhs` te 0.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Ka whakahee i a ia ano me te ahua nui
        ///
        /// Whakahoki ai i te `!self + 1` ma te whakamahi i nga mahi takai ki te whakahoki i te uara e tohu ana i te whakakorekore o tenei uara kore hainatia.
        /// Kia maumahara mo nga uara kore hainatia pai ka pupuru tonu, engari ko te whakakore i te 0 kaore e neke ake.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Ka neke ke ia ma te `rhs` paraire e waiho.
        ///
        /// Whakahokia ai he tuple o te momo nekehanga ake o koe me te boolean e tohu ana he nui ake te uara neke atu i te rite ranei ki te maha o nga paraire.
        /// Mena he nui te uara neke, ka hipokina te uara (N-1) ko te N te maha o nga paraire, ka whakamahia tenei uara hei whakamahi i te neke.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Ka huri tika i a `rhs` paraire.
        ///
        /// Whakahokia ai he tuple o te momo nekehanga ake o koe me te boolean e tohu ana he nui ake te uara neke atu i te rite ranei ki te maha o nga paraire.
        /// Mena he nui te uara neke, ka hipokina te uara (N-1) ko te N te maha o nga paraire, ka whakamahia tenei uara hei whakamahi i te neke.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Ka ara ake i a ia ki te kaha o `exp`, ma te whakamahi i te whaarangahono ma te tapawha.
        ///
        /// Whakahokia te tuple o te mana rea me ki te bool tohu ranei tupu te waipuke.
        ///
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, pono));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Mokowhiti mo te penapena i nga hua o te tupuranga_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // mai exp!=0, te mutunga ko te exp me 1.
            // Me mahi wehe te waahanga whakamutunga o te kaiwhakaputa, na te mea ko te tapawha i te papa o muri kaore e tika ana kia nui ake ai te rere.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Ka ara ake i a ia ki te kaha o `exp`, ma te whakamahi i te whaarangahono ma te tapawha.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // mai exp!=0, te mutunga ko te exp me 1.
            // Me mahi wehe te waahanga whakamutunga o te kaiwhakaputa, na te mea ko te tapawha i te papa o muri kaore e tika ana kia nui ake ai te rere.
            //
            //
            acc * base
        }

        /// Ka mahi wehenga Euclidean.
        ///
        /// Mai, mo nga tau tōpu pai, he rite whakamāramatanga noa katoa o wehenga, he rite rite ki `self / rhs` tenei.
        ///
        ///
        /// # Panics
        ///
        /// Ka panic tenei mahi mena ko `rhs` te 0.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Ka tatauhia te toenga iti rawa o te `self (mod rhs)`.
        ///
        /// Na te mea, mo nga tau tōpū, he rite katoa nga whakamaaramatanga o te wehenga, he rite tonu tenei ki te `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ka panic tenei mahi mena ko `rhs` te 0.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Whakahoki `true` mena ka `self == 2^k` anake mo etahi `k`.
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Whakahoki mai ai i te mea iti iho i te kaha o muri mai o te rua.
        // (Mo te mana 8u8 o muri ko te 8u8 me te 6u8 ko te 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Kaore e taea e tenei tikanga te waipuke, penei i nga keehi kaputa `next_power_of_two` ka mutu ka hoki mai te uara nui o te momo, ka taea te whakahoki 0 mo te 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // HAUMARU: No te mea `p > 0`, e kore e taea e ngā reira katoa o ārahi ngā kore.
            // Ko te tikanga ko te nekehanga he-i roto i te rohe, me etahi tukatuka (penei i te intel i mua-haswell) he pai ake nga kaiwhakauru o te CTlz ka kore te tautohe e kore-kore.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Whakahoki ai i te mana iti rawa o te rua nui ake i te orite ki te `self` ranei.
        ///
        /// Ka nui ana te uara whakahoki (arā, `self > (1 << (N-1))` mo te momo `uN`), panics i te aratau patuiro me te uara whakahoki ka takaihia ki te 0 i roto i te mahinga tuku (ko te ahuatanga anake ka taea e te tikanga te whakahoki 0).
        ///
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Whakahoki ai i te mana iti rawa o te rua nui ake i te orite ki te `n` ranei.
        /// Mena he nui ake te mana o muri e rua i te uara nui o te momo, ka whakahokia mai a `None`, ki te kore ka takaihia te mana o te rua ki te `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Whakahoki ai i te mana iti rawa o te rua nui ake i te orite ki te `n` ranei.
        /// Mena he nui ake te mana o muri e rua i te uara nui o te momo, ka takaihia te uara whakahoki ki te `0`.
        ///
        ///
        /// # Examples
        ///
        /// Whakamahi taketake:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Whakahokihia te tohu whakamaharatanga o tenei integer hei paita paita i roto i te ota paita (network) nui-mutunga.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Whakahokihia te tohu whakamaharatanga o tenei integer hei paita paita i roto i te raupapa paita iti-mutunga.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Whakahokihia te tohu whakamaharatanga o tenei tau hei taputapu paita i te raupapa pauna maori.
        ///
        /// I te mutunga o te maatapuna o te whaainga e whakamahia ana, me whakamahi te waehere kawe i te [`to_be_bytes`], te [`to_le_bytes`] ranei, ina tika ana.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     paita, mena CFg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } atu {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: tangi tangi na te mea he totatata nga putake tawhito tawhito ka taea e taatau i nga wa katoa
        // whakawhiti ki nga raarangi paita
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SAFETY: ko nga integers he taatai tawhito kia taea ai e tatou te whakawhiti atu ki a raatau
            // Tuhinga o mua
            unsafe { mem::transmute(self) }
        }

        /// Whakahokihia te tohu whakamaharatanga o tenei tau hei taputapu paita i te raupapa pauna maori.
        ///
        ///
        /// [`to_ne_bytes`] kia nui ake i tenei i nga wa katoa ka taea.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// kia paita= num.as_ne_bytes();
        /// assert_eq!(
        ///     paita, mena CFg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } atu {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SAFETY: ko nga integers he taatai tawhito kia taea ai e tatou te whakawhiti atu ki a raatau
            // Tuhinga o mua
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Hangaia he uara tauotiwi taketake a te tangata mai i tana whakaaturanga hei paita paita i roto i te endian nui.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// whakamahi std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * whakauru=okiokinga;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Hangaia he uara tauotiwi taketake mai i tana whakaaturanga hei paita paita i te iti o te endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// whakamahi std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * whakauru=okiokinga;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Hangaia he uara integer taketake maori mai i tana whakaaturanga whakamaharatanga hei paita pauna i roto i te maori tuuturu.
        ///
        /// I te mutunga o te whaainga o te papa whaainga e whakamahia ana, ko te waehere kawe pea e hiahia ana ki te whakamahi i te [`from_be_bytes`] me te [`from_le_bytes`], i te mea e tika ana.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } atu {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// whakamahi std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * whakauru=okiokinga;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: tangi tangi na te mea he totatata nga putake tawhito tawhito ka taea e taatau i nga wa katoa
        // whakawhiti ki a ratou
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SAFETY: ko nga integers he putunga tawhito tawhito kia taea ai e tatou te whakawhiti atu ki a raatau
            unsafe { mem::transmute(bytes) }
        }

        /// Ko te waehere hou me pai ki te whakamahi
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Whakahoki ai i te uara iti rawa ka taea te tohu mo tenei momo integer.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Ko te waehere hou me pai ki te whakamahi
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Whakahoki ai i te uara nui rawa atu ka taea e tenei momo integer.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}