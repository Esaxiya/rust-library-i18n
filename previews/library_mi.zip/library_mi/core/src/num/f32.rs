//! Ko nga wa katoa e tika ana mo te `f32` momo tohu rererangi takitahi-tika.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! He maha nga tohu pangarau kei roto i te waahanga-iti `consts`.
//!
//! Mo nga taapiri kua tautuhia tika ki tenei waahanga (kia rereke i era kua tautuhia ki te waahanga-iti `consts`), ma te waehere hou me whakamahi nga taapiri hono kua tautuhia tika ki te momo `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Ko te radix, ko te turanga ranei o te whakaaturanga a-roto o te `f32`.
/// Whakamahia [`f32::RADIX`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // ara tikanga
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Tau o nga mati nui i te turanga 2.
/// Whakamahia [`f32::MANTISSA_DIGITS`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // ara tikanga
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Tau tatauranga o nga mati nui kei te papa 10.
/// Whakamahia [`f32::DIGITS`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // ara tikanga
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] uara mo `f32`.
/// Whakamahia [`f32::EPSILON`] hei utu.
///
/// Koinei te rereketanga i waenga i te `1.0` me te tau nui ake e whai ake nei.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // ara tikanga
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Iti rawa te uara `f32` uara.
/// Whakamahia [`f32::MIN`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // ara tikanga
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Iti rawa te uara `f32` pai.
/// Whakamahia [`f32::MIN_POSITIVE`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // ara tikanga
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Nui rawa te uara `f32` uara.
/// Whakamahia [`f32::MAX`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // ara tikanga
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Kotahi te mea nui ake i te iti rawa te kaha o te 2 kaiwhakaari.
/// Whakamahia [`f32::MIN_EXP`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // ara tikanga
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Te kaha nui rawa atu o te 2 kaiwhakatairanga.
/// Whakamahia [`f32::MAX_EXP`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // ara tikanga
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Te iti rawa o te mana noa o te 10 kaiwhakaari.
/// Whakamahia [`f32::MIN_10_EXP`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // ara tikanga
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Te kaha pea mo te 10 kaiwhakaari.
/// Whakamahia [`f32::MAX_10_EXP`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // ara tikanga
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Ehara i te Nama (NaN).
/// Whakamahia [`f32::NAN`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // ara tikanga
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Mutunga Kore (∞).
/// Whakamahia [`f32::INFINITY`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // ara tikanga
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Te mutunga kore (−∞).
/// Whakamahia [`f32::NEG_INFINITY`] hei utu.
///
/// # Examples
///
/// ```rust
/// // ara tauwhāitihia
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // ara tikanga
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Nga tikanga tikanga pangarau.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: whakakapia ki nga tikanga pangarau mai i te cmath.

    /// Archimedes (π) tuturu
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Te porowhita katoa tonu (τ)
    ///
    /// Alrite ki te 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Tau a Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Ko te radix, ko te turanga ranei o te whakaaturanga a-roto o te `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Tau o nga mati nui i te turanga 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Tau tatauranga o nga mati nui kei te papa 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] uara mo `f32`.
    ///
    /// Koinei te rereketanga i waenga i te `1.0` me te tau nui ake e whai ake nei.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Iti rawa te uara `f32` uara.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Iti rawa te uara `f32` pai.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Nui rawa te uara `f32` uara.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Kotahi te mea nui ake i te iti rawa te kaha o te 2 kaiwhakaari.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Te kaha nui rawa atu o te 2 kaiwhakatairanga.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Te iti rawa o te mana noa o te 10 kaiwhakaari.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Te kaha pea mo te 10 kaiwhakaari.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Ehara i te Nama (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Mutunga Kore (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Te mutunga kore (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Whakahoki `true` mena ko te uara tenei ko `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): Kaore a `abs` i te waatea i te waatea na te mea he awangawanga mo te kawe, no reira ko tenei whakamahinga hei whakamahi maau ake i roto.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Whakahoki mai ai i te `true` mena he pai ake te uara, he mutunga kore ranei, me te `false` kaore.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Whakahoki ai i te `true` mena kaore tenei nama i te mutunga kore ranei `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Kaore he take o te whakahaere wehe i a NaN: mena ko NaN tonu, kaore i te pono te whakataurite, e rite ana ki te hiahia.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Whakahoki `true` mena ko te nama [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Ko nga uara i waenga i te `0` me te `min` he Iti noa.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Whakahoki ai i te `true` mena kaore te nama i te kore, mutunga kore, [subnormal], `NaN` ranei.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Ko nga uara i waenga i te `0` me te `min` he Iti noa.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Whakahoki ai i te kāwai tohu mānu o te nama.
    /// Mena kotahi noa te rawa ka whakamatautauria, he tere ake te whakamahi i te tohu motuhake.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Whakahoki mai ai i te `true` mena he tohu pai to `self`, tae atu ki te `+0.0`, `NaN`s me te tohu tohu pai me te mutunga kore pai.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Whakahoki ai i te `true` mena he tohu kino to `self`, tae atu ki te `-0.0`, `NaN`s me te tohu tohu kino me te mutunga kore kino.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // E kii ana a IEEE754: He pono te isSignMinus(x) mena mena he tohu kino to x.
        // isSignMinus e pa ana ki nga kore me nga NaN hoki.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Tangohia te (inverse) tauutuutu o te tau, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Ka huri i nga radian ki nga nekehanga.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Whakamahia he taapiri kia pai ake ai te mahi.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Hurihia nga tohu ki nga radian.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Whakahoki ai i te rahinga o nga nama e rua.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Mena ko tetahi o nga tautohe ko NaN, katahi ka whakahokia mai tetahi atu tohenga.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Whakahoki ai i te iti o nga tau e rua.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Mena ko tetahi o nga tautohe ko NaN, katahi ka whakahokia mai tetahi atu tohenga.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Ka rauna ki te kore ka huri ki nga momo integer tawhito, me te kii he iti te uara ka uru ki taua momo.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Te uara me:
    ///
    /// * Kaua hei `NaN`
    /// * Kaua hei mutunga
    /// * Me whakaatu i te momo whakahoki `Int`, i muri i te tapahi i tana waahanga hautanga
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Te whakawhiti noa ki te `u32`.
    ///
    /// He rite tenei ki te `transmute::<f32, u32>(self)` kei runga i nga papa katoa.
    ///
    /// Tirohia te `from_bits` mo etahi korero mo te kaha o tenei mahi (kaore pea he take)
    ///
    /// Kia mahara he rereke tenei mahi mai i te tuku `as`, e ngana ana ki te pupuri i te uara *tau*, kaore i te uara iti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() kaore i te maka!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // SAFETY: `u32` he momo raraunga tawhito maamaa kia taea ai e tatou te whakawhiti atu ki a ia i nga wa katoa
        unsafe { mem::transmute(self) }
    }

    /// Tuhinga mai i te `u32`.
    ///
    /// He rite tenei ki te `transmute::<u32, f32>(v)` kei runga i nga papa katoa.
    /// Ka puta ke he kawe tino nui tenei, na te mea e rua nga take:
    ///
    /// * He rite ano te mutunga o nga Floats me Ints ki runga i nga kaupapa tautoko katoa.
    /// * Ko te IEEE-754 e tino whakarite ana i te whakatakotoranga o nga waahanga.
    ///
    /// Heoi kotahi ano te whakatupato: i mua o te putanga 2008 o te IEEE-754, me pehea te whakamaori i te tohu tohu NaN kaore i tino tohua.
    /// Ko te nuinga o nga papa (ko te x86 me te ARM) i kowhiria te whakamaori i whakamanahia i te tau 2008, engari ko etahi kaore (ko MIPS pea).
    /// I te mutunga, ko nga NaN tohu katoa kei runga i te MIPS he noho humarie NaN i te x86, me te tua atu.
    ///
    /// Engari ki te tarai ki te pupuri i te papa-whakawhiti-kore, ko tenei whakatinana he pai ki te tiaki i nga paraire tika.
    /// Ko te tikanga ko nga utunga e whakawaeherehia ana i roto i nga NaN ka tiakina ahakoa ka tukuna te hua o tenei tikanga ki runga whatunga mai i te miihini x86 ki te MIPS.
    ///
    ///
    /// Mena ko nga hua o tenei tikanga ka rawekehia e te hoahoanga tonu nana i whakaputa, kaore he awangawanga kawe.
    ///
    /// Mena kaore te NaN o te urunga, kaore he awangawanga kawe.
    ///
    /// Mena kaore koe e aro ki te tohu tohu (tera pea), kaare he awangawanga kawe.
    ///
    /// Kia mahara he rereke tenei mahi mai i te tuku `as`, e ngana ana ki te pupuri i te uara *tau*, kaore i te uara iti.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // SAFETY: `u32` he momo raraunga tawhito maamaa kia taea ai e tatou te whakawhiti mai i taua waa
        // Ka puta ko nga take haumaru me te sNaN kua kaha rawa!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// Whakahokihia te tohu whakamaharatanga o tenei nama ira maawewe hei raupapa paita i roto i te ota paita (network) nui-mutunga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Whakahokihia te tohu whakamaharatanga o tenei nama ira maawewe hei raupapa paita i roto i te raupapa paita iti-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Whakahokihia te tohu whakamaharatanga o tenei nama ira tere hei huinga paita i te raupapa pauna maori.
    ///
    /// I te mutunga o te maatapuna o te whaainga e whakamahia ana, me whakamahi te waehere kawe i te [`to_be_bytes`], te [`to_le_bytes`] ranei, ina tika ana.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Whakahokihia te tohu whakamaharatanga o tenei nama ira tere hei huinga paita i te raupapa pauna maori.
    ///
    ///
    /// [`to_ne_bytes`] kia nui ake i tenei i nga wa katoa ka taea.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // SAFETY: `f32` he momo raraunga tawhito maamaa kia taea ai e tatou te whakawhiti atu ki a ia i nga wa katoa
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Hangaia he uara mauruuru mai i tana whakaaturanga hei paita paita i roto i te endian nui.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Hangaia he uara maungarongo mai i tana whakaaturanga hei paita paita i te mutunga o te mutunga.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Hangaia he uara maungarongo mai i tona whakaaturanga hei paita paita i roto i te reo taketake Maori.
    ///
    /// I te mutunga o te whaainga o te papa whaainga e whakamahia ana, ko te waehere kawe pea e hiahia ana ki te whakamahi i te [`from_be_bytes`] me te [`from_le_bytes`], i te mea e tika ana.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Whakahoki ai i te ota i waenga i a koe ano me etahi atu uara.
    /// Kaore i rite ki te whakataurite waahanga paatete i waenga i nga tau tere, ko tenei whakataurite he whakaputa i nga ota kia rite ki te katoa o nga tohu Kaiwhakahaere kua tautuhia ki te IEEE 754 (2008 whakahou) paerewa ira tere.
    /// Ko nga uara kei te ota e whai ake nei:
    /// - Noho humarie NaN
    /// - Tohu tohu kino NaN
    /// - Mutu mutunga kore
    /// - Tau kino
    /// - Tau kino kore
    /// - Kore kino
    /// - Kore pai
    /// - Nga tau takirua pai
    /// - Tau pai
    /// - Mutu mutunga kore
    /// - Positive kē Nan
    /// - Ata noho pai NaN
    ///
    /// Kia mahara kaore tenei mahi e whakaae katoa ki nga whakamahinga [`PartialOrd`] me [`PartialEq`] o `f32`.Ina hoki, ko te kore o te kino me te pai he rite, engari kaore a `total_cmp`.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Mena he kino, porehia nga paraire katoa engari ko te tohu hei whakatutuki i tetahi whakatakotoranga rite ki nga integers e rua
        //
        // He aha ai i mahi ai?Ko te IEEE 754 e rewa ana e toru nga waahi:
        // Moka tohu, kaiwhakaari me te mantissa.Ko te kohinga o te mara whaihua me te mantissa katoa, kei i a raatau te taonga e rite ana te raupapa paku ki te rahi o te tau e tautuhia ana te rahi.
        // Kaore te tikanga e tautuhia ki nga uara NaN, engari ko te IEEE 754 katoaOrder e tautuhi ana i nga uara NaN ki te whai i te raupapa iti.Ka arahina tenei ki te ota kua whakamaramatia i roto i te tuhinga a te tuhinga.
        // Heoi, ko te whakaaturanga o te nui he rite mo nga tau kino me te pai-he rereke noa te tohu tohu.
        // Hei whakataurite i nga waatea kia rite ki nga integers kua hainatia, me huri nga kaiwhakawhanake me nga mowhiti mantissa mena he tau kino.
        // He pai te huri i nga tau ki te puka "two's complement".
        //
        // Ki te mahi i te piupiu, ka hangaia he kopare kanohi me te XOR ki a ia.
        // Ka kore e taatai i te miihini "all-ones except for the sign bit" mai i nga uara kua hainatia-kore: ko te tohu neke tika-ka toro atu i te tau, no reira ka "fill" te kopare me nga tohu tohu, ka huri ki te kore waitohu kia peehi ano i te moka kore.
        //
        // I runga i nga uara pai, ko te kopare he kaero katoa, na he kore-kore.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Whakawhāiti te uara ki tētahi wā kia kore ko NaN.
    ///
    /// Whakahoki ai i te `max` mena he nui ake te `self` i te `max`, me te `min` mena he iti iho te `self` i te `min`.
    /// Ki te kore ka hoki mai tenei `self`.
    ///
    /// Kia mahara ko tenei mahi ka whakahoki NaN mena ko te uara tuatahi ko NaN hoki.
    ///
    /// # Panics
    ///
    /// Panics mena ko `min > max`, `min` ko NaN, ko `max` ko NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}