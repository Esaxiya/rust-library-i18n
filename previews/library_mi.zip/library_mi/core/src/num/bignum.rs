//! Ritenga whaimana-tino tau (bignum) whakatinana.
//!
//! I hangaia tenei hei karo i te tohatoha puranga hei utu mo te maumahara o te puranga.
//! Ko te momo bignum tino whakamahia, `Big32x40`, he mea iti na 32 × 40=1,280 paraire, ka neke ake i te 160 paita mahara mahara taapiri.
//! He nui ake tenei mo te takahi i nga uara `f64` katoa ka taea.
//!
//! I runga i te tikanga ka taea te maha o nga momo bignum mo nga whakaurunga rereke, engari kaore maatau e peera ki te karo i te kopae waehere.
//!
//! Ko ia bignum e whai ana mo nga whakamahinga tuuturu, no reira kaore he take.
//!

// Ko tenei waahanga mo te dec2flt me te flt2dec anake, me te iwi noa na te mea ko nga coretests.
// Kaore i te whakaarohia kia pumau.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Nga mahi Arithmetic e hiahiatia ana e nga bignums.
pub trait FullOps: Sized {
    /// Whakahoki `(carry', v')` penei i te `carry' * 2^W + v' = self + other + carry`, ko te `W` te maha o nga paraire i te `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Whakahoki `(carry', v')` penei i te `carry'*2^W + v' = self* other + carry`, ko te `W` te maha o nga paraire i te `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Whakahoki `(carry', v')` penei i te `carry'*2^W + v' = self* other + other2 + carry`, ko te `W` te maha o nga paraire i te `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Whakahoki `(quo, rem)` penei i te `borrow *2^W + self = quo* other + rem` me te `0 <= rem < other`, kei reira te `W` te maha o nga paraire i te `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Kaore tenei e kaha ake;ko te putanga kei waenga i te `0` me te `2 * 2^nbits - 1`.
                    // FIXME: ka whakaritehia e LLVM tenei ki te ADC rite ranei?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Kaore tenei e kaha ake;
                    // ko te putanga kei waenga i te `0` me te `2^nbits * (2^nbits - 1)`.
                    // FIXME: ka whakaritehia e LLVM tenei ki te ADC rite ranei?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Kaore tenei e kaha ake;
                    // ko te putanga kei waenga i te `0` me te `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Kaore tenei e kaha ake;ko te putanga kei waenga i te `0` me te `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Tirohia te RFC #521 mo te whakahohe i tenei.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Teepu mana o te 5 e tika ana mo te mati.Ina koa, ko te uara {u8, u16, u32} nui rawa atu e rima te mana, me te kaiwhakataetae e rite ana.
/// Whakamahia i te `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Toha-tohaina-tau-tika (tae atu ki etahi rohe) tau tōpū.
        ///
        /// Ka tautokona tenei e te kohinga rahi-rahi o te momo ("digit") kua hoatu.
        /// Ahakoa kaore i tino nui te kohinga (he rau rau paita te tikanga), ma te kore e aro ki te kape ka kore e puta te mahi.
        ///
        /// Ko tenei kaore tenei i te `Copy`.
        ///
        /// Katoa nga mahinga e waatea ana ki nga pungawerewere panic mena ka pakaru te wai.
        /// Kei te kaikaranga te kawenga ki te whakamahi i nga momo bignum nui.
        pub struct $name {
            /// Kotahi te taapiri ki te "digit" nui e whakamahia ana.
            /// Kaore tenei e heke, no reira kia maarama ki te raupapa tatauranga.
            /// `base[size..]` kia kore.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` he tohu i te `a + b *2^W + c* 2^(2W) + ...` ko te `W` te maha o nga paraire o te momo mati.
            base: [$ty; $n],
        }

        impl $name {
            /// Ka hangaia he bignum mai i te mati kotahi.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Ka hangaia he bignum mai i te uara `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Whakahoki ai i nga tau a roto hei poro `[a, b, c, ...]` te mea ko te uara nama ko te `a + b *2^W + c* 2^(2W) + ...` ko te `W` te maha o nga waahanga i te momo mati.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Whakahoki ai i te 'i`-th bit kei reira te moka 0 te mea iti rawa.
            /// I etahi atu kupu, ko te moka me te taumaha `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Whakahoki `true` mena he kore te bignum.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Whakahokia ai te maha o nga paraire hei tohu mo tenei uara.
            /// Kia mahara, ko te kore e hiahiatia ana kia 0 nga paraire.
            pub fn bit_length(&self) -> usize {
                // Peke atu ki nga mati tino nui kaore nei.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Kaore he nama kore-kore, ara, he nama kore.
                    return 0;
                }
                // Ka taea te whakapai ake ma te leading_zeros() me te neke paku, engari kaore pea pea i te pai te awangawanga.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Ka taapiri i te `other` ki a ia ano ka whakahoki i tana ake tohutoro ka taea te whakarereke.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Ka tohaina te `other` mai i a ia ano ka hoki mai i tana ake tohutoro ka taea te whakarereke.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Ka whakareatia ki a ia ano ma te `other` rahi-rahi ka whakahoki i tana ake tohutoro ka taea te huri.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Whakareatia ake e `2^bits` ka whakahoki i tana ake tohutoro ka taea te whakarereke.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // neke e `digits * digitbits` paraire
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // neke e `bits` paraire
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. mati] he koretake, kaore e hiahiatia te neke
                }

                self.size = sz;
                self
            }

            /// Whakareatia ake e `5^e` ka whakahoki i tana ake tohutoro ka taea te whakarereke.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // He zero tonu te aorangi i te 2 ^ n, ana ko te rahinga mati e whai kiko ana ko nga mana ruarua o te rua, no reira he taupū pai tenei mo te teepu.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Whakareatanga me te mana nui-mati-nui rawa atu te roa ka taea ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... ka mutu te toenga.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Ka whakareatia ki a ia ano i te nama kua whakaahuahia e `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (ko te `W` te maha o nga paraire o te momo mati) ka whakahoki ano i tana ake tohutoro ka taea te whakarereke.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // te mahi ā-.he pai ake te mahi ina aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Ka wehe ia ia ma te `other`-taarua-nui ka whakahoki i taana ake tohutoro *me* te toenga.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Wehehia koe ki tetahi atu bignum, ka tuhirua i te `q` me te kohinga me te `r` me nga toenga.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Poauau puhoi base-2 wehenga roa i tangohia mai
                // https://en.wikipedia.org/wiki/Division_algorithm
                // Whakamahia te FIXME i te turanga ($ty) nui ake mo te wehenga roa.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Whakatakotoria te bit `i` o te q ki te 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Ko te momo mati mo `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// whakamahia tenei tetahi mo te whakamatautau anake.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}