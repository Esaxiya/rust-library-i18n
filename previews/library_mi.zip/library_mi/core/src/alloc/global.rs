use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// He kaiwhakarato mahara ka taea te rehita hei taunoa o te wharepukapuka paerewa na roto i te huanga `#[global_allocator]`.
///
/// Etahi o nga tikanga e rapu e kia *tohaina tēnei wā he poraka mahara* mā te allocator.Ko te tikanga tenei:
///
/// * ko te wahitau timatanga mo taua poraka mahara i whakahokia mai e tetahi piiraa o mua ki tetahi tikanga tohatoha penei i te `alloc`, me te
///
/// * kaore ano kia nekehia te poraka mahara, i reira ka whakawhitihia nga poraka ma te tuku atu ki te tikanga whakawhitiwhitinga penei i te `dealloc`, ma te tuku atu ranei ki tetahi tikanga tuuturu e whakahoki ai i tetahi tohu kore-kore.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// Ko te `GlobalAlloc` trait he `unsafe` trait mo te maha o nga take, me nga kaitono me whakarite kia piri ki enei kirimana:
///
/// * He whanonga kore i tautuhia mena ka ngahore te hunga tohatoha o te ao.kia ara tenei here i roto i te future, engari i tēnei wā kia he panic i tetahi o enei mahi arahi ki unsafety mahara.
///
/// * `Layout` Me kia tika pātai me ngā tātaitanga i roto i te whānui.whakaaetia kaiwaea o tenei trait e ki te whakawhirinaki i runga i te kirimana tautuhia i runga i ia tikanga, a me whakarite implementors noho pono taua kirimana.
///
/// * Kaore pea koe e whakawhirinaki ki nga tohatoha ka puta, ahakoa he maarama puranga toha kei roto i te putake.
/// kia kitea te mōhinuhinu tohatoha kāore e rānei taea te whakakore i te reira katoa ranei neke ki te tāpae me te kupu e kore e whakahuatia te allocator.
/// Ka kii pea te kaitautoko ko te tohatoha kaore e hapa, na ko te waehere i ngoikore i mua na te ngoikoretanga o nga kaiwhakarato ka mahi ohorere inaianei na te mea i whakamahia e te kaitoha te hiahia mo te tohatoha.
/// Ko te mea nui ake hoki, ko te tauira waehere e whai ake nei he koretake, ahakoa mena ka tukuna e to kaiwhakarato ritenga te tatau e hia nga waahanga kua toha.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Kia mahara ko nga arotautanga kua whakahuatia i runga ake nei ehara koinei anake te arotautanga ka taea te whakamahi.Koe e kore te tikanga e whakawhirinaki i runga i tohatoha puranga tupu ki te taea te nekehia atu ratou, kahore te huri whanonga hōtaka.
///   Ahakoa ka tutuki nga tohatoha kaore ranei i te waahanga o te whanonga o te papatono, ahakoa ka kitea ma te kaitoha tohatoha i nga tohatoha ma te taarua, ma te kore e pa ki nga paanga kino.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Tohaina te whakamahara kia rite ki ta te `layout` i homai.
    ///
    /// Whakahokia te atatohu ki mahara hou-tohaina, i whakakahore ranei ki tohu kore tohatoha.
    ///
    /// # Safety
    ///
    /// Ko te haumaru tenei mahi no te mea e taea e whanonga kāore hua ki te kore te kaiwaea e whakarite e he rahi-kore kore `layout`.
    ///
    /// (Ma nga waahanga taapiri e whakarato ai nga rohe ake mo te whanonga, hei tauira, he tohu i te wahitau kaitiaki, he tohu kore ranei hei whakautu ki te tono tohatoha kore-rahi.)
    ///
    /// Ko te poraka mahara kua tohaina kaore pea i te arahi.
    ///
    /// # Errors
    ///
    /// Hoki mai i te atatohu i whakakahore tohu e he ruha rānei mahara ranei e kore e `layout` whakatau te rahi tīaroaro ranei herenga o tenei allocator.
    ///
    /// E akiakitia ana nga mahi ki te whakahoki kore i te mauiui o te mahara kaua ki te haukoti, engari ehara tenei i te mea tino kaha.
    /// (Tüturu: ko reira * * ture ki te whakatinana i tenei trait i ni'a i te whare pukapuka tohatoha Maori waiwai e aborts i runga i te rohirohi mahara.)
    ///
    /// Ko nga Kaihoko e hiahia ana ki te whakakore i te tatauranga hei whakautu ki te hapa tohatoha ka whakatenatena kia waea atu ki te mahi [`handle_alloc_error`], kaua ki te karanga tika ki te `panic!` me nga mea pera ranei.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Tohua te poraka o te mahara ki te tohu atawhai `ptr` me te `layout` i homai.
    ///
    /// # Safety
    ///
    /// Ko te haumaru tenei mahi no te mea e taea e whanonga kāore hua ki te kore te kaiwaea e whakarite katoa o te whai ake:
    ///
    ///
    /// * `ptr` me tohu he poraka mahara kua tohaina mai ma tenei kaitoha,
    ///
    /// * `layout` Me te taua tahora i whakamahia ki te tohatoha i taua poraka o te mahara.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// E mahi rite `alloc`, engari ano hoki fakapapau'i e whakaturia nga tirotiro e ki te kore i mua i te hoki mai.
    ///
    /// # Safety
    ///
    /// Ko tenei mahi kaore i te haumaru mo nga take ano he `alloc`.
    /// Heoi ko te poraka mahara kua tohaina kia whakauruhia.
    ///
    /// # Errors
    ///
    /// Ko te whakahoki i tetahi tohu kore tohu e tohu ana kua pau te mahara, kaore ranei te `layout` e tutuki i te rahinga o te kaitoha, i nga herenga whakatikatika ranei, pera i te `alloc`.
    ///
    /// Ko nga Kaihoko e hiahia ana ki te whakakore i te tatauranga hei whakautu ki te hapa tohatoha ka whakatenatena kia waea atu ki te mahi [`handle_alloc_error`], kaua ki te karanga tika ki te `panic!` me nga mea pera ranei.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SAFETY: ko te kirimana ahuru mo `alloc` me tautoko e te kaiwaea.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SAFETY: i te wahanga o te tohatoha, te rohe mai i te `ptr`
            // o te rahi `size` e pono ana mo nga tuhinga.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Tīngongo tupu te poraka o te mahara ki te `new_size` homai ranei.
    /// Ko te poraka e whakaahuahia ana e te tohu atawhai `ptr` me te `layout`.
    ///
    /// Mena ka whakahokia mai he tohu kore-kore, na, ko te rangatira o te poraka mahara kua tohua e `ptr` kua whakawhitihia ki tenei kaiwhakawhiwhi.
    /// Ko te whakamaharatanga kaore pea i whakawhitingahia, a me kii pea kaore e taea (ki te kore ka whakahokia ano ki te kaiwaea ma te uara whakahoki o tenei tikanga).
    /// tohaina te poraka mahara hou te ki `layout`, engari ki te `size` whakahoutia ki `new_size`.
    /// Me whakamahi tenei whakatakotoranga hou i te wa e whakawhiti ana i te poraka mahara hou me te `dealloc`.
    /// Ko te awhe `0..min(layout.size(), new_size) `o te poraka mahara hou ka u ki te uara rite ki te poraka taketake.
    ///
    /// Mena ka hoki whakamuri tenei tikanga, na, ko te mana pupuri o te poraka mahara kaore ano kia nekehia ki tenei kaitoha, a kaore nga tuhinga o te poraka mahara i whakarereke.
    ///
    /// # Safety
    ///
    /// Ko te haumaru tenei mahi no te mea e taea e whanonga kāore hua ki te kore te kaiwaea e whakarite katoa o te whai ake:
    ///
    /// * `ptr` me tohaina i tenei wa ma tenei kaitoha,
    ///
    /// * `layout` me rite te whakatakotoranga i whakamahia hei tohaina i taua poraka mahara,
    ///
    /// * `new_size` me nui ake i te kore.
    ///
    /// * `new_size`, ka huri ana ki te tini tata atu o te `layout.align()`, kaua e neke atu (penei, me iti iho i te `usize::MAX` te uara porotaka).
    ///
    /// (Ma nga waahanga taapiri e whakarato ai nga rohe ake mo te whanonga, hei tauira, he tohu i te wahitau kaitiaki, he tohu kore ranei hei whakautu ki te tono tohatoha kore-rahi.)
    ///
    /// # Errors
    ///
    /// Returns korenga ki te kore e whakatau i te tahora hou te rahi me te tīaroaro herenga o te allocator, ranei, ki te kore kore te Manatü.
    ///
    /// E akiakitia ana implementations ki te hoki whakakahore i runga i te rohirohi mahara, kaua ki te ngohe E waiho ana ranei, engari e kore te mea he titauraa tino tenei.
    /// (Tüturu: ko reira * * ture ki te whakatinana i tenei trait i ni'a i te whare pukapuka tohatoha Maori waiwai e aborts i runga i te rohirohi mahara.)
    ///
    /// E akiakitia ana kiritaki hiahia ki Haukoti tätaitanga i roto i te whakautu ki te hapa te Manatü ki te karanga i te mahi [`handle_alloc_error`], nui atu i tika Haute `panic!` rite ranei.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SAFETY: me whakarite e te kaiwaea kia kore te `new_size` e waipuke.
        // `layout.align()` mai i te `Layout` ana ka tika kia whai mana.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SAFETY: me whakarite e te kaiwaea ko te `new_layout` nui ake i te kore.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // HAUMARU: e kore e taea e te poraka whakaritea i mua īnaki te poraka hou tohaina.
            // Ko te kirimana ahuru mo te `dealloc` me tautoko e te kaiwaea.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}