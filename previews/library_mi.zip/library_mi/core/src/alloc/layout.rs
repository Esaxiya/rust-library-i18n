use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Ahakoa e whakamahia ana tenei mahi i te waahi kotahi ana ka taea te tohu, engari ko nga mahi o mua kia tere haere te rustc:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Tahora o te poraka mahara.
///
/// He tauira o `Layout` whakaahua ana te whakatakotoranga ngā o te mahara.
/// Ka hangaia e koe he `Layout` hei whakauru ki te tuku ki tetahi roopu toha.
///
/// Katoa nga whakatakotoranga he rahi te hono me te whakaoronga-a-e-rua.
///
/// (Kia mahara ko nga whakatakotoranga *kaore* e hiahiatia kia nui-kore te rahi, ahakoa ko te `GlobalAlloc` me kii nga tono mahara kia kore-nui te rahi.
/// rānei me te kaiwaea whakarite e eke ai ngā tikanga rite tenei, allocators whakamahi motuhake ki ngā whakaritenga looser, ranei te whakamahi i te atanga `Allocator` atu mārire.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // rahi o te poraka tono o mahara, whanganga i paita.
    size_: usize,

    // tīaroaro o te poraka tono o mahara, whanganga i paita.
    // whakarite tatou e te mea tonu tenei he mana-o-rua, no te mea e rapu a API rite `posix_memalign` reira ka ko reira he herenga whaitake ki te tangohia i runga i constructors Tahora.
    //
    //
    // (Heoi, tatou e kore analogously rapua e `tiaro>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Ka hangaia he `Layout` mai i te `size` me te `align`, ka whakahoki mai ranei i te `LayoutError` ki te kore e tutuki tetahi o nga tikanga e whai ake nei:
    ///
    /// * `align` kaua e kore
    ///
    /// * `align` Me waiho te mana o e rua,
    ///
    /// * `size`, ka huri ana ki te tini tata atu o te `align`, kaua e neke ke atu (arā, ko te uara porotaka me iti ake i te orite ki te `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (te mana-o-te-rua he tohu ki te haangai!=0.)

        // Te rahinga porotaka ko:
        //   size_rounds_up=(rahi + tiaro, 1)&! (whakahāngai, 1);
        //
        // E matau ana tatou i runga ake taua tiaro!=0.
        // Mena ka kore e taapirihia te taapiri (whakaaro, 1), ka pai te porohita.
        //
        // Hei rereke,&-whakaataata me! (Tiiti, 1) ka tangohia noa i nga waahanga iti-raupapa-iti.
        // Na, ki te puta he taaputanga me te moni, kaore e taea e te&-mask te tango kia iti ake te whakakore.
        //
        //
        // I runga ake nei ko te tirotiro mo te waipuke whakarpopototanga he tika me te rawaka.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SAFETY: ko nga tikanga mo `from_size_align_unchecked` kua
        // kua tirohia i runga ake nei.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// He waihanga he tahora, bypassing arowhai katoa.
    ///
    /// # Safety
    ///
    /// Kaore i te haumaru tenei mahi na te mea kaore i te whakaatuhia nga waahanga o mua mai i te [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SAFETY: me whakarite e te kaiwaea ko te `align` nui ake i te kore.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Te rahi iti i roto i te paita mo te poraka mahara o tenei tahora.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Te whakaoritanga paita iti mo te poraka mahara o tenei whakatakotoranga.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Ka hangaia e te `Layout` e tika ana mō te pupuri i te uara o te momo `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // HAUMARU: whai te tiaro e Rust ki te waiho i te mana o e rua, me te
        // te rahinga + whakarite paheko tuturu kia uru ki o maatau waahi korero.
        // Hei konae whakamahi i te kaihanga kore e tirotirohia i konei kia kore ai e whakauru i te waehere e panics mena kaore e pai te whakatika.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Hua tahora whakaahua i te lekooti e taea te whakamahi ki te tohatoha hanganga poupou mo `T` (e taea e te trait atu momo unsized rite te wāhanga ranei).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SAFETY: tirohia te whaitake i te `new` mo te aha e whakamahi ai tenei i te momo haumaru
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Hua tahora whakaahua i te lekooti e taea te whakamahi ki te tohatoha hanganga poupou mo `T` (e taea e te trait atu momo unsized rite te wāhanga ranei).
    ///
    /// # Safety
    ///
    /// He pai noa iho tenei mahi ki te waea mena ka mau nga tikanga e whai ake nei:
    ///
    /// - Mena ko `T` te `Sized`, he pai tonu tenei mahi ki te karanga.
    /// - Mena ko te hiku hika o `T` ko:
    ///     - he [slice], na me waiho te roa o te hiku wāhanga he tōpū arawhiti, me te rahi o te (roa hihiri hiku + kuhimua statically rahi)*uara* katoa me uru i roto i `isize`.
    ///     - he [trait object], na me tohu i te wahi vtable o te atatohu ki te vtable whaimana mo te momo riro `T` e te coersion unsizing, me te rahi o te *uara* katoa (hihiri hiku roa + kuhimua statically rahi) Me uru i roto i `isize`.
    ///
    ///     - he (unstable) [extern type], na te mea he pai tenei waea ki te waea atu, engari kia panic kia kore ranei e whakahokia mai te uara he, i te mea kaore e mohiotia te whakatakotoranga o te momo o waho.
    ///     He rite tonu te whanonga ki te [`Layout::for_value`] e pa ana ki te hiku momo o waho.
    ///     - ki te kore, kaore e whakaaehia kia karangahia tenei mahi.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SAFETY: haere tatou me te hiahiatanga o enei mahi ki te kaiwaea
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SAFETY: tirohia te whaitake i te `new` mo te aha e whakamahi ai tenei i te momo haumaru
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Ka waihanga te `NonNull` te nao e, engari te pai-tiaro hoki tenei Tahora.
    ///
    /// Kia mahara ko te uara tohu ka tohu pea i tetahi tohu tohu tika, ko te tikanga kaua e whakamahia hei uara sentinel "not yet initialized".
    /// Ko nga momo e toha mangere ana me whai i te arawhiti ki etahi atu huarahi.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SAFETY: ka whakamanahia kia kore-kore
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Ka waihangahia he whakatakotoranga e whakaatu ana i te rekoata ka taea te pupuri i te uara o te whakatakotoranga rite tonu ki te `self`, engari e hangai ana ki te huringa `align` (ka inea ki nga paita).
    ///
    ///
    /// Mena kua tutuki kea a `self` i te whakahoutanga kua whakaritea, ka hoki mai ano te `self`.
    ///
    /// Kia mōhio e kore e tenei tikanga tāpiri tetahi purpuru ki te rahi whānui, ahakoa o ahakoa te tahora hoki kua he tīaroaro rerekē.
    /// I etahi atu kupu, mena he nui te 16 o te `K`, ko te `K.align_to(32)`*tonu* he rahi te 16.
    ///
    /// Ka whakahokia mai he hapa mena ka whakakotahihia te whakakotahitanga o `self.size()` me te `align` kua hoatuhia ki te [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Whakahokihia te nui o nga papa taapiri me whakauruhia e tatou i muri i te `self` kia mohio ai ka makona te `align` i te wahitau e whai ake nei (ka inea ki nga paita).
    ///
    /// hei tauira, mena ko `self.size()` te 9, katahi ka whakahokia mai e `self.padding_needed_for(4)` te 3, na te mea ko te nama iti rawa o te paita o te taapiri e hiahiatia ana kia 4-haangai te haangai (me te whakaaro ko te poraka mahara e haangai ana ka timata i te wahitau haangai e 4).
    ///
    ///
    /// Ko te uara hoki o tenei mahi e kore tikanga, ki te kahore te mea `align` te mana-o-rua.
    ///
    /// Kia mahara ko te whakamahinga o te uara i whakahokia mai me kii te `align` kia iti ake i te rite ranei ki te whakaoronga o te wahitau timatanga mo te poraka mahara katoa kua tohaina.Ko tētahi ara ki te makona tenei herenga ko ki te whakarite `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Ko te uara whakaawhiwhi ko:
        //   len_rounds_up=(len + align, 1)&! (whakahāngai, 1);
        // katahi ka whakahokia te rereketanga o te papa: `len_rounded_up - len`.
        //
        // Ka whakamahia e maatau te taatai noa:
        //
        // 1. whai tiaro te ki kia> 0, na tiaro, he tika tonu 1.
        //
        // 2.
        // `len + align - 1` Ka taea e te waipuke te e i te nuinga `align - 1`, na te&-mask ki `!(align - 1)` ka whakarite e i roto i te take o te waipuke, `len_rounded_up` ka waiho iho 0.
        //
        //    Ko te whakahoki mai o te papa, ka tapirihia ki te `len`, ka puta he 0, e makona ana i te hononga `align`.
        //
        // (Ae ra, ko te tarai ki te tohatoha poraka maumahara na te rahinga me te taapiri i te ahua i runga ake nei ka raru pea te kaihoko.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Ka waihangahia he taatai ma te huri i te rahi o tenei whakatakotoranga tae atu ki te maha o nga waahanga o te tahora.
    ///
    ///
    /// He ōrite ki te tāpiri i te hua o `padding_needed_for` ki te rahi o te tahora o nāianei tenei.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Kaore tenei e kaha ake.Te whakahua mai i te kaitautoko Tahora:
        // > `size`, ka whakaekea ana ki te tini tata o `align`,
        // > Me kore te waipuke (arā, me waiho te uara porotaka iti iho i te
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Ka waihangahia he whakatakotoranga e whakaahua ana i nga rekoata mo nga waahanga `n` o te `self`, me te rahi o te taapiri i waenga i a raatau kia mohio ai ka whakawhiwhia ki ia waahanga te rahi me te whakahoutanga.
    /// I te angitu, hoki `(k, offs)` i reira `k` ko te tahora o te ngohi, me te `offs` ko te tawhiti i waenganui i te tīmatanga o ia huānga i roto i te ngohi.
    ///
    /// I te rerenga o te tauhanga, ka whakahoki `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Kaore tenei e kaha ake.Te whakahua mai i te kaitautoko Tahora:
        // > `size`, ka whakaekea ana ki te tini tata o `align`,
        // > Me kore te waipuke (arā, me waiho te uara porotaka iti iho i te
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // Kei te mohiotia kua self.align ki kia tika, me alloc_size kua: SAFETY
        // kua kapi kē.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Ka waihangahia he whakatakotoranga e whakaatu ana i te rekoata mo te `self` ka whai ake ko te `next`, tae atu ki nga taapiri e tika ana hei whakarite kia tika te whakatika o te `next`, engari *kaore he papa hikoi*.
    ///
    /// I roto i te tikanga ki te ōrite C kanohi tahora `repr(C)`, kia karanga koutou `pad_to_align` i muri i te whakawhānui i te tahora ki mara katoa.
    /// (Kaore he huarahi hei taurite ki te taunoa whakaaturanga Rust whakaaturanga `repr(Rust)`, as it is unspecified.)
    ///
    /// Kia mahara ko te huringa o te whakatakotoranga ka puta ko te rahinga o era o `self` me `next`, kia pai ai te whakaurunga o nga waahanga e rua.
    ///
    /// Whakahoki mai ai i te `Ok((k, offset))`, kei reira a `k` e whakatakotoria ana mo te rekoata whakakao me te `offset` te waahi whanaunga, i nga paita, mo te tiimata o te `next` kua whakauruhia ki roto i nga rekoata whakauru (me te kii ko nga rekoata ano ka tiimata mai i te whakaweto 0).
    ///
    ///
    /// I te rerenga o te tauhanga, ka whakahoki `LayoutError`.
    ///
    /// # Examples
    ///
    /// Ki te tātai i te tahora o te hanganga `#[repr(C)]` me nga pokohiwi o te mara i ngā whakatakotoranga ona mara ':
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Kia mahara ki te whakaoti me te `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // whakamatauhia kei te mahi
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Ka waihanga te tahora whakaahua i te lekooti mo `n` wā o `self`, ki kore purpuru i waenganui i ia tauira.
    ///
    /// Note e, pērā `repeat`, `repeat_packed` e kore kī e te wā toutou o `self` ka kia tika hāngai, ara, ki te te tika hāngai te tauira i homai o `self`.
    /// I etahi atu kupu, mena ko te whakatakotoranga i whakahokia mai e `repeat_packed` e whakamahia ana hei tohatoha i te kohinga, kaore e tuturu ko nga waahanga katoa o te raarangi ka tika te whakatika.
    ///
    /// I te rerenga o te tauhanga, ka whakahoki `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Ka waihanga te tahora whakaahua i te lekooti mo `self` aru e `next` ki kore purpuru atu i waenganui i te rua.
    /// Mai whakaurua kahore purpuru te, he kotiti te tīaroaro o `next`, a kore e whakaurua *i* katoa ki te tahora hua.
    ///
    ///
    /// I te rerenga o te tauhanga, ka whakahoki `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Ka hangaia he whakatakotoranga hei whakaahua i te rekoata mo te `[T; n]`.
    ///
    /// I te rerenga o te tauhanga, ka whakahoki `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Ko te tawhā hoatu ki `Layout::from_size_align` etahi atu hanganga `Layout` kore e makona i ona herenga tuhia ranei.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (e hiahiatia ana e maatau tenei mo nga waahanga o raro o te Hapa trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}