//! API tohatoha mahara

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Ko te hapa `AllocError` tohu he kore tohatoha e kia tika ki te rohirohi rauemi ranei ki te tahi mea he, ka whakakotahi i te tohenga tāuru i homai ki tenei allocator.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (e hiahiatia ana e maatau tenei mo nga waahanga o raro o te Hapa trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// He whakatinanatanga o `Allocator` taea tohatoha, e tupu, holomui, ka deallocate poraka noho o raraunga whakaahuatia mā [`Layout`][].
///
/// `Allocator` kua hoahoatia kia mahia ki runga i nga ZST, tohutoro, tohu tohu mohio ranei na te mea he toha toha penei i te `MyAlloc([u8; N])` kaore e taea te neke, me te kore e whakahou i nga tohu ki te mahara kua tohaina.
///
/// Kaore e rite ki te [`GlobalAlloc`][], ko nga tohatoha kore-rahi ka whakaaetia i te `Allocator`.
/// Mena kaore te kaitautoko taketake e tautoko i tenei (penei i te jemalloc) ka whakahoki mai ranei i tetahi tohu kore (penei i te `libc::malloc`), me mau tenei ma te whakamahi.
///
/// ### mahara tēnei wā tohaina
///
/// Etahi o nga tikanga e rapu e kia *tohaina tēnei wā he poraka mahara* mā te allocator.Ko te tikanga tenei:
///
/// * ko te wahitau timatanga mo taua poraka mahara i whakahokia mai i mua e [`allocate`], [`grow`], [`shrink`] ranei, a
///
/// * Kua kore i muri deallocated te poraka mahara, te wahi e rānei deallocated tika poraka e te haere ki [`deallocate`] i puta ke e te haere ki [`grow`] [`shrink`] ranei e hoki `Ok` ranei.
///
/// Mena kua whakahokia mai e `grow`, `shrink` ranei te `Err`, ka pumau tonu te tohu i tukuna.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Whakauru mahara
///
/// Ko etahi o nga tikanga e hiahia ana kia whakatakotoria he takotoranga * ki tetahi poraka mahara.
/// He aha te tikanga o te reira mo te tahora he tikanga poraka mahara ki "fit" (ranei equivalently, mo te poraka mahara ki "fit" te tahora) Ko e me mau i te tikanga e whai ake nei:
///
/// * Me tohaina te poraka me te whakahoutanga kia rite ki te [`layout.align()`], me te
///
/// * Ko te [`layout.size()`] e toha ana me taka ki roto i te awhe `min ..= max`, kei reira:
///   - `min` ko te rahi o te whakatakotoranga i whakamahia noa nei hei tohatoha i te poraka, a
///   - `max` Ko te rahi ake o te rahi i whakahokia mai i te [`allocate`], [`grow`], te [`shrink`] ranei.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Ko nga poraka maumahara i hoki mai i te kaiwhakarato me tohu ki te maumahara pono me te pupuri i te whaitake tae atu ki te wa e hinga ana nga tauira katoa,
///
/// * te pūrua ranei neke i te allocator me kore poraka mahara whakakahore hoki i tenei allocator.Me rite te mahi a te kaihoko toha ki te kaitoha rite, me te
///
/// * tetahi tohu ki tetahi poraka mahara ko [*currently allocated*] tera pea ka tukuna ki tetahi atu tikanga a te kaitoha.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Ngana ki te tohatoha i tetahi poraka mahara.
    ///
    /// I te angitu, ka whakahoki mai i te hui [`NonNull<[u8]>`][NonNull] te rahinga me te taunga whakaahuru o `layout`.
    ///
    /// kia whai i te poraka hoki te rahi nui atu i tohua e `layout.size()`, a kia kore ai ranei i ona tirotiro arawhitia.
    ///
    /// # Errors
    ///
    /// Ko te whakahoki i te `Err` e tohu ana kua pau te mahara, kaore ranei te `layout` e tutuki i te rahinga o te kaiwhakarato, i nga herenga whakatikatika ranei.
    ///
    /// E akiakitia ana implementations ki hoki `Err` i rohirohi mahara, kaua ki te ngohe E waiho ana ranei, engari e kore te mea he titauraa tino tenei.
    /// (Tüturu: ko reira * * ture ki te whakatinana i tenei trait i ni'a i te whare pukapuka tohatoha Maori waiwai e aborts i runga i te rohirohi mahara.)
    ///
    /// Ko nga Kaihoko e hiahia ana ki te whakakore i te tatauranga hei whakautu ki te hapa tohatoha ka whakatenatena kia waea atu ki te mahi [`handle_alloc_error`], kaua ki te karanga tika ki te `panic!` me nga mea pera ranei.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// E mahi rite `allocate`, engari ano hoki fakapapau'i e te mahara hoki ko te kore-arawhitia.
    ///
    /// # Errors
    ///
    /// Ko te whakahoki i te `Err` e tohu ana kua pau te mahara, kaore ranei te `layout` e tutuki i te rahinga o te kaiwhakarato, i nga herenga whakatikatika ranei.
    ///
    /// E akiakitia ana implementations ki hoki `Err` i rohirohi mahara, kaua ki te ngohe E waiho ana ranei, engari e kore te mea he titauraa tino tenei.
    /// (Tüturu: ko reira * * ture ki te whakatinana i tenei trait i ni'a i te whare pukapuka tohatoha Maori waiwai e aborts i runga i te rohirohi mahara.)
    ///
    /// Ko nga Kaihoko e hiahia ana ki te whakakore i te tatauranga hei whakautu ki te hapa tohatoha ka whakatenatena kia waea atu ki te mahi [`handle_alloc_error`], kaua ki te karanga tika ki te `panic!` me nga mea pera ranei.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SAFETY: Ka whakahokia mai e `alloc` tetahi poraka mahara tika
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Ka tohaina te whakamaharatanga e `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` me tohu he poraka mo te mahara [*currently allocated*] ma tenei kaitoha, a
    /// * `layout` me [*fit*] tera poraka mahara.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Ngana ki te whakaroa i te poraka mahara.
    ///
    /// Whakahokia ai he [`NonNull<[u8]>`][NonNull] hou kei roto he tohu me te rahi o te maumahara kua tohaina.He tika te tohu ki te pupuri i nga raraunga kua whakaahuahia e `new_layout`.
    /// Hei whakatutuki i tenei, ka ahei te kaiwhakawhiwhi ki te toro atu i te tohatoha e `ptr` kia uru ai ki te whakatakotoranga hou.
    ///
    /// Ki te hoki tenei `Ok`, ka mana o te poraka mahara tohutoro e `ptr` kua whakawhitia ki tenei allocator.
    /// kia te maharatanga ranei kia kore i wetekina i, a kia kia whakaaro taea te kore i whakawhiti ai hoki ki te kaiwaea ano mā te uara hoki o tenei tikanga.
    ///
    /// Mena ka whakahoki mai tenei tikanga i te `Err`, na ko te rangatira o te poraka mahara kaore ano kia whakawhitihia ki tenei kaitoha, a kaore nga tuhinga o te poraka mahara i whakarereke.
    ///
    /// # Safety
    ///
    /// * `ptr` me tohu he poraka mo te mahara [*currently allocated*] ma tenei kaitoha.
    /// * `old_layout` Me [*fit*] e poraka o te mahara (Te `new_layout` tohenga hiahia e kore e pai i te reira.).
    /// * `new_layout.size()` Me kia nui atu rite ranei ki `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Whakahoki `Err` ki te kore e tutuki i te whakatakotoranga hou te rahinga o te kaitoha me nga herenga haangai o te kaitoha, mena kaare e tipu te tipu.
    ///
    /// E akiakitia ana implementations ki hoki `Err` i rohirohi mahara, kaua ki te ngohe E waiho ana ranei, engari e kore te mea he titauraa tino tenei.
    /// (Tüturu: ko reira * * ture ki te whakatinana i tenei trait i ni'a i te whare pukapuka tohatoha Maori waiwai e aborts i runga i te rohirohi mahara.)
    ///
    /// Ko nga Kaihoko e hiahia ana ki te whakakore i te tatauranga hei whakautu ki te hapa tohatoha ka whakatenatena kia waea atu ki te mahi [`handle_alloc_error`], kaua ki te karanga tika ki te `panic!` me nga mea pera ranei.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: na te mea me nui ake te `new_layout.size()` i te orite ranei ki
        // `old_layout.size()`, e rua e tika te tohatoha mahara tawhito, me te hou mo pānui me tuhi hoki ngā paita `old_layout.size()`.
        // Ano hoki, na te mea kaore ano kia tohatohahia te toha tawhito, kaore e taea te taupoki i te `new_ptr`.
        // Na, ko te piiraa ki `copy_nonoverlapping` he ahuru.
        // Ko te kirimana ahuru mo te `dealloc` me tautoko e te kaiwaea.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// He peepi te ahua o te `grow`, engari me whakarite ano kia kore noa nga korero hou i mua i te whakahoki mai.
    ///
    /// Kei roto i te poraka mahara nga korero e whai ake nei i muri i te waea angitu ki a koe
    /// `grow_zeroed`:
    ///   * Paita `0..old_layout.size()` e tiakina ana mai i te tohatoha taketake.
    ///   * Bytes `old_layout.size()..old_size` ka tiakina, ka kore ranei, ka whakawhirinaki ki te whakatinanatanga o te kaiwhakawhiwhi.
    ///   `old_size` e pa ana ki te rahinga o te poraka mahara i mua i te waeatanga `grow_zeroed`, tera pea he rahi ake i te rahinga i tonohia i te wa i tohaina ai.
    ///   * Paita `old_size..new_size` kua kore.Ko te `new_size` e pa ana ki te rahinga o te poraka mahara i whakahokia mai e te waea `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` me tohu he poraka mo te mahara [*currently allocated*] ma tenei kaitoha.
    /// * `old_layout` Me [*fit*] e poraka o te mahara (Te `new_layout` tohenga hiahia e kore e pai i te reira.).
    /// * `new_layout.size()` Me kia nui atu rite ranei ki `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Whakahoki `Err` ki te kore e tutuki i te whakatakotoranga hou te rahinga o te kaitoha me nga herenga haangai o te kaitoha, mena kaare e tipu te tipu.
    ///
    /// E akiakitia ana implementations ki hoki `Err` i rohirohi mahara, kaua ki te ngohe E waiho ana ranei, engari e kore te mea he titauraa tino tenei.
    /// (Tüturu: ko reira * * ture ki te whakatinana i tenei trait i ni'a i te whare pukapuka tohatoha Maori waiwai e aborts i runga i te rohirohi mahara.)
    ///
    /// Ko nga Kaihoko e hiahia ana ki te whakakore i te tatauranga hei whakautu ki te hapa tohatoha ka whakatenatena kia waea atu ki te mahi [`handle_alloc_error`], kaua ki te karanga tika ki te `panic!` me nga mea pera ranei.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SAFETY: na te mea me nui ake te `new_layout.size()` i te orite ranei ki
        // `old_layout.size()`, e rua e tika te tohatoha mahara tawhito, me te hou mo pānui me tuhi hoki ngā paita `old_layout.size()`.
        // Ano hoki, na te mea kaore ano kia tohatohahia te toha tawhito, kaore e taea te taupoki i te `new_ptr`.
        // Na, ko te piiraa ki `copy_nonoverlapping` he ahuru.
        // Ko te kirimana ahuru mo te `dealloc` me tautoko e te kaiwaea.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ngana ki te whakaheke i te poraka mahara.
    ///
    /// Whakahokia ai he [`NonNull<[u8]>`][NonNull] hou kei roto he tohu me te rahi o te maumahara kua tohaina.He tika te tohu ki te pupuri i nga raraunga kua whakaahuahia e `new_layout`.
    /// No te faatupu i tenei, kia holomui te allocator te tohanga tohutoro e `ptr` ki uru te tahora hou.
    ///
    /// Ki te hoki tenei `Ok`, ka mana o te poraka mahara tohutoro e `ptr` kua whakawhitia ki tenei allocator.
    /// kia te maharatanga ranei kia kore i wetekina i, a kia kia whakaaro taea te kore i whakawhiti ai hoki ki te kaiwaea ano mā te uara hoki o tenei tikanga.
    ///
    /// Mena ka whakahoki mai tenei tikanga i te `Err`, na ko te rangatira o te poraka mahara kaore ano kia whakawhitihia ki tenei kaitoha, a kaore nga tuhinga o te poraka mahara i whakarereke.
    ///
    /// # Safety
    ///
    /// * `ptr` me tohu he poraka mo te mahara [*currently allocated*] ma tenei kaitoha.
    /// * `old_layout` Me [*fit*] e poraka o te mahara (Te `new_layout` tohenga hiahia e kore e pai i te reira.).
    /// * `new_layout.size()` me iti ake, kia rite ranei ki te `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Whakahoki `Err` ki te kore e tutuki i te whakatakotoranga hou te rahinga o te kaitoha me nga herenga haangai o te kaitoha, mena ka heke ranei te kore.
    ///
    /// E akiakitia ana implementations ki hoki `Err` i rohirohi mahara, kaua ki te ngohe E waiho ana ranei, engari e kore te mea he titauraa tino tenei.
    /// (Tüturu: ko reira * * ture ki te whakatinana i tenei trait i ni'a i te whare pukapuka tohatoha Maori waiwai e aborts i runga i te rohirohi mahara.)
    ///
    /// Ko nga Kaihoko e hiahia ana ki te whakakore i te tatauranga hei whakautu ki te hapa tohatoha ka whakatenatena kia waea atu ki te mahi [`handle_alloc_error`], kaua ki te karanga tika ki te `panic!` me nga mea pera ranei.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: na te mea ko te `new_layout.size()` me iti ake i te orite ranei
        // `old_layout.size()`, e rua e tika te tohatoha mahara tawhito, me te hou mo pānui me tuhi hoki ngā paita `new_layout.size()`.
        // Ano hoki, na te mea kaore ano kia tohatohahia te toha tawhito, kaore e taea te taupoki i te `new_ptr`.
        // Na, ko te piiraa ki `copy_nonoverlapping` he ahuru.
        // Ko te kirimana ahuru mo te `dealloc` me tautoko e te kaiwaea.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ka waihanga te whāurutau "by reference" mo tenei tauira o `Allocator`.
    ///
    /// whakatinana hoki te pūurutau hoki `Allocator` a ka tarewa tenei noa.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SAFETY: ko te kirimana ahuru me whakatuturu e te kaiwaea
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: ko te kirimana ahuru me whakatuturu e te kaiwaea
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: ko te kirimana ahuru me whakatuturu e te kaiwaea
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: ko te kirimana ahuru me whakatuturu e te kaiwaea
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}