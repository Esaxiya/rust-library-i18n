//! I tahito ra traits me ngā momo māngai āhuatanga taketake o momo.
//!
//! Ka taea te whakarōpūtia momo Rust i ngā huarahi whai hua rite ki o ratou āhuatanga tūturu.
//! E māngai ēnei whakarōpūtanga rite traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Momo e taea te whakawhiti puta noa rohe miro.
///
/// Kei te whakatinana aunoa tenei trait ka whakatau te taupatupatu te reira e tika ana.
///
/// Ko tetahi tauira o te momo-kore "Tukua` ko te tohu tohu-tohu [`rc::Rc`][`Rc`].
/// Mena e rua nga aho e ngana ana ki te tarai i te [`Rc`] e tohu ana ki te uara toharite-kaute taua, ka tarai pea ki te whakahou i te tatauranga tohutoro i te wa ano, ko te [undefined behavior][ub] na te mea kaore a [`Rc`] e whakamahi i nga ngota ngota.
///
/// Ko tōna whanaunga [`sync::Arc`][arc] e whakamahi ngā mahi ngota (incurring etahi rererangi) me te kupu, ko te `Send`.
///
/// Tirohia te [the Nomicon](../../nomicon/send-and-sync.html) hoki ētahi atu kōrero.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Types ki te rahi tamau mohiotia i te wā whakahiato.
///
/// tawhā momo katoa i te matū herea o `Sized`.Ka taea te whakamahi i te raukaha `?Sized` motuhake ki te tango i tenei here ki te kore e tika.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//hapa: Kaore te rahi e whakatinanahia mo [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Ko te kotahi okotahi ko te momo `Self` matū o te trait.
/// E kore te trait i herea te matū `Sized` rite he hotokore ki tenei [trait ahanoa] s wahi, i te whakamāramatanga, me te trait ki te mahi ki te implementors taea katoa, a ko te kupu i taea e tetahi te rahi.
///
///
/// Ahakoa ka tukua Rust herea koe `Sized` ki te trait, e kore e taea ki te whakamahi i te reira ki te hanga i te ahanoa trait i muri ia koutou:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // kia y: Bar &dyn = &Impl;//hapa: e taea kore te hanga e te trait `Bar` ki te ahanoa
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // mo te Taunoa, mo te tauira, e titau e kia `[T]: !Default` evaluatable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Momo e taea e "unsized" ki te momo hihiri-rahi.
///
/// Hei tauira, ko te momo rahinga momo `[i8; 2]` ka whakamahi i te `Unsize<[i8]>` me te `Unsize<dyn fmt::Debug>`.
///
/// E whakaratohia implementations katoa o `Unsize` aunoa i te taupatupatu.
///
/// `Unsize` whakatinana ai mo:
///
/// - `[T; N]` ko `Unsize<[T]>`
/// - `T` Ko `Unsize<dyn Trait>` ka `T: Trait`
/// - `Foo<..., T, ...>` Ko `Unsize<Foo<..., U, ...>>` ki te:
///   - `T: Unsize<U>`
///   - Ko te Foo he hangahanga
///   - Anake te mara whakamutunga o `Foo` he momo e whai wāhi mai `T`
///   - `T` ehara i te waahanga o etahi atu mara
///   - `Bar<T>: Unsize<Bar<U>>`, ki te te mara whakamutunga o `Foo` he momo `Bar<T>`
///
/// `Unsize` Kei te whakamahia me [`ops::CoerceUnsized`] ki tukua "user-defined" ipu pērā i [`Rc`] ki roto i ngā momo hihiri-rahi.
/// Tirohia te te [DST coercion RFC][RFC982] me [the nomicon entry on coercion][nomicon-coerce] mo ētahi atu kōrero.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Hiahiatia ana trait mō taimau whakamahia i roto i ngā kēmu tauira.
///
/// Ko nga momo ka puta mai i te `PartialEq` ka whakatinana i tenei trait,*ahakoa* mena ko ona momo-taatari e whakamahi ana i te `Eq`.
///
/// Ki te kei te tūemi `const` etahi momo e kore e e whakatinana tenei trait, ka e momo rānei (1.) e kore whakatinana `PartialEq` (e te tikanga te tamau e kore e whakarato i taua tikanga whakarite, e waehere whakatupuranga riro he wātea), ranei (2.) reira ngā *ona ake* putanga o `PartialEq` (e amo tatou e kore e hāngai ki te whakarite hanganga-taurite).
///
///
/// I roto i rānei o te wheako e rua i runga ake, paopao tatou whakamahi o te taimau taua i roto i te kēmu tauira.
///
/// A hi'o hoki te [structural match RFC][RFC1445], a [issue 63438] e Heke.ods hihiri i hoahoa e hāngai ana huanga-ki tenei trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Hiahiatia ana trait mō taimau whakamahia i roto i ngā kēmu tauira.
///
/// Tetahi momo e whakatinana aunoa ahu `Eq` tenei trait,*ahakoa* o ahakoa whakatinana ona tawhā momo `Eq`.
///
/// Ko te hack tenei ki te mahi i te taha o te herenga o a taatau punaha momo.
///
/// # Background
///
/// e hiahia ana matou ki te rapu utu e momo o consts whakamahia i roto i ngā kēmu tauira i te huanga `#[derive(PartialEq, Eq)]`.
///
/// I roto i te ao pai ake, i taea e tirohia tatou e titauraa na roto i te te arowhai tika e nga mea mahi momo homai e rua te `StructuralPartialEq` trait *me* te `Eq` trait.
/// Heoi, ka taea e koe ADTs e *mahi*`derive(PartialEq, Eq)`, a ka waiho i te take e hiahia ana tatou i te taupatupatu ki te farii i, a heoi kore momo o te tamau ki te whakatinana i `Eq`.
///
/// Ara, he take rite tenei:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Ko te raruraru i roto i te waehere i runga ko e kore e `Wrap<fn(&())>` whakatinana `PartialEq`, e kore `Eq`, no te mea, no te < 'he> fn(&'a _)` does not implement those traits.)
///
/// Na reira, e kore e taea e matou te whakawhirinaki i runga Taki kuware mo `StructuralPartialEq` me mere `Eq`.
///
/// Hei mahinga ki te mahi i tenei, ka whakamahia e maatau nga traits motuhake e werohia ana e ia o nga mea e rua (`#[derive(PartialEq)]` me `#[derive(Eq)]`) me te tirotiro kei te kitea era e rua hei waahanga tirotiro-takawaenga.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Types nei ngā uara taea te tārite noa na roto i te tārua paraire.
///
/// Na roto i te taunoa, Here tāupe i 'semantics nekehanga.'I etahi atu kupu:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` Kua oho ki `y`, a kore e taea te whakamahi na
///
/// // println ("{: ?}", x)!;//hapa: te whakamahi o te uara kua nukuhia
/// ```
///
/// Heoi, ki te whakamahia e te momo `Copy`, he 'kape tauira' tana:
///
/// ```
/// // Ka taea e tatou ahu i te whakatinanatanga `Copy`.
/// // `Clone` e hiahiatia ana hoki, na te mea he supertrait o `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` he kape o `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// He mea nui ki te mōhio e i roto i teie mau hi'oraa e rua, anake te rerekētanga ko ranei e whakaaetia koe ki te uru `x` i muri i te ohipa.
/// I raro i te araa, e rua he kape, me te nekehanga e taea hua i roto i nga paraire te tārua i roto i te mahara, ahakoa kei te te tahi mau taime tenei papaitia atu.
///
/// ## Me pehea e taea te whakatinana i ahau `Copy`?
///
/// E rua ngā huarahi ki te whakatinana i `Copy` runga i tō momo.Ko te mea maamaa ko te whakamahi i te `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Ka taea hoki e koe te whakamahi i te `Copy` me te `Clone` a-ringa:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// He he he rerekētanga iti i waenganui i te rua: herea te rautaki `derive` ka tuu ano he `Copy` i momo tawhā, e kore e nei hiahiatia tonu.
///
/// ## He aha te rereketanga i waenga i `Copy` me `Clone`?
///
/// Kape tupu kakato, mo te tauira hei wāhanga o te ohipa `y = x`.E kore te mea overloadable te whanonga o `Copy`;he kape maamaa noa iho.
///
/// Cloning ko te mahi mārama, `x.clone()`.Ko te whakatinanatanga o [`Clone`] taea whakarato i tetahi whanonga momo-motuhake e tika ana ki te tārua uara humarie.
/// Hei tauira, me te whakatinanatanga o [`Clone`] mo [`String`] ki tārua te-ki oka te moka aho i roto i te puranga.
/// He kape bitwise ohie o uara [`String`] e tārua noa te atatohu, ārahi ki te rua noa iho te rārangi.
/// Hoki tenei take, [`String`] ko [`Clone`] engari e kore e `Copy`.
///
/// [`Clone`] he supertrait o `Copy`, na ko nga mea katoa `Copy` me whakauru [`Clone`].
/// Ki te he momo ko `Copy` ka anake me tona whakatinanatanga [`Clone`] ki hoki `*self` (kite i te tauira i runga ake).
///
/// ## Ahea ka taea ai taku momo `Copy`?
///
/// Ka taea e tetahi momo te whakamahi i te `Copy` mena ka whakatinana te `Copy` i ona waahanga katoa.Hei tauira, ko tenei hanganga ka taea te `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Ka taea e te struct e `Copy`, a [`i32`] ko `Copy`, na reira he āhei ki te hei `Copy` `Point`.
/// Ma te rereke, whakaarohia
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// E kore e taea e te struct `PointList` whakatinana `Copy`, no te mea kahore he [`Vec<T>`] `Copy`.Ki te tamata tatou ki te ahu i te whakatinanatanga `Copy`, ka whiwhi tatou i te hapa:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// He tohutoro ngā (`&T`) hoki `Copy`, kia taea he momo e `Copy`, ara ka mau ngā reira tohutoro o ngā momo `T` e te hunga *kore*`Copy`.
/// A feruri i te struct e whai ake nei, e taea te whakatinana `Copy`, no te mea te reira mau anake he *tohutoro ngā* ki to tatou momo kore-`Copy` `PointList` i runga ake:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## A, no te *kore e taea e* toku momo e `Copy`?
///
/// e kore e taea te tārua humarie ētahi momo.Hei tauira, te tārua `&mut T` e te hanga i tētahi tohutoro mutable aliased.
/// Tāruatia ana [`String`] e tārua kawenga mō te whakahaere i te [`String`] 'o moka, ārahi ki te utu rua.
///
/// Ko te whakakii i te keehi mutunga, ko nga momo whakamahi [`Drop`] kaore e taea te `Copy`, na te mea kei te whakahaere i etahi rauemi haunga nga paita [`size_of::<T>`].
///
/// Ki te tamata koe ki te whakatinana i `Copy` i runga i te struct tau e ranei kei roto raraunga kore-`Copy`, ka whiwhi koe i te hapa [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## A, no te *kia* toku momo e `Copy`?
///
/// I te nuinga o te korero, mena ka whakatinanahia e to momo _can_ te `Copy`, me tika.
/// Kia mahara, ahakoa, e whakatinana `Copy` ko wāhanga o te API tūmatanui o koutou momo.
/// Mena ka kore te momo i te "Kape` i te future, he tupato pea te whakakore i te whakatinanatanga `Copy` inaianei, kia kore ai e pakaru te rereketanga o te API.
///
/// ## Kaitono whakatinana
///
/// I tua atu ki te [implementors listed below][impls], whakatinana ano hoki te momo e whai ake nei `Copy`:
///
/// * momo Taumahi tūemi (arā, te momo motuhake tautuhia hoki ia mahi)
/// * Nga momo tohu tohu (hei tauira, `fn() -> i32`)
/// * momo ngohi, mo te rahi katoa, ki te whakatinana hoki i te momo tūemi `Copy` (hei tauira, `[i32; 123456]`)
/// * Tuple momo, ki te whakatinana hoki ia wāhanga `Copy` (hei tauira, `()`, `(i32, bool)`)
/// * momo katinga, ki te hopu e ratou kahore uara i te taiao ranei ki te whakatinana i taua uara riro katoa `Copy` ratou.
///   Note e taurangi riro e tohutoro ngā whakatinana tonu `Copy` (ara, ki te kahore te referent e), i taurangi riro e tohutoro mutable kore whakatinana `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Tenei taea te tārua i te momo e kore e whakatinana `Copy` no o rohe ora kau (tārua `A<'_>` ka `A<'static>: Copy` anake me `A<'_>: Clone`).
// Kei i a tatou tenei ahuatanga i konei mo tenei wa na te mea he tino ruarua nga tohunga kei runga i te `Copy` kei roto i te wharepukapuka paerewa, a kaore he huarahi e taea ai tenei whanonga i tenei wa.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Ka ahu mai i te tonotono e hua ana i te trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Nga momo e pai ana te tohatoha korero i waenga i nga miro.
///
/// Kei te whakatinana aunoa tenei trait ka whakatau te taupatupatu te reira e tika ana.
///
/// Ko te whakamāramatanga pū ko: he momo `T` ko [`Sync`] ki a anake, ki te `&T` ko [`Send`].
/// I roto i te mau parau te tahi atu, ki te kahore he pea o [undefined behavior][ub] (tae atu ki ngā iwi raraunga) ka haere tohutoro `&T` i waenganui miro.
///
/// Ka rite ki tetahi e mahara, momo tahito rite [`u8`] me [`f64`] ko [`Sync`] katoa, a kia he momo töpü ohie kei roto ratou, rite tuples, structs me enums.
/// tauira atu o ngā momo [`Sync`] taketake ngā "immutable" momo rite `&T`, me te hunga i te mutability ohie riro, pērā i [`Box<T>`][box], [`Vec<T>`][vec] me te nuinga atu momo kohinga.
///
/// (Me Ahuwhānui tawhā ki te hei [`Sync`] mo ratou ipu ki te kia [`Sync`].)
///
/// He putanga ahua maere o te whakamāramatanga ko e `&mut T` ko `Sync` (ki te ko `T` `Sync`) ahakoa te mea te reira rite kia whakarato irakētanga tukutahi kore.
/// Ko te whakapati Ko e riro lau-anake te tohutoro mutable muri te tohutoro ngā (e ko, `& &mut T`), me te mea i reira te `& &T`.
/// No reira kaore he raru o te reehi raraunga.
///
/// Momo e kore e e `Sync` ko te hunga e whai "interior mutability" i roto i te puka kore-miro-haumaru, pērā i [`Cell`][cell] me [`RefCell`][refcell].
/// Ēnei momo tukua hoki te irakētanga o ratou hei tirotiro noa i roto i te pumau, tohutoro ngā.
/// Hei tauira te tikanga `set` i [`Cell<T>`][cell] e `&self`, na titau te reira i te tohutoro anake ngā [`&Cell<T>`][cell].
/// Ko te mahi tikanga kahore tukutahi, te kupu e kore e taea [`Cell`][cell] e `Sync`.
///
/// Ko tētahi atu tauira o te momo kore-`Sync` ko te atatohu tohutoro-tatau [`Rc`][rc].
/// Homai tetahi tohutoro [`&Rc<T>`][rc], ka taea e koe ki tou he [`Rc<T>`][rc] hou, te whakakētanga te tatau tohutoro i roto i te ara kore-ngota.
///
/// Hoki ngā take ka e tetahi hiahia mutability roto miro-haumaru, Rust whakarato [atomic data types], me te maukati mārama mā [`sync::Mutex`][mutex] me [`sync::RwLock`][rwlock].
/// Enei momo whakarite e tetahi irakētanga taea kore take iwi raraunga, i konei nga momo e `Sync`.
/// Waihoki, ko te [`sync::Arc`][arc] he tohu taapiri-haumaru o te [`Rc`][rc].
///
/// Me whakamahi hoki Tetahi momo ki mutability roto te Uwhi [`cell::UnsafeCell`][unsafecell] a tawhio noa te value(s) e taea te mutated roto i te tohutoro ngā.
/// Ko te kore e mahi i tenei ko te [undefined behavior][ub].
/// Hei tauira, [`transmute`][transmute]-ing mai i `&T` ki `&mut T` he muhu.
///
/// Tirohia te [the Nomicon][nomicon-send-and-sync] hoki ētahi atu kōrero e pā ana ki `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): kotahi ki te tautoko tāpiri tuhipoka i roto i whenua `rustc_on_unimplemented` i peta, a kua reira kua atu ki te taki mēnā he hea he katinga i roto i te mekameka whakaritenga, whakawhānui reira rite taua (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Zero-rahi momo whakamahia ki te tohu mea e "act like" ake ratou i te `T`.
///
/// Tāpiri i te mara `PhantomData<T>` ki tou momo parau te taupatupatu e tou momo mahi, me te mea pupuru ana te reira i te uara o te momo `T`, ahakoa e kore e te reira tino.
/// Ka whakamahia enei korero i te wa e rorohiko ana koe i etahi waahanga ahuru.
///
/// Hoki te atu i roto i-hohonu whakamārama o te āhua o ki te whakamahi i `PhantomData<T>`, tēnā kite [the Nomicon](../../nomicon/phantom-data.html).
///
/// # He korero ngahue h
///
/// Ahakoa whai ratou e rua ingoa wehiwehi, e pā ana `PhantomData` me 'momo mariko', engari e kore e ōrite.Ko noa te momo mariko tawhā he tawhā momo kore te i whakamahia.
/// I roto i te Rust, maha ai tenei te taupatupatu ki te amuamu, me te otinga, ko te ki te tāpiri i te whakamahi "dummy" i ara o `PhantomData`.
///
/// # Examples
///
/// ## tawhā ora kāore
///
/// Mahalo te nuinga take whakamahi noa hoki `PhantomData` ko he struct e kua he tawhā ora kāore, nuinga hei wāhanga o etahi waehere haumaru.
/// Hei tauira, anei te hanganga `Slice` e rua nga tohu o te momo `*const T`, akene pea ka tohu ki te raarangi i tetahi waahi:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Ko te whakaaro ko, e te raraunga whāriki he tika anake hoki te ora `'a` na `Slice` kia kore mutunga o `'a`.
/// Heoi, e kore e whakahuatia tenei whakaaro i roto i te waehere, mai i reira he kore whakamahinga o te ora `'a` me i konei e kore te mea ūkui aha raraunga pā reira ki.
/// Ka taea e taatau te whakatika ma te korero ki te kaitautu kia mahi *me te mea* kei roto i te `Slice` hanganga he tohutoro `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// I tenei wa ka hiahiatia te tuhinga `T: 'a`, e tohu ana ko nga tohutoro i te `T` e whaimana ana i te roanga o te tau `'a`.
///
/// A, no te arawhiti he `Slice` koutou whakarato noa te `PhantomData` uara mo te mara `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Nga taatari momo kore whakamahia
///
/// Reira te tahi mau taime te tupu e whai koe tawhā momo kāore e tohu he aha te momo o ngā raraunga i te struct ko "tied" ki, ahakoa e kore e mau i kitea e raraunga i roto i te struct iho.
/// Tenei ko te tauira i reira te panga o tenei ki [FFI].
/// Ko te whakamahinga atanga ke kakau o momo `*mut ()` ki tirohia ki Rust uara o ngā momo rerekē.
/// aru i tatou i te momo Rust te whakamahi i te tawhā momo mariko i runga i te struct `ExternalResource` i takaia te kakau.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Rangatiratanga me te haki taka
///
/// Tāpiri i te mara o te momo `PhantomData<T>` tohu e koutou momo nona raraunga o momo `T`.Ko tenei ka tohu ke ana ka whakatakahia to momo, ka taka pea i te kotahi neke atu ranei nga waahanga o te momo `T`.
/// Ko tenei e pa ana ki te Rust kaiwhakatautau [drop check] taatai.
///
/// Ki te kore koutou struct e i roto i te meka *ake* te raraunga o te momo `T`, he reira pai ki te whakamahi i te momo tohutoro, rite `PhantomData<&'a T>` (ideally) `PhantomData<*const T>` (ki te pā kahore ora) ranei, kia rite kore ki te tohu mana.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// I whakamahia te trait Kaitoha-a-roto hei tohu i te momo whakaahuru enum.
///
/// Kei te whakatinana aunoa tenei trait mo nga momo me e kore e tāpiri tetahi wakaae ki [`mem::Discriminant`].
/// Ko reira **whanonga kāore** ki ai ā i waenganui `DiscriminantKind::Discriminant` me `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Ko te momo o te discriminant, e me makona i te trait bounds hiahiatia e `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// whakamahia e taupatupatu-ā trait ki te whakatau mehemea kei te momo tetahi `UnsafeCell` ä, engari e kore i roto i te indirection.
///
/// pā tenei, hei tauira, ahakoa whakanohoia he `static` o taua momo i roto i te pānui i-anake pūmahara pateko pūmahara pateko taeatuhi ranei.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Momo e taea e whakakorikoria humarie i muri i te pinea.
///
/// Rust iho e kore ariā o ngā momo aueue ore, a whakaaro nekehanga (hei tauira, i roto i taumahi [`mem::replace`] ranei) ki te kia haumaru tonu.
///
/// whakamahia te momo [`Pin`][Pin] te utu ki te ārai nekehanga i roto i te pūnaha momo.Ko nga Tohohu `P<T>` kua takaia ki te takai [`Pin<P<T>>`][Pin] kaore e taea te neke atu.
/// Tirohia nga tuhinga [`pin` module] mo etahi atu korero mo te pinea.
///
/// Ko te whakamahi i te `Unpin` trait mo te `T` ka hapai i nga here o te whakaweto i te momo, ka taea ai te neke i te `T` mai i te [`Pin<P<T>>`][Pin] me nga mahi penei i te [`mem::replace`].
///
///
/// `Unpin` e kore putanga i te katoa mo ngā raraunga kore-pinea.
/// Ina koa, ko te [`mem::replace`] te neke neke i te `!Unpin` raraunga (he pai mo tetahi `&mut T`, kaore i te waa `T: Unpin`).
/// Heoi, e kore e taea e koe te whakamahi i [`mem::replace`] i runga i raraunga takaia roto i te [`Pin<P<T>>`][Pin] no te mea e kore koutou e taea te tiki i te `&mut T` e hiahia ana koe mo taua, a *e* ko te aha hanga tenei mahi pūnaha.
///
/// Na tenei, mo te tauira, e taea anake te mahi i runga i ngā momo whakatinana `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // E hiahia ana matou ki tetahi korero whakarereke hei karanga i te `mem::replace`.
/// // Ka taea e maatau te tiki korero penei na (implicitly) e tono ana ki te `Pin::deref_mut`, engari ka taea noa na te mea `String` e whakamahi ana i te `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Kei te whakatinana aunoa tenei trait mo tata nga momo.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// He momo tautohu e kore nei e whakatinana `Unpin`.
///
/// Ki te kei te momo he `PhantomPinned`, e kore e whakatinana reira `Unpin` i taunoa.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Nga Whakatinana o `Copy` mo nga momo tawhito.
///
/// E whakatinana implementations e kore e taea te whakaahuatia i roto i Rust i `traits::SelectionContext::copy_clone_conditions()` i `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Ka taea te kape i nga tohutoro tiri, engari ko nga tohutoro ka taea te huri *kaore e taea*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}