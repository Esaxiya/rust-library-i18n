#![stable(feature = "futures_api", since = "1.36.0")]

//! uara tukutahingakore.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// E hiahiatia ana tenei momo na te mea:
///
/// a) Kaore e taea e nga Kaihanga te whakamahi i te `for<'a, 'b> Generator<&'a mut Context<'b>>`, no reira me tika te tohu tohu tika (tirohia te <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Ko nga tohu tohu me te `NonNull` ehara i te `Send`, i te `Sync` ranei, na te mea ko te future non-Send/Sync ano hoki, a kaore matou e hiahia ki tera.
///
/// Reira e ohie hoki te HIR e tukupu ana o `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Takaia he kaihanga miihini ki te future.
///
/// Tenei mahi hoki i te raro `GenFuture`, engari hiako te reira i roto i `impl Trait` ki te hoatu karere pai hapa (`impl Future` nui atu i `GenFuture<[closure.....]>`).
///
// Ko `const` tenei ki te karo i ngā hapa anō i muri i ora tatou i `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // whakawhirinaki tatou i runga i te meka e he aueue ore i roto i te tikanga ki te hanga i tarewa whaiaro-referential i roto i te generator whāriki async/await futures.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // HAUMARU: Haumaru no te mea kei tatou !Unpin + !Drop, a ka he tika he ngä mara tenei.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Tīmata anō te generator, tahuri te `&mut Context` ki te `NonNull` raw atatohu.
            // Te `.await` e tukupu ana ka maka humarie e hoki ki te `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // HAUMARU: te pau kaiwaea taurangi e `cx.0` ko te atatohu whaimana
    // e fakahoko nga whakaritenga katoa mo te tohutoro mutable.
    unsafe { &mut *cx.0.as_ptr().cast() }
}