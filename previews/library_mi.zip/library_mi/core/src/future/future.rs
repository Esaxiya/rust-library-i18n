#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Ko te future e tohu ana i te tatauranga taarua.
///
/// He future he uara kaore ano pea kia oti te rorohiko te mahi.
/// Tenei ahua o "asynchronous value" hanga taea reira mo te miro ki te haere tonu te mahi mahi whai hua i tatari ai mo ki te uara hei wātea.
///
///
/// # Ko te tikanga `poll`
///
/// Ko te tikanga matua o future, `poll`,*ngana* ki te whakatau i te future ki te uara whakamutunga.
/// Kaore tenei tikanga e aukati mena kaore i te rite te uara.
/// Engari, whakaritea te mahi o nāianei te ki kia rų ake ina te reira taea ki te hanga atu te ahunga whakamua e `poll`ing ano.
/// Ko te `context` i tukuna ki te tikanga `poll` ka taea te whakarato i te [`Waker`], he kakau mo te whakaoho i te mahi o naianei.
///
/// A, no te whakamahi i te future, koutou e kore te tikanga e karanga `poll` tika, engari hei utu `.await` te uara.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Te momo uara kua oti i te otinga.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Ngana ki te whakatau i te future ki te uara whakamutunga, rēhita i te mahi o nāianei mō te ohonga ki te kahore he wātea ano te uara.
    ///
    /// # uara Hoki
    ///
    /// Tenei hoki taumahi:
    ///
    /// - [`Poll::Pending`] mena kaore ano kia rite te future
    /// - [`Poll::Ready(val)`] me te hua `val` o tenei future mena i oti angitu.
    ///
    /// Kia oti, kua he future, e kore kia `poll` reira ano kiritaki.
    ///
    /// A, no te kore ko te future rite ano, hoki `poll` `Poll::Pending` me toa he ki tou o te [`Waker`] tuhi i te [`Context`] nāianei.
    /// Kei te ka rų tenei [`Waker`] kotahi te future taea te hanga i te ahunga whakamua.
    /// Hei tauira, he future tatari mo te turanga ki te riro te pānui e karanga `.clone()` i runga i te [`Waker`] me te rokiroki i te reira.
    /// A, no te tae mai te tohu tohu wāhi kē e he pānui te ateatenga, ka karanga [`Waker::wake`] ko me te turanga awoken mahi o future te.
    /// Kia oti te mahi, kua rų ake, kia ngana ano reira ki `poll` te future, e ai ranei e kore e hua i te uara whakamutunga.
    ///
    /// kia Note e i runga i ngā waea maha ki `poll`, anake te [`Waker`] i te [`Context`] haere ki te karanga tata te nuinga kia whakaritea ki te farii i te ohonga.
    ///
    /// # āhuatanga wāhaere
    ///
    /// Futures anake he e mangere,* *;Me waiho ratou *kaha*`poll`ed ki te hanga i te ahunga whakamua, te tikanga e ia wa rų te mahi o nāianei ake, kia kaha ai anō-`poll` tārewa futures e reira kua he moni i roto i tonu.
    ///
    /// E kore e karangatia e te mahi `poll` toutou i roto i te koropiko raru-hei utu, anake kia huaina reira ka tohu te future e he reira rite ki te hanga i te ahunga whakamua (na roto i te te karanga `wake()`).
    /// Ki te koe kei maheni ki te syscalls `poll(2)` `select(2)` ranei i runga Unix o reira utu fakatokanga'i e te nuinga mahi futures *kore* mamae te taua raruraru o "all wakeups must poll all events";atu rite `epoll(4)` he ratou.
    ///
    /// He whakatinanatanga o `poll` kia feinga ki hoki hohoro, a kahore e ārai.Ko te hoki wawe mai ka aukati i te aukati i nga miro, o nga koropiko huihuinga ranei.
    /// Mena e mohiotia ana i mua atu o te waa ko te piiraa ki `poll` ka mutu te wa poto, me tuku te mahi ki te puna miro (he mea pera ranei) kia mohio ai ka taea te whakahoki wawe mai a `poll`.
    ///
    /// # Panics
    ///
    /// Kia Kua oti he future (hoki mai `Ready` i `poll`), karanga tona tikanga `poll` ano kia panic, te aukati ake, take atu momo o raruraru ranei;te `Future` trait kaore he whakaritenga mo nga paanga o taua piiraa.
    /// Heoi, ka rite ki kore e te tikanga `poll` tohua `unsafe`, te tono ture mua o Rust: e kore me meinga waea whanonga kāore (pirau mahara, te whakamahi hē o ngā mahi `unsafe`, ranei te rite), ahakoa o te kāwanatanga o te future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}