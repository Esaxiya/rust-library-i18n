use crate::future::Future;

/// Te faafariuraa ki te `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Ko te putanga e ka whakaputa i te future i otinga.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// E ahua o future e tahuri tatou tenei ki?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Ka waihanga te future i te uara.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}