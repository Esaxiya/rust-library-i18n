use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Nga taonga e whai mana ana ki te *whakakapinga* me te *mahi o mua* i mua.
///
/// Ko te whakakapi * * nekehanga mahi ki uara e whakataurite nui.
/// Ko te mua * * nekehanga mahi ki uara e whakataurite iti.
///
/// # Safety
///
/// Ko tenei trait he `unsafe` na te mea me tika tana whakatinana mo te ahuru o te whakatinanatanga `unsafe trait TrustedLen`, a ko nga hua o te whakamahi i tenei trait ka taea te whakawhirinaki ma te waehere `unsafe` kia tika ana ka tutuki i nga waahanga kua whakaraupapahia.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Hoki te maha o mono * * kaupae e hiahiatia ana ki te tiki i `start` ki `end`.
    ///
    /// Whakahokia `None` ki te maha o kaupae e huri `usize` (ranei e kore e taea, ranei, ki te kore e te tae `end`).
    ///
    ///
    /// # Invariants
    ///
    /// Hoki tetahi `a`, `b`, ko `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` mehemea ana mena ko `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` mehemea ana mena ko `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` ana mena ko `a <= b`
    ///   * Tokua ko: `steps_between(&a, &b) == Some(0)` ki a anake, ki te `a == b`
    ///   * Kia mahara ko te `a <= b` ko _not_ te tohu `steps_between(&a, &b) != None`;
    ///     Ko te take tenei ka e rapu utu i te reira hau atu i te `usize::MAX` sitepu ki te tiki ki `b`
    /// * `steps_between(&a, &b) == None` mena `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Hoki te uara e pai kia whiwhi e tango i te mono * * o nga wa `self` `count`.
    ///
    /// Mena ka kaha ake tenei i te whānuitanga o nga uara e tautokohia ana e `Self`, whakahokia mai a `None`.
    ///
    /// # Invariants
    ///
    /// Hoki tetahi `a`, `n`, ko `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Hoki tetahi `a`, `n`, a `m` te wahi e kore e `n + m` waipuke:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Mo tetahi `a` me `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Hoki te uara e pai kia whiwhi e tango i te mono * * o nga wa `self` `count`.
    ///
    /// Mena ka kaha ake tenei ki te whānuitanga o nga uara e tautokohia ana e `Self`, ka tukuna tenei mahi ki te panic, te takai, te kukume ranei.
    ///
    /// Ko te whanonga te whakaaro ki panic ina e whakahohea tāpaetanga patuiro, a ki te roropi mai te faaо te kore ranei.
    ///
    /// Ko te waehere huakore kaua e whakawhirinaki ki te tika o te whanonga i muri o te taumaha.
    ///
    /// # Invariants
    ///
    /// Hoki tetahi `a`, `n`, ko `m`, te wahi puta kahore waipuke:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Hoki tetahi `a` ko `n`, te wahi puta kahore waipuke:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Hoki te uara e pai kia whiwhi e tango i te mono * * o nga wa `self` `count`.
    ///
    /// # Safety
    ///
    /// He whanonga kore i tautuhia mo tenei mahi ki te waipuke i te whānuitanga o nga uara e tautokohia ana e `Self`.
    /// Ki te kore koe e taea e kī e e tenei e kore e rauroha noa, whakamahi `forward` ranei `forward_checked` hei utu.
    ///
    /// # Invariants
    ///
    /// Hoki tetahi `a`:
    ///
    /// * ki te reira te vai `b` pērā i `b > a`, he reira haumaru ki te karanga `Step::forward_unchecked(a, 1)`
    /// * ki te reira te vai `b`, `n` penei e `steps_between(&a, &b) == Some(n)`, he reira haumaru ki te karanga `Step::forward_unchecked(a, m)` mo tetahi `m <= n`.
    ///
    ///
    /// Hoki tetahi `a` ko `n`, te wahi puta kahore waipuke:
    ///
    /// * `Step::forward_unchecked(a, n)` he rite ki te `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Hoki te uara e pai kia whiwhi e tango i te mua * * o nga wa `self` `count`.
    ///
    /// Mena ka kaha ake tenei i te whānuitanga o nga uara e tautokohia ana e `Self`, whakahokia mai a `None`.
    ///
    /// # Invariants
    ///
    /// Hoki tetahi `a`, `n`, ko `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Mo tetahi `a` me `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Hoki te uara e pai kia whiwhi e tango i te mua * * o nga wa `self` `count`.
    ///
    /// Mena ka kaha ake tenei ki te whānuitanga o nga uara e tautokohia ana e `Self`, ka tukuna tenei mahi ki te panic, te takai, te kukume ranei.
    ///
    /// Ko te whanonga te whakaaro ki panic ina e whakahohea tāpaetanga patuiro, a ki te roropi mai te faaо te kore ranei.
    ///
    /// Ko te waehere huakore kaua e whakawhirinaki ki te tika o te whanonga i muri o te taumaha.
    ///
    /// # Invariants
    ///
    /// Hoki tetahi `a`, `n`, ko `m`, te wahi puta kahore waipuke:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Hoki tetahi `a` ko `n`, te wahi puta kahore waipuke:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Hoki te uara e pai kia whiwhi e tango i te mua * * o nga wa `self` `count`.
    ///
    /// # Safety
    ///
    /// He whanonga kore i tautuhia mo tenei mahi ki te waipuke i te whānuitanga o nga uara e tautokohia ana e `Self`.
    /// Ki te kore koe e taea e kī e e tenei e kore e rauroha noa, whakamahi `backward` ranei `backward_checked` hei utu.
    ///
    /// # Invariants
    ///
    /// Hoki tetahi `a`:
    ///
    /// * ki te reira te vai `b` pērā i `b < a`, he reira haumaru ki te karanga `Step::backward_unchecked(a, 1)`
    /// * Mena he `b`, `n` penei i te `steps_between(&b, &a) == Some(n)`, he pai te karanga `Step::backward_unchecked(a, m)` mo tetahi `m <= n`.
    ///
    ///
    /// Hoki tetahi `a` ko `n`, te wahi puta kahore waipuke:
    ///
    /// * `Step::backward_unchecked(a, n)` he rite ki te `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// He tonotono-hangaia hoki pūrite te tau tōpū fakapapau ki ngā momo rerekē tonu enei.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // SAFETY: me kii te kaiwaea kia kore te `start + n` e waipuke.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // HAUMARU: te kaiwaea kua ki taurangi e kore `start - n` e te waipuke te.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // I roto i te hanga patuiro, tīmata i te panic i te waipuke.
            // kia arotau tino i roto i roto i te tuku hanga tenei.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Mahi tākai pāngarau ki tukua hei tauira `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // I roto i te hanga patuiro, tīmata i te panic i te waipuke.
            // kia arotau tino i roto i roto i te tuku hanga tenei.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Mahi tākai pāngarau ki tukua hei tauira `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Ka whakawhirinaki tenei ki te $u_narrower <=whakamahi
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // ki te mea he n roto o awhe, he rawa `unsigned_start + n`
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // ki te mea he n roto o awhe, he rawa `unsigned_start - n`
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // whakawhirinaki ana tēnei i runga i $i_narrower <=usize
                        //
                        // Ko te maka ki te miihini e toro atu te whanui engari ka tiakina te tohu.
                        // Whakamahia wrapping_sub i roto i te wāhi isize me maka ki te usize ki whakatatau te rerekētanga e kore ai e uru ki roto i te whānuitanga o te isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Tākai kakau take rite `Step::forward(-120_i8, 200) == Some(80_i8)`, ahakoa 200 Ko roto o te awhe mo i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // puke ana Addition
                            }
                        }
                        // Ki te he n roto o ngā o tauira
                        // u8, katahi ka nui ake i te whānuitanga katoa mo te i8 he whanui na `any_i8 + n` me te i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Tākai kakau take rite `Step::forward(-120_i8, 200) == Some(80_i8)`, ahakoa 200 Ko roto o te awhe mo i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // tangohanga ngawha
                            }
                        }
                        // Ki te he n roto o ngā o tauira
                        // u8, Na ko reira nui atu i te whānuitanga katoa hoki i8 he whanui kia `any_i8 - n` tika ngawha i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Ki te mea nui rawa hoki tauira te rerekētanga
                            // i128, ngā ano whaikupu hei reira nui hoki usize rawa ki iti paraire.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // HAUMARU: res ko te scalar Waehereao whaimana
            // (I raro 0x110000 a kahore i roto i 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // HAUMARU: res ko te scalar Waehereao whaimana
        // (I raro 0x110000 a kahore i roto i 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SAFETY: me kii te kaiwaea kia kore tenei e waipuke
        // te whānuitanga o ngā uara mō te char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // SAFETY: me kii te kaiwaea kia kore tenei e waipuke
            // te whānuitanga o ngā uara mō te char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // HAUMARU: no te mea o te kirimana o mua, whai ko tenei
        // i te kaiwaea ki te waiho i te char whaimana.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SAFETY: me kii te kaiwaea kia kore tenei e waipuke
        // te whānuitanga o ngā uara mō te char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // SAFETY: me kii te kaiwaea kia kore tenei e waipuke
            // te whānuitanga o ngā uara mō te char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // HAUMARU: no te mea o te kirimana o mua, whai ko tenei
        // i te kaiwaea ki te waiho i te char whaimana.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // SAFETY: katahi ano ka tirohia te tikanga o mua
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // SAFETY: katahi ano ka tirohia te tikanga o mua
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Ēnei tonotono whakaputa `ExactSizeIterator` impls mō ngā momo ngā.
//
// * `ExactSizeIterator::len` Kei te hiahiatia ki te hoki tonu tangohia he `usize`, kia taea e kore ngā roa atu `usize::MAX`.
//
// * Hoki ngā momo tau tōpū i `Range<_>` ko te take mō ngā momo whaiti atu rite whanui rite `usize` ranei tenei.
//   Hoki ngā momo tau tōpū i `RangeInclusive<_>` ko te take mō ngā momo *tino whaiti* atu `usize` mai tauira tenei
//   `(0..=u64::MAX).len()` e kia `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Ko enei incorect ia te korerorero i runga ake, engari te tango ratou e waiho i te huringa pakaru rite i ähuareka ratou i roto i Rust 1.0.0.
    // Na eg
    // `(0..66_000_u32).len()` hei tauira, ka whakahiato, kahore hapa faaararaa i runga i ngä tüäpapa moka-16 ranei, engari tonu ki te hoatu i te hua he.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Ko enei incorect ia te korerorero i runga ake, engari te tango ratou e waiho i te huringa pakaru rite i ähuareka ratou i roto i Rust 1.26.0.
    // Na eg
    // `(0..=u16::MAX).len()` hei tauira, ka whakahiato, kahore hapa faaararaa i runga i ngä tüäpapa moka-16 ranei, engari tonu ki te hoatu i te hua he.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // SAFETY: katahi ano ka tirohia te tikanga o mua
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // SAFETY: katahi ano ka tirohia te tikanga o mua
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SAFETY: katahi ano ka tirohia te tikanga o mua
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SAFETY: katahi ano ka tirohia te tikanga o mua
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SAFETY: katahi ano ka tirohia te tikanga o mua
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SAFETY: katahi ano ka tirohia te tikanga o mua
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}