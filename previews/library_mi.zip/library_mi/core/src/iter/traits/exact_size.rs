/// He kaituku hiko e mohio ana ki tona roa roa.
///
/// He tokomaha [`Iterator`] s e kore e matau i te tini o nga wa e ratou tukurua, engari mahi etahi.
/// Ki te mohio te iterator pehea maha nga wa e taea tukurua reira, whakarato wāhi ki taua kōrero e taea e whai hua.
/// Hei tauira, ki te hiahia koe ki tukurua whakamuri, he tīmatanga pai, ko te ki te matau ki te wahi i te mutunga, ko te.
///
/// A, no te whakamahi i te `ExactSizeIterator`, me whakauru ano e koe te [`Iterator`].
/// I a koe e pera ana, ko te whakatinanatanga o [`Iterator::size_hint`]*me* whakahoki i te rahinga tika o te kaitahuri.
///
/// Ko te tikanga [`len`] he whakamahinga taunoa, no reira kaore e tika kia whakamahia e koe.
/// Heoi, kia waiho koutou taea ki te whakarato i te whakatinanatanga performant nui atu i te taunoa, na'ete reira i roto i tenei take hanga tikanga.
///
///
/// Note e tenei trait ko te haumaru trait me rite taua e *kore* me *kore e taea e* taurangi e he tika te roa hoki.
/// Tenei tikanga e `unsafe` waehere kore me ** ** whakawhirinaki i runga i te tika o [`Iterator::size_hint`].
/// homai ana te iu me te haumaru [`TrustedLen`](super::marker::TrustedLen) trait tenei taurangi atu.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// // e matau ana te whānuitanga fakataimí rite pehea maha nga wa ka tukurua i te reira
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// I te [module-level docs], i whakamahia e maatau he [`Iterator`], `Counter`.
/// Me whakamahi ano a `ExactSizeIterator` mo tenei:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Ka taea e ngāwari tatou tātai i te toe maha o tāruarua.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Na inaianei e taea tatou te whakamahi i te reira!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Whakahokia te roa tangohia o te iterator.
    ///
    /// Ko te āta whakatinanatanga i ka hoki te iterator rite `len()` atu wā he uara [`Some(T)`], i mua i hoki mai [`None`].
    ///
    /// He whakamahinga taunoa ta tenei tikanga, no reira kaore e tika kia whakamahia e koe.
    /// Heoi, ki te taea e koe te whakarato i tētahi whakatinanatanga pai atu, e taea e koe na reira.
    /// Tirohia te te tuhinga [trait-level] mo te tauira.
    ///
    /// He te taurangi haumaru taua rite te mahi [`Iterator::size_hint`] tenei mahi.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // e matau ana te whānuitanga fakataimí rite pehea maha nga wa ka tukurua i te reira
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Ko te uaua rawa ārai tenei whakapae, engari taki reira te pūmau
        // whai e te trait.
        // Mena ko trait tenei ko rust-a-roto, ka taea e taatau te whakamahi i te debug_assert !;haapapu_eq!Ka tirohia implementations kaiwhakamahi Rust katoa rawa.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Whakahoki ai i te `true` mena he putu te kaitohu.
    ///
    /// Tenei tikanga he whakatinanatanga taunoa mā te whakamahi i [`ExactSizeIterator::len()`], kia kore koe e hiahia ana ki te whakatinana i te reira koe.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}