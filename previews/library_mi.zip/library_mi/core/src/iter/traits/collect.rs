/// Te hurihanga mai i te [`Iterator`].
///
/// Na roto i te whakatinana i `FromIterator` mo te momo, te tautuhi koe pehea ka hanga ai i te iterator.
/// He tikanga noa tenei mo nga momo e whakaahua ana i te kohinga momo.
///
/// [`FromIterator::from_iter()`] Ko uaua i huaina āta, a ka te utu e whakamahia ana i roto i te tikanga [`Iterator::collect()`].
///
/// Tirohia nga tuhinga [`Iterator::collect()`]'s mo etahi atu tauira.
///
/// Tirohia hoki: [`IntoIterator`].
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Ma te whakamahi i te [`Iterator::collect()`] hei whakamahi marama i te `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Te whakamahi i te `FromIterator` mo to momo:
///
/// ```
/// use std::iter::FromIterator;
///
/// // He kohinga tauira, tera noa te taapiringa mo te Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Me hoatu e maatau etahi tikanga kia taea ai e tatou te hanga tetahi hei taapiri i nga mea ki roto.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // a ka whakatinana tatou FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Na e taea te hanga matou i te iterator hou ...
/// let iter = (0..5).into_iter();
///
/// // ... a ka hanga he MyCollection i roto o reira
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // mahi kohi rawa!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Ka waihanga te uara i te iterator.
    ///
    /// Tirohia te [module-level documentation] mo etahi atu.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Te hurihanga ki te [`Iterator`].
///
/// Na roto i te whakatinana i `IntoIterator` mo te momo, te tautuhi koe pehea e tahuri ai ki te iterator.
/// He tikanga noa tenei mo nga momo e whakaahua ana i te kohinga momo.
///
/// Ko tētahi painga o te whakatinana i `IntoIterator` ko e to koutou momo e [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Tirohia hoki: [`FromIterator`].
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Te whakatinana i `IntoIterator` mo koutou momo:
///
/// ```
/// // He kohinga tauira, tera noa te taapiringa mo te Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Me hoatu e maatau etahi tikanga kia taea ai e tatou te hanga tetahi hei taapiri i nga mea ki roto.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // a ka whakamahia e matou te IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Ka taea e maatau te hanga kohinga hou ...
/// let mut c = MyCollection::new();
///
/// // ... tāpiri i te tahi mea ki reira ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... a ka tahuri ai ki te Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Ko reira noa ki te whakamahi i `IntoIterator` rite te trait bound.Ma tenei ka taea te whakarereke i te momo kohinga whakauru, i te mea he kaituku tonu.
/// Ka taea te tohua rohe atu i te rāhui i runga i
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// te iterated te momo o te huānga ki runga.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// E ahua o iterator e tahuri tatou tenei ki?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Ka waihanga te iterator i te uara.
    ///
    /// Tirohia te [module-level documentation] mo etahi atu.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Whakawhānuihia he kohinga me nga tuhinga o te miihini.
///
/// Ka whakaputahia e te Iterators he raupapa uara, ka taea hoki te kohinga kohinga hei raupapa uara.
/// Te `Extend` trait Bridge tenei āputa, tuku ki a koutou whakawhānui i te kohinga mā te tae atu i te tirotiro o taua iterator.
/// A, no te whakawhānui i te kohinga ki te kī kē tīariari, whakahoutia e te urunga te ranei, i roto i te take o ngā kohinga e tukua e ngā tāurunga maha ki taviri rite, e whakaurua te urunga te.
///
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// // Ka taea e koe te whakawhānui i te Aho ki etahi pūāhua:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Te whakamahi i te `Extend`:
///
/// ```
/// // He kohinga tauira, tera noa te taapiringa mo te Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Me hoatu e maatau etahi tikanga kia taea ai e tatou te hanga tetahi hei taapiri i nga mea ki roto.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // mai kua MyCollection he rārangi o i32s, whakatinana tatou Toro mo i32
/// impl Extend<i32> for MyCollection {
///
///     // He maama ake tenei me te waitohu momo raima: ka taea te karanga ki te toro atu i nga mea katoa ka taea te huri hei Iterator e homai ana ki a tatou nga i32s.
///     // No te mea e ti'a ia tatou i32s ki te hoatu ki MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Ko te whakatinanatanga rawa māmā: koropiko i roto i te iterator, a add() ia huānga ki tatou.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // kia whakawhānui a to tatou kohinga ki toru atu tau
/// c.extend(vec![1, 2, 3]);
///
/// // kua tapiritia e matou enei āhuatanga ki runga i te mutunga
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Ka tohaina he kohinga me nga korero o te miihini.
    ///
    /// Ka rite ki te mea te tikanga anake e hiahiatia ana mo tenei trait tenei, i roto i nga tuhinga [trait-level] ētahi atu kōrero.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // Ka taea e koe te whakawhānui i te Aho ki etahi pūāhua:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Ka tohaina he kohinga me te waahanga kotahi.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// kaha Rahui i roto i te kohinga mo te maha homai o huānga atu.
    ///
    /// Te whakatinanatanga taunoa kahore e.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}