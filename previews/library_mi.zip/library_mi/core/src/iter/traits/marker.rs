/// He iterator e tonu ma'u pē ki tukua `None` ka pau.
///
/// Ko te waea i muri mai i runga i te miihini kua oti te whakahoki mai i te `None` i tetahi wa ka tutuki kia hoki mai ano a [`None`].
/// Ko tenei trait me whakatinana e nga kaitautoko katoa e peera ana i tenei ara na te mea ka taea te whakarite kia [`Iterator::fuse()`].
///
///
/// Note: I te nuinga, kaua e whakamahia e koe te `FusedIterator` ki nga rohe whanui mena ka hiahia koe ki te miihini whakauru.
/// Engari, me karanga noa e koe te [`Iterator::fuse()`] i runga i te tohu.
/// Mena kua whakauruhia te miihini, ko te taapiri [`Fuse`] taapiri ka waiho hei kore-kore kaore he whiu mahi.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// He kaituku korero e whakaatu ana i te roa tika ma te whakamahi i te rahi_hint.
///
/// pūrongo te iterator he tīwhiri rahi i reira ko reira rānei tangohia (raro herea he rite ki runga, herea), te o runga herea ko [`None`] ranei.
///
/// Ko te here o runga ko te [`None`] anake mena he nui ake te roa o te kaitahuri i te [`usize::MAX`].
/// I roto i taua take, ko te raro herea kia [`usize::MAX`], hua i roto i te [`Iterator::size_hint()`] o `(usize::MAX, None)`.
///
/// Me whakaputa e te kaitahuri te maha o nga huanga i panuitia e ia, i rereke ranei i mua i te mutunga o te mutunga.
///
/// # Safety
///
/// Me anake kia whakatinana tenei trait ka tautokona ake te kirimana te.
/// Me tirohia kiritaki o tenei trait [`Iterator::size_hint()`]’s o runga herea.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// He kaitohu i te wa e whakaputa ana i tetahi taonga ka tangohia e ia tetahi waahanga neke atu i te [`SourceIter`] e whaaia ana.
///
/// Ka karangatia hoki e tetahi tikanga e kōkiritanga te iterator, hei tauira
/// [`next()`] ranei [`try_fold()`], taurangi e hoki ia taahiraa i te iti rawa kia kotahi uara o puna whāriki o te iterator kua oho atu a taea te kōkuhu te hua o te mekameka iterator i tona wahi, Ngae herenga hanganga o te pūtake tukua he kōkuhu taua.
///
/// I roto i te mau parau te tahi atu tohu tenei trait e taea te kohia he paipa iterator i wahi.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}