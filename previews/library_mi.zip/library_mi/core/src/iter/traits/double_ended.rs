use crate::ops::{ControlFlow, Try};

/// Ka taea e te kaitahuri te whakaputa huanga mai i nga pito e rua.
///
/// Ko tetahi mea e whakamahi ana i te `DoubleEndedIterator` tetahi atu taapiri ki runga ake i tetahi mea e whakamahi ana i te [`Iterator`]: te kaha ki te tango ano i nga `Tuemi` mai i muri, me mua hoki.
///
///
/// He mea nui ki te tuhipoka e rua hoki, me te mahi mai i runga i te whānuitanga kotahi, a ka mahi i kore ripeka: ko runga whitiauau ina tutaki ratou i roto i te waenganui.
///
/// I roto i te ahua rite ki te kawa [`Iterator`], kotahi hoki te `DoubleEndedIterator` [`None`] i te [`next_back()`], karanga reira ano kia ranei e kore e hoki mai ano ake [`Some`].
/// [`next()`] me [`next_back()`] ka taea te whakawhiti mo tenei kaupapa.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Tango ai me hoki te huānga i te pito o te iterator.
    ///
    /// Whakahokia `None` ka reira he kore ake huānga.
    ///
    /// Kei nga tuhinga [trait-level] etahi atu korero.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Ko te āhuatanga tuku e `tikanga o DoubleEndedIterator` kia rerekē i te hunga tuku i ngā tikanga [`Iterator`] 's:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Ka kōkiri i te iterator mai i muri e nga huanga `n`.
    ///
    /// `advance_back_by` Ko te putanga whakamuri o [`advance_by`].Ko tenei tikanga ka peke i nga waahanga `n` mai i te tuara ma te karanga i te [`next_back`] tae atu ki nga waa `n` kia tutuki ra ano te [`None`].
    ///
    /// `advance_back_by(n)` ka hoki mai [`Ok(())`] ki te pai te kōkiritanga te iterator i āhuatanga `n`, [`Err(k)`] ranei ki te te tūpono [`None`], kei hea `k` ko te maha o ngā āhuatanga ko matatau te iterator e i mua i rere i roto i o huānga (arā
    /// te roa o te whiti).
    /// Kia mahara ko te `k` he iti ake i te `n` i nga wa katoa.
    ///
    /// Ko te karanga i te `advance_back_by(0)` kaore e pau i nga waahanga ka hoki mai ano i te [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` anake i pekehia
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Hoki te `huānga n`th i te pito o te iterator.
    ///
    /// Koinei te mea kua hurihia te whakahokinga o [`Iterator::nth()`].
    /// Ahakoa he penei i te nuinga o nga mahi whakariterite, ka tiimata te tatauranga mai i te kore, na `nth_back(0)` i whakahoki mai te uara tuatahi mai i te mutunga, `nth_back(1)` te tuarua, aha atu.
    ///
    ///
    /// Kia mōhio e ka pau āhuatanga katoa i waenganui i te mutunga, me te huānga hoki, tae atu ki te huānga hoki.
    /// tikanga hoki tenei e karanga `nth_back(0)` wa maha i runga i te iterator ano ka hoki mai huānga rerekē.
    ///
    /// `nth_back()` ka hoki mai [`None`] ki te mea nui atu rite ki te roa o te iterator ranei `n`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Ko te karanga i te `nth_back()` i nga wa maha kaore i te huri i te kaitohu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Hoki mai `None` ki reira he iti iho i te huānga `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Ko te putanga whakamuri o [`Iterator::try_fold()`] tenei: e te reira huānga tīmata i te hoki o te iterator.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // No te mea te reira poto-circuited, he wātea tonu te toe huānga i roto i te iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// He tikanga iterator e whakaiti huānga o te iterator ki te, uara whakamutunga kotahi, timata mai i te hoki.
    ///
    /// Ko te putanga whakamuri o [`Iterator::fold()`] tenei: e te reira huānga tīmata i te hoki o te iterator.
    ///
    /// `rfold()` e rua ngā tohenga: he uara tuatahi, me te katinga ki e rua ngā tohenga: he 'accumulator', me he huānga.
    /// Ko te katinga ka whakahoki i te uara me whiwhi te kaiwhakaputuputu mo te whaarua i muri mai.
    ///
    /// Ko te uara tuatahi ko te uara ka whai te accumulator i runga i te karanga tuatahi.
    ///
    /// I muri tono i tenei katinga ki nga huānga o te iterator, hoki `rfold()` te accumulator.
    ///
    /// Kei te te tahi mau taime i huaina tenei mahi 'reduce' 'inject' ranei.
    ///
    /// He whai hua kotuinga wa e whai koe i te kohinga o te tahi mea, a ka hiahia ki te whakaputa i te uara kotahi i reira.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // te moni o te katoa o nga āhuatanga o te
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Tenei tauira hanga he string, tīmata ki te uara tuatahi, me te haere tonu ki ia huānga i te hoki noa te mua:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Rapu mō te huānga o te iterator i te hoki e makona i te paparangi.
    ///
    /// `rfind()` e te katinga e hoki `true` `false` ranei.
    /// Ka pa ki tenei katinga ki ia waahanga o te miihini, ka tiimata i te mutunga, ana ka hoki mai tetahi o `true`, na `rfind()` ka whakahoki [`Some(element)`].
    /// Mena ka hoki mai raatau katoa `false`, ka hoki mai a [`None`].
    ///
    /// `rfind()` He poto-circuiting;i roto i te kupu atu, ka mutu te reira te tukatuka, no te te katinga hoki `true`.
    ///
    /// No te mea e `rfind()` te tohutoro, a he maha iterators tukurua runga tohutoro, tenei ahu ki te āhuatanga puputu'u pea te wahi i te tautohe ko te tohutoro rua.
    ///
    /// Ka kitea e koe tenei paanga ki nga tauira i raro ake nei, me te `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Me tu i te `true` tuatahi:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // Ka taea e tonu tatou te whakamahi i `iter`, rite reira e nui ake huānga.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}