// whakahawea-whakanikoniko-filelength Ko tenei konae tata tonu ki te kohinga o te `Iterator`.
// E kore e taea e tatou wahia e ki ngā kōnae maha.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// He atanga mō te pā ana ki iterators.
///
/// Ko te matua iterator trait tenei.
/// Hoki atu e pā ana ki te ariā o iterators tikanga, tēnā kite te [module-level documentation].
/// Ina koa, ka hiahia pea koe ki te mohio me pehea te [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// te iterated te momo o te huānga ki runga.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Kōkiritanga te iterator me hoki te uara i muri.
    ///
    /// Whakahokia [`None`] ka oti te whitiauau.
    /// kia whiriwhiri implementations iterator takitahi ki anō whitiauau, a na karanga ano `next()` kia kore ai ranei pae hopea tīmata hoki mai ano [`Some(Item)`] i etahi wāhi.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // He karanga ki a next() hoki te uara i muri ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... a ka tetahi kotahi te reira ki runga.
    /// assert_eq!(None, iter.next());
    ///
    /// // waea atu kia ranei e kore e hoki mai `None`.Here, e tonu ratou.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Whakahokia te rohe i runga i te roa o te iterator toe.
    ///
    /// Ina koa, ka whakahoki mai a `size_hint()` i tetahi tuple kei reira te waahanga tuatahi ko te roopu o raro, a ko te waahanga tuarua ko te roopu o runga.
    ///
    /// Ko te hawhe tuarua o te tuple hoki e te ko te [`Option`]`<`[`usize`] `>`.
    /// He [`None`] konei tikanga e rānei reira te kore mohiotia o runga herea, ranei te runga herea he nui atu i [`usize`].
    ///
    /// # tuhipoka whakatinana
    ///
    /// E kore e whakaūtia reira e hua he whakatinanatanga iterator te maha whakapuakina o huānga.He paki ai iterator tukua iti iho i te herea raro ranei nui atu i te o runga herea o huānga.
    ///
    /// `size_hint()` Kei te matua tikanga ki te whakamahi hoki optimizations pērā i rahui wāhi mo te āhuatanga o te iterator, engari e kore e me e whakawhirinaki ki tauira, waihotia ai rohe arowhai i roto i te waehere haumaru.
    /// He whakatinanatanga hē o `size_hint()` kore e arahi ki maumaui haumaru mahara.
    ///
    /// E mea, kia whakarato te whakatinanatanga he i whakarite tika, no te mea te kore e riro te reira i te takahi o te kawa o te trait.
    ///
    /// Ko te hoki te whakatinanatanga taunoa `(0,` [`None`]`)`e he tika hoki tetahi iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// He tauira uaua ake:
    ///
    /// ```
    /// // Ko nga tau mai i te kore ki te tekau.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // kia tukurua tatou i te kore ki te tekau nga wa.
    /// // E matau ana hoki a reira e rima rite kore e e taea kahore mahi filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Kia tāpiri o atu tau e rima ki chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // inaianei kua nui haere rohe e rua i te rima
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Whakahoki i te `None` mo te rohe o runga:
    ///
    /// ```
    /// // he kaikawe mutunga kore he here o runga me te rahinga o raro rawa pea ka taea
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Pau te iterator, tatau i te maha o tāruarua, me te hoki mai i te reira.
    ///
    /// Ka karanga i tēnei tikanga [`next`] toutou tūpono noa te [`None`], hoki mai te maha o ngā wā i kite ai [`Some`].
    /// Note e kua kia huaina [`next`] ki te iti rawa kotahi noa, ki te kore e te iterator i tetahi huānga.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Whanonga Kaha
    ///
    /// Kaore te tikanga e tiaki i nga rerenga, no reira ka tatau i nga waahanga o te miihini neke atu i te [`usize::MAX`] nga huanga ka hua mai he hua he, panics ranei.
    ///
    /// Ki te whakahohea tāpaetanga patuiro, whai he panic te.
    ///
    /// # Panics
    ///
    /// Akene tenei mahi panic mena he nui atu i te [`usize::MAX`] nga waahanga o te tiiti.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Pau te iterator, e hoki i te huānga whakamutunga.
    ///
    /// Ka aromātai tēnei tikanga te iterator noa hoki reira [`None`].
    /// I a koe e pera ana, ka mau tonu ki nga ahuatanga o tenei wa.
    /// Whai muri i te whakahoki mai o [`None`], ka whakahokia mai e `last()` te mea whakamutunga i kitea e ia.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Kōkiritanga te iterator e huānga `n`.
    ///
    /// vēkeveke ka tēnei aratuka tīpoka huānga `n` e karanga [`next`] ki runga ki nga wa `n` tūpono noa te [`None`].
    ///
    /// `advance_by(n)` ka hoki mai [`Ok(())`][Ok] ki te pai te kōkiritanga te iterator i āhuatanga `n`, [`Err(k)`][Err] ranei ki te te tūpono [`None`], kei hea `k` ko te maha o ngā āhuatanga ko matatau te iterator e i mua i rere i roto i o huānga (arā
    /// te roa o te whiti).
    /// Kia mahara ko te `k` he iti ake i te `n` i nga wa katoa.
    ///
    /// e kore e karanga ana `advance_by(0)` pau tetahi huānga me hoki tonu [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // anake i tīpoka `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Whakahoki ai i te `n`th huanga o te whiti.
    ///
    /// Ka rite ki te nuinga o ngā mahi fakahokohoko, tīmata te tatau i te kore, na hoki `nth(0)` te uara tuatahi, `nth(1)` te tuarua, a na i runga i.
    ///
    /// Note e huānga mua katoa, me te te huānga hoki, ka kia pau i te iterator.
    /// Ko te tikanga e ka makaia nga mea timatanga mua, me e karanga `nth(0)` wa maha i runga i te iterator taua ka hoki ano huānga rerekē.
    ///
    ///
    /// `nth()` ka hoki mai [`None`] ki te mea nui atu rite ki te roa o te iterator ranei `n`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Ko te karanga i te `nth()` i nga wa maha kaore i te huri i te kaitohu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Hoki mai `None` ki reira he iti iho i te huānga `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Ka waihanga te iterator tīmata i te wāhi kotahi, engari te takahi i te nui homai i ia tātaitanga tāruarua.
    ///
    /// Note 1: Ko te āhuatanga tuatahi o te iterator ka tonu e hoki mai, ahakoa o te taahiraa i homai.
    ///
    /// Note 2: Ko te wa i ai e unuhia huānga waihotia e kore te whakaritea.
    /// `StepBy` he rite ki te raupapa `next(), nth(step-1), nth(step-1),…`, engari he waatea ano hoki ki te whanonga penei i te raupapa
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// E ara te whakamahia kia huri hoki te tahi mau iterators mō take mahi.
    /// Ko te huarahi tuarua ka haere whakamua te whiti i mua atu ka pau pea i nga taonga.
    ///
    /// `advance_n_and_return_first` he ōritenga o:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Ko te tikanga ka panic ki ko `0` te taahiraa i homai.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// E rua nga hikoi ka hangaia he miihini hou i runga i nga waahanga e rua.
    ///
    /// `chain()` ka whakahoki mai i te iterator hou ka tiimata i nga uara mai i te tuatahi i muri ka pa ki nga uara mai i te tuarua o te iterator.
    ///
    /// I etahi atu kupu, e honohono ana i nga iterator e rua, i roto i te mekameka.🔗
    ///
    /// [`once`] he whakamahinga hei whakamahi i te uara kotahi ki te mekameka o etahi atu momo taarua.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mai whakamahi te tautohe ki `chain()` [`IntoIterator`], ka taea e tatou haere tetahi e taea te tahuri ki te [`Iterator`], e kore noa he [`Iterator`] iho.
    /// Hei tauira, poro (`&[T]`) whakatinana [`IntoIterator`], a ka taea te tuku tika ki te `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ki te mahi koe ki Windows API, kia hiahia koe ki te tahuri [`OsStr`] ki `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips ake' e rua iterators ki te iterator kotahi o takirua.
    ///
    /// `zip()` ka whakahoki i te whitiera hou ka toro i etahi atu iterator, ka whakahoki i te tuple ka ahu mai te timatanga tuatahi mai i te tuatahi, a ko te tuarua ka ahu mai i te tuarua o te taarua.
    ///
    ///
    /// I etahi atu kupu, ka tohatohahia e ia nga miihini e rua, ki te kotahi.
    ///
    /// Ki te rānei hoki iterator [`None`], [`next`] i te kōtui ka hoki iterator [`None`].
    /// Ki te hoki te iterator tuatahi [`None`], ka poto-iahiko me `next` ka kore e huaina `zip` i te rua o nga iterator.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mai whakamahi te tautohe ki `zip()` [`IntoIterator`], ka taea e tatou haere tetahi e taea te tahuri ki te [`Iterator`], e kore noa he [`Iterator`] iho.
    /// Hei tauira, poro (`&[T]`) whakatinana [`IntoIterator`], a ka taea te tuku tika ki te `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` Kei te maha whakamahia ki te kōtui i te iterator mure ore ki te tetahi fakataimí.
    /// Tenei mahi no te mea te tahuti nei iku iterator ka hoki [`None`], mutu te kumemau.Kakati ki `(0..)` taea te titiro i te rota rite [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Ka waihanga te iterator hou e tuu te kape o `separator` i waenganui i ngā tūemi pātata o te iterator taketake.
    ///
    /// I roto i te take e kore e `separator` whakatinana [`Clone`] hiahia ki te kia computed wa katoa ranei, te whakamahi i [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Ko te waahanga tuatahi mai i `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ko te whakawehe.
    /// assert_eq!(a.next(), Some(&1));   // Ko te waahanga e whai ake nei mai i `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ko te whakawehe.
    /// assert_eq!(a.next(), Some(&2));   // Ko te waahanga whakamutunga mai i `a`.
    /// assert_eq!(a.next(), None);       // Kua oti te whiti.
    /// ```
    ///
    /// `intersperse` he pai rawa ki te hono ki nga taonga a te kaitohu ma te whakamahi i te waahanga noa:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Ka waihanga te iterator hou e tuu te tūemi i hanga e `separator` i waenganui i ngā tūemi pātata o te iterator taketake.
    ///
    /// Ka te katinga e huaina rite kotahi i ia wa whakanohoia he tūemi te waenganui i rua ngā tūemi pātata i te iterator whakakaupapa;
    /// āta, e kore e karangatia e te katinga ki te loto iterator whāriki iti iho i te rua ngā tūemi me i muri i te tūemi whakamutunga tuku te.
    ///
    ///
    /// Mena ka whakatinanahia e te taputapu o te miihini te [`Clone`], ka maama ake pea te whakamahi i te [`intersperse`].
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Ko te waahanga tuatahi mai i `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ko te whakawehe.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Ko te waahanga e whai ake nei mai i `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ko te whakawehe.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Ko te waahanga whakamutunga mai i `v`.
    /// assert_eq!(it.next(), None);               // Kua oti te whiti.
    /// ```
    ///
    /// `intersperse_with` Ka taea te whakamahi i roto i ngā āhuatanga i reira me te whakawehe ki te kia computed:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Ko te katinga mutably tikina tona horopaki ki te whakaputa i te tūemi.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Ka katia ka hangaia he miihini karanga e kiia ana he katinga mo ia waahanga.
    ///
    /// `map()` liliu tetahi iterator ki tetahi, na te tikanga o tona tautohe:
    /// tetahi mea e whakamahi ana i te [`FnMut`].Ka whakaputahia he iterator hou e kiia ana ko tenei katinga mo ia waahanga o te tiimana ake.
    ///
    /// Mena he pai o whakaaro ki nga momo, ka taea e koe te whakaaro mo te `map()` penei:
    /// Ki te whai koe i te iterator e homai e koe ngā āhuatanga o etahi momo `A`, a ka hiahia koe te iterator o etahi atu momo `B`, ka taea e koe te whakamahi i `map()`, haere he katinga e tango he `A` me hoki he `B`.
    ///
    ///
    /// `map()` he orite te whakaaro ki te koropiko [`for`].Heoi, ka rite ki `map()` he mangere, Kei te pai whakamahia reira ina e kua koutou mahi ki ētahi atu iterators.
    /// Ki te e mahi i koe etahi ahua o koropiko ana hoki te pānga taha, ngā whakaaro reira atu rerenga ki te whakamahi i [`for`] atu `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ki te e mahi i koe etahi ahua o pānga taha, hiahia [`for`] ki `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // kaua e mahi i tenei:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // kaore e mahia, na te mea he mangere.Ma te Rust koe e whakatupato.
    ///
    /// // Engari, whakamahia mo:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Waea te kati i runga i ia huānga o te iterator.
    ///
    /// He ōrite ki te whakamahi i te koropiko [`for`] i runga i te iterator tenei, ahakoa kahore e taea `break` me `continue` i te katinga.
    /// He tikanga noa ake te whakaaro ki te whakamahi i te koropiko `for`, engari ka marama ake pea te `for_each` i te wa e tukatuka ana i nga taonga i te mutunga o nga mekameka iterator roa.
    ///
    /// I roto i ētahi wā kia hoki kia `for_each` tere atu i te koropiko, no te mea ka whakamahi i te reira whitiauau ā-i runga i whāurutau rite `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Mo tetahi tauira iti, ko te koropiko `for` pea ka maamaa, engari ko `for_each` te mea pai ki te pupuri i tetahi momo taera me nga kaitahuri roa:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Ka waihanga te iterator e whakamahi ana i te katinga ki te whakatau, ki te kia tuku te huānga.
    ///
    /// Homai he huānga te katinga me hoki `true` `false` ranei.Ko te hoki ka tukua anake iterator te āhuatanga mō nei hoki pono te katinga.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// No te mea te katinga haere ki `filter()` e te tohutoro, a he maha iterators tukurua runga tohutoro, tenei ahu ki te āhuatanga puputu'u pea, i reira te momo o te katinga ko te tohutoro rua:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // Me rua * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// noa o te reira ki hei utu whakamahi destructuring i runga i te tautohe ki te muru i atu kotahi:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // rua&me *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ranei e rua:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // rua &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// o enei paparanga.
    ///
    /// Kia mōhio e he ōrite ki `iter.find(f)` `iter.filter(f).next()`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Ka waihanga te iterator e rua whiriwhiringa me mahere.
    ///
    /// Ko te hoki hua iterator anake te `value`s mo e hoki te katinga tukuna `Some(value)`.
    ///
    /// `filter_map` ka taea te whakamahi kia poto ai nga mekameka o [`filter`] me [`map`].
    /// Ko te tauira i raro nei whakaaturanga pehea e taea te poroa te `map().filter().map()` ki te karanga kotahi ki `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tenei te te tauira kotahi, engari ki [`filter`] me [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Ka waihangahia he taarua e homai ana i te tatauranga tatai o naianei me te uara e whai ake nei.
    ///
    /// Ko te miihini i whakahoki i nga hua takirua `(i, val)`, kei hea te `i` te taurangi o te whitiauau me `val` te uara i whakahokia mai e te kaituku.
    ///
    ///
    /// `enumerate()` e pupuri ana i tona tatau rite te [`usize`].
    /// Ki te hiahia koe ki te tatau i te tau tōpū rerekē rahi, whakarato te mahi [`zip`] rite taumahinga.
    ///
    /// # Whanonga Kaha
    ///
    /// Ko te tikanga e kore e tiaki ki waipuke, na Te Tatau neke atu i ngā huānga [`usize::MAX`] rānei hua te hua he panics ranei.
    /// Ki te whakahohea tāpaetanga patuiro, whai he panic te.
    ///
    /// # Panics
    ///
    /// Ka taea pea e te kaitahuri te whakahoki mai i te panic mena ka huri te taupū-ki-te whakahoki mai he [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Ka waihanga te iterator e taea te whakamahi i [`peek`] ki titiro i te huānga muri o te iterator kahore e kai ana i te reira.
    ///
    /// Ka taapirihia he tikanga [`peek`] ki te kaitahuri.Tirohia ona tuhinga mo te roanga atu o nga korero.
    ///
    /// Kia mahara kei te haere tonu te whiti i raro i te wa e karangahia ana a [`peek`] mo te wa tuatahi: Hei tiki i te waahanga e whai ake nei, ka karangahia a [`next`] mo te whiti, na reira ka puta he awangawanga (arā
    ///
    /// tetahi mea ke atu i te tango i te uara e whai ake nei) o te tikanga [`next`] ka puta.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() kia kite tatou i roto i te future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // ka taea e taatau te peek() i nga wa maha, kaore e haere whakamua te whiti
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // i muri i oti te iterator te, pera ko peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Ka waihanga te iterator e hāngai [`skip`] s āhuatanga i runga i te paparangi.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` ka kati hei tautohe.Ka karanga te reira i tenei katinga i runga i ia huānga o te iterator, ka wareware huānga tae noa hoki reira `false`.
    ///
    /// I muri hoki `false` te, ko runga `skip_while()`'s mahi, me te toenga o te huānga e tuku.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// No te mea te katinga haere ki `skip_while()` e te tohutoro, a he maha iterators tukurua runga tohutoro, tenei ahu ki te āhuatanga puputu'u pea, i reira te momo o te tautohe katinga ko te tohutoro rua:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // Me rua * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Me tu i muri o te `false` tuatahi:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // i e tenei kua teka, mai ka kua tatou i te teka, e kore te skip_while() whakamahia a muri ake nei
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Ka waihanga te iterator e hāngai loto āhuatanga i runga i te paparangi.
    ///
    /// `take_while()` ka kati hei tautohe.Ka karanga te reira i tenei katinga i runga i ia huānga o te iterator, ka tukua ngā āhuatanga i hoki reira `true`.
    ///
    /// I muri hoki `false` te, ko runga `take_while()`'s mahi, me te toenga o te huānga e waihotia.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Na te mea kua katia te katinga ki `take_while()` he tohutoro, a he maha nga kaitukino e korero ana mo nga tohutoro, ka ahu mai tenei ki tetahi ahuatanga raruraru pea, kei hea te momo o te katinga e rua nga korero.
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // Me rua * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Me tu i muri o te `false` tuatahi:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // He maha ake o taatau waahanga he iti ake i te kore, engari mai i te mea kua he taatau, kaore te take_while() e whakamahia ana
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// No te mea Me `take_while()` ki te titiro i te uara i roto i te tikanga ki te kite, ki te kia whakaurua reira e kore ranei, e kai ana, ka kite iterators e te nekehia atu ai:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Kua kore te `3` i reira, na te mea i pau kia kite ai mena me mutu te whaikorero, engari kaore i whakahokia ki roto.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Ka waihangahia he tautuhi ka whakaputa i nga waahanga e rua i runga i te tohu me te mapi.
    ///
    /// `map_while()` ka kati hei tautohe.
    /// Ka karanga te reira i tenei katinga i runga i ia huānga o te iterator, ka tukua ngā āhuatanga i hoki reira [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tenei te te tauira kotahi, engari ki [`take_while`] me [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// E tū i muri i te [`None`] tuatahi:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // E tatou atu huānga e taea e pai i roto i u32 (4, 5), engari hoki `map_while` `None` mo `-3` (rite te `predicate` hoki `None`) me mutu `collect` i tūpono te `None` tuatahi.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Na te mea me titiro te `map_while()` ki te uara kia kite mena ka whakauruhia kaore ranei, ka mohio te kaituku kua nekehia atu:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// he kore i reira te `-3`, no te mea i pau te reira i roto i te tikanga ki te kite, ki te kia mutu te whitiauau, engari kihai i whakanohoia hoki ki te iterator.
    ///
    /// Kia mahara kaore i rite ki te [`take_while`] tenei kaituku **kaore** i whakahiatohia.
    /// Kaore ano hoki i te tohuhia he aha te whakahoki mai a tenei kaituri i muri i te hokinga mai o te [`None`] tuatahi.
    /// Ki te titauhia tauta koe iterator, te whakamahi i [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Ka waihanga te iterator e kua peke te āhuatanga tuatahi `n`.
    ///
    /// I muri kua ratou poto, te toenga o nga mea timatanga e tuku.
    /// Tena ki te takahi tika i tenei tikanga, kaua hei takahi i te tikanga `nth`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Ka waihangahia he taarua e whakaputa ana i ona waahanga `n` tuatahi.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` Kei te maha whakamahia ki te iterator mure ore, ki te hanga i fakataimí reira:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mena he iti ake i te `n` nga waahanga e waatea ana, ka tukuna e `take` a ia ano ki te rahinga o te kaituku takirua:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// He miihini whakamaarama he rite ki te [`fold`] e mau ana i te ahua o roto me te whakaputa i tetahi miihini hou.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` e rua ngā tohenga: he uara tuatahi i purapura te āhua ā-, me te katinga ki e rua ngā tohenga, te tuatahi he tohutoro mutable ki te āhua ā-me te tuarua he huānga iterator.
    ///
    /// Ka taea e te katinga tautapa ki te āhua ā-ki share kāwanatanga i waenganui i tāruarua.
    ///
    /// I runga i te whakahuri, ka whakamahia te katinga ki ia waahanga o te miihini me te uara whakahoki mai i te katinga, he [`Option`], ka tukuna e te miihini.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // ia whitiauau, ka tini tatou te āhua i te huānga
    ///     *state = *state * x;
    ///
    ///     // Na, ka tukua e matou i te whakakorehanga o te kāwanatanga
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Ka waihanga te iterator e mahi rite mahere, engari tarere hanganga whakautu.
    ///
    /// Ko te tino whai hua te whāurutau [`map`], engari anake ka hua te tautohe katinga uara.
    /// Ki te hua i te reira i te iterator hei utu, i reira te he paparanga anō o indirection.
    /// `flat_map()` ka tango i tenei paparanga anō i runga i ona ake.
    ///
    /// Ka taea e koe te whakaaro o `flat_map(f)` rite te ōrite pū o [`map`] ping, a ka [`flatten`] raa rite i roto i `map(f).flatten()`.
    ///
    /// Ko tetahi atu whakaaro mo te `flat_map()`: Ko te katinga o te "map`] ka whakahoki i tetahi mea mo ia waahanga, a ko te katinga `flat_map()`'s ka whakahoki ano i tetahi waahanga mo ia waahanga.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() hoki te iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Ka waihangahia he miihini whakaheke i te hanganga kohanga.
    ///
    /// Ko te pai tenei ina whai koe te iterator o iterators ranei te iterator o mea e taea te tahuri ki iterators me te hiahia koe ki te tango i tetahi taumata o indirection.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mahere a ka flattening:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() hoki te iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Ka taea hoki e koe te tuhituhi anō i tenei i roto i ngā o [`flat_map()`], i te mea pai i roto i tenei take mai horoa te reira atu mana'o mārama:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() hoki te iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening tango anake kotahi taumata o hanga kohanga i te wa:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Tenei kite tatou e kore e `flatten()` mahi i te whakaparaha "deep".
    /// Engari, nekehia kotahi anake taumata o kōhanga te.Ko, ki te `flatten()` koe he ngohi e toru-ahu, ka waiho-ahu rua me kore tetahi-ahu te hua.
    /// Ki te tiki i te hanganga kotahi-ahu, whai ano koe ki `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Ka hangaia he miihini ka mutu i muri o te [`None`] tuatahi.
    ///
    /// I muri i te iterator hoki [`None`], waea future kia ranei kia kore e tukua ano [`Some(T)`].
    /// `fuse()` faa'aano he iterator, te whakarite e i muri i homai he [`None`] te, ka hoki tonu te reira [`None`] ake ake.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // he kaituku e whakawhiti ana i waenga i etahi me te Kore
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // mena he ara, Some(i32), kaare Kare
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // ka taea e taatau te kite i te kaitahuri e hoki whakamuri ana
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Heoi, kotahi e nunumi ana matou i te reira ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ka hoki mai ano `None` i muri i te wa tuatahi.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// E te tahi mea ki ia huānga o te iterator, haere i te uara i runga i.
    ///
    /// A, no te whakamahi i iterators, ka maha herea koutou te maha o ratou tahi.
    /// I te mahi i runga i taua waehere, ai e hiahia ana koe ki te tirohia i roto i te mea te tupu i nga wahi ngā i roto i te paipa.Ki te mahi i taua, kōkuhu he karanga ki `inspect()`.
    ///
    /// Ko te atu noa mō te `inspect()` ki te whakamahi rite te taputapu patuiro atu ki te tīariari i roto i to koutou waehere whakamutunga, engari kia kitea tono whai hua te reira i roto i etahi āhuatanga ina hiahia hapa kia takiuru ki te aroaro o te whiua.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // Ko te matatini tenei raupapa iterator.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // kia a tāpiri te tahi mau piiraa inspect() ki te tirotiro he aha te memeha
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Ka taia tenei:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Te takiuru hapa i mua i whakareretanga ratou:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Ka taia tenei:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Te tikina ano he iterator, kaua ki te kai i te reira.
    ///
    /// He pai ki te tukua te tono iterator whāurutau te pupuri tonu te mana o te iterator taketake tenei.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ki te tamata tatou ki te whakamahi i ano te ara, e kore e mahi i te reira.
    /// // Ko te raarangi e whai ake nei ka "hapa: te whakamahi i te uara neke: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // kia ngana e ano o
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // hei utu, tāpiri tatou i roto i te .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // inaianei he pai tika tenei:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Ka huri i te kaitahuri hei kohinga.
    ///
    /// `collect()` Ka taea e te tango tetahi mea iterable, a tahuri ai ki te kohinga e hāngai ana.
    /// Tenei Ko tetahi o nga tikanga atu kaha i roto i te whare pukapuka paerewa, whakamahia i roto i te whānuitanga o ngā horopaki.
    ///
    /// Ko te tauira tino nui e whakamahia ai te `collect()` ko te huri i tetahi kohinga ki tetahi atu.
    /// tango koe i te kohinga, karanga [`iter`] runga reira, te mahi i te paihere o panoni, a ka `collect()` i te mutunga.
    ///
    /// `collect()` ka taea hoki te hanga tauira o nga momo ehara i te kohinga angamaheni.
    /// Hei tauira, ka taea te hanga he [`String`] i [`char`] s, a taea te kohia he iterator o ngā tūemi [`Result<T, E>`][`Result`] ki `Result<Collection<T>, E>`.
    ///
    /// Tirohia te te tauira i raro nei mo ake.
    ///
    /// No te mea he pera whānui `collect()`, e taea ai te raruraru ki te momo hīkaro.
    /// Ka rite ki taua, `collect()` ko tetahi o nga wa torutoru ka kite koe i te wetereo e mōhio whānuitia rite te 'turbofish': `::<>`.
    /// E āwhina ana tēnei mahino te hātepe hīkaro āta nei kohinga e ngana ana koe ki te kohikohi ki.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Note e hiahiatia e matou te `: Vec<i32>` i te taha maui-ringa.Ko tenei no te mea i taea e tatou kohikohi ki, hei tauira, he [`VecDeque<T>`] hei utu:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Mā te whakamahi i te 'turbofish' hei utu o te whakakaupapa `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// No te mea `collect()` anake e mahara e pā ana ki te mea e kohikohi koe ki, tonu koe e taea te whakamahi i te momo tohu wāhanga, `_`, ki te turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Ma te `collect()` hei hanga i te [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Ki te whai koe i te rārangi o [`Hua<T, E>`][`Result`] s, ka taea e koe te whakamahi i `collect()` kia kite, ki te i taka tetahi o ratou:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // horo'a mai ia tatou i te hapa tuatahi
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // homai ki a matou te raarangi o nga whakautu
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Pau he iterator, te hanga rua kohikohinga i reira.
    ///
    /// Ko te paparangi haere ki `partition()` taea hoki `true`, `false` ranei.
    /// `partition()` whakahoki mai he takirua, nga waahanga katoa i whakahokia mai ai a `true`, me nga waahanga katoa i whakahokia mai ai a `false`.
    ///
    ///
    /// A hi'o hoki [`is_partitioned()`] me [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders nga āhuatanga o tenei iterator *i roto i-wahi* rite ki te paparangi homai, pērā e te hunga katoa e pahika atu ki mua hoki `true` te hunga katoa e hoki `false`.
    ///
    /// Returns kitea te maha o ngā huānga `true`.
    ///
    /// E kore e tonu te tikanga whanaunga o ngā tūemi roherohea.
    ///
    /// A hi'o hoki [`is_partitioned()`] me [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Wehewehenga i roto i-wahi i waenganui i evens me aroaro
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: me manukanuka taatau mo te tatauranga e kaha haere ana?Ko te huarahi anake kia nui ake i te
        // `usize::MAX` ko nga tohutoro ka taea te whakarereke me nga ZST, kaore e whai kiko ki te wehewehe ...

        // Ko enei mahi kati "factory" kei te noho ki te karo i te whanui i te `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Toutou kitea te `false` tuatahi me hurihia ngā reira ki te `true` whakamutunga.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Arowhai ki te nga mea timatanga o tenei e roherohea iterator rite ki te paparangi homai, pērā e te hunga katoa e pahika atu ki mua hoki `true` te hunga katoa e hoki `false`.
    ///
    ///
    /// Tirohia hoki [`partition()`] me [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Rānei ngā tūemi katoa whakamatautau `true`, ranei mutu te rarangi tuatahi i `false` me tirohia tatou e reira e kore ake `true` tūemi i muri i taua.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// He tikanga whakamaarama e hono ana i tetahi mahi mena e angitu ana te whakahoki mai, e whakaputa ana i te uara whakamutunga kotahi.
    ///
    /// `try_fold()` e rua ngā tohenga: he uara tuatahi, me te katinga ki e rua ngā tohenga: he 'accumulator', me he huānga.
    /// Ko te katinga rānei hoki pai te, ki te uara e kia whai i te accumulator mo te whitiauau muri, hoki reira kore, ki te uara hapa whakatipuria e te hoki ki te kaiwaea tonu (short-circuiting) ranei.
    ///
    ///
    /// Ko te uara tuatahi ko te uara ka whai te accumulator i runga i te karanga tuatahi.Ki te tono te katinga i muri ki nga huānga o te iterator, hoki `try_fold()` te accumulator whakamutunga rite angitu.
    ///
    /// He whai hua kotuinga wa e whai koe i te kohinga o te tahi mea, a ka hiahia ki te whakaputa i te uara kotahi i reira.
    ///
    /// # Tuhipoka ki Implementors
    ///
    /// E rave rahi o te tahi atu tikanga (forward) i implementations taunoa i roto i ngā o tenei tetahi, kia tamata ki te whakatinana i āta tenei ki te taea e te reira te tahi mea pai atu i te taunoa `for` whakatinanatanga koropiko.
    ///
    /// I roto i ngā, tamata ki te whai i tenei karanga `try_fold()` i runga i nga wahi ā i nei tito tenei iterator te.
    /// Mena he maha nga piiraa e hiahiatia ana, he pai pea ma te kaiwhakahaere `?` te mekameka i te uara kohikohi, engari kia tupato ki nga kaitautoko e tika ana kia mau i mua o te whakahoki wawe mai.
    /// Ko te tikanga `&mut self` tenei, na me whitiauau ki kia resumable i muri i patu i te hapa i konei.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // te moni takina o katoa o nga āhuatanga o te ngohi
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // ngawha ana tēnei moni ka tāpiri i te huānga 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // No te mea te reira poto-circuited, he wātea tonu te toe huānga i roto i te iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// He tikanga iterator e pā te mahi sipí ki ia tūemi i te iterator, tu i te hapa tuatahi, me te hoki mai i taua hapa.
    ///
    ///
    /// taea hoki te whakaaro tenei o rite te ahua sipí o [`for_each()`] rite te putanga stateless o [`try_fold()`] ranei.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Te reira i poto-circuited, na te toe tūemi kei tonu i roto i te iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Taiepa katoa huānga ki te accumulator mā te tono i tētahi mahi, e hoki ana i te hua whakamutunga.
    ///
    /// `fold()` e rua ngā tohenga: he uara tuatahi, me te katinga ki e rua ngā tohenga: he 'accumulator', me he huānga.
    /// Ko te katinga ka whakahoki i te uara me whiwhi te kaiwhakaputuputu mo te whaarua i muri mai.
    ///
    /// Ko te uara tuatahi ko te uara ka whai te accumulator i runga i te karanga tuatahi.
    ///
    /// I muri tono i tenei katinga ki nga huānga o te iterator, hoki `fold()` te accumulator.
    ///
    /// Kei te te tahi mau taime i huaina tenei mahi 'reduce' 'inject' ranei.
    ///
    /// He whai hua kotuinga wa e whai koe i te kohinga o te tahi mea, a ka hiahia ki te whakaputa i te uara kotahi i reira.
    ///
    /// Note: `fold()`, me nga tikanga pera e haerere ana i te whiti katoa, kaore pea e mutu mo nga kaitarai mutunga kore, tae atu ki te traits e taea ana te whakatau mo tetahi wa mutunga.
    ///
    /// Note: Ka taea te whakamahi [`reduce()`] ki te whakamahi i te huānga tuatahi rite te uara tuatahi, ki te ko te taua te momo accumulator me momo tūemi.
    ///
    /// # Tuhipoka ki Implementors
    ///
    /// E rave rahi o te tahi atu tikanga (forward) i implementations taunoa i roto i ngā o tenei tetahi, kia tamata ki te whakatinana i āta tenei ki te taea e te reira te tahi mea pai atu i te taunoa `for` whakatinanatanga koropiko.
    ///
    ///
    /// I roto i ngā, tamata ki te whai i tenei karanga `fold()` i runga i nga wahi ā i nei tito tenei iterator te.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // te moni o te katoa o nga āhuatanga o te ngohi
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// haere a Kia i roto i ia taahiraa o te whitiauau konei:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// A pera, to matou hua whakamutunga, `6`.
    ///
    /// He mea noa ma nga taangata kaore i tino whakamahi i nga miihini ki te whakamahi i te koropiko `for` me te raarangi o nga mea hei hanga i tetahi hua.Ka taea te huri hei `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // mō te koropiko:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // kei te taua ratou
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Ka whakaitihia nga waahanga ki te waahanga kotahi, ma te whakamahi i te mahi whakaiti i nga wa katoa.
    ///
    /// Mena he koretake te miihini, whakahoki [`None`];te kore, hoki te hua o te whakaiti.
    ///
    /// Hoki iterators ki te iti rawa kia kotahi huānga, ko te taua rite [`fold()`] ki te huānga tuatahi o te iterator rite te uara tuatahi, whakakopa nga huānga muri ki reira tenei.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Rapua te uara nui:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Whakamātautau ki te ōrite katoa huānga o te iterator te paparangi.
    ///
    /// `all()` e te katinga e hoki `true` `false` ranei.tano te reira i tenei katinga ki ia huānga o te iterator, a ki te hoki ratou katoa `true`, ka pera e `all()`.
    /// Ki te hoki mai tetahi o ratou `false`, hoki reira `false`.
    ///
    /// `all()` he porohita-poto;i roto i te kupu atu, ka mutu te reira te tukatuka, no te kitea e te reira he `false`, i homai e noa'tu te mea atu tupu, ka hoki te hua e `false`.
    ///
    ///
    /// hoki He iterator kau `true`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Ka tu i te `false` tuatahi:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // Ka taea e tonu tatou te whakamahi i `iter`, rite reira e nui ake huānga.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Whakamatautau mena ka haangai te waahanga o te whiti ki te takirua.
    ///
    /// `any()` e te katinga e hoki `true` `false` ranei.Ka pa ki tenei katinga ki ia waahanga o te miihini, a ki te hoki mai tetahi o `true`, ka pera ano te `any()`.
    /// Ki te hoki mai ratou katoa `false`, hoki reira `false`.
    ///
    /// `any()` He poto-circuiting;i roto i te kupu atu, ka mutu te reira te tukatuka, no te kitea e te reira he `true`, i homai e noa'tu te mea atu tupu, ka hoki te hua e `true`.
    ///
    ///
    /// hoki He iterator kau `false`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Me tu i te `true` tuatahi:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // Ka taea e tonu tatou te whakamahi i `iter`, rite reira e nui ake huānga.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Rapu mō te huānga o te iterator e makona i te paparangi.
    ///
    /// `find()` e te katinga e hoki `true` `false` ranei.
    /// tano te reira i tenei katinga ki ia huānga o te iterator, a ki te hoki tetahi o ratou `true`, ka hoki `find()` [`Some(element)`].
    /// Mena ka hoki mai raatau katoa `false`, ka hoki mai a [`None`].
    ///
    /// `find()` He poto-circuiting;i roto i te kupu atu, ka mutu te reira te tukatuka, no te te katinga hoki `true`.
    ///
    /// No te mea e `find()` te tohutoro, a he maha iterators tukurua runga tohutoro, tenei ahu ki te āhuatanga puputu'u pea te wahi i te tautohe ko te tohutoro rua.
    ///
    /// Ka kitea e koe tenei paanga ki nga tauira i raro ake nei, me te `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Me tu i te `true` tuatahi:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // Ka taea e tonu tatou te whakamahi i `iter`, rite reira e nui ake huānga.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Kia mōhio e he ōrite ki `iter.filter(f).next()` `iter.find(f)`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Ka hoatu mahi ki nga mea timatanga o iterator me hoki te hua kahore-kore tuatahi.
    ///
    ///
    /// `iter.find_map(f)` He ōrite ki `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Ka hoatu mahi ki nga mea timatanga o iterator me hoki te hua pono tuatahi te hapa tuatahi ranei.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Rapu mō te huānga i roto i te iterator, hoki mai tona taupū.
    ///
    /// `position()` e te katinga e hoki `true` `false` ranei.
    /// Ka pa ki tenei katinga ki ia waahanga o te miihini, ana ki te whakahoki mai tetahi i te `true`, na `position()` ka whakahoki [`Some(index)`].
    /// Mena ko ratou katoa ka hoki mai `false`, ka hoki mai a [`None`].
    ///
    /// `position()` He poto-circuiting;i roto i te kupu atu, ka mutu te reira te tukatuka, no te kitea e te reira he `true`.
    ///
    /// # Whanonga Kaha
    ///
    /// Kaore te tikanga e tiaki i nga rerenga wai, no reira mena he nui ake i te [`usize::MAX`] nga waahanga kaore e taurite ana, ka hua mai he hua he, he panics ranei.
    ///
    /// Ki te whakahohea tāpaetanga patuiro, whai he panic te.
    ///
    /// # Panics
    ///
    /// Tenei mahi kaha panic ki te iterator kua neke atu i te `usize::MAX` huānga ōrite-kore.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Me tu i te `true` tuatahi:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // Ka taea e tonu tatou te whakamahi i `iter`, rite reira e nui ake huānga.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Ko te taupū whakahoki ka whakawhirinaki ki te ahua iterator
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Rapu mō te huānga i roto i te iterator i te tika, e hoki tona taupū.
    ///
    /// `rposition()` e te katinga e hoki `true` `false` ranei.
    /// tano te reira i tenei katinga ki ia huānga o te iterator, timata i te mutunga, me te mea hoki tetahi o ratou `true`, ka hoki `rposition()` [`Some(index)`].
    ///
    /// Mena ko ratou katoa ka hoki mai `false`, ka hoki mai a [`None`].
    ///
    /// `rposition()` He poto-circuiting;i roto i te kupu atu, ka mutu te reira te tukatuka, no te kitea e te reira he `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Me tu i te `true` tuatahi:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // Ka taea e tonu tatou te whakamahi i `iter`, rite reira e nui ake huānga.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Kahore he take mo te waipuke tirohia konei, no te mea titau `ExactSizeIterator` e te maha o ngā huānga mö ki te `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Whakahokia te huānga mōrahi o te iterator.
    ///
    /// Mena he maha nga waahanga o te nuinga, ka whakahokia te waahanga whakamutunga.
    /// Ki te he kau te iterator, kua hoki mai [`None`].
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Whakahoki ai i te waahanga iti o te whiti.
    ///
    /// Ki te he rite iti e rave rahi āhuatanga, ka hoki te huānga tuatahi te.
    /// Ki te he kau te iterator, kua hoki mai [`None`].
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Whakahoki ai i te waahanga e homai ana i te uara nui mai i te mahinga kua tohua.
    ///
    ///
    /// Mena he maha nga waahanga o te nuinga, ka whakahokia te waahanga whakamutunga.
    /// Ki te he kau te iterator, kua hoki mai [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Hoki te huānga e homai te uara mōrahi ki te faatura ki te mahi whakarite whakaritea.
    ///
    ///
    /// Mena he maha nga waahanga o te nuinga, ka whakahokia te waahanga whakamutunga.
    /// Ki te he kau te iterator, kua hoki mai [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Whakahoki ai i te waahanga e homai ana i te uara iti rawa mai i te mahi kua tohua.
    ///
    ///
    /// Ki te he rite iti e rave rahi āhuatanga, ka hoki te huānga tuatahi te.
    /// Ki te he kau te iterator, kua hoki mai [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Hoki te huānga e homai te uara iti ki te faatura ki te mahi whakarite whakaritea.
    ///
    ///
    /// Ki te he rite iti e rave rahi āhuatanga, ka hoki te huānga tuatahi te.
    /// Ki te he kau te iterator, kua hoki mai [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Huri whakamuri aronga o te iterator.
    ///
    /// Ko te tikanga, tukurua iterators i mahue ki te matau.
    /// Whai muri i te whakamahinga o te `rev()`, ka tautokona e te kaitahuri i te taha matau ki te maui.
    ///
    /// Ko te taea noa tenei ki te he mutunga te iterator, na `rev()` anake mahi i runga i [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Tahuri ai te iterator o takirua ki te rua o ngā.
    ///
    /// `unzip()` pau i te iterator katoa o takirua, te whakaputa e rua nga kohinga: kotahi mai i nga waahanga maui o nga takirua, me tetahi mai i nga waahanga tika.
    ///
    ///
    /// Tenei mahi ko, i roto i etahi tikanga, te ritenga o [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Ka waihanga te iterator e kape katoa o ona āhuatanga.
    ///
    /// He mea whai hua tenei ka whai koe i te hiko i te `&T`, engari me neke atu i te `T`.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // Ko te taua rite .map(|&x| x) tāruatia
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Ka waihangahia he iterator e [`clone`] ana i ona waahanga katoa.
    ///
    /// He mea whai hua tenei ka whai koe i te hiko i te `&T`, engari me neke atu i te `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // Ko mōu te taua rite .map(|&x| x), hoki tau tōpū
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Tukuruatia te iterator oku taengata.
    ///
    /// Engari ki te tu i te [`None`], ka tiimata ano te tiimana, mai i te tiimata.Ka mutu ana ano, ka tiimata ano i te tiimatanga.Na ano.
    /// Na ano.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Tapeke nga āhuatanga o te iterator.
    ///
    /// Ka kawea ia huānga, tāpiri tahi ratou, a ka hoki te hua.
    ///
    /// Ka whakahokia mai e te miihini kore noa te uara kore o te momo.
    ///
    /// # Panics
    ///
    /// Ka waea ana ki te `sum()` me te momo integer tuatahi kei te whakahokia mai, ko tenei tikanga ka panic mena ka kaha te taatai me nga korero whakakore.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates mo te iterator katoa, nui nga āhuatanga katoa
    ///
    /// hoki He iterator kau nga tetahi uara o te momo.
    ///
    /// # Panics
    ///
    /// A, no te karanga `product()` me kei te hoki mai te momo tau tōpū i tahito ra, ka panic ki te e whakahohea tikanga nga purena tätaitanga me kīanga patuiro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ka whakataurite i nga waahanga o tenei [`Iterator`] me etahi atu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) whakataurite nga āhuatanga o tenei [`Iterator`] ki te hunga o tetahi ki te faatura ki te mahi whakarite whakaritea.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ka whakataurite i nga waahanga o tenei [`Iterator`] me etahi atu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) whakataurite nga āhuatanga o tenei [`Iterator`] ki te hunga o tetahi ki te faatura ki te mahi whakarite whakaritea.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Whakatau ki te e rite ana ki te hunga o tetahi atu nga mea timatanga o tenei [`Iterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Ka whakatau mena ko nga waahanga o tenei [`Iterator`] he orite ki era o tetahi atu mo te mahi taurite kua tohua.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Whakatau ki te e taurite ki te hunga o tetahi atu nga mea timatanga o tenei [`Iterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Whakatau ki te nga mea timatanga o tenei [`Iterator`] he iti iho i te hunga o tetahi atu [lexicographically](Ord#lexicographical-comparison).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Whakatau ki te ko nga mea timatanga o tenei [`Iterator`] rite ki te hunga o tetahi [lexicographically](Ord#lexicographical-comparison) iti iho ranei.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Whakatau ki te ko nga mea timatanga o tenei [`Iterator`] [lexicographically](Ord#lexicographical-comparison) nui atu i te hunga o tetahi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Whakatau ki te ko nga mea timatanga o tenei [`Iterator`] [lexicographically](Ord#lexicographical-comparison) nui atu rite ki te hunga o tetahi atu ranei.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Ka tirohia mena ka tohatohahia nga waahanga o te whiti
    ///
    /// Ko, hoki ia huānga `a` me tona huānga e whai ake nei `b`, me mau `a <= b`.Mena ka rite te kore o te hua o te whiti, kotahi ranei te huanga, ka whakahokia mai a `true`.
    ///
    /// Note e ki ko `Self::Item` `PartialOrd` anake, engari e kore e `Ord`, titau te whakamāramatanga i runga e hoki tenei mahi `false` ki te kore e rite tetahi rua tūemi karapīpiti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Arowhai ki te e kōmaka nga mea timatanga o tenei iterator te whakamahi i te mahi comparator homai.
    ///
    /// Engari o te whakamahi i `PartialOrd::partial_cmp`, whakamahia e tenei mahi i te mahi i homai `compare` ki te whakatau i te tikanga o ngā huānga e rua.
    /// I tua atu i tera, he rite ki te [`is_sorted`];tirohia ana tuhinga mo etahi atu korero.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Arowhai ki te e kōmaka nga mea timatanga o tenei iterator te whakamahi i te mahi tangohanga matua hoatu.
    ///
    /// Engari o te whakatairite tika huānga o te iterator, whakataurite tenei mahi te mau taviri o te huānga, rite whakaritea e `f`.
    /// I tua atu i tera, he rite ki te [`is_sorted`];tirohia ana tuhinga mo etahi atu korero.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Hi'o [TrustedRandomAccess]
    // Ko te ingoa rereke ko te karo i nga tukinga ingoa ki te whakatau tikanga tirohia te #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}