//! Whakawhitihia i waho
//!
//! Mena kua kitea e koe he kohinga o nga momo momo, me mahi koe i runga i nga waahanga o taua kohinga, ka tere rere koe ki te 'iterators'.
//! Kei te kaha Iterators whakamahia i roto i te waehere Rust rerenga, na hoko maheni ki a ratou o reira utu.
//!
//! I mua i te whakamārama i atu, kia a korero e pā ana ki te āhua o te hanganga tenei kōwae te:
//!
//! # Organization
//!
//! Ko tenei waahanga he mea whakarite ma te momo:
//!
//! * [Traits] Ko te wahi matua: enei traits tautuhi he aha te ahua o iterators tīariari me aha koe e taea te mahi ki a ratou.Ko te tikanga o enei traits e utu maka ana etahi wa ako anō ki.
//! * [Functions] whakarato tahi mau rave'a āwhina ki te hanga i te tahi mau iterators taketake.
//! * [Structs] Ko maha nga momo hoki o nga tikanga ngā i runga i traits o tenei kōwae.Ka te tikanga e hiahia ana koe ki te titiro i te tikanga e hangaia e te `struct`, nui atu i te `struct` iho.
//! Mo te roanga atu o nga korero mo te take, tirohia te '[Implementing Iterator](#implementing-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Ko te reira!keri a Kia ki iterators.
//!
//! # Iterator
//!
//! Ko te ngakau, me te wairua o tenei kōwae ko te [`Iterator`] trait.Ko te ahua o te [`Iterator`] penei:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! He He iterator he tikanga, [`next`], e ka huaina, hoki he [`Option`]`<Item>`.
//! [`next`] ka hoki mai [`Some(Item)`] rite te roa rite reira he āhuatanga, me kua kua pau kotahi ratou katoa, ka hoki mai `None` ki tohu e oti te whitiauau.
//! Ka kowhiria e nga taatai takitahi te whakaora ano, na ko te karanga ano i te [`next`] ka kore pea ka tiimata te whakahoki mai i te [`Some(Item)`] i etahi waa (hei tauira, tirohia te [`TryIter`]).
//!
//!
//! Ko te whakamaarama katoa [Iterator`] he maha atu ano nga tikanga, engari he tikanga taunoa, hangaia i runga ake o [`next`], no reira ka riro ma te koreutu e tuku.
//!
//! Ko Iterators hoki composable, a a reira noa ki te mekameka ratou tahi ki te mahi i ngā momo matatini ake o tukatuka.Tirohia te waahanga [Adapters](#adapters) i raro ake nei mo nga korero taipitopito.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Nga momo e toru o te whaarua
//!
//! E toru nga tikanga noa e taea te waihanga iterators i te kohinga:
//!
//! * `iter()`, e iterates runga `&T`.
//! * `iter_mut()`, ka utua i te `&mut T`.
//! * `into_iter()`, e iterates runga `T`.
//!
//! mea Various i roto i te whare pukapuka paerewa kia whakatinana tetahi atu o te toru, te wahi e tika ana ranei.
//!
//! # Te Whakatinana i te Iterator
//!
//! Ko te hanga i taau ake taapiri e rua nga waahanga: te hanga i te `struct` hei pupuri i te kaitautoko, ka whakamahi i te [`Iterator`] mo taua `struct`.
//! Tenei he aha i reira e pera maha, struct`s i roto i tenei kōwae: i reira ko tetahi hoki ia iterator me iterator whāurutau.
//!
//! Me hanga he miihini ingoa `Counter` ka kiia mai i `1` ki `5`:
//!
//! ```
//! // Tuatahi, ko te struct:
//!
//! /// He kaituku hiko e kiia ana mai i te kotahi ki te rima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // e hiahia ana matou i to tatou tatau ki te tīmata i te kotahi, pera kia a tāpiri he tikanga new() ki te tauturu.
//! // Ehara tenei i te mea tino tika, engari he waatea.
//! // Note e tīmata tatou `count` i kore, ka kite tatou i te aha i roto i `next()`'s whakatinanatanga i raro.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Na, whakatinana tatou `Iterator` mo to tatou `Counter`:
//!
//! impl Iterator for Counter {
//!     // ka waiho tatou tatau ki usize
//!     type Item = usize;
//!
//!     // next() Ko te tikanga anake e hiahiatia ana
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Whakanuia taatau kaute.Ko tenei he aha tatou i tīmata i te kore.
//!         self.count += 1;
//!
//!         // Tirohia ki te kite, ki te ua tatou oti tatau e kore ranei.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Na inaianei e taea tatou te whakamahi i te reira!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Ka karangatia hoki e [`next`] whiwhi auau tenei ara.Rust kua he mea hangä e taea karanga [`next`] runga i tou iterator, tae noa ki tae te reira `None`.Kia haere a ki runga ki e muri.
//!
//! mōhio hoki e whakarato ana `Iterator` he whakatinanatanga taunoa o ngā tikanga pērā i `nth` me `fold` e karanga `next` ä.
//! Heoi, ka taea ano hoki te tuhi i te whakatinana ritenga o nga tikanga penei i te `nth` me te `fold` mena ka taea e te kaitahuri te whakatau tika i a raatau me te kore e karanga i te `next`.
//!
//! # `for` koropiko me `IntoIterator`
//!
//! Ko te mau `for` koropiko wetereo o Rust huka mō iterators.Tenei te he tauira taketake o `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Tenei ka tā i te tetahi tau i roto i rima, ia i runga i to ratou ake raina.Ko ka kite koutou i te tahi mea i konei: e kore matou ka karanga tetahi i runga i to tatou vector ki te whakaputa i te iterator.He aha homai?
//!
//! He te te trait i te whare pukapuka paerewa mō te tahuri te tahi mea ki te iterator: [`IntoIterator`].
//! Tenei trait kua kotahi tikanga, [`into_iter`], e faafariu te mea whakatinana i [`IntoIterator`] ki te iterator.
//! tangohia Kia o te titiro i taua `for` koropiko ano, me aha nga kau ului e taupatupatu ai ki:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-huka tenei ki:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Tuatahi, ka karanga matou i te `into_iter()` i runga i te uara.Na, ōrite tatou i runga i te iterator e hoki, karanga [`next`] mo a mo tae noa kite tatou i te `None`.
//! I tera wa, ka tukuna atu e matou te `break` mai i te koropiko, a ka mutu taatau.
//!
//! He te kotahi moka mohio atu i konei: kei te whare pukapuka paerewa te whakatinanatanga ngā o [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! I etahi atu, ko nga [`Iterator`] katoa ka whakatinana i te [`IntoIterator`], ma te hoki noa mai ano.E rua nga tikanga o tenei:
//!
//! 1. Ki te e tuhituhi koe i te [`Iterator`], ka taea e koe te whakamahi i te reira ki te koropiko `for`.
//! 2. Ki te kei te hanga koe i te kohinga, te whakatinana [`IntoIterator`] hoki e tukua reira koutou kohinga ki te whakamahi ki te koropiko `for`.
//!
//! # Iterating i te tohutoro
//!
//! Mai e [`into_iter()`] `self` i uara, te whakamahi i te koropiko `for` ki tukurua i runga i te pau kohinga e kohikohinga.I te nuinga o nga wa, ka hiahia pea koe ki te tirotiro i nga kohinga kaore e pau i a koe.
//! He maha nga kohinga e toha ana i nga tikanga hei whakarato iterator mo nga tohutoro, e kiia ana ko te `iter()` me te `iter_mut()`.
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` kei tenei rangatira tonu tenei mahi.
//! ```
//!
//! Mena he momo kohinga `C` e whakarato ana i te `iter()`, ko te tikanga ka whakamahia te `IntoIterator` mo te `&C`, me te whakatinanatanga ka karanga noa ko `iter()`.
//! Waihoki, ko te kohinga `C` e whakarato ana i te `iter_mut()` te tikanga o te whakamahi i te `IntoIterator` mo te `&mut C` ma te tuku atu ki te `iter_mut()`.Tenei ka taea te takinga watea:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // he rite ki te `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // taua rite `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Ahakoa he maha nga kohinga e tuku ana i te `iter()`, kaore katoa i te tuku `iter_mut()`.
//! Hei tauira, mutating te mau taviri o te [`HashSet<T>`] [`HashMap<K, V>`] ranei i taea e hoatu i te kohinga ki te āhua maiorooro ki te Hashes te kī huringa, kia enei kohikohinga whakahere `iter()` anake.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Ko nga mahi e tangohia ana i te [`Iterator`] ka whakahoki i tetahi atu [`Iterator`] e kiia ana he 'aderator iterator', na te mea ko te ahua o te 'adapter
//! pattern'.
//!
//! whāurutau iterator Common ngā [`map`], [`take`], ko [`filter`].
//! Hoki atu, e kite ratou tuhinga.
//!
//! Mena he urutau Iterator panics, ka noho te kaitahuri i roto i te waahanga kaore i tohua (engari he maumahara)
//! Tenei kāwanatanga e kore e hoki te whai ki te noho i te taua puta noa putanga o Rust, kia kia karo koe whakawhirinaki i runga i te uara tangohia hoki e te iterator i ri'ari'a.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (a ko te iterator [adapters](#adapters)) he *mangere*. Ko te tikanga ko te hanga noa i te miihini kaore i te _do_ katoa. Kaore he mea e tupu kia karanga ra koe [`next`].
//! Ko te ētahi wā tenei he puna o te whakama, ina hanga he iterator anake mo ona pānga taha.
//! Hei tauira, e karanga te tikanga [`map`] te katinga i runga i ia huānga iterates reira ki runga:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Tenei e kore e taia he uara, rite tatou i hanga anake te iterator, nui atu i te whakamahi i te reira.Ka whakatupato mai te kaiwhakamaherehere mo tenei momo whanonga:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Ko te ara rerenga ki te tuhituhi i te [`map`] mo ona pānga taha ko ki te whakamahi i te koropiko `for` karanga te tikanga [`for_each`] ranei:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Ko tetahi atu huarahi ki te aromatawai i te miihini ko te whakamahi i te tikanga [`collect`] ki te whakaputa kohinga hou.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! e kore Iterators e whai ki te kia tahuti.Hei tauira, ko te awhe tuwhera-mutunga he kaiwhakauru mutunga kore:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Ko reira noa ki te whakamahi i te iterator whāurutau [`take`] ki te tahuri i te iterator mure ore ki te kotahi fakataimí:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Tenei ka tā i te tau `0` roto `4`, ia i runga i to ratou ake raina.
//!
//! Kia mahara ko nga tikanga mo nga miihini mutunga kore, ara ko nga hua ka taea te whakatau mo te pangarau i te waa mutunga, kaore pea e mutu.
//! Tüturu, tikanga pērā i [`min`], i roto i te take whānui rapua e kopikopiko tonu nga huānga i roto i te iterator, he pea e kore ki te hoki mai pai mo tetahi iterators mure ore.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Aue kahore!He koropiko mutunga kore!
//! // `ones.min()` ai te koropiko mure ore, na e kore matou e tae tenei wāhi!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;