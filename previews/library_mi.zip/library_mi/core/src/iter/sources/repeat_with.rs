use crate::iter::{FusedIterator, TrustedLen};

/// Ka waihanga te iterator hou e tuaruatia āhuatanga o momo `A` hope na roto i te faaohiparaa i te katinga whakaratohia, te repeater, `F: FnMut() -> A`.
///
/// karanga te mahi `repeat_with()` te repeater mo a mo ano.
///
/// Kei te maha iterators Infinite rite `repeat_with()` whakamahia ki whāurutau rite [`Iterator::take()`], i roto i te tikanga ki te hanga fakataimí ratou.
///
/// Mena ko te momo waahanga o te miihini e hiahia ana koe ki te whakamahi i te [`Clone`], a he pai ki te waiho maumahara tonu te putake o te putake, me whakamahi e koe te mahi [`repeat()`].
///
///
/// Ko te huringa i hangaia e `repeat_with()` ehara i te [`DoubleEndedIterator`].
/// Mena ka hiahia koe ki te `repeat_with()` ki te whakahoki i te [`DoubleEndedIterator`], tena koa whakatuwherahia tetahi take GitHub e whakamarama ana i to keehi whakamahi.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::iter;
///
/// // kia a amo whai tatou i te tahi uara o te momo e kore te mea e `Clone` kore e nei hiahia ana ki te whai i roto i te mahara tika ano te mea he reira te utu ranei:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // he uara ake ake:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Te whakamahi i te whakarereketanga me te haere mutunga:
///
/// ```rust
/// use std::iter;
///
/// // Mai i te Teroto ki te tuatoru o nga mana e rua:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... a inaianei e mahi matou
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// He iterator e tuaruatia āhuatanga o momo `A` hope na roto i te faaohiparaa i te katinga whakaratohia `F: FnMut() -> A`.
///
///
/// Ko tenei `struct` na te mahi [`repeat_with()`] i hanga.
/// Tirohia ona tuhinga mo te roanga atu.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}