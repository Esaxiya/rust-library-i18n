use crate::iter::{FusedIterator, TrustedLen};

/// Ka waihanga te iterator e pai¬ko mahia he uara rite kotahi panga o te katinga whakaratohia.
///
/// Kei te whakamahia tenei ki te urutau te generator uara kotahi ki te [`chain()`] o ētahi atu momo o te whitiauau.
/// Pea to koutou he iterator e rakau tata katoa, engari e hiahia ana koe i te take motuhake anō.
/// Pea koe te mahi i mahi i runga i iterators, engari e hiahia ana anake koe ki te tukatuka kotahi uara.
///
/// Rerekē [`once()`], ka tenei mahi pai¬ko whakaputa i te uara i runga i te tono.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::iter;
///
/// // Ko tetahi te tau otahi
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // kotahi noa, koira noa taatau e whiwhi ai
/// assert_eq!(None, one.next());
/// ```
///
/// Te mekameka tahi me tetahi atu kaituku.
/// Kia mea a e hiahia ana tatou ki te tukurua i runga i ia kōnae o te whaiaronga `.foo`, engari ano hoki i te kōnae whirihoranga,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // Me tatou ki te tahuri i te iterator o DirEntry-s ki te iterator o PathBufs, na whakamahi tatou mahere
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // inaianei, ko ta maatau kaitohu mo ta maatau konae whirihora
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // mekameka nga iterator e rua ki tahi ki te iterator nui
/// let files = dirs.chain(config);
///
/// // ka homai ki a matou tenei katoa o te kōnae i roto i te .foo me te .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// He iterator e hua i te āhuatanga kotahi o te momo `A` i te faaohiparaa i te katinga whakaratohia `F: FnOnce() -> A`.
///
///
/// Ko tenei `struct` na te mahi [`once_with()`] i hanga.
/// Tirohia ona tuhinga mo te roanga atu.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}