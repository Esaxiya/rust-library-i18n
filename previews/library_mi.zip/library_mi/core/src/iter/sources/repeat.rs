use crate::iter::{FusedIterator, TrustedLen};

/// Ka waihanga te iterator hou e hope tuarua he huānga kotahi.
///
/// Ko te mahi `repeat()` ka whakahoki ano i te uara kotahi.
///
/// Kei te maha iterators Infinite rite `repeat()` whakamahia ki whāurutau rite [`Iterator::take()`], i roto i te tikanga ki te hanga fakataimí ratou.
///
/// Ki te te momo huānga o te iterator e hiahia ana koe e kore e whakatinana `Clone`, ki te kore koe e hiahia ki te pupuri i te huānga toutou i mahara, hei utu koutou taea te whakamahi i te mahi [`repeat_with()`] ranei.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::iter;
///
/// // te nama wha 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // Yup, tonu wha
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Ka mutu me te [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // e ko tauira whakamutunga maha rawa nga waewae hei.Kia wha noa nga wha o taatau.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... a inaianei e mahi matou
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// He iterator e tuarua ana i te huānga oku taengata.
///
/// Ko tenei `struct` na te mahi [`repeat()`] i hanga.Tirohia ona tuhinga mo te roanga atu.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}