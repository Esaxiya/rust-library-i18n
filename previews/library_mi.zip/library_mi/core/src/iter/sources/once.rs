use crate::iter::{FusedIterator, TrustedLen};

/// Ka waihangahia he kaitautoko e whakaputa ana i tetahi waahanga kotahi te wa kotahi.
///
/// kei te whakamahia i tēnei ki te urutau i te uara kotahi ki te [`chain()`] o ētahi atu momo o te whitiauau.
/// Pea to koutou he iterator e rakau tata katoa, engari e hiahia ana koe i te take motuhake anō.
/// Pea koe te mahi i mahi i runga i iterators, engari e hiahia ana anake koe ki te tukatuka kotahi uara.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::iter;
///
/// // Ko tetahi te tau otahi
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // kotahi noa, koira noa taatau e whiwhi ai
/// assert_eq!(None, one.next());
/// ```
///
/// Te mekameka tahi me tetahi atu kaituku.
/// Kia mea a e hiahia ana tatou ki te tukurua i runga i ia kōnae o te whaiaronga `.foo`, engari ano hoki i te kōnae whirihoranga,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // Me tatou ki te tahuri i te iterator o DirEntry-s ki te iterator o PathBufs, na whakamahi tatou mahere
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // inaianei, ko ta maatau kaitohu mo ta maatau konae whirihora
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // mekameka nga iterator e rua ki tahi ki te iterator nui
/// let files = dirs.chain(config);
///
/// // ka homai ki a matou tenei katoa o te kōnae i roto i te .foo me te .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// He iterator e hua he huānga rite kotahi.
///
/// hanga tenei `struct` e te mahi [`once()`].Tirohia te tona tuhinga mō ake.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}