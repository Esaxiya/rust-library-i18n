//! He tautuhi i te `IntoIter` kaipupuri i te kaitahuri.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// He kaiwhakauru [array]-uara-uara.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ko te ngohi e iterating runga tatou tenei.
    ///
    /// Ko nga huanga me te taupū `i` kaore ano kia tukuna mai te `alive.start <= i < alive.end`, a he whai hua te whakauru urunga.
    /// Ko nga huanga me nga tohu `i < alive.start`, `i >= alive.end` ranei kua oti te tuku, kaore e hiahiatia kia uru atu!ara ai aua āhuatanga mate kia i roto i te āhua tino Korearawhiti!
    ///
    ///
    /// Na ko nga kaitautoko ko:
    /// - `data[alive]` kei te ora (arā, kei roto ngā huanga tika)
    /// - `data[..alive.start]` a kua mate te `data[alive.end..]` (ara kua panuihia nga waahanga kaore ano kia pa atu!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Ko nga waahanga o te `data` kaore ano kia tukuna.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Ka waihanga te iterator hou i runga i te `array` homai.
    ///
    /// *Note*: tenei tikanga kia tauwhāitihia ai i roto i te future, i muri i [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Ko te momo `value` he `i32` i konei, kaua ko te `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SAFETY: Ko te whakawhitinga i konei he tino ahuru.Tuhinga o mua
        // promise:
        //
        // > `MaybeUninit<T>` kua tau kia rite te rahi me te whakahoutanga
        // > hei `T`.
        //
        // Ko te tuhinga ara whakaatu he ai ā i te ngohi o `MaybeUninit<T>` ki te ngohi o `T`.
        //
        //
        // Ki tenei, ko tenei whakaurutanga ka makona nga kaihautu.

        // FIXME(LukasKalbertodt): whakamahia te `mem::transmute` i konei, ka mahi ana me nga tikanga o te kaupapa.
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Kia tae ra ano, ka taea e taatau te whakamahi i te `mem::transmute_copy` ki te hanga i tetahi kape iti hei momo rereke, ka wareware ki te `array` kia kore e heke.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Whakahokia te wāhanga pumau o ngā huānga katoa kihai i i i tuku ano.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SAFETY: Kei te mohio taatau ko nga waahanga katoa kei roto i te `alive` he mea tiimata.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Whakahokia te wāhanga mutable o ngā huānga katoa kihai i i i tuku ano.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SAFETY: Kei te mohio taatau ko nga waahanga katoa kei roto i te `alive` he mea tiimata.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Haere i te taupū i muri i te mua.
        //
        // Ko te whakanui i te `alive.start` ma te 1 e pupuri ana i te kaiwhakawhiwhi mo te `alive`.
        // Heoi, na tenei whakarereke, mo te wa poto, ko te rohe ora ehara i te `data[alive]` inaianei, engari `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Pānuitia te huānga i te ngohi.
            // SAFETY: `idx` he taupū ki te rohe "alive" o mua o
            // ngohi.Ko te panui i tenei waahanga ko te `data[idx]` kua kiia kua mate inaianei (ara kaua e pa).
            // Ka rite ki a `idx` te tīmatanga o te ora-rohe, te rohe ora ko `data[alive]` ano inaianei, whakaora invariants katoa.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Tangohia te taupū muri mai i muri.
        //
        // Ko te whakaheke i te `alive.end` na te 1 e pupuri ana i te kaitautoko mo te `alive`.
        // Heoi, na tenei whakarereke, mo te wa poto, ko te rohe ora ehara i te `data[alive]` inaianei, engari `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Pānuitia te huānga i te ngohi.
            // SAFETY: `idx` he taupū ki te rohe "alive" o mua o
            // ngohi.Ko te panui i tenei waahanga ko te `data[idx]` kua kiia kua mate inaianei (ara kaua e pa).
            // I te mea ko te `idx` te mutunga o te rohe-ora, ko te rohe ora inaianei ko te `data[alive]` ano, me te whakahoki mai i nga kaitukino katoa.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // HAUMARU: Ko te haumaru tenei: hoki `as_mut_slice` rite te iti-wāhanga
        // o ngā āhuatanga e kore i oho atu ano me e noho ki te kia maturuturu iho.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Kaore e pakaru mai i te kaha o te hunga haere mai `me te tiimata: tiimata <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// He pono te whakaatu i te roa o te whiti.
// Ko te maha o ngā āhuatanga "alive" (e ka tonu kia tuku) ko te roa o te awhe `alive`.
// Ko tenei awhe ka heke te roa i te `next` me te `next_back` ranei.
// Ka whakahekehia i nga wa katoa e 1 i roto i era tikanga, engari mena ka whakahokia mai te `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Kia mahara, kaore e tino mate taatau ki te taurite ki te awhe ora tonu, kia taea ai e taatau te whakakapi i te 0 ahakoa ahakoa kei hea `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Ki tou ora huānga katoa.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Tuhia he tohu ki roto i te raarangi hou, ka whakahou i tana awhe ora.
            // Mena te whakakii i te panics, ka tika te taka i nga taonga o mua.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // tā anake nga mea timatanga kihai i i tuku ano: e kore e taea e maua te uru i te āhuatanga tuku a muri.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}