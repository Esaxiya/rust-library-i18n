//! implementations Trait hoki `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Ka whakatinana i te raupapa aho
///
/// Ko nga aho e tono ana i te [lexicographically](Ord#lexicographical-comparison) ma o raatau uara pauna.
/// Ka whakahau tenei i nga waehere waehere Waehereao i runga i o raatau tuunga i nga raarangi waehere.
/// Kaore tenei i te orite ki te ota "alphabetical", ka rereke i te reo me te rohe.
/// Kōmaka aho rite ki ngā paerewa ahurea-whakaaetia titau raraunga tauwāhi-motuhake e ko waho te hōkai o te momo `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Ka whakatinana i nga mahi whakariterite ki runga aho.
///
/// Ka whakaritea nga aho [lexicographically](Ord#lexicographical-comparison) ma a raatau uara pauna.
/// whakataurite tenei Waehereao ngā waehere e hāngai ana i runga i o ratou tūranga i roto i te ngā tūtohi waehere.
/// Kaore tenei i te orite ki te ota "alphabetical", ka rereke i te reo me te rohe.
/// Ko te whakataurite i nga aho e pa ana ki nga paerewa e whakaaehia ana e te ahurea, me kii he raraunga-tauwāhi kei waho o te waahanga `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Ka whakatinana i te waahanga taapiri me te taarua `&self[..]`, `&mut self[..]` ranei.
///
/// Whakahokia ai te poro o te aho katoa, ara, ka whakahokia mai te `&self`, te `&mut self` ranei.Ivalritenga ki te `&whaiaro [0 ..
/// len] `or`&mut self [0 ..
/// len]`.
/// Kaore i rite ki era atu mahi whakaraupuputu, kaore rawa e taea te panic.
///
/// Ko tenei mahinga ko *O*(1).
///
/// I mua i te 1.20.0, i tautokona tonuhia enei mahi whakariterite ma te whakamahi tika i te `Index` me te `IndexMut`.
///
/// He orite ki te `&self[0 .. len]`, te `&mut self[0 .. len]` ranei.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Ka whakatinana i te waahanga taapiri me te taarua `&self[begin .. end]`, `&mut self[begin .. end]` ranei.
///
/// Whakahokia ai tetahi waahanga o te aho i whakawhiwhia mai i te paita paita [`tiimata`, `end`).
///
/// Ko tenei mahinga ko *O*(1).
///
/// I mua i te 1.20.0, i tautokona tonuhia enei mahi whakariterite ma te whakamahi tika i te `Index` me te `IndexMut`.
///
/// # Panics
///
/// Panics ki te kore e `begin` `end` ranei tohu ki te paita tīmata wāhikē o te huru (rite tautuhia e `is_char_boundary`), ki te `begin > end`, ki te `end > len` ranei.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // enei ka panic:
/// // paita 2 kei roto i te `ö`:
/// // &s [2 ..3];
///
/// // paita 8 kei roto i te `老`&s [1 ..
/// // 8];
///
/// // byte 100 kei waho o te aho&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: katahi ano ka tirohia ko `start` me `end` kei runga i te rohe char,
            // ana kei te paahitia e maatau he korero ahuru, no reira ka kotahi ano te uara whakahoki.
            // takina ano tatou rohe pūāuha, na he tika UTF-8 tenei.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: katahi ano ka tirohia ko `start` me `end` kei runga i te rohe taapiri.
            // Kei te mohio matau he motuhake te tohu tohu na te mea i riro mai i a `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAFETY: ka whakapumau te kaikaranga kei te `self` te rohe o `slice`
        // e makona ana i nga tikanga katoa mo te `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: tirohia nga korero mo `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary te tirotiro kei roto te taurangi i [0, .len()] kaore e taea te whakamahi ano i te `get` penei i runga ake nei, na te raru o te NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: katahi ano ka tirohia ko `start` me `end` kei runga i te rohe char,
            // ana kei te paahitia e maatau he korero ahuru, no reira ka kotahi ano te uara whakahoki.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Ka whakatinana i te waahanga taapiri me te taarua `&self[.. end]`, `&mut self[.. end]` ranei.
///
/// Whakahokia ai tetahi poro o te aho i whakawhiwhia mai i te paita paita [`0`, `end`).
/// He orite ki te `&self[0 .. end]`, te `&mut self[0 .. end]` ranei.
///
/// Ko tenei mahinga ko *O*(1).
///
/// I mua i te 1.20.0, i tautokona tonuhia enei mahi whakariterite ma te whakamahi tika i te `Index` me te `IndexMut`.
///
/// # Panics
///
/// Panics ki te kore te `end` e tohu ki te timatanga o te paapena takirua o te tangata (e tautuhia ana e `is_char_boundary`), mena ko `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: katahi ano ka tirohia ko te `end` kei runga i te rohe taapiri,
            // ana kei te paahitia e maatau he korero ahuru, no reira ka kotahi ano te uara whakahoki.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: katahi ano ka tirohia ko te `end` kei runga i te rohe taapiri,
            // ana kei te paahitia e maatau he korero ahuru, no reira ka kotahi ano te uara whakahoki.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SAFETY: katahi ano ka tirohia ko te `end` kei runga i te rohe taapiri,
            // ana kei te paahitia e maatau he korero ahuru, no reira ka kotahi ano te uara whakahoki.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Ka whakatinana i te waahanga taapiri me te taarua `&self[begin ..]`, `&mut self[begin ..]` ranei.
///
/// Whakahokia ai tetahi waahanga o te aho i whakawhiwhia mai i te paita paita [`tiimata`, `len`).Ivalritenga ki te `&whaiaro [tiimata ..
/// len] `ranei`&whaiaro mut [timata ..
/// len]`.
///
/// Ko tenei mahinga ko *O*(1).
///
/// I mua i te 1.20.0, i tautokona tonuhia enei mahi whakariterite ma te whakamahi tika i te `Index` me te `IndexMut`.
///
/// # Panics
///
/// Panics ki te kore te `begin` e tohu ki te timatanga o te paapena takirua o te tangata (e tautuhia ana e `is_char_boundary`), mena ko `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: katahi ano ka tirohia ko te `start` kei runga i te rohe taapiri,
            // ana kei te paahitia e maatau he korero ahuru, no reira ka kotahi ano te uara whakahoki.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: katahi ano ka tirohia ko te `start` kei runga i te rohe taapiri,
            // ana kei te paahitia e maatau he korero ahuru, no reira ka kotahi ano te uara whakahoki.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAFETY: ka whakapumau te kaikaranga kei te `self` te rohe o `slice`
        // e makona ana i nga tikanga katoa mo te `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: ōrite ki `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SAFETY: katahi ano ka tirohia ko te `start` kei runga i te rohe taapiri,
            // ana kei te paahitia e maatau he korero ahuru, no reira ka kotahi ano te uara whakahoki.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Ngā Ahoroto slicing ki wetereo `&self[begin ..= end]` `&mut self[begin ..= end]` ranei.
///
/// Whakahokia ai tetahi poro o te aho i whakawhiwhia mai i te paita paita [`begin`, `end`].He rite ki te `&self [begin .. end + 1]` ko te `&mut self[begin .. end + 1]` ranei, engari mena ko te `end` te uara nui mo te `usize`.
///
/// Ko tenei mahinga ko *O*(1).
///
/// # Panics
///
/// Panics ki te kore te `begin` e tohu ki te timatanga o te paapena takirua o te tangata (kua tautuhia e `is_char_boundary`), mena kaore te `end` e tohu ki te mutunga o te paita mutunga o te tangata (`end + 1` he tiimata timatanga tiimata orite ranei ki te `len`), mena `begin > end`, mena `end >= len` ranei.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Ka whakatinana i te waahanga taapiri me te taarua `&self[..= end]`, `&mut self[..= end]` ranei.
///
/// Whakahokia te wāhanga o te aho homai i te whānuitanga paita [0, `end`].
/// Ōrite ki `&self [0 .. end + 1]`, kore ai ki te he `end` te uara mōrahi mō `usize`.
///
/// Ko tenei mahinga ko *O*(1).
///
/// # Panics
///
/// Panics mena kaore te `end` e tohu ki te mutunga o te takahanga takahi o te tangata (`end + 1` he tiimata timatanga timatanga e tautuhia ana e `is_char_boundary`, peera ranei ki te `len`), mena ranei ki te `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Poroporo te uara i te aho
///
/// `Kei te maha whakamahia tikanga [`from_str`] o FromStr` kakato, i roto i [`str`] 'o aratuka [`parse`].
/// Tirohia nga tuhinga a [`parse`] hei tauira.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` kaore he waahanga mo te roanga o te wa, no reira ka taea noa e koe te taatai i nga momo kaore he waahanga ora mo ratou ake.
///
/// I roto i te mau parau te tahi atu, ka taea e koe te poroporo he `i32` ki `FromStr`, engari e kore e he `&i32`.
/// Ka taea e koe te wehe i tetahi hanganga kei roto tetahi `i32`, engari kaore ano kia kotahi te `&i32`.
///
/// # Examples
///
/// Te whakatinana i te `FromStr` mo te tauira `Point` momo:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Ko te hapa e pa ana ka taea te whakahoki mai i te tuhinga.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Parses ki te string `s` hoki te uara o tenei momo.
    ///
    /// Ki te manuïa poroporo, hoki te uara roto [`Ok`], te kore ka te aho, ko te hoki kino-hōputu te tauwhāiti hapa ki te roto [`Err`].
    /// Ko te momo hapa he motuhake ki te whakatinanatanga o te trait.
    ///
    /// # Examples
    ///
    /// Te whakamahinga taketake me te [`i32`], he momo e whakamahi ana i te `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Tuhia he `bool` mai i te aho.
    ///
    /// Ka whakaputa i te `Result<bool, ParseBoolError>`, na te mea `s` kaore pea pea ka taea te whakarite.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Note, i roto i te rahiraa o te taime, te tikanga `.parse()` i `str` ko atu tika.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}