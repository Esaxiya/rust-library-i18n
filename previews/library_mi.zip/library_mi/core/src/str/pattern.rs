//! Ko te aho Tauira API.
//!
//! Ko te Tauira API he whakarato tikanga hanga mo te whakamahi i nga momo tauira rereke ka rapu koe i te aho.
//!
//! Mo etahi atu korero, tirohia te traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], me [`DoubleEndedSearcher`].
//!
//! Ahakoa kaore i pumau tenei API, ka kitea ma nga API pumau i runga i te momo [`str`].
//!
//! # Examples
//!
//! [`Pattern`] he [implemented][pattern-impls] i roto i te API pumau mo [`&str`][`str`], [`char`], poro o [`char`], me nga mahi me nga katinga e whakamahi ana i te `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // tauira pūāuha te
//! assert_eq!(s.find('n'), Some(2));
//! // poro poro tauira
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // tauira katinga
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// He tauira aho.
///
/// He `Pattern<'a>` faaite e taea te whakamahi i te momo whakatinana rite te tauira string mō te rapu i roto i te [`&'a str`][str].
///
/// Hei tauira, ko te `'a'` me te `"aa"` he tauira e rite ana ki te tohu `1` i te aho `"baaaab"`.
///
/// Ko te trait ano he kaihanga mo tetahi momo [`Searcher`] e hono ana, e mahi ana i nga mahi ki te kimi i nga ahuatanga o te tauira i roto i te aho.
///
///
/// Tei runga i te momo o te tauira, te whanonga o ngā tikanga rite [`str::find`] me [`str::contains`] taea te huri.
/// E whakaatu ana te teepu i raro ake nei i etahi o aua whanonga.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Ko te kaitoha e hono ana mo tenei tauira
    type Searcher: Searcher<'a>;

    /// Hangaia te kaiwhai rapu mai i `self` me te `haystack` ki te rapu.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Ka tirotirohia mena e taupatupatu ana te tauira ki hea i te maihi
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Taki ai mēnā ōrite te tauira i te mua o te tāke hei
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Ka tirotirohia mena ka tau te tauira ki muri o te maihi
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Tango te tauira i te mua o te tāke hei, ki te ōrite te reira.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SAFETY: `Searcher` e mohiotia ana ka hoki mai nga tohu whaihua.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Ka tangohia te tauira mai i muri o te tarutaru, mena ka uru.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SAFETY: `Searcher` e mohiotia ana ka hoki mai nga tohu whaihua.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Hua o te waea [`Searcher::next()`], [`ReverseSearcher::next_back()`] ranei.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// E whakaatu ana kua kitea te whakataetae o te tauira i te `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// E whakaatu ana ko `haystack[a..b]` kua paopaohia kia taea ai te tauira.
    ///
    /// Kia mahara tera pea neke atu i te kotahi `Reject` i waenga i nga `Match`es e rua, kaore he whakaritenga kia honoa ratou kia kotahi.
    ///
    ///
    Reject(usize, usize),
    /// He whakaatu kua tae mai nga paita o te maatapihi ki te whakamutu, ka mutu ano hoki te korero.
    ///
    Done,
}

/// He kaiwhaiwhai mo te tauira aho.
///
/// Ko tenei trait e whakarato ana i nga tikanga mo te rapu i nga taarua-kore o te tauira mai i te (left) o mua o te aho.
///
/// Ka whakatinanahia e nga momo `Searcher` e hono ana o te [`Pattern`] trait.
///
/// Ko te trait kua tohuhia kaore i te haumaru na te mea ko nga tohu i whakahokia mai e nga tikanga [`next()`][Searcher::next] e tika ana kia takoto i nga rohe utf8 whaimana kei roto i te maaka.
/// Ma tenei ka taea e nga kaihoko o tenei trait te tapatapahi i te kohinga tarutaru kaore he arowhai taapiri.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter mo te aho e whaaia ana kia rapua
    ///
    /// Ka hoki tonu mai te [`&str`][str] ano.
    fn haystack(&self) -> &'a str;

    /// Ka mahi i nga mahi rapu a muri ka tiimata mai i mua.
    ///
    /// - Whakahoki [`Match(a, b)`][SearchStep::Match] mena ka uru a `haystack[a..b]` ki te tauira.
    /// - Whakahoki [`Reject(a, b)`][SearchStep::Reject] mena kaore e taea e `haystack[a..b]` te taurite ki te tauira, ahakoa he waahanga.
    /// - Whakahoki ai i te [`Done`][SearchStep::Done] mena kua tae mai nga paita katoa o te kohinga tarutaru.
    ///
    /// Ko te awa o [`Match`][SearchStep::Match] me [`Reject`][SearchStep::Reject] uara ake ki te [`Done`][SearchStep::Done] ka i roto i awhe taupū e he pātata, inaki-kore, te uhi i te tāke hei katoa, me te whakapanga ki runga rohe utf8.
    ///
    ///
    /// Me hua He [`Match`][SearchStep::Match] ki roto i te tauira katoa ki āu, Heoi kia wahia e ake ai ngā hua [`Reject`][SearchStep::Reject] ki te noho maha whatiwhatinga pātata.kia whai kore roa awhe rua.
    ///
    /// Ka rite ki te tauira, te tauira `"aaa"` me te tāke hei `"cbaaaaab"` kia hua te awa
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Ka kitea te hua [`Match`][SearchStep::Match] e whai ake nei.Tirohia te [`next()`][Searcher::next].
    ///
    /// Kaore i te ahua o te [`next()`][Searcher::next], kaore he tutukitanga ka pakaru mai nga awhe i whakahokia mai o tenei ka [`next_reject`][Searcher::next_reject].
    /// Ka hoki mai tenei i te `(start_match, end_match)`, kei hea te timatanga o te timatanga mo te waahi ka tiimata te whakataetae, a ko te mutunga ko te tohu i muri o te mutunga o te whakataetae.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Ka kitea te hua [`Reject`][SearchStep::Reject] e whai ake nei.Tirohia te [`next()`][Searcher::next] ko [`next_match()`][Searcher::next_match].
    ///
    /// Kaore i te ahua o te [`next()`][Searcher::next], kaore he tutukitanga ka pakaru mai nga awhe i whakahokia mai o tenei ka [`next_match`][Searcher::next_match].
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// He kaiwhakararu whakamuri mo te tauira aho.
///
/// Ko tenei trait e whakarato ana i nga tikanga mo te rapu i nga taarua-kore o te tauira ka tiimata mai i te tuara (right) o te aho.
///
/// Ka whakatinanahia e nga momo [`Searcher`] e hono ana o te [`Pattern`] trait mena ka tautoko te tauira i te rapu mai i muri.
///
///
/// Ko nga raarangi tohu i whakahokia mai e tenei trait kaore e hiahiatia kia rite ki nga waahanga o te rapu whakamua i muri.
///
/// Mo nga take i tohua ai tenei trait kaore i te haumaru, tirohia maatua matua trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// He whakamahi i te taahiraa rapu i muri timata i te hoki.
    ///
    /// - Whakahoki [`Match(a, b)`][SearchStep::Match] mena ka uru a `haystack[a..b]` ki te tauira.
    /// - [`Reject(a, b)`][SearchStep::Reject] hoki, ki te kore e taea e `haystack[a..b]` ōrite te tauira, ara wāhanga.
    /// - Whakahoki ai i te [`Done`][SearchStep::Done] mena kua tae mai nga paita katoa o te kohinga tarutaru
    ///
    /// Ko te awa o [`Match`][SearchStep::Match] me [`Reject`][SearchStep::Reject] uara ake ki te [`Done`][SearchStep::Done] ka i roto i awhe taupū e he pātata, inaki-kore, te uhi i te tāke hei katoa, me te whakapanga ki runga rohe utf8.
    ///
    ///
    /// Me hua He [`Match`][SearchStep::Match] ki roto i te tauira katoa ki āu, Heoi kia wahia e ake ai ngā hua [`Reject`][SearchStep::Reject] ki te noho maha whatiwhatinga pātata.kia whai kore roa awhe rua.
    ///
    /// Ka rite ki te tauira, te tauira `"aaa"` me te tāke hei `"cbaaaaab"` kia hua te awa `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Ka kimi te hua [`Match`][SearchStep::Match] muri.
    /// Tirohia te [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Ka kitea te hua [`Reject`][SearchStep::Reject] e whai ake nei.
    /// Tirohia te [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// He tohu trait hei whakaatu ka taea te whakamahi i te [`ReverseSearcher`] mo te whakamahi [`DoubleEndedIterator`].
///
/// Hoki tenei, Me te impl o [`Searcher`] ko [`ReverseSearcher`] ki te whai i enei tikanga:
///
/// - Me hua katoa o `next()` ki kia ōrite ki te hua o `next_back()` i te raupapa whakamuri.
/// - `next()` me te `next_back()` me whanonga kia rite ki nga pito e rua o te whānuitanga o ngā uara, ko te kore e taea te "walk past each other".
///
/// # Examples
///
/// `char::Searcher` Ko te `DoubleEndedSearcher` no rapu mō te [`char`] anake titau titiro i te kotahi i te wa, e mahi ana te taua i pito e rua.
///
/// `(&str)::Searcher` ehara i te `DoubleEndedSearcher` na te mea ko te tauira `"aa"` kei roto i te otaota otaota `"aaa"` he rite ki te `"[aa]a"` ko te `"a[aa]"` ranei, mai i tehea taha e rapuhia ana.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl mō te char
/////////////////////////////////////////////////////////////////////////////

/// Momo hono mo `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // kaiwhakawhiwhi ahuru: `finger`/`finger_back` me tohu he tohu utf8 paita o `haystack` Ka taea te pakaru tenei kaitautoko *i roto i te* muri_match me muri_match_back, heoi me puta me nga maihao i nga rohe tohu tohu tika.
    //
    //
    /// `finger` Ko te taupū paita nāianei o te rapu whakamua.
    /// Whakaarohia kei mua i te paita i tona taupūtanga, arā
    /// `haystack[finger]` Ko te paita tuatahi o te waahanga me tirotirohia e tatou i te wa e rapu ana i mua
    ///
    finger: usize,
    /// `finger_back` Ko te taupū paita nāianei o te rapu whakamuri.
    /// A feruri na e te vai te reira i muri i te paita i tona taupūtanga, arā
    /// tāke hei [finger_back, 1] ko te paita whakamutunga o te wāhanga e ti'a ia tatou tirotiro i roto i te rapu whakamua (a ko te kupu i te paita tuatahi kia tirotirohia ki ina karanga next_back()).
    ///
    finger_back: usize,
    /// Ko te kiripuaki e rapuhia ana
    needle: char,

    // te kaitukino haumaru: `utf8_size` me iti iho i te 5
    /// Ko te maha o ngā paita `needle` e ake ina whakawaeheretia i utf8.
    utf8_size: usize,
    /// whakawaeheretia He utf8 kape o te `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SAFETY: Ko te 1-4 te haumaru o `get_unchecked`
        // 1. `self.finger` me te `self.finger_back` kei runga i nga rohe unicode (he haurangi tenei)
        // 2. `self.finger >= 0` mai i te tiimata mai i te 0 ka piki noa ake
        // 3. `self.finger < self.finger_back` no te mea e hoki mai te kore te char `iter` `SearchStep::Done`
        // 4.
        // `self.finger` mai i mua i te mutunga o te tāke hei no te mea tīmata `self.finger_back` i te mutunga, me te anake heke
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // tāpiri paita wāhikē o huru nāianei kahore re-whakawaehere rite utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // tikina te tarutaru i muri i te kitenga o te tangata whakamutunga
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // te paita whakamutunga o te utf8 ngira SAFETY kua whakawaeheretia: he kaitautoko kei a `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Ko te maihao hou te tohu o te paita i kitea e maatau, me tetahi, na te mea i maumahara maatau ki te paita whakamutunga o te tangata.
                //
                // Note e kore e homai nga wa katoa i tenei tatou te maihao i runga i te rohe UTF8.
                // Ki te tatou kahore i * * kitea to tatou huru e kua taupū matou ki te paita kore-whakamutunga o te huru 3-paita 4-paita ranei.
                // E kore e taea e tatou tīpoka noa ki te paita tīmatanga tika muri no te mea te huru rite ꁁ (U + A041 Yi haupū PA), ka whai utf-8 `EA 81 81` kitea tonu tatou te rua te paita rapu mō te tuatoru.
                //
                //
                // Heoi, he pai noa atu tenei.
                // Ahakoa kei a maatau te kaitoha kei te self.finger kei runga i te rohe UTF8, kaore e whakawhirinaki tenei kaitautoko ki roto i tenei tikanga (ka whakawhirinaki ki a CharSearcher::next()).
                //
                // Tatou puta noa i tenei tikanga ka tae tatou i te mutunga o te aho, ranei ki te kitea tatou te tahi mea.Ka kitea e maatau tetahi mea ka whakatauhia te `finger` ki te rohe UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // kitea tetahi mea, putanga
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // kia next_reject whakamahi i te whakatinanatanga taunoa i te Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SAFETY: tirohia nga korero mo next() i runga ake nei
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // tangohia te paita paita o te tangata onaianei me te kore e whakawaehere ano hei utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // te tiki i te tāke hei runga ki engari e kore e tae atu i te pūāhua whakamutunga rapu
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // te paita whakamutunga o te utf8 ngira SAFETY kua whakawaeheretia: he kaitautoko kei a `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // i rapuhia e maatau tetahi waahanga i utua e self.finger, taapiri i te self.finger hei whakahoki mai i te taurangi taketake
                //
                let index = self.finger + index;
                // Ma te memrchr e whakahoki te taurangi o te paita e hiahia ana matou kia kitea.
                // I roto i te take o te pūāhua ASCII, kei te pono nga tenei hiahia tatou i to tatou ringa hou ki te hei ("after" te pūāuha kitea i roto i te tauira o te whitiauau whakamuri).
                //
                // Hoki Ngā pū multibyte hiahia tatou ki te tīpoka ki raro i te maha o atu paita whai ratou i te ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // neke maihao ki te aroaro o kitea te pūāhua (arā, i tona taupū tīmatanga)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Kaore e taea e taatau te whakamahi i te ringaringa_muri=taupū, rahinga + 1 i konei.
                // Ki te kitea e matou i te char whakamutunga o te huru rerekē-rahi (te paita waenganui o te huru rerekē ranei) he aha tatou ki puku te finger_back ki raro ki `index`.
                // Ma tenei ka taea pea e `finger_back` te kore ki runga i tetahi rohe, engari he pai tenei na te mea ka puta noa atu taatau mahi i runga i te rohe ka tino rapuhia ranei te tarutaru.
                //
                //
                // Kaore i te ahua o muri_mai kaore tenei i te raru o nga paita tukurua i te utf-8 na te mea e rapu ana matou i te paita whakamutunga, a ka kitea noa e matou te paita whakamutunga ka rapu whakamuri.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // kitea tetahi mea, putanga
                return None;
            }
        }
    }

    // kia next_reject_back whakamahi i te whakatinanatanga taunoa i te Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Rapu mō Ngā pū e te hunga rite ki te [`char`] homai.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl mo te Uwhi MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Whakatauritea roa o te iterator paita te wāhanga ā-ki te kitea te roa o te char nāianei
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Whakatauritea roa o te iterator paita te wāhanga ā-ki te kitea te roa o te char nāianei
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl hoki&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Hurihia/Tango na te ruarua o te tikanga.

/// E pā ana momo mo `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Rapu mo nga kara e rite ana ki nga [[char`] katoa o te poro.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl hoki F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Momo hono mo `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Rapu mo nga [`char`] e taurite ana ki nga tohu o mua.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl mo&&str
/////////////////////////////////////////////////////////////////////////////

/// Kaitono ki te `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl mo te &str
/////////////////////////////////////////////////////////////////////////////

/// Te tohatoha-kore rapu taapiri.
///
/// E hapai i te tauira `""` rite hoki mai kēmu kau i ia rohe pūāhua.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Taki ai mēnā ōrite te tauira i te mua o te tāke hei.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Tango te tauira i te mua o te tāke hei, ki te ōrite te reira.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // HAUMARU: kuhimua i tika manatoko ki te tīariari.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Ka tirotirohia mena ka tau te tauira ki muri o te maihi.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Ka tangohia te tauira mai i muri o te tarutaru, mena ka uru.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // HAUMARU: kūmuri i tika manatoko ki te tīariari.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// E rua nga kaiwhakararu taapiri
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Momo hono mo `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // whakakahore ngira kau katoa char me ōrite ana nga string kau i waenganui ia ratou
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // E ruaWaySearcher e whakaputa ana i nga tohu *Whakataurite* e wehe ana i nga rohe taangata mena e tika ana te taatai me te tarutaru me te ngira he UTF-8 *Ka paopao* mai i te algorithm ka taka ki runga i nga tohu, engari ka haere a ringa ki nga rohe o muri, kia e he haumaru utf-8 ratou.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // peke ki te rohe o muri mai
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // tuhia nga keehi `true` me `false` hei akiaki i te kaiwhakangungu kia motuhake nga waahanga e rua.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // peke ki te rohe o muri mai
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // tuhia te `true` me te `false`, penei i te `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Te ahua o roto o te hātepe rapu-rua rapu algorithm.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// taupū tauwehe tauwehe
    crit_pos: usize,
    /// taupū tauwehenga tauwehe mo te ngira kua hurihia
    crit_pos_back: usize,
    period: usize,
    /// `byteset` he toronga (ehara i te waahanga o te algorithm ara e rua);
    /// he 64-bit "fingerprint" kei reira nga kohinga `j` e hangai ana ki te (paita&63)==j kei roto i te ngira.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// whakaraupapahia ki te ngira i mua o taatau kua taatai
    memory: usize,
    /// taupū ki ngira i muri nei kua tatou āu kua
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Ko nga whakamarama e tino paanui ana mo nga mea e pa ana ki konei ka kitea i te pukapuka a Crochemore me a Rytter "Text Algorithms", ch 13.
        // Āta kite i te waehere mō "Algorithm CP" i p.
        // 323.
        //
        // Ko te mea kei te haere kei i a maatau etahi tohu whakahirahira (u, v) o te ngira, a e hiahia ana maatau ki te whakatau mena he tohu to u mo te&v [.. wā].
        // Mena he, ka whakamahia e matou te "Algorithm CP1".
        // Kore whakamahi tatou "Algorithm CP2", papaitia nei hoki ina he nui te wā o te ngira.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // take mo te wa poto-ko te waa ka tatau tonu i tetahi waahanga whakahirahira motuhake mo te ngira hurihuri x=u 'v' kei hea | v '|<period(x).
            //
            // Ka tere tenei ma te wa e mohiotia ana.
            // Kia mahara ko tetahi keehi penei i te x= "acba" ka taea te hora whakamua (crit_pos=1, waa=3) i te wa e haangai ana ki te waa tata ki muri (crit_pos=2, wā=2).
            // whakamahi tatou i te factorization whakamuri homai engari te pupuri i te wā tangohia.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // take wā roa-to tatou he āwhiwhitanga ki te wā tūturu, a kahore e whakamahi aauraa.
            //
            //
            // Whakatata atu ki te waa ma te taapiri o max(|u|, |v|) + 1.
            // Ko te tauwehenga whakahirahira he pai ki te whakamahi mo te rapu whakamua me te rapu whakamuri.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Te uara Dummy hei tohu he roa te waa
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Ko tetahi o nga whakaaro nui o te Huarua-Tuarua ko te tohu i te ngira kia rua haurua, (u, v), ka tarai ki te kimi v i roto i te tarutaru ma te matawai maui ki matau.
    // Mena he whakataetae v, ka ngana taatau ki te whakaari i a koe ma te matawai matau ki te taha maui.
    // Kia pehea te tawhiti ki te peke ka kitea he taurite, ko te (u, v) he take nui mo te ngira.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` whakamahia te `self.position` hei pehu mo ia
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Tirohia mena he waahi taatau ki te rapu i te tuunga + te ngira_ka kore e taea te totika mena ka kiia e taatau ana nga poro i te awhe a isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Hohoro tīpoka i nui wahi auauhia, ki to tatou Ahoroto
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Tirohia mena e haangai ana te waahanga tika o te ngira
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Kite ki te te wahi maui o te kēmu ngira
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Kua kitea he whakataetae!
            let match_pos = self.position;

            // Note: taapiri i te self.period hei utu mo te needle.len() kia taarua nga whakataetae
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // tautuhia ki needle.len(), self.period mo nga tukinga inaki
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Whai te whakaaro i roto i `next()`.
    //
    // He hangarite nga whakamaaramatanga, me te period(x) = period(reverse(x)) me te local_period(u, v) = local_period(reverse(v), reverse(u)), na mena he (u, v) he tohu whakahirahira, he pera ano te (reverse(v), reverse(u)).
    //
    //
    // Mo te keehi whakamuri kua tirohia e maatau tetahi waahanga nui x=u 'v' (mara `crit_pos_back`).E hiahia ana matou | u |<period(x) mo te keehi whakamua me te penei | v '|<period(x) mo te tahatua.
    //
    // Hei rapu i roto i whakamuri roto i te tāke hei, rapu tatou i mua i roto i te tāke hei whakataka ki te ngira whakamuri, ōrite tuatahi u 'a ka v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` ka whakamahi i te `self.end` hei pehu ki a ia-kia motuhake ai te `next()` me te `next_back()`.
        //
        let old_end = self.end;
        'search: loop {
            // Tirohia mena he waahi taatau ki te rapu i te mutunga, ka roropi a needle.len() i te wa kaore he ruuma, engari na te aukati i te roa o te waahanga kaore e taea te whakahoki ano ki te waa o te tarutaru.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Hohoro tīpoka i nui wahi auauhia, ki to tatou Ahoroto
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Kite ki te te wahi maui o te kēmu ngira
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Tirohia mena e haangai ana te waahanga tika o te ngira
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Kua kitea he whakataetae!
            let match_pos = self.end - needle.len();
            // Note: raro self.period hei utu mo needle.len() kia taarua nga whakataetae
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Tuhia te taapiri teitei o te `arr`.
    //
    // Ko te taapiri tino nui ko te waahanga nui pea (u, v) o `arr`.
    //
    // Returns (`i`, `p`) kei hea `i` ko te taupū tīmata o te v me `p` ko te wā o te v.
    //
    // `order_greater` whakatau ki te ko `<` `>` ranei kia wetereo.
    // Ko nga ota e rua me tatau-ko te ota me te `i` nui rawa atu he tohu tino nui.
    //
    //
    // Mo nga keehi roa, kaore i te tino tika te wa i puta (he poto rawa).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Hāngai ki i roto i te pepa
        let mut right = 1; // Hāngai ki te j roto i te pepa
        let mut offset = 0; // E hangai ana ki te k i roto i te pepa, engari ka tiimata mai i te 0
        // ki te taurite i te taurangi tau-0.
        let mut period = 1; // E hangai ana ki te p i te pepa

        while let Some(&a) = arr.get(right + offset) {
            // `left` ka waiho inbounds ka `right` he.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // He iti ake te Suffix, ko te wa te awhinga katoa i tenei wa.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Haere whakamua ma te tukurua o te waa onaianei.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // He nui ake te Suffix, tiimata mai i te waahi o naianei.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Tuhia te taapiri teitei o te tuuraka o `arr`.
    //
    // Ko te taapiringa tino nui ko te take tera pea (u ', v') o `arr`.
    //
    // Whakahoki `i` kei hea te `i` te tiimata tauanga o v ', mai i muri;
    // hoki mai ano ka tae mai te waa o `known_period`.
    //
    // `order_greater` whakatau ki te ko `<` `>` ranei kia wetereo.
    // Ko nga ota e rua me tatau-ko te ota me te `i` nui rawa atu he tohu tino nui.
    //
    //
    // Mo nga keehi roa, kaore i te tino tika te wa i puta (he poto rawa).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Hāngai ki i roto i te pepa
        let mut right = 1; // Hāngai ki te j roto i te pepa
        let mut offset = 0; // E hangai ana ki te k i roto i te pepa, engari ka tiimata mai i te 0
        // ki te taurite i te taurangi tau-0.
        let mut period = 1; // E hangai ana ki te p i te pepa
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // He iti ake te Suffix, ko te wa te awhinga katoa i tenei wa.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Haere whakamua ma te tukurua o te waa onaianei.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // He nui ake te Suffix, tiimata mai i te waahi o naianei.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy taea te hātepe ki te tīpoka rānei kore ngā tākaro-rite hohoro rite taea, ki te mahi ranei i roto i te aratau i reira tuku hoki ngā hohoro reira Ka whakakore.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Haere ki te taurite i nga waa kia tere
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit Ka paopao i nga wa katoa
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}