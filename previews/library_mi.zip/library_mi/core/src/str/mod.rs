//! Te whawhe i te aho
//!
//! Mo etahi atu taipitopito, tirohia te waahanga [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. Tuhinga o mua
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. tiimata <=mutunga
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. rohe ahua
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // kitea te huru
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` me iti ake i te len me te rohe char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Whakahokia ai te roa o `self`.
    ///
    /// Ko tenei roa i roto i paita, e kore [`char`] o ranei graphemes.
    /// I etahi atu kupu, akene kaore pea ko te mea ka whakaarohia e te tangata te roa o te aho.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // rerehua f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Whakahoki ai i te `true` mena he roa te kore paita o te `self`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ka tirohia ko te `index`-th paita te paita tuatahi i te raupapa tohu waehere UTF-8 te mutunga ranei o te aho.
    ///
    ///
    /// Te timatanga me te mutunga o te aho (ina te `taupū== self.len()`) e kiia ana he rohe.
    ///
    /// Whakahoki ai i te `false` mena he nui ake te `index` i te `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // Tuhinga o mua
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // paita tuarua o `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // Tuhinga o mua `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 a len he pai tonu.
        // Whakamatauhia te 0 kia mohio ai kia maama te tirotiro i te haki ka pahemo i nga raraunga aho panui mo tera keehi.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // He rite te makutu nei ki te: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Ka huri i te poro aho ki te poro paita.
    /// Hei huri i te poro paita ki tetahi poro aho, whakamahia te mahi [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SAFETY: tangi const no te mea ai ā matou e rua ngā momo ki te tahora taua
        unsafe { mem::transmute(self) }
    }

    /// Ka huri i te poro aho e taea te huri ki te poro paita huri noa.
    ///
    /// # Safety
    ///
    /// Me whakarite e te kaiwaea ko nga korero o te poroi he tika te UTF-8 i mua i te mutunga o te nama ka whakamahia te take `str`.
    ///
    ///
    /// Ko te whakamahi i te `str` kaore nei o raatau tuhinga e tika UTF-8, he whanonga kore.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SAFETY: ko te kaiwhakaari mai i `&str` ki `&[u8]` he ahuru mai i te `str`
        // He te tahora taua rite `&[u8]` (anake libstd taea te hanga i tēnei taurangi).
        // He pai te whakaahuru a te tohu tohu mai i te korero ka taea te huri hei tohu mo nga tuhinga.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Ka huri i te poro aho ki te atatohu noa.
    ///
    /// Ka rite ki string poro ko te wāhanga o paita, nga ngā atatohu raw ki te [`u8`].
    /// Ka tohu tenei tohu ki te paita tuatahi o te poro aho.
    ///
    /// Me whakarite i te kaiwaea e kore te te atatohu hoki tuhituhia ki.
    /// Mena ka hiahia koe ki te whakarereke i nga tuhinga o te poro aho, whakamahia te [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Tahuri ai i te poro aho huri noa ki te atatohu mata.
    ///
    /// Ka rite ki string poro ko te wāhanga o paita, nga ngā atatohu raw ki te [`u8`].
    /// Ka tohu tenei tohu ki te paita tuatahi o te poro aho.
    ///
    /// Kei a koe te tikanga kia mohio ko te waahanga o te aho ka whakarerekehia kia pai ai te noho UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Whakahokia ai te utu mo te `str`.
    ///
    /// Koinei te rereke kore-panui ki te whakariterite i te `str`.
    /// Whakahoki ai i te [`None`] i nga wa katoa ka rite te mahinga whakariterite ki a panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // nga tohu kaore i runga i nga rohe raupapa UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // Tuhinga o mua
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Whakahoki ai i te waahanga o te `str` ka taea te whakarereke.
    ///
    /// Koinei te rereke kore-panui ki te whakariterite i te `str`.
    /// Whakahoki ai i te [`None`] i nga wa katoa ka rite te mahinga whakariterite ki a panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // te roa tika
    /// assert!(v.get_mut(0..5).is_some());
    /// // Tuhinga o mua
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Whakahokia te subslice kore taki o `str`.
    ///
    /// Koinei te rereke kaore i tirotirohia ki te tuhi i te `str`.
    ///
    /// # Safety
    ///
    /// Ko nga kaiwaea o tenei mahi he kawenga kei te pai enei whakaritenga o mua:
    ///
    /// * E kore me te taupū tīmata nui te taupū mutu;
    /// * Ko nga taurangi me noho ki roto i nga rohe o te poro taketake;
    /// * Me takoto nga tohu ki nga rohe raupapa UTF-8.
    ///
    /// Ki te kore, ko te waahanga o te aho kua whakahokia mai, ka tohu pea i te maharatanga he he, ki te takahi ranei i nga kaitono korero mai i te momo `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SAFETY: me tautoko te kaiwaea i te kirimana ahuru mo te `get_unchecked`;
        // ka taea te whakakore i te poro no te mea ko te `self` he tohu ahuru.
        // He ahuru te tohu atawhai i whakahokia mai na te mea ko te `SliceIndex` me kii he pono.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Whakahoki ai i te kohinga `str` e kore e taea te tirotiro.
    ///
    /// Koinei te rereke kaore i tirotirohia ki te tuhi i te `str`.
    ///
    /// # Safety
    ///
    /// Ko nga kaiwaea o tenei mahi he kawenga kei te pai enei whakaritenga o mua:
    ///
    /// * E kore me te taupū tīmata nui te taupū mutu;
    /// * Ko nga taurangi me noho ki roto i nga rohe o te poro taketake;
    /// * Me takoto nga tohu ki nga rohe raupapa UTF-8.
    ///
    /// Ki te kore, ko te waahanga o te aho kua whakahokia mai, ka tohu pea i te maharatanga he he, ki te takahi ranei i nga kaitono korero mai i te momo `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SAFETY: me tautoko te kaiwaea i te kirimana ahuru mo te `get_unchecked_mut`;
        // ka taea te whakakore i te poro no te mea ko te `self` he tohu ahuru.
        // He ahuru te tohu atawhai i whakahokia mai na te mea ko te `SliceIndex` me kii he pono.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Ka waihanga te wāhanga string i tetahi atu wāhanga string, bypassing arowhai haumaru.
    ///
    /// Ko te tikanga kaore tenei e taunakitia, kia tupato!Mo tetahi waahanga ahuru tirohia te [`str`] me te [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Ko tenei waahanga hou ka neke atu i te `begin` ki te `end`, tae atu ki te `begin` engari ka whakakore i te `end`.
    ///
    /// Ki te tiki i te wāhanga string mutable hei utu, kite te tikanga [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Ko nga Kaikaranga o tenei mahi he kawenga mo nga whakaritenga e toru kua ea:
    ///
    /// * `begin` kaua e nui ake i te `end`.
    /// * `begin` me `end` me noho hei nohoanga i roto i te poro aho.
    /// * `begin` me `end` me takoto ki nga rohe raupapa UTF-8.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SAFETY: me tautoko te kaiwaea i te kirimana ahuru mo te `get_unchecked`;
        // ka taea te whakakore i te poro no te mea ko te `self` he tohu ahuru.
        // He ahuru te tohu atawhai i whakahokia mai na te mea ko te `SliceIndex` me kii he pono.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Ka waihanga te wāhanga string i tetahi atu wāhanga string, bypassing arowhai haumaru.
    /// Tenei e kore te tikanga e tūtohu, te whakamahi ki te tūpato!Mo tetahi waahanga ahuru tirohia te [`str`] me te [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Ko tenei waahanga hou ka neke atu i te `begin` ki te `end`, tae atu ki te `begin` engari ka whakakore i te `end`.
    ///
    /// Ki te tango i tetahi waahanga aho whakarereke, tirohia te tikanga [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Ko nga Kaikaranga o tenei mahi he kawenga mo nga whakaritenga e toru kua ea:
    ///
    /// * `begin` kaua e nui ake i te `end`.
    /// * `begin` me `end` me noho hei nohoanga i roto i te poro aho.
    /// * `begin` me `end` me takoto ki nga rohe raupapa UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SAFETY: me tautoko te kaiwaea i te kirimana ahuru mo te `get_unchecked_mut`;
        // ka taea te whakakore i te poro no te mea ko te `self` he tohu ahuru.
        // He ahuru te tohu atawhai i whakahokia mai na te mea ko te `SliceIndex` me kii he pono.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Wehea tetahi waahanga aho kia rua ki te taurangi.
    ///
    /// Ko te tohenga, `mid`, me waiho hei byte whakaweto mai i te tiimata o te aho.
    /// Me kia hoki te reira i runga i te rohe o te ira waehere UTF-8.
    ///
    /// Ko nga poro e rua i hoki mai i te tiimata o te poro aho ki te `mid`, a mai i te `mid` ki te pito o te poro o te aho.
    ///
    /// Ki te whiwhi poro string mutable hei utu, kite te tikanga [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics mena kaore a `mid` i te rohe tohu waehere UTF-8, mena kua pahemo te mutunga o te tohu waehere whakamutunga o te poro aho.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary takina kei roto te taurangi [0, .len()]
        if self.is_char_boundary(mid) {
            // SAFETY: katahi ano ka tirohia ko `mid` kei runga i te rohe taapiri.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Wehe kotahi wāhanga string mutable ki rua i te taupū.
    ///
    /// Ko te tohenga, `mid`, me waiho hei byte whakaweto mai i te tiimata o te aho.
    /// Me kia hoki te reira i runga i te rohe o te ira waehere UTF-8.
    ///
    /// Ko nga poro e rua i hoki mai i te tiimata o te poro aho ki te `mid`, a mai i te `mid` ki te pito o te poro o te aho.
    ///
    /// Hei tango i nga poro aho whakarereke, tirohia te tikanga [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics mena kaore a `mid` i te rohe tohu waehere UTF-8, mena kua pahemo te mutunga o te tohu waehere whakamutunga o te poro aho.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary takina kei roto te taurangi [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SAFETY: katahi ano ka tirohia ko `mid` kei runga i te rohe taapiri.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Whakahokihia ai he miihini ki runga i nga [`char`] o te poro aho.
    ///
    /// I te waahanga o te aho taapiri he UTF-8 whaimana, ka taea e taatau te whakamahi i tetahi waahanga aho na [`char`].
    /// Ko tenei tikanga ka whakahoki i taua kaituhi.
    ///
    /// He mea nui ki te mahara e tohu [`char`] he Unicode scalar Uara, a kore e ōrite koutou whakaaro o te mea he 'character' he.
    ///
    /// Ko te taarua mo nga tautau karepe tera pea e hiahia ana koe.
    /// Ko tenei mahinga kaore i te waihangahia e te whare pukapuka paerewa a Rust, tirohia te crates.io.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Kia mahara, [`char`] kore s kia ōrite tō pūmanawa e pā ana ki pūāhua:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // kaore 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Whakahokihia ai he miihini ki runga i nga waahanga [`char`] o tetahi poro aho, me o raatau tuunga.
    ///
    /// I te waahanga o te aho taapiri he UTF-8 whaimana, ka taea e taatau te whakamahi i tetahi waahanga aho na [`char`].
    /// Ko tenei tikanga ka whakahoki i te kaitahuri o enei [`char`] e rua, me o raatau tūranga paita.
    ///
    /// Ka whakawhiwhia e te kaitarai te huringa.Ko te waahi ko te tuatahi, ko te [`char`] te tuarua.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Kia mahara, [`char`] kore s kia ōrite tō pūmanawa e pā ana ki pūāhua:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // kore (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // tuhipoka te 3 i konei, ko te tangata whakamutunga i tango i nga paita e rua
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// He taurite ki runga i nga paita o te poro taura.
    ///
    /// Ka rite ki te poro taara he raupapa paita, ka taea e taatau te huri i tetahi waahanga paita i te paita.
    /// Ko tenei tikanga ka whakahoki i taua kaituhi.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Ka tohaina te poro aho ki te waahi ma.
    ///
    /// Ka whakahokia mai e te miihini e whakahoki mai ana i nga poro taapiri he waahanga iti o te waahanga taketake o te aho, ka wehea e te nuinga o te waahi ma.
    ///
    ///
    /// 'Whitespace' kua tautuhia kia rite ki nga tikanga o te Unicode I ahu mai i te Rawa Taonga `White_Space`.
    /// Ki te hiahia noa koe ki te maringi i runga i ASCII mokowāmā hei utu, te whakamahi i [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// E whakaaro momo katoa o mokowāmā:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Ka tohaina te poro aho ki te waahi ma a ASCII.
    ///
    /// Ka whakahokia mai e te miihini e whakahoki mai ana i nga poro taapiri he waahanga iti o te waahanga taara taketake, ka wehea e te nuinga o te waahi maamaa ASCII.
    ///
    ///
    /// Hei wehe ma te Waehereao `Whitespace` hei utu, whakamahia te [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Ko nga momo maama ASCII katoa e whakaarohia ana:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// He iterator mo nga rārangi o te aho, kia rite ki poro aho.
    ///
    /// te mutunga o ngā rārangi e ki rānei te rainahou (`\n`) ranei te hoki hariata ki te kai raina (`\r\n`).
    ///
    /// He kōwhiringa te mutunga raina whakamutunga.
    /// Ko te aho e mutu ana me te mutunga o te raina whakamutunga ka whakahoki ano i nga raina ano ki tetahi aho penei ka kore e mutu tetahi raina whakamutunga.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Ko te raina whakamutunga kaore e hiahiatia:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// He kaituku hiko i runga i nga raina o te aho.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Whakahokia ai te iterator o `u16` ki runga i te aho kua whakawaeheretia hei UTF-16.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Whakahoki ai i te `true` mena ka uru te tauira ki tetahi waahanga-iti o tenei poro aho.
    ///
    /// Whakahokia `false` ki te kore e te reira.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Whakahoki `true` mena ka uru te tauira ki te kuhimua o tenei poro aho.
    ///
    /// Whakahokia `false` ki te kore e te reira.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Whakahoki ai i te `true` mena ka uru te tauira ki te huringa o tenei poro aho.
    ///
    /// Whakahokia `false` ki te kore e te reira.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Whakahoki ai i te taurangi paita o te tohu tuatahi o tenei poro aho e taurite ana ki te tauira.
    ///
    /// Whakahokia [`None`] ki te kore e ōrite te tauira.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Tauira ngawari:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// He tauira uaua ake ma te whakamahi i te momo korekore-kore me te katinga:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// E kore e te kimi i te tauira:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Whakahokia te taupū paita mo te pūāhua tuatahi o te kēmu rightmost o te tauira i roto i tenei wāhanga aho.
    ///
    /// Whakahokia [`None`] ki te kore e ōrite te tauira.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Tauira ngawari:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// He tauira uaua ake me nga katinga:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// E kore e te kimi i te tauira:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// He taarua i runga i nga taararo o te poro aho nei, he mea wehe na nga tohu e rite ana ki te tauira.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Whanonga Iterator
    ///
    /// Ko te whakamaarama i whakahokia mai ka waiho hei [`DoubleEndedIterator`] mena ka ahei te tauira ki te rapu takahuri me te rapu forward/reverse i nga huanga kotahi.
    /// He tika tenei mo, hei tauira, [`char`], engari kaore mo `&str`.
    ///
    /// Mena ka taea e te tauira te rapu whakamuri engari ko nga hua ka rereke mai i te rapu whakamua, ka taea te whakamahi i te tikanga [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Tauira ngawari:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Mena ko te tauira he poro poro, ka tohaina ki ia mahinga o nga kiripuaki:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// He tauira uaua ake, ma te kati:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Mena he maha nga kaiwhakawehe taapiri kei roto i te aho, ka mutu ka weto nga aho i te putanga:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// E wehea e te aho kau whakawehe pātata.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Ko nga whakawehe i te timatanga, i te mutunga ranei o te aho e piri tata ana ki nga aho kore.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// A, no te whakamahia te aho kau te rite te whakawehe, wehe reira i nga huru i roto i te aho, me te timatanga, me te whakamutunga o te aho.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Ka taea e ngā whakawehe pātata arahi ki whanonga pea maere ina te whakamahia mokowāmā rite te whakawehe.He tika tenei waehere:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// e hoatu te reira i _not_ koutou:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Whakamahia [`split_whitespace`] hoki tenei whanonga.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// He taarua i runga i nga taararo o te poro aho nei, he mea wehe na nga tohu e rite ana ki te tauira.
    /// Rerekē i te iterator whakaputaina e `split` i taua rau `split_inclusive` te wahi ki āu rite te Terminator o te Ahoroto.
    ///
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Mena ka whakataurite te waahanga whakamutunga o te aho, ka kiia ko te waahanga te whakamutu o te taararo o mua.
    /// Ko taua wehenga ko te mea whakamutunga ka whakahokia mai e te kaituku.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// He kaitarai i runga i nga waahanga o te poro aho i wehea, ka wehea e nga kiripuaki e taurite ana ki te tauira ka tuku ki te ota whakamuri.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Whanonga Iterator
    ///
    /// Ko te hoki titau iterator e tautoko ana i te tauira te rapu whakamuri, a ka waiho i te reira he [`DoubleEndedIterator`] ki te hua te rapu forward/reverse te taua huānga.
    ///
    ///
    /// Mo te taatai mai i mua, ka taea te whakamahi i te tikanga [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Tauira ngawari:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// He tauira uaua ake, ma te kati:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// He whakaurunga kei runga i nga waahanga o te poro aho kua wehea, ka wehea e nga kiripuaki e taurite ana ki te tauira.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ōrite ki [`split`], kore ai e Pekepeke ana te Ahoroto makatea te ki te kau.
    ///
    /// [`split`]: str::split
    ///
    /// Ka taea te whakamahi i tēnei tikanga mō te raraunga string e ko _terminated_, nui atu i _separated_ i te tauira.
    ///
    /// # Whanonga Iterator
    ///
    /// Ko te whakamaarama i whakahokia mai ka waiho hei [`DoubleEndedIterator`] mena ka ahei te tauira ki te rapu takahuri me te rapu forward/reverse i nga huanga kotahi.
    /// He tika tenei mo, hei tauira, [`char`], engari kaore mo `&str`.
    ///
    /// Mena ka taea e te tauira te rapu whakamuri engari ko nga hua ka rereke mai i te rapu whakamua, ka taea te whakamahi i te tikanga [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// He taatai i runga i nga tangohanga o `self`, ka wehea e nga kiripuaki e taurite ana ki te tauira ka tuku ki te ota whakamuri.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ōrite ki [`split`], kore ai e Pekepeke ana te Ahoroto makatea te ki te kau.
    ///
    /// [`split`]: str::split
    ///
    /// Ka taea te whakamahi i tēnei tikanga mō te raraunga string e ko _terminated_, nui atu i _separated_ i te tauira.
    ///
    /// # Whanonga Iterator
    ///
    /// Ko te kaitohu kua whakahokia mai me tautoko te tauira i te rapunga whakamuri, a ka rua te mutunga ka puta mai i te rapunga forward/reverse nga ahuatanga ano.
    ///
    ///
    /// Mo te taatai mai i mua, ka taea te whakamahi i te tikanga [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// He iterator mo substrings o te pōro aho homai, wehea e te tauira, whāiti ki hoki mai i te nuinga o ngā tūemi `n`.
    ///
    /// Ki te hoki mai `n` substrings, ka i roto i te Ahoroto whakamutunga (te `Ahoroto n`th) te toenga o te aho.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Whanonga Iterator
    ///
    /// Ko te kaitahuri kua hoki mai nei e kore e oti rua, na te mea kaore e pai ki te tautoko.
    ///
    /// Ki te taea te tauira te rapu whakamuri, ka taea te whakamahi i te tikanga [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Tauira ngawari:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// He tauira uaua ake, ma te kati:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// He kaitarai i runga i nga waahanga o te poro aho nei, he mea wehe mai i tetahi tauira, mai i te pito o te aho, ka aukati ki te whakahoki mai i te nuinga o nga taonga `n`.
    ///
    ///
    /// Ki te hoki mai `n` substrings, ka i roto i te Ahoroto whakamutunga (te `Ahoroto n`th) te toenga o te aho.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Whanonga Iterator
    ///
    /// Ko te kaitahuri kua hoki mai nei e kore e oti rua, na te mea kaore e pai ki te tautoko.
    ///
    /// Mo te wehe mai i mua, ka taea te whakamahi i te tikanga [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Tauira ngawari:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// He tauira uaua ake, ma te kati:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Ka wahia te aho ki te putunga tuatahi o te kaiweutu kua tohua ka whakahoki ano i te kuhimua i mua i te kaiweutu me te taapi i muri i te kaiwehe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Whakawehe te aho i runga i te takanga whakamutunga o te kaiwehe tohua me kuhimua hoki i mua i kaiwehe me pīmuri i muri i kaiwehe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// He iterator mo te ritua ōrite o te tauira i roto i te wāhanga aho homai.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Whanonga Iterator
    ///
    /// Ko te whakamaarama i whakahokia mai ka waiho hei [`DoubleEndedIterator`] mena ka ahei te tauira ki te rapu takahuri me te rapu forward/reverse i nga huanga kotahi.
    /// He tika tenei mo, hei tauira, [`char`], engari kaore mo `&str`.
    ///
    /// Ki te taea te tauira te rapu whakamuri, engari kia rerekē ona hua i te rapu whakamua, e taea te whakamahi i te tikanga [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// He kaitohu i runga i nga taarua wehenga o tetahi tauira o roto i tenei poro aho, i tukuna i runga i te ota whakamuri.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Whanonga Iterator
    ///
    /// Ko te hoki titau iterator e tautoko ana i te tauira te rapu whakamuri, a ka waiho i te reira he [`DoubleEndedIterator`] ki te hua te rapu forward/reverse te taua huānga.
    ///
    ///
    /// Mo te taatai mai i mua, ka taea te whakamahi i te tikanga [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// He kaitohu i nga taarua rereke o tetahi tauira o roto i tenei poro aho me te taupū e tiimata ana te whakataetae.
    ///
    /// Mo nga whakataetae o `pat` kei roto i te `self` e inaki ana, ko nga tohu anake e pa ana ki te whakataetae tuatahi ka whakahokia.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Whanonga Iterator
    ///
    /// Ko te whakamaarama i whakahokia mai ka waiho hei [`DoubleEndedIterator`] mena ka ahei te tauira ki te rapu takahuri me te rapu forward/reverse i nga huanga kotahi.
    /// He tika tenei mo, hei tauira, [`char`], engari kaore mo `&str`.
    ///
    /// Mena ka taea e te tauira te rapu whakamuri engari ko nga hua ka rereke mai i te rapu whakamua, ka taea te whakamahi i te tikanga [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // ko te `aba` tuatahi anake
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// He kaitohu i runga i nga taarua wehenga o tetahi tauira i roto i te `self`, i whakaputaina i runga i te ota whakamuri me te taupū o te keemu.
    ///
    /// Mo nga whakataetae o `pat` kei roto i te `self` e inaki ana, ko nga tohu anake e pa ana ki te tukinga whakamutunga ka whakahokia.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Whanonga Iterator
    ///
    /// Ko te hoki titau iterator e tautoko ana i te tauira te rapu whakamuri, a ka waiho i te reira he [`DoubleEndedIterator`] ki te hua te rapu forward/reverse te taua huānga.
    ///
    ///
    /// Mo te taatai mai i mua, ka taea te whakamahi i te tikanga [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // ko te `aba` whakamutunga anake
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Returns te wāhanga string ki ārahi me te autō mokowāmā nekehia.
    ///
    /// 'Whitespace' kua tautuhia kia rite ki nga tikanga o te Unicode I ahu mai i te Rawa Taonga `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Whakahokia ai tetahi poro aho ka tangohia atu te waahi maamaatea.
    ///
    /// 'Whitespace' kua tautuhia kia rite ki nga tikanga o te Unicode I ahu mai i te Rawa Taonga `White_Space`.
    ///
    /// # Aronga Kuputuhi
    ///
    /// He aho ko te raupapa o paita.
    /// `start` i roto i tenei horopaki te tikanga ko te tuunga tuatahi o tera aho paita;mo te reo maui-ki-matau penei i te Ingarihi, i te Ruhia ranei, ka taha maui tenei, a mo nga reo matau-ki-maui penei me te Arapi, te Hiperu ranei, koinei te taha matau.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Returns te wāhanga string ki autō mokowāmā nekehia.
    ///
    /// 'Whitespace' kua tautuhia kia rite ki nga tikanga o te Unicode I ahu mai i te Rawa Taonga `White_Space`.
    ///
    /// # Aronga Kuputuhi
    ///
    /// He aho ko te raupapa o paita.
    /// `end` i roto i tenei horopaki te tikanga o te tuunga whakamutunga o tera aho paita;mo te reo mahue-ki-matau rite English Russian ranei, ka hei te taha matau tenei, me hoki ngā reo tika-ki-mahue rite Arabic Hiperu ranei, ka waiho i te taha ki maui tenei.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Whakahokia ai tetahi poro aho ka tangohia atu te waahi maamaatea.
    ///
    /// 'Whitespace' kua tautuhia kia rite ki nga tikanga o te Unicode I ahu mai i te Rawa Taonga `White_Space`.
    ///
    /// # Aronga Kuputuhi
    ///
    /// He aho ko te raupapa o paita.
    /// 'Left' i roto i tenei horopaki te tikanga ko te tuunga tuatahi o tera aho paita;mo te reo rite Arabic Hiperu ranei e he 'tika ki mahue', nui atu i 'mahue ki matau', ka waiho i te taha _right_, e kore te maui tenei.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Returns te wāhanga string ki autō mokowāmā nekehia.
    ///
    /// 'Whitespace' kua tautuhia kia rite ki nga tikanga o te Unicode I ahu mai i te Rawa Taonga `White_Space`.
    ///
    /// # Aronga Kuputuhi
    ///
    /// He aho ko te raupapa o paita.
    /// 'Right' i roto i tenei horopaki tikanga te tūranga whakamutunga o taua paita aho;mo te reo rite Arabic Hiperu ranei e he 'tika ki mahue', nui atu i 'mahue ki matau', ka waiho i te taha _left_, e kore te tika tenei.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Whakahokia ai he poro aho me nga kuhimua katoa me nga taapi e taurite ana ki te tauira ka tangohia tonutia.
    ///
    /// Ka taea e te [pattern] te [`char`], te poro o te [`char`] s, te mahi, te kati ranei e whakatau ana mena e taurite ana te tangata.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Tauira ngawari:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// He tauira uaua ake, ma te kati:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Kia maumahara ki nga whakaari mohio o mua, whakatikahia i raro mena
            // he rereke te tukinga whakamutunga
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` e mohiotia ana ka hoki mai nga tohu whaihua.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Whakahokia ai he poro aho me nga kuhimua katoa e taurite ana ki te tauira ka tangohia tonutia.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Aronga Kuputuhi
    ///
    /// He aho ko te raupapa o paita.
    /// `start` i roto i tenei horopaki te tikanga ko te tuunga tuatahi o tera aho paita;mo te reo maui-ki-matau penei i te Ingarihi, i te Ruhia ranei, ka taha maui tenei, a mo nga reo matau-ki-maui penei me te Arapi, te Hiperu ranei, koinei te taha matau.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SAFETY: `Searcher` e mohiotia ana ka hoki mai nga tohu whaihua.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Whakahokia te wāhanga string ki te kuhimua nekehia.
    ///
    /// Mena ka tiimata te aho ki te tauira `prefix`, ka hoki mai ano i te tuaina whai muri i te kuhimua, ka takaia ki te `Some`.
    /// Kaore i rite ki te `trim_start_matches`, ka tango tenei tikanga i te kuhimua kia kotahi te wa.
    ///
    /// Mena kaore i te tiimata te aho ki te `prefix`, whakahokia te `None`.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Whakahokia ai he poro aho ka tangohia te whakakapi.
    ///
    /// Mena ka mutu te aho me te tauira `suffix`, whakahokia te taapiri i mua i te whakakapi, ka takaia ki te `Some`.
    /// Kaore i rite ki te `trim_end_matches`, ko tenei tikanga ka tangohia te whakakapi i te wa kotahi.
    ///
    /// Mena kaore e mutu te aho ki te `suffix`, whakahokia te `None`.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Whakahokia ai he poro aho me nga taapi katoa e taurite ana ki te tauira ka tangohia tonutia.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Aronga Kuputuhi
    ///
    /// He aho ko te raupapa o paita.
    /// `end` i roto i tenei horopaki te tikanga o te tuunga whakamutunga o tera aho paita;mo te reo mahue-ki-matau rite English Russian ranei, ka hei te taha matau tenei, me hoki ngā reo tika-ki-mahue rite Arabic Hiperu ranei, ka waiho i te taha ki maui tenei.
    ///
    ///
    /// # Examples
    ///
    /// Tauira ngawari:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// He tauira uaua ake, ma te kati:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` e mohiotia ana ka hoki mai nga tohu whaihua.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Whakahokia ai he poro aho me nga kuhimua katoa e taurite ana ki te tauira ka tangohia tonutia.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Aronga Kuputuhi
    ///
    /// He aho ko te raupapa o paita.
    /// 'Left' i roto i tenei horopaki te tikanga ko te tuunga tuatahi o tera aho paita;mo te reo rite Arabic Hiperu ranei e he 'tika ki mahue', nui atu i 'mahue ki matau', ka waiho i te taha _right_, e kore te maui tenei.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Whakahokia ai he poro aho me nga taapi katoa e taurite ana ki te tauira ka tangohia tonutia.
    ///
    /// Ka taea e te [pattern] e he `&str`, [`char`], he wāhanga o [`char`] s, ranei te mahi katinga ranei e whakatau, ki te he kēmu pūāhua.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Aronga Kuputuhi
    ///
    /// He aho ko te raupapa o paita.
    /// 'Right' i roto i tenei horopaki tikanga te tūranga whakamutunga o taua paita aho;mo te reo rite Arabic Hiperu ranei e he 'tika ki mahue', nui atu i 'mahue ki matau', ka waiho i te taha _left_, e kore te tika tenei.
    ///
    ///
    /// # Examples
    ///
    /// Tauira ngawari:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// He tauira uaua ake, ma te kati:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Ka parea tenei aho ki tetahi atu momo.
    ///
    /// Na te mea he whanui te `parse`, ka raru pea te ahua o te momo.
    /// Ka rite ki taua, `parse` ko tetahi o nga wa torutoru ka kite koe i te wetereo e mōhio whānuitia rite te 'turbofish': `::<>`.
    ///
    /// Ma tenei e maarama ai te whakamaarama algorithm kia tohu ko te momo e hiahia ana koe ki te wetewete.
    ///
    /// `parse` Ka taea e poroporo ki tetahi momo e whakatinana te [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Ka whakahokia mai a [`Err`] ki te kore e taea te wehe i tenei waahanga ki roto i te momo e hiahiatia ana.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Whakamahi taketake
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Mā te whakamahi i te 'turbofish' hei utu o te whakakaupapa `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Oreraa ki Poroporo:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Arowhai ki te he i roto i te whānuitanga ASCII pūāhua katoa i roto i tenei aho.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Ka taea e taatau te whakarite i ia paita hei taera i konei: ko nga taatai multibyte katoa ka tiimata me te paita kaore i te awhe o te taiao, na reira ka mutu taatau i reira.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Ka tirohia e rua nga aho he taarua-kore aro ki te ASCII.
    ///
    /// He rite tonu ki te `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, engari kaore e tohatoha ana me te kape i nga waahanga poto.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Ka huri tenei aho ki tona ASCII take nui e taurite ana ki te waahi.
    ///
    /// Ko nga reta ASCII 'a' ki 'z' ka maherehia ki te 'A' ki te 'Z', engari ko nga reta kore ASCII kaore i whakarereke.
    ///
    /// Hei whakahoki i tetahi uara taapiri hou me te kore e whakarereke i tetahi, whakamahia [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // HAUMARU: haumaru no te mea ai ā matou e rua ngā momo ki te tahora taua.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Ka huri tenei aho ki tana ASCII take iti iho e rite ana i te waahi.
    ///
    /// Ko nga reta ASCII 'A' ki 'Z' ka maherehia ki te 'a' ki te 'z', engari ko nga reta kore ASCII kaore i whakarereke.
    ///
    /// Hei hoki i tētahi uara lowercased hou i waho te whakakē i te kotahi ngā, te whakamahi i [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // HAUMARU: haumaru no te mea ai ā matou e rua ngā momo ki te tahora taua.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Whakahokihia he miihini ka mawhiti i ia char i te `self` me te [`char::escape_debug`].
    ///
    ///
    /// Note: ko nga waehere grapheme anake kua whakarahihia ka tiimata te mawhiti ka mawhiti.
    ///
    /// # Examples
    ///
    /// Ka rite ki te iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mā te tika `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// He orite enei e rua ki:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Ma te `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Whakahokihia he miihini ka mawhiti i ia char i te `self` me te [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Ka rite ki te iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mā te tika `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// He orite enei e rua ki:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Ma te `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Hoki he iterator e mawhiti ia char i `self` ki [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Ka rite ki te iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mā te tika `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// He orite enei e rua ki:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Ma te `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Hangaia ai he str kau
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Ka waihanga te Str mutable kau
    #[inline]
    fn default() -> Self {
        // SAFETY: Ko te aho putu he whaimana UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// He nameable, momo FN cloneable
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SAFETY: kaore e haumaru
        unsafe { from_utf8_unchecked(bytes) }
    };
}