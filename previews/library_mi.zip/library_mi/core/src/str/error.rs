//! He tautuhi i te momo hapa utf8.

use crate::fmt;

/// Nga he ka taea i te wa e ngana ana ki te whakamaori i te raupapa o [`u8`] hei taura.
///
/// I penei, ko te whanau `from_utf8` o nga mahi me nga tikanga mo te [String`] s me te [`&str`] ka whakamahi i tenei hapa, hei tauira.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Ka taea te whakamahi i nga tikanga o tenei momo hapa ki te hanga mahi rite ki te `String::from_utf8_lossy` me te kore e tohaina te puranga puranga:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Hoki te taupū roto i te aho i homai ki runga ki te mea i manatoko tika UTF-8.
    ///
    /// Ko te taupū nui rawa atu penei ka whakahokia mai e `from_utf8(&input[..index])` te `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// use std::str;
    ///
    /// // etahi paita muhu, i te vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 whakahoki he Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // te paita tuarua kaore i te tika i konei
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Ka whakarato i etahi atu korero mo te ngoikoretanga:
    ///
    /// * `None`: te mutunga o te whakauru kua tae ohorere atu.
    ///   `self.valid_up_to()` he 1 ki te 3 paita mai i te mutunga o te whakauru.
    ///   Ki te te te decoded te awa paita (pēnei i te kōnae he turanga whatunga ranei) otirā, tenei i taea e waiho he `char` whaimana nei UTF-8 paita raupapa e puta noa tamâraa maha.
    ///
    ///
    /// * `Some(len)`: i puta tetahi paita ohorere.
    ///   Ko te roa e hoatuhia ana ko te raupapa paita muhu e tiimata ana mai i te tohu i hoatu e `valid_up_to()`.
    ///   Me mahi ano te whakawaahuatanga i muri o tera raupapa (i muri i te whakauru i te [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) mena ka ngoikoretanga te tango.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// I hoki mai he hapa i te wa ka kore te whiu i te `bool` ma te [`from_str`]
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}