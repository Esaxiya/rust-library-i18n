//! Nga huarahi hei hanga `str` mai i te poro poro paita.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Tahuri ai te wāhanga o paita ki te wāhanga string.
///
/// He wāhanga string hanga ([`&str`]) te o bytes ([`u8`]), me te wāhanga paita hanga ([`&[u8]`][byteslice]) te o paita, na tenei mahi faafariu i waenganui i te rua.
/// Ehara ko nga poro byte katoa he poro aho tika, heoi: [`&str`] me UTF-8 te mana.
/// `from_utf8()` arowhai ki te whakarite kia te paita e tika UTF-8, a ka mahi i te faafariuraa.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Mena e mohio ana koe he tika te poro byte UTF-8, ana kaore koe e hiahia kia kaha ake te tirotiro o te haki tika, he putanga kore mo tenei mahi, [`from_utf8_unchecked`], he peera ano ona ahua engari ka pekehia te haki.
///
///
/// Mena e hiahia ana koe ki te `String` kaore i te `&str`, whakaarohia te [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Na te mea ka taea e koe te taapiri-toha i te `[u8; N]`, a ka taea e koe te tango i te [`&[u8]`][byteslice], ko tenei mahi tetahi huarahi kia whai aho toha-tohaina.He tauira tenei mo nga tauira tauira i raro ake nei.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Whakahoki ai i te `Err` mena kaore te poro i te UTF-8 me te whakaahuatanga he aha i kore ai te poro i te UTF-8.
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::str;
///
/// // etahi paita, i roto i te vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // E matau ana tatou he tika enei paita, na noa te whakamahi i `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Paita hē:
///
/// ```
/// use std::str;
///
/// // etahi paita muhu, i te vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Tirohia nga tuhinga mo [`Utf8Error`] mo nga korero taipitopito mo nga momo hapa ka taea te whakahoki.
///
/// He "stack allocated string":
///
/// ```
/// use std::str;
///
/// // etahi paita, i roto i te ngohi tāpae-tohaina
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // E matau ana tatou he tika enei paita, na noa te whakamahi i `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Katahi ano ka whakamana.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Ka huri i tetahi waahanga paita e taea te whakarereke ki te poro aho e taea te whakarereke.
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" hei vector mutable
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Ka rite ki matau ana tatou he tika enei paita, ka taea e tatou te whakamahi i `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Paita hē:
///
/// ```
/// use std::str;
///
/// // Ko etahi paita muhu i te vector huri noa
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Tirohia nga tuhinga mo [`Utf8Error`] mo nga korero taipitopito mo nga momo hapa ka taea te whakahoki.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Katahi ano ka whakamana.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Ka huri i tetahi waahanga paita ki tetahi poro aho me te kore e tohu he UTF-8 te aho o te aho.
///
/// Tirohia te putanga ahuru, [`from_utf8`], mo te roanga atu o nga korero.
///
/// # Safety
///
/// Ko tenei mahi kaore i te ahuru na te mea kaore e tirohia mena nga paita i tukuna ki a ia he tika UTF-8.
/// Mena kua takahia tenei herenga, kaore e tautuhia nga whanonga, na te mea ko te toenga o te Rust e kii ana he [X&XX] te mana o te UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::str;
///
/// // etahi paita, i roto i te vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SAFETY: me kii te kaiwaea ko nga paita `v` he tika UTF-8.
    // Ka whakawhirinaki hoki ki te `&str` me te `&[u8]` he rite te whakatakotoranga.
    unsafe { mem::transmute(v) }
}

/// Tahuri ai te wāhanga o paita ki te wāhanga string kahore te arowhai e kei te aho whaimana UTF-8;putanga mutable.
///
///
/// Tirohia te waahanga kaore e taea te whakarereke, [`from_utf8_unchecked()`] mo etahi atu korero.
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SAFETY: te kī pau kaiwaea e te paita `v`
    // He tika UTF-8, ko te kupu ko haumaru te maka ki `*mut str`.
    // Ano hoki, he ahuru te kore e tohu ki te tohu tohu na te mea he tohu tera e tohu ana he tika mo nga tuhinga.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}