#![stable(feature = "core_hint", since = "1.27.0")]

//! Tīwhiri ki taupatupatu e pā pehea kia tukuna waehere papaitia ranei.
//! He tohu ranei te whakahiato i te waa, te waahi ranei.

use crate::intrinsics;

/// Ngā te taupatupatu e kore he reachable tenei wāhi i roto i te waehere, taea atu optimizations.
///
/// # Safety
///
/// Ko te whakatutuki i tenei mahi he tino *whanonga kore tautuhi*(UB).I roto i ngā, riro te taupatupatu e kore me tupu UB katoa, a reira ka faaore manga katoa e taea ki te karanga ki a `unreachable_unchecked()`.
///
/// Ka rite ki ngā wā katoa o UB, ki te tahuri atu i tenei whakaaro ki te kia he, arā, ko te mau reachable roto rere mana katoa taea te karanga `unreachable_unchecked()`, ka tono te taupatupatu te rautaki arotautanga he, a kia ētahi wā noa kino waehere ngali auauhia, meinga difficult-raruraru ki-patuiro.
///
///
/// Whakamahia tenei mahi anake ka taea e koe te whakamatautau e kore e karanga ai te waehere.
/// Te kore, whakaaro te whakamahi i te tonotono [`unreachable!`], e kore nei e tuku i optimizations engari ka panic ka mahi i.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` he pai nga wa katoa (kore kore), i konei `checked_div` kore e hoki mai `None`.
/////
///     // Na reira, he ūnga atu te branch.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SAFETY: te kirimana haumaru mō te pau `intrinsics::unreachable`
    // kia tautoko ake e te kaiwaea.
    unsafe { intrinsics::unreachable() }
}

/// E faatae mai te ako mīhini ki te tohu i te pūtukatuka e te rere i te reira i roto i te pukumahi-whanga whatu-koropiko ("maukati miro").
///
/// Ki runga ki te fariiraa i te tohu whatu-koropiko te pūtukatuka taea arotau tona whanonga e, hei tauira, te mana whakaora ranei whakawhiti hyper-miro.
///
/// He rerekē i [`thread::yield_now`] tenei mahi e hua tika ki Pūhōtaka o te pūnaha, te mea kahore `spin_loop` e pāhekoheko ki te pūnaha whakahaere.
///
/// He take whakamahi noa mō te `spin_loop` te whakatinana rohe pōtaka fakatu'amelie i roto i te koropiko CAS i roto i primitives tukutahitanga.
/// Ki raruraru faka'ehi'ehi rite matua koaro, kei te kaha tūtohu reira e poroa te koropiko whatu kei te i muri i te nui tahuti o tāruarua, me te hanga i te syscall ārai tika te.
///
///
/// **Panui**: I nga paparanga kaore e tautoko i te whiwhi tohu-koropiko tohu kore tenei mahi e mahi i tetahi mea.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // He uara ngota ngā e ka whakamahi aho ki ruruku
/// let live = Arc::new(AtomicBool::new(false));
///
/// // I roto i te miro papamuri ka whakaritea e maatau te uara
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Mahia etahi mahi, ka ora ai te uara
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Hoki i runga i to tatou miro nāianei, tatari tatou hoki ki te uara hei huinga
/// while !live.load(Ordering::Acquire) {
///     // Ko te koropiko hurihuri he tohu ki te PTM e tatari ana tatou, engari akene kaore pea mo te wa roa
/////
///     hint::spin_loop();
/// }
///
/// // Kei te whakaturia te uara i teie nei
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SAFETY: te attr fakapapau'i `cfg` e tatou anake mahia tenei i runga i ngā taumata x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SAFETY: te attr fakapapau'i `cfg` e tatou anake mahia tenei i runga i ngā taumata x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SAFETY: ko te tohu `cfg` e whakarite ana ka mahia noa tenei i runga i nga whaainga aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SAFETY: ma te `cfg` e whakarite kia mahia noa e taatau nga mahi a te ringaringa
            // me te tautoko mo te waahanga v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// He mahi tuakiri e *__ tīwhiri __* ki te taupatupatu, ki te kia maximally fakatu'atamaki e pā ana ki te mea `black_box` taea mahi.
///
/// Rerekē [`std::convert::identity`], ākina te taupatupatu Rust te ki te amo i taua taea `black_box` whakamahi `dummy` i tetahi ara whaimana taea e whakaaetia te Rust waehere ki waho te whakauru whanonga kāore i roto i te waehere piiraa.
///
/// Ma tenei kaainga e whai kiko ai te `black_box` mo te tuhi waehere kaore e hiahiatia ana nga waahanga pai, penei i nga tohu tohu.
///
/// Kia mōhio Heoi, e `black_box` he anake (a taea anake te) ngā i runga i te pūtake "best-effort".Ko te whanui ka taea e ia te aukati i te maaramatanga kia rerekee i runga i te turanga me te waehere-ira kua whakamahia.
/// Kaore e taea e nga papatono te whakawhirinaki ki te `black_box` mo te *tika* ahakoa te aha.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // E ti'a ia tatou ki "use" te tautohe i roto i te tahi mau ara LLVM taea kore introspect, a ki runga ki ngā taumata e tautoko reira e nehenehe e tatou te nuinga huanga rōrārangi hahi ki te mahi i tenei.
    // Ko te whakamaoritanga a LLVM mo te huihuinga whakaroto he, he pouaka pango.
    // E kore te mea tenei te whakatinanatanga nui mai pea te reira deoptimizes atu atu matou e hiahia ana, engari te reira na tawhiti nui pai.
    //
    //

    #[cfg(not(miri))] // He tohu noa tenei, no reira he pai ki te peke atu ki Miri.
    // SAFETY: ko te huihuinga o te raarangi he-kore.
    unsafe {
        // FIXME: Kaore e taea te whakamahi i te `asm!` na te mea kaore e tautoko i te MIPS me etahi atu hoahoanga.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}