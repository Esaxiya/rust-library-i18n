#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Ma te `RawWaker` e ahei ki te kaiwhakauru i tetahi kaitoha mahi te hanga [`Waker`] e whakarato ana i te whanonga whakaoho ake.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Kei roto he tohu tohu me tetahi [virtual function pointer table (vtable)][vtable] e whakarite ana i te whanonga o te `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// He tohu tohu, ka taea te penapena i nga korero taapiri e hiahiatia ana e te kaitohutohu.
    /// Akene he tauira tenei
    /// he tohu tohu-kua horoia ki te `Arc` e hono ana ki tenei mahi.
    /// Ko te uara o tenei mara ka paahitia ki nga taumahi katoa kei roto i te waahanga tae atu ki te waahanga tuatahi.
    ///
    data: *const (),
    /// tepu atatohu mahi mariko e Whakaritea te whanonga o tenei waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Ka hangaia he `RawWaker` hou mai i te tohu atawhai `data` me te `vtable`.
    ///
    /// Ka taea te whakamahi i te atatohu `data` ki te penapena i nga korero taapiri e hiahiatia ana e te kaitohutohu.Tenei i taea e kia tauira
    /// he tohu tohu-kua horoia ki te `Arc` e hono ana ki tenei mahi.
    /// Ko te uara o tenei tohu ka tukuna ki nga mahi katoa he waahanga o te `vtable` hei waahanga tuatahi.
    ///
    /// Ko te `vtable` Whakaritea te whanonga o te `Waker` tangata hanga nei i te `RawWaker`.
    /// Mo ia mahinga i te `Waker`, ka karangahia te mahi e pa ana ki te `vtable` o te `RawWaker` kei raro.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// He teepu atawhai tohu mariko (vtable) e tohu ana i te whanonga o te [`RawWaker`].
///
/// I tukuna te tohu ki nga mahi katoa kei roto i te papapu ko te tohu `data` mai i te mea [`RawWaker`] kati.
///
/// E anake te tikanga te mahi i roto i tenei struct kia huaina ki runga i te atatohu `data` o te ahanoa [`RawWaker`] tika hangaia i roto i te whakatinanatanga [`RawWaker`].
/// Ma te piihia tetahi o nga mahi kei roto ma te whakamahi i tetahi atu tohu tohu `data` ka kore e tautuhia te whanonga.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Ka karangahia tenei mahi ka tohaina te [`RawWaker`], hei tauira ina tae mai te [`Waker`] e penapena ai te [`RawWaker`] ka tohaina.
    ///
    /// Ko te whakatinanatanga o tenei mahi me pupuri nga rauemi katoa e hiahiatia ana mo tenei waahanga taapiri o te [`RawWaker`] me nga mahi e hono ana.
    /// Ko te karanga i te `wake` i runga i te [`RawWaker`] e hua ana ka ara ake ano taua mahi ka whakaohohia e te [`RawWaker`] taketake.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Ka karangahia tenei mahi ka karangahia a `wake` i te [`Waker`].
    /// Me whakaoho te mahi e hono ana ki tenei [`RawWaker`].
    ///
    /// Me kia ki te tuku i tetahi rauemi e kua e pā ana ki tenei tauira o te [`RawWaker`] me mahi whai pānga te whakatinanatanga o tenei mahi.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Ka tenei mahi e huaina ka huaina `wake_by_ref` ko i runga i te [`Waker`].
    /// Me whakaoho te mahi e hono ana ki tenei [`RawWaker`].
    ///
    /// He rite tenei mahi ki te `wake`, engari kaua e pau i te tohu tohu kua whakaritea.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Ka karangahia tenei mahi ka heke ana te [`RawWaker`].
    ///
    /// Me kia ki te tuku i tetahi rauemi e kua e pā ana ki tenei tauira o te [`RawWaker`] me mahi whai pānga te whakatinanatanga o tenei mahi.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Ka hangaia he `RawWakerVTable` hou mai i nga mahi `clone`, `wake`, `wake_by_ref`, me `drop` kua hoatuhia.
    ///
    /// # `clone`
    ///
    /// Ka karangahia tenei mahi ka tohaina te [`RawWaker`], hei tauira ina tae mai te [`Waker`] e penapena ai te [`RawWaker`] ka tohaina.
    ///
    /// Ko te whakatinanatanga o tenei mahi me pupuri nga rauemi katoa e hiahiatia ana mo tenei waahanga taapiri o te [`RawWaker`] me nga mahi e hono ana.
    /// Ko te karanga i te `wake` i runga i te [`RawWaker`] e hua ana ka ara ake ano taua mahi ka whakaohohia e te [`RawWaker`] taketake.
    ///
    /// # `wake`
    ///
    /// Ka karangahia tenei mahi ka karangahia a `wake` i te [`Waker`].
    /// Me whakaoho te mahi e hono ana ki tenei [`RawWaker`].
    ///
    /// Me kia ki te tuku i tetahi rauemi e kua e pā ana ki tenei tauira o te [`RawWaker`] me mahi whai pānga te whakatinanatanga o tenei mahi.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Ka tenei mahi e huaina ka huaina `wake_by_ref` ko i runga i te [`Waker`].
    /// Me whakaoho te mahi e hono ana ki tenei [`RawWaker`].
    ///
    /// He rite tenei mahi ki te `wake`, engari kaua e pau i te tohu tohu kua whakaritea.
    ///
    /// # `drop`
    ///
    /// Ka karangahia tenei mahi ka heke ana te [`RawWaker`].
    ///
    /// Me kia ki te tuku i tetahi rauemi e kua e pā ana ki tenei tauira o te [`RawWaker`] me mahi whai pānga te whakatinanatanga o tenei mahi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Ko te `Context` o te mahi hototahi.
///
/// I tenei wa, ka whakamahia noa e `Context` te urunga ki te `&Waker` ka taea te whakamahi hei whakaoho i nga mahi o naianei.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // tatou whakarite future-tohu ki huringa whawhai mā te akina te ora ki te hei pūmau (he contravariant ra katoa tautohe-tūranga i he covariant ra katoa hoki-tūnga).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Hangaia he `Context` hou mai i te `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Whakahoki ai i te tohutoro ki te `Waker` mo nga mahi onaianei.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// He `Waker` Ko te kakau mo fafangu ake he mahi mā te whakamōhio tona whakahaere e he reira rite ki te kia rere.
///
/// Tenei kakau e kapo ake te tauira [`RawWaker`], e tautuhi ana i te whanonga ohonga whakahaere-motuhake.
///
///
/// Ka whakatinana i te [`Clone`], [`Send`], me te [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Oho ake i te mahi e pā ana ki tenei `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Ko te waeatanga oho ake ka tohaina ma te waeatanga mahi mariko ki te whakatinana kua tautuhia e te kai-kawe.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Kaua e karanga `drop`-ka pau i te oho te `wake`.
        crate::mem::forget(self);

        // SAFETY: He haumaru tenei na te mea ko te `Waker::from_raw` anake te huarahi
        // hei arahi i te `wake` me te `data` me whakahau te kaiwhakamahi kia mau te kirimana o `RawWaker`.
        //
        unsafe { (wake)(data) };
    }

    /// Whakaaraahia te mahi e pa ana ki tenei `Waker` me te kore e pau i te `Waker`.
    ///
    /// He orite tenei ki te `wake`, engari akene he iti ake te mahi i te wa e waatea ana he `Waker` rangatira.
    /// kia tenei tikanga kia meinga ki te karanga `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Ko te waeatanga oho ake ka tohaina ma te waeatanga mahi mariko ki te whakatinana kua tautuhia e te kai-kawe.
        //

        // SAFETY: kite `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Whakahoki `true` mena tenei `Waker` me tetahi `Waker` kua whakaoho i taua mahi ano.
    ///
    /// mahi tēnei mahi i runga i te pūtake pai-kaha, a kia hoki mai teka noa, no te e te faaara i te `Waker`s te mahi taua.
    /// Heoi, ki te hoki mai tenei mahi `true`, ka tutuki te mahi ka whakaohohia e te `Waker` taua mahi ano.
    ///
    /// Kei te matua tenei mahi e whakamahia ana mō ngā take arotautanga.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Ka hangaia he `Waker` hou mai i te [`RawWaker`].
    ///
    /// koretautuhi te whanonga o te `Waker` hoki te ki te kore te te kirimana tautuhia i roto i [`RawWaker`] 'o me [`RawWakerVTable`]' o tuhinga i tautoko.
    ///
    /// Na reira ko te haumaru tenei tikanga.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SAFETY: He haumaru tenei na te mea ko te `Waker::from_raw` anake te huarahi
            // hei arahi i te `clone` me te `data` me whakahau te kaiwhakamahi kia mau te kirimana o [`RawWaker`].
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SAFETY: He haumaru tenei na te mea ko te `Waker::from_raw` anake te huarahi
        // ki te arawhiti `drop` ko `data` tono te kaiwhakamahi ki te whakaae tautoko ake e te te kirimana o `RawWaker`.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}