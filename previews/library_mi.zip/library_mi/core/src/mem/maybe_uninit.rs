use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// He momo Uwhi ki te hanga wā Korearawhiti o `T`.
///
/// # arawhitinga pūmau
///
/// Ko te kaiwhakaputu, i te nuinga o te waa, e kii ana he taunga ke te tiimata mai i nga whakaritenga o te momo taurangi.Hei tauira, me hāngai te tāupe o te momo tohutoro me te korengia-kore.
/// Ko te pūmau e Me tautokona *tonu*, ara i roto i te waehere haumaru tenei.
/// Ka rite ki te putanga, kore-arawhiti he tāupe o momo tohutoro ai inamata [undefined behavior][ub], kahore he mea ahakoa taua tohutoro ake tangata whakamahia ki te pūmahara uru:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // whanonga kāore!⚠️
/// // Te waehere ōrite ki `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // whanonga kāore!⚠️
/// ```
///
/// whakamahia ana tēnei e te taupatupatu mo te ngā optimizations, pērā i eliding arowhai oma-wā, me te mä tahora `enum`.
///
/// Waihoki, kia whai i tetahi ihirangi mahara katoa Korearawhiti, i te `bool` kia `true` `false` ranei tonu.No reira, te hanga i tētahi `bool` Korearawhiti he whanonga kāore:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // whanonga kāore!⚠️
/// // Te waehere ōrite ki `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // whanonga kāore!⚠️
/// ```
///
/// Ano, he motuhake mahara Korearawhiti i roto i taua e kore e whai te reira i te uara pūmau ("fixed" tikanga "it won't change without being written to").Pānui i te paita Korearawhiti wa maha taua taea hoatu hua rerekē.
/// hanga tenei koretautuhi reira whanonga ki te whai raraunga Korearawhiti i roto i te tāupe noa, ki te he momo tōpū, e kore e taea te pupuri i tetahi tauira moka * * whakaritea e tāupe:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // whanonga kāore!⚠️
/// // Ko te waehere rite ki te `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // whanonga kāore!⚠️
/// ```
/// (Kia mahara kaore ano kia whakaotihia nga ture mo nga integers kaore ano kia whakamanahia, engari kia oti ra ano, ko te tohutohu kia karohia.)
///
/// I runga o taua, mahara e te nuinga o ngā momo whai invariants atu tua atu noa te whakaaro arawhiti i te taumata momo.
/// Hei tauira, ko te `1`-tiimata [`Vec<T>`] ka whakaarohia (i raro i te whakatinanatanga o tenei wa; kaore tenei i te pumau o te taurangi) na te mea ko te whakaritenga anake e mohio ana te kaiwhakaputa ko te tohu o nga raraunga me whakakore.
/// Te hanga taua he `Vec<T>` e kore take *whanonga kāore* tonu, engari ka meinga whanonga kāore ki te nuinga ngā mahi haumaru (tae atu iho i te reira).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` kaimahi ki te taea ai waehere haumaru ki te mahi ki raraunga Korearawhiti.
/// Ko te tohu ki te taupatupatu tohu kia kore * * e arawhiti te raraunga konei:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Waihanga i te tohutoro āta Korearawhiti.
/// // Kei te mohio te kaiwhakaputa ko nga raraunga kei roto i te `MaybeUninit<T>` he pea he tika, na reira ehara tenei i te UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Whakaturia ana e ia ki te uara tika.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Unuhia te raraunga arawhitia-tenei *e whakaaetia anake i muri i* tika arawhiti `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Ko te taupatupatu ka matau ki te kore hanga i tetahi whakapae hē optimizations ranei i runga i tenei waehere.
///
/// Ka taea e koe te whakaaro ko te `MaybeUninit<T>` he ahua rite ki te `Option<T>` engari kaore he kaupapa aroturukinga mo te waa-rere me te kore o nga arowhai ahuru.
///
/// ## out-pointers
///
/// Ka taea e koe te whakamahi i `MaybeUninit<T>` ki te whakatinana i "out-pointers": hei utu o hoki mai raraunga i te mahi, haere reira he atatohu ki etahi mahara (uninitialized) ki te hoatu i te hua ki.
/// taea e tenei whai hua i te mea e nui hoki te kaiwaea ki te mana pehea te mahara kei te rongoa te hua i roto i te tangata e whakaritea, me te hiahia koe ki te karo i nekehanga faufaa.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` kaore e maturuturu nga korero tawhito, he mea nui.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Inaianei kua mohio taatau kua tiimata te `v`!Ma tenei ka tino heke te vector.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Kei te tiimata i te huanga huanga-ma-te huanga
///
/// `MaybeUninit<T>` Ka taea te whakamahi ki te arawhiti te ngohi nui huānga-e-huānga:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Waihanga i te ngohi Korearawhiti o `MaybeUninit`.
///     // He haumaru te `assume_init` no te momo e kī tatou ki kua arawhitia konei ko te paihere o `MaybeUninit`s, e kore e nei rapua e arawhiti.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Iho i te `MaybeUninit` e tetahi mea.
///     // Ko te kupu te whakamahi i taumahi atatohu raw hei utu o te kore e `ptr::write` meinga te uara Korearawhiti tawhito ki te kia maturuturu iho.
/////
///     // Hoki, ki te reira ko te panic i roto i tenei koropiko, to tatou he turuturu mahara, engari i reira he kahore take haumaru mahara.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Kua tiimata nga mea katoa.
///     // Ai ā te ngohi ki te momo arawhiti.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Ka taea hoki te mahi ki ngā huānga wāhanga arawhitia, e taea te kitea i roto i datastructures taumata-iti.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Waihanga i te ngohi Korearawhiti o `MaybeUninit`.
/// // He haumaru te `assume_init` no te momo e kī tatou ki kua arawhitia konei ko te paihere o `MaybeUninit`s, e kore e nei rapua e arawhiti.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Tatauria te maha o nga waahanga kua tohaina e matou.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Hoki ia tūemi i roto i te ngohi, maturuturu ki te tohaina matou i te reira.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Arawhiti ana i te mara-e-mara struct
///
/// Ka taea e koe te whakamahi i te `MaybeUninit<T>`, me te tonotono [`std::ptr::addr_of_mut`], hei arahi i nga waahanga hangahanga i te mara:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Arawhiti ana i te `name` mara
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Te tiimata i te mara `list` Mena he panic kei konei, katahi te `String` kei roto i nga riu o te `name`.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Kua arawhitia te mara katoa, na karanga matou `assume_init` ki te tiki i te Foo arawhitia.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` Kei te kī taurangi ki te whai i te rahi taua, tīaroaro, a Abi rite `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Heoi mahara e te momo *kei* kore te mea tika he `MaybeUninit<T>` te tahora taua;Rust kore e roto i te kī whānui e whai nga mara o te `Foo<T>` te tikanga taua rite te `Foo<U>` noa, ki te `T` ko `U` i te rahi taua, me te tīaroaro.
///
/// I tua atu no te mea he tika tetahi uara moka mo te `MaybeUninit<T>` e kore e taea e te taupatupatu tono non-zero/niche-filling optimizations, pea hua i roto i te rahi nui:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ki te he FFI-haumaru `T`, na pera ko `MaybeUninit<T>`.
///
/// Ahakoa `MaybeUninit` Ko `#[repr(transparent)]` (tohu wakaae reira te rahi taua, tīaroaro, a Abi rite `T`), e tenei *kore* huri i tetahi o nga reehita o mua.
/// `Option<T>` a he rereke ano pea te rahi o te `Option<MaybeUninit<T>>`, a ko nga momo kei roto he momo momo `T` ka taea te whakatakoto (me te rahi) he rereke ke mena ko te mara he `MaybeUninit<T>`.
/// `MaybeUninit` Ko te momo uniana, a `#[repr(transparent)]` i runga i ngā uniana he iu (kite [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Ka haere te waa, ka whanake nga taurangi pono o `#[repr(transparent)]` o nga uniana, ana ko `MaybeUninit` kaore pea e noho `#[repr(transparent)]`.
/// E mea, ka `MaybeUninit<T>`*tonu* taurangi e te mea te rahi taua, tīaroaro, a Abi rite `T`;te reira noa e te ara `MaybeUninit` mea mahi e kia whanake taurangi.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Ka taea e taatau te takai i etahi atu momo ki roto.He pai tenei ma nga kaiwhakanao.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ehara i karanga `T::clone()`, e kore e taea e tatou e matau ki te e arawhitia tatou nui mo taua.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Ka waihangahia he `MaybeUninit<T>` hou kua tiimata me te uara kua whakaritea.
    /// He pai te karanga [`assume_init`] mo te uara whakahoki o tenei mahi.
    ///
    /// Kia mahara ko te whakaheke i te `MaybeUninit<T>` kaore e kiia te waehere taka o te "T`.
    /// Ko to koutou hopoi'a ki te kia maturuturu iho tino `T` tangata ki te Ua arawhitia reira.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Ka waihanga te `MaybeUninit<T>` hou i roto i te āhua Korearawhiti.
    ///
    /// Kia mahara ko te whakaheke i te `MaybeUninit<T>` kaore e kiia te waehere taka o te "T`.
    /// Ko to koutou hopoi'a ki te kia maturuturu iho tino `T` tangata ki te Ua arawhitia reira.
    ///
    /// Tirohia te [type-level documentation][MaybeUninit] mo etahi tauira.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Waihanga i te ngohi hou o ngā tūemi `MaybeUninit<T>`, i roto i te āhua Korearawhiti.
    ///
    /// Note: i roto i te whakaputanga future Rust ka kore noa iho tenei tikanga ina ka whakaaetia e te kohinga taatai te [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Ko te tauira i raro nei i taea e ka whakamahi `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Whakahoki ai i te (he iti ake pea) tetahi waahanga o nga korero i panuihia
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // HAUMARU: He Korearawhiti he tika `[MaybeUninit<_>; LEN]`.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Ka waihangahia he `MaybeUninit<T>` hou i roto i te ahua kore whakauru, me te mahara ka ki tonu i nga paita `0`.Tei te reira i runga i `T` ranei e hanga kua hoki arawhiti tika.
    ///
    /// Hei tauira, ko te `MaybeUninit<usize>::zeroed()` he mea tiimata, engari ko te `MaybeUninit<&'static i32>::zeroed()` ehara na te mea ko nga tohutoro kaua e whakakore.
    ///
    /// Kia mahara ko te whakaheke i te `MaybeUninit<T>` kaore e kiia te waehere taka o te "T`.
    /// Ko to koutou hopoi'a ki te kia maturuturu iho tino `T` tangata ki te Ua arawhitia reira.
    ///
    /// # Example
    ///
    /// whakamahinga tika o tenei mahi: arawhiti he struct ki te kore, i reira mara katoa o te struct e taea te pupuri i te bit-tauira 0 rite te uara whaimana.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *He he* te whakamahinga o tenei mahi: ko te karanga i te `x.zeroed().assume_init()` i te mea kaore a `0` i te tauira-iti mo te momo.
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // I roto i te takirua, ka hangaia e maatau he `NotZero` kaore he kaiwhakahe tika.
    /// // Ko te whanonga kāore tenei.️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SAFETY: `u.as_mut_ptr()` tohu ki te whakamaharatanga tohaina.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Ka tautuhia te uara o te `MaybeUninit<T>`.
    /// tuhirua tenei tetahi uara o mua, kahore iho ana i te reira, na kia tupato e kore ki te whakamahi i tenei rua te kore e hiahia ana koe ki te tīpoka rere te destructor.
    ///
    /// Hei pai maau, ka hoki mai ano tenei i te waa ka taea te whakarereke i nga tuhinga (kua tiimata inaianei mo te `self`).
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SAFETY: Katahi ano ka timata taatau i tenei uara.
        unsafe { self.assume_init_mut() }
    }

    /// Whiwhi te atatohu ki te uara roto.
    /// Pānui i tenei atatohu ranei tahuri te reira ki te tohutoro he whanonga kāore te kore arawhiti te `MaybeUninit<T>` te.
    /// Ko te tuhi ki te maumahara ko te tohu a te (non-transitively) e tohu ana he whanonga kore (haunga ko te `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// whakamahinga tika o tenei tikanga:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Hangaia he korero ki te `MaybeUninit<T>`.He pai tenei na te mea i timatanga e maatau.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Hē te whakamahinga* o tenei tikanga:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Kua hanga e matou he tohutoro ki te vector Korearawhiti!Ko te whanonga kāore tenei.️
    /// ```
    ///
    /// (Panui ko nga ture mo te whakahua i nga korero kaore ano kia whakamanahia, kaore ano kia whakaotihia, engari kia tae ra ano ki tenei, me whakahau kia karo.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ko `ManuallyDrop` He `repr(transparent)` e rua kia taea e matou maka te atatohu.
        self as *const _ as *const T
    }

    /// Whiwhi te atatohu mutable ki te uara roto.
    /// Pānui i tenei atatohu ranei tahuri te reira ki te tohutoro he whanonga kāore te kore arawhiti te `MaybeUninit<T>` te.
    ///
    /// # Examples
    ///
    /// whakamahinga tika o tenei tikanga:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Hangaia he korero ki te `MaybeUninit<Vec<u32>>`.
    /// // He pai tenei na te mea i timatanga e maatau.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Hē te whakamahinga* o tenei tikanga:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Kua hanga e matou he tohutoro ki te vector Korearawhiti!Ko te whanonga kāore tenei.️
    /// ```
    ///
    /// (Panui ko nga ture mo te whakahua i nga korero kaore ano kia whakamanahia, kaore ano kia whakaotihia, engari kia tae ra ano ki tenei, me whakahau kia karo.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ko `ManuallyDrop` He `repr(transparent)` e rua kia taea e matou maka te atatohu.
        self as *mut _ as *mut T
    }

    /// Unu i te uara i te ipu `MaybeUninit<T>`.Ko he ara nui ki te whakarite kia e kia maturuturu iho te raraunga, no te mea ko te `T` hua raro ki te whāwhā taka mua tenei.
    ///
    /// # Safety
    ///
    /// Ko reira ki runga ki te kaiwaea ki kī e tino ko te `MaybeUninit<T>` i te āhua arawhiti.Ka karangatia hoki tenei e kore te ka ano arawhiti tino te ihirangi take tonu te whanonga kāore.
    /// Kei roto i te [type-level documentation][inv] ētahi atu pārongo e pā ana ki tenei pūmau arawhiti.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// I runga o taua, mahara e te nuinga o ngā momo whai invariants atu tua atu noa te whakaaro arawhiti i te taumata momo.
    /// Hei tauira, ko te `1`-tiimata [`Vec<T>`] ka whakaarohia (i raro i te whakatinanatanga o tenei wa; kaore tenei i te pumau o te taurangi) na te mea ko te whakaritenga anake e mohio ana te kaiwhakaputa ko te tohu o nga raraunga me whakakore.
    ///
    /// Te hanga taua he `Vec<T>` e kore take *whanonga kāore* tonu, engari ka meinga whanonga kāore ki te nuinga ngā mahi haumaru (tae atu iho i te reira).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// whakamahinga tika o tenei tikanga:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Hē te whakamahinga* o tenei tikanga:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` i kore i arawhiti ano, na meinga tenei raina whakamutunga whanonga kāore.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SAFETY: te kī pau kaiwaea e arawhiti `self` te.
        // tikanga hoki tenei e kia `self` he kē `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Ua tai'oi te uara i te ipu `MaybeUninit<T>`.Ko te hua `T` ka raro i te whakahaere o te maturuturunga iho.
    ///
    /// Taime atoa taea, he mea pai ki te whakamahi i [`assume_init`] hei utu, e Haukarotia Tāritehia te ihirangi o te `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Ko reira ki runga ki te kaiwaea ki kī e tino ko te `MaybeUninit<T>` i te āhua arawhiti.Ka karangatia hoki tenei e kore te ka ano arawhiti tino te ihirangi take whanonga kāore.
    /// Kei roto i te [type-level documentation][inv] ētahi atu pārongo e pā ana ki tenei pūmau arawhiti.
    ///
    /// Ano, tenei rau he tārua o te i muri i raraunga taua i roto i te `MaybeUninit<T>`.
    /// A, no te whakamahi i kape maha o nga raraunga (na roto i te te karanga `assume_init_read` wā maha, ranei tuatahi karanga `assume_init_read` me ka [`assume_init`]), ko reira koutou kawenga ki te whakarite kia pono kia te tārite taua raraunga.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// whakamahinga tika o tenei tikanga:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` he `Copy`, na kia maha taatau panui.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Ko te whakahua i te uara `None` he pai, na kia panui pea tatou i nga waa maha.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Hē te whakamahinga* o tenei tikanga:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // I hangaia e maatau inaianei nga kape e rua o te vector ano, ka tae atu ki te kore-rua ⚠️ ka hinga ana raua tokorua!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SAFETY: te kī pau kaiwaea e arawhiti `self` te.
        // Ko te panui mai i te `self.as_ptr()` he ahuru mai i te mea me matua arahi te `self`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Makaka te uara roto i roto i te wahi.
    ///
    /// Ki te whai koe i te mana o te `MaybeUninit`, ka taea e koe te whakamahi i hei utu [`assume_init`].
    ///
    /// # Safety
    ///
    /// Ko reira ki runga ki te kaiwaea ki kī e tino ko te `MaybeUninit<T>` i te āhua arawhiti.Ka karangatia hoki tenei e kore te ka ano arawhiti tino te ihirangi take whanonga kāore.
    ///
    /// I runga o taua, me kia makona invariants atu katoa o te momo `T`, rite kia te whakatinanatanga `Drop` o `T` (ranei ona mema o) whakawhirinaki i runga i tenei.
    /// Hei tauira, ko te `1`-tiimata [`Vec<T>`] ka whakaarohia (i raro i te whakatinanatanga o tenei wa; kaore tenei i te pumau o te taurangi) na te mea ko te whakaritenga anake e mohio ana te kaiwhakaputa ko te tohu o nga raraunga me whakakore.
    ///
    /// Ko te whakaheke i te `Vec<T>` engari ka kore e tautuhia te whanonga.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SAFETY: arawhitia te pau kaiwaea taurangi e `self` te me
        // Tuhinga o mua.
        // Ko te whakaheke i te uara ki te waahi ka ahuru mena ka pena.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Whiwhi te tohutoro ngā ki te uara roto.
    ///
    /// Ka taea e kia whai hua tenei ina e hiahia ana tatou ki te uru i te `MaybeUninit` kua e kua arawhiti engari e kore e whai mana o te `MaybeUninit` (ārai te whakamahi o `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Ka karangatia hoki tenei, no te kore e ano tino arawhiti te ihirangi take whanonga kāore: he ake reira ki te kaiwaea ki kī e tino ko te `MaybeUninit<T>` i te āhua arawhiti.
    ///
    ///
    /// # Examples
    ///
    /// ### whakamahinga tika o tenei tikanga:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Arawhiti `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Na e mohiotia to tatou `MaybeUninit<_>` te ki kia arawhiti, ko reira pai ki te hanga i tētahi tohutoro ngā ki reira:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SAFETY: `x` kua tiimata.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Hē* whakamahinga o tenei tikanga:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Kua hanga e matou he tohutoro ki te vector Korearawhiti!Ko te whanonga kāore tenei.️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Whakauruhia te `MaybeUninit` ma te `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Tohutoro ki te `Cell<bool>` koretake: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SAFETY: te kī pau kaiwaea e arawhiti `self` te.
        // tikanga hoki tenei e kia `self` he kē `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Whiwhi te tohutoro (unique) mutable ki te uara roto.
    ///
    /// Ka taea e kia whai hua tenei ina e hiahia ana tatou ki te uru i te `MaybeUninit` kua e kua arawhiti engari e kore e whai mana o te `MaybeUninit` (ārai te whakamahi o `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Ka karangatia hoki tenei, no te kore e ano tino arawhiti te ihirangi take whanonga kāore: he ake reira ki te kaiwaea ki kī e tino ko te `MaybeUninit<T>` i te āhua arawhiti.
    /// Hei tauira, e kore e taea te whakamahi `.assume_init_mut()` ki arawhiti te `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### whakamahinga tika o tenei tikanga:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initializes *nga paita* katoa o te moka tāuru.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Arawhiti `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Inaianei kua mohio taatau kua timata te `buf`, na ka taea e taatau te `.assume_init()`.
    /// // Heoi, mā te whakamahi i `.assume_init()` kia tīmata i te `memcpy` o te paita 2048.
    /// // Ki Kua whakapuaki kua arawhiti to tatou moka kahore tārua reira, whakapai ake tatou te `&mut MaybeUninit<[u8; 2048]>` ki te `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // HAUMARU: Kua `buf` kua arawhiti.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Na ka taea e taatau te whakamahi i te `buf` hei waahanga noa:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Hē* whakamahinga o tenei tikanga:
    ///
    /// Kaore e taea e koe te whakamahi i te `.assume_init_mut()` hei arahi i te uara:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Kua hanga e matou he tohutoro (mutable) ki te `bool` Korearawhiti!
    ///     // Ko te whanonga kāore tenei.️
    /// }
    /// ```
    ///
    /// Hei tauira, e taea e koe kahore [`Read`] ki te moka Korearawhiti:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) tohutoro ki te pūmahara Korearawhiti!
    ///                             // He whanonga kore tenei.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Kaore hoki e taea te whakamahi i te urunga tika ki te mara ki te mara i te timatanga o te mara:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tohutoro ki te pūmahara Korearawhiti!
    ///                  // He whanonga kore tenei.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tohutoro ki te pūmahara Korearawhiti!
    ///                  // He whanonga kore tenei.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): whakawhirinaki tēnei wā matou i runga i te i runga i te hē, arā, kua tatou tohutoro ki raraunga Korearawhiti (hei tauira, i roto i `libcore/fmt/float.rs`).
    // kia meinga e tatou he whakatau whakamutunga e pā ana ki te ture i mua i stabilization.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SAFETY: te kī pau kaiwaea e arawhiti `self` te.
        // tikanga hoki tenei e kia `self` he kē `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Tangohia ai nga uara mai i te kohinga o nga ipu `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Kei te kaikaranga te tohu ko nga mea katoa o te ngohi kei roto i te ahua tiimata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SAFETY: Inaianei kei te haumaru i a maatau e whakaatu ana i nga waahanga katoa
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Ka whakamana te kaiwaea kua timataria nga waahanga katoa o te ngohi
        // * `MaybeUninit<T>` a ko T te mea tuturu kia rite te whakatakotoranga
        // * e kore e MaybeUnint maturuturu, na reira he kore-wewete i rua Na te kupu ko haumaru te faafariuraa
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Mā katoa e arawhiti nga mea timatanga, te tiki i te wāhanga ki a ratou.
    ///
    /// # Safety
    ///
    /// Ko ake reira ki te kaiwaea ki te kī e te āhuatanga `MaybeUninit<T>` tino e i roto i te āhua arawhiti.
    ///
    /// Ka karangatia hoki tenei e kore te ka ano arawhiti tino te ihirangi take whanonga kāore.
    ///
    /// Tirohia te [`assume_init_ref`] hoki ētahi atu kōrero me tauira.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // HAUMARU: e maka ana te wāhanga ki te `*const [T]` he haumaru mai i te taurangi kaiwaea e
        // `slice` Ko arawhitia, kua kī and`MaybeUninit` ki te whai i te tahora taua rite `T`.
        // He tika te atatohu whiwhi mai pā reira ki te mahara puritia e `slice` i te mea he tohutoro me te kupu kī ki te kia tika hoki pānui.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Mā katoa e arawhiti nga mea timatanga, te tiki i te wāhanga mutable ki a ratou.
    ///
    /// # Safety
    ///
    /// Ko ake reira ki te kaiwaea ki te kī e te āhuatanga `MaybeUninit<T>` tino e i roto i te āhua arawhiti.
    ///
    /// Ka karangatia hoki tenei e kore te ka ano arawhiti tino te ihirangi take whanonga kāore.
    ///
    /// Tirohia te [`assume_init_mut`] mo etahi atu taipitopito me nga tauira.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SAFETY: he rite ki nga tuhinga haumaru mo `slice_get_ref`, engari kei a maatau
        // tohutoro mutable nei te kī taurangi hoki ki te kia tika mō ngā tuhi.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Ka tohua he tohu ki te tuatahi o te ngohi.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Ka tohua he tohu ki te huanga tuatahi o te ngohi.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Ka kape i nga mea timatanga mai i te `src` ki te `this`, e whakahoki ana i te korero whakarereke ki nga korero o `this` kua oti nei te whakamoemiti.
    ///
    /// Ki te kore e `T` whakatinana `Copy`, te whakamahi i [`write_slice_cloned`]
    ///
    /// He rite tenei ki te [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Tenei mahi ka panic ki te whai roa rerekē nga poro e rua.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: tika matou kua tārua nga āhuatanga katoa o Len ki te kaha e manawapa
    /// // ko nga mea tuatahi src.len() o nga vector e mana ana inaianei.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // HAUMARU: &[T] me&[MaybeUninit<T>] I te taua tahora
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SAFETY: āhuatanga tika kua tika kua tāruatia ki `this` na te initalized reira
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Ka taatai i nga waahanga mai i te `src` ki te `this`, ka hoki mai ano he korero ka taea te huri mo te `this`.
    /// Ko nga waahanga kua whakauruhia e kore e makere.
    ///
    /// Ki te `T` taputapu `Copy`, te whakamahi [`write_slice`]
    ///
    /// He rite tenei ki te [`slice::clone_from_slice`] engari kaore e taka nga waahanga o mua.
    ///
    /// # Panics
    ///
    /// Tenei mahi ka panic ki te whai roa rerekē nga poro e rua, ranei, ki te te whakatinanatanga o `Clone` panics.
    ///
    /// Ki te reira te mea he panic, ka kia maturuturu iho nga mea timatanga kua mōu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: tika matou kua mōu nga āhuatanga katoa o Len ki te kaha e manawapa
    /// // ko nga mea tuatahi src.len() o nga vector e mana ana inaianei.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // pērā copy_from_slice kore e tenei karanga clone_from_slice i runga i te wāhanga ko tenei no te mea e kore e `MaybeUninit<T: Clone>` whakatinana Tārite.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // HAUMARU: ka i roto i tenei wāhanga raw ahanoa anake arawhitia
                // e te aha, kua whakaaetia reira ki te maturuturu reira.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: E ti'a ia tatou ki te tapahi āta ratou ki te roa taua
        // mo nga rohe e tirohia ana kia whakamotitia, a ma te kaitautoko e whakaputa he memcpy mo nga keehi ngawari (hei tauira T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // hiahiatia kaitiaki te b/c panic kia tupu i roto i te tou
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SAFETY: āhuatanga tika kua oti te tuhituhi tika ki `this` na te initalized reira
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}