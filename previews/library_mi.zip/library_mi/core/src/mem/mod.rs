//! Nga mahi taketake mo te mahi mahara.
//!
//! Kei roto i tēnei kōwae mahi mō te e tohea ana te rahi me te tīaroaro o ngā momo, arawhiti, me te raweke mahara.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// E te mana, me te "forgets" e pā ana ki te uara **kahore rere tona destructor**.
///
/// Ko nga rauemi e whakahaerehia ana e te uara, penei i te maumahara o te puranga, o te konae konae ranei, ka roa tonu ia i roto i te ahua kaore e tae atu.Heoi, e kore e kī i te reira e e noho atatohu ki tenei mahara tika.
///
/// * Ki te hiahia koe ki te turuturu mahara, tirohia te [`Box::leak`].
/// * Ki te hiahia koe ki te whiwhi i te atatohu raw ki te mahara, kite [`Box::into_raw`].
/// * Mena kei te hiahia koe ki te tuku tika i tetahi uara, te whakahaere i tana kaitukino, tirohia te [`mem::drop`].
///
/// # Safety
///
/// `forget` kaore i te tohuhia hei `unsafe`, na te mea kaore he taurangi o te Rust e whai tohu ana ka rere tonu nga kaipahua.
/// Hei tauira, ka taea e te hōtaka te waihanga i tētahi huringa tohutoro whakamahi [`Rc`][rc], karanga [`process::exit`][exit] ki putanga i waho rere destructors ranei.
/// Ko te kupu, e kore e tuku `mem::forget` i waehere haumaru faufaa huri taurangi haumaru o Rust.
///
/// I kii, ko nga rauemi turuturu penei i te mahara ki nga taonga I/O ranei te nuinga kaore e hiahiatia.
/// Ko te hiahia mai ake i roto i ētahi wā whakamahi motuhake mō te FFI waehere haumaru ranei, engari ara reira, kei te nuinga meinga [`ManuallyDrop`].
///
/// No te wareware i te uara whakaaetia te, me tukua tetahi waehere `unsafe` tuhituhi koe mo tenei taea.e kore koe e taea e hoki te uara me te titau e ka rere tika te kaiwaea destructor o te uara.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Ko te whakamahinga ahuru o te `mem::forget` hei aukati i te kaiwhakangungu o te uara i whakatinanahia e te `Drop` trait.Hei tauira, ka puta tenei i te `File`, ara
/// te titau i te wāhi i tangohia e te tāupe, engari e kore tata te rauemi pūnaha e whāriki ana:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// He whaihua tenei i te wa i whakawhitihia te rangatira o nga rauemi maaro ki te waehere i waho atu o te Rust, hei tauira ma te tuku i te tuhinga whakamaarama ki te waehere C.
///
/// # Te hononga ki te `ManuallyDrop`
///
/// Ahakoa hoki e taea te whakamahi `mem::forget` ki te whakawhiti mahara * * mana, mahi pera he hapa-pängia ana.
/// [`ManuallyDrop`] kia whakamahia hei utu.Whakaaroa, mo te tauira, tenei waehere:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Hangaia he `String` ma te whakamahi i nga korero o `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // turuturu `v` no te mea kei te whakahaere inaianei tona mahara e `s`
/// mem::forget(v);  // HAPA, v he he, me kore me tuku ki tetahi mahi
/// assert_eq!(s, "Az");
/// // `s` Kei te kakato maturuturu iho ka deallocated ona mahara.
/// ```
///
/// E rua nga putanga o te tauira i runga ake nei:
///
/// * Ki te i honoa atu waehere i waenganui i te hanga o `String` me te kau sangató, o `mem::forget()`, he panic roto e meinga ai he noa rua no te mea i whawha atu te mahara taua e rua `v` me `s`.
/// * I muri i te waea `v.as_mut_ptr()` me te tuku i te rangatira o nga raraunga ki te `s`, he he te uara `v`.
/// Ahakoa ka neke noa atu te uara ki te `mem::forget` (kaore e tirotirohia), ko etahi momo he tino whakaritenga ki a raatau uara kia muhu ai ina whakairi ana, kaore ranei i te rangatira.
/// Ma te whakamahi i nga uara muhu ahakoa te aha, tae atu ki te whakawhiti atu ki te whakahoki mai ranei i a raatau mai i nga mahi, he tikanga kaore i tautuhia, ka pakaru pea i nga whakaaro i mahia e te kaiwhakaputu.
///
/// Ko te huri ki te `ManuallyDrop` ka karo i nga take e rua:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // I mua i to taatai `v` ki ona waahanga mata, kia kore e taka iho!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Inaianei wetekina `v`.Ēnei ngā mahi e taea e kore panic, na reira ka taea e kore e he turuturu.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Hei whakamutunga, hangaia he `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` Kei te kakato maturuturu iho ka deallocated ona mahara.
/// ```
///
/// `ManuallyDrop` kia kaha te aukati i te taarua-kore na te mea ka whakakorehia e taatau te kino o te 'v` i mua i te mahi i tetahi atu mea.
/// `mem::forget()` kaore e whakaaehia tenei na te mea ka pau tana tautohe, ka akiaki ia maatau ki te karanga i muri noa o te tango i nga mea e hiahiatia ana e matou mai i te `v`.
/// Ahakoa i whakauruhia he panic i waenga i te hanganga o `ManuallyDrop` me te hanga i te aho (kaore e taea te whakaatu i te waehere e whakaaturia ana), ka puta he turuturu kaore e rua te koreutu.
/// I etahi atu kupu, `ManuallyDrop` ka he i te taha o te turuturu kaua ki te he i te taha o te (takirua-) maturuturu.
///
/// Ano hoki, ka aukati a `ManuallyDrop` i a maatau ki te "touch" `v` i muri i te whakawhiti i te rangatira ki `s`-ko te taahiraa whakamutunga o te taunekeneke ki te `v` ki te whakakore me te kore e whakangaro i te kaitukino.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Ka rite ki te [`forget`], engari ka whakaae hoki ki nga uara kore kua taukatia.
///
/// Ko tenei mahi he mea noa kia tangohia ina ka pumau te ahuatanga `unsized_locals`.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Whakahoki ai i te rahi o te momo paita.
///
/// Ko te mea nui ake, koinei te urupare o nga paita i waenga i nga waahanga tima i roto i te raupapa me te momo tuemi tae atu ki te taatai whakaurunga.
///
/// Na, mo nga momo `T` me te roa `n`, `[T; n]` he rahi te `n * size_of::<T>()`.
///
/// I te nuinga, ko te rahinga o te momo kaore e pumau puta noa i nga whakahiato, engari ko nga momo motuhake penei i te tuatahi.
///
/// Ma te ripanga e whai ake nei e whakaatu te rahi mo nga mea tuatahi.
///
/// Patohia |rahi_o: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Ano hoki, he rite te rahi o te `usize` me te `isize`.
///
/// Ko nga momo `*const T`, `&T`, `Box<T>`, `Option<&T>`, me `Option<Box<T>>` he rite katoa te rahi.
/// Mena he Rahi te `T`, he rite te rahi o era momo ki te `usize`.
///
/// Ko te rereketanga o te tohu he tohu kaore e rereke te rahi.I penei, `&T` me `&mut T` he rite te rahi.
/// Waihoki mo te `*const T` me te `* mut T`.
///
/// # Rahinga o nga taonga `#[repr(C)]`
///
/// Ko te whakaaturanga `C` mo nga taonga he whakatakotoranga tautuhi.
/// Ma tenei whakatakotoranga, he pumau hoki te rahi o nga taonga mena he rahi te rahinga o nga mara katoa.
///
/// ## Tuhinga o mua
///
/// Mo te `structs`, ko te rahi e whakatauhia ana e te algorithm e whai ake nei.
///
/// Mo ia mara i roto i te hanganga i whakahaua e te ota panui:
///
/// 1. Taapirihia te rahi o te mara.
/// 2. Hurihia te rahinga o naianei ki te tata tata o te [alignment] o te mara e whai ake nei.
///
/// Hei whakamutunga, huri i te rahi o te hanganga ki te tata tata atu o tana [alignment].
/// Ko te whakahoutanga o te hanganga te nuinga o nga waahanga katoa o ona mara;ka taea tenei te whakarereke ma te whakamahi i te `repr(align(N))`.
///
/// Kaore e rite ki te `C`, ko nga mahinga kore kore e porotaka ki te kotahi paita te rahi.
///
/// ## Tuhinga o mua
///
/// Ko nga miihini kaore i te kawe korero, haunga te kaiwhakapae, he rite te rahi ki nga enumene C i runga i te papaaho i kohia e raatau.
///
/// ## Tuhinga o mua
///
/// Ko te rahinga o te uniana ko te rahi o tana mara nui rawa atu.
///
/// Kaore e rite ki te `C`, ko nga uniana kore rahi kaore e porotaka ki te kotahi paita te rahi.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // ētahi primitives
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Ko etahi raarangi
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // taurite te rahi Atatohu
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Ma te `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Te rahi o te mara tuatahi ko 1, kia tāpiri 1 ki te rahi.Rahi Ko 1.
/// // Ko te hāngaitanga o te mara tuarua ko 2, kia tāpiri 1 ki te rahi mo te purpuru.Rahi he 2.
/// // Ko te rahinga o te āpure tuarua he 2, no reira taapirihia he 2 ki te rahinga.Rahi Ko 4.
/// // Ko te hāngaitanga o te toru o nga mara ko 1, kia tāpiri 0 ki te rahi mo te purpuru.Rahi Ko 4.
/// // Te rahi o te toru o nga mara ko 1, kia tāpiri 1 ki te rahi.Rahi Ko 5.
/// // Hei whakamutunga, ko te whakahoutanga o te hanganga he 2 (na te mea ko te waahanga nui rawa atu i waenga i ana mara ko te 2), na reira taapirihia te 1 ki te rahinga mo te taatai.
/// // Rahi he 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // whai tuple structs te taua ture.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Kia mahara e whakaraupapa anō i te mara e taea raro i te rahi.
/// // Ka taea e tatou te tango e rua paita purpuru mā te maka ana `third` te aroaro o `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Union rahi ko te rahi o te parae nui rawa.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Whakahokia ai te rahi o te uara tohu-ki nga paita.
///
/// He rite tonu tenei ki te `size_of::<T>()`.
/// Heoi, ki te `T`*kaore* he rahi-e mohiotia ana te rahi, hei tauira, he poro [`[T]`][slice] he [trait object] ranei, katahi ka taea te whakamahi i te `size_of_val` kia mohiotia ai te rahi.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: `val` he tohutoro, na he tohu tika te tohu
    unsafe { intrinsics::size_of_val(val) }
}

/// Whakahokia ai te rahi o te uara tohu-ki nga paita.
///
/// He rite tonu tenei ki te `size_of::<T>()`.Heoi, i te kore o te `T` * e mohiotia ana te rahi, hei tauira, te poro [`[T]`][slice], te [trait object] ranei, katahi ka taea te whakamahi i te `size_of_val_raw` kia mohiotia ai te rahi.
///
/// # Safety
///
/// He pai noa iho tenei mahi ki te waea mena ka mau nga tikanga e whai ake nei:
///
/// - Mena ko `T` te `Sized`, he pai tonu tenei mahi ki te karanga.
/// - Mena ko te hiku hika o `T` ko:
///     - he [slice], na ko te roa o te hiku poro he tauwehe tuatahi, a ko te rahinga o te *uara katoa*(te roa o te hiku whakahoahoa + kuhimua rahi taatai) me uru ki te `isize`.
///     - he [trait object], na me tohu te waahanga tere o te tohu ki tetahi reeti whaimana i whakawhiwhia mai e te akiaki kore, me te rahinga o te *uara katoa*(te roa o te hiku hihiri + awhi pateko te rahi) me uru ki te `isize`.
///
///     - he (unstable) [extern type], na te mea he pai tenei waea ki te waea atu, engari kia panic kia kore ranei e whakahokia mai te uara he, i te mea kaore e mohiotia te whakatakotoranga o te momo o waho.
///     He rite tonu te whanonga ki te [`size_of_val`] mo te tohutoro ki te momo me te hiku momo o waho.
///     - ki te kore, kaore e whakaaehia kia karangahia tenei mahi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETY: me whakarato e te kaiwaea he tohu tohu tika
    unsafe { intrinsics::size_of_val(val) }
}

/// Whakahoki ai i te [ABI]-e tika ana kia whakaritehia te waahanga iti o te momo.
///
/// Katoa nga korero e pa ana ki te uara o te momo `T` me maha ake mo tenei tau.
///
/// Koinei te whakaoronga e whakamahia ana mo nga mara hangahanga.Akene he iti ake i te whakaoritanga pai.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Whakahoki ai i te [ABI]-e tika ana ki te whakaorite iti o te momo uara e tohu ana `val`.
///
/// Katoa nga korero e pa ana ki te uara o te momo `T` me maha ake mo tenei tau.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: he tohu te val, no reira he tohu tika te tohu
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Whakahoki ai i te [ABI]-e tika ana kia whakaritehia te waahanga iti o te momo.
///
/// Katoa nga korero e pa ana ki te uara o te momo `T` me maha ake mo tenei tau.
///
/// Koinei te whakaoronga e whakamahia ana mo nga mara hangahanga.Akene he iti ake i te whakaoritanga pai.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Whakahoki ai i te [ABI]-e tika ana ki te whakaorite iti o te momo uara e tohu ana `val`.
///
/// Katoa nga korero e pa ana ki te uara o te momo `T` me maha ake mo tenei tau.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: he tohu te val, no reira he tohu tika te tohu
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Whakahoki ai i te [ABI]-e tika ana ki te whakaorite iti o te momo uara e tohu ana `val`.
///
/// Katoa nga korero e pa ana ki te uara o te momo `T` me maha ake mo tenei tau.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// He pai noa iho tenei mahi ki te waea mena ka mau nga tikanga e whai ake nei:
///
/// - Mena ko `T` te `Sized`, he pai tonu tenei mahi ki te karanga.
/// - Mena ko te hiku hika o `T` ko:
///     - he [slice], na ko te roa o te hiku poro he tauwehe tuatahi, a ko te rahinga o te *uara katoa*(te roa o te hiku whakahoahoa + kuhimua rahi taatai) me uru ki te `isize`.
///     - he [trait object], na me tohu te waahanga tere o te tohu ki tetahi reeti whaimana i whakawhiwhia mai e te akiaki kore, me te rahinga o te *uara katoa*(te roa o te hiku hihiri + awhi pateko te rahi) me uru ki te `isize`.
///
///     - he (unstable) [extern type], na te mea he pai tenei waea ki te waea atu, engari kia panic kia kore ranei e whakahokia mai te uara he, i te mea kaore e mohiotia te whakatakotoranga o te momo o waho.
///     He rite tonu te whanonga ki te [`align_of_val`] mo te tohutoro ki te momo me te hiku momo o waho.
///     - ki te kore, kaore e whakaaehia kia karangahia tenei mahi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETY: me whakarato e te kaiwaea he tohu tohu tika
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Whakahoki `true` mena ka taka nga uara o te momo `T` mea nui.
///
/// He tohu awhina noa tenei, a ka taea pea te whakamahi whakatinana:
/// akene ka hoki mai te `true` mo nga momo kaore e hiahiatia kia taka iho.
/// I te mea ko te whakahoki mai i te `true` he tikanga tika mo tenei mahi.Engari ki te hoki mai tenei mahi `false`, ka mohio koe ka taka te `T` kaore he awangawanga.
///
/// Ko te whakamahinga iti o nga mea penei i nga kohinga, me maturuturu a raatau tuhinga, me whakamahi i tenei mahi kia kore ai e ngana ki te maturuturu i o raatau korero ka ngaro ana.
///
/// Kaore pea tenei e rereke i nga hanganga tuku (kei reira te koropiko kaore he awangawanga e kitea noa ana ka whakakorea), engari he wini nui mo nga hanga patuiro.
///
/// Kia mahara kua oti i a [`drop_in_place`] tenei haki, na mena ka taea te whakaheke i o taumahatanga ki etahi nama iti a [`drop_in_place`], ma te whakamahi kaore he take o tenei.
/// Kia mahara ka taea e koe te [`drop_in_place`] te poro, ana ka tiro i tetahi hiahia_tirohia iho nga uara katoa.
///
/// Nga momo penei i a Vec no reira `drop_in_place(&mut self[..])` noa iho me te kore e whakamahi marama i te `needs_drop`.
/// Ko nga momo penei i te [`HashMap`], i tetahi atu ringa, me taka nga uara ki ia wa, ka whakamahi i tenei API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Anei tetahi tauira mo te kohikohinga i te `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // maturuturu te raraunga
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Whakahoki ai i te uara o te momo `T` e whakaatuhia ana e te tauira paita-kore katoa.
///
/// Ko te tikanga tenei, hei tauira, ko te paita padding i te `(u8, u16)` kaore i te kore noa.
///
/// Kaore he taurangi ko te tauira paita-kore katoa e tohu ana i te uara whaimana o etahi momo `T`.
/// Hei tauira, ko te tauira-byte-tauira katoa kaore i te uara whaimana mo nga momo tohutoro (`&T`, `&mut T`) me nga tohu tohu mahi.
/// Ma te whakamahi i te `zeroed` i runga i nga momo penei ka [undefined behavior][ub] tonu na te mea [the Rust compiler assumes][inv] kei kona tonu tetahi uara tika i roto i te taurangi e whakaarohia ana e ia i timata.
///
///
/// He rite tenei ki te [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// He pai mo te FFI i etahi wa, engari me karo ke.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Te whakamahi tika i tenei mahi: te whakauru i te integer me te kore.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Hē* te whakamahinga o tenei mahi: ko te arawhiti i te tohutoro ki te kore.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // whanonga koretautuhi!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ana ano!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SAFETY: me kii e te kaiwaea he whaimana-kore te uara mo te `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Ko nga tohu o te Rust ka maumahara ki te arowhai-maatauranga ma te whakapae ki te whakaputa i te uara o te momo `T`, kaore kau i te mahi.
///
/// **Kua whakakorehia tenei mahi.** Whakamahia te [`MaybeUninit<T>`].
///
/// Ko te take mo te whakaheke i te mea kaore e taea te whakamahi tika i te mahi: he rite tona ahua ki te [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// I te [`assume_init` documentation][assume_init] e whakamarama ana, [the Rust compiler assumes][inv] ko nga uara ka aata tiimata.
/// Ko te mutunga ake, ko te karanga eg
/// `mem::uninitialized::<bool>()` na te whanonga kaore i tautuhia mo te whakahoki i te `bool` kaore i te tino `true`, `false` ranei.
/// Ko te mea kino, ko te maaramatanga pono kore ano hoki pera i te mea e hoki mai ana ki konei he mea motuhake na te mohio o te kaiwhakaatu kaore he uara pumau o taua mea.
/// Ma tenei ka kore e tautuhia te whanonga ki te whai raraunga kore whakauru ki te taurangi ahakoa he momo taurangi te taurangi.
/// (Kia mahara kaore ano kia whakaotihia nga ture mo nga integers kaore ano kia whakamanahia, engari kia oti ra ano, ko te tohutohu kia karohia.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SAFETY: me kii e te kaiwaea he uara whakawehe mo te `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Hurihia nga uara i nga waahi e rua ka taea te whakarereke, me te kore e whakakorehia tetahi.
///
/// * Mena kei te hiahia koe ki te whakawhiti me te uara taunoa, te uara ranei, tirohia te [`take`].
/// * Mena kei te hiahia koe ki te whakawhiti me te uara kua paahitia, whakahokia mai te uara tawhito, tirohia te [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SAFETY: kua waihangahia nga tohu tohu mai i nga korero whakarereke haumaru ka ea katoa
    // herenga kei runga i te `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Ka whakakapihia te `dest` me te uara taunoa o `T`, ka whakahoki i te uara `dest` o mua.
///
/// * Mena kei te hiahia koe ki te whakakapi i nga uara o nga taurangi e rua, tirohia te [`swap`].
/// * Mena kei te hiahia koe ki te whakakapi i te uara kua hipa hei utu mo te uara taunoa, tirohia te [`replace`].
///
/// # Examples
///
/// He tauira ngawari:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` ka taea te tango i tetahi mara ma te whakakapi ki te uara "empty".
/// Kaore he `take` ka taea e koe te pa ki nga take penei:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Kia mahara kaore te `T` e whakamahi i te [`Clone`], na reira kaore e taea te whakakii me te tautuhi i te `self.buf`.
/// Engari ka taea te whakamahi i te `take` ki te wehe i te uara taketake o `self.buf` mai i `self`, kia taea ai te whakahoki mai:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Ka nekehia te `src` ki te `dest` tohutoro, ka whakahokia mai te uara `dest` o mua.
///
/// Kaore ano kia heke te uara.
///
/// * Mena kei te hiahia koe ki te whakakapi i nga uara o nga taurangi e rua, tirohia te [`swap`].
/// * Mena kei te hiahia whakakapi koe i te uara taunoa, tirohia te [`take`].
///
/// # Examples
///
/// He tauira ngawari:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` āhei ai te kohi i te āpure hanganga ma te whakakapi ki tetahi atu uara.
/// Kaore he `replace` ka taea e koe te pa ki nga take penei:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Kia mahara kaore a `T` i te whakamahi i te [`Clone`], na reira kaore e taea te whakakii i te `self.buf[i]` kia kore ai e neke.
/// Engari ka taea te whakamahi i te `replace` ki te wehe i te uara taketake o taua taupū mai i te `self`, kia taea ai te whakahoki mai:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SAFETY: Ka panuihia e maatau mai i `dest` engari ka tuhi `src` ki roto i muri iho,
    // penei kaore i te taarua te uara tawhito.
    // Kaore he mea i whakataka, kaore hoki he mea i konei ka taea te panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Tuhinga o mua.
///
/// Ma tenei ma te karanga i te whakatinanatanga o te tautohe mo te [`Drop`][drop].
///
/// Kaore tenei e whai kiko mo nga momo ka whakamahi i te `Copy`, hei tauira
/// integers.
/// Ko nga uara pera ka taatuhia ka nekehia te _then_ ki te mahinga, no reira kei te mau tonu te uara i muri o tenei waeatanga mahi.
///
///
/// Ehara tenei mahi i te mahi makutu;kua tino tautuhia hei
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Na te mea kua nekehia te `_x` ki te mahi, ka heke noa i mua i te hokinga mai o te mahi.
///
/// [drop]: Drop
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // whakataka maramatia te vector
/// ```
///
/// Mai i te [`RefCell`] e whakamana ana i nga ture tono nama i te waa wahanga, ka taea e `drop` te tuku nama [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // waiho te nama tarewa tere i runga i tenei mokamoka
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Ko nga integers me etahi atu momo whakamahi i te [`Copy`] kaore e pangia e `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // Kei te oho te tārua o `x` me maturuturu iho
/// drop(y); // Kei te oho te tārua o `y` me maturuturu iho
///
/// println!("x: {}, y: {}", x, y.0); // e waatea tonu ana
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// He whakamaori i te `src` he momo `&U`, ka panui i te `src` me te kore e neke i te uara o roto.
///
/// Ma tenei mahi e kore e tau te tohu he tika te tohu atawhai `src` mo nga paita [`size_of::<U>`][size_of] ma te whakawhiti i te `&T` ki te `&U` ka panui i te `&U` (engari ko tenei ka mahia ma te ara e tika ana ahakoa ka kaha ake te tono a `&U` i te `&T`).
/// Ka waimarie hoki te hanga i tetahi kape o te uara kei roto hei utu mo te neke atu i te `src`.
///
/// Ehara i te he he hapa-wa-whakahiato mena he rereketanga te rahi o te `T` me te `U`, engari he tino kaha ki te karanga noa i tenei mahi e rite ana te rahi o te `T` me te `U`.Ko tenei mahi ka whakaoho i te [undefined behavior][ub] mena he nui ake te `U` i te `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Tuhia nga raraunga mai i te 'foo_array' ka whakaarohia hei 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Whakakētia te raraunga kua kape
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Ko nga korero o 'foo_array' kaore i rereke
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Mena he nui ake te whakaritenga o U, kaore e tika te whakatika o te src.
    if align_of::<U>() > align_of::<T>() {
        // SAFETY: Ko te `src` he tohutoro e pono ana mo nga paanui.
        // Me kii te kaiwaea he haumaru te whakawhitinga pono.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SAFETY: Ko te `src` he tohutoro e pono ana mo nga paanui.
        // Katahi ano ka tirohia he tika te huringa o te `src as *const U`.
        // Me kii te kaiwaea he haumaru te whakawhitinga pono.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Momo opaque e tohu ana i te whakahāweatanga o te enum.
///
/// Tirohia te mahi [`discriminant`] kei roto i tenei waahanga mo etahi atu korero.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ko enei whakamahinga trait kaore e taea te whakaputa na te mea kaore matou e hiahia kia herea ki te T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Whakahoki ai i te uara motuhake te tautuhi i te momo enum i te `v`.
///
/// Mena ko `T` ehara i te enum, ma te karanga i tenei mahi kaore e whai hua kaore i tautuhia, engari ko te uara whakahoki kaore i te tohua.
///
///
/// # Stability
///
/// Ka rereke te tangata whakaharahara i te momo enum mena ka rereke te whakamaramatanga enum.
/// Ko te kaitaapapa o etahi momo rereke kaore e rereke i waenga i nga whakahiato me te kaiwhakaputa kotahi.
///
/// # Examples
///
/// Ka taea te whakamahi ki te whakataurite i nga haurangi e kawe ana i nga raraunga, me te kore e aro ki nga raraunga tuuturu.
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Whakahokia ai te maha o nga momo rereke i te momo enum `T`.
///
/// Mena ko `T` ehara i te enum, ma te karanga i tenei mahi kaore e whai hua kaore i tautuhia, engari ko te uara whakahoki kaore i te tohua.
/// Waihoki, mena ko te `T` he enum me te maha atu o nga rereketanga i te `usize::MAX` kaore e tohua te uara whakahoki.
/// Ka tatau i nga momo noho kore.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}