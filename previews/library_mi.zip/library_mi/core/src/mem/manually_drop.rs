use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// He Uwhi ki Tautāwhitia taupatupatu i karanga aunoa `destructor o T`.
/// Tenei Uwhi Ko 0-utu.
///
/// `ManuallyDrop<T>` Ko raro ki te optimizations tahora taua rite `T`.
/// Ka rite ki te putanga, kua reira *kahore pānga* i runga i te whakapae e te taupatupatu hanga e pā ana ki ona tirotiro.
/// Hei tauira, ko te arawhiti i te `ManuallyDrop<&mut T>` me te [`mem::zeroed`] he whanonga kore.
/// Ki te hiahia koe ki te hapai i raraunga Korearawhiti, te whakamahi i hei utu [`MaybeUninit<T>`].
///
/// Kia mahara ko te whakauru ki te uara kei roto i te `ManuallyDrop<T>` he haumaru.
/// Tenei tikanga e te `ManuallyDrop<T>` nei ihirangi kua maturuturu iho kore me kitea i roto i te API haumaru tūmatanui.
/// Correspondingly, he haumaru `ManuallyDrop::drop`.
///
/// # `ManuallyDrop` ka taka te ota.
///
/// He he [drop order] pai-tautuhi o uara Rust.
/// Hei te tino e maturuturu iho mara kāinga ranei i roto i te raupapa motuhake, raupapa anō i te whakapuakanga pērā e te raupapa maturuturunga papu ko te kotahi tika.
///
/// Ka taea te whakamahi i te `ManuallyDrop` ki te whakahaere i te ota taka, engari me kii te waehere kore haumaru, ka uaua ki te mahi tika i te wa e kore e moe.
///
///
/// Hei tauira, ki te hiahia koe ki te hanga i mohio e maturuturu iho te mara motuhake kei muri i te etahi, kia reira te mara whakamutunga o te struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` ka tukuna iho i muri o te `children`.
///     // wakaae Rust e maturuturu iho mara i roto i te tikanga o te whakapuakanga.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Roropi te uara ki te kia maturuturu iho ā.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Ka taea e tonu e koe te mahi humarie i runga i te uara
    /// assert_eq!(*x, "Hello");
    /// // Otiia e kore e `Drop` e rere i konei
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Unu i te uara i te ipu `ManuallyDrop`.
    ///
    /// Tenei taea te uara ki te kia maturuturu iho ano.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // makaka tenei te `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Tangohia te uara mai i te ipu `ManuallyDrop<T>` ki waho.
    ///
    /// Ko te tikanga tenei he tikanga kia neke atu nga uara ki raro.
    /// Engari ki te whakamahi i te [`ManuallyDrop::drop`] ki te maturuturu atu i te uara, ka taea e koe te whakamahi i tenei tikanga ki te tango i te uara me te whakamahi ahakoa te hiahia.
    ///
    /// Ka taea ana, he pai ake te whakamahi i te [`into_inner`][`ManuallyDrop::into_inner`], hei aukati i te taarua o nga korero o te `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Ko tenei mahi ka neke ke atu te uara o roto kaore e aukati i te whakamahinga, ka waiho te ahua o tenei ipu kia kore e rereke.
    /// Ko to koutou kawenga ki te whakarite kia kore te tenei `ManuallyDrop` whakamahia ano.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // HAUMARU: Kei te pānui tatou i te tohutoro, whai nei te
        // ki te kia tika hoki pānui.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// makaka-ringatia te uara roto.He rite tenei ki te karanga [`ptr::drop_in_place`] me te tohu ki te uara kei roto.
    /// Na, mena kaore he uara te uara o roto, ka karangahia te kaipahua ki te waahi kaore e neke i te uara, a ka taea te whakamahi kia maturuturu iho te [pinned] raraunga.
    ///
    /// Mena kei a koe te mana o te uara, ka taea e koe te whakamahi i te [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Ma tenei mahi e whakangaro te taonga uara.
    /// Ētahi atu huringa i hanga e te destructor ano, mahue te mahara kei te tonu, a kia tae noa ki āwangawanga te taupatupatu kei te mau tonu te bit-tauira i te mea tika hoki te momo `T`.
    ///
    ///
    /// Heoi, e kore e kitea i tenei uara "zombie" ki waehere haumaru, me kore kia huaina tenei mahi nui atu i te kotahi.
    /// Hei whakamahi i te uara i muri te reira i maturuturu iho, ranei maturuturu he uara wā maha, ka taea e meinga Whanonga tautuhi (i runga i te mea `drop` e rānei).
    /// Kei te tikanga tatatia tenei i te pūnaha momo, engari me tautokona kaiwhakamahi o `ManuallyDrop` aua taurangi waho āwhina i te taupatupatu.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // HAUMARU: Kei te iho tatou i te uara tohu ki te taha o te tohutoro mutable
        // whai nei ki te kia tika mō ngā tuhi.
        // Ko ake reira ki te kaiwaea ki te kia e kore e maturuturu iho ano `slot`.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}