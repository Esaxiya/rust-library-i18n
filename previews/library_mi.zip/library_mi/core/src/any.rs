//! Ka whakamahia e tenei waahanga te `Any` trait, e taea ai te patopato kaha o tetahi momo `'static` na roto i te whakaata i te waa.
//!
//! `Any` ano ka taea te whakamahi ki te tiki `TypeId`, a he maha atu nga waahanga ka whakamahia hei taonga trait.
//! Ka rite ki `&dyn Any` (he ahanoa trait tono), kua reira nga tikanga `is` ko `downcast_ref`, ki te whakamātau i te mea ko te uara roto o te momo i homai, me te ki te tiki i te tohutoro ki te uara roto rite te momo.
//! Ka rite ki te `&mut dyn Any`, kei kona ano te tikanga `downcast_mut`, mo te tango i tetahi korero rereke ki te uara o roto.
//! `Box<dyn Any>` tāpiri te tikanga `downcast`, e ngana ki te ului ki te `Box<T>`.
//! Tirohia te te tuhinga [`Box`] mo nga taipitopito tonu.
//!
//! Note e te iti `&dyn Any` ki whakamatautau ranei ko te uara o te momo raima i whakapūtāhia, a kore e taea te whakamahi ki te whakamātautau mēnā he momo taputapu he trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Nga tohu atawhai me te `dyn Any`
//!
//! Ko tetahi o nga whanonga kia mahara koe ma te whakamahi i te `Any` hei taonga trait, ina koa ko nga momo penei i te `Box<dyn Any>` ko te `Arc<dyn Any>` ranei, ko te karanga noa i te `.type_id()` i runga i te uara ka puta te `TypeId` o te *ipu*, kaore ko te mea nui o te trait.
//!
//! Ka taea tenei te karo ma te huri i te tohu atawhai ki te `&dyn Any` hei utu, ka whakahoki i te `TypeId` o te mea.
//! Hei tauira:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // koe pea ake ki te hiahia tenei koe:
//! let actual_id = (&*boxed).type_id();
//! // ... atu i tenei:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Whakaarohia tetahi ahuatanga e hiahia ana maatau ki te takahi i tetahi uara kua tukuna ki tetahi mahi.
//! E matau ana tatou i te uara e mahi tatou i runga i ngā Patuiro, engari e kore matou e matau ona momo raima.Kei te hiahia matou ki te tuku maimoatanga motuhake ki etahi momo: i roto i tenei ko te taarua i te roa o nga uara String i mua i to raatau uara.
//! E kore matou e mohio ki te momo raima o to tatou uara i wa whakahiato, kia hiahia tatou ki te whakamahi i hei utu whakaata wāhaere.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Mahi logger mo nga momo whakamahi i te Patuiro.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Ngana ki te huri i to maatau uara ki te `String`.
//!     // Ki te angitu, e hiahia ana matou ki te putanga roa o te String` rite te pai kia rite ki tona uara.
//!     // Ki te kore, he momo ke: taarua noa kia kore e whakapaia.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Kei te hiahia tenei mahi ki te takiuru i tana taapara i mua i te mahinga o nga mahi.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... mahia etahi atu mahi
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Tetahi trait
///////////////////////////////////////////////////////////////////////////////

/// He trait ki pee patopato hihiri.
///
/// Ko te nuinga o nga momo ka whakamahi i te `Any`.Heoi, ko nga momo katoa kei roto ko te tohutoro kore-`tatic` e kore.
/// Tirohia te te [module-level documentation][mod] mō ētahi atu kōrero.
///
/// [mod]: crate::any
// Kaore tenei trait i te haumaru, ahakoa ka whakawhirinaki matou ki nga korero o te mahi `type_id` anake o tana impl i roto i te waehere kore haumaru (hei tauira, `downcast`).Tikanga, e waiho he raruraru e, engari no te mea he anake te impl o `Any` te whakatinanatanga paraikete, ka taea e kore atu waehere whakatinana `Any`.
//
// Ka taea e maatau te kore e haumaru i tenei trait-kaore e pakaru, na te mea kei te whakahaere maatau i nga mahi katoa-engari i kowhiria e maatau na te mea kaore e tino hiahiatia ana, ka raru pea nga kaiwhakamahi mo te rereketanga o te traits haumaru me nga tikanga kore haumaru (arā, Ka pai pea te karanga a `type_id`, engari ka hiahia pea maatau ki te whakaatu penei i roto i nga tuhinga).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Riro te `TypeId` o `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// tikanga toronga mo tetahi taonga trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Me whakarite e te hua o tauira, hono i te miro e taea te tā, me te i konei whakamahia ki `unwrap`.
// Kia faifai kore e hiahiatia ki te mahi pānui i te upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Whakahokia `true` ki te ko te taua rite `T` te momo pouaka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Haere `TypeId` o te momo instantiated tenei mahi te ki.
        let t = TypeId::of::<T>();

        // Haere `TypeId` o te momo i roto i te ahanoa trait (`self`).
        let concrete = self.type_id();

        // Whakatairitea nga `TypeId` e rua ki te taurite.
        t == concrete
    }

    /// Whakahokia etahi tohutoro ki te uara pouaka ki te he te reira o te momo `T`, `None` ranei ki te kore he reira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SAFETY: katahi ano ka tirohia mena e tohu ana taatau i te momo tika, a ka taea e taatau te whakawhirinaki
            // e taki mo te haumaru mahara no te mea kua whakatinana matou tetahi mo momo katoa;kore e taea e te tahi atu impls tīariari rite e fepaki ratou ki to tatou impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Whakahokia etahi tohutoro mutable ki te uara pouaka ki te he te reira o te momo `T`, `None` ranei ki te kore he reira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SAFETY: katahi ano ka tirohia mena e tohu ana taatau i te momo tika, a ka taea e taatau te whakawhirinaki
            // e taki mo te haumaru mahara no te mea kua whakatinana matou tetahi mo momo katoa;kore e taea e te tahi atu impls tīariari rite e fepaki ratou ki to tatou impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Whakamua ki te tikanga kua tautuhia ki te momo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Whakamua ki te tikanga kua tautuhia ki te momo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Whakamua ki te tikanga kua tautuhia ki te momo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Whakamua ki te tikanga kua tautuhia ki te momo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Whakamua ki te tikanga kua tautuhia ki te momo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Whakamua ki te tikanga kua tautuhia ki te momo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID me ona tikanga
///////////////////////////////////////////////////////////////////////////////

/// Ko te `TypeId` e tohu ana i tetahi tohu ahurei o te ao mo tetahi momo.
///
/// Ia `TypeId` Ko te ahanoa puatakore e kore nei e tukua tirohanga o te mea te roto, engari e tukua ngā mahi taketake pērā i te pūrua, whakarite, tā, me te whakaatu.
///
///
/// Ko te `TypeId` tēnei wā e wātea ana anake hoki ngā momo e waiho ki `'static`, engari kia kia nekehia atu tenei whāititanga i roto i te future.
///
/// Ahakoa `TypeId` whakatinana `Hash`, `PartialOrd`, ko `Ord`, he reira ia tapao e ka rerekē te Hashes me tono i waenganui i ngā putanga Rust.
/// Kia tupato ki te whakawhirinaki atu ki a raatau i roto i to waehere!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Whakahoki ai i te `TypeId` o te momo kua whakauruhia tenei mahi whanui.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Whakahokia ai te ingoa o te momo hei poro poro.
///
/// # Note
///
/// He tikanga tenei hei whakamahi maataatai.
/// Ko nga tino kiko me te whakatakotoranga o te aho i whakahokia mai kaore i te whakaatuhia, haunga te whakamaarama o te momo momo mahi.
/// Hei tauira, i roto i nga aho e kia hoki `type_name::<Option<String>>()` ko `"Option<String>"` me `"std::option::Option<std::string::String>"`.
///
///
/// Ko te aho i whakahokia mai kaua e kiia he tuuturu ahurei o te momo na te mea he maha nga momo ka mahere ki te ingoa momo.
/// Atoa, i reira he kore kī e ka puta wahi katoa o te momo i roto i te aho hoki: no te tauira, specifiers ra kahore e tēnei wā ngā.
/// Hei taapiri, ka rereke pea te putanga i waenga i nga momo whakahiato.
///
/// Ko te whakamahinga o naianei e whakamahi ana i nga hanganga taua rite ki nga taatai taatai me te debuginfo, engari kaore e tutuki tenei.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Whakahokia ai te ingoa o te momo uara tohu-ki te poro poro.
/// He rite tenei ki te `type_name::<T>()`, engari ka taea te whakamahi i te waa kaore e ngawari te waatea o te momo taurangi.
///
/// # Note
///
/// He tikanga tenei hei whakamahi maataatai.E kore e nga tirotiro tangohia me te hōputu o te aho i whakaritea, i tua atu i te i te whakaahuatanga pai-kaha o te momo.
/// Hei tauira, `type_name_of_val::<Option<String>>(None)` taea hoki `"Option<String>"` ranei `"std::option::Option<std::string::String>"`, engari e kore e `"foobar"`.
///
/// Hei taapiri, ka rereke pea te putanga i waenga i nga momo whakahiato.
///
/// e kore e tenei mahi whakatau ngā trait, te tikanga kia hoki `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"`, engari e kore e `"u32"`.
///
/// e kore e te whakaaro te ingoa momo he pūtāutu ahurei o te momo;
/// kia faaite momo maha te ingoa momo taua.
///
/// Ko te whakamahinga o naianei e whakamahi ana i nga hanganga taua rite ki nga taatai taatai me te debuginfo, engari kaore e tutuki tenei.
///
/// # Examples
///
/// Ka taarua i te taurangi totika taunoa me nga momo reanga.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}