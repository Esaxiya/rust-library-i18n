//! He ipu ka taea te huri.
//!
//! Ko te ahuru mahara a Rust e hangai ana ki tenei ture: I homai he taonga `T`, ka taea noa ko tetahi o enei e whai ake nei:
//!
//! - He maha ngā tohutoro pumau (`&T`) ki te ahanoa (hoki e mohiotia ana ko aliasing ** **).
//! - Kotahi te tohutoro ka taea te huri (`&mut T`) ki te ahanoa (e mohiotia ana ko **te rereketanga**).
//!
//! Ka whakamanahia tenei e te kaiwhakautu Rust.Heoi, kei kona ano etahi ahuatanga kaore i tino ngawari tenei ture.I etahi wa ka hiahiatia kia maha nga tohutoro ki tetahi mea a ka huria.
//!
//! Haeretia oko mutable tīari ki te tukua e mutability i roto i te tikanga whakahaeretia, ara i roto i te aroaro o te aliasing.Rua [`Cell<T>`] ko [`RefCell<T>`] e faati'a ai te mahi tenei i roto i te ara kotahi-whiria.
//! Heoi, kaore te `Cell<T>` me te `RefCell<T>` ranei i te miro haumaru (kaore e whakatinana i te [`Sync`]).
//! Ki te hiahia koe ki te mahi i aliasing me te irakētanga i waenganui i aho maha e taea ki te whakamahi i [`Mutex<T>`], [`RwLock<T>`] [`atomic`] ranei momo.
//!
//! kia kia mutated Uara o nga momo `Cell<T>` me `RefCell<T>` roto tohutoro ngā (ie
//! te momo `&T` noa), ko te nuinga o nga momo Rust ka taea noa te whakarereke ma nga korero motuhake (`&mut T`).
//! mea tatou e whakarato `Cell<T>` me `RefCell<T>` 'mutability roto', i roto i te taa ki angamaheni momo Rust e whakaatu 'riro mutability'.
//!
//! mai momo pūtau i roto i te rua rongo: `Cell<T>` ko `RefCell<T>`.`Cell<T>` ka whakatinana i te whakarereke o roto ma te neke i nga uara ki roto me waho o te `Cell<T>`.
//! Hei whakamahi i ngā tohutoro hei utu o uara, me te whakamahi i tetahi te momo `RefCell<T>`, whiwhi i te raka tuhituhi i mua i mutating.`Cell<T>` whakarato tikanga ki te tiki me te huri i te uara roto nāianei:
//!
//!  - Hoki ngā momo e whakatinana [`Copy`], tango te tikanga [`get`](Cell::get) te uara roto nāianei.
//!  - Hoki ngā momo e whakatinana [`Default`], whakakapi te tikanga [`take`](Cell::take) te uara roto nāianei ki [`Default::default()`] me hoki te uara whakakapi.
//!  - No te momo katoa, whakakapi te tikanga [`replace`](Cell::replace) te uara roto nāianei me hoki te uara whakakapi me te pau [`into_inner`](Cell::into_inner) tikanga te `Cell<T>` me hoki te uara roto.
//!  I tua atu, whakakapi te tikanga [`set`](Cell::set) te uara roto, iho te uara whakakapi.
//!
//! `RefCell<T>` ka whakamahi i nga wa o Rust ki te whakamahi i te 'nama kaha', he mahinga e taea ai e tetahi te kii mo te wa poto, motuhake, me te urunga ki te uara o roto.
//! Te tikina ano hoki `RefCell<T>"Ka rangahauhia 'i te wa watea', he rereke ki nga momo tohutoro taketake a Rust e tino tirotirohia ana, i te waa e whakahiatohia ana.
//! No te mea he hihiri `RefCell<T>` tarewa e taea ki te ngana ki te taonga tarewa i te uara e te kua mutably tono;ka tupu tenei hua te reira i roto i te miro panic.
//!
//! # A, no te ki te whiriwhiri i roto mutability
//!
//! Ko te rereketanga o te taonga tuku iho, ko te tikanga me uru motuhake ki te whakarereke i te uara, tetahi o nga mea nui o te reo e ahei ana te Rust ki te aata whakaaro mo te whakakoanga a te hunga tohu, me te aukati i nga aukati.
//! Na tenei, ko te rereketanga o nga taonga tuku iho e manakohia ana, a ko te whakarereke o roto tetahi mea tino pai.
//! I te mea ko nga momo o te pūtau e taea ai te whakarereke i te waahi kaore e whakaaehia, engari i etahi waa ka tika te whakarereke o roto, me *me* whakamahi, hei tauira
//!
//! * Te whakauru i te rereketanga 'inside' o tetahi mea kaore e taea te whakarereke
//! * ngā whakatinanatanga o ngā tikanga arorau-pumau.
//! * Mutating implementations o [`Clone`].
//!
//! ## Te whakauru i te rereketanga 'inside' o tetahi mea kaore e taea te whakarereke
//!
//! He maha nga momo tohu atawhai mohio, tae atu ki te [`Rc<T>`] me te [`Arc<T>`], he tohaina i nga ipu ka taea te kaata ka tohaina i waenga i nga roopu maha.
//! No te mea kia te uara roto tini-aliased, anake e taea te tono ratou ki `&`, e kore `&mut`.
//! Ki te kore nga pūtau kaore e taea te whakarereke i nga raraunga o roto i enei tohu mohio katoa.
//!
//! Ko te tino noa ka ki te hoatu te `RefCell<T>` roto momo atatohu ngā ki anō i mutability:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Hangaia he poraka hou hei whakaiti i te waahanga o te nama hihiri
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Kia mahara mena kaore i tukuna e tatou te nama o te keteroki kia taka ki waho o te waahi ka riro na te nama taapiri te miro hihiri panic.
//!     //
//!     // Koinei te raru nui mo te whakamahi i te `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Kia mahara ko tenei tauira e whakamahi ana i te `Rc<T>` kaore i te `Arc<T>`.`RefCell<T>`S kei hoki wheako kotahi-whiria.A feruri i te whakamahi i [`RwLock<T>`] [`Mutex<T>`] ranei, ki te titauhia ngā koe mutability i roto i te āhuatanga maha-whiria.
//!
//! ## Te whakamahi i nga taipitopito o nga tikanga whaitake-kore e taea te whakaputa
//!
//! I te tahi taime kia ai taua mea e minaminatia e kore ki te maka atu i roto i te API e reira he irakētanga e puta "under the hood".
//! pea tenei no te mea arorau he pumau te mahi, engari hei tauira, Keteroki ope te whakatinanatanga ki te mahi irakētanga;ranei no te mea me mahi koe te irakētanga ki te whakatinana i te tikanga trait e i tautuhia tuatahi ki te tango i `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Ka tata te tatau te utu
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutating implementations o `Clone`
//!
//! Ko te noa tenei he motuhake, engari noa, take o te mua: mutability piringa hoki ngā mahi e puta ana ki te kia pumau.
//! tūmanakohia ana te tikanga [`clone`](Clone::clone) te ki e kore e huri i te uara pūtake, me te whakaaturia ki te tango `&self`, e kore `&mut self`.
//! Na reira, i tetahi irakētanga e tupu i roto i te tikanga `clone` me te whakamahi i ngā momo pūtau.
//! Hei tauira, pupuritia [`Rc<T>`] ona kaute tohutoro i roto i te `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// He waahi maumahara.
///
/// # Examples
///
/// I roto i tenei tauira, ka taea e kite koe e `Cell<T>` āhei irakētanga i roto i te struct pumau.
/// I etahi atu kupu, ka taea te "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // HAPA: `my_struct` kaore e taea te neke
/// // my_struct.regular_field =uara_hou;
///
/// // NGĀ MAHI: ahakoa `my_struct` kaore e taea te whakaputa, `special_field` he `Cell`,
/// // e tonu e taea te mutated
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Tirohia te [module-level documentation](self) mo etahi atu.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Ka hangaia he `Cell<T>`, me te uara `Default` mo te T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Ka waihanga te `Cell` hou kei roto i te uara i homai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Ka tautuhia te uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Ngā nga uara o rua Pūtau.
    /// Difference ki `std::mem::swap` ko e kore e tenei mahi rapua e `&mut` tohutoro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // HAUMARU: Ka taea e kia tenei meá ki te karanga a i aho motuhake, engari `Cell`
        // Ko `!Sync` kia kore tenei e tupu.
        // Tenei e kore ano e muhu tetahi atatohu mai `Cell` hanga tetahi mea tino e atu e tuhu ki ranei o enei `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Ka whakakapi te uara roto ki `val`, a ka hoki te uara roto tawhito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // HAUMARU: tenei e taea e meinga iwi raraunga ki te karanga a i te miro motuhake,
        // engari `Cell` he `!Sync` na kaore tenei e puta.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Unwraps te uara.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Whakahokia ai he kape o te uara kei roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // HAUMARU: tenei e taea e meinga iwi raraunga ki te karanga a i te miro motuhake,
        // engari `Cell` he `!Sync` na kaore tenei e puta.
        unsafe { *self.value.get() }
    }

    /// Whakahōu te uara roto te whakamahi i te mahi me te hoki te uara hou.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Whakahoki ai i te atatohu maama ki nga maataapuna korero o tenei pūtau.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Whakahoki ai i te korero ka taea te whakarereke ki nga raraunga e whaaia ana.
    ///
    /// Ko tenei piiraa ka tono moni i te `Cell` (i te waa-whakahiato) e kii ana kei a matou anake te korero.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Whakahokia te `&Cell<T>` i te `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SAFETY: `&mut` whakarite i te urunga ahurei.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Ka mau i te uara o te pūtau, ka waiho ko te `Default::default()` ki tona wahi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Whakahokia ai he `&[Cell<T>]` mai i te `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // HAUMARU: `Cell<T>` kua te tahora mahara taua rite `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// He waahi maumahara me nga ture tono tarewa
///
/// Tirohia te [module-level documentation](self) mo etahi atu.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// He hapa hoki e [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// He hapa hoki e [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// uara mauritau tohu te maha o `Ref` kaha.uara tōraro tohu te maha o `RefMut` kaha.
// Ka taea e anake Maha, RefMut`s kia kaha i te wa ki te kōrero ratou ki motuhake, īnakinaki kore wāhanga o te `RefCell` (hei tauira, awhe rerekē o te wāhanga).
//
// `Ref` a ko te `RefMut` e rua nga kupu e rua te rahi, no reira kaore pea e ruarua nga "Ref`s ranei"RefMut`s hei waipuke ki te haurua o te whanui `usize`.
// Na, ko te `BorrowFlag` kaore pea e waipuke, kia heke ranei.
// Heoi, ehara tenei i te tohu taurangi, na te mea ka taea e te kaupapa patai te hanga i nga waa ka mem::forget `Ref`s, me te 'RefMut`s.
// Ko te kupu, me waehere katoa āta tirohia hoki waipuke me underflow i roto i te tikanga ki te karo unsafety, ranei i te iti rawa rangatira whawhai tika i roto i te kaupapa e te waipuke underflow ranei tupu (hei tauira, kite BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Ka waihanga te `RefCell` hou kei roto `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Ka pau te `RefCell`, ka whakahokia mai te uara kua takaia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Mai e tenei mahi `self` (te `RefCell`) i uara, te taupatupatu statically manatoko e kore e tarewa reira i tēnei wā.
        //
        self.value.into_inner()
    }

    /// Ka whakakapi te uara takai ki te tetahi hou, e hoki ana i te uara tawhito, kahore deinitializing rānei tetahi.
    ///
    ///
    /// Ko tenei mahi e pa ana ki te [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics ki te tono i te uara tēnei wā.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Ka whakakapihia te uara kua takaia ki te mea hou ka taatai mai i te `f`, ka whakahoki i te uara tawhito, kaore e whakakorehia tetahi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ki te tono i te uara tēnei wā.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Ngā te uara takai o `self` ki te uara takai o `other`, kahore deinitializing rānei tetahi.
    ///
    ///
    /// hāngai ana tēnei mahi ki [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics mena ka nama te uara o te `RefCell` i tenei wa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Immutably tikina te uara takaia.
    ///
    /// pumau i te taonga tarewa noa putaatu te `Ref` hoki hōkai.
    /// He maha nga nama kaore e taea te whakaputa i te wa ano.
    ///
    /// # Panics
    ///
    /// Panics ki te wā mutably nama te uara.
    /// Mo te panui kore-panicking, whakamahia [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// He tauira o panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Immutably tikina te uara takaia, hoki mai he hapa, ki te te wā mutably nama te uara.
    ///
    ///
    /// pumau i te taonga tarewa noa putaatu te `Ref` hoki hōkai.
    /// He maha nga nama kaore e taea te whakaputa i te wa ano.
    ///
    /// Ko te kē kore-ngohe o [`borrow`](#method.borrow) tenei.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SAFETY: Ma te `BorrowRef` e whakarite kia uru noa
            // ki te wariu i te nama.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Ka taea te tango i te uara kua takaia.
    ///
    /// pumau i te taonga tarewa noa te `RefMut` hoki ranei katoa, RefMut`s i takea mai i reira putanga hōkai.
    ///
    /// e kore e taea te tono i te uara i te he hohe tenei e tono he.
    ///
    /// # Panics
    ///
    /// Panics ki te tono i te uara tēnei wā.
    /// Mo te panui kore-panicking, whakamahia [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// He tauira o panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Ka taea te tono i te uara kua takaia, ka whakahoki he hapa mena ka namaina te uara i tenei wa.
    ///
    ///
    /// pumau i te taonga tarewa noa te `RefMut` hoki ranei katoa, RefMut`s i takea mai i reira putanga hōkai.
    /// e kore e taea te tono i te uara i te he hohe tenei e tono he.
    ///
    /// Koinei te rereketanga-kore o [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // wakaae `BorrowRef` uru ahurei: SAFETY.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Whakahoki ai i te atatohu maama ki nga maataapuna korero o tenei pūtau.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Whakahoki ai i te korero ka taea te whakarereke ki nga raraunga e whaaia ana.
    ///
    /// Ko tenei piiraa ka tono nama i te `RefCell` (i te waa-whakahiato) na reira kaore he take mo nga arowhai kaha.
    ///
    /// Heoi kia tupato: ko te tikanga tenei ka taea te huri i te `self`, kaore ke i te take ka whakamahi i te `RefCell`.
    ///
    /// Tirohia te tikanga [`borrow_mut`] mena ka kore e taea te huri i te `self`.
    ///
    /// Ano hoki, kia maarama ko tenei tikanga mo nga ahuatanga motuhake noa iho kaore ko te mea e hiahia ana koe.
    /// Mena he ruarua, whakamahia [`borrow_mut`] hei utu.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Whakakorehia te paanga o nga kaitiaki turuturu mo te ahua nama o te `RefCell`.
    ///
    /// He rite tenei piiraa ki [`get_mut`] engari he tohunga ake.
    /// tikina te reira i `RefCell` mutably ki te whakarite kore tarewa tīariari me ka tautuhi anō i te āhua aroturuki tarewa ngā.
    /// He paanga tenei mena kua puta mai etahi nama `Ref`, `RefMut` ranei.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Immutably tikina te uara takaia, hoki mai he hapa, ki te te wā mutably nama te uara.
    ///
    /// # Safety
    ///
    /// Rerekē `RefCell::borrow`, he haumaru tenei tikanga no te mea e kore te reira e hoki te `Ref`, ko te kupu mahue te haki e tono he toe.
    /// Mutably tarahu i te `RefCell` i te tohutoro hoki i tenei tikanga ko ora he whanonga kāore.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // HAUMARU: tirohia matou te kaha te tuhi i taua tangata inaianei, engari ko te reira
            // te kawenga a te kaiwaea ki te whakarite kia kaua tetahi e tuhi tae noa ki te hokinga mai o te tohutoro.
            // Hoki, e pā ana `self.value.get()` ki te uara nā `self` me te kupu kī ki te kia tika hoki te ora o `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// E te uara takaia, mahue `Default::default()` i tona wahi.
    ///
    /// # Panics
    ///
    /// Panics ki te tono i te uara tēnei wā.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics ki te wā mutably nama te uara.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Ka hangaia he `RefCell<T>`, me te uara `Default` mo te T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics mena ka nama te uara o te `RefCell` i tenei wa.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics mena ka nama te uara o te `RefCell` i tenei wa.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics mena ka nama te uara o te `RefCell` i tenei wa.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics mena ka nama te uara o te `RefCell` i tenei wa.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics mena ka nama te uara o te `RefCell` i tenei wa.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics mena ka nama te uara o te `RefCell` i tenei wa.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics mena ka nama te uara o te `RefCell` i tenei wa.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Incrementing e tono he e taea te hua i roto i te uara kore-pānui (<=0) i roto i enei take:
            // 1. I <0, ara he nama tuhi, na reira kaore e taea e taatau te tuku nama panui na nga ture tuku korero a Rust
            // 2.
            // Ko isize::MAX (te nui max o pānui tarewa) a ngawha ki runga i ki isize::MIN (te nui max o tuhi tarewa) kia kore e taea e tatou e tuku i te tono he pānui atu no te mea e kore isize taea tohu na maha tarewa pānui (taea anake tenei tupu ki te koe mem::forget neke atu i te nui tamau iti o `Ref`s, e kore te mea e mahi pai)
            //
            //
            //
            //
            None
        } else {
            // Ko te nama nama ka hua te uara o te panui (> 0) i enei keehi:
            // 1. Ko=0, e kore arā reira i tono, a ka e tango tatou i te tikina pānui tuatahi
            // 2. Ko te> 0 me <isize::MAX, arā
            // i panuihia nga nama, a he nui te hiiti hei tohu kia kotahi ano te nama nama
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Mai te vai tenei Ref, e matau ana tatou ki te haki e tono he ko te tikina pānui.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Aukatihia te kaitautoko nama mai i te waipuke ki roto i te nama tono tuhinga.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Takaia te tohutoro tono ki te uara i roto i te pouaka `RefCell`.
/// He momo takai mo te uara kaore e taea te whakaputa ke mai i te `RefCell<T>`.
///
/// Tirohia te [module-level documentation](self) mo etahi atu.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Ka kape i te `Ref`.
    ///
    /// Ko te `RefCell` kua oti ke te tuku nama, no reira kaore e kore tenei.
    ///
    /// Ko te mahi e hāngai ana e tika ana kia whakamahia rite `Ref::clone(...)` tenei.
    /// He whakatinanatanga `Clone` he tikanga ranei e pokanoa ki te whakamahi whānui o `r.borrow().clone()` ki te ki tou te tirotiro o te `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// He whakaahua i te `Ref` hou mo te wāhanga o te raraunga tono.
    ///
    /// Ko te `RefCell` kua oti ke te tuku nama, no reira kaore e kore tenei.
    ///
    /// Ko te mahi e hāngai ana e tika ana kia whakamahia rite `Ref::map(...)` tenei.
    /// Ka raru tetahi tikanga i nga tikanga o te ingoa kotahi i runga i nga korero o te `RefCell` i whakamahia na `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// He whakaahua i tētahi `Ref` hou mo te wāhanga kōwhiringa o te raraunga tono.
    /// Ko te kaitiaki taketake ka whakahokia hei `Err(..)` mena ka kati te katinga `None`.
    ///
    /// Ko te `RefCell` kua oti ke te tuku nama, no reira kaore e kore tenei.
    ///
    /// He mahi honohono tenei hei whakamahi i te `Ref::filter_map(...)`.
    /// Ka raru tetahi tikanga i nga tikanga o te ingoa kotahi i runga i nga korero o te `RefCell` i whakamahia na `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Whakawehe i te `Ref` ki maha `Ref`s hoki wāhanga rerekē o te raraunga tono.
    ///
    /// Ko te `RefCell` kua oti ke te tuku nama, no reira kaore e kore tenei.
    ///
    /// He mahi honohono tenei hei whakamahi i te `Ref::map_split(...)`.
    /// Ka raru tetahi tikanga i nga tikanga o te ingoa kotahi i runga i nga korero o te `RefCell` i whakamahia na `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Faafariu ki te tohutoro ki te raraunga whāriki.
    ///
    /// Ko te tūāpapa `RefCell` taea kore te mutably tono i ano, a ka puta tonu kua immutably tono.
    ///
    /// Ehara i te whakaaro pai te turuturu atu i te maha noa o nga tohutoro.
    /// Ka taea ano te nama ke i te `RefCell` mena he iti noa nga rerenga kua puta katoa.
    ///
    /// He mahi honohono tenei hei whakamahi i te `Ref::leak(...)`.
    /// Ka raru tetahi tikanga i nga tikanga o te ingoa kotahi i runga i nga korero o te `RefCell` i whakamahia na `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Na roto i te wareware tenei Ref whakarite tatou e kore e taea e te counter e tono he i roto i te RefCell haere hoki ki kāore i roto i te ora `'b`.
        // Ko te tautuhi i te ahua aroturuki tohutoro ka hiahiatia he tohutoro motuhake ki te RefCell nama.
        // Kaore e taea te hanga i etahi atu tohutoro ka taea te hanga mai i te pūtau taketake.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Ka hangaia he `RefMut` hou mo te waahanga o nga tuhinga nama, hei tauira, he momo enum.
    ///
    /// Kei te kē mutably tono te `RefCell`, kia kore e taea e tenei kore.
    ///
    /// Ko te mahi e hāngai ana e tika ana kia whakamahia rite `RefMut::map(...)` tenei.
    /// Ka raru tetahi tikanga i nga tikanga o te ingoa kotahi i runga i nga korero o te `RefCell` i whakamahia na `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): whakatika-taatai-tirotiro
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Ka hangaia he `RefMut` hou mo tetahi waahanga waahanga o nga tuhinga nama.
    /// Ko te kaitiaki taketake ka whakahokia hei `Err(..)` mena ka kati te katinga `None`.
    ///
    /// Kei te kē mutably tono te `RefCell`, kia kore e taea e tenei kore.
    ///
    /// Ko te mahi e hāngai ana e tika ana kia whakamahia rite `RefMut::filter_map(...)` tenei.
    /// Ka raru tetahi tikanga i nga tikanga o te ingoa kotahi i runga i nga korero o te `RefCell` i whakamahia na `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): whakatika-taatai-tirotiro
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SAFETY: kei te mahi tetahi tohutoro motuhake mo te roanga
        // o tana piiraa na roto i te `orig`, a ko te tohu tohu he tohu-noa i roto i te waeatanga mahi kaore e ahei te tuku i te tohutoro motuhake kia rere.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SAFETY: he rite ki runga ake nei.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Whakawehe i te `RefMut` ki maha `RefMut`s mō wāhanga rerekē o te raraunga tono.
    ///
    /// Ko te `RefCell` kei raro nei ka noho nama tonu kia hoki mai ra ano te hunga "RefMut` ki te ngaro.
    ///
    /// Kei te kē mutably tono te `RefCell`, kia kore e taea e tenei kore.
    ///
    /// Ko te mahi e hāngai ana e tika ana kia whakamahia rite `RefMut::map_split(...)` tenei.
    /// Ka raru tetahi tikanga i nga tikanga o te ingoa kotahi i runga i nga korero o te `RefCell` i whakamahia na `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Hurihia hei tohu mutable ki nga maataapuna korero.
    ///
    /// Kaore e taea te nama mai i te `RefCell` e whaaia ana, ka puta ano hoki kua puta ke te ahua o te nama, me te whakahoki ano ko te roto anake.
    ///
    ///
    /// He mahi honohono tenei hei whakamahi i te `RefMut::leak(...)`.
    /// Ka raru tetahi tikanga i nga tikanga o te ingoa kotahi i runga i nga korero o te `RefCell` i whakamahia na `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Ma te wareware ki tenei BorrowRefMut ka tutuki i a maatau te nama nama i te RefCell kaore e hoki ki UNUSED i roto i te roanga o te tau `'b`.
        // Ko te tautuhi i te ahua aroturuki tohutoro ka hiahiatia he tohutoro motuhake ki te RefCell nama.
        // Ka taea te hanga kahore atu tohutoro i te pūtau taketake i roto i taua ora, hanga i te tono he nāianei nga anake tohutoro mo te toe ora.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Kaore i te BorrowRefMut::clone, ka karangahia he hou hei hanga i te tuatahi
        // tohutoro ka taea te whakarereke, no reira kaore kau he tohutoro o tenei wa.
        // Na, i te wa e whakanui ana te kaute i te tatauranga ka taea te huri, i konei ka tino whakaae maatau kia haere mai i UNUSED ki UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Iramate he `BorrowRefMut`.
    //
    // He tika noa tenei mena ka whakamahia ia `BorrowRefMut` ki te whai i tetahi tohu whakahuri ki tetahi waahanga motuhake, kore whakawhitiwhitinga o te mea taketake.
    //
    // E kore te mea tenei i roto i te impl Tārite kia kore e taua waehere karanga tenei kakato.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Ārai i te counter e tono he i te underflowing.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// He momo takai mo te uara e kaha tono ana mai i te `RefCell<T>`.
///
/// Tirohia te [module-level documentation](self) mo etahi atu.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Ko te matua i tahito ra no te mutability roto i Rust.
///
/// Mena he `&T` to korero, na Rust noa te mahi a te kaiwhakatuutu i runga i te maaramatanga e tohu ana a `&T` i nga tuhinga kaore e taea te whakarereke.Ko te whakarereke i taua tuhinga, hei tauira ma te ingoakore, ma te tuku `&T` ranei ki te `&mut T`, ka kiia he whanonga kore.
/// `UnsafeCell<T>` he kowhiri-i te taurangi pumau mo `&T`: ko te tohutoro `&UnsafeCell<T>` tera pea ka tohu ki nga raraunga e whakarerekehia ana.huaina ana tēnei ko "interior mutability".
///
/// Ko etahi atu momo e whakaae ana ki te whakarereke o roto, penei i te `Cell<T>` me te `RefCell<T>`, ka whakamahi a roto i te `UnsafeCell` hei takai i a raatau raraunga.
///
/// Kia mahara ko te taurangi pumau anake mo nga tohutoro tiri ka pa ki a `UnsafeCell`.Ko te tohu motuhake mo nga tohutoro ka taea te whakararu.Kahore he *kahore ara ture* ki te whiwhi aliasing `&mut`, e kore noa ki `UnsafeCell<T>`.
///
/// Ko te `UnsafeCell` API ano he mea maamaa noa: he [`.get()`] e hoatu ana ki a koe he tohu tohu `*mut T` katoa me nga korero o roto.Ka tae atu ki te _you_ hei kaihoahoa tango ki te whakamahi tika i taua tohu noa.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Ko nga ture whakahoahoa Rust tika tonu kua paku haere, engari ko nga kaupapa matua kaore i te tautohe:
///
/// - Ki te hanga koe i te tohutoro haumaru ki ora `'a` (rānei te `&T` ranei `&mut T` tohutoro) e he wātea i waehere haumaru (hei tauira, no te mea hoki koe i te reira), na me kore te uru koutou te raraunga i roto i tetahi ara e fepaki e tohutoro mo te toenga Tuhinga o mua.
/// Hei tauira, tenei tikanga e ki te tangohia e koe te `*mut T` i te `UnsafeCell<T>`, a maka ana e ia ki te `&T`, na me noho te raraunga i roto i `T` pumau (modulo kitea tetahi raraunga `UnsafeCell` roto `T`, o te akoranga) tae noa pau ora o taua tohutoro.
/// Waihoki, ki te hanga e koe he tohutoro `&mut T` ka tukuna ki te waehere haumaru, na me matua uru koe ki nga korero o roto i te `UnsafeCell` kia mate ra ano taua korero.
///
/// - I nga wa katoa, me te karo koe iwi raraunga.Ki te whai wāhi ki te taua `UnsafeCell` aho maha, ka me whai i tetahi tuhia e te tika tupu-i mua i pā ana ki ētahi atu whai katoa (te whakamahi atomics ranei).
///
/// Hei āwhina ki te hoahoa tika, e āta whakapuakina te wheako e whai ake nei ture mō te waehere kotahi-whiria:
///
/// 1. Ka taea te tuku tohutoro `&T` ki te waehere haumaru ana kei reira ka noho tahi me etahi atu tohutoro `&T`, engari kaore me te `&mut T`
///
/// 2. kia kia tukua te `&mut T` tohutoro ki te waehere haumaru ngā kore atu `&mut T` ranei `&T` tahi-te tīariari ki reira.Me kia ahurei tonu A `&mut T`.
///
/// Kia mahara koe i te wa e whakarereke ana i nga korero o te `&UnsafeCell<T>` (ahakoa etahi atu tohutoro `&UnsafeCell<T>` me te rekoata) he pai (mena ka whakamana e koe etahi atu kaitono i runga ake nei), kaore ano kia tautuhia he whanonga `&mut UnsafeCell<T>` maha.
/// Ko, `UnsafeCell` ko te Uwhi hangaia ki te whai i te ngā motuhake ki _shared_ accesses (_i.e._, i roto i te tohutoro `&UnsafeCell<_>`);kaore he mahi makutu i te wa e pa ana ki te _exclusive_ accesses (_e.g._, ma roto i te `&mut UnsafeCell<_>`): kaore hoki te kamera, te uara roropi ranei e taea te whakakii mo te roanga o te nama `&mut`.
///
/// whakaaturia ana tēnei e te accessor [`.get_mut()`], i te mea he _safe_ getter e hua he `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Anei tetahi tauira e whakaatu ana me pehea te whakarereke i nga korero o te `UnsafeCell<_>` ahakoa he maha nga tohutoro hei whakakii i te pūtau.
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Tangohia nga tohutoro maha/tohaina ki te `x` ano.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // HAUMARU: i roto i tenei hōkai i reira he kahore atu tohutoro ki `tirotiro o x`,
///     // no reira he tino ahurei to taatau.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- tarewa-+
///     *p1_exclusive += 27; // |
/// } // <---------- e kore e taea e haere ki tua atu i tenei wāhi -------------------+
///
/// unsafe {
///     // SAFETY: i roto i tenei waahanga kaore tetahi e hiahia kia uru noa ki nga tuhinga o te 'x`,
///     // kia taea ai e taatau te uru atu ki nga huihuinga maha i te wa kotahi.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Ko te tauira e whai ake nei e whakaatu ana i te urunga motuhake ki te `UnsafeCell<T>` e tohu ana i te urunga motuhake ki tana `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // ki whai motuhake,
///                         // `UnsafeCell` Ko te Uwhi kahore-op mārama, na kahore he take mo `unsafe` konei.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Tikina te tohutoro ahurei whakahiato-wā-tirohia ki `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Ki te tohutoro motuhake, ka taea e tatou mutate te tirotiro mō te kore utu.
/// *p_unique.get_mut() = 0;
/// // Ranei, equivalently:
/// x = UnsafeCell::new(0);
///
/// // A, no te ake tatou te uara, ka taea e tatou te unu i nga tirotiro mō te kore utu.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Ka hangaia e te tauira hou o `UnsafeCell` e e roropi te uara i tohua.
    ///
    ///
    /// Katoa te urunga atu ki te uara o roto na nga tikanga ko te `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Unwraps te uara.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Ka whiwhi tohu ki te uara takaia.
    ///
    /// Ka taea tenei ki te tuku ki tetahi tohu tohu ahakoa te ahua.
    /// Tirohia he ahurei te urunga (kaore he tohutoro hohe, ka taea te huri, kaore ranei) i te wa e tukuna ana ki te `&mut T`, me te whakarite kia kore he rereketanga, he tohu rereke ranei e huri ana ka tukuna ana ki `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Ka taea e tatou maka noa te atatohu i `UnsafeCell<T>` ki `T` no o #[repr(transparent)].
        // hē tūnga motuhake o libstd tenei, kahore he kī mō te waehere kaiwhakamahi e ka mahi tenei i roto i future putanga o te taupatupatu!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Whakahoki ai i te korero ka taea te whakarereke ki nga raraunga e whaaia ana.
    ///
    /// Tenei karanga tikina te `UnsafeCell` mutably (i whakahiato-wā) e whakapūmau e riro tatou anake te tohutoro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Ka whiwhi tohu ki te uara takaia.
    /// Ko te rereketanga ki te [`get`] ko tenei mahi ka whakaae ki tetahi tohu tika, he mea pai ki te karo i te hanga tohutoro poto.
    ///
    /// Ko te mutunga ka taea te tuku ki tetahi tohu tohu ahakoa he aha.
    /// Tirohia he ahurei te urunga (kaore he tohutoro hohe, ka taea te whakarereke kaore ranei) i te wa e tukuna ana ki `&mut T`, me te whakarite kia kore he rereketanga, he tohu rereke ranei e huri ana ka tukuna ana ki `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Ko te whakaurutanga o te `UnsafeCell` me `raw_get`, me te karanga i te `get` me hanga he korero ki nga raraunga kaore i whakauruhia:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Ka taea e tatou maka noa te atatohu i `UnsafeCell<T>` ki `T` no o #[repr(transparent)].
        // hē tūnga motuhake o libstd tenei, kahore he kī mō te waehere kaiwhakamahi e ka mahi tenei i roto i future putanga o te taupatupatu!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// He waihanga he `UnsafeCell`, ki te uara `Default` mo T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}