#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Ka toro atu ki te `$crate::panic::panic_2015` ko te `$crate::panic::panic_2021` ranei kei runga i te putanga o te kaiwaea.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Kanui to e he rite ki tetahi ki tetahi e rua kīanga (te whakamahi i [`PartialEq`]).
///
/// I panic, ka tā tenei tonotono nga uara o nga kīanga me ratou ngā patuiro.
///
///
/// Ka rite ki [`assert!`], tenei tonotono kua he puka tuarua, te wahi e taea te whakaratohia he karere panic ritenga.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // He whakaae nga reborrows i raro.
                    // Te kore ratou, arawhiti te mokamoka tāpae mo te tono he te ara i mua i e whakaritea te uara, ārahi ki te raro, puhoi kite.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // He whakaae nga reborrows i raro.
                    // Te kore ratou, arawhiti te mokamoka tāpae mo te tono he te ara i mua i e whakaritea te uara, ārahi ki te raro, puhoi kite.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Kanui to e kore e rite ki tetahi ki tetahi e rua kīanga (te whakamahi i [`PartialEq`]).
///
/// I panic, ka tā tenei tonotono nga uara o nga kīanga me ratou ngā patuiro.
///
///
/// Ka rite ki [`assert!`], tenei tonotono kua he puka tuarua, te wahi e taea te whakaratohia he karere panic ritenga.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // He whakaae nga reborrows i raro.
                    // Te kore ratou, arawhiti te mokamoka tāpae mo te tono he te ara i mua i e whakaritea te uara, ārahi ki te raro, puhoi kite.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // He whakaae nga reborrows i raro.
                    // Te kore ratou, arawhiti te mokamoka tāpae mo te tono he te ara i mua i e whakaritea te uara, ārahi ki te raro, puhoi kite.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Kanui to e te faaiteraa boolean ko `true` i wāhaere.
///
/// Tenei ka mahara ra te tonotono [`panic!`] ki te kore e taea te aro mātai i te faaiteraa e whakaratohia ana ki a `true` i wāhaere.
///
/// Ka rite ki [`assert!`], tenei tonotono hoki kua he putanga tuarua, te wahi e taea te whakaratohia he karere panic ritenga.
///
/// # Uses
///
/// Rerekē [`assert!`], e anake whakahohea tauākī `debug_assert!` i kore papaitia hanga i te taunoa.
/// Ko te hanganga papaihia kaore e tukuna nga korero `debug_assert!` ki te kore `-C debug-assertions` e tukuna ki te kaiwhakaputu.
/// hanga `debug_assert!` whai hua mō ngā arowhai e te hunga utu rawa ki te kia hakari i roto i te hanga tuku engari kia kia āwhina i roto i te whanaketanga tenei.
/// Kei te momo takina tonu te hua o whakawhänui `debug_assert!`.
///
/// He whakapae kore taki taea te hōtaka i roto i te āhua maiorooro ki te pupuri i rere, e ai whai hopearaa ohorere engari e kore e whakauru i unsafety rite te roa rite anake tenei tupu i roto i te waehere haumaru.
///
/// Ko te utu mahi o tāpaetanga, Heoi kahore he ine i te whānui,.
/// Whakakapi [`assert!`] ki `debug_assert!` te kupu anake ākina i muri profiling tino, a nui atu, anake i roto i te waehere haumaru!
///
/// # Examples
///
/// ```
/// // te karere panic mo enei kīanga ko te uara stringified o te faaiteraa i homai.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // he mahi tino ngawari
/// debug_assert!(some_expensive_computation());
///
/// // whakapuaki ki te karere ritenga
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// E kii ana e rua nga whakahuatanga e rite ana tetahi ki tetahi.
///
/// I panic, ka tā tenei tonotono nga uara o nga kīanga me ratou ngā patuiro.
///
/// Rerekē [`assert_eq!`], e anake whakahohea tauākī `debug_assert_eq!` i kore papaitia hanga i te taunoa.
/// e kore e He hanga papaitia mahia tauākī `debug_assert_eq!` te kore haere te `-C debug-assertions` ki te taupatupatu.
/// hanga `debug_assert_eq!` whai hua mō ngā arowhai e te hunga utu rawa ki te kia hakari i roto i te hanga tuku engari kia kia āwhina i roto i te whanaketanga tenei.
///
/// Kei te momo takina tonu te hua o whakawhänui `debug_assert_eq!`.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// E kii ana e rua nga whakahuatanga kaore i te orite ki a raatau.
///
/// I panic, ka tā tenei tonotono nga uara o nga kīanga me ratou ngā patuiro.
///
/// Kaore i rite ki te [`assert_ne!`], ko nga korero `debug_assert_ne!` ka whakahohea noa i nga waahanga kaore i te papaihia i te taunoa.
/// e kore e He hanga papaitia mahia tauākī `debug_assert_ne!` te kore haere te `-C debug-assertions` ki te taupatupatu.
/// hanga `debug_assert_ne!` whai hua mō ngā arowhai e te hunga utu rawa ki te kia hakari i roto i te hanga tuku engari kia kia āwhina i roto i te whanaketanga tenei.
///
/// Kei te momo takina tonu te hua o whakawhänui `debug_assert_ne!`.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Hoki ahakoa ōrite te faaiteraa homai tetahi o nga tauira i homai.
///
/// Ka rite ki te whakaaturanga `match`, ka taea te kowhiri i te tauira ma te `if` me te kiato kaitiaki e uru ana ki nga ingoa e herea ana e te tauira.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Unwraps te hua whakanoho tona hapa ranei.
///
/// i honoa te operator `?` ki te whakakapi `try!` a kia whakamahia hei utu.
/// I tua atu, `try` ko te kupu rangatira i Rust 2018, na te mea me whakamahi koe i reira, ka hiahia koe ki te whakamahi i te [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ōrite ki te [`Result`] i homai.Mena he rereketanga `Ok`, ko te whakahua he uara o te uara takai.
///
/// I roto i te take o te kē `Err`, nanao reira te hapa i roto.ka mahi `try!` faafariuraa te whakamahi i `From`.
/// Ma tenei ka huri noa i waenga i nga hapa motuhake me nga mea noa ake.
/// Kei te ka hoki mai tonu te hapa hua.
///
/// No te mea o te hoki wawe nga, anake e taea te whakamahi `try!` i roto i ngā mahi e hoki mai [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Te tikanga pai mo te whakahoki wawe i nga Hapa
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Ko te tikanga o mua mo te whakahoki wawe i nga Hapa
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Ko te ōrite ki tenei:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Ka tuhi i nga rarangi whakahōputuhia ki roto i te pere.
///
/// whakaae ana tēnei tonotono he 'writer', he aho hōputu, me te rārangi o ngā tohenga.
/// Ka kia whakahōputu tohenga rite ki te aho hōputu tohua a ka te hua kia haere ki te kaituhi.
/// pea te kaituhi tetahi uara ki te tikanga `write_fmt`;te tikanga mai tenei i te whakatinanatanga o te [`fmt::Write`] rānei ranei te [`io::Write`] trait.
/// Ko te hoki tonotono mea katoa hoki tikanga te `write_fmt`;noa he [`fmt::Result`], he [`io::Result`] ranei.
///
/// Tirohia te [`std::fmt`] mō ētahi atu mōhiohio i runga i te wetereo hōputu string.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Ka taea e te kōwae kawemai rua `std::fmt::Write` ko `std::io::Write` me karanga `write!` i runga i ngā whakatinana rānei, rite kore e taonga nuinga whakatinana e rua.
///
/// Heoi, i whai te kōwae me kawemai te traits kia kore mahi ratou ingoa pakanga:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // Ka whakamahia e fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // whakamahi io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Ka taea te whakamahi i tenei tonotono i nga tatai `no_std` hoki.
/// I roto i te whakaturanga `no_std` kei a koe te kawenga mo nga korero whakatinana mo nga waahanga.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Tuhia raraunga whakahōpututia ki te moka, ki te rainahou āpitihia.
///
/// I te tüäpapa katoa, te rainahou ko te pūāhua RĀRANGI KAI A (`\n`/`U+000A`) anake (kahore atu Tuhinga RETURN (`\r`/`U+000D`).
///
/// Mō ētahi atu pārongo, kite [`write!`].Hoki ngā mōhiohio i runga i te aho wetereo hōputu, kite [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Ka taea e te kōwae kawemai rua `std::fmt::Write` ko `std::io::Write` me karanga `write!` i runga i ngā whakatinana rānei, rite kore e taonga nuinga whakatinana e rua.
/// Heoi, i whai te kōwae me kawemai te traits kia kore mahi ratou ingoa pakanga:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // Ka whakamahia e fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // whakamahi io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Tohu waehere ūnga.
///
/// Ko te pai tenei i tetahi wa e kore e taea e te taupatupatu whakatau e he ūnga etahi waehere.Hei tauira:
///
/// * Ōrite ringa ki tikanga kaitiaki.
/// * Koropiko e whakamutu hihiri.
/// * Iterators e hihiri whakamutu.
///
/// Ki te faaite i te faaotiraa e he ūnga te waehere hē, Aukatihia ai tonu te hōtaka ki te [`panic!`].
///
/// Ko te tauira haumaru o tenei tonotono ko te mahi [`unreachable_unchecked`], e ka meinga whanonga kāore ki te tae te waehere te.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Tenei i pai ai i nga wa katoa [`panic!`].
///
/// # Examples
///
/// Whakatika ringa:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // whakahiato hapa mena ka puta te korero
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // tetahi o nga whakatinanatanga rawakore o x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Tohu waehere unimplemented mā te ngohe ki te karere o "not implemented".
///
/// Tenei taea tō waehere ki momo-Taki, e te mea pai ki te e prototyping koe te whakatinana i te trait e titau tikanga maha e kore mahi koutou mahere o te whakamahi i te katoa o ranei.
///
/// Ko te rerekētanga i waenganui i `unimplemented!` me [`todo!`] ko e ia `todo!` tuku he whakaaro o te whakatinana i te taumahinga muri me te kupu, ko te "not yet implemented", hanga `unimplemented!` kahore kerēme taua.
/// Ko tōna karere ko "not implemented".
/// Me etahi IDE ka tohu i te `todo!` S.
///
/// # Panics
///
/// Tenei i pai ai [`panic!`] tonu no te mea ko `unimplemented!` he takinga tika mo `panic!` ki te whakaritea, karere motuhake.
///
/// Ka rite ki `panic!`, tenei tonotono kua he puka tuarua mō te whakaatu ngā uara ritenga.
///
/// # Examples
///
/// Mea atu to tatou he trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// e hiahia ana matou ki te whakatinana i `Foo` mo 'MyStruct', engari mo etahi take reira anake hanga tikanga ki te whakatinana i te mahi `bar()`.
/// `baz()` a ka Me `qux()` tonu ki te kia tautuhia i roto i to tatou whakatinanatanga o `Foo`, engari ka taea e tatou te whakamahi i `unimplemented!` i roto i o ratou whakamāramatanga ki te tukua to tatou waehere ki whakahiato.
///
/// Kei te hiahia tonu taatau kia mutu te whakahaere o ta maatau kaupapa mena ka tutuki nga tikanga koretake.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Kaore he tikanga ki te `baz` a `MyStruct`, na reira kaore o maatau whakaaro i konei.
/////
///         // Tenei ka whakaatu "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // E tatou etahi arorau konei, ka taea e tatou te tāpiri i te karere ki unimplemented!ki te whakaatu i to tatou a °.
///         // Tenei ka whakaatu: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// He tohu waehere kaore ano kia oti.
///
/// Ka taea e kia whai hua tenei ki te e prototyping koutou me e tika te titiro ki te whai i to koutou typecheck waehere.
///
/// Ko te rerekētanga i waenganui i [`unimplemented!`] me `todo!` ko e ia `todo!` tuku he whakaaro o te whakatinana i te taumahinga muri me te kupu, ko te "not yet implemented", hanga `unimplemented!` kahore kerēme taua.
/// Ko tōna karere ko "not implemented".
/// Me etahi IDE ka tohu i te `todo!` S.
///
/// # Panics
///
/// Tenei i pai ai i nga wa katoa [`panic!`].
///
/// # Examples
///
/// Anei he tauira o etahi waehere i roto i-te ahunga whakamua.E tatou te trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// e hiahia ana matou ki te whakatinana i `Foo` i tetahi o matou momo, engari e hiahia ana ano hoki matou ki te mahi i runga i tika `bar()` tuatahi.I roto i te tikanga mo to tatou waehere ki whakahiato, Me matou ki te whakatinana i `baz()`, kia taea tatou te whakamahi i `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // whakatinana haere konei
///     }
///
///     fn baz(&self) {
///         // kaua e manukanuka ki te whakatinana i te baz() mo tenei wa
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // E kore noa te whakamahi i tatou baz(), na ko te pai tenei.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Whakamāramatanga o hanga-i roto i ngā tonotono.
///
/// tangohia te nuinga o nga āhuatanga tonotono (pūmautanga, aritanga, etc) e i te waehere pūtake konei, ki te haunga o mahi roha whakaahua kōkuhunga tonotono ki whakaputanga, e whakaratohia aua mahi e te taupatupatu.
///
///
pub(crate) mod builtin {

    /// Kaare e ngoikore te whakahiato me nga kupu hapa i te wa e tu ana.
    ///
    /// kia whakamahia tēnei tonotono ina whakamahi i te crate he rautaki kohinga herenga ki te whakarato i ngā karere pai hapa mō ngā āhuatanga hape.
    ///
    /// Ko te te puka taumata-taupatupatu o [`panic!`], engari E faatae mai te hapa i roto i haaputuputuraa * * nui atu i i te wā * *.
    ///
    /// # Examples
    ///
    /// E rua taua tauira he tonotono me taiao `#[cfg]`.
    ///
    /// Emit pai hapa taupatupatu, ki te haere i te tonotono te uara muhu.
    /// Te kore te branch whakamutunga, te taupatupatu e emit tonu he hapa, engari karere o te hapa e kore e whakahua i te uara tika rua.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Whakawhitahia te hapa kaitoha mena kaore i te waatea tetahi o nga ahuatanga.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ka hangaia e tawhā mo te tahi atu tonotono string-whakahōputu.
    ///
    /// Ka mahi tenei tonotono ma te tango i tetahi aho whakahou he `{}` mo ia taapiri taapiri kua paahitia.
    /// `format_args!` faaineine te atu tawhā ki te whakarite i te putanga e taea te whakaatu ai rite te aho, me te canonicalizes nga tautohetohe ki te momo kotahi.
    /// Tetahi uara e ngā taea te haere te [`Display`] trait ki `format_args!`, rite e taea tetahi whakatinanatanga [`Debug`] kia haere ki te `{:?}` i roto i te aho whakahōputu.
    ///
    ///
    /// Tenei tonotono hua te uara o te momo [`fmt::Arguments`].Ka taea te tuku i tenei uara ki nga tohutō i roto i te [`std::fmt`] hei whakamahi i te ahutanga whaihua.
    /// Katoa o nga toka whakahōpututanga ([`whakatakotoranga!`], [`write!`], [`println!`], me etahi atu) ka haangai mo tenei.
    /// `format_args!`, pērā ona tonotono ahu, mawehe opehia tohatoha.
    ///
    /// Ka taea e koe te whakamahi i te uara [`fmt::Arguments`] ka hoki mai a `format_args!` i nga horopaki `Debug` me `Display` e kitea ana i raro nei.
    /// Ko te tauira e whakaatu ana ko te whakatakotoranga `Debug` me te `Display` ki taua mea ano: ko te aho whakatakotoranga hono i `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Mo etahi atu korero, tirohia nga tuhinga kei [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Rite `format_args`, engari tāpiri he rainahou i roto i te mutunga.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Ka tirotirohia te taurangi taiao i te wa whakahiato.
    ///
    /// Ka whakawhānui i tēnei tonotono ki te uara o te tāupe taiao ko i wa whakahiato, whai i te faaiteraa o te momo `&'static str`.
    ///
    ///
    /// Ki te kore te tautuhi te tāupe taiao, katahi ka kia tukuna he hapa kohinga.
    /// Ki te kore e emit te hapa whakahiato, te whakamahi i te tonotono [`option_env!`] hei utu.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Ka taea e koe te whakarite i te karere hapa i te haere i te aho rite te rua te tawhā:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Mena kaore i te tautuhia te taurangi o te taiao `documentation`, ka hapa koe i enei:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// He kowhiri ka tirotirohia te taurangi taiao i te wa whakahiato.
    ///
    /// Ki te he reira i te wa whakahiato te tāupe taiao ingoa, ka whakawhānui i tenei ki te faaiteraa o te momo `Option<&'static str>` tona uara ko `Some` o te uara o te tāupe taiao.
    /// Ki te kore he reira te tāupe taiao, katahi ka whakawhānui i tenei ki a `None`.
    /// Tirohia te [`Option<T>`][Option] mō ētahi atu mōhiohio i runga i tenei momo.
    ///
    /// e kore te tukuna tētahi hapa wa whakahiato, ka whakamahi i tenei tonotono ahakoa o ahakoa he reira e kore ranei te tāupe taiao.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates pūwehe ki tetahi pūtāutu.
    ///
    /// Tenei tonotono e tetahi maha o pūwehe piko-wehea, me concatenates ratou katoa ki kotahi, whai he whakapuaki i te mea he pūtāutu hou.
    /// Kia mahara maamaa te wairua e kore ai e taea e tenei tonotono te hopu i nga taera o te rohe.
    /// Ano hoki, hei tikanga whanui, ko nga tonotono anake e whakaaetia ana mo te tuunga, korero me te tuunga whakaputa.
    /// E te tikanga ia koutou kia whakamahi i tēnei tonotono mō te kōrero ki ngā taurangi, mahi ranei kōwae etc, e kore koe e taea e te tautuhi i te tetahi hou ki reira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // concat_idents FI! (hou, ngahau, ingoa) { } kore//pai i roto i tenei ara!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates pūrite ki te wāhanga rerekore string.
    ///
    /// Ko tenei tonotono he maha nga rita kua wehe-piko, ka whakaputa i te momo `&'static str` e tohu ana i te katoa o nga tuhinga o te taha maui-ki-matau.
    ///
    ///
    /// E stringified pūnaha me wāhi tere pūrite i roto i te tikanga ki te kia whakaemi.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ka toro atu ki te raina raina i karangahia ai.
    ///
    /// Ki te [`column!`] ko [`file!`], whakarato enei tonotono mōhiohio patuiro mō ngā e pā ana ki te wāhi i roto i te pūtake.
    ///
    /// Ko te whakahuatanga kua whakarahihia he momo `u32` a he mea 1-na te mea ko te raina tuatahi o ia konae ka aromatawaihia ki te 1, te tuarua ki te 2, etc.
    /// Ko te rite ki te hapa karere e compilers noa ētita rongonui ranei tenei.
    /// Ko te raina hoki *kihai tika* te raina o te Warua `line!` iho, engari te Warua tonotono tuatahi ārahi ake ki te kau sangató, o te tonotono `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Whakaroha ki te tau tīwae i ai i whakahuatia ai.
    ///
    /// Ki te [`line!`] ko [`file!`], whakarato enei tonotono mōhiohio patuiro mō ngā e pā ana ki te wāhi i roto i te pūtake.
    ///
    /// He te faaiteraa whänui momo `u32` me he 1-e hāngai ana, na te tīwae tuatahi i roto i ia ka arotakengia raina ki te 1, te tuarua ki te 2, me ētahi atu
    /// Ko te rite ki te hapa karere e compilers noa ētita rongonui ranei tenei.
    /// Ko te tīwae hoki he *kore e tika* te raina o te Warua `column!` iho, engari te Warua tonotono tuatahi ārahi ake ki te kau sangató, o te tonotono `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Whakaroha ki te ingoa kōnae i roto i nei i whakahuatia ai.
    ///
    /// Ki te [`line!`] ko [`column!`], whakarato enei tonotono mōhiohio patuiro mō ngā e pā ana ki te wāhi i roto i te pūtake.
    ///
    /// He te faaiteraa whakawhānui pato `&'static str`, a kahore he te kōnae hoki te kau sangató, o te tonotono `file!` iho, engari te Warua tonotono tuatahi ārahi ake ki te kau sangató, o te tonotono `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Ka whakamarama i ona tautohe.
    ///
    /// Ka tukua tenei tonotono te faaiteraa o te momo `&'static str` i te mea haere te stringification o te tokens katoa ki te tonotono.
    /// E whakanohoia No here i runga i te wetereo o te fua lotú tonotono iho.
    ///
    /// Kia mōhio kia huri i te hua whänui o te tāuru tokens i te future.Kia tupato koe ki te whakawhirinaki koe i runga i te putanga.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Kei te kōnae whakawaeheretia UTF-8 rite te aho.
    ///
    /// Kei te kōnae te whanaunga ki te kōnae o nāianei (rite ki te āhua o e kitea kōwae).
    /// tikanga te ara whakaratohia te i roto i i te wa whakahiato te ara pūhara-motuhake.
    /// Na, hei tauira, ko te tono ki te ara Windows kei roto i nga kohinga `\` kaore e tika te whakahiato i te Unix.
    ///
    ///
    /// Ka tukua tenei tonotono te faaiteraa o te momo `&'static str` i ko te tirotiro o te kōnae.
    ///
    /// # Examples
    ///
    /// Whakaarohia e rua nga konae kei te raarangiarangi kotahi me nga korero e whai ake nei:
    ///
    /// 'spanish.in' Kōnae:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' Kōnae:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Ko te whakahiato 'main.rs' me te whakahaere i te hua takirua ka taarua te "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Kei te kōnae rite te tohutoro ki te ngohi paita.
    ///
    /// Kei te kōnae te whanaunga ki te kōnae o nāianei (rite ki te āhua o e kitea kōwae).
    /// tikanga te ara whakaratohia te i roto i i te wa whakahiato te ara pūhara-motuhake.
    /// Na, hei tauira, ko te tono ki te ara Windows kei roto i nga kohinga `\` kaore e tika te whakahiato i te Unix.
    ///
    ///
    /// Ka tukua tenei tonotono te faaiteraa o te momo `&'static [u8; N]` i ko te tirotiro o te kōnae.
    ///
    /// # Examples
    ///
    /// Whakaarohia e rua nga konae kei te raarangiarangi kotahi me nga korero e whai ake nei:
    ///
    /// 'spanish.in' Kōnae:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' Kōnae:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Ko te whakahiato 'main.rs' me te whakahaere i te hua takirua ka taarua te "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Whakaroha ki te string e tohu ana i te ara kōwae nāianei.
    ///
    /// Ka taea te whakaaro te ara kōwae nāianei o rite te raupapatanga o ngā kōwae ārahi hoki ki runga ki te crate root.
    /// Ko te ingoa o te crate tēnei wā te haaputuhia te wāhanga tuatahi o te ara hoki.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Te arotake i nga huinga boolean o nga haki whirihoranga i te waa whakahiato.
    ///
    /// I tua atu ki te huanga `#[cfg]`, whakaratohia tenei tonotono te ki tukua aro mātai faaiteraa boolean o haki whirihoranga.
    /// Tenei pinepine ahu ki waehere iti tāriterite.
    ///
    /// Ko te wetereo homai ki tenei tonotono ko te wetereo taua rite te huanga [`cfg`].
    ///
    /// `cfg!`, e pera `#[cfg]`, e kore e tango i tetahi waehere me te aro mātai anake ki pono teka ranei.
    /// Hei tauira, ki te poraka katoa i roto i te faaiteraa hiahia if/else kia whaimana ina te whakamahia `cfg!` mo te huru, noa'tu o te mea kei te aro mātai i `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Ka tohaina tetahi konae hei whakaatu i te taonga ranei kia rite ki te horopaki.
    ///
    /// Ko te konae e hono ana ki te konae o tenei wa (peera ki te ahua o nga tohu e kitea ana).tikanga te ara whakaratohia te i roto i i te wa whakahiato te ara pūhara-motuhake.
    /// Na, hei tauira, ko te tono ki te ara Windows kei roto i nga kohinga `\` kaore e tika te whakahiato i te Unix.
    ///
    /// Ko te whakamahi i tenei tonotono he whakaaro kino tonu, na te mea mena ka whakararuahia te konae hei korero, ka waiho ma te waehere a tawhio noa e kore e tau.
    /// taea hua tenei i roto i taurangi ranei mahi he rerekē i te mea te kōnae tūmanakohia ki reira he taurangi ranei mahi e whai te taua ingoa i roto i te kōnae onāianei.
    ///
    ///
    /// # Examples
    ///
    /// Whakaarohia e rua nga konae kei te raarangiarangi kotahi me nga korero e whai ake nei:
    ///
    /// 'monkeys.in' Kōnae:
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 'main.rs' Kōnae:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Ko te whakahiato 'main.rs' me te whakahaere i te hua takirua ka taarua te "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Kanui to e te faaiteraa boolean ko `true` i wāhaere.
    ///
    /// Tenei ka mahara ra te tonotono [`panic!`] ki te kore e taea te aro mātai i te faaiteraa e whakaratohia ana ki a `true` i wāhaere.
    ///
    /// # Uses
    ///
    /// E takina tāpaetanga tonu i roto i rua patuiro me tuku hanga, a kore e taea te mono.
    /// Hi'o [`debug_assert!`] hoki tāpaetanga e kore e i whakahohea i tuku hanga i te taunoa.
    ///
    /// kia whakawhirinaki waehere haumaru i runga i `assert!` ki te uruhi i invariants rere-wa e, ki te takahi i taea arahi ki unsafety.
    ///
    /// Ētahi atu whakamahinga-take o `assert!` ngā whakamatautau, me te uruhi invariants oma-wā i roto i te waehere haumaru (nei ofatiraa kore e taea hua i roto i te unsafety).
    ///
    ///
    /// # Karere Ritenga
    ///
    /// He puka tuarua to tenei tonotono, ka taea te tuku i tetahi korero panic ritenga me te kore tohetohe ranei mo te whakatakotoranga.
    /// Tirohia te [`std::fmt`] mo te wetereo mo tenei puka.
    /// Ka anake e arotakea kīanga whakamahia rite tohenga hōputu te mea kore te whakapae.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // te karere panic mo enei kīanga ko te uara stringified o te faaiteraa i homai.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // he mahi tino ngawari
    ///
    /// assert!(some_computation());
    ///
    /// // whakapuaki ki te karere ritenga
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Huihuinga rarangi.
    ///
    /// Pānuitia te [unstable book] mo te whakamahi i.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-kāhua rōrārangi whakaminenga.
    ///
    /// Pānuitia te [unstable book] mo te whakamahi i.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// taumata-kōwae rōrārangi whakaminenga.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// haere Tānga tokens ki te putanga paerewa.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Whakahohea, monokia whakataki taumahinga whakamahia mō te patuiro atu tonotono ranei.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// I whakamahia te huanga tonotono hei whakamahi i nga tonotono.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Kua whakamahia te tonotono tonotono ki tetahi mahi hei huri i te waahanga whakamatautau.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// tono Huanga tonotono ki te mahi ki te tahuri i te reira ki te whakamātautau tu'unga.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// He taipitopito whakatinanatanga o nga tonotono `#[test]` me `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Kua tonohia te tonotono tonotono ki te taatai hei rehitatanga hei kaitoha mo te ao.
    ///
    /// Tirohia hoki [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Pukepuke te tūemi ngā tono ai ki te mea he wātea te ara haere, a ka tango i reira te kore.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Whakaroha huanga `#[cfg]` katoa a `#[cfg_attr]` i roto i te kongakonga waehere ngā tono reira ki.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Taipitopito whakatinana pumau o te `rustc` whakahiato, kaua e whakamahia.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Taipitopito whakatinana pumau o te `rustc` whakahiato, kaua e whakamahia.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}