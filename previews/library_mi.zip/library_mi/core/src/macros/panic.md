Panics te miro o nāianei.

Tenei taea te hōtaka ki te whakamutu i tonu, ka whakarato urupare ki te kaiwaea o te hōtaka.
`panic!` me whakamahi ina tae ana te hotaka ki te ahua kore e taea te whakaora.

Ko tenei tonotono te huarahi pai ki te whakaatu tikanga i roto i te tauira tauira me nga whakamatautau.
`panic!` Kei te tata e here ana ki te tikanga `unwrap` o e rua enums [`Option`][ounwrap] me [`Result`][runwrap].
karanga implementations rua `panic!` ina e whakatakotoria ratou ki [`None`] [`Err`] ranei rerekē.

A, no te whakamahi `panic!()` taea e koe te whakapūtā te ututaumaha string, hanga e te whakamahi i te wetereo [`format!`].
Ko whakamahia e ututaumaha ka injecting te panic ki te miro Rust karanga, meinga te miro ki panic katoa.

Ko te whanonga o te taunoa `std` hook, arā
ko te waehere e rere tika ana i muri i te tangohanga o te panic, ko te taarua i te utunga o te karere ki te `stderr` me nga korero file/line/column o te waea `panic!()`.

Ka taea e koe te whakakore i te panic hook ma te whakamahi i te [`std::panic::set_hook()`].
Roto te hook taea te uru he panic rite te `&dyn Any + Send`, e kei rānei te `&str` `String` ranei mo karakia `panic!()` auau.
Ki panic ki te uara o tetahi atu momo atu, e taea te whakamahi [`panic_any`].

[`Result`] Ko te enum he otinga pai ake mo te whakaora mai i nga hapa kaore i te whakamahi i te tonotono `panic!`.
kia whakamahia tēnei tonotono ki te karo i puta te whakamahi i ngā uara hē, pērā i mai i waho atu.
kitea ngā mōhiohio Taipitopito e pā ana ki hapa whāwhā e i roto i te [book].

A hi'o hoki te tonotono [`compile_error!`], hoki te whakatairanga i hapa i roto i te kohinga.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Te whakatinanatanga o tenei wa

Mena ko te miro matua panics ka whakamutua o aho katoa ka mutu to papatono ki te waehere `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





