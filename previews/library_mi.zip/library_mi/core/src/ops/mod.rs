//! Kaiwhakarite taumaha.
//!
//! Ko te whakamahi i enei traits ka taea e koe te whakakaha i etahi kaiwhakahaere.
//!
//! Ko etahi o enei traits e kawemai ana e te prelude, na e waatea ana i roto i nga kaupapa Rust.Ko nga kaiwhakahaere anake e tautokohia ana e traits ka taea te taumaha.
//! Hei tauira, ko te kaiwhakahaere taapiri (`+`) ka taea te taumaha ma te [`Add`] trait, engari na te mea ko te kaiwhakawhiwhi (`=`) kaore he kaitautoko trait, kaore he huarahi hei whakanui i ana korero.
//! Hei taapiri, kaore tenei waahanga e whakarato i tetahi tikanga hei hanga i nga kaiwhakahaere hou.
//! Mena he nui rawa atu te whakahaere i nga kaiwhakahaere ritenga ranei e hiahiatia ana, me titiro koe ki nga tonotono, ki nga mono whakahiato ranei hei whakawhānui ake i te wetiweti a Rust.
//!
//! Ko nga mahi a te kaiwhakahaere traits kaua e miharo i roto i o raatau ake horopaki, kia maumahara ki o raatau tikanga me te [operator precedence].
//! Hei tauira, i te wa e whakatinana ana i te [`Mul`], me rite te mahi ki te whakareatanga (me te tohatoha i nga taonga e tika ana kia rite ki te whakahoahoa).
//!
//! Kia mahara ko te `&&` me te `||` kaiwhakahaere poto-ara, ara, ka arotakehia e ratau a raatau operan tuarua mena ka whai hua ki te mutunga.Na te mea kaore e taea e traits tenei mahi, kaore i te tautokohia a `&&` me `||` hei kaiwhakahaere kawenga.
//!
//! Ko te nuinga o nga kaiwhakahaere ka haangai i a raatau mahi.I roto i nga horopaki-kore-noa e pa ana ki nga momo hanga-i roto, kaore tenei i te raru.
//! Heoi, ma te whakamahi i enei kaiwhakangungu i roto i te waehere whanui, me aata aro ki te whakamahi ano i nga uara hei whakahe i nga kaiwhakawhanake i a raatau.Ko tetahi waahanga ko te whakamahi i te [`clone`] i etahi waa.
//! Ko tetahi atu whiringa ko te whakawhirinaki ki nga momo e pa ana ki te whakarato taapiri kaiwhakahaere mo nga tohutoro.
//! Hei tauira, mo te momo-tautuhia e te kaiwhakamahi `T` e kiia ana hei tautoko i te taapiri, he pai pea kia tukuna e `T` me `&T` te traits [`Add<T>`][`Add`] me te [`Add<&T>`][`Add`] kia taea ai te tuhi i te waehere whanui me te korone kore.
//!
//!
//! # Examples
//!
//! Ma tenei tauira e hanga he hanganga `Point` e whakamahi ana i te [`Add`] me te [`Sub`], ana ka whakaatu i te taapiri me te tango i nga `Tohu` rua.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Tirohia nga tuhinga mo ia trait hei tauira whakatinana.
//!
//! Te [`Fn`], [`FnMut`], a [`FnOnce`] traits e whakatinana e momo e taea, e maharatia a rite mahi.Kia mahara ko te [`Fn`] he `&self`, ko te [`FnMut`] ko te `&mut self` ko te [`FnOnce`] ko te `self`.
//! Ko enei e pa ana ki nga momo tikanga e toru ka taea te tono i runga i tetahi tauira: waea-a-tohutoro, karanga-ma-whakarereke-tohutoro, me te-waea-uara.
//! Ko te whakamahinga noa o enei traits ko te mahi hei rohe ki nga mahi teitei ake e kii ana i nga mahi kati ranei hei tautohe.
//!
//! Ko te tango i te [`Fn`] hei waahanga:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Ko te tango i te [`FnMut`] hei waahanga:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Ko te tango i te [`FnOnce`] hei waahanga:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ka pau i ona taurangi kua mau, na reira kaore e taea te whakahaere i te wa kotahi
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Ko te ngana ki te karanga `func()` ano ka whiua he hapa `use of moved value` mo `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` kaore e taea te piira i tenei wa
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;