/// Ko te putanga o te kaiwhakahaere waea ka tango i tetahi kaiwhiwhi kaore e taea te huri.
///
/// Ko nga waahi o `Fn` ka taea te karanga i nga waa katoa kaore i te rereke te ahua.
///
/// *Ko tenei trait (`Fn`) kaua e raruraru ki te [function pointers] (`fn`).*
///
/// `Fn` ka whakatinanahia e nga kati ka tango noa i nga tohu kore e taea te huri ki nga taurangi hopu, kaore hoki e mau ki tetahi mea, me te (safe) [function pointers] (me etahi korero, tirohia a raatau tuhinga mo etahi atu korero).
///
/// I tua atu, hoki tetahi momo `F` e ngā `Fn`, `&F` ngā `Fn`, rawa.
///
/// Mai i te mea ko te [`FnMut`] me te [`FnOnce`] he supertraits o `Fn`, ka taea te whakamahi i tetahi waahanga o te `Fn` hei waahanga e hiahiatia ana he [`FnMut`] ko [`FnOnce`] ranei.
///
/// Whakamahia te `Fn` hei herea ina hiahia koe ki te whakaae i tetahi taapiri o te momo-rite momo mahi me karanga kia taatai tonu me te kore e rereke te ahua (hei tauira, i te wa e kii ana i te waa).
/// Mena kaore e hiahiatia ana e koe nga whakaritenga pera, whakamahia te [`FnMut`], te [`FnOnce`] ranei hei rohe.
///
/// Tirohia te [chapter on closures in *The Rust Programming Language*][book] mo etahi atu korero mo tenei kaupapa.
///
/// Hei tohu ano ko te kohinga motuhake mo `Fn` traits (hei tauira
/// `Fn(usize, bool) -> whakamahi``.Ko te hunga e hiahia ana ki nga korero hangarau o tenei ka tohu ki te [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Te karanga i te katinga
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Ma te whakamahi i te tawhai `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kia taea ai e te regex te whakawhirinaki ki taua `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Ka mahi i te mahi karanga.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Ko te putanga o te kaiwhakahaere waea ka tango i te kaiwhiwhi huri.
///
/// Ko nga waahi o te `FnMut` ka taea te karanga i nga wa katoa ka huri ke i te ahua.
///
/// `FnMut` ka whakatinanahia aunoatia e nga katinga ka mau ki nga tohu rereke ki nga taurangi kua mau, me nga momo katoa e whakamahi ana i te [`Fn`], hei tauira, (safe) [function pointers] (mai i te `FnMut` he supertrait o [`Fn`]).
/// Hei taapiri, mo nga momo `F` e whakamahi ana i te `FnMut`, `&mut F` e whakamahi ana i te `FnMut`, ano hoki.
///
/// I te mea ko te [`FnOnce`] he supertrait o `FnMut`, ka taea te whakamahi i tetahi waahanga o te `FnMut` i te wa e hiahiatia ana te [`FnOnce`], a, na te mea ko te [`Fn`] he haangai mo `FnMut`, ka taea te whakamahi i tetahi tauira o te [`Fn`] i te wa e tatari ana a `FnMut`.
///
/// Whakamahia te `FnMut` hei herea ina hiahia koe ki te whakaae i tetahi taapiri o te momo mahi-rite me te piiraa i nga wa katoa, i te wa e tuku ana kia whakarereke te ahua.
/// Mena kaore koe e hiahia kia hurihuri te taapiri, whakamahia te [`Fn`] hei herea;ki te kore koe e hiahia ki te karanga pinepine, whakamahia [`FnOnce`].
///
/// Tirohia te [chapter on closures in *The Rust Programming Language*][book] mo etahi atu korero mo tenei kaupapa.
///
/// Hei tohu ano ko te kohinga motuhake mo `Fn` traits (hei tauira
/// `Fn(usize, bool) -> whakamahi``.Ko te hunga e hiahia ana ki nga korero hangarau o tenei ka tohu ki te [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Te karanga i tetahi katinga tino hopu
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Ma te whakamahi i te tawhai `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kia taea ai e te regex te whakawhirinaki ki taua `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Ka mahi i te mahi karanga.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Ko te putanga o te kaiwhakahaere waea ka tango i te kaiwhiwhi uara-uara.
///
/// Ko nga waahi o `FnOnce` ka taea te karanga, engari kaore pea e taea te karanga i nga waa maha.Na tenei, mena ko te mea noa e mohiotia ana mo tetahi momo ko te whakamahi i te `FnOnce`, kotahi noa te wa ka taea te karanga.
///
/// `FnOnce` Kei te whakatinana aunoa i closures e pau ai taurangi riro, me te momo katoa e whakatinana [`FnMut`], hei tauira, (safe) [function pointers] (mai `FnOnce` ko te supertrait o [`FnMut`]).
///
///
/// I te mea ko nga [`Fn`] me te [`FnMut`] nga waahanga o te `FnOnce`, ka taea te whakamahi i nga waahanga [`Fn`] me [`FnMut`] ranei e hiahiatia ana te `FnOnce`.
///
/// Whakamahia `FnOnce` rite te rohe, ina e hiahia ana koe ki te whakaae ki te tawhā o te mahi-rite momo me te hiahia anake ki te karanga i reira kotahi.
/// Mena me karanga tonu e koe te waahanga, whakamahia te [`FnMut`] hei herea;Mena ka hiahia koe kia kaua e whakarereke i te ahua, whakamahia te [`Fn`].
///
/// Tirohia te [chapter on closures in *The Rust Programming Language*][book] mo etahi atu korero mo tenei kaupapa.
///
/// Hei tohu ano ko te kohinga motuhake mo `Fn` traits (hei tauira
/// `Fn(usize, bool) -> whakamahi``.Ko te hunga e hiahia ana ki nga korero hangarau o tenei ka tohu ki te [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ma te whakamahi i te tawhai `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` pau ona taurangi riro, kia kore e taea te rere reira nui atu i te kotahi.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Ko te ngana ki te karanga `func()` ano ka whiua he hapa `use of moved value` mo `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` kaore e taea te piira i tenei wa
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kia taea ai e te regex te whakawhirinaki ki taua `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Ko te momo i whakahokia mai i muri i te whakamahinga o te kaiwhakahaere waea.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Ka mahi i te mahi karanga.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}