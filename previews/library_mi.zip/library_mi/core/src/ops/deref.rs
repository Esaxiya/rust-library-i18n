/// Whakamahia mo nga mahi whakakorenga koretake, penei i te `*v`.
///
/// I tua atu i te whakamahinga mo nga mahi whakapae marama me te kaiwhakahaere (unary) `*` i roto i nga horopaki kaore e taea te whakarereke, ka whakamahia paahitia te `Deref` e te kaiwhakaputa i roto i nga ahuatanga maha.
/// Ko te tikanga tenei ka kiia ko te ['`Deref` coercion'][more].
/// I nga horopaki ka taea te whakarereke, ka whakamahia te [`DerefMut`].
///
/// Ko te whakamahi i te `Deref` mo nga tohu tohu mohio he pai ki te uru atu ki nga raraunga i muri i a raatau, na reira ka whakatinana i te `Deref`.
/// I tetahi atu, ko nga ture mo te `Deref` me te [`DerefMut`] i hoahoahia kia uru ki nga tohu mohio.
/// Na tenei,**Me whakatinana noa te "Deref` mo nga tohu mohio** ki te kore e rangirua.
///
/// Mo nga take pena,**ko tenei trait kaua e ngoikore**.Ko te ngoikoretanga i te wa o te whakakore i te ture ka tino raruraru ka tukuna paahitia te `Deref`.
///
/// # He maha atu ano mo te taikaha `Deref`
///
/// Mena ka whakamahia e `T` te `Deref<Target = U>`, a ko te `x` te uara o te momo `T`, na:
///
/// * I roto i nga horopaki kaore e taea te whakarereke, `*x` (kei hea te `T` kaore he tohutoro, kaore hoki he tohu tohu noa) he rite ki te `* Deref::deref(&x)`.
/// * Ko nga uara o te momo `&T` ka akiakihia ki nga uara o te momo `&U`
/// * `T` ka tino whakatinana i nga tikanga (immutable) katoa o te momo `U`.
///
/// Mo etahi atu korero, tirohia te [the chapter in *The Rust Programming Language*][book] me nga waahanga tohutoro kei [the dereference operator][ref-deref-op], [method resolution] me [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// He hanganga me te waahi kotahi e waatea ana ma te whakakore i nga waahanga.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Ko te momo ka puta i muri i te whakakorenga.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Whakakorea te uara.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Whakamahia mo nga mahi whakakorenga rereke, penei i te `*v = 1;`.
///
/// I tua atu i te whakamahinga mo nga mahi whakapae marama me te kaiwhakahaere (unary) `*` i roto i nga horopaki ka taea te whakamahi, `DerefMut` ka whakamahia paahitia e te kaiwhakaputa i roto i nga ahuatanga maha.
/// Ko te tikanga tenei ka kiia ko te ['`Deref` coercion'][more].
/// I nga horopaki kaore e taea te whakarereke, ka whakamahia te [`Deref`].
///
/// Ko te whakamahi i te `DerefMut` mo nga tohu mohio he pai ki te whakarereke i nga raraunga o muri, na reira ka whakatinana i te `DerefMut`.
/// I tetahi atu, ko nga ture mo te [`Deref`] me te `DerefMut` i hoahoahia kia uru ki nga tohu mohio.
/// Na tenei,**Me whakatinana noa te** DerefMut` mo nga tohu mohio ** kia kore e rangirua.
///
/// Mo nga take pena,**ko tenei trait kaua e ngoikore**.Ko te ngoikoretanga i te wa o te whakakore i te ture ka tino raruraru ka tukuna paahitia te `DerefMut`.
///
/// # He maha atu ano mo te taikaha `Deref`
///
/// Mena ka whakamahia e `T` te `DerefMut<Target = U>`, a ko te `x` te uara o te momo `T`, na:
///
/// * I nga horopaki ka taea te whakarereke, ko te `*x` (ko te `T` ehara i te tohutoro, kaore he tohu tohu noa) he rite ki te `* DerefMut::deref_mut(&mut x)`.
/// * Ko nga uara o te momo `&mut T` ka akiakihia ki nga uara o te momo `&mut U`
/// * `T` ka tino whakatinana i nga tikanga (mutable) katoa o te momo `U`.
///
/// Mo etahi atu korero, tirohia te [the chapter in *The Rust Programming Language*][book] me nga waahanga tohutoro kei [the dereference operator][ref-deref-op], [method resolution] me [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// He hanganga me te waahi kotahi ka taea te whakarereke ma te whakakore i te hanganga.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Ka taea te whakakore i te uara.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// E tohu ana ka taea te whakamahi i tetahi hanganga hei kaiwhiwhi tikanga, me te kore te ahua `arbitrary_self_types`.
///
/// Ka whakatinanahia e nga momo tohu tohu stdlib penei i te `Box<T>`, `Rc<T>`, `&T`, me `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}