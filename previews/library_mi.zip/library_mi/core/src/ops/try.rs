/// He trait mo te whakarereke i te whanonga o te kaiwhakahaere `?`.
///
/// Ko te momo e whakamahi ana i te `Try` tetahi e ahei ana ki te tirotiro i a ia e pa ana ki te success/failure dichotomy.
/// Ma tenei trait e ahei te tango i aua uara angitu, uara huakore ranei mai i tetahi waa o mua me te hanga tauira hou mai i te uara angitu, i te uara ranei.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Te momo o tenei uara ina tirohia ka angitu.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Ko te momo o tenei uara ina tirohia kua kore.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Ka tono ki te kaiwhakahaere "?".Ko te whakahoki mai i te `Ok(t)` ko te tikanga me haere tonu te mahi, a ko te mutunga o te `?` ko te uara `t`.
    /// Ko te whakahoki mai o `Err(e)` ko te tikanga me branch te hoatutanga ki te roto rawa i te `catch`, me hoki mai ranei i te mahi.
    ///
    /// Mena kua whakahokia mai he hua `Err(e)`, ko te uara `e` hei "wrapped" i roto i te momo whakahoki mai o te whanui kapi (me tino whakatinana i te `Try`).
    ///
    /// Ina koa, ko te uara `X::from_error(From::from(e))` ka whakahokia mai, kei reira ko te `X` te momo whakahoki o te mahi kapi.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Takai he uara hapa hei hanga i te hua hiato.
    /// Hei tauira, `Result::Err(x)` me `Result::from_error(x)` he orite.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Takai he uara OK ki te hanga i te hua hiato.
    /// Hei tauira, `Result::Ok(x)` me `Result::from_ok(x)` he orite.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}