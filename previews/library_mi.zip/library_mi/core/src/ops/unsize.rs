use crate::marker::Unsize;

/// Trait e tohu ana he tohu tenei he takai ranei mo tetahi, ka taea te whakakino i te kaitohu.
///
/// Tirohia te [DST coercion RFC][dst-coerce] me te [the nomicon entry on coercion][nomicon-coerce] mo etahi atu taipitopito.
///
/// Mo nga momo tohu atawhai, ka tohu nga tohu ki te `T` ki nga tohu ki te `U` mena he `T: Unsize<U>` ma te huri mai i tetahi tohu angiangi ki tetahi tohu momona.
///
/// Mo nga momo ritenga, ko te akiaki i konei ka mahi ma te akiaki i te `Foo<T>` ki te `Foo<U>` mena he `CoerceUnsized<Foo<U>> for Foo<T>` kei roto.
/// Ka taea anake te tuhi i nga korero mena he `Foo<T>` tetahi waahi kore-phantomdata kotahi e pa ana ki te `T`.
/// Mena ko te momo o tera mara ko `Bar<T>`, me whakatinana he `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Ka mahi te akiaki ma te akiaki i te āpure `Bar<T>` ki te `Bar<U>` ka whakakii i te toenga o nga mara mai i te `Foo<T>` ki te hanga `Foo<U>`.
/// Ma tenei ka kaha te toro ki raro ki te papa tohu me te toha.
///
/// Te tikanga, mo nga tohu mohio ka whakatinanahia e koe te `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, me te `?Sized` whiringa ka herea ki te `T` ano.
/// Hoki ngā momo Uwhi e tika whakaū `T` rite `Cell<T>` ko `RefCell<T>`, ka taea e koe tika whakatinana `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Ma tenei ka waiho nga mahi akiaki o nga momo penei i te `Cell<Box<T>>` mahi.
///
/// [`Unsize`][unsize] ka whakamahia hei tohu i nga momo ka taea te akiaki ki nga DST mena kei muri nga tohu.Ka whakatinanahia e te kaiwhakaputu.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Kei te whakamahia tenei mo te haumaru ahanoa, ki te tirohia e taea a kia tutuki i runga i te momo kaiwhiwhi o te tikanga.
///
/// He tauira hei whakamahi i te trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}