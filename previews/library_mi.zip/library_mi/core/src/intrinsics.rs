//! Nga kaiwhakatangitangi intrinsics.
//!
//! Ko nga whakamaaramatanga rite ana kei roto i te `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Ko nga implementations const ōrite i roto i `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Tuhinga o mua Const
//!
//! Note: kia tetahi huringa ki te constness o intrinsics kia kōrero ki te rōpū reo.
//! Kei roto i tenei ko nga whakarereketanga o te pumau o te kaupapa here.
//!
//! I roto i te tikanga ki te hanga i te pai tūturu i whakahiato-wa, ki te kotahi hiahia tārua te whakatinanatanga i <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ki `compiler/rustc_mir/src/interpret/intrinsics.rs` me te tāpiri i te `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ki te tūturu.
//!
//!
//! Mena he mea whakamahi te intrinsic mai i te `const fn` me te huanga `rustc_const_stable`, me `rustc_const_stable` te huanga o te tangata tuuturu.
//! Ko tenei panoni kaua e mahia mena kaore he korerorero a T-lang, na te mea ka tunu i tetahi ahuatanga ki te reo kaore e taea te whakakii i te waehere kaiwhakamahi kaore he tautoko a te kaiwhakaputu.
//!
//! # Volatiles
//!
//! Ko te intrinsics ahua whakarato tikanga ngā mahi ki te mahi i runga i te mahara I/O, e kua whai ki te kore e pūketehia rānei e te taupatupatu puta noa atu intrinsics te ahua.Tirohia te te tuhinga LLVM i runga i [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Ko te intrinsics ngota whakarato ngā mahi ngota noa i runga i nga kupu mīhini, me tikanga mahara taea maha.rongo ratou i te taua semantics rite C++ 11.Tirohia te te tuhinga LLVM i runga i [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! He whakahou tere mo te ota whakamaharatanga:
//!
//! * Whiwhi, he arai mo riro he raka.Ko nga panui me nga tuhinga ka whai ake i muri o te aukati.
//! * Te tuku, he arai mo te tuku i te raka.Ko nga panui me nga tuhinga o mua ka mahia i mua o te aukati.
//! * E whai raupapa ōrite, ngā mahi raupapa ōrite ki te tupu i roto i te raupapa.Ko te aratau paerewa mō te mahi ki te momo ngota tenei me he ōrite ki `volatile` o Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// E whakamahia ēnei kawemai mō te faaohieraa e hononga kōtuitui-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SAFETY: kite `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, tangohia enei intrinsics atatohu raw no ratou mutate mahara aliased, e kore te mea tika hoki rānei `&` `&mut` ranei e.
    //

    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `compare_exchange` ma te whakawhiti i te [`Ordering::SeqCst`] hei tohu `success` me `failure` hoki.
    ///
    /// Hei tauira, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `compare_exchange` e haere [`Ordering::Acquire`] rite te tawhā e rua `success` me `failure` te putanga ähuareka o tenei tūturu.
    ///
    /// Hei tauira, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `compare_exchange` ma te whakawhiti i te [`Ordering::Release`] hei `success` me [`Ordering::Relaxed`] hei tohu `failure`.
    /// Hei tauira, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `compare_exchange` e haere [`Ordering::AcqRel`] rite te `success` ko [`Ordering::Acquire`] rite nga tawhā `failure` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `compare_exchange` ma te whakawhiti i te [`Ordering::Relaxed`] hei tohu `success` me `failure` hoki.
    ///
    /// Hei tauira, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `compare_exchange` e haere [`Ordering::SeqCst`] rite te `success` ko [`Ordering::Relaxed`] rite nga tawhā `failure` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `compare_exchange` ma te whakawhiti i te [`Ordering::SeqCst`] hei `success` me [`Ordering::Acquire`] hei tohu `failure`.
    /// Hei tauira, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `compare_exchange` e haere [`Ordering::Acquire`] rite te `success` ko [`Ordering::Relaxed`] rite nga tawhā `failure` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `compare_exchange` e haere [`Ordering::AcqRel`] rite te `success` ko [`Ordering::Relaxed`] rite nga tawhā `failure` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `compare_exchange_weak` ma te whakawhiti i te [`Ordering::SeqCst`] hei tohu `success` me `failure` hoki.
    ///
    /// Hei tauira, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `compare_exchange_weak` ma te whakawhiti i te [`Ordering::Acquire`] hei tohu `success` me `failure` hoki.
    ///
    /// Hei tauira, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `compare_exchange_weak` e haere [`Ordering::Release`] rite te `success` ko [`Ordering::Relaxed`] rite nga tawhā `failure` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `compare_exchange_weak` e haere [`Ordering::AcqRel`] rite te `success` ko [`Ordering::Acquire`] rite nga tawhā `failure` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `compare_exchange_weak` e haere [`Ordering::Relaxed`] rite te tawhā e rua `success` me `failure` te putanga ähuareka o tenei tūturu.
    ///
    /// Hei tauira, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `compare_exchange_weak` ma te whakawhiti i te [`Ordering::SeqCst`] hei `success` me [`Ordering::Relaxed`] hei tohu `failure`.
    /// Hei tauira, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `compare_exchange_weak` e haere [`Ordering::SeqCst`] rite te `success` ko [`Ordering::Acquire`] rite nga tawhā `failure` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `compare_exchange_weak` e haere [`Ordering::Acquire`] rite te `success` ko [`Ordering::Relaxed`] rite nga tawhā `failure` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pupuru ana i te uara ki te ko te taua rite te uara `old` te uara o nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `compare_exchange_weak` e haere [`Ordering::AcqRel`] rite te `success` ko [`Ordering::Relaxed`] rite nga tawhā `failure` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Utaina te uara o te atatohu nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `load` e haere [`Ordering::SeqCst`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Utaina te uara o te atatohu nāianei.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `load` e haere [`Ordering::Acquire`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Utaina te uara o te atatohu nāianei.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `load` ma te tuku [`Ordering::Relaxed`] hei `order`.
    /// Hei tauira, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Ka penapenahia te uara ki te waahi maumahara i whakahuatia.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `store` e haere [`Ordering::SeqCst`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Ka penapenahia te uara ki te waahi maumahara i whakahuatia.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `store` e haere [`Ordering::Release`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Ka penapenahia te uara ki te waahi maumahara i whakahuatia.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `store` e haere [`Ordering::Relaxed`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Ka penapenahia te uara ki te waahi maumahara kua tohua, ka whakahoki i te uara tawhito.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `swap` e haere [`Ordering::SeqCst`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka penapenahia te uara ki te waahi maumahara kua tohua, ka whakahoki i te uara tawhito.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `swap` e haere [`Ordering::Acquire`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka penapenahia te uara ki te waahi maumahara kua tohua, ka whakahoki i te uara tawhito.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `swap` ma te paahihia i te [`Ordering::Release`] hei `order`.
    /// Hei tauira, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka penapenahia te uara ki te waahi maumahara kua tohua, ka whakahoki i te uara tawhito.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `swap` ma te paahihia i te [`Ordering::AcqRel`] hei `order`.
    /// Hei tauira, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka penapenahia te uara ki te waahi maumahara kua tohua, ka whakahoki i te uara tawhito.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `swap` e haere [`Ordering::Relaxed`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ka taapirihia ki te uara o naianei, ka whakahoki i te uara o mua.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `fetch_add` ma te paahihia i te [`Ordering::SeqCst`] hei `order`.
    /// Hei tauira, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka taapirihia ki te uara o naianei, ka whakahoki i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_add` e haere [`Ordering::Acquire`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka taapirihia ki te uara o naianei, ka whakahoki i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_add` e haere [`Ordering::Release`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka taapirihia ki te uara o naianei, ka whakahoki i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_add` e haere [`Ordering::AcqRel`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka taapirihia ki te uara o naianei, ka whakahoki i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_add` e haere [`Ordering::Relaxed`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Tangohia mai i te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `fetch_sub` ma te paahihia i te [`Ordering::SeqCst`] hei `order`.
    /// Hei tauira, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tangohia mai i te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `fetch_sub` ma te paahihia i te [`Ordering::Acquire`] hei `order`.
    /// Hei tauira, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tangohia mai i te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_sub` e haere [`Ordering::Release`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tangohia mai i te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `fetch_sub` ma te paahihia i te [`Ordering::AcqRel`] hei `order`.
    /// Hei tauira, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tangohia mai i te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `fetch_sub` ma te paahihia i te [`Ordering::Relaxed`] hei `order`.
    /// Hei tauira, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise me ki te uara o nāianei, e hoki ana i te uara o mua.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `fetch_and` ma te paahihia i te [`Ordering::SeqCst`] hei `order`.
    /// Hei tauira, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise me ki te uara o nāianei, e hoki ana i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_and` e haere [`Ordering::Acquire`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise me ki te uara o nāianei, e hoki ana i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_and` e haere [`Ordering::Release`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise me ki te uara o nāianei, e hoki ana i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_and` e haere [`Ordering::AcqRel`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise me ki te uara o nāianei, e hoki ana i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_and` e haere [`Ordering::Relaxed`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand me te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i te momo [`AtomicBool`] ma te tikanga `fetch_nand` ma te tuku [`Ordering::SeqCst`] hei `order`.
    /// Hei tauira, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand me te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i te momo [`AtomicBool`] ma te tikanga `fetch_nand` ma te tuku [`Ordering::Acquire`] hei `order`.
    /// Hei tauira, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand me te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i te momo [`AtomicBool`] ma te tikanga `fetch_nand` ma te tuku [`Ordering::Release`] hei `order`.
    /// Hei tauira, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand me te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko wātea i runga i te momo [`AtomicBool`] mā te tikanga `fetch_nand` e haere [`Ordering::AcqRel`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand me te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko wātea i runga i te momo [`AtomicBool`] mā te tikanga `fetch_nand` e haere [`Ordering::Relaxed`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise ki te uara o nāianei ranei, e hoki i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_or` e haere [`Ordering::SeqCst`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ki te uara o nāianei ranei, e hoki i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_or` e haere [`Ordering::Acquire`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ki te uara o nāianei ranei, e hoki i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_or` e haere [`Ordering::Release`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ki te uara o nāianei ranei, e hoki i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_or` e haere [`Ordering::AcqRel`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ki te uara o nāianei ranei, e hoki i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_or` e haere [`Ordering::Relaxed`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor me te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `fetch_xor` ma te tuku [`Ordering::SeqCst`] hei `order`.
    /// Hei tauira, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor me te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `fetch_xor` ma te paahihia i te [`Ordering::Acquire`] hei `order`.
    /// Hei tauira, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor me te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_xor` e haere [`Ordering::Release`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor me te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i nga momo [`atomic`] ma te tikanga `fetch_xor` ma te paahihia i te [`Ordering::AcqRel`] hei `order`.
    /// Hei tauira, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor me te uara o naianei, me te whakahoki mai i te uara o mua.
    ///
    /// Ko e wātea ana i runga i te momo [`atomic`] mā te tikanga `fetch_xor` e haere [`Ordering::Relaxed`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mōrahi ki te uara o nāianei mā te whakamahi i te whakarite hainatia.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i te [`atomic`] momo taero kua hainatia ma te tikanga `fetch_max` ma te tuku [`Ordering::SeqCst`] hei `order`.
    /// Hei tauira, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mōrahi ki te uara o nāianei mā te whakamahi i te whakarite hainatia.
    ///
    /// He wātea te putanga ähuareka o tenei tūturu i runga i haina te [`atomic`] tau tōpū momo mā te tikanga `fetch_max` e haere [`Ordering::Acquire`] rite te `order`.
    /// Hei tauira, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mōrahi ki te uara o nāianei mā te whakamahi i te whakarite hainatia.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i te [`atomic`] momo taero kua hainatia ma te tikanga `fetch_max` ma te tuku [`Ordering::Release`] hei `order`.
    /// Hei tauira, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mōrahi ki te uara o nāianei mā te whakamahi i te whakarite hainatia.
    ///
    /// He wātea te putanga ähuareka o tenei tūturu i runga i haina te [`atomic`] tau tōpū momo mā te tikanga `fetch_max` e haere [`Ordering::AcqRel`] rite te `order`.
    /// Hei tauira, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mōrahi ki te uara o nāianei.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i te [`atomic`] momo taero kua hainatia ma te tikanga `fetch_max` ma te tuku [`Ordering::Relaxed`] hei `order`.
    /// Hei tauira, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Iti me te uara o naianei ma te whakamahi i te whakataurite kua hainatia.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i runga i te [`atomic`] momo integer kua hainatia ma te tikanga `fetch_min` ma te tuku [`Ordering::SeqCst`] hei `order`.
    /// Hei tauira, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iti me te uara o naianei ma te whakamahi i te whakataurite kua hainatia.
    ///
    /// He wātea te putanga ähuareka o tenei tūturu i runga i haina te [`atomic`] tau tōpū momo mā te tikanga `fetch_min` e haere [`Ordering::Acquire`] rite te `order`.
    /// Hei tauira, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iti me te uara o naianei ma te whakamahi i te whakataurite kua hainatia.
    ///
    /// He wātea te putanga ähuareka o tenei tūturu i runga i haina te [`atomic`] tau tōpū momo mā te tikanga `fetch_min` e haere [`Ordering::Release`] rite te `order`.
    /// Hei tauira, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iti me te uara o naianei ma te whakamahi i te whakataurite kua hainatia.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i te [`atomic`] momo taero kua hainatia ma te tikanga `fetch_min` ma te tuku [`Ordering::AcqRel`] hei `order`.
    /// Hei tauira, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iti me te uara o naianei ma te whakamahi i te whakataurite kua hainatia.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i te [`atomic`] momo taero kua hainatia ma te tikanga `fetch_min` ma te tuku [`Ordering::Relaxed`] hei `order`.
    /// Hei tauira, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mōkito ki te uara o nāianei mā te whakamahi i te whakarite waitohu.
    ///
    /// Ko e wātea ana i runga i te momo tōpū waitohu [`atomic`] mā te tikanga `fetch_min` e haere [`Ordering::SeqCst`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mōkito ki te uara o nāianei mā te whakamahi i te whakarite waitohu.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i runga i nga momo taarua kore tohu kore [`atomic`] ma te tikanga `fetch_min` ma te tuku [`Ordering::Acquire`] hei `order`.
    /// Hei tauira, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mōkito ki te uara o nāianei mā te whakamahi i te whakarite waitohu.
    ///
    /// Ko e wātea ana i runga i te momo tōpū waitohu [`atomic`] mā te tikanga `fetch_min` e haere [`Ordering::Release`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mōkito ki te uara o nāianei mā te whakamahi i te whakarite waitohu.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i runga i nga momo taarua kore tohu kore [`atomic`] ma te tikanga `fetch_min` ma te tuku [`Ordering::AcqRel`] hei `order`.
    /// Hei tauira, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mōkito ki te uara o nāianei mā te whakamahi i te whakarite waitohu.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i runga i nga momo taarua kore tohu kore [`atomic`] ma te tikanga `fetch_min` ma te tuku [`Ordering::Relaxed`] hei `order`.
    /// Hei tauira, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Te rahinga me te uara o naianei ma te whakamahi i te whakataurite kore waitohu.
    ///
    /// Ko e wātea ana i runga i te momo tōpū waitohu [`atomic`] mā te tikanga `fetch_max` e haere [`Ordering::SeqCst`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Te rahinga me te uara o naianei ma te whakamahi i te whakataurite kore waitohu.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i runga i nga momo taarua kore tohu kore [`atomic`] ma te tikanga `fetch_max` ma te tuku [`Ordering::Acquire`] hei `order`.
    /// Hei tauira, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Te rahinga me te uara o naianei ma te whakamahi i te whakataurite kore waitohu.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i runga i nga momo taarua kore tohu kore [`atomic`] ma te tikanga `fetch_max` ma te tuku [`Ordering::Release`] hei `order`.
    /// Hei tauira, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Te rahinga me te uara o naianei ma te whakamahi i te whakataurite kore waitohu.
    ///
    /// Ko e wātea ana i runga i te momo tōpū waitohu [`atomic`] mā te tikanga `fetch_max` e haere [`Ordering::AcqRel`] rite te `order` te putanga ähuareka o tenei tūturu.
    /// Hei tauira, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Te rahinga me te uara o naianei ma te whakamahi i te whakataurite kore waitohu.
    ///
    /// Ko te putanga pumau o tenei intrinsic e waatea ana i runga i nga momo taarua kore tohu kore [`atomic`] ma te tikanga `fetch_max` ma te tuku [`Ordering::Relaxed`] hei `order`.
    /// Hei tauira, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ko te `prefetch` intrinsic he tohu ki te kaihanga waehere ki te whakauru i nga tohutohu kapi ki te tautokohia;te kore, he mea he kore-op.
    /// Prefetches kahore pānga i runga i te whanonga o te hōtaka, engari ka taea e te huri ona āhuatanga mahi.
    ///
    /// Me kia te tautohe `locality` te tau tōpū tamau me te ko te tautohu pae tino wāhi mai i (0), kahore wāhi, ki (3), tino huna rohe i roto i te keteroki.
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Ko te `prefetch` intrinsic he tohu ki te kaihanga waehere ki te whakauru i nga tohutohu kapi ki te tautokohia;te kore, he mea he kore-op.
    /// Prefetches kahore pānga i runga i te whanonga o te hōtaka, engari ka taea e te huri ona āhuatanga mahi.
    ///
    /// Me kia te tautohe `locality` te tau tōpū tamau me te ko te tautohu pae tino wāhi mai i (0), kahore wāhi, ki (3), tino huna rohe i roto i te keteroki.
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Ko te `prefetch` intrinsic he tohu ki te kaihanga waehere ki te whakauru i nga tohutohu kapi ki te tautokohia;te kore, he mea he kore-op.
    /// Prefetches kahore pānga i runga i te whanonga o te hōtaka, engari ka taea e te huri ona āhuatanga mahi.
    ///
    /// Me kia te tautohe `locality` te tau tōpū tamau me te ko te tautohu pae tino wāhi mai i (0), kahore wāhi, ki (3), tino huna rohe i roto i te keteroki.
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Ko te `prefetch` intrinsic he tohu ki te kaihanga waehere ki te whakauru i nga tohutohu kapi ki te tautokohia;te kore, he mea he kore-op.
    /// Prefetches kahore pānga i runga i te whanonga o te hōtaka, engari ka taea e te huri ona āhuatanga mahi.
    ///
    /// Me kia te tautohe `locality` te tau tōpū tamau me te ko te tautohu pae tino wāhi mai i (0), kahore wāhi, ki (3), tino huna rohe i roto i te keteroki.
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// He taiapa ngota.
    ///
    /// He wātea te putanga ähuareka o tenei tūturu i roto i [`atomic::fence`] e haere [`Ordering::SeqCst`] rite te `order`.
    ///
    ///
    pub fn atomic_fence();
    /// He taiapa ngota.
    ///
    /// He wātea te putanga ähuareka o tenei tūturu i roto i [`atomic::fence`] e haere [`Ordering::Acquire`] rite te `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// He taiapa ngota.
    ///
    /// He wātea te putanga ähuareka o tenei tūturu i roto i [`atomic::fence`] e haere [`Ordering::Release`] rite te `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// He taiapa ngota.
    ///
    /// He wātea te putanga ähuareka o tenei tūturu i roto i [`atomic::fence`] e haere [`Ordering::AcqRel`] rite te `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// He aukati whakamahara-anake.
    ///
    /// Ko nga uru maumahara kaore e raupaparutia kia tae atu ki tenei aukati e te kaiwhakaara, engari kaore he tohutohu hei whakaputa atu.
    /// He tika tenei mo nga mahi i runga i te miro kotahi e taea ana te peera, penei i te wa e taunekeneke ana ki nga kaitiaki tohu.
    ///
    /// He wātea te putanga ähuareka o tenei tūturu i roto i [`atomic::compiler_fence`] e haere [`Ordering::SeqCst`] rite te `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// He aukati whakamahara-anake.
    ///
    /// Ko nga uru maumahara kaore e raupaparutia kia tae atu ki tenei aukati e te kaiwhakaara, engari kaore he tohutohu hei whakaputa atu.
    /// He tika tenei mo nga mahi i runga i te miro kotahi e taea ana te peera, penei i te wa e taunekeneke ana ki nga kaitiaki tohu.
    ///
    /// He wātea te putanga ähuareka o tenei tūturu i roto i [`atomic::compiler_fence`] e haere [`Ordering::Acquire`] rite te `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// He aukati whakamahara-anake.
    ///
    /// Ko nga uru maumahara kaore e raupaparutia kia tae atu ki tenei aukati e te kaiwhakaara, engari kaore he tohutohu hei whakaputa atu.
    /// He tika tenei mo nga mahi i runga i te miro kotahi e taea ana te peera, penei i te wa e taunekeneke ana ki nga kaitiaki tohu.
    ///
    /// Ko te putanga whakapumautia o tenei intrinsic e waatea ana i te [`atomic::compiler_fence`] ma te paahitanga i te [`Ordering::Release`] hei `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// He aukati whakamahara-anake.
    ///
    /// Ko nga uru maumahara kaore e raupaparutia kia tae atu ki tenei aukati e te kaiwhakaara, engari kaore he tohutohu hei whakaputa atu.
    /// He tika tenei mo nga mahi i runga i te miro kotahi e taea ana te peera, penei i te wa e taunekeneke ana ki nga kaitiaki tohu.
    ///
    /// He wātea te putanga ähuareka o tenei tūturu i roto i [`atomic::compiler_fence`] e haere [`Ordering::AcqRel`] rite te `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// tūturu Magic e ahu tona tikanga i ngā huanga piri ki te mahi.
    ///
    /// Hei tauira, ki dataflow whakamahinga tenei wero kīanga pateko kia `rustc_peek(potentially_uninitialized)` e mau Taki-rua e i pono whakatatau dataflow e te Korearawhiti reira i taua wāhi i roto i te rere mana.
    ///
    ///
    /// e kore e tenei tūturu hei waho whakamahia o te taupatupatu.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborts te mahia o te tukanga.
    ///
    /// He atu me eu-hoa kaiwhakamahi putanga o tenei mahi ko [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Ngā te mōhinuhinu e kore he reachable tenei wāhi i roto i te waehere, taea atu optimizations.
    ///
    /// NB, he rereke tenei i te tonotono `unreachable!()`: Kaore i rite ki te tonotono, e panics i te wa e mahia ana, he *whanonga kore kua tautuhia* kia tae atu ki te waehere kua tohua ki tenei mahi.
    ///
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Ka whakamohio ki te kaitautoko ko te tikanga he pono i nga wa katoa.
    /// Mena he he te ahua, kaore i te tautuhia te whanonga.
    ///
    /// Kaore he waehere i hangaia mo tenei korero o roto, engari ka ngana te kaitoha ki te pupuri (me tona ahuatanga) i waenga i nga paahitanga, tera pea ka raru te aromautanga o te waehere huri noa ka whakaiti i te mahinga.
    /// Kaua e whakamahia mena ka kitea te kaitautoko e te kaitoha ki a ia ano, ki te kore ranei e taea te whakanui ake.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// He tohu ki te kaitautu e ahua pono ana te ahua branch.
    /// Whakahokia ai te uara i tukuna ki a ia.
    ///
    /// Tetahi whakamahi atu atu i ki tauākī `if` kore pea e whai he pānga.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Tīwhiri ki te taupatupatu i he pea ki te kia teka branch huru.
    /// Whakahokia ai te uara i tukuna ki a ia.
    ///
    /// Tetahi whakamahi atu atu i ki tauākī `if` kore pea e whai he pānga.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Ka puta ia i te mahanga kokotinga, no te tirohanga i te kaipatuiro.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn breakpoint();

    /// Te rahi o te momo i roto i te paita.
    ///
    /// Ko te mea nui ake, koinei te urupare o nga paita i waenga i nga taonga whai muri o te momo kotahi, tae atu ki nga taatai whakaurunga.
    ///
    ///
    /// Ko te putanga pumau o tenei intrinsic ko te [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Ko te whakaurunga iti o te momo.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Ko te tīaroaro pai o te momo.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Te rahi o te uara tohutoro i roto i te paita.
    ///
    /// Ko te putanga pumau o tenei intrinsic ko te [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Ko te whakahoutanga e hiahiatia ana mo te uara tohutoro.
    ///
    /// Ko te putanga pumau o tenei intrinsic ko te [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Whiwhi te wāhanga string pateko kei roto i te ingoa o te momo.
    ///
    /// Ko te putanga pumau o tenei intrinsic ko te [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Ka tiki te pūtāutu i te mea ao ahurei ki te momo whakaritea.
    /// Ka hoki tenei mahi te uara taua mo te momo ahakoa o ēnei crate reira karangatia te i.
    ///
    ///
    /// Ko te putanga pumau o tenei intrinsic ko te [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// He kaitiaki mo nga mahi haumaru kaore e taea te whakahaere mena kaore i te noho te `T`:
    /// Ka tuturu tenei ma panic, kaore ranei e mahi.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// He kaitiaki mō ngā mahi haumaru e kore e taea tonu te mahi i te mea e kore e `T` tukua kore-arawhiti: tenei e statically rānei panic, ranei te mahi i tetahi mea.
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn assert_zero_valid<T>();

    /// He kaitiaki mō ngā mahi haumaru e kore e taea tonu te mahi i te mea he tauira moka muhu `T`: tenei e statically rānei panic, ranei te mahi i tetahi mea.
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn assert_uninit_valid<T>();

    /// Whiwhi te tohutoro ki te rerekore `Location` tohu te wahi i huaina ai.
    ///
    /// Whakaarohia te whakamahi i te [`core::panic::Location::caller`](crate::panic::Location::caller) hei utu.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Ka nuku te uara i o whānuitanga kahore rere te maturuturunga iho kāpia.
    ///
    /// Mo [`mem::forget_unsized`] noa tenei;Ka whakamahia e noa `forget` `ManuallyDrop` hei utu.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterprets nga paraire o te uara o tetahi momo rite tetahi momo.
    ///
    /// Me whai i te rahi taua momo rua.
    /// E kore te taketake, kaua te hua, kia waiho hei [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` Ko semantically ōrite ki te nekehanga bitwise o momo tetahi ki tetahi.Te reira i kape nga paraire i te uara pūtake ki te uara ūnga, ka wareware te taketake.
    /// He rite ki te C's `memcpy` i raro i te taupoki, rite tonu ki te `transmute_copy`.
    ///
    /// No te mea `transmute` Ko te mahi i-uara, hāngaitanga o te uara *transmuted ratou kahore* ko te āwangawanga.
    /// Ka rite ki etahi atu mahi, kua mohio ke te kaiwhakaputa he tika te whakariterite i te `T` me te `U`.
    /// Heoi, ka transmuting uara e wāhi *wāhi kē*(pērā i kuru, tohutoro, pouaka ...), kua ki te whakarite tīaroaro tika o nga uara oka-ki te kaiwaea.
    ///
    /// `transmute` he **mīharo** haumaru.He he maha nui o ngā huarahi ki te meinga [undefined behavior][ub] ki tenei mahi.Ko te `transmute` te tikanga whakamutunga.
    ///
    /// Te [nomicon](../../nomicon/transmutes.html) he tuhinga atu.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// He he mea torutoru e he tino whai hua mō te `transmute`.
    ///
    /// Te huri i tetahi tohu ki tetahi tohu tohu mahi.Ko *kore* kawe ki ngā mīhini i reira atatohu mahi me atatohu raraunga i rerekē te rahi tenei.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Te whakawhnui i te roanga o te ra, te whakapoto ranei i te roanga o te wa.whakanekehanga tenei te, te tino haumaru Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Kaua e wehi: he tokomaha whakamahinga o `transmute` taea te tutuki i roto i te tahi atu rave'a.
    /// Kei raro he tono noa o `transmute` e taea te whakakapi ki ngā hanganga haumaru.
    ///
    /// Tahuri bytes(`&[u8]`) raw ki `u32`, `f64`, etc .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // whakamahia `u32::from_ne_bytes` hei utu
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // whakamahia `u32::from_le_bytes` ranei `u32::from_be_bytes` ranei ki te whakarite i te mutunga
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Hurihia te tohu ki te `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Whakamahia te `as` kaiwhakaari hei whakakapi
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Hurihia te `*mut T` hei `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Whakamahia te nama ano
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Hurihia te `&mut T` hei `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Na, hoatu tahi `as` me reborrowing, mōhio e kore he transitive te herea ana o `as` `as`
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Tahuri te `&str` ki te `&[u8]`:
    ///
    /// ```
    /// // e kore te mea he ara pai ki te mahi i tenei i tenei.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ka taea e koe te whakamahi i te `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ranei, te whakamahi i tika i te aho paita, ki te whai koe i te mana i runga i te mau string
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Hurihia te `Vec<&T>` ki te `Vec<Option<&T>>`.
    ///
    /// Hei ai ā te momo roto o nga tirotiro o te ipu, me hanga e koe mohio ki te kore i tetahi o invariants o te ipu.
    /// Hoki `Vec`, ki tenei tikanga e rua i te rahi *me tīaroaro* o nga momo roto i ōrite.
    /// Ko etahi o nga ipu ka whakawhirinaki pea ki te rahi o te momo, te whakahoutanga, tae atu ki te `TypeId`, na reira kaore e taea te whakawhitiwhiti me te kore e takahi i nga kaipupuri ipu.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // tohu i te vector ka whakamahia ano e maatau a muri ake
    /// let v_clone = v_orig.clone();
    ///
    /// // Mā te ai ā: whakawhirinaki tenei i runga i te tahora raraunga kāore i o `Vec`, i te mea he whakaaro kino, a taea meinga koretautuhi Whanonga.
    /////
    /// // Heoi, he mea kahore-tārua.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Koinei te huarahi whakaaro, haumaru.
    /// // e tārua reira katoa te vector, ahakoa, ki te ngohi hou.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Koinei te kape-kore tika, ara haumaru o "transmuting" a `Vec`, me te kore e whirinaki ki te whakatakotoranga raraunga.
    /// // Engari o mo'oni karanga `transmute`, te mahi tatou i te maka atatohu, engari i roto i ngā o te faafariuraa i te momo i roto taketake (`&i32`) ki te kotahi hou (`Option<&i32>`), kua tenei te taua reehita katoa.
    /////
    /// // Haunga ngā runga ake te mōhiohio, kōrero hoki te tuhinga [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Whakahoutia tenei ka whakaū ana te vector_into_raw_parts.
    ///     // Me whakarite i te taketake e kore e maturuturu iho vector.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Te whakamahi i te `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // He huarahi maha ki te mahi i tenei, a reira e raruraru maha ki te ara (transmute) e whai ake nei.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // tuatahi: e kore te ai ā te pato haumaru;ko nga mea katoa e tirohia ana ko te T me te
    ///         // He orite te rahi o U.
    ///         // Tuarua, e tika i konei, i koe e rua tohutoro mutable tuhu ki te mahara taua.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // whakakahoretia tenei tangata o nga raruraru momo haumaru;`&mut *` ka* hoatu noa *i a koe he `&mut T` mai i te `&mut T`, i te `* mut T` ranei.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // Heoi, E tonu koe e rua tohutoro mutable tuhu ki te mahara taua.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ko tenei e founga te whare pukapuka paerewa e te reira.
    /// // Ko te tikanga pai tenei, ki te hiahia koe ki te mahi i te tahi mea rite tenei
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Tenei E toru tohutoro mutable tuhu i te mahara ano inaianei.`slice`, te Whakatauranga ret.0, me te Whakatauranga ret.1.
    ///         // `slice` e kore te whakamahia i muri `let ptr = ...`, a kia taea e tetahi te hamani i te reira rite "dead", a reira, koutou anake i rua poro mutable tūturu.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Ahakoa tenei hanga te eu const tūturu, whai tatou etahi waehere ritenga i roto i te FN const
    // nga arowhai e aukati ana i tana whakamahinga i roto i te `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Whakahoki `true` mena ko te momo tuuturu i whakawhiwhia ki te `T` me whakapiri te whakapiri;hoki `false` ki te momo tūturu whakaratohia hoki `T` whakatinana `Copy`.
    ///
    ///
    /// Ki te kore titau te momo tūturu maturuturunga kāpia ranei ngā `Copy`, na ko kāore i te uara hoki o tenei mahi.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Ka taatau i te whakawhirinaki mai i te tohu tohu.
    ///
    /// whakatinana ana tēnei te rite te tūturu ki te karo i tahuri ki a i te tau tōpū, mai e maka atu i te faafariuraa aliasing mōhiohio.
    ///
    /// # Safety
    ///
    /// Rua kia rānei te atatohu tīmata me te hua i roto i rohe kotahi paita mua te mutunga o te ahanoa tohaina ranei.
    /// Mena kaore i te tuaina te tohu ranei, ka kaha mai ranei te kaha o te tatauranga ka riro ma te kore e tautuhia te whakamahi i te uara i whakahokia.
    ///
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Tātaitia ana te wāhikē i te atatohu, pea tākainga.
    ///
    /// Ka whakatinanahia hei intrinsic ki te karo i te huri ki te tau mai i te tau, mai i te hurihanga e aukati ana i etahi papaanga.
    ///
    /// # Safety
    ///
    /// Rerekē te tūturu `offset`, e kore e tenei tūturu te rāhui i te atatohu hua ki te wāhi ki tetahi paita mua te mutunga o te ahanoa tohaina ranei, a takaia ana e ia ki te tauhanga ngä o rua.
    /// Ko te uara ka puta ehara i te mea tika hei whakamahi kia uru mai ai te mahara.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// He orite ki te kiko o te `llvm.memcpy.p0i8.0i8.*` e tika ana, me te rahi o te `count`*`size_of::<T>()` me te haangai o
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ko te waahanga ohorere kua whakatauhia ki te `true`, na reira kaore e pai ake te kore e rite te rahi ki te kore.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ōrite ki te tika `llvm.memmove.p0i8.0i8.*` tūturu, ki te rahi o `count* size_of::<T>()` me te tīaroaro o
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ko te waahanga ohorere kua whakatauhia ki te `true`, na reira kaore e pai ake te kore e rite te rahi ki te kore.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// He rite ki te kiko o te `llvm.memset.p0i8.*` e tika ana, me te rahi o te `count* size_of::<T>()` me te tuurite o te `min_align_of::<T>()`.
    ///
    ///
    /// Ko te waahanga ohorere kua whakatauhia ki te `true`, na reira kaore e pai ake te kore e rite te rahi ki te kore.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Ka mahi i tetahi kawenga taumaha mai i te atatohu `src`.
    ///
    /// Ko te putanga pumau o tenei intrinsic ko te [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Mahi he toa ahua ki te atatohu `dst`.
    ///
    /// Ko te putanga pumau o tenei intrinsic ko te [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Rave i te kawenga ahua i te atatohu `src` kore te te atatohu hiahiatia ki te kia hāngai.
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Mahi he toa ahua ki te atatohu `dst`.
    /// E kore te te atatohu hiahiatia ki te kia hāngai.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Whakahokia ai te pakiaka tapawha o te `f32`
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Whakahokia te pakiaka tapawha o te `f64`
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Ka whakaara i te `f32` ki te hiko tauoti.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Whakaara ake he `f64` ki te mana tōpū.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Whakahokia te aho o te `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Whakahokia te aho o te `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Whakahokia te whenu o te `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Whakahokia te whenu o te `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Whakaara ake he `f32` ki te mana `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Whakaarahia te `f64` ki te kaha `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Whakahokia te taupūtanga o te `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Whakahoki ai i te taupatupatu o te `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Returns 2 whakaarahia ki te mana o te `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Returns 2 whakaarahia ki te mana o te `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Whakahokia te taupū kōaro tūturu o te `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Whakahoki ai i te logarithm taiao o te `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Whakahokia te turanga 10 taupū kōaro o te `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Whakahokia te turanga 10 taupū kōaro o te `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Whakahoki ai i te turanga 2 logarithm o te `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Whakahoki ai i te turanga 2 logarithm o te `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Whakahokia `a * b + c` mō uara `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Whakahoki ai i te `a * b + c` mo nga uara `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Whakahokia te uara pū o te `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Whakahoki ai i te uara tino o te `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Whakahokia te iti rawa o e rua ngā uara `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Whakahokia te iti rawa o e rua ngā uara `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Whakahoki ai i te rahinga o nga uara `f32` e rua.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Whakahoki ai i te rahinga o nga uara `f64` e rua.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Tārua te tohu i `y` ki `x` mō ngā uara `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Tārua te tohu i `y` ki `x` mō ngā uara `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Whakahoki ai i te tauanga nui rawa atu iti iho i te orite ki te `f32` ranei.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Hoki te tōpū nui iti iho i te ranei rite ki te `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Whakahokia te tōpū nui iti atu rite ranei ki te `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Whakahoki ai i te taupū iti rawa nui atu i te rite ranei ki te `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Whakahoki ai i te waahanga integer o te `f32`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Whakahoki ai i te waahanga integer o te `f64`.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Whakahokia ai te tau tōpū tata ki te `f32`.
    /// Akene ka whakaarahia tetahi okotahi-tere rere ke mena kaore te tautohe he tauwehe.
    pub fn rintf32(x: f32) -> f32;
    /// Whakahoki ai i te tau tōpū tata ki te `f64`.
    /// Akene ka whakaarahia tetahi okotahi-tere rere ke mena kaore te tautohe he tauwehe.
    pub fn rintf64(x: f64) -> f64;

    /// Whakahokia ai te tau tōpū tata ki te `f32`.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Whakahoki ai i te tau tōpū tata ki te `f64`.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Whakahoki ai i te tau tōpū tata ki te `f32`.Ko nga keehi haurua haurua te tawhiti atu i te kore.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Whakahokia ai te tau tōpū tata ki te `f64`.Ko nga keehi haurua haurua te tawhiti atu i te kore.
    ///
    /// Ko te putanga ähuareka o tenei tūturu ko
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Rewa tua e taea optimizations e hāngai ana i runga i ngā ture taurangi.
    /// Akuanei ka uru mai nga whakauru he mutunga.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Te tangohanga ngaru e ahei ai te whakaniko i runga i nga tikanga taurangi.
    /// Akuanei ka uru mai nga whakauru he mutunga.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Rewa whakareatanga e taea optimizations e hāngai ana i runga i ngā ture taurangi.
    /// Akuanei ka uru mai nga whakauru he mutunga.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Rewa wehenga e taea optimizations e hāngai ana i runga i ngā ture taurangi.
    /// Akuanei ka uru mai nga whakauru he mutunga.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Te toenga rewa ka taea ai te whakaniko i runga i nga tikanga taurangi.
    /// Akuanei ka uru mai nga whakauru he mutunga.
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Faafariu ki fptoui/fptosi a LLVM, e ai hoki undef hoki uara i o awhe
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Whakapumautia hei [`f32::to_int_unchecked`] me [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Hoki te maha o nga paraire whakaturia i roto i te momo tōpū `T`
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `count_ones` nga putanga ähuareka o tenei tūturu.
    /// Hei tauira,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Whakahoki ai i te maha o nga waahanga kaitautuhia (zeroes) i roto i te momo integer `T`.
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `leading_zeros` nga putanga ähuareka o tenei tūturu.
    /// Hei tauira,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// He `x` ki uara `0` ka hoki te whanui moka o `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Ka rite ki `ctlz`, engari anō-haumaru rite hoki reira `undef` ka homai he `x` ki uara `0`.
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Whakahokia te maha o autō paraire tango tautuhi (zeroes) i roto i te momo tōpū `T`.
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `trailing_zeros` nga putanga ähuareka o tenei tūturu.
    /// Hei tauira,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Ko te `x` me te uara `0` ka whakahoki i te whanui o te `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Ka rite ki `cttz`, engari anō-haumaru rite hoki reira `undef` ka homai he `x` ki uara `0`.
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Huri whakamuri te paita i roto i te momo tōpū `T`.
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `swap_bytes` nga putanga ähuareka o tenei tūturu.
    /// Hei tauira,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Huri whakamuri te paraire i roto i te momo tōpū `T`.
    ///
    /// Ko nga putanga pumau o tenei intrinsic e waatea ana i runga i te tuatahi integer ma te tikanga `reverse_bits`.
    /// Hei tauira,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// takina rave tōpū tua.
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `overflowing_add` nga putanga ähuareka o tenei tūturu.
    /// Hei tauira,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Mahi ai i te tangohanga tauoti
    ///
    /// Ko nga putanga pumau o tenei intrinsic e waatea ana i te integer primitives ma te tikanga `overflowing_sub`.
    /// Hei tauira,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Mahi ai i te whakareatanga tauotioti
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `overflowing_mul` nga putanga ähuareka o tenei tūturu.
    /// Hei tauira,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Mahi he wehenga tangohia, hua i roto i te whanonga kāore i reira `x % y != 0` `y == 0` `x == T::MIN && y == -1` ranei ranei
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Mahi he wehenga kore taki, hua i roto i te whanonga kāore `x == T::MIN && y == -1` i reira `y == 0` ranei
    ///
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `checked_div` wrappers Haumaru mō tenei tūturu.
    /// Hei tauira,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Whakahokia te toenga o te wehenga kore taki, hua i roto i te whanonga kāore `x == T::MIN && y == -1` ka `y == 0` ranei
    ///
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `checked_rem` wrappers Haumaru mō tenei tūturu.
    /// Hei tauira,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Mahi he neke maui wetetakihia, hua i roto i te whanonga kāore ina `y < 0` ranei `y >= N`, kei hea N ko te whanui o T i paraire.
    ///
    ///
    /// Ko nga taakaro haumaru mo tenei intrinsic e waatea ana i runga i te tuatahi o te integer ma te tikanga `checked_shl`.
    /// Hei tauira,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Mahi he neke matau wetetakihia, hua i roto i te whanonga kāore ina `y < 0` ranei `y >= N`, kei hea N ko te whanui o T i paraire.
    ///
    ///
    /// Ko nga taakaro haumaru mo tenei intrinsic e waatea ana i runga i te tuatahi o te integer ma te tikanga `checked_shr`.
    /// Hei tauira,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Whakahokia te hua o te tua kore taki, hua i roto i te whanonga kāore `x + y < T::MIN` ka `x + y > T::MAX` ranei.
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Whakahoki ai i te otinga o te tangohanga kaore i tirohia, ka hua he whanonga kore ka `x - y > T::MAX` ko `x - y < T::MIN` ranei.
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Whakahokia te hua o te whakareatanga kore taki, hua i roto i te whanonga kāore `x *y < T::MIN` ka `x* y > T::MAX` ranei.
    ///
    ///
    /// Kaore he ritenga pumau o tenei intrinsic.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Ka takahuri i te taha maui.
    ///
    /// Ko nga putanga pumau o tenei intrinsic e waatea ana i te integer primitives ma te tikanga `rotate_left`.
    /// Hei tauira,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// tika tītaka mahi.
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `rotate_right` nga putanga ähuareka o tenei tūturu.
    /// Hei tauira,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Whakahoki (a + b) mod 2 <sup>N</sup>, kei hea te whanui o te T i nga paraire.
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `wrapping_add` nga putanga ähuareka o tenei tūturu.
    /// Hei tauira,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Hoki (he, b) mod 2 <sup>N,</sup> kei hea N ko te whanui o T i paraire.
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `wrapping_sub` nga putanga ähuareka o tenei tūturu.
    /// Hei tauira,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Returns (he b *) mod 2 <sup>N,</sup> kei hea N ko te whanui o T i paraire.
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `wrapping_mul` nga putanga ähuareka o tenei tūturu.
    /// Hei tauira,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Computes `a + b`, saturating i rohe tau.
    ///
    /// Ko nga putanga pumau o tenei intrinsic e waatea ana i runga i te tuatahi integer ma te tikanga `saturating_add`.
    /// Hei tauira,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Ka tatau i te `a - b`, e makona ana i nga rohe tau.
    ///
    /// E wātea ana i runga i nga primitives tau tōpū mā te tikanga `saturating_sub` nga putanga ähuareka o tenei tūturu.
    /// Hei tauira,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Whakahokia te uara o te discriminant mo te kē i roto i 'v';
    /// mena kaore he manawapa a te `T`, whakahokia mai a `0`.
    ///
    /// Ko te putanga pumau o tenei intrinsic ko te [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Hoki te maha o rerekē o te momo maka `T` ki te `usize`;
    /// ki te `T` kahore rerekē, hoki `0`.Ka kiia rerekē e nohoia.
    ///
    /// Ko te putanga ki-kia-ähuareka o tenei tūturu ko [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// "try catch" hangä o Rust e tiaororaa te atatohu mahi `try_fn` ki te atatohu raraunga `data`.
    ///
    /// toru o te tautohe ko te mahi i huaina ki te puta he panic.
    /// Tenei mahi e te atatohu raraunga me te atatohu ki te ahanoa okotahi ūnga-tauwhāiti e i mau.
    ///
    /// Mō ētahi atu pārongo kite pūtake o te taupatupatu me te whakatinanatanga hao o std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// E faatae mai te toa `!nontemporal` rite ki LLVM (kite ratou tuhinga).
    /// Pea e kore e riro eu.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Tirohia te tuhinga o `<*const T>::offset_from` mō ngā taipitopito.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Tirohia te tuhinga o `<*const T>::guaranteed_eq` mō ngā taipitopito.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Tirohia nga tuhinga o `<*const T>::guaranteed_ne` mo nga korero taipitopito.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Tohatoha i te wā whakahiato.Kaua e karangahia i te wa weto.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// E tautuhi ētahi mahi i konei no te mea ratou aitua Ua hanga e wātea ana i roto i tenei kōwae i runga eu.
// Tirohia te <https://github.com/rust-lang/rust/issues/15702>.
// (Ka taka a `transmute` ki tenei waahanga, engari kaore e taea te takai na te haki he rite te rahi o te `T` me te `U`.)
//

/// Taki ai mēnā `ptr` te tika hāngai ki te whakapai kanohi ki `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Tārua ngā paita `count *size_of::<T>()` i `src` ki `dst`.Ko te pūtake me te ūnga pau kore** inaki.
///
/// Hoki rohe o te mahara i ai īnaki, te whakamahi i hei utu [`copy`].
///
/// `copy_nonoverlapping` he orite te rite ki te C's [`memcpy`], engari me te ota tohenga i hurihia.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `src` Me waiho [valid] hoki na ô o `count * size_of::<T>()` ngā paita.
///
/// * `dst` Me waiho [valid] mō tuhi e o paita `count * size_of::<T>()`.
///
/// * Ko nga `src` me te `dst` me tika te whakariterite.
///
/// * Ko te rohe o te mahara timata i `src` ki te rahi o `tatau *
///   size_of: :<T>() `Ngā paita pau kore * * inaki ki te rohe o te mahara timata i `dst` ki te rahi taua.
///
/// Ka rite ki [`read`], hanga `copy_nonoverlapping` he kape bitwise o `T`, ahakoa o ahakoa `T` ko [`Copy`].
/// Mena ko `T` ehara i te [`Copy`], ma te whakamahi i nga mea e rua *o te rohe ka tiimata mai i te `* src` me te rohe ka tiimata mai i te `*dst` ka taea te [violate memory safety][read-ownership].
///
///
/// Kia mahara ahakoa te rahi o te kape kua taarua (`tatau * rahinga_o: :<T>()`) Ko `0`, me kia te atatohu kore i korengia-a tika tiaro.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Whakahaerehia te [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Ka nekehia nga waahanga katoa o te `src` ki te `dst`, ka waiho he kore noa te `src`.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Whakarite e he nui kaha ki te mau katoa o `src` `dst`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // He haumaru tonu te karanga ki te wāhikē no te mea e kore `Vec` e tohatoha atu atu ngā paita `isize::MAX`.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Takarepa `src` kahore iho ona tirotiro.
///         // mahi tatou i tenei i te tuatahi, ki ngā raruraru faka'ehi'ehi mei roto i te take te tahi mea atu ki raro panics.
///         src.set_len(0);
///
///         // Kaore e taea e nga rohe e rua te taarua na te mea kaore nga ingoa tohutoro e rereke i te ingoakē, ka rua nga vector rereke kaore e taea te pupuri i taua mahara kotahi.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Whakamōhio `dst` e inaianei reira mau te tirotiro o `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Me mahi enei arowhai i te wa oma anake
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Kaore i te awangawanga kia iti ake te pa o te codegen.
        abort();
    }*/

    // HAUMARU: Me waiho te kirimana haumaru mō `copy_nonoverlapping`
    // i tautokohia e te kaiwaea.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Ka kape i nga paita `count * size_of::<T>()` mai i te `src` ki te `dst`.Ko te pūtake me te ūnga kia īnaki.
///
/// Ki te ka *kore inaki*, Ka taea te whakamahi hei utu te pūtake, me te ūnga [`copy_nonoverlapping`].
///
/// `copy` he orite te rite ki te C's [`memmove`], engari me te ota tohenga i hurihia.
/// Tārua e wahi, me te mea i tuhi nga paita i `src` ki te ngohi rangitahi, me te ka tuhi i te ngohi ki `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `src` Me waiho [valid] hoki na ô o `count * size_of::<T>()` ngā paita.
///
/// * `dst` Me waiho [valid] mō tuhi e o paita `count * size_of::<T>()`.
///
/// * Ko nga `src` me te `dst` me tika te whakariterite.
///
/// Ka rite ki [`read`], hanga `copy` he kape bitwise o `T`, ahakoa o ahakoa `T` ko [`Copy`].
/// Ki te kore te mea [`Copy`] `T`, te whakamahi i te uara e rua i roto i te rohe timata i `*src` me te rohe timata i `* dst` taea [violate memory safety][read-ownership].
///
///
/// Kia mahara ahakoa te rahi o te kape kua taarua (`tatau * rahinga_o: :<T>()`) Ko `0`, me kia te atatohu kore i korengia-a tika tiaro.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Mahia te hanga i tetahi Rust vector mai i te miihini kore haumaru:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` me tika te whakatika mo te momo me te kore-kore.
/// /// * `ptr` me tika mo nga paanui o te `elts` waahanga honohono o te momo `T`.
/// /// * Ko era waahanga kaore e whakamahia i muri i te karanga i tenei mahi ki te kore `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // HAUMARU: To tatou fakapapau'i ai öna hāngai te pūtake te me tika,
///     // me āta `Vec::with_capacity` e whai tatou wāhi pai ki te tuhituhi ratou.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SAFETY: I hangaia e maatau me tenei kaha i mua atu,
///     // a kua arawhitia te `copy` mua enei āhuatanga.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Me mahi enei arowhai i te wa oma anake
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Kaore i te awangawanga kia iti ake te pa o te codegen.
        abort();
    }*/

    // SAFETY: ko te kirimana ahuru mo `copy` me tautoko e te kaiwaea.
    unsafe { copy(src, dst, count) }
}

/// Ka tautuhia te `count * size_of::<T>()` paita mahara ma te tiimata mai i te `dst` ki te `val`.
///
/// `write_bytes` He rite ki [`memset`] o C, engari whakatakoto ana ngā paita `count * size_of::<T>()` ki `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `dst` Me waiho [valid] mō tuhi e o paita `count * size_of::<T>()`.
///
/// * `dst` Me tika kia hāngai.
///
/// I tua atu, me whakarite i te kaiwaea e tuhituhi `count * size_of::<T>()` ngā paita ki te rohe homai o hua mahara i roto i te uara tika o `T`.
/// Mā te whakamahi i te rohe o te mahara pato rite te `T` e kei he uara muhu o `T` he whanonga kāore.
///
/// Note e ara, ki te te rahi tōtika tārua (`tatau size_of *: :<T>()`) he `0`, me tohu te tohu-kore-kore, kia tika te whakariterite.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Te hanga i tetahi uara muhu:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Te turuturu te uara tū i mua na roto i te taupoki i te `Box<T>` ki te atatohu whakakahore.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // I tenei wa, ma te whakamahi i te whakaheke ranei i te `v` ka whai hua kore.
/// // drop(v); // ERROR
///
/// // Ahakoa turuturu `v` "uses" reira, a konei he whanonga kāore.
/// // mem::forget(v); // ERROR
///
/// // Inaa hoki, he hē te `v` e ai ki nga momo kaitono whakatakotoranga whakatakotoranga, no reira *tetahi mahi* e pa ana ki a ia he whanonga kore.
/////
/// // kia v2 =v;//HAPA
///
/// unsafe {
///     // Kia hei utu hoatu tatou i roto i te uara tika
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Na te pouaka, ko te pai
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // HAUMARU: Me e tautokona ake te kirimana haumaru mō `write_bytes` i te kaiwaea.
    unsafe { write_bytes(dst, val, count) }
}