//! Panic tautoko i te wharepukapuka paerewa.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// He hanganga e whakarato ana i nga korero mo te panic.
///
/// `PanicInfo` kua tukuna te hanganga ki te panic hook kua whakaritea e te mahi [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Whakahoki ai i nga utunga e hono ana ki te panic.
    ///
    /// Ka nui noa atu, engari kaore i te wa katoa, he `&'static str`, ko te [`String`] ranei.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Mena i whakamahia te tonotono `panic!` mai i te `core` crate (ehara i te `std`) me te aho whakahōpututanga me etahi tohenga taapiri, ka whakahoki i taua karere kia rite hei [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Whakahoki ai i nga korero mo te waahi i ahu mai ai te panic, mena kei te waatea.
    ///
    /// I tenei wa ka hoki mai ano te [`Some`] i nga wa katoa, engari ka rereke pea nga putanga future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Mena ka hurihia tenei ka hoki mai i etahi waa Kaore,
        // mahi ki taua keehi i te std::panicking::default_hook me te std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: kaore e taea e taatau te whakamahi downcast_ref: :<String>() konei
        // mai i te mea kaore i te waatea te aho!
        // Ko te utunga he Utu ka karangahia a `std::panic!` me nga tohenga maha, engari mena ka waatea ano te korero.
        //

        self.location.fmt(formatter)
    }
}

/// He hanganga kei roto nga korero mo te waahi o te panic.
///
/// Na [`PanicInfo::location()`] tenei hanganga i hanga.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Ko nga whakataurite mo te taurite me te ota ota e mahia ana ki te konae, raina, ka tohua ko te pou.
/// Ka whakatauhia nga konae hei aho, kaua ko te `Path`, ka kore pea e puta ke.
/// Tirohia nga tuhinga a [`Tauwāhi: konae`] mo te korerorero ano.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Whakahoki ai i te waahi putake o te kaiwaea o tenei mahi.
    /// Mena he tauanga te kaiwaea o tera mahi ka whakahokia mai tana waahi karanga, ana ka piki ake ki te piinga tuatahi ki roto i te tinana mahi-kore e aroturukihia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Whakahokia ai te [`Location`] e karangahia ana.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Whakahokia ai he [`Location`] mai i roto i te whakamaaramatanga o tenei mahi.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // rere te mahi taua kore aroturuki i roto i te wāhi rerekē homai tatou te hua taua
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ko te whakahaere i te mahi aroturukihia i tetahi atu waahi ka rereke te uara
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Whakahoki ai i te ingoa o te konae putake i ahu mai ai te panic.
    ///
    /// # `&str`, kaore `&Path`
    ///
    /// Ko te ingoa i whakahokia mai nei e pa ana ki tetahi huarahi ara kei runga i te punaha whakahiato, engari kaore i te tika te whakaatu tika hei `&Path` tenei.
    /// rere ai te waehere haaputuhia i runga i te pūnaha rerekē ki te whakatinanatanga `Path` rerekē atu te pūnaha whakarato i te tirotiro, me te kore e whai i tēnei wā i tēnei whare pukapuka he momo "host path" rerekē.
    ///
    /// Ko te whanonga tino miharo i te wa e tae atu ana te konae "the same" ma te maha o nga ara o te punaha modula (te tikanga e whakamahi ana i te huanga `#[path = "..."]` peera ranei), na tera pea ka puta ko te waehere rite ki te whakahoki mai i nga uara rereke mai i tenei mahi.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Kaore tenei uara e pai mo te whakawhiti ki te `Path::new`, ki nga kaihanga rite ranei i te rereke o te kaupapa whakahaere.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Whakahoki ai i te raina raina i ahu mai ai te panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Whakahokia ai te pou i ahu mai ai te panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// He trait o roto e whakamahia ana e libstd ki te tuku raraunga mai i te libstd ki te `panic_unwind` me etahi atu waahanga panic.
/// Kaore i te whakaarohia kia whakapumautia wawe ake, kaua e whakamahia.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Tangohia katoatia nga mana o roto.
    /// Ko te momo whakahoki ko te `Box<dyn Any + Send>`, engari kaore e taea te whakamahi i te `Box` i roto i te rekoata.
    ///
    /// Whai muri i te karangatanga o tenei tikanga, ko te toenga taunoa anake e toe ana i te `self`.
    /// Ko te karanga i tenei tikanga kia rua, ko te karanga `get` ranei i muri i te karanga i tenei tikanga, he he.
    ///
    /// Kua nama te tautohe na te mea ko te panic runtime (`__rust_start_panic`) ka riro he `dyn BoxMeUp` nama noa iho.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// tarewa Just te tirotiro.
    fn get(&mut self) -> &(dyn Any + Send);
}