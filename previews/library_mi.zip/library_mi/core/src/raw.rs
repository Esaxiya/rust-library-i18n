#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Kei roto nga whakamaaramatanga hanganga mo te whakatakotoranga o nga momo momo hanga-hanga.
//!
//! Ka taea te whakamahi hei whaainga mo nga whakawhiti i roto i te waehere kore haumaru hei whakamahi tika i nga whakaaturanga mata.
//!
//!
//! kia ōrite tonu ratou whakamāramatanga te Abi tautuhia i roto i `rustc_middle::ty::layout`.
//!

/// Ko te whakaaturanga o te taonga trait penei i te `&dyn SomeTrait`.
///
/// Tenei struct He te tahora taua rite momo rite `&dyn SomeTrait` me `Box<dyn AnotherTrait>`.
///
/// `TraitObject` he taurangi kia taurite ki nga whakatakotoranga, engari ehara ko te momo trait taonga (hei tauira, kaore e tika te toro atu o nga mara ki te `&dyn SomeTrait`) kaore hoki e whakahaerehia te whakatakotoranga (ko te whakarereke i te whakamaaramatanga kaore e rereke te whakatakotoranga o te `&dyn SomeTrait`).
///
/// Kei te anake hangaia te reira ki te kia whakamahia e te waehere haumaru e hiahia ki te rāwekeweke i te kōrero taumata-iti.
///
/// Kaore he huarahi hei toro atu ki nga taonga trait katoa i te nuinga o te waa, na ko te huarahi noa hei hanga uara o tenei momo ko nga mahi penei i te [`std::mem::transmute`][transmute].
/// Waihoki, ko te huarahi anake ki te hanga i tetahi taonga trait pono mai i te uara `TraitObject` ko te `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Ko te whakariterite i tetahi mea trait me nga momo kaore e taurite ana-tetahi kaore e tau te vety ki te momo uara e tohu ai te tohu tohu raraunga-tera pea ka puta he whanonga kore.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // he tauira trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // waiho ma te kaiwhakawhanake e hanga tetahi taonga trait
/// let object: &dyn Foo = &value;
///
/// // titiro ki te kanohi raw
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // te atatohu raraunga te wahitau o `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // hangahia he taonga hou, tohu atu ki tetahi `i32` rereke, kia tupato ki te whakamahi i te `i32` vtable mai i `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // kia rite te mahi me te mea i hangaia e maatau tetahi taonga trait mai i te `other_value` tika
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}