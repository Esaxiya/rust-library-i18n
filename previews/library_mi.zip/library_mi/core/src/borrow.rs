//! He waahanga hei mahi me nga raraunga kua nama.

#![stable(feature = "rust1", since = "1.0.0")]

/// He trait mo te nama nama.
///
/// I te Rust, he mea noa te whakarato i nga momo whakaaturanga o tetahi momo mo nga keehi whakamahi rereke.
/// Hei tauira, e taea te āta whiriwhiri wāhi rokiroki me te whakahaere mo te uara rite tika mo te whakamahi ngā mā momo atatohu pērā i [`Box<T>`] [`Rc<T>`] ranei.
/// I tua atu i enei panui whanui e taea ana te whakamahi me nga momo katoa, ko etahi momo e whakarato ana i nga waahanga kowhiri me te utu nui te mahi.
/// He tauira mō te momo te taua ko [`String`] e tāpiri te kaha ki te whakawhānui i te aho ki te taketake [`str`].
/// Ko te tikanga me waiho kia nui ake nga korero kaore e hiahiatia ana mo tetahi aho ngawari, kaore e taea te huri.
///
/// Ma enei momo e ahei te uru atu ki nga korero tuuturu ma roto i nga tohutoro ki te momo o ena tuhinga.E kiia ana ko ratou 'i namaina hei' momo penei.
/// Hei tauira, ka taea te tono i te [`Box<T>`] rite `T` i taea te tono he [`String`] rite `str`.
///
/// Momo faaite e taea te tono ratou kia rite ki etahi momo `T` i whakatinana `Borrow<T>`, whakarato i te tohutoro ki te `T` i te tikanga [`borrow`] o te trait.Kaore he momo e utu ki te nama nama he maha nga momo momo.
/// Ki te hiahia te reira ki mutably tarewa rite te momo-tuku i te raraunga whāriki ki te kia whakarerekētia, e taea ato'a whakatinana reira [`BorrowMut<T>`].
///
/// I tua atu, ka whakarato implementations mo atu traits, me te reira ki te kia whakaaro mehemea pohehe ratou ōrite ki te hunga o te momo whāriki rite te putanga o te mahi kia rite ki te kanohi o taua momo whāriki.
/// waehere Whānui tikanga whakamahi `Borrow<T>` ka whakawhirinaki ai ki runga ki te whanonga ōrite o enei atu implementations trait.
/// Ko enei traits ka puta ano he trait bounds.
///
/// I roto i ngā `Eq`, me kia ōrite mō te tono me te puritia uara `Ord` me `Hash`: kia hoatu `x.borrow() == y.borrow()` te hua taua rite `x == y`.
///
/// Ki te hiahia noa waehere kano ki te mahi mō te momo katoa e taea te whakarato i tētahi tohutoro ki te momo e hāngai ana `T`, he reira maha pai ki te whakamahi i [`AsRef<T>`] rite atu momo e taea humarie whakatinana i te reira.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Ka rite ki te kohinga raraunga, nona [`HashMap<K, V>`] e rua taviri me uara.Ki te te takai raraunga tūturu o te kī i roto i te momo whakahaere o etahi ahua, kia, Heoi, tonu te mea taea ki te rapu hoki i te uara mā te whakamahi i te tohutoro ki raraunga o te kī.
/// Hoki tauira, ki te ko te kī he string, ka te pea rongoatia reira ki te mahere hae i rite te [`String`], i kia waiho reira taea ki te rapu te whakamahi i te [`&str`][`str`].
/// Na, me whakahaere te `insert` i te `String` i te wa e hiahia ana a `get` ki te whakamahi i te `&str`.
///
/// He maama noa ake, ko nga waahanga e tika ana mo te `HashMap<K, V>` penei:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // i whakakahoretia nga mara
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Ko te mapi haehae katoa he whanui kei runga i te momo matua `K`.No te mea e penapena enei mau taviri ki te mahere hae, tenei momo kua ki ake raraunga o te kī.
/// Ka whakauru ana koe i te takirua uara-matua, ka whakawhiwhia te mapi ki taua `K` ana me rapu te peere hash tika ka tirohia mena kei kona ke te matua i runga i taua `K`.No reira me `K: Hash + Eq`.
///
/// I a koe e rapu ana i tetahi uara i te mapi, me tuku e koe he tohu ki te `K` hei ki te rapu, me hanga e koe taua uara ake.
/// No te mau taviri string, e te tikanga o tenei hiahia te uara `String` ki kia hanga tika mo te rapu mo te take i reira he wātea he `str` anake.
///
/// Engari, ko te tikanga `get` he momo noa i runga ake i te momo o nga korero matua e whaaia ana, e kiia ana ko `Q` i roto i te waitohu tikanga i runga ake nei.E kii ana ko `K` ka tono moni hei `Q` ma te tono kia `K: Borrow<Q>`.
/// Na roto ato'a tono `Q: Hash + Eq`, tohu te reira i te titauraa e whai `K` me `Q` implementations o te `Hash` me `Eq` traits e hua hua ōrite.
///
/// Ko te whakatinanatanga o te `get` e whirinaki ana ki nga whakaritenga rite o te `Hash` ma te whakatau i te peere peere o te matua ma te karanga `Hash::hash` i runga i te uara `Q` ahakoa i whakauruhia te matua ki te uara hash i taatai mai i te uara `K`.
///
///
/// Ka rite ki te putanga, te wehenga hae mahere, ki te te `K` tākai i te uara `Q` hua he hae rerekē atu `Q`.Hei tauira, whakaarohia he momo taau takai takai engari ka whakataurite i nga reta ASCII kaore e aro ki o raatau keehi:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Na te mea e rua nga uara rite ki te whakaputa i taua uara hash, ko te whakatinanatanga o te `Hash` me wareware i te keehi ASCII hoki:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Ka taea e `CaseInsensitiveString` te whakamahi i te `Borrow<str>`?Ka taea tonu te whakarato i tetahi tohutoro ki te poro taura ma roto i ona aho e mau ana.
/// Engari na te mea he rereke tana whakamahinga `Hash`, he rere ke tana whakahaere mai i te `str` na reira me tino kore, me whakamahi `Borrow<str>`.
/// Mena kei te hiahia ia kia uru etahi atu ki te `str` e whaaia ana, ka taea e ia ma `AsRef<str>` kaore nei e ea he whakaritenga taapiri.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Kaore e taea te tango i nga moni mai i te uara mana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// He trait mo nga raraunga e taea ana te tono tarewa.
///
/// Hei hoa mo [`Borrow<T>`] ma tenei trait e tuku tetahi momo nama ki te nama hei momo momo ma te whakarato i tetahi tohutoro ka taea te whakarereke.
/// Tirohia te [`Borrow<T>`] mo nga korero taapiri mo te nama nama ano tetahi atu momo.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Ka taea te tango moni mai i te uara mana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}