#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// Ko te putanga o [Unicode](http://www.unicode.org/) kei runga nga waahanga Unicode o nga tikanga `char` me te `str`.
///
/// Ko nga putanga hou o Unicode ka tukuna i nga waa katoa ka mutu ka whakahouhia nga tikanga katoa i te wharepukapuka paerewa, kei i te Unicode anake.
/// Na reira te whanonga o etahi tikanga `char` ko `str` me te uara o tenei taimau taui i runga i te wā.
/// Kaore tenei * e kiia ana he whakarereke pakaru tenei.
///
/// Kua whakamaramahia te mahinga tatauranga putanga i te [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Hei whakamahi i te liballoc, kaua e kaweake ano ki te libstd.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;