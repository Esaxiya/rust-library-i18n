//! Nga mahi i runga i te ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Ka tirohia mena kei roto katoa nga paita o tenei poro i te awhe ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Ka tirohia ko nga poro e rua he taarua-kore aro ki te ASCII.
    ///
    /// He rite tonu ki te `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, engari kaore e tohatoha ana me te kape i nga waahanga poto.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Ka huri i tenei waahanga ki tona ASCII take nui e taurite ana i te waahi.
    ///
    /// Ko nga reta ASCII 'a' ki 'z' ka maherehia ki te 'A' ki te 'Z', engari ko nga reta kore ASCII kaore i whakarereke.
    ///
    /// Hei whakahoki i tetahi uara taapiri hou me te kore e whakarereke i tetahi, whakamahia [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Faafariu tenei wāhanga ki tona ASCII ōrite take o raro i roto i-wahi.
    ///
    /// Ko nga reta ASCII 'A' ki 'Z' ka maherehia ki te 'a' ki te 'z', engari ko nga reta kore ASCII kaore i whakarereke.
    ///
    /// Hei whakahoki i tetahi uara uara hou me te kore e whakarereke i tetahi, whakamahia [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Whakahoki `true` mena he paita o te kupu `v` he nonascii (>=128).
/// I kapohia mai i `../str/mod.rs`, he rite te mahi mo te whakamana utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Te whakamatau i te whakamatau ASCII ka whakamahi i nga mahi whakamahi-i-te-waa kaore i nga mahi paita-i-te-waa (ka taea).
///
/// Ko te algorithm e whakamahia ana e matou i konei he maamaa noa.Mena he poto rawa te `s`, ka tirohia noa e ia nga paita ka oti ai.Ki te kore:
///
/// - Panuihia te kupu tuatahi me te uta utaina.
/// - Whakatikahia te atatohu, panuihia nga kupu o muri kia mutu ra ano nga kawenga haangai.
/// - Panuihia te `usize` whakamutunga mai i te `s` me te utanga kore haangai.
///
/// Mena ko enei kawenga e whakaputa ana i tetahi mea e hoki mai ai te `contains_nonascii` (above), ka mohio taatau he he te whakautu.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Mena kaore e riro mai i a maatau tetahi mea mai i te whakamahi kupu-i-te-waa, hoki atu ki te koropiko scalar.
    //
    // Ka mahia e maatau tenei mo nga hoahoanga kaore he raru o te `size_of::<usize>()` mo te `usize`, na te mea he keehi ke te edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Ka panuihia e maatau te kupu tuatahi kaore i haangai, ko te tikanga `align_offset` he
    // 0, ka panuihia ano e maatau taua uara mo te panui tika.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // HAUMARU: manatoko tatou `len < USIZE_SIZE` i runga.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // I tirohia e maatau tenei i runga ake nei.
    // Kia mahara ko te `offset_to_aligned` he `align_offset` ko te `USIZE_SIZE` ranei, e rua e tirotirohia ana i runga ake nei.
    //
    debug_assert!(offset_to_aligned <= len);

    // SAFETY: ko te kupu_ptr te (whakanoho tika) ki te whakamahi i te ptr e whakamahia ana e taatau ki te paanui i te
    // poro waenganui o te poro.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` Ko te taupū paita o `word_ptr`, e whakamahia ana mo nga arowhai mutunga koropiko.
    let mut byte_pos = offset_to_aligned;

    // Taki Paranoia e pā ana ki tīaroaro, mai kei e pā ana ki ki te mahi i te paihere o kawenga unaligned tatou.
    // I roto i te mahinga kaore e taea te aukati i te bug i te `align_offset` ahakoa.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Panuihia nga kupu o muri tae atu ki te kupu raina whakamutunga, haunga nga kupu whakamutunga i waatea kia mahi i te hiku haki i muri, kia tuturu tonu te hiore kotahi `usize` te nuinga ki te nui atu ki te branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Tirohia te Sanity kei roto i nga rohe te paanui
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Ana ko o maatau whakaaro mo `byte_pos` kei te mau tonu.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SAFETY: Kei te mohio matau he tika te huringa o te `word_ptr` (na te mea
        // `align_offset`), a ka mohio taatau he maha nga paita i waenga i te `word_ptr` me te mutunga
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SAFETY: Kei te mohio taatau ko `byte_pos <= len - USIZE_SIZE`, te tikanga ko tera
        // i muri i tenei `add`, `word_ptr` ka neke atu i te-mutunga-mutunga.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Tirohia te Sanity kia kotahi anake te `usize` e toe ana.
    // Ma tenei e tau ai to tatou ahua koropiko.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SAFETY: Ko tenei ka whakawhirinaki ki `len >= USIZE_SIZE`, ka tirotirohia e maatau i te tiimatanga.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}