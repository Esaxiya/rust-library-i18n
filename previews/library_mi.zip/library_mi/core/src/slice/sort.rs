//! Poro kōmaka
//!
//! Kei roto i tenei waahanga he algorithm wehewehe i runga i te tauira-aukati i a Orson Peters, i whakaputaina i: <https://github.com/orlp/pdqsort>
//!
//!
//! He hototahi te mahi wehe kaore e taatatia na te mea kaore e tohaina te mahara, kaore i rite ki ta tatou whakatinana wehewehe pumau.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// A, no te maturuturu iho, kape i `src` ki `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SAFETY: He akomanga awhina tenei.
        //          Tena tirohia tona whakamahinga mo te tika.
        //          Ara, me tino mohio koe kaore te `src` me te `dst` e taapiri kia hiahiatia e `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Ka hurihia te waahanga tuatahi ki te taha matau tae noa ki te tutaki ki tetahi waahanga nui ake ranei.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: Ko nga mahi kore haumaru i raro ake nei ko te taatai kaore he haki here (`get_unchecked` me `get_unchecked_mut`)
    // me te kape i te mahara (`ptr::copy_nonoverlapping`).
    //
    // a.fakahokohoko:
    //  1. I tirohia e maatau te rahi o te kohinga ki>=2.
    //  2. Katoa nga tauanga ka mahi maatau i waenga i te {0 <= index < len} i te nuinga o te waa.
    //
    // b.tārua Memory
    //  1. Kei te whiwhi tohu maatau mo nga tohutoro e pono ana.
    //  2. e kore e taea e ratou te īnaki no te whiwhi tatou atatohu ki kuputohu rerekētanga o te pōro.
    //     Ara, `i` me `i-1`.
    //  3. Mena he tika te hono o te poro, ka tika te whakariterite i nga waahanga.
    //     Ko te kawenga a te kaiwaea kia aata whakarite kia haangai tika te poro.
    //
    // Tirohia nga korero i raro ake nei mo nga korero taipitopito.
    unsafe {
        // Mena ko nga waahanga tuatahi e rua kaore i te ota ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Panuihia te waahanga tuatahi ki te taurangi tohatoha-tohaina.
            // Mena he mahi whakataurite e whai ake nei ko panics, ka heke iho a `hole` ka tuhi ano i te waahanga ki roto i te poro.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Nuku `i`-th huanga kotahi te wahi ki te maui, ka huri i te koha ki te taha matau.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ka makaka ka kape `tmp` ki te koha e toe ana i te `v`.
        }
    }
}

/// Ka hurihia te waahanga whakamutunga ki te taha maui kia tutaki ki tetahi waahanga iti ake ranei.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: Ko nga mahi kore haumaru i raro ake nei ko te taatai kaore he haki here (`get_unchecked` me `get_unchecked_mut`)
    // me te kape i te mahara (`ptr::copy_nonoverlapping`).
    //
    // a.fakahokohoko:
    //  1. I tirohia e maatau te rahi o te kohinga ki>=2.
    //  2. Katoa nga tauanga ka mahi maatau i waenga i te `0 <= index < len-1` i te nuinga o te waa.
    //
    // b.tārua Memory
    //  1. Kei te whiwhi tohu maatau mo nga tohutoro e pono ana.
    //  2. e kore e taea e ratou te īnaki no te whiwhi tatou atatohu ki kuputohu rerekētanga o te pōro.
    //     Ara, `i` ko `i+1`.
    //  3. Mena he tika te hono o te poro, ka tika te whakariterite i nga waahanga.
    //     Ko te kawenga a te kaiwaea kia aata whakarite kia haangai tika te poro.
    //
    // Tirohia nga korero i raro ake nei mo nga korero taipitopito.
    unsafe {
        // Mena ko nga mea e rua o muri kaore i te ota ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Panuihia te waahanga whakamutunga ki roto i te taurangi tohatoha-tohaina.
            // Mena he mahi whakataurite e whai ake nei ko panics, ka heke iho a `hole` ka tuhi ano i te waahanga ki roto i te poro.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Nuku `i`-th tetahi wahi huānga ki te tika, ko te kupu neke te poka ki te maui.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ka makaka ka kape `tmp` ki te koha e toe ana i te `v`.
        }
    }
}

/// Me wehe tetahi waahanga ma te huri i etahi waahanga o-waho-a-roto.
///
/// Whakahokia `true` ki te kōmaka te wāhanga e i te mutunga.Ko tenei mahinga ko te *O*(*n*) keehi kino rawa atu.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Te rahinga o nga takirua tata-waho-tata e neke ana ka neke.
    const MAX_STEPS: usize = 5;
    // Ki te he poto atu i tenei te wāhanga, e kore e nuku tetahi huānga.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SAFETY: Kua oti ke te tirotiro ma te `i < len`.
        // Katoa ko to tatou fakahokohoko muri anake i roto i te awhe `0 <= index < len`
        unsafe {
            // Rapua te waahanga e whai ake nei o nga mea timatanga-o-te-raupapa e piri ana.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Kua oti tatou?
        if i == len {
            return true;
        }

        // Kaua e neke nga waahanga i nga waahanga poto, he utu mo te mahi.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Hurihia nga waahanga e rua kua kitea.Tenei e tona ratou i roto i te raupapa tika.
        v.swap(i - 1, i);

        // Me neke te waahanga iti ki te taha maui.
        shift_tail(&mut v[..i], is_less);
        // Shift te huānga rahi ki te tika.
        shift_head(&mut v[i..], is_less);
    }

    // kihai ianei te whakahaere ki te kōmaka te wāhanga i roto i te iti te maha o hikoinga.
    false
}

/// Ka kōmaka te wāhanga mā te whakamahi i kōkuhunga ahua, i te mea *e*(*n*^ 2) kino-take.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Ka tohaina te `v` ma te whakamahi i te puranga, e whakamana ana i te *O*(*n*\*log(* n*)) tino kino rawa atu.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ko tenei puranga ruarua e whakaute ana i te `parent >= child` whakakeke.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Nga Tamariki o `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Kōwhiritia te tamaiti nui.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Kati mena kei te `node` te kaitautoko.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Huri `node` ki te tamaiti nui, neke kotahi taahiraa iho, a ka haere tonu Tātarihia.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Hangaia te puranga i te waa raina.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pahūhia nga mea nui mai i te puranga.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Wehenga `v` ki nga waahanga iti ake i te `pivot`, ka whai ake nga waahanga nui atu i te `pivot` ranei.
///
///
/// Whakahoki ai i te maha o nga huanga iti ake i te `pivot`.
///
/// Ko te whakawehe ka whakahaerehia poraka-poraka kia iti ai te utu mo nga mahi manga.
/// Ko tenei whakaaro ka whakaatuhia ki te pepa [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Tau o nga waahanga i roto i te poraka angamaheni.
    const BLOCK: usize = 128;

    // Ko te algorithm wehewehewehe ka taatai i nga mahi e whai ake nei kia oti ra ano:
    //
    // 1. Tuhia he poraka mai i te taha maui ki te tohu i nga waahanga nui ake i te orite ranei ki te kaurori.
    // 2. Tuhia he poraka mai i te taha matau ki te tohu i nga waahanga iti ake i te kaurori.
    // 3. Exchange nga āhuatanga i tāutuhia ai i waenganui i te maui, me te taha ki matau.
    //
    // Ka purihia e maatau nga waahanga e whai ake nei mo te poraka o nga waahanga:
    //
    // 1. `block` - Te maha o nga waahanga o te poraka.
    // 2. `start` - Me tiimata te tohu tohu ki te raarangi `offsets`.
    // 3. `end` - Whakamutua te tohu ki te raarangi `offsets`.
    // 4. `offset, Nga tohu o nga waahanga kaore i te ota i roto i te poraka.

    // Ko te poraka o nāianei i te taha ki maui (i `l` ki `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Te poraka o naianei i te taha matau (mai i `r.sub(block_r)` to `r`).
    // SAFETY: Ko nga tuhinga mo .add() e kii ana ko te `vec.as_ptr().add(vec.len())` he haumaru tonu`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Ka whiwhi ana tatou i nga VLA, ngana ki te hanga i tetahi raina te roa `min(v.len(), 2 * PATU) `kaua
    // neke atu i te rua nga raina-whika whakarite roa te roa `BLOCK`.Akene he pai te keteroki o nga VLA.

    // Whakahokia te maha o ngā huānga i waenganui i atatohu `l` (inclusive) me `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Kua oti taatau ki te wehewehe poraka-poraka ka tata mai te `l` me te `r`.
        // Na ka mahi maatau taapiri kia taea ai te wehewehe i nga waahanga e toe ana i waenga.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Te maha o nga mea e toe ana (kaore ano kia whakataurite ki te kaurori).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Whakatikahia te rahi o te poraka kia kore te poraka maui me te matau e tarai, engari kia tino rite ki te taupoki i te āputa e toe ana.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Tuhia nga waahanga `block_l` mai i te taha maui.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SAFETY: Ko nga mahi kore haumaru i raro ake nei ko te whakamahinga o te `offset`.
                //         E ai ki nga tikanga e hiahiatia ana e te mahi, ka makona matou i te mea:
                //         1. `offsets_l` kua tohaina-tohaina, a na reira ka kiia he taonga wehe kua wehea.
                //         2. Ko te mahi `is_less` ka whakahoki i te `bool`.
                //            Ko te maka i te `bool` kaore e neke ake i te `isize`.
                //         3. Kua whakapumautia e maatau ko `block_l` ka `<= BLOCK`.
                //            Ano hoki, ko te `end_l` i te timatanga o te tohu tohu o `offsets_` i kiia i runga i te puranga.
                //            Na, e mohio ana taatau ahakoa ko te keehi tino kino (ko nga tono katoa mo te `is_less` ka hoki mai he teka) ka tae atu ki te 1 paita te mutunga.
                //        Ko tētahi atu mahi unsafety konei te ingoakē `elem`.
                //        Heoi, ko te tīmatanga `elem` te timata atatohu ki te wāhanga i te mea tika tonu.
                unsafe {
                    // Whakataurite peka.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // huānga Trace `block_r` i te taha ki matau.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SAFETY: Ko nga mahi kore haumaru i raro ake nei ko te whakamahinga o te `offset`.
                //         E ai ki nga tikanga e hiahiatia ana e te mahi, ka makona matou i te mea:
                //         1. `offsets_r` kua tohaina-tohaina, a na reira ka kiia he taonga wehe kua wehea.
                //         2. Ko te mahi `is_less` ka whakahoki i te `bool`.
                //            Ko te maka i te `bool` kaore e neke ake i te `isize`.
                //         3. Kua whakapumautia e maatau ko `block_r` ka `<= BLOCK`.
                //            Plus, i tuatahi whakaturia `end_r` ki te atatohu timata o `offsets_` i whakapuakina i runga i te tāpae.
                //            Na, e mohio ana taatau ahakoa ko te keehi tino kino (ko nga tono katoa mo te `is_less` ka hoki pono) ka neke atu i te 1 paita te mutunga.
                //        Ko tētahi atu mahi unsafety konei te ingoakē `elem`.
                //        Heoi, `elem` i te tuatahi `1 *sizeof(T)` i mua o te mutunga ka whakahekehia e `1* sizeof(T)` i mua i to uru atu.
                //        Ano hoki, i kii te `block_r` he iti ake i te `BLOCK` me te `elem` na reira ka tohu atu ki te timatanga o te poro.
                unsafe {
                    // Whakataurite peka.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Te maha o nga waahanga o-waho-ota kia huri i waenga i te taha maui me te taha matau.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Tena ki te huri i tetahi takirua i tera wa, he pai ake te mahi i te huringa huringa.
            // e kore te mea tino ōrite ki te Whitiwhiti tenei, engari hua he hua rite te whakamahi i ngā mahi mahara iti.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Ko nga mea katoa kei waho-o-ota i te poraka maui i nekehia.Nuku ki te poraka e whai ake nei.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // i oho āhuatanga katoa i roto i-o tikanga-i roto i te poraka tika.Nuku ki te poraka o mua.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Ko nga mea e toe ana inaianei ko te nuinga o te poraka (ki te taha maui ki matau ranei) me nga waahanga o-waho e tika ana kia neke.
    // Ko era mea e toe ana ka taea te neke noa ki te pito o to raatau poraka.
    //

    if start_l < end_l {
        // Ka noho tonu te poraka maui.
        // Nekehia nga toenga o-waho-o-ota ki te taha matau rawa.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Ko te poraka tika kei te noho tonu.
        // Nekehia nga toenga o-waho-o-ota ki te maui maui.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Kaore he mea ke atu, kua mutu taatau.
        width(v.as_mut_ptr(), l)
    }
}

/// Wehenga `v` ki nga waahanga iti ake i te `v[pivot]`, ka whai ake nga waahanga nui atu i te `v[pivot]` ranei.
///
///
/// Whakahokia te tuple o:
///
/// 1. Tau o nga waahanga iti ake i te `v[pivot]`.
/// 2. Pono ki te i roherohea kē `v`.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Whakanohia te kaurori i te timatanga o te poro.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Panuihia te kaurori ki roto i te taurangi tohatoha-tohaina kia pai ai.
        // Ki te he mahi whakarite e whai ake nei panics, ka te kaurori e tuhituhia aunoa whakahokia ki te wāhanga.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Rapua nga waahanga takirua tuatahi o waho-o-raupapa
        let mut l = 0;
        let mut r = v.len();

        // SAFETY: Ko te kore haumaru i raro nei ko te whakariterite i te ngohi.
        // Hoki te kotahi tuatahi: mahi kua matou nga rohe arowhai konei ki `l < r`.
        // Mo te tuarua: Kei a matou i te tuatahi `l == 0` me `r == v.len()` a kua tirohia e maatau te `l < r` i nga mahi tohu katoa.
        //                     Mai i konei ka mohio taatau ko te `r` me tino `r == l` i whakaatuhia kia whai mana mai i te tuatahi.
        unsafe {
            // Kimihia te nui huānga tuatahi atu ranei rite ki te kaurori.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Rapua te waahanga whakamutunga hei iti ake na te kaurori.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` ka pau i te whanui ka tuhi i te kaurori (he taurangi tohatoha-tohaina) ka hoki ano ki te poro o te timatanga.
        // He mea nui tenei mahi ki te whakarite kia ahuru!
        //
    };

    // Whakanohia te kaurori i waenga i nga waahanga e rua.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Wehewehenga `v` ki nga waahanga e rite ana ki te `v[pivot]` ka whai ake nga waahanga nui atu i te `v[pivot]`.
///
/// rite hoki te maha o ngā āhuatanga ki te kaurori.
/// E kiia ana ko te `v` kaore he waahanga iti ake i te kaurori.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Whakanohia te kaurori i te timatanga o te poro.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Panuihia te kaurori ki roto i te taurangi tohatoha-tohaina kia pai ai.
    // Ki te he mahi whakarite e whai ake nei panics, ka te kaurori e tuhituhia aunoa whakahokia ki te wāhanga.
    // SAFETY: He tika te tohu i konei na te mea i tangohia mai i te korero mo te poro.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Wehea tenei waahanga.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SAFETY: Ko te kore haumaru i raro nei ko te whakariterite i te ngohi.
        // Hoki te kotahi tuatahi: mahi kua matou nga rohe arowhai konei ki `l < r`.
        // Mo te tuarua: Kei a matou i te tuatahi `l == 0` me `r == v.len()` a kua tirohia e maatau te `l < r` i nga mahi tohu katoa.
        //                     Mai i konei ka mohio taatau ko te `r` me tino `r == l` i whakaatuhia kia whai mana mai i te tuatahi.
        unsafe {
            // Rapua te waahanga tuatahi nui ake i te kaurori.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Rapua te waahanga whakamutunga kia rite ki te kaurori.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Kua oti tatou?
            if l >= r {
                break;
            }

            // Whakawhitihia nga waahanga kua puta mai o nga waahanga kaore i te-ota.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // kitea e matou rite āhuatanga `l` ki te kaurori.Taapirihia te 1 ki te kaute mo te kaurori ano.
    l + 1

    // `_pivot_guard` ka pau i te whanui ka tuhi i te kaurori (he taurangi tohatoha-tohaina) ka hoki ano ki te poro o te timatanga.
    // He mea nui tenei mahi ki te whakarite kia ahuru!
}

/// E titaritari ana etahi āhuatanga a tawhio noa i roto i te ngana ki te wahi i tauira e ai ai te imbalanced pātaki i quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom generator tau mai i te pepa "Xorshift RNGs" na George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Tangohia tau tupurangi modulo tenei tau.
        // Ko te tau ka uru ki te `usize` na te mea kaore te `len` i te nui ake i te `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Ko etahi kaitono kaurori ka tata ki tenei tatauranga.Kia randomize o ratou.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Hangaia he tau takirua modulo `len`.
            // Heoi, i roto i te tikanga ki te karo ngā mahi utu nui tatou tango tuatahi modulo reira he mana o e rua, a ka iti haere e `len` tae noa hāngai reira ki te awhe `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` kua tohua kia iti ake i te `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Ka kowhiri i te kaurori i te `v` ka whakahoki i te taurangi me te `true` mena ka kowhitihia te waahanga.
///
/// Ko nga huanga i te `v` ka taea te whakatika ano i te waa.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // roa iti ki te whiriwhiri i te tikanga waenga-o-medians.
    // poro poto whakamahi i te tikanga ohie waenga-o-toru.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Te rahinga o nga huringa ka taea te mahi i tenei mahi.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // E toru nga tohu e tata ana ka kowhiri e matou he kaurori.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Kaute ki te katoa maha o te whakawhiti e tatou e pā ana ki te mahi i te wā e kōmaka kuputohu.
    let mut swaps = 0;

    if len >= 8 {
        // Whakawhitihia nga tohu kia `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Whakawhitihia nga tohu kia `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Ka kitea te waenga waenga o `v[a - 1], v[a], v[a + 1]` ka penapena i te taurangi ki te `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Kimihia medians i roto i te vahi o `a`, `b`, ko `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Rapua te tau waenga i waenga i te `a`, `b`, me te `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Ko te rahinga o nga swap i whakahaerehia.
        // He tuponotanga kei te heke mai te poro, ka heke ranei te nuinga, na reira ko te hurihuri ka tere ake pea te wehe.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` recursively tini.
///
/// Mena he mea whai mua tetahi o nga poro i roto i te raarangi taketake, kua tohua hei `pred`.
///
/// `limit` ko te maha o nga waahanga taangata kua whakaaehia i mua i te huri ki te `heapsort`.
/// Ki te kore, ka huri tonu tenei mahi ki te puranga.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ko nga waahanga tae atu ki tenei waa ka whakariterite ma te whakauru momo whakauru.
    const MAX_INSERTION: usize = 20;

    // He pono mena he riterite te wehewehe o muri.
    let mut was_balanced = true;
    // He pono mena kaore i paku te waahanga o te waahanga whakamutunga (kua oti te wehe te waahanga).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Ko nga poro tino poto ka tohaina ma te whakauru momo whakauru.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Mena he maha nga kowhiringa pooti kino i whakatauhia, hoki atu ki te puranga kia tutuki ai te `O(n * log(n))` tino kino.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Mena kaore i te taurite nga waahanga whakamutunga, ngana kia pakaru te tauira i te waahanga me te huri i etahi waahanga huri noa.
        // Ko te tumanako ka kowhiri tatou i tetahi kaurori pai ake i tenei wa.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Tohua he kaurori ka ngana ki te matapae kua oti te wehe te poro.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ki te i totika tautika te wawahi whakamutunga, me te kore i pikarikari huānga, a ki te Waitohungia kōwhiringa kaurori te pea kua kōmaka te pōro ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Whakamātauria tautuhi rave rahi āhuatanga i roto i-o tikanga-a neke ratou ki tūranga tika.
            // Mena ka mutu te waahanga o te poro, ka mutu.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ki te he rite ki te mua te kaurori whiriwhiri, ka te reira te huānga iti i roto i te wāhanga.
        // Te wawahi i te wāhanga rite ki huānga ki me āhuatanga nui atu te kaurori.
        // Te tikanga ka patua tenei keehi i te maha o nga waahanga taarua o te poro.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Haere tonu ki te wehe i nga waahanga nui ake i te kaurori.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Wehea te poro.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Wahia te poro ki te `left`, `pivot`, me te `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Me hoki ano ki te taha poto noa iho hei whakaiti i te tapeke o nga waea panui ka pau i te waahi taapiri.
        // Na tika tonu ki te taha roa (he rite ki te hiawero recursion tenei).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Ka wehewehe i te `v` ma te whakamahi i te tauira tere-hinga i te tere, ara ko te *O*(*n*\*log(* n*)) tino kino.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kaore he tikanga whai kiko o te tatai mo nga momo kore-rahi.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Whakaitihia te maha o nga waahanga taurite ki te `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // No te poro o runga ki tenei roa te reira pea tere ki noa ahua ratou.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Tohua he kaurori
        let (pivot, _) = choose_pivot(v, is_less);

        // Ki te he rite ki te mua te kaurori whiriwhiri, ka te reira te huānga iti i roto i te wāhanga.
        // Te wawahi i te wāhanga rite ki huānga ki me āhuatanga nui atu te kaurori.
        // Te tikanga ka patua tenei keehi i te maha o nga waahanga taarua o te poro.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Mena kua paahitia e maatau taatau tohu, he pai taatau.
                if mid > index {
                    return;
                }

                // Ki te kore, haere tonu ki te wehe i nga waahanga nui ake i te kaurori.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Wahia te poro ki te `left`, `pivot`, me te `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Mena te waenganui==te tohu, ka mutu taatau, mai i te wa i whakaaria ai e partition() ko nga waahanga katoa i muri o te waenganui he nui ake, he rite ranei ki waenga
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Kaore he tikanga whai kiko o te tatai mo nga momo kore-rahi.Mahi i tetahi mea.
    } else if index == v.len() - 1 {
        // Rapua te waahanga nui ka waiho ki te waahi whakamutunga o te raarangi.
        // kei noa ki te whakamahi i `unwrap()` konei no te mea e matau ana tatou kahore me v e kau matou.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Rapua te waahanga iti ka waiho ki te waahi tuatahi o te raarangi.
        // kei noa ki te whakamahi i `unwrap()` konei no te mea e matau ana tatou kahore me v e kau matou.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}