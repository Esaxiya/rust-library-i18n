//! Tonotono whakamahia e iterators o wāhanga.

// Ko te whakauru i te_mahi me te len he rereketanga nui o te mahinga
macro_rules! is_empty {
    // Ko te huarahi e whakawairihia ai e matou te roa o te kaitahuri ZST, he pai mo te ZST me te kore-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Hei whakakore i etahi haki rohe (tirohia te `position`), ka taatau te roa i te waa kaore i te mohiotia.
// (I whakamatauria e `codegen/poro-waahi-rohe-taki`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // i etahi wa ka whakamahia maatau i roto i tetahi poraka kore haumaru

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ka whakamahia e tenei _cannot_ te `unchecked_sub` na te mea ka whakawhirinaki matou ki te takai hei tohu i te roa o nga miihini poro ZST roa.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Kei te mohio taatau ko `start <= end`, na he pai ke atu i te `offset_from`, me hainahia.
            // Ma te whakarite haki e tika ana ka taea e maatau te korero ki a LLVM tenei, ma tenei e ahei te tango i nga haki rohe.
            // SAFETY: Na te kaihauturu momo, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Ma te korero ano ki a LLVM he wehe nga tohu ki te maha tonu o te rahinga momo, ka taea te arotau i te `len() == 0` ki raro ki te `start == end` kaua ki te `(end - start) < size`.
            //
            // SAFETY: Na te momo kaitoro, kua haangai nga tohu kia
            //         te tawhiti i waenga i a raatau me nui te tohu kaute
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Ko te whakamaaramatanga tiri o nga whakamaarama `Iter` me `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Whakahoki ai i te waahanga tuatahi ka neke te tiimatanga o te whiti i mua i te 1.
        // Ka pai ake te whakapai ake i te mahinga ka whakaritea ki tetahi mahi kua haangai.
        // Ko te kaitahuri kaua e putua.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Hoki te huānga whakamutunga me nuku te mutunga o nga whakamuri iterator e 1.
        // Ka pai ake te whakapai ake i te mahinga ka whakaritea ki tetahi mahi kua haangai.
        // Ko te kaitahuri kaua e putua.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Tīngongo te iterator ka T ko te ZST, i neke te mutunga o nga whakamuri iterator e `n`.
        // `n` kaua e nui ake i te `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // mahi Kaiwhakamarie hoki te hanga he wāhanga i te iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SAFETY: te iterator i hangaia mai i tetahi waahanga me te tohu
                // `self.ptr` me te roa `len!(self)`.
                // He tohu tenei ka tutuki nga whakaritenga katoa mo te `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Helper mahi mō te neke i te tīmatanga o te iterator whakamua i ngā āhuatanga `offset`, e hoki ana i te tīmatanga tawhito.
            //
            // Kaore i te haumaru na te mea kaore e nui ake te utu mutunga ki te `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SAFETY: ka kii te kaiwaea ko te `offset` kaore i neke ake i te `self.len()`,
                    // na ko tenei tohu hou kei roto i te `self` ana ka kiia ka kore-kore.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Ko te mahi a te kaiawhina mo te neke whakamuri o te pito o te whiti e nga huanga `offset`, me te whakahoki i te mutunga hou.
            //
            // Kaore i te haumaru na te mea kaore e nui ake te utu mutunga ki te `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SAFETY: ka kii te kaiwaea ko te `offset` kaore i neke ake i te `self.len()`,
                    // e pumau ana kia kaua e nui ake te `isize`.
                    // Ano hoki, ko te tohu tohu kei roto i nga rohe o `slice`, e tutuki ana i etahi atu whakaritenga mo te `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // taea te whakatinana ki te poro, ko tenei mawehe rohe arowhai

                // SAFETY: He pai nga waea `assume` mai i te timatanga o te tohu tohu
                // me noho kore-kore, me nga poro mo nga kore-ZST me whai tohu kore-kore ranei te tohu.
                // Ko te piiraa ki `next_unchecked!` he ahuru mai i te mea ka tirohia mena ka putu te whiti.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Kua noho kau noa tenei taatai.
                    if mem::size_of::<T>() == 0 {
                        // E tatou ki te mahi i reira tenei ara rite `ptr` kore ai e 0, engari `end` taea e (e tika ana ki te tākai).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SAFETY: ko te mutunga kaore e 0 ki te kore a T i te ZST na te mea kaore te ptr i te 0 ka mutu>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SAFETY: Kei roto tatou i nga rohe.He tika te mahi a `post_inc_start` ahakoa mo nga ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Ka takahia e maatau te whakamahinga taunoa, e whakamahi ana i te `try_fold`, na te mea ko tenei whakamahinga ngawari ka iti ake te LLVM IR ka tere ki te whakahiato.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Ka takahia e maatau te whakamahinga taunoa, e whakamahi ana i te `try_fold`, na te mea ko tenei whakamahinga ngawari ka iti ake te LLVM IR ka tere ki te whakahiato.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Ka takahia e maatau te whakamahinga taunoa, e whakamahi ana i te `try_fold`, na te mea ko tenei whakamahinga ngawari ka iti ake te LLVM IR ka tere ki te whakahiato.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Ka takahia e maatau te whakamahinga taunoa, e whakamahi ana i te `try_fold`, na te mea ko tenei whakamahinga ngawari ka iti ake te LLVM IR ka tere ki te whakahiato.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Ka takahia e maatau te whakamahinga taunoa, e whakamahi ana i te `try_fold`, na te mea ko tenei whakamahinga ngawari ka iti ake te LLVM IR ka tere ki te whakahiato.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Ka takahia e maatau te whakamahinga taunoa, e whakamahi ana i te `try_fold`, na te mea ko tenei whakamahinga ngawari ka iti ake te LLVM IR ka tere ki te whakahiato.
            // Ano hoki, ka karo te `assume` i te haki rohe.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SAFETY: ka tutuki taatau ma te reimana koropiko e tuku:
                        // ka `i >= n`, `self.next()` ka whakahoki `None` ka whati te koropiko.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Ka takahia e maatau te whakamahinga taunoa, e whakamahi ana i te `try_fold`, na te mea ko tenei whakamahinga ngawari ka iti ake te LLVM IR ka tere ki te whakahiato.
            // Ano hoki, ka karo te `assume` i te haki rohe.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SAFETY: `i` me iti ake i te `n` mai i te tiimata mai i te `n`
                        // a kei te heke noa iho.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SAFETY: me kii e te kaiwaea ko `i` kei roto i nga rohe
                // te poro o raro, no reira kaore e taea e `i` te neke atu i te `isize`, ana ko nga tohutoro kua hoki mai he tohu ki tetahi waahanga o te poroi ka whai mana.
                //
                // mōhio hoki e whakapūmau te kaiwaea hoki e kore tatou e ka karanga ano ki te taupū taua, a e huaina kahore atu tikanga e ka uru tenei subslice, na he reira tika hoki ki te tohutoro hoki kia mutable i te take o
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // taea te whakatinana ki te poro, ko tenei mawehe rohe arowhai

                // SAFETY: He pai te waea `assume` mai i te mea ko te tohu timatanga o te poro kia kaua e whakakore,
                // me nga poro mo nga kore-ZST me whai tohu kore-kore hoki.
                // He haumaru te karanga ki `next_back_unchecked!` mai tirohia tatou ki te he kau tuatahi te iterator.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Kua noho kau noa tenei taatai.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SAFETY: Kei roto tatou i nga rohe.He tika te mahi a `pre_dec_end` ahakoa mo nga ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}