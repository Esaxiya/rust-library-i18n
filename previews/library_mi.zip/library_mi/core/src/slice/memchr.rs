// Ko te whakatinanatanga taketake i tangohia mai i te rust-memchr.
// Mana pupuri 2015 Andrew Gallant, bluss me Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Whakamahia te tapahi.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Whakahoki `true` mena kei `x` etahi paita kore.
///
/// Mai i *Nga Mea Whakataunga*, J. Arndt:
///
/// "Ko te whakaaro ko te tango i tetahi o nga paita katahi ka rapu paita i reira te nama i whakatipuria ai tae atu ki nga mea tino nui
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Whakahoki ai i te taupū tuatahi e taurite ana i te paita `x` i te `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Ara tere mo nga poro iti
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Matawai mo te uara paita kotahi ma te panui i nga kupu `usize` e rua i te wa kotahi.
    //
    // Wehea `text` ki nga waahanga e toru
    // - unaligned wahi tuatahi, i mua i te kupu tuatahi hāngai wāhitau i roto i te kuputuhi
    // - tinana, karohia nga kupu 2 i te wa kotahi
    // - te waahanga whakamutunga e toe ana, <2 kupu rahi

    // rapua kia tae ki te rohe e hono ana
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // rapua te tinana o te tuhinga
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // HAUMARU: paparangi o te i te whakapūmau i te tawhiti o te iti rawa 2 usize_bytes *
        // i waenga i te urupare me te mutunga o te poro.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // pakaru ki te mea he paita rite
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Rapua te paita i muri i te waahi ka mutu te koropiko o te tinana.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Whakahokia te taupū whakamutunga ōrite te paita `x` i `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Matawai mo te uara paita kotahi ma te panui i nga kupu `usize` e rua i te wa kotahi.
    //
    // Wehea `text` ki nga waahanga e toru:
    // - hiku taarua, i muri i te kupu whakamutunga i taatai i te wahitau ki te kupu,
    // - tinana, karapahia e 2 kupu i te wa,
    // - nga paita tuatahi e toe ana, <2 kupu rahi.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Ka karangahia tenei kia noa mai te roa o te kuhimua me te taapi.
        // I waenga ka mahi maatau e rua nga waahanga i te wa kotahi.
        // SAFETY: te whakawhiti i te `[u8]` ki te `[usize]` he ahuru engari mo nga rereketanga rahi e whakahaerehia ana e `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Rapua te tuhinga o te tuhinga, kia kaua e whiti i te Min_aligned_offset.
    // he taurite tonu te whakaurunga, no reira ko te whakamatautau i te `>` he rawaka ana me te karo i te kaha o te waipuke.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SAFETY: ka tiimata te timatanga ki te len, suffix.len(), mena ka nui atu i te
        // min_aligned_offset (prefix.len()) te toenga o te tawhiti ko te iti rawa 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Pakaru mena he paita rite.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Rapua te paita i mua i te waahi ka mutu te koropiko o te tinana.
    text[..offset].iter().rposition(|elt| *elt == x)
}