// ignore-tidy-filelength

//! Te whakahaerenga poro me te raweke.
//!
//! Mo nga korero taipitopito tirohia te [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// rust parakore memchr whakatinana, tangohia mai i rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Ko te iwi whānui tenei mahi anake no te mea i reira he kore ara atu ki te heapsort wae whakamātautau.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Whakahokia te maha o ngā āhuatanga i roto i te wāhanga.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SAFETY: tangi te tangi na te mea ka tukuna e tatou te roa o te mara hei whakamahi (me pehea)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: he haumaru tenei na te mea he rite te whakatakotoranga o te `&[T]` me te `FatPtr<T>`.
            // Ma te `std` anake e ahei te kii i tenei oati.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Whakakapihia ki te `crate::ptr::metadata(self)` ka pumau tena.
            // I tenei tuhinga ka hapa te "Const-stable functions can only call other const-stable functions".
            //

            // SAFETY: Ko te urunga ki te uara mai i te uniana `PtrRepr` he ahuru mai i te * const T
            // me nga Kamupene PtrCents<T>rite nga whakatakotoranga mahara.
            // Ko te std anake te mea ka taea te whakarite.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Whakahoki ai i te `true` mena he roa te roanga o te poro.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Whakahoki ai i te waahanga tuatahi o te poro, te `None` ranei mena he kau.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Whakahokia ai he tohu tohu ki te waahanga tuatahi o te poro, ki te `None` ranei mena he kau.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Whakahokia ai te tuatahi me nga toenga katoa o nga waahanga o te poro, te `None` ranei mena he kau.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Whakahokia ai te tuatahi me nga toenga katoa o nga waahanga o te poro, te `None` ranei mena he kau.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Whakahokihia te whakamutunga me nga toenga katoa o nga waahanga o te poro, te `None` ranei mena he kau.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Whakahokihia te whakamutunga me nga toenga katoa o nga waahanga o te poro, te `None` ranei mena he kau.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Whakahoki ai i te waahanga whakamutunga o te poro, te `None` ranei mena he kau.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Whakahokia ai he tohu tohu ki te mea whakamutunga o te poro.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Whakahoki ai i te korero ki tetahi waahanga waahanga waahanga ranei i runga i te momo taurangi.
    ///
    /// - Mena kua whakawhiwhia ki tetahi tuunga, whakahokia mai he korero ki te waahanga i tera tuunga `None` ranei mena kaore i te rohe.
    ///
    /// - Mena ka whakawhiwhia ki te awhe, whakahokia mai te mokamoka e hangai ana ki tera awhe, ki te `None` ranei ki te kore e herea.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Whakahoki ai i te korero ka taea te whakarereke ki tetahi waahanga waahanga waahanga ranei i runga i te momo taurangi (tirohia te [`get`]) ko te `None` mena kei waho te rohe i te taurangi.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Whakahoki ai i te korero ki tetahi waahanga waahanga waahanga ranei, me te kore e tirotiro i nga rohe.
    ///
    /// Hoki te rerekē haumaru kite [`get`].
    ///
    /// # Safety
    ///
    /// Ko te waeatanga i tenei tikanga me te taupū-i-rohe ko te *[whanonga kore tautuhi]* ahakoa kaore e whakamahia te tohutoro hua.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: me mau ki te kaiwaea te nuinga o nga whakaritenga haumaru mo te `get_unchecked`;
        // ka taea te whakakore i te poro no te mea ko te `self` he tohu ahuru.
        // He ahuru te tohu atawhai i whakahokia mai na te mea ko te `SliceIndex` me kii he pono.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Whakahoki ai i te korero rereke ki tetahi waahanga waahanga ranei, kaore ano kia tirohia nga rohe.
    ///
    /// Mo tetahi atu huarahi haumaru tirohia te [`get_mut`].
    ///
    /// # Safety
    ///
    /// Ko te waeatanga i tenei tikanga me te taupū-i-rohe ko te *[whanonga kore tautuhi]* ahakoa kaore e whakamahia te tohutoro hua.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: me mau tonu i te kaiwaea nga whakaritenga haumaru mo te `get_unchecked_mut`;
        // ka taea te whakakore i te poro no te mea ko te `self` he tohu ahuru.
        // He ahuru te tohu atawhai i whakahokia mai na te mea ko te `SliceIndex` me kii he pono.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Whakahokia te atatohu raw ki moka o te wāhanga.
    ///
    /// Me whakarite i te kaiwaea e outlives te wāhanga te atatohu tenei hoki mahi, ka mutu i te reira ki runga tuhu ki paru ranei atu.
    ///
    /// Me whakarite hoki e te kaiwaea kia kore te tuhinga o te atatohu tohu (non-transitively) e tuhia ki (haunga ki roto i te `UnsafeCell`) te whakamahi i tenei tohu tetahi tohu ranei i ahu mai i a ia.
    /// Ki te hiahia koe ki te mutate te tirotiro o te pōro, te whakamahi i [`as_mut_ptr`].
    ///
    /// Ko te whakarereke i te ipu e tohutohuhia ana e tenei waahanga ka ahei te whakakotahi i tana peera, ka kore pea e tohu nga tohu ki a ia.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Whakahokia te atatohu mutable haumaru ki te moka o te wāhanga.
    ///
    /// Me whakarite i te kaiwaea e outlives te wāhanga te atatohu tenei hoki mahi, ka mutu i te reira ki runga tuhu ki paru ranei atu.
    ///
    /// Ko te whakarereke i te ipu e tohutohuhia ana e tenei waahanga ka ahei te whakakotahi i tana peera, ka kore pea e tohu nga tohu ki a ia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Whakahoki ai i nga tohu tohu e rua e whanui ana i te poro.
    ///
    /// Ko te awhe i whakahokia mai he hawhe-tuwhera, ko te tikanga ko nga tohu tohu whakamutunga *kotahi kua pahure* te waahanga whakamutunga o te poro.
    /// Ma tenei, e rua nga tohu tohu e whakaatuhia ana te waahanga kore, a ko te rereketanga i waenga i nga tohu e rua hei tohu mo te rahi o te poro.
    ///
    /// Tirohia te [`as_ptr`] mo nga whakatupato mo te whakamahi i enei tohu tohu.Me whakatupato ano te tohu mutunga, na te mea kaore e tohu ki tetahi waahanga tika o te poro.
    ///
    /// He pai tenei mahi mo te taunekeneke ki nga atanga ke e whakamahi ana i nga tohu e rua hei tohu ki te whānuitanga o nga mea kei te maumahara, pera ano me te C++ .
    ///
    ///
    /// He mea pai ano hoki te tirotiro mena he tohu tetahi tohu mo tetahi waahanga o tenei waahanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SAFETY: He pai te `add` i konei, na te mea:
        //
        //   - Ko nga tohu e rua he waahanga no te mea kotahi, na te tohu tika i mua ka kiia hoki te taonga.
        //
        //   - Ko te rahinga o te poro kaua e rahi ake i te isize::MAX paita, e kiia ana i konei:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Kahore he tākainga tawhio whai wāhi, kia rite ki poro kore e roropi mua te mutunga o te wāhi wāhitau.
        //
        // Tirohia nga tuhinga o pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Whakahoki ai i nga tohu tohu korekore e rua e totoro ana i te poro.
    ///
    /// Ko te awhe i whakahokia mai he hawhe-tuwhera, ko te tikanga ko nga tohu tohu whakamutunga *kotahi kua pahure* te waahanga whakamutunga o te poro.
    /// Ma tenei, e rua nga tohu tohu e whakaatuhia ana te waahanga kore, a ko te rereketanga i waenga i nga tohu e rua hei tohu mo te rahi o te poro.
    ///
    /// Tirohia te [`as_mut_ptr`] mo nga whakatupato mo te whakamahi i enei tohu tohu.
    /// titau te atatohu mutunga tūpato anō, rite kore e tohu i te reira ki te huānga whaimana i roto i te wāhanga.
    ///
    /// He pai tenei mahi mo te taunekeneke ki nga atanga ke e whakamahi ana i nga tohu e rua hei tohu ki te whānuitanga o nga mea kei te maumahara, pera ano me te C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // HAUMARU: Vakai as_ptr_range() i runga hoki aha he haumaru `add` konei.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Ngā rua ngā āhuatanga i roto i te wāhanga.
    ///
    /// # Arguments
    ///
    /// * a, Ko te taurangi o te timatanga tuatahi
    /// * b, Te taupūtanga o te waahanga tuarua
    ///
    /// # Panics
    ///
    /// Panics ki te `a` `b` ranei he i roto o rohe.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Kaore e taea te tango i nga nama e rua ka taea te huri mai i te vector kotahi, na me tohu tohu tohu.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // HAUMARU: `pa` ko `pb` kua hanga i tohutoro haumaru mutable me kōrero
        // ki nga mea tima o te poroi no reira ka tuturu kia whai mana, kia taurite.
        // Kia mahara ko te whakauru ki nga waahanga kei muri o te `a` me te `b` kua tirohia ka panic ka puta ke atu i nga rohe.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Ka hurihia te raupapa o nga waahanga i te poro, i te waahi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Mo nga momo iti rawa, ko nga taangata katoa e panui i te huarahi noa kaore e pai te mahi.
        // Ka taea e taatau te mahi pai ake, ma te whakawhiwhia ki te load/store kore whai kiko, ma te utaina i tetahi waahanga nui ake ka huri i te rehita.
        //

        // e meatia tano LLVM tenei mo tatou, kia rite ki matau reira pai atu tatou mahi ranei unaligned pānui e tōtika (mai i taua huringa i waenganui i putanga ARM rerekē, hei tauira) me he aha e waiho te rahi wāhi pai.
        // Heoi, mai i te LLVM 4.0 (2017-05) ka wehe noa te koropiko, no reira me mahi maatau ano tenei mahi.
        // (Whakapae: . Whakamuri ko raruraru no te mea e taea te hāngai te taha rerekē-ka waiho, ka he rerekē te roa-na reira te kore ara o emitting mua-me postludes ki te whakamahi i tino-tiaro SIMD i te waenganui)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Whakamahia te pepeha llvm.bswap ki te huri i nga u8 i roto i te whakamahi
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SAFETY: He maha nga mea hei tirotiro i konei:
                //
                // - Kia mahara ko te `chunk` he 4, ko te 8 ranei na te tohu CFg i runga ake nei.Na he pai te `chunk - 1`.
                // - He pai te tohu tohu me te tohu `i` i te mea ka whakamana te tohu koropiko
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - He pai te tohu tohu me te tohu `ln - i - chunk = ln - (i + chunk)`:
                //   - `i + chunk > 0` he pono noa iho.
                //   - Ma te huringa koropiko e tohu:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, na reira ka kore te tangohanga e totohu.
                // - He pai nga karanga `read_unaligned` me `write_unaligned`:
                //   - `pa` tohu ki te tohu `i` kei hea te `i < ln / 2 - (chunk - 1)` (tirohia i runga ake nei) me te `pb` tohu ki te tohu `ln - i - chunk`, no reira ko nga mea e rua `chunk` neke atu i te mutunga o te `self`.
                //
                //   - Ko nga maaramatanga tuatahi hei `usize` whaimana.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Whakamahia te huri-i-te-16 ki te huri i nga u16 i te u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SAFETY: Ka taea te panui i te u32 kore tohu mai i te `i` mena he `i + 1 < ln`
                // (A mārama `i < ln`), no te mea ia huānga he 2 paita me kei te pānui tatou 4.
                //
                // `i + chunk - 1 < ln / 2` # i te ahua
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Na te mea he iti ake i te roa e wehea ana ki te 2, na me uru ki roto i nga rohe.
                //
                // Ko te tikanga hoki ko te ahuatanga `0 < i + chunk <= ln` e whakaute ana i nga wa katoa, me te whakarite kia pai te whakamahi i te tohu a `pb`.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SAFETY: He iti iho te `i` ki te haurua o te roa o te poro
            // te whakauru ki te `i` me te `ln - i - 1` he haumaru (`i` ka tiimata mai i te 0 ana kaore e neke atu i te `ln / 2 - 1`).
            // Ko nga tohu tohu `pa` me `pb` na reira he tika, he taurite hoki, a ka taea te korero mai i te tuhi me te tuhi.
            //
            //
            unsafe {
                // Huri kore haumaru hei karo i nga huringa rohe ki te huringa ahuru.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Whakahokia ai he miihini ki runga i te poro.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Whakahokihia ai he miera e taea ai te whakakapi i ia uara.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Whakahoki ai i te miihini i runga i te taha windows katoa o te roa `size`.
    /// Ko te windows ka inaki.
    /// Mena he poto ake te poro i te `size`, ka kore te uara e hoki mai i nga uara.
    ///
    /// # Panics
    ///
    /// Panics mena ko `size` te 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Mena he poto ake te poro i te `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Whakahokihia ai he miihini mo nga waahanga `chunk_size` o te poro i ia wa, ka tiimata i te tiimatanga o te poro.
    ///
    /// Ko nga tapatapahi he poro, kaore e taapiri.Mena kaore te `chunk_size` e wehewehe i te roa o te poro, ka kore te waaawa whakamutunga e whai `chunk_size` te roa.
    ///
    /// Tirohia te [`chunks_exact`] mo te rereketanga o tenei miihini e whakahoki ana i nga waahanga o nga waahanga `chunk_size` i nga wa katoa, me te [`rchunks`] mo taua mea ano engari ka tiimata i te pito o te poro.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko `chunk_size` te 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Whakahokihia ai he miihini mo nga waahanga `chunk_size` o te poro i ia wa, ka tiimata i te tiimatanga o te poro.
    ///
    /// He poro poro nga poro, a, kaua e inaki.Mena kaore te `chunk_size` e wehewehe i te roa o te poro, ka kore te waaawa whakamutunga e whai `chunk_size` te roa.
    ///
    /// Tirohia te [`chunks_exact_mut`] mo te rereketanga o tenei miihini e whakahoki ana i nga waahanga o nga waahanga `chunk_size` i nga wa katoa, me te [`rchunks_mut`] mo taua mea ano engari ka tiimata i te pito o te poro.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko `chunk_size` te 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Whakahokihia ai he miihini mo nga waahanga `chunk_size` o te poro i ia wa, ka tiimata i te tiimatanga o te poro.
    ///
    /// Ko nga tapatapahi he poro, kaore e taapiri.
    /// Ki te kore e `chunk_size` wehe i te roa o te wāhanga, ka te ake whakamutunga ki huānga `chunk_size-1` ka mahue a taea te tiki i te mahi `remainder` o te iterator.
    ///
    ///
    /// Na te mea ka rite tonu nga waahanga o te `chunk_size` ki ia waahanga, ka taea e te kaipupuri te whakarite kia pai ake te waehere ka puta ake i te keehi o [`chunks`].
    ///
    /// Tirohia te [`chunks`] mo te rereketanga o tenei miihini ka whakahoki ano i te toenga hei waahanga iti ake, me te [`rchunks_exact`] mo te miihini ano engari ka tiimata i te pito o te poro.
    ///
    /// # Panics
    ///
    /// Panics mena ko `chunk_size` te 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Whakahokihia ai he miihini mo nga waahanga `chunk_size` o te poro i ia wa, ka tiimata i te tiimatanga o te poro.
    ///
    /// He poro poro nga poro, a, kaua e inaki.
    /// Mena kaore e wehewehe te `chunk_size` i te roa o te poro, ka tangohia nga mea whakamutunga tae atu ki te `chunk_size-1` ka taea te tango mai i te mahi `into_remainder` o te miihini.
    ///
    ///
    /// Na te mea ka rite tonu nga waahanga o te `chunk_size` ki ia waahanga, ka taea e te kaipupuri te whakarite kia pai ake te waehere ka puta ake i te keehi o [`chunks_mut`].
    ///
    /// Tirohia te [`chunks_mut`] mo te kē o tenei iterator e hoki ano te toenga, ano he wāhi iti, ko [`rchunks_exact_mut`] mo te iterator taua engari tīmata i te mutunga o te wāhanga.
    ///
    /// # Panics
    ///
    /// Panics mena ko `chunk_size` te 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Ka tohatohahia te poro ki roto i te waahanga o te 'N`-huanga huānga, me te kii kaore he toenga.
    ///
    ///
    /// # Safety
    ///
    /// Ka karanga noa tenei i te wa
    /// - Ka wehe tika te poro ki roto i nga waahanga 'N`-element (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SAFETY: Ko nga waahanga 1-waahanga kaore i toe
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SAFETY: Ko te poro poroi (6) te maha o te 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Ko enei kaore e tau:
    /// // kia tamâraa: &[[_;5]]= slice.as_chunks_unchecked()//Ko te roanga poro kaore i te maha o nga waatea kia 5:&[[_;0]]= slice.as_chunks_unchecked()//Ko nga waahanga iti-roa-roa kaore e whakaaehia
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: Ko ta maatau tikanga koina te mea e hiahiatia ana kia karangahia tenei
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // HAUMARU: maka matou he wāhanga o huānga `new_len * N` ki
        // he poro o `new_len` maha nga waahanga o te `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Whakawehe te wāhanga ki te wāhanga o `huānga N`-huānga, tīmata i te timatanga o te pōro, me te wāhanga toenga ki tino iti iho i `N` roa.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko te `N` te 0. Ko tenei huringa ka huri pea ki te hapa wa whakahiato i mua i te whakatuturutanga o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SAFETY: Kua raru matou mo te kore, a ka whakarite ma te hangahanga
        // ko te roa o te waahanga he maha o te N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Whakawehe te wāhanga ki te wāhanga o `huānga N`-huānga, tīmata i te mutunga o te wāhanga, me te wāhanga toenga ki tino iti iho i `N` roa.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko te `N` te 0. Ko tenei huringa ka huri pea ki te hapa wa whakahiato i mua i te whakatuturutanga o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SAFETY: Kua raru matou mo te kore, a ka whakarite ma te hangahanga
        // ko te roa o te waahanga he maha o te N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Whakahokihia ai he miihini mo nga waahanga `N` o te poro i ia wa, ka tiimata i te tiimatanga o te poro.
    ///
    /// Ko nga waahanga he tohutoro whakatuu, kaore hoki e pararau.
    /// Mena kaore e wehewehe te `N` i te roa o te poro, ka tangohia nga mea whakamutunga tae atu ki te `N-1` ka taea te tango mai i te mahi `remainder` o te miihini.
    ///
    ///
    /// Tenei tikanga ko te ōrite kano const o [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics mena ko te `N` te 0. Ko tenei huringa ka huri pea ki te hapa wa whakahiato i mua i te whakatuturutanga o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Ka tohatohahia te poro ki roto i te waahanga o te 'N`-huanga huānga, me te kii kaore he toenga.
    ///
    ///
    /// # Safety
    ///
    /// Ka karanga noa tenei i te wa
    /// - Ka wehe tika te poro ki roto i nga waahanga 'N`-element (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SAFETY: Ko nga waahanga 1-waahanga kaore i toe
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SAFETY: Ko te poro poroi (6) te maha o te 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Ko enei kaore e tau:
    /// // tukua nga tapatapahi: &[[_;5]]= slice.as_chunks_unchecked_mut()//Ko te roanga poro kaore i te maha o nga waatea kia 5:&[[_;0]]= slice.as_chunks_unchecked_mut()//Ko nga waahanga iti-roa-roa kaore e whakaaehia
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: Ko ta maatau tikanga koina te mea e hiahiatia ana kia karangahia tenei
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // HAUMARU: maka matou he wāhanga o huānga `new_len * N` ki
        // he poro o `new_len` maha nga waahanga o te `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Whakawehe te wāhanga ki te wāhanga o `huānga N`-huānga, tīmata i te timatanga o te pōro, me te wāhanga toenga ki tino iti iho i `N` roa.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko te `N` te 0. Ko tenei huringa ka huri pea ki te hapa wa whakahiato i mua i te whakatuturutanga o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SAFETY: Kua raru matou mo te kore, a ka whakarite ma te hangahanga
        // ko te roa o te waahanga he maha o te N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Whakawehe te wāhanga ki te wāhanga o `huānga N`-huānga, tīmata i te mutunga o te wāhanga, me te wāhanga toenga ki tino iti iho i `N` roa.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko te `N` te 0. Ko tenei huringa ka huri pea ki te hapa wa whakahiato i mua i te whakatuturutanga o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SAFETY: Kua raru matou mo te kore, a ka whakarite ma te hangahanga
        // ko te roa o te waahanga he maha o te N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Whakahokihia ai he miihini mo nga waahanga `N` o te poro i ia wa, ka tiimata i te tiimatanga o te poro.
    ///
    /// Ko nga waahanga he tohu whakarereke whakariterite, kaore hoki e tarai.
    /// Mena kaore e wehea e `N` te roa o te poro, ka tangohia nga mea whakamutunga ki te `N-1` ka taea te tango mai i te mahi `into_remainder` o te miihini.
    ///
    ///
    /// Ko tenei tikanga ko te taurite o te [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics mena ko te `N` te 0. Ko tenei huringa ka huri pea ki te hapa wa whakahiato i mua i te whakatuturutanga o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Whakahokihia ai he miihini mo te taapiri windows o nga waahanga `N` o te poro, ka tiimata mai i te timatanga o te poro.
    ///
    ///
    /// Koinei te taurite o te [`windows`].
    ///
    /// Mena he nui ake te `N` i te rahi o te poro, ka hoki mai kaore windows.
    ///
    /// # Panics
    ///
    /// Panics mena ko `N` te 0.
    /// Tenei Taki ka tino pea kia puta ke ki te hapa wa whakahiato i mua i tenei tikanga ähuareka tangata.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Whakahokia te iterator mo `chunk_size` āhuatanga o te wāhanga i te wa, timata i te mutunga o te wāhanga.
    ///
    /// Ko nga tapatapahi he poro, kaore e taapiri.Mena kaore te `chunk_size` e wehewehe i te roa o te poro, ka kore te waaawa whakamutunga e whai `chunk_size` te roa.
    ///
    /// Tirohia te [`rchunks_exact`] mo te rereketanga o tenei miihini e whakahoki ana i nga waahanga o nga waahanga `chunk_size` i nga wa katoa, me te [`chunks`] mo taua mea ano engari ka tiimata i te tiimatanga o te poro.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko `chunk_size` te 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Whakahokia te iterator mo `chunk_size` āhuatanga o te wāhanga i te wa, timata i te mutunga o te wāhanga.
    ///
    /// He poro poro nga poro, a, kaua e inaki.Mena kaore te `chunk_size` e wehewehe i te roa o te poro, ka kore te waaawa whakamutunga e whai `chunk_size` te roa.
    ///
    /// Tirohia te [`rchunks_exact_mut`] mo te rereketanga o tenei miihini e whakahoki ana i nga waahanga o nga waahanga `chunk_size` i nga wa katoa, me te [`chunks_mut`] mo taua mea ano engari ka tiimata i te timatanga o te poro.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko `chunk_size` te 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Whakahokia te iterator mo `chunk_size` āhuatanga o te wāhanga i te wa, timata i te mutunga o te wāhanga.
    ///
    /// Ko nga tapatapahi he poro, kaore e taapiri.
    /// Ki te kore e `chunk_size` wehe i te roa o te wāhanga, ka te ake whakamutunga ki huānga `chunk_size-1` ka mahue a taea te tiki i te mahi `remainder` o te iterator.
    ///
    /// Na te mea ka rite tonu nga waahanga o te `chunk_size` ki ia waahanga, ka taea e te kaipupuri te whakarite kia pai ake te waehere ka puta ake i te keehi o [`chunks`].
    ///
    /// Tirohia te [`rchunks`] mo te rereketanga o tenei miihini ka whakahoki ano i te toenga hei waahanga iti ake, me te [`chunks_exact`] mo te taatai kotahi engari ka tiimata i te timatanga o te poro.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko `chunk_size` te 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Whakahokia te iterator mo `chunk_size` āhuatanga o te wāhanga i te wa, timata i te mutunga o te wāhanga.
    ///
    /// He poro poro nga poro, a, kaua e inaki.
    /// Mena kaore e wehewehe te `chunk_size` i te roa o te poro, ka tangohia nga mea whakamutunga tae atu ki te `chunk_size-1` ka taea te tango mai i te mahi `into_remainder` o te miihini.
    ///
    /// Na te mea ka rite tonu nga waahanga o te `chunk_size` ki ia waahanga, ka taea e te kaipupuri te whakarite kia pai ake te waehere ka puta ake i te keehi o [`chunks_mut`].
    ///
    /// Tirohia te [`rchunks_mut`] mo te rereketanga o tenei miihini ka whakahoki ano i te toenga hei waahanga iti ake, me te [`chunks_exact_mut`] mo te taatai kotahi engari ka tiimata i te timatanga o te poro.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko `chunk_size` te 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Whakahokihia ai he miihini ki runga i te poro e whakaputa ana i nga waahanga huakore-kore e whakamahi ana i te tohu ki te wehe.
    ///
    /// E rua nga waahanga e karangahia ana te predicate e whai ana i a raatau ano, ko te tikanga ko te tohu i te `slice[0]` me te `slice[1]` ka tae ki te `slice[1]` me te `slice[2]` me te aha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ka taea te whakamahi i tenei tikanga ki te tango i nga waahanga kua tohatohahia:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Whakahokihia ai he miihini ki runga i te waahanga e whakaputa ana i nga waahanga koretake o te waahanga e whakamahi ana i te tohu ki te wehe.
    ///
    /// E rua nga waahanga e karangahia ana te predicate e whai ana i a raatau ano, ko te tikanga ko te tohu i te `slice[0]` me te `slice[1]` ka tae ki te `slice[1]` me te `slice[2]` me te aha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ka taea te whakamahi i tenei tikanga ki te tango i nga waahanga kua tohatohahia:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Wehea tetahi waahanga ki te rua i te tohu.
    ///
    /// Ko te mea tuatahi ka uru katoa nga tuhinga mai i te `[0, mid)` (haunga te taurangi `mid` ano) me te tuarua ka whakaatu nga tohu katoa mai i te `[mid, len)` (haunga te taurangi `len` ano).
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` me `[mid; len]` kei roto `self`, nei
        // whakatutuki ana i nga whakaritenga o `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Wehewehe ai i tetahi waahanga huri ki te rua i te taupū.
    ///
    /// Ko te mea tuatahi ka uru katoa nga tuhinga mai i te `[0, mid)` (haunga te taurangi `mid` ano) me te tuarua ka whakaatu nga tohu katoa mai i te `[mid, len)` (haunga te taurangi `len` ano).
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` me `[mid; len]` kei roto `self`, nei
        // whakatutuki ana i nga whakaritenga o `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Wehea tetahi waahanga ki te rua i te taurangi, kaore he tohu rohe.
    ///
    /// Ko te mea tuatahi ka uru katoa nga tuhinga mai i te `[0, mid)` (haunga te taurangi `mid` ano) me te tuarua ka whakaatu nga tohu katoa mai i te `[mid, len)` (haunga te taurangi `len` ano).
    ///
    ///
    /// Mo tetahi atu huarahi haumaru tirohia te [`split_at`].
    ///
    /// # Safety
    ///
    /// Ko te waeatanga i tenei tikanga me te taupū-i-rohe ko te *[whanonga kore tautuhi]* ahakoa kaore e whakamahia te tohutoro hua.He ki whakarite e `0 <= mid <= self.len()` te kaiwaea.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // HAUMARU: Kaiwaea kua ki te tirohia e `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Ka wehewehe i tetahi waahanga huri ki te rua i te taurangi, me te kore e tirotiro i nga rohe.
    ///
    /// Ko te mea tuatahi ka uru katoa nga tuhinga mai i te `[0, mid)` (haunga te taurangi `mid` ano) me te tuarua ka whakaatu nga tohu katoa mai i te `[mid, len)` (haunga te taurangi `len` ano).
    ///
    ///
    /// Mo tetahi atu huarahi haumaru tirohia te [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Ko te waeatanga i tenei tikanga me te taupū-i-rohe ko te *[whanonga kore tautuhi]* ahakoa kaore e whakamahia te tohutoro hua.He ki whakarite e `0 <= mid <= self.len()` te kaiwaea.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SAFETY: Me tirohia e te Kaiwaea te `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` a ko `[mid; len]` kaore i te taapiri, na te whakahoki i te tohutoro rereke ka pai.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Whakahokihia ai he miihini mo nga waahanga kua wehea e nga waahanga e rite ana ki te `pred`.
    /// Ko te waahanga e taurite ana kaore i roto i nga mokete.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ki te ki āu te huānga tuatahi ko, ka waiho he wāhanga kau te tūemi tuatahi hoki e te iterator.
    /// Waihoki, ki te ki āu te huānga whakamutunga i roto i te wāhanga e, ka waiho he wāhanga kau te tūemi whakamutunga hoki e te iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Mena e rua nga mea e taurite ana e piri tata ana, ka kitea tetahi waahanga kore i waenga i a raatau:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Returns he iterator mo subslices mutable wehea e ngā āhuatanga e ōrite `pred`.
    /// Ko te waahanga e taurite ana kaore i roto i nga mokete.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Whakahokihia ai he miihini mo nga waahanga kua wehea e nga waahanga e rite ana ki te `pred`.
    /// Ko te waahanga e taurite ana kei roto i te mutunga o te kaitono o mua hei whakamutu.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Mena ka haangai te waahanga whakamutunga o te poro, ka kiia tera waahanga ko te whakamutu o te poro o mua.
    ///
    /// Ko taua poroihi te mea whakamutunga ka whakahokia mai e te kaitahuri.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Returns he iterator mo subslices mutable wehea e ngā āhuatanga e ōrite `pred`.
    /// Ko te waahanga e taurite ana kei roto i te waahanga o mua hei whakamutu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Whakahokihia he miihini mo nga waahanga kua wehea e nga waahanga e rite ana ki te `pred`, ka tiimata i te pito o te poro ka mahi whakamuri.
    /// Ko te waahanga e taurite ana kaore i roto i nga mokete.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ka rite ki te `split()`, mena ka haangai te waahanga tuatahi, o muri ranei, ko te poroakore te waahanga tuatahi (muri ranei) ka whakahokia mai e te kaitahuri.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Whakahokihia ai he miihini mo nga waahanga iti ka taea te wehe e nga waahanga e rite ana ki te `pred`, ka tiimata i te pito o te poro ka mahi whakamuri.
    /// Ko te waahanga e taurite ana kaore i roto i nga mokete.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Whakahokihia ai he miihini mo nga waahanga kua wehea e nga waahanga e rite ana ki te `pred`, he iti ki te whakahoki mai i te nuinga o nga taonga `n`.
    /// Ko te waahanga e taurite ana kaore i roto i nga mokete.
    ///
    /// Ko te mea timatanga whakamutunga i whakahokia mai, mena ana, kei roto nga toenga o te poro.
    ///
    /// # Examples
    ///
    /// Taatahia te waahanga i tohatoha kia kotahi ma nga tau e mawehe ana ki te 3 (arā, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Whakahokihia ai he miihini mo nga waahanga kua wehea e nga waahanga e rite ana ki te `pred`, he iti ki te whakahoki mai i te nuinga o nga taonga `n`.
    /// Ko te waahanga e taurite ana kaore i roto i nga mokete.
    ///
    /// Ko te mea timatanga whakamutunga i whakahokia mai, mena ana, kei roto nga toenga o te poro.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Whakahokihia ai he miihini mo nga waahanga kua wehea e nga waahanga e rite ana ki te `pred` he iti ki te whakahoki mai i te nuinga o nga taonga `n`.
    /// Ka tiimata tenei i te mutunga o te poro ka anga whakamuri.
    /// Ko te waahanga e taurite ana kaore i roto i nga mokete.
    ///
    /// Ko te mea timatanga whakamutunga i whakahokia mai, mena ana, kei roto nga toenga o te poro.
    ///
    /// # Examples
    ///
    /// Kotahi te taarua poro i te waahanga, tiimata mai i te pito, ma nga tau e wehea ana e te 3 (arā, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Whakahokihia ai he miihini mo nga waahanga kua wehea e nga waahanga e rite ana ki te `pred` he iti ki te whakahoki mai i te nuinga o nga taonga `n`.
    /// Ka tiimata tenei i te mutunga o te poro ka anga whakamuri.
    /// Ko te waahanga e taurite ana kaore i roto i nga mokete.
    ///
    /// Ko te mea timatanga whakamutunga i whakahokia mai, mena ana, kei roto nga toenga o te poro.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Whakahoki ai i te `true` mena kei roto i te poro tetahi waahanga me te uara kua whakaritea.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Mena kaore o `&T`, engari he `&U` noa tera `T: Borrow<U>` (hei tauira
    /// `Takai: Taarua<str>`), ka taea e koe te whakamahi i te `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // Tuhinga o mua
    /// assert!(v.iter().any(|e| e == "hello")); // rapu ki `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Whakahoki `true` mena ko `needle` te kuhimua o te poro.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// hoki i ngā wā katoa `true` ki he `needle` he wāhanga kau:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Whakahoki mai ai i te `true` mena ko te `needle` he mapi o te poro.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// hoki i ngā wā katoa `true` ki he `needle` he wāhanga kau:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Whakahoki ai i tetahi waahanga me te kuhimua kua tangohia.
    ///
    /// Mena ka tiimata te poroi ki te `prefix`, whakahokia te waahanga i muri i te kuhimua, ka takaia ki te `Some`.
    /// Ki te he kau `prefix`, hoki noa te wāhanga taketake.
    ///
    /// Mena kaore te waahanga e tiimata ki te `prefix`, whakahokia mai a `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ko tenei mahi ka hiahia ki te tuhi mena ka mena ka uaua ake a SlicePattern.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Whakahoki ai i te taaramatanga, ka tangohia te whakakapi.
    ///
    /// Mena ka mutu te poroi ki te `suffix`, whakahokia te waahanga mo mua i te whakakapi, ka takaia ki te `Some`.
    /// Mena he koretake te `suffix`, whakahokia noa te poro taketake.
    ///
    /// Mena kaore e mutu te poro ki te `suffix`, whakahokia te `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ko tenei mahi ka hiahia ki te tuhi mena ka mena ka uaua ake a SlicePattern.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// e rapu ana-rua tenei wāhanga kōmaka hoki te huānga i homai.
    ///
    /// Mena kua kitea te uara ka whakahokia mai te [`Result::Ok`], kei roto te taurangi o te waahanga e taurite ana.
    /// Mena he maha nga whakataetae, ka taea te whakahoki mai i tetahi o nga whakataetae.
    /// Mena kaore i kitea te uara katahi ka whakahokia mai te [`Result::Err`], kei roto te taurangi e taea ai te whakauru i tetahi waahanga taapiri kia mau tonu te raupapa.
    ///
    ///
    /// Tirohia hoki [`binary_search_by`], [`binary_search_by_key`], me [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Tirohia te raupapa o nga waahanga e wha.
    /// Ko te tuatahi ka kitea, me te tuunga motuhake kua whakatauhia;te tuarua me te tuatoru e kore e kitea;te tuawha ka taea te whakarite i tetahi tuunga i te `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Mena kei te hiahia koe ki te whakauru i tetahi taonga ki te vector kua tohua, i te wa e pupuri ana i te ota raupapa:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// rapu ā-rua kōmaka tenei te wāhanga ki te mahi comparator.
    ///
    /// kia whakatinana i te mahi comparator he tikanga e hāngai ana ki te raupapa ahua o te wāhanga e whāriki ana, hoki mai he waehere kia e tohu ranei i tona tautohe ko `Less`, `Equal` ranei `Greater` te ūnga e hiahiatia ana.
    ///
    ///
    /// Mena kua kitea te uara ka whakahokia mai te [`Result::Ok`], kei roto te taurangi o te waahanga e taurite ana.Mena he maha nga whakataetae, ka taea te whakahoki mai i tetahi o nga whakataetae.
    /// Mena kaore i kitea te uara katahi ka whakahokia mai te [`Result::Err`], kei roto te taurangi e taea ai te whakauru i tetahi waahanga taapiri kia mau tonu te raupapa.
    ///
    /// Tirohia hoki [`binary_search`], [`binary_search_by_key`], me [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Tirohia te raupapa o nga waahanga e wha.Ko te te kitea tuatahi, ki te tūranga ahurei fakapapau'i;te tuarua me te tuatoru e kore e kitea;te tuawha ka taea te whakarite i tetahi tuunga i te `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SAFETY: kua ora te karanga a nga kai-tono e whai ake nei:
            // - `mid >= 0`
            // - `mid < size`: `mid` he iti na `[left; right)` herea.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Ko te take ka whakamahi maatau i te rerenga whakahaere if/else kaore i te taatai na te mea ka whakatika ano nga mahi whakataurite whakariterite, he mea ngawari.
            //
            // Ko te x86 asm tenei mo u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Ka rapu a Binary i tenei waahanga kua tohatohahia me te mahi tangohanga matua.
    ///
    /// Ki te whakaaro ko te waahanga ka tohatohahia e te matua, hei tauira me te [`sort_by_key`] e whakamahi ana i taua mahi tangohanga matua.
    ///
    /// Mena kua kitea te uara ka whakahokia mai te [`Result::Ok`], kei roto te taurangi o te waahanga e taurite ana.
    /// Mena he maha nga whakataetae, ka taea te whakahoki mai i tetahi o nga whakataetae.
    /// Mena kaore i kitea te uara katahi ka whakahokia mai te [`Result::Err`], kei roto te taurangi e taea ai te whakauru i tetahi waahanga taapiri kia mau tonu te raupapa.
    ///
    ///
    /// Tirohia hoki [`binary_search`], [`binary_search_by`], me [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Tirohia te raupapa o nga waahanga e wha i roto i te waahanga takirua i tohaina e nga waahanga tuarua.
    /// Ko te tuatahi ka kitea, me te tuunga motuhake kua whakatauhia;te tuarua me te tuatoru e kore e kitea;te tuawha ka taea te whakarite i tetahi tuunga i te `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // whakaaetia Lint rustdoc::broken_intra_doc_links te rite `slice::sort_by_key` kei roto crate `alloc`, a rite taua e kore te vai ano ina hanga `core`.
    //
    // hononga ki te Z0crate0 whakararo: #74481.Mai i te mea ko nga korero tuatahi ka tuhia noa ki te libstd (#73423), kaore tenei e tau ki nga hononga pakaru i roto i nga mahi.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Ka tohatohahia te poro, engari kaore pea e tiakina te raupapa o nga waahanga rite.
    ///
    /// Kaore i te pumau tenei momo (ara, ka taea te whakariterite ano i nga waahanga rite), i te waahi (ara, kaore e tohaina), me *O*(*n*\*log(* n*)) tino kino.
    ///
    /// # Te whakatinanatanga o tenei wa
    ///
    /// Ko te algorithm o naianei e hangai ana ki te [pattern-defeating quicksort][pdqsort] na Orson Peters, e hono ana i te keehi toharite tere o te tere tere me te keehi tino kino rawa o te puranga, i te wa e tutuki ana te waa ki nga poro me etahi tauira.
    /// Ka whakamahia te matapōkere kia kore ai e heke nga keehi, engari me te seed kua whakaritea kia mau tonu te whanonga whakatau.
    ///
    /// He tere ake i te tohatoha pumau, haunga ia mo etahi keehi motuhake, hei tauira, i te waahanga o te waahanga waahanga whakariterite whakariterite.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Ka kōmaka te wāhanga ki te mahi comparator, engari e kore e kia tupu te tikanga o ngā huānga rite.
    ///
    /// Kaore i te pumau tenei momo (ara, ka taea te whakariterite ano i nga waahanga rite), i te waahi (ara, kaore e tohaina), me *O*(*n*\*log(* n*)) tino kino.
    ///
    /// Ko te mahi whakataurite me tautuhi i te ota katoa mo nga waahanga o te poro.Mena kaore i te katoa te ota, kaore i te tohua te ota o nga waahanga.Ko te ota he ota katoa mena (mo te `a` katoa, `b` me `c`):
    ///
    /// * katoa, me te antisymmetric: he pono rite tetahi o `a < b`, `a == b` `a > b` ranei, me
    /// * whakawhiti, `a < b` me `b < c` e tohu ana i te `a < c`.Te mau roa taua mo e rua `==` me `>`.
    ///
    /// Hei tauira, ahakoa kaore te [`f64`] e whakatinana i te [`Ord`] na te mea `NaN != NaN`, ka taea e taatau te whakamahi i te `partial_cmp` hei mahi wehe ina mohio ana taatau kaore i te `NaN` tetahi poro.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Te whakatinanatanga o tenei wa
    ///
    /// Ko te algorithm o naianei e hangai ana ki te [pattern-defeating quicksort][pdqsort] na Orson Peters, e hono ana i te keehi toharite tere o te tere tere me te keehi tino kino rawa o te puranga, i te wa e tutuki ana te waa ki nga poro me etahi tauira.
    /// Ka whakamahia te matapōkere kia kore ai e heke nga keehi, engari me te seed kua whakaritea kia mau tonu te whanonga whakatau.
    ///
    /// He tere ake i te tohatoha pumau, haunga ia mo etahi keehi motuhake, hei tauira, i te waahanga o te waahanga waahanga whakariterite whakariterite.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // whakatikatika whakamuri
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Ka whakararangihia te poro me te mahi tangohanga matua, engari kaore pea e tiakina te raupapa o nga waahanga rite.
    ///
    /// Kaore i te pumau tenei momo (ara, ka taea te whakariterite ano i nga waahanga rite), i te waahi (ara, kaore e tohaina), me te *O*(m\* * n *\* log(*n*)) tino kino, kei reira te mahi matua *O*(*m*).
    ///
    /// # Te whakatinanatanga o tenei wa
    ///
    /// Ko te algorithm o naianei e hangai ana ki te [pattern-defeating quicksort][pdqsort] na Orson Peters, e hono ana i te keehi toharite tere o te tere tere me te keehi tino kino rawa o te puranga, i te wa e tutuki ana te waa ki nga poro me etahi tauira.
    /// Ka whakamahia te matapōkere kia kore ai e heke nga keehi, engari me te seed kua whakaritea kia mau tonu te whanonga whakatau.
    ///
    /// Na tana rautaki karanga matua, ko te [`sort_unstable_by_key`](#method.sort_unstable_by_key) ka iti ake pea i te [`sort_by_cached_key`](#method.sort_by_cached_key) i nga keehi he utu nui te mahi matua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Whakaritehia te waahanga kia rite ai te waahanga i te `index` kei te waahanga whakamutunga.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Whakaritehia te poro me te mahi whakataurite kia rite ki te waahanga o te `index` kei te waahanga whakamutunga.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Raupapa anō i te wāhanga ki te mahi matua tangohanga pērā e te huānga i `index` ko i tona tūnga whakamutunga Kōmaka.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Whakaritehia te waahanga kia rite ai te waahanga i te `index` kei te waahanga whakamutunga.
    ///
    /// Ko tenei whakarereketanga he taonga taapiri ano ko nga uara i te tuunga `i < index` ka iti iho i te orite ranei ki nga uara katoa i te tuunga `j > index`.
    /// Hei taapiri, ko tenei whakariterite kaore i te pumau (ie
    /// ahakoa ko tehea o nga huanga rite ka mutu i te turanga `index`), i te waahi (ara
    /// kaore e tohatoha), me te *O*(*n*) keehi kino rawa.
    /// Ko te hoki tenei mahi/mohiotia rite "kth element" i te tahi atu whare pukapuka.
    /// Ka whakahokia mai e ia te toru o nga uara e whai ake nei: ko nga waahanga katoa he iti ake i te kotahi i te taupū i homai, ko te uara kei te taurangi kua tohua, me nga waahanga katoa e rahi ake ana i te tohu e hoatu ana.
    ///
    ///
    /// # Te whakatinanatanga o tenei wa
    ///
    /// Ko te algorithm o naianei e hangai ana ki te waahanga kowhiriwhiri o taua algorithm tere ano i whakamahia mo te [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ka `index >= len()`, te tikanga he panics tonu i runga i nga poro kau.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Rapua te tau waenga
    /// v.select_nth_unstable(2);
    ///
    /// // Ka whakamanahia noa iho maatau ko te waahanga tetahi o enei e whai ake nei, i runga i ta maatau waahanga mo te taurangi kua tohua.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Whakaritehia te poro me te mahi whakataurite kia rite ki te waahanga o te `index` kei te waahanga whakamutunga.
    ///
    /// Ko tenei whakarereketanga he taonga taapiri ano ko te uara i te tuunga `i < index` ka iti iho i te orite ranei ki tetahi uara i te tuunga `j > index` ma te whakamahi i te mahi whakataurite.
    /// Hei taapiri, ko tenei whakariterite kaore i te pumau (ara ko nga waahanga rite tonu ka mutu i te waahi `index`), i te waahi (ara kaore e tohaina), me te *O*(*n*) tino kino rawa atu.
    /// Ko tenei mahi e mohiotia ana ko "kth element" i etahi atu whare pukapuka.
    /// hoki te reira i te triplet o te uara e whai ake nei: ngā huānga katoa iti iho i te kotahi i te taupū hoatu, te uara i te taupū hoatu, me ngā āhuatanga katoa nui atu i te kotahi i te taupū hoatu, te whakamahi i te mahi comparator whakaratohia.
    ///
    ///
    /// # Te whakatinanatanga o tenei wa
    ///
    /// Ko te algorithm o naianei e hangai ana ki te waahanga kowhiriwhiri o taua algorithm tere ano i whakamahia mo te [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ka `index >= len()`, te tikanga he panics tonu i runga i nga poro kau.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Kimihia te tau waenga, me te mea te wāhanga i kōmaka i roto i te heke te raupapa.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Ka whakamanahia noa iho maatau ko te waahanga tetahi o enei e whai ake nei, i runga i ta maatau waahanga mo te taurangi kua tohua.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Raupapa anō i te wāhanga ki te mahi matua tangohanga pērā e te huānga i `index` ko i tona tūnga whakamutunga Kōmaka.
    ///
    /// Ko tenei whakarereketanga he taonga taapiri ano ko te uara i te tuunga `i < index` ka iti iho i te orite ranei ki tetahi uara i te tuunga `j > index` ma te whakamahi i te mahi tangohanga matua.
    /// Hei taapiri, ko tenei whakariterite kaore i te pumau (ara ko nga waahanga rite tonu ka mutu i te waahi `index`), i te waahi (ara kaore e tohaina), me te *O*(*n*) tino kino rawa atu.
    /// Ko tenei mahi e mohiotia ana ko "kth element" i etahi atu whare pukapuka.
    /// Ka whakahokia mai e ia te toru o nga uara e whai ake nei: ko nga waahanga katoa he iti ake i te waahanga o te taupū, te uara kei te taurangi kua tohua, me nga waahanga katoa e rahi ake ana i te tauanga kua tohua, ma te whakamahi i te mahi tangohanga matua.
    ///
    ///
    /// # Te whakatinanatanga o tenei wa
    ///
    /// Ko te algorithm o naianei e hangai ana ki te waahanga kowhiriwhiri o taua algorithm tere ano i whakamahia mo te [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ka `index >= len()`, te tikanga he panics tonu i runga i nga poro kau.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Whakahokihia te waenga waenga me te mea he mea wehe te raupapa ki te uara tino.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Ka whakamanahia noa iho maatau ko te waahanga tetahi o enei e whai ake nei, i runga i ta maatau waahanga mo te taurangi kua tohua.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Ka nukuhia nga waahanga panui katoa ki te pito o te poro kia rite ki te mahinga [`PartialEq`] trait.
    ///
    ///
    /// Whakahokia ai e rua nga poro.Ko te mea tuatahi kaore he timatanga o nga korero timatanga.
    /// Kei te tuarua ko nga taarua katoa kaore i te ota kua tau.
    ///
    /// Ki te kōmaka te wāhanga kei te, kei te wāhanga hoki tuatahi kahore he tārua.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Ka neke katoa engari ko te tuatahi o nga mea timatanga ki te mutunga o te poro e makona ana i te whanaungatanga taurite kua hoatu.
    ///
    /// Whakahokia ai e rua nga poro.Ko te mea tuatahi kaore he timatanga o nga korero timatanga.
    /// Kei te tuarua ko nga taarua katoa kaore i te ota kua tau.
    ///
    /// Ko te mahinga `same_bucket` ka tukuna he tohutoro ki nga waahanga e rua mai i te poro, me whakatau mena ka whakataurite nga waahanga.
    /// Ko nga waahanga ka tukuna i te ritenga ke mai i te raupapa i te poro, no reira mena ka whakahokia mai e `same_bucket(a, b)` te `true`, ka nekehia te `a` i te pito o te poro.
    ///
    ///
    /// Ki te kōmaka te wāhanga kei te, kei te wāhanga hoki tuatahi kahore he tārua.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Ahakoa he pai te korero mo `self`, kaore e taea te whakarereke *taapiri*.taea te waea `same_bucket` panic, pera ti'a ia tatou ia whakarite kia ko te wāhanga i roto i te āhua tika i nga wa katoa.
        //
        // Ko te huarahi e hapai ai taatau ma tenei, ma te huri swap;ka tirohia e maatau nga waahanga katoa, ka huri ke i a maatau e haere ana kia tae ki te mutunga ko nga mea e hiahia ana matou ki te pupuri kei mua, ko nga mea e hiahia ana matou ki te paopao kei muri.
        // Ka taea te wehe i te poro.
        // Ko tenei mahinga `O(n)` tonu.
        //
        // Tauira: Ka tiimata taatau i tenei ahuatanga, ka whakaatuhia e `r` "a muri ake
        // lau "ko `w` tohu" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Te whakatairite self[r] ki whaiaro [w-1], e kore te mea he tārite tenei, na hurihia tatou self[r] me self[w] (kahore pānga rite r==w) me ka nuku rua r me w, ka mahue ia matou ki:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ki te whakataurite i te self[r] ki a ia ano [w-1], he taarua tenei uara, na reira ka whakapikiu matou i te `r` engari me waiho nga mea katoa kia kaua e whakarereke:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ki te whakataurite i te self[r] ki a koe ano [w-1], ehara tenei i te mea taarua, na hurihia te self[r] me te self[w] ka haere ki mua r me te w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ehara i te tāruarua, tukurua:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Tārua, advance r. End o wāhanga.Wahia i w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SAFETY: ko te ahua `while` e tohu ana i te `next_read` me te `next_write`
        // he iti ake i te `len`, na kei roto ko te `self`.
        // `prev_ptr_write` ngā ki tetahi huānga te aroaro o `ptr_write`, engari tīmata `next_write` i 1, na te mea e kore iti `prev_ptr_write` i te 0 me te ko roto te wāhanga.
        // Ka whakatutukihia nga whakaritenga mo te whakakore i te `ptr_read`, `prev_ptr_write` me `ptr_write`, me te whakamahi i te `ptr.add(next_read)`, `ptr.add(next_write - 1)` me `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` he mea whakapiki hoki i te wa kotahi mo ia koropiko te tikanga kaore he kaupapa i hipa i te waa me huri ke.
        //
        // `ptr_read` me te `prev_ptr_write` kaore e tohu ki te kaupapa kotahi.E hiahiatia ana tenei kia haumaru a `&mut *ptr_read`, `&mut* prev_ptr_write`.
        // Ko te whakamaarama he pono tonu te `next_read >= next_write` i nga wa katoa, no reira he `next_read > next_write - 1` ano hoki.
        //
        //
        //
        //
        //
        unsafe {
            // Aukati i nga arowhai rohe ma te whakamahi i nga tohu tohu noa.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Ka neke katoa engari ko te tuatahi o nga mea timatanga ki te pito o te poro e whakatau ana ki te matua ano.
    ///
    ///
    /// Whakahokia ai e rua nga poro.Ko te mea tuatahi kaore he timatanga o nga korero timatanga.
    /// Kei te tuarua ko nga taarua katoa kaore i te ota kua tau.
    ///
    /// Ki te kōmaka te wāhanga kei te, kei te wāhanga hoki tuatahi kahore he tārua.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Tītaka te wāhanga i roto i-wahi taua e te āhuatanga tuatahi `mid` o te nekehanga wāhanga ki te mutunga i te neke nga āhuatanga `self.len() - mid` whakamutunga ki te mua.
    /// I muri i te karanga `rotate_left`, te huānga mua i te taupū `mid` ka riro te huānga tuatahi i roto i te wāhanga.
    ///
    /// # Panics
    ///
    /// Tenei mahi e panic ki te mea nui atu te roa o te wāhanga `mid`.Kia mahara ko te `mid == self.len()` he _not_ panic a he hurihanga no-op.
    ///
    /// # Complexity
    ///
    /// Ka noho raina (i te waa `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Te hurihuri reanga
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SAFETY: Ko te awhe `[p.add(mid) - mid, p.add(mid) + k)` he iti noa
        // he tika mo te panui me te tuhi, e hiahiatia ana e `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Tītaka te wāhanga i roto i-wahi taua e te āhuatanga tuatahi `self.len() - k` o te nekehanga wāhanga ki te mutunga i te neke nga āhuatanga `k` whakamutunga ki te mua.
    /// I muri i te karanga `rotate_right`, ko te waahanga o mua i te taupū `self.len() - k` ka waiho hei waahanga tuatahi i te poro.
    ///
    /// # Panics
    ///
    /// Ma tenei mahi e panic mena he nui ake te `k` i te roa o te poro.Note e te `k == self.len()` _not_ panic me he he hurihanga kahore-op.
    ///
    /// # Complexity
    ///
    /// Ka noho raina (i te waa `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Tītaka he subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SAFETY: Ko te awhe `[p.add(mid) - mid, p.add(mid) + k)` he iti noa
        // he tika mo te panui me te tuhi, e hiahiatia ana e `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Whakakiihia te `self` me nga huanga ma te whakakii i te `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Whakakihia te `self` me nga waahanga i whakahokia mai ma te piiraa i tetahi katinga i nga wa katoa.
    ///
    /// Whakamahia ai i tēnei aratuka he katinga ki te waihanga uara hou.Mena he pai ake ki a koe te [`Clone`] i tetahi uara, whakamahia [`fill`].
    /// Ki te hiahia koe ki te whakamahi i te [`Default`] trait ki te whakaputa ngā uara, ka taea e koe tika [`Default::default`] rite te tautohe.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Ka kape i nga waahanga mai i te `src` ki te `self`.
    ///
    /// Me te taua rite `self` te roa o `src`.
    ///
    /// Mena ka whakamahia e `T` te `Copy`, ka kaha ake te whakamahi i te [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Tenei mahi ka panic ki te whai roa rerekē nga poro e rua.
    ///
    /// # Examples
    ///
    /// Te taarua i nga waahanga e rua mai i tetahi waahanga ki tetahi atu:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Na te mea kia rite te roa o nga poro, ka tapahia e maatau te waahanga o te waahanga mai i nga waahanga e wha ki te rua.
    /// // Ka panic mena ka kore e penei ta maatau.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// E whakamana ana a Rust kotahi noa te tohutoro kaore e taea te whakarereke i tetahi waahanga korero i tetahi waahanga whanui.
    /// Na tenei, ko te ngana ki te whakamahi i te `clone_from_slice` i runga i te waahanga kotahi ka ngoikore te kohikohi:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ki te mahi a tawhio noa tenei, ka taea e tatou te whakamahi i [`split_at_mut`] ki te waihanga e rua motuhake iti-poro i te wāhanga:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Ka kape i nga waahanga katoa mai i te `src` ki te `self`, ma te whakamahi i te memcpy.
    ///
    /// Me te taua rite `self` te roa o `src`.
    ///
    /// Mena kaore te `T` e whakamahi i te `Copy`, whakamahia te [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Tenei mahi ka panic ki te whai roa rerekē nga poro e rua.
    ///
    /// # Examples
    ///
    /// E tāruatia ana e rua ngā huānga i te wāhanga ki tetahi:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Na te mea kia rite te roa o nga poro, ka tapahia e maatau te waahanga o te waahanga mai i nga waahanga e wha ki te rua.
    /// // Ka panic mena ka kore e penei ta maatau.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// E whakamana ana a Rust kotahi noa te tohutoro kaore e taea te whakarereke i tetahi waahanga korero i tetahi waahanga whanui.
    /// Na tenei, ko te ngana ki te whakamahi i te `copy_from_slice` i runga i te waahanga kotahi ka ngoikore te kohikohi:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ki te mahi a tawhio noa tenei, ka taea e tatou te whakamahi i [`split_at_mut`] ki te waihanga e rua motuhake iti-poro i te wāhanga:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Ko te ara waehere panic i whakauruhia ki tetahi mahi makariri kia kore e pupuhi i te pae karanga.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SAFETY: `self` he tika mo nga waahanga `self.len()` ma te whakamaarama, a `src` i tika
        // takina kia orite te roa.
        // E kore e taea e te poro te īnaki no te mea he motuhake tohutoro mutable.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Tārua huānga i tetahi wahi o te wāhanga ki tetahi atu wahi o ake, te whakamahi i te memmove.
    ///
    /// `src` ko te awhe kei roto i te `self` hei kape mai i.
    /// `dest` Ko te tohu tiimata o te awhe i roto i te `self` hei kape, ka rite te roa ki te `src`.
    /// kia īnaki te awhe e rua.
    /// Ko nga pito o nga awhe e rua me iti ake i te orite ki te `self.len()`.
    ///
    /// # Panics
    ///
    /// Ka panic tenei mahi mena ka neke atu te awhe i te mutunga o te poro, mena ko te mutunga o te `src` i mua o te tiimata.
    ///
    ///
    /// # Examples
    ///
    /// Te kape i nga paita e wha i roto i te poro:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SAFETY: nga tikanga mo te `ptr::copy` kua tirohia katoa i runga ake nei,
        // pera me era mo `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Hurihia nga waahanga katoa i te `self` me era i te `other`.
    ///
    /// Me te taua rite `self` te roa o `other`.
    ///
    /// # Panics
    ///
    /// Tenei mahi ka panic ki te whai roa rerekē nga poro e rua.
    ///
    /// # Example
    ///
    /// Te huri i nga waahanga e rua puta noa i nga poro:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// whakaū Rust e reira e taea anake e kotahi tohutoro mutable ki te wahi ngā o ngā raraunga i roto i te hōkai ngā.
    ///
    /// Na tenei, ko te ngana ki te whakamahi i te `swap_with_slice` i runga i te waahanga kotahi ka ngoikore te kohikohi:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Hei mahi i tenei, ka taea e taatau te whakamahi i te [`split_at_mut`] ki te hanga e rua nga waahanga iti-rereke rereke mai i te waahanga:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SAFETY: `self` he tika mo nga waahanga `self.len()` ma te whakamaarama, a `src` i tika
        // takina kia orite te roa.
        // E kore e taea e te poro te īnaki no te mea he motuhake tohutoro mutable.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Taumahi ki te tatau i te roa o te waahanga waenga me te poro mo te `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Aha ka whaikupu mahi matou e pā ana ki `rest` he ahua i roto i te mea maha o `U`s taea tatou te hoatu i roto i te maha i raro o`T`s.
        //
        // E hia nga `T e hiahiatia ana mo ia "multiple".
        //
        // A feruri no te tauira T=u8 U=u16.Na e taea tatou te hoatu 1 U i roto i te 2 TS.Māmā.
        // Na, whakaarohia hei tauira keehi te rahi_o: :<T>=16, rahi_o::<U>=24.</u>
        // Ka taea e taatau te whakanoho i a 2 Tatou ki te waahi mo ia 3 Ts i te waahanga `rest`.
        // He uaua ake.
        //
        // Tātai hei tatau:
        //
        // Tatou= lcm(size_of::<T>, size_of::<U>)/rahi_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/rahinga_o::</u><T>
        //
        // Roha ka maamaa:
        //
        // Tatou=rahi_o: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=rahinga_o::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // He waimarie na te mea he arotake-katoa tenei ... kaore he take o te mahi i konei!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // hātepe Stein's algorithm Me mahi tonu e tatou tenei `const fn` (ka hoki ki te algorithm hokinga mai mena ka mahi tatou) na te whakawhirinaki ki te llvm ki te tutuki i enei mea katoa…pai, kaore au i pai.
            //
            //

            // E tirohia `a` ko `b` ki hei uara kore-kore: SAFETY.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // tango i nga waahanga 2 katoa mai i te b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // takina `b` te ki hei kore-kore: SAFETY.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Ka mau ana i tenei maaramatanga, ka kitea e maatau nga `U` e taea ana e taatau!
        let us_len = self.len() / ts * us;
        // E hia hoki nga `T i roto i te poro tuaahu!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Ai ā te wāhanga ki te wāhanga o tetahi momo, te whakarite hāngaitanga o te momo tonu te.
    ///
    /// motumotuhia ana tēnei tikanga i te wāhanga ki toru poro motuhake: kuhimua, tika hāngai wāhanga waenganui o te momo hou, me te wāhanga pīmuri.
    /// Ma te tikanga e pai ai te poro waenga i te roa rawa atu mo tetahi momo me te waahanga whakauru, engari ko te mahi a to algorithm anake me whakawhirinaki ki tera, kaua ko tona tika.
    ///
    /// Ka ahei te whakahoki mai i nga raraunga whakauru katoa hei kuhimua, hei waahanga tuauri ranei.
    ///
    /// Kaore he tikanga o tenei tikanga ka kore te waahanga whakauru `T`, te waahanga whakaputa `U` ranei e rahi-rahi, ka hoki mai ano i te waahanga taketake me te kore e wehewehe tetahi mea.
    ///
    /// # Safety
    ///
    /// Ko te tikanga he `transmute` tenei mo nga mea timatanga o te poro waenga i whakahokia mai, no reira ko nga tohu katoa e pa ana ki te `transmute::<T, U>` e pa ana ki konei.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Kia mahara ko te nuinga o enei mahi ka arotake-i-te-te-waatea,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // kia pai te whakahaere i nga ZST, ara-kaua e rahurahu.
            return (self, &[], &[]);
        }

        // Tuatahi, tirohia he aha te waahanga ka wehehia e maatau te waahanga tuatahi me te waahanga tuarua.
        // He ngawari ki te ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETY: Tirohia te tikanga `align_to_mut` mo nga korero mo te haumaru taipitopito.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SAFETY: inaianei `rest` kua tino tuutika, no reira he pai te `from_raw_parts` o raro,
            // mai i te kaikaranga e kii ana ka taea e taatau te whakawhiti i te `T` ki te `U` ma te ahuru.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Ai ā te wāhanga ki te wāhanga o tetahi momo, te whakarite hāngaitanga o te momo tonu te.
    ///
    /// motumotuhia ana tēnei tikanga i te wāhanga ki toru poro motuhake: kuhimua, tika hāngai wāhanga waenganui o te momo hou, me te wāhanga pīmuri.
    /// Ma te tikanga e pai ai te poro waenga i te roa rawa atu mo tetahi momo me te waahanga whakauru, engari ko te mahi a to algorithm anake me whakawhirinaki ki tera, kaua ko tona tika.
    ///
    /// Ka ahei te whakahoki mai i nga raraunga whakauru katoa hei kuhimua, hei waahanga tuauri ranei.
    ///
    /// Kaore he tikanga o tenei tikanga ka kore te waahanga whakauru `T`, te waahanga whakaputa `U` ranei e rahi-rahi, ka hoki mai ano i te waahanga taketake me te kore e wehewehe tetahi mea.
    ///
    /// # Safety
    ///
    /// Ko te tikanga he `transmute` tenei mo nga mea timatanga o te poro waenga i whakahokia mai, no reira ko nga tohu katoa e pa ana ki te `transmute::<T, U>` e pa ana ki konei.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Kia mahara ko te nuinga o enei mahi ka arotake-i-te-te-waatea,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // kia pai te whakahaere i nga ZST, ara-kaua e rahurahu.
            return (self, &mut [], &mut []);
        }

        // Tuatahi, tirohia he aha te waahanga ka wehehia e maatau te waahanga tuatahi me te waahanga tuarua.
        // He ngawari ki te ptr.align_offset.
        let ptr = self.as_ptr();
        // HAUMARU: Tenei e whakarite tatou e whakamahi tatou atatohu hāngai hoki U mo te
        // okioki o te tikanga.Ka mahia tenei ma te tuku tohu ki te&[T] me te whakahāngai i te anga mo U.
        // `crate::ptr::align_offset` ka karangahia me te tohu tika me te tohu tika `ptr` (mai i te tohutoro ki te `self`) me te rahinga e rua pea te mana (mai i te waahanga mo U), e ngata ana i nga aukati haumaru.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // E kore e taea e tatou te whakamahi ano `rest` i muri i tenei, e e haafaufaa tona ingoakē `mut_ptr`!HAUMARU: kite kōrero hoki `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Arowhai ki te e kōmaka nga mea timatanga o tenei wāhanga.
    ///
    /// Koinei, mo ia waahanga `a` me tana waahanga `b` e whai ake nei, me mau tonu te `a <= b`.Ki te hua i te wāhanga rite kore ranei tetahi huānga, e hoki mai `true`.
    ///
    /// Note e ki ko `Self::Item` `PartialOrd` anake, engari e kore e `Ord`, titau te whakamāramatanga i runga e hoki tenei mahi `false` ki te kore e rite tetahi rua tūemi karapīpiti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Ka tirohia mena ka tohatohahia nga waahanga o tenei waahanga ma te whakamahi i te mahi whakataurite kua homai.
    ///
    /// Engari o te whakamahi i `PartialOrd::partial_cmp`, whakamahia e tenei mahi i te mahi i homai `compare` ki te whakatau i te tikanga o ngā huānga e rua.
    /// I tua atu i tera, he rite ki te [`is_sorted`];tirohia ana tuhinga mo etahi atu korero.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Ka tirohia mena ka tohatohahia nga waahanga o tenei waahanga ma te whakamahi i te mahi tangohanga matua.
    ///
    /// Engari ki te whakataurite tika i nga waahanga o te poro, ka whakataurite tenei mahi i nga ki o nga waahanga, kia rite ki ta `f` i whakatau ai.
    /// I tua atu i tera, he rite ki te [`is_sorted`];tirohia ana tuhinga mo etahi atu korero.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Whakahoki ai i te taurangi o te tohu wehewehe kia rite ki te tohu kua tohaina (te tohu o te waahanga tuatahi o te waahanga tuarua).
    ///
    /// Ko te waahanga ka kiia kia wawahihia kia rite ki nga tohu o mua.
    /// Ko te tikanga ko nga waahanga katoa e hoki pono ana te predicate i te timatanga o te poro me nga waahanga katoa e hoki teka ana te predicate kei te mutunga.
    ///
    /// Hei tauira, ko te [7, 15, 3, 5, 4, 12, 6] he waahanga i raro i te tohu x% 2!=0 (ko nga tau rereke katoa kei te timatanga, ahakoa i te mutunga).
    ///
    /// Mena kaore tenei waahanga i wehewehe, kaore te hua i whakahokia mai i tau mai mo te kore whai kiko, na te mea ko tenei tikanga e mahi ana i te momo rapu ruarua.
    ///
    /// A hi'o hoki [`binary_search`], [`binary_search_by`], ko [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SAFETY: Ka `left < right`, `left <= mid < right`.
            // No reira ka nui haere tonu te `left` ka heke tonu te `right`, ana kua tohua tetahi o raatau.I nga wa e rua ko te `left <= right` kua makona.Na, ki te `left < right` i roto i te taahiraa, makona `left <= right` te i roto i te taahiraa i muri mai.
            //
            // Na reira i te mea ko te `left != right`, ka pai te `0 <= left < right <= len` ana mena kua pai tenei keehi `0 <= mid < len`.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: E ti'a ia tatou ki te tapahi āta ratou ki te roa taua
        // ki te hanga i te reira māmā mo te mōhinuhinu ki elide rohe taki.
        // Engari na te mea kaore e taea te whakawhirinaki he tino mohio taatau mo te T: Tārua.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Ka waihangahia he poro poroakore.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Ka waihangahia he poro wairangi kau.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Ko nga tauira i roto i nga poro, i tenei wa, ka whakamahia noa e `strip_prefix` me `strip_suffix`.
/// I te wa future, ko te tumanako ka whakariterite te `core::str::Pattern` (i te wa e tuhi ana ka whakawhitingahia ki te `str`) ki nga poro, katahi ka whakakapia ka whakakorehia ranei tenei trait.
///
pub trait SlicePattern {
    /// Ko te momo waahanga o te poro e taurite ana.
    type Item;

    /// I tenei wa, ko nga kaihoko o `SlicePattern` e hiahia ana ki te poro.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}