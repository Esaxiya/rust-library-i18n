// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Ka hurihia te awhe `[mid-left, mid+right)` kia pai ai te huanga i `mid` hei waahanga tuatahi.Ka rite, ka huri i te waahanga `left` awhe ki te taha maui, `right` ranei ki te taha matau.
///
/// # Safety
///
/// Ko te awhe kua tau kia whai mana mo te paanui me te tuhi.
///
/// # Algorithm
///
/// Ka whakamahia te Huringa 1 mo nga uara iti o `left + right` mo te `T` nui ranei.
/// Ka nekehia nga waahanga ki o raatau tuunga whakamutunga i te waa ka tiimata mai i te `mid - left` ka anga whakamua ma te `right` kaupae modulo `left + right`, na te mea kotahi noa te waa e hiahiatia ana.
/// I te pae hopea, tae tatou hoki i `mid - left`.
/// Heoi, ki te kore ko `gcd(left + right, right)` te 1, ka takahia e nga kaupae o runga ake nga waahanga.
/// Hei tauira:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Waimarie, ko te maha o nga mea i hipa i runga i nga waahanga i waenga i nga waahanga kua oti te whakarite i nga wa katoa, na reira ka taea e taatau te whakarite i to taatau tiimata me te mahi i nga waahanga (ko te katoa o nga rauna ko te `gcd(left + right, right)` value).
///
/// Ko te hua mutunga ko e kua oti āhuatanga katoa kotahi me kotahi anake.
///
/// whakamahia Hātepe 2 te ki he nui `left + right` ko `min(left, right)` he nui iti ki te uru ki runga i te moka tāpae.
/// Ko nga mea `min(left, right)` ka taatatia ki runga i te pararai, ka tukuna te `memmove` ki etahi atu, a ko nga mea kei runga i te kaitautoko ka neke ano ki roto i te koha i tera taha o te takenga mai.
///
/// Hātepe e taea te vectorized faito te runga ake riro kotahi `left + right` nui nui.
/// Ko te Huringa 1 ka taea te tango ma te taatai me te mahi i nga waahanga maha i te wa kotahi, engari he iti rawa nga waahanga mo te toharite tae noa ki te `left + right` he nui, ana ko te keehi kino rawa o te rauna kotahi kei reira tonu.
/// Engari, korerotia hātepe 3 faaohipahia whakawhiti o ngā āhuatanga `min(left, right)` tae noa te raruraru tītaka iti mahue te.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// ka tupu `left < right` te Whitiwhiti i te maui hei utu.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. te raro hātepe e taea kore ki te kore e tirohia i enei take
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Huringa 1 Ko nga tohu tohu tohu tohu tohu ko te mahi toharite mo nga nekehanga tupurangi he pai ake i te waa tae atu ki te `left + right == 32`, engari ko te mahi tino kino ka pakaru tae atu ki te 16.
            // 24 i tohua hei whenua waenga.
            // Mena he nui ake te rahinga o te `T` i te 4 usize`s, he pai ake tenei algorithm ki etahi atu algorithm.
            //
            //
            let x = unsafe { mid.sub(left) };
            // timatanga o te rauna tuatahi
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` ka kitea i mua o te ringaringa ma te tatau i te `gcd(left + right, right)`, engari he tere ki te mahi i tetahi koropiko e tatau ana i te gcd hei paanga, ka mahi ai i te toenga o te waahanga
            //
            //
            let mut gcd = right;
            // e whakaatu ana nga tohu he tere ake te whakawhiti poto mo nga wa katoa, kaua ki te panui i tetahi wa poto, te kape whakamuri, ka tuhi ai i taua wa poto i te mutunga.
            // Ko te pea tenei e tika ana ki te meka e whakawhiti whakakapi temporaries ranei whakamahi kotahi anake wāhitau mahara i roto i te koropiko hei utu o hinaaro ki te whakahaere e rua.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // hei utu o incrementing `i` me ka arowhai ki te ko reira waho te rohe, tirohia tatou ki te e haere `i` waho nga rohe i runga i te nuku i muri.
                // Ka aukati tenei i nga takai tohu `usize` ranei.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // te mutunga o te rauna tuatahi
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // Me kia konei, ki te tenei herenga `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // whakaotihia te waahanga me etahi atu rauna
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ehara i te momo kore-rahi, no reira he pai ki te wehe i te rahi.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Huringa 2 Ko te `[T; 0]` kei konei kia maarama te whakatika tika mo T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Huringa 3 He huarahi ke ano mo te whakawhitiwhai ko te kimi ko tehea te whakamutunga o tenei algorithm ka huri, me te huri ki te whakamahi i taua waahanga whakamutunga kaore i te huri i nga waahanga tata penei i te mahi a tenei algorithm, engari he tere tonu tenei ara.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Hātepe 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}