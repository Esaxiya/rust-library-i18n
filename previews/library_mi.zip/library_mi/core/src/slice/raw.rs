//! Nga mahi koreutu hei hanga `&[T]` me `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Ka hangaia he poro mai i te tohu tohu me te roa.
///
/// Ko te tohenga `len` ko te maha o nga **huanga**, kaua ko te maha o nga paita.
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `data` me [valid] mo nga paanui mo `len * mem::size_of::<T>()` nga paita maha, ana me tika te whakariterite.Ko te tikanga tenei:
///
///     * Ko te whānuitanga o te whakamahara o tenei poro me uru ki roto i te ahanoa kotahi kua tohaina!
///       e kore e taea e poro awhe puta noa ahanoa tohaina maha.Tirohia te [below](#incorrect-usage) mo tetahi tauira he kei te kore e aro ki tenei.
///     * `data` Me kia kore whakakahore-a tiaro noa hoki poro kore-roa.
///     Ko tetahi take mo tenei ko te pai ake o te whakatakotoranga whakatakotoranga whakatakotoranga whakapae ka whakawhirinaki ki nga tohutoro (tae atu ki nga poro o te roa) kia haangai ana kia kaua e whakakorehia ki te wehewehe i etahi atu o nga raraunga.
///     Ka taea e koe te tiki i tetahi tohu tohu ka taea te whakamahi hei `data` mo nga poro-kore-roa te whakamahi i te [`NonNull::dangling()`].
///
/// * `data` Me tohu ki `len` piritahi uara tika arawhitia o momo `T`.
///
/// * Ko te whakamaharatanga kua tohua e te waahanga kua whakahokia mai kaua e whakarerekehia mo te roanga o te tau `'a`, haunga ko te `UnsafeCell`.
///
/// * Ko te kohinga katoa `len * mem::size_of::<T>()` o te poro kaua kia rahi ake i te `isize::MAX`.
///   Tirohia nga tuhinga ahuru o [`pointer::offset`].
///
/// # Caveat
///
/// Ko te oranga mo te waahanga kua whakahokia mai e mohiotia ana mai i tona whakamahinga.
/// Kia kore ai faaino kōpeka, ngā whakaaro ki te here i te ora ki ēnei pūtake ora he haumaru i roto i te horopaki, pērā i te taha o te whakarato i te pānga kaiawhina tango i te ora o te uara ope mo te wāhanga, i te tuhipoka mārama ranei.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // faaite mai i te wāhanga mo te huānga kotahi
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Whakamahi hē
///
/// Ko te mahi `join_slices` e whai ake nei ko **korekore** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Ko te whakapae i runga whakarite `fst` me `snd` e pātata, engari kia tonu kia roto ratou i roto i _different allocated objects_, i roto i nei take hanga tenei wāhanga he whanonga kāore.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ko `b` He rerekē ahanoa tohaina ...
///     let a = 42;
///     let b = 27;
///     // ... e kore nei pea e taapirihia atu ki te whakamaharatanga: |he |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Mahi te taumahinga taua rite [`from_raw_parts`], ki te kahore e hoki mai te wāhanga mutable te.
///
/// # Safety
///
/// koretautuhi Whanonga te ki te e takahia tetahi o nga tikanga e whai ake nei:
///
/// * `data` Me waiho [valid] hoki pānui e rua, me te tuhi hoki `len * mem::size_of::<T>()` maha paita, a me tika kia hāngai ai.Ko te tikanga tenei:
///
///     * Ko te whānuitanga o te whakamahara o tenei poro me uru ki roto i te ahanoa kotahi kua tohaina!
///       Kaore e taea e nga poro te toro atu ki nga taonga maha kua tohaina.
///     * `data` Me kia kore whakakahore-a tiaro noa hoki poro kore-roa.
///     Ko tetahi take mo tenei ko te pai ake o te whakatakotoranga whakatakotoranga whakatakotoranga whakapae ka whakawhirinaki ki nga tohutoro (tae atu ki nga poro o te roa) kia haangai ana kia kaua e whakakorehia ki te wehewehe i etahi atu o nga raraunga.
///
///     Ka taea e koe te tiki i tetahi tohu tohu ka taea te whakamahi hei `data` mo nga poro-kore-roa te whakamahi i te [`NonNull::dangling()`].
///
/// * `data` Me tohu ki `len` piritahi uara tika arawhitia o momo `T`.
///
/// * Ko te whakamaharatanga e tohua ana e te waahanga kua whakahokia mai kaua e uru ki tetahi atu tohu tohu (kaore i ahu mai i te uara whakahoki) mo te roanga o te tau `'a`.
///   E rua lau a e tapui whai Tuhituhi.
///
/// * Ko te kohinga katoa `len * mem::size_of::<T>()` o te poro kaua kia rahi ake i te `isize::MAX`.
///   Tirohia nga tuhinga ahuru o [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: me mau te kaikaranga i te kirimana ahuru mo te `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Ka huri i te tohutoro ki te T ki te poroanga o te roa 1 (kaore he kape)
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Ka huri i te tohutoro ki te T ki te poroanga o te roa 1 (kaore he kape)
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}