//! Composable whitiauau tukutahingakore.
//!
//! Mena ko te futures he uara hangarite, na he rererangi takahuri te rerenga.
//! Mena kua kitea e koe he kohinga koretake o tetahi momo, a me mahi koe i runga i nga waahanga o taua kohinga, ka tere rere koe ki te 'streams'.
//! He kaha te whakamahi i nga rerenga i roto i te waehere Rust takahuri wairangi, no reira me maarama ki a raatau.
//!
//! I mua i te whakamārama i atu, kia a korero e pā ana ki te āhua o te hanganga tenei kōwae te:
//!
//! # Organization
//!
//! Ko tenei waahanga he mea whakarite ma te momo:
//!
//! * [Traits] ko te waahanga nui: ko enei traits e whakaatu ana he aha nga momo awa me nga aha ka taea e koe ki a raatau.Ko te tikanga o enei traits e utu maka ana etahi wa ako anō ki.
//! * Ma nga mahi e whakarato etahi huarahi awhina hei hanga i etahi awa taketake.
//! * Ko maha Structs nga momo hoki o nga tikanga ngā i runga i traits o tenei kōwae.I te nuinga o te waa ka hiahia koe ki te tiro i te tikanga e hanga ana i te `struct`, kaua ki te `struct` ano.
//! Mo te roanga atu o nga korero mo te take, tirohia te '[Whakatinana i te Awa](#awa whakatinana)'.
//!
//! [Traits]: #traits
//!
//! Ko te reira!Kia keri tatou ki nga awa.
//!
//! # Stream
//!
//! Ko te ngakau, me te wairua o tenei kōwae ko te [`Stream`] trait.Ko te ahua o te [`Stream`] penei:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Rerekē `Iterator`, hanga `Stream` he wehewehe te tikanga [`poll_next`] i te mea whakamahia ina whakatinana i te `Stream`, me te tikanga (to-be-implemented) `next` i whakamahia te ka kai i te awa.
//!
//! Ko nga kaihoko o `Stream` anake me whakaaro ki te `next`, ka karangahia ana, ka whakahokia mai he future ka puta mai te `Option<Stream::Item>`.
//!
//! Ko te future i whakahokia mai e `next` ka whakaputa `Some(Item)` i nga wa katoa he huanga, ana kua pau katoa, ka whakaputa `None` hei tohu kua mutu te whaarua.
//! Ki te e tatari tatou ki runga ki te tahi mea tukutahingakore ki fakapapau, ka tatari i te future tae noa he rite ki te tukua ano te awa.
//!
//! Ka kowhiria nga awa takitahi ki te whakahoki ano, no reira te karanga ano i te `next` ka kore pea e tukuna mai te `Some(Item)` i etahi waa.
//!
//! whakamāramatanga tonu [`Stream`] 'o ngā he maha o te tahi atu tikanga rite te pai, engari he ratou tikanga taunoa, hanga i runga i te tihi o [`poll_next`], a kia whiwhi koe ratou mo te kore utu.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Te Whakatinana i te Awa
//!
//! Ko te hanga i to awa ake e rua nga waahanga: ko te hanga `struct` hei pupuri i te ahua o te awa, ka whakamahi i te [`Stream`] mo taua `struct`.
//!
//! Me hanga e tatou he awa ko `Counter` te nama mai i te `1` ki te `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Tuatahi, ko te struct:
//!
//! /// He awa kaute mai i te kotahi ki te rima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // e hiahia ana matou i to tatou tatau ki te tīmata i te kotahi, pera kia a tāpiri he tikanga new() ki te tauturu.
//! // Ehara tenei i te mea tino tika, engari he waatea.
//! // Kia mahara kua tiimata taatau i te `count` i te kore, ka kite taatau i te `poll_next()`'s whakatinanatanga i raro.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Na, ka whakamahia e matou te `Stream` mo to `Counter`:
//!
//! impl Stream for Counter {
//!     // ka waiho tatou tatau ki usize
//!     type Item = usize;
//!
//!     // poll_next() Ko te tikanga anake e hiahiatia ana
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Whakanuia taatau kaute.Ko tenei he aha tatou i tīmata i te kore.
//!         self.count += 1;
//!
//!         // Tirohia ki te kite, ki te ua tatou oti tatau e kore ranei.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Awa e * * mangere.Ko te tikanga ko te hanga noa i te awa kaore e _do_ katoa.Kaore he mea e tupu kia karanga ra koe `next`.
//! Ko te ētahi wā tenei he puna o te whakama, ina hanga he awa anake mo ona pānga taha.
//! Ka whakatupato mai te kaiwhakamaherehere mo tenei momo whanonga:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;