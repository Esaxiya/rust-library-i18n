use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// He atanga mō te pā ana ki iterators tukutahingakore.
///
/// Koinei te awa nui trait.
/// Mo etahi atu korero mo te kaupapa o nga awa, tirohia te [module-level documentation].
/// Ina koa, ka hiahia pea koe ki te mohio me pehea te [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Te momo tuemi i tukuna e te awa.
    type Item;

    /// Ngana ki te wahia i roto i te uara muri o tenei awa, rēhita i te mahi o nāianei mō te ohonga ki te kahore he wātea ano te uara, me hoki mai `None` ki he ruha te awa.
    ///
    /// # uara Hoki
    ///
    /// He maha ngā uara hoki ka taea, ia tohu i te āhua awa motuhake:
    ///
    /// - `Poll::Pending` te tikanga kaore ano kia reri te uara o muri mai.Ka whakarite implementations e ka whakamōhiotia te mahi o nāianei kia ai ina kia rite te uara i muri.
    ///
    /// - `Poll::Ready(Some(val))` te tikanga kua pai te whakaputa a te roma i tetahi uara, `val`, a ka whakaputa pea i etahi atu uara i runga i nga waeatanga `poll_next` o muri mai.
    ///
    /// - `Poll::Ready(None)` tikanga e kua poroa te awa, a kahore e, e maharatia a ano `poll_next`.
    ///
    /// # Panics
    ///
    /// Ka mutu ana te awa (ka hoki mai a `Ready(None)` from `poll_next`), ka karanga ano i tana tikanga `poll_next` kia panic, ka aukati mo ake tonu atu, ka mahi ranei i etahi atu momo raru; kaore te `Stream` trait e hiahia ki nga paanga o taua piiraa.
    ///
    /// Heoi, na te mea kaore i te tohua te tikanga `poll_next` `unsafe`, ka whai ture a Rust: kaore nga piiraa e whakatau i nga whanonga kore (he maumahara, he pohehe i nga mahi `unsafe`, he aha ranei), ahakoa te ahua o te awa.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Whakahokia te rohe i runga i te roa o te awa e toe ana.
    ///
    /// Ina koa, ka whakahoki mai a `size_hint()` i tetahi tuple kei reira te waahanga tuatahi ko te roopu o raro, a ko te waahanga tuarua ko te roopu o runga.
    ///
    /// Ko te hawhe tuarua o te tuple hoki e te ko te [`Option`]`<`[`usize`] `>`.
    /// He [`None`] konei tikanga e rānei reira te kore mohiotia o runga herea, ranei te runga herea he nui atu i [`usize`].
    ///
    /// # tuhipoka whakatinana
    ///
    /// Kaore i te whakatutukihia na te whakatinanatanga o te awa e whakaatu te maha o nga waahanga kua puta.He iti ake te hua o te awa buggy i te rohe o raro, neke atu ranei i te rohe o runga o nga waahanga.
    ///
    /// `size_hint()` Kei te matua tikanga ki te whakamahi hoki optimizations pērā i rahui wāhi mo te āhuatanga o te awa, engari e kore e me e whakawhirinaki ki tauira, waihotia ai rohe arowhai i roto i te waehere haumaru.
    /// He whakatinanatanga hē o `size_hint()` kore e arahi ki maumaui haumaru mahara.
    ///
    /// E mea, kia whakarato te whakatinanatanga he i whakarite tika, no te mea te kore e riro te reira i te takahi o te kawa o te trait.
    ///
    /// Ko te hoki te whakatinanatanga taunoa `(0,` [`None`]`)`e he tika hoki tetahi awa.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}