//! Traits mo nga rereketanga i waenga i nga momo.
//!
//! Te traits i roto i tenei kōwae whakarato te ara ki te tahuri i momo tetahi ki tetahi momo.
//! He rereke te kaupapa o ia trait:
//!
//! - Whakahaerehia te [`AsRef`] trait mo te iti rawa o te whakawhiti korero-ki-tohutoro
//! - Whakahaerehia te [`AsMut`] trait mo te iti o te huri-ki-te huri
//! - Whakamahia te [`From`] trait mo te kai i nga whakawhitinga uara-ki-uara
//! - Whakahaerehia te [`Into`] trait mo te kohi uara-ki-uara ki nga momo i waho o te crate onaianei
//! - whakahihi te [`TryFrom`] me [`TryInto`] traits rite [`From`] ko [`Into`], engari kia kia whakatinana ka taea kore te faafariuraa.
//!
//! Kei te maha te traits i roto i tenei kōwae whakamahia rite trait bounds mō ngā mahi whānui pērā e tautokona ki tautohetohe o ngā momo maha.Tirohia te te tuhinga o ia trait mō tauira.
//!
//! Ka rite ki te kaituhi pukapuka, kia hiahia tonu koe te whakatinana i [`From<T>`][`From`] ranei [`TryFrom<T>`][`TryFrom`], kaua ki te [`Into<U>`][`Into`] ranei [`TryInto<U>`][`TryInto`], rite [`From`] ko [`TryFrom`] whakarato ngäwari nui me whakahere ōrite [`Into`] [`TryInto`] ranei implementations mō te kore utu, whakawhetai ki te whakatinanatanga paraikete i roto i te whare pukapuka paerewa.
//! A, no te ngā i te putanga i mua ki Rust 1.41, kia ai taua mea e tika ana ki te whakatinana i tika [`Into`] [`TryInto`] ranei ka tahuri ki te momo i waho te crate nāianei.
//!
//! # Ahuwhānui Implementations
//!
//! - [`AsRef`] me te [`AsMut`] whakakore-aunoa mena he momo tohutoro te momo o roto
//! - [`Mai`]`<U>mō T` e kī ana [`Ki roto`]`</u><T><U>mo U`</u>
//! - ["Whakamātauria Mai`]`<U>mō T` e kī ana ["Whakamātauria ki roto`]`</u><T><U>hoki U`</u>
//! - [`From`] a he whakaata, e tikanga e taea momo katoa `into` ratou ko `from` ratou [`Into`]
//!
//! Tirohia te ia trait mō tauira whakamahi.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Te mahi tuakiri.
///
/// E rua nga mea nui kia maarama mo tenei mahi:
///
/// - Kaore i te rite ki te katinga pera i te `|x| x`, na te mea katahi pea ka tohaina te `x` ki tetahi momo momo.
///
/// - neke te reira i te wāhi i haere `x` ki te mahi.
///
/// Ahakoa te mea he ai ke ki te whai i te mahi e hoki tika hoki i te wāhi, i reira e te tahi mau whakamahinga ngā.
///
///
/// # Examples
///
/// Ma te whakamahi i te `identity` ki te kore mahi i tetahi atu raupapa, whakamere, mahi ranei:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Me ahua ke taapiri tetahi he mahi whakamere.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Mā te `identity` rite te take turanga "do nothing" i roto i te herenga:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Mahia etahi atu mea whakamere ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Mā te `identity` ki te pupuri i te `Some` rerekē o te iterator o `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Whakamahia hei mahi i te hurihuri tohutoro-ki-tohutoro iti.
///
/// Ko tenei trait he rite ki te [`AsMut`] e whakamahia ana mo te huri i waenga i nga korero whakarereke.
/// Ki te hiahia koe ki te mahi i te faafariuraa utu nui he reira pai ki te whakatinana i [`From`] ki momo `&T` tuhituhi i te mahi ritenga ranei.
///
/// `AsRef` he rite ano te waitohu ki a [`Borrow`], engari he rereke te [`Borrow`] i roto i etahi waahanga.
///
/// - Rerekē `AsRef`, kua [`Borrow`] he impl paraikete mo tetahi `T`, a taea te whakamahi ki te farii i rānei te tohutoro i te uara ranei.
/// - [`Borrow`] e hiahia ana hoki kia [`Hash`], [`Eq`] me [`Ord`] mo te utu tarewa e orite ana ki era o te uara nona ake.
/// Mo konei, mena kei te hiahia koe ki te nama noa i te waahanga kotahi o te hanganga ka taea e koe te whakamahi i te `AsRef`, engari kaua ko te [`Borrow`].
///
/// **Note: kore me tenei trait kore **.Ki te taea te faafariuraa kore, te whakamahi i te tikanga i whakatapua e hoki he [`Option<T>`] he [`Result<T, E>`] ranei.
///
/// # Ahuwhānui Implementations
///
/// - `AsRef` dereferences aunoa-ki ko te momo i roto i te tohutoro i te tohutoro mutable ranei (hei tauira: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Ma te whakamahi i te trait bounds ka taea e taatau te whakaae i nga tohenga o nga momo rereke mena ka taea te huri ki te momo `T` kua tohua.
///
/// Hei tauira: Ma te hanga i tetahi mahi whanui hei `AsRef<str>` ka kii taatau e hiahia ana maatau ki te whakaae ki nga tohutoro katoa ka taea te huri ki te [`&str`] hei tautohe.
/// Mai i te [`String`] me te [`&str`] ka whakatinana i te `AsRef<str>` ka taea e taatau te whakaae i nga tautohetohe whakauru.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Ka mahi i te hurihanga.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Whakamahia hei mahi i te tahuritanga tohutoro ngawari-ki-whakarereke.
///
/// He rite ki [`AsRef`] engari whakamahia mō te tahuri i waenganui i tohutoro mutable tenei trait.
/// Ki te hiahia koe ki te mahi i te faafariuraa utu nui he reira pai ki te whakatinana i [`From`] ki momo `&mut T` tuhituhi i te mahi ritenga ranei.
///
/// **Note: kore me tenei trait kore **.Ki te taea te faafariuraa kore, te whakamahi i te tikanga i whakatapua e hoki he [`Option<T>`] he [`Result<T, E>`] ranei.
///
/// # Ahuwhānui Implementations
///
/// - `AsMut` whakakore-aunoa mai i te mea ko te momo o roto he tohu ka taea te whakarereke (hei tauira: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Ma te whakamahi i te `AsMut` hei trait bound mo te mahi whanui ka taea e taatau te tango i nga tohutoro huri katoa ka taea te huri hei patopato `&mut T`.
/// Na te mea ka whakamahia e [`Box<T>`] te `AsMut<T>` ka taea e taatau te tuhi i tetahi mahi `add_one` ka tango i nga tohenga katoa ka taea te huri ki te `&mut u64`.
/// Na te mea ka whakamahia e [`Box<T>`] te `AsMut<T>`, ka whakaae a `add_one` ki nga tautohe o te momo `&mut Box<u64>` hoki:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Ka mahi i te hurihanga.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// He hurihanga uara-ki-uara ka pau te uara whakauru.Ko te ritenga ke o [`From`].
///
/// Kia karohia e tetahi te whakamahi i te [`Into`] me te whakamahi i te [`From`] hei utu.
/// Ko te whakamahi i te [`From`] ka whakawhiwhia ki tetahi ki te whakamahi i te [`Into`] whakawhetai ki te whakatinanatanga paraikete i te wharepukapuka paerewa.
///
/// Pai te whakamahi i te [`Into`] i runga i te [`From`] i te wa e tohu ana i te trait bounds i runga i te mahi whanui kia mohio ko nga momo e whakamahi ana i te [`Into`] ka taea hoki te whakamahi.
///
/// **Note: Ko tenei trait kaua e taka **.Ki te taea te faafariuraa kore, te whakamahi i [`TryInto`].
///
/// # Ahuwhānui Implementations
///
/// - [`Mai`]`<T>mo U` e tohu `Into<U> for T`
/// - [`Into`] he whakaata, ko te tikanga ka whakatinanahia te `Into<T> for T`
///
/// # Te whakatinana i [`Into`] mō faafariuraa ki momo waho i roto i ngā putanga tawhito o Rust
///
/// I mua ki Rust 1.41, ki te kahore i te momo ūnga wahi o te crate nāianei ka koe i taea kore whakatinana tika [`From`].
/// Hei tauira, tangohia tenei waehere:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Tenei ka kore ki te whakahiato i roto i ngā putanga tawhito o te reo no te whakamahia ture orphaning o Rust ki te waiho i te iti bit tino atu.
/// Hei karo i tenei, ka taea e koe te whakamahi tika i te [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// He mea nui ki te matau, e kore e [`Into`] whakarato i tētahi whakatinanatanga [`From`] (rite [`From`] e ki [`Into`]).
/// Na reira, me tarai tonu koe ki te whakamahi i te [`From`] ka hoki ano ki te [`Into`] mena kaore e taea te whakamahi i te [`From`].
///
/// # Examples
///
/// [`String`] taputapu [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Hei whakaatu e hiahia ana maatau kia tangohia e tetahi mahi whanui te tautohe katoa ka taea te huri ki te momo `T` kua tohua, ka taea e taatau te whakamahi i te trait bound o [`Ki roto`] '<T>`.
///
/// Hei tauira: Ko te mahi `is_hello` ka tango i nga tohenga katoa ka taea te huri hei [`Vec`]`<`[`u8`] `> '.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Ka mahi i te hurihanga.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Whakamahia ai hei huri i nga uara-ki-uara i te wa e pau ana te uara whakauru.Ko reira te tau utuutu o [`Into`].
///
/// kia hiahia tonu tetahi te whakatinana i `From` mo [`Into`] no te whakatinana i `From` whakarato aunoa tetahi ki te whakatinanatanga o te whakawhetai [`Into`] ki te whakatinanatanga paraikete i roto i te whare pukapuka paerewa.
///
///
/// whakatinana anake [`Into`] ka arotahi te putanga i mua ki Rust 1.41 me tahuri ki te momo i waho te crate nāianei.
/// `From` kaore i taea enei momo huri i nga waahanga o mua na te mea ko nga ture pani a Rust.
/// Tirohia te [`Into`] mo etahi atu korero taipitopito.
///
/// He pai ake te whakamahi i te [`Into`] nui atu i te whakamahi i te `From` i te waa e tohu ana koe i te trait bounds i runga i te mahi whanui.
/// Tenei ara, momo e tika whakatinana [`Into`] taea te whakamahi rite tohenga rite te pai.
///
/// He tino whaihua te `From` ka mahi hapa hapa.Ka hangaia ana e koe tetahi mahi e kaha ana ki te ngoikore, ko te momo whakahoki mai i te ahua `Result<T, E>`.
/// hapa te `From` trait ohie whāwhā mā te tuku i te mahi ki te hoki mai te momo hapa kotahi e āhuatanga momo hapa maha.Tirohia te waahanga "Examples" me [the book][book] mo etahi atu taipitopito.
///
/// **Note: kore me tenei trait kore **.Ki te taea te faafariuraa kore, te whakamahi i [`TryFrom`].
///
/// # Ahuwhānui Implementations
///
/// - `From<T> for U` e tohu ana [`Ki roto`]`<U>mo T`</u>
/// - `From` Ko whakaata, i te tikanga whakatinana e te `From<T> for T`
///
/// # Examples
///
/// [`String`] whakatinana `From<&str>`:
///
/// mahi He faafariuraa mārama i te `&str` ki te Aho te rite e whai ake nei:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// I a koe e mahi ana i te hapa hapa he pai tonu te whakamahi i te `From` mo taau ake momo hapa.
/// Ma te huri i nga momo hapa o taatau ki ta taatau ake momo momo raru e karapoti ana i te momo hapa o te hapa, ka taea e taatau te whakahoki mai i tetahi momo hapa kaore e ngaro nga korero mo te kaupapa matua.
/// Ko te kaiwhakahaere '?' e tahuri aunoa i te momo hapa whāriki ki to tatou momo hapa ritenga mā te karanga `Into<CliError>::into` nei te whakaratohia aunoa ina whakatinana `From`.
/// Ka werohia e te kaitautu te whakamahi i te `Into` me whakamahi.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Ka mahi i te hurihanga.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// He ngana faafariuraa e pau `self`, e ai ranei e kore ai e utu.
///
/// kaituhi Library kia kore te tikanga tika whakatinana tenei trait, engari kia pai te whakatinana i te [`TryFrom`] trait, e tuku ngāwari nui me whakarato te whakatinanatanga `TryInto` ōrite mō te kore utu, whakawhetai ki te whakatinanatanga paraikete i roto i te whare pukapuka paerewa.
/// Mo etahi atu korero mo tenei, tirohia nga tuhinga mo [`Into`].
///
/// # Te Whakatinana i te `TryInto`
///
/// mamae tenei te taua here me whakaaroaro rite whakatinana [`Into`], kite reira hoki kōrero.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// I hoki mai ano te momo mena ka he o te huringa.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ka mahi i te hurihanga.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Māmā me faafariuraa momo haumaru e kia kore i roto i te ara whakahaeretia i raro i te tahi mau huru.Ko te whakautu a [`TryInto`].
///
/// He mea whai hua tenei ka mahi koe i te momo momo whakarereketanga kaore pea e angitu ana engari ka hiahia pea koe ki te whakahaere motuhake.
/// Hei tauira, i reira he kore huarahi ki te tahuri i te [`i64`] ki te [`i32`] te whakamahi i te [`From`] trait, no te mea kia roto i te [`i64`] te uara e kore e taea e te [`i32`] tohu me na te faafariuraa e ngaro raraunga.
///
/// kia whawha ai tenei e whakapoto te [`i64`] ki te [`i32`] (tino hoatu te [`i64`] 'o uara modulo [`i32::MAX`]) ranei e hoki mai noa [`i32::MAX`], i etahi atu tikanga ranei.
/// tikanga te [`From`] trait te hoki faafariuraa tino, na ngā te `TryFrom` trait te kaihātepe ina taea te faafariuraa momo haere kino, me te ka taea whakatau ratou me pehea ki te hapai i te reira.
///
/// # Ahuwhānui Implementations
///
/// - `TryFrom<T> for U` fakahu'unga [`TryInto`]`<U>mo T`</u>
/// - [`try_from`] Ko whakaata, i te tikanga e whakatinanahia `TryFrom<T> for T` te me kore e taea kore-i te momo `Error` e pā ana mō te karanga `T::try_from()` i runga i te uara o te momo `T` ko [`Infallible`].
/// Ka pumau ana te momo [`!`] [`Infallible`] me te [`!`] ka rite.
///
/// `TryFrom<T>` ka taea te whakatinana penei:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Ka rite ki te korero, [`i32`] ka whakamahi i te 'TryFrom <"[` i64`]`>>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Mamu noa Poporetia `big_number`, titau kimi me te maminga te poporetanga i muri i te meka.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Ka whakahoki he hapa na te mea `big_number` he nui rawa kia kore e uru ki te `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Whakahoki `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// I hoki mai ano te momo mena ka he o te huringa.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ka mahi i te hurihanga.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// NGA WHAKAMAHI KAUPAPA
////////////////////////////////////////////////////////////////////////////////

// Ka hikitia ana&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Ka rite ki whakaara ki runga ki &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): whakakapi i te impls runga ake hoki&/&mut ki te tetahi atu whānui e whai ake nei:
// // Ka rite ki whakaara ki runga ki Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Rahi> AsRef <U>mo D {FI as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut whakaara ki runga ki &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): whakakapi i te impl runga ake hoki &mut ki te tetahi atu whānui e whai ake nei:
// // Ka piki a AsMut ki runga i a DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Rahi> AsMut <U>mo D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Mai i titau ki
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Mai i (a ko te kupu ki) he whakaata
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **pūmautanga tuhipoka:** kore e tenei impl ano te tīariari, engari e tatou "reserving space" ki te tāpiri i te reira i roto i te future.
/// Tirohia te [rust-lang/rust#64715][#64715] mo nga korero taipitopito.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): mahia te kaupapa whai.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom uhinga a TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// E semantically ōrite ki faafariuraa sipí ki he momo hapa e nohoia tahuritanga whakamamaetanga.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// NGĀ MAHI NGARU
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// TE KORE-HAPA MOMO HAPA
////////////////////////////////////////////////////////////////////////////////

/// Te momo hapa mo nga hapa kaore e taea te mahi.
///
/// Mai tenei tau e kua kahore kē, he uara o tenei momo e taea kore mau te tīariari.
/// He pai pea mo nga API whanui e whakamahi ana i te [`Result`] me te taatai i te momo hapa, hei tohu ko te hua [`Ok`] tonu.
///
/// Hei tauira, te [`TryFrom`] trait (faafariuraa e hoki he [`Result`]) he whakatinanatanga paraikete mo momo katoa i reira te vai te whakatinanatanga [`Into`] whakamuri.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Hototahi Future
///
/// Tenei tau e He te tūranga taua rite [the `!`“never”type][never], i te mea iu i tenei putanga o Rust.
/// Ka pumau ana te `!`, ka whakamahere maatau kia waiho te `Infallible` hei momo ingoa ki a ia:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Ka mutu ka kore te `Infallible`.
///
/// Heoi i reira he kotahi take i reira e taea te whakamahi `!` wetereo i mua i ähuareka `!` te rite te momo tonu-parirau: i roto i te tūranga o te momo hoki o te mahi.
/// Tüturu, he mea implementations taea mō ngā momo mahi atatohu rerekē e rua:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Ki te `Infallible` te he tau, he tika tenei waehere.
/// Heoi ka riro a `Infallible` hei ingoakii mo te never type, ka tiimata nga `impl`s e rua ka kore e whakaaetia e nga ture honohono trait o te reo.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}