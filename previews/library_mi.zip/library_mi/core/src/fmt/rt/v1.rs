//! He mahinga a-roto tenei e whakamahia ana e te ifmt!wāhaere.E tukuna ēnei hanganga ki ngā huānga pateko ki aho hōputu precompile mua o te wā.
//!
//! Ko enei whakamaaramatanga he rite ki a raatau `ct` taurite, engari he rereke te rereke ka taea te tohatoha me te whakariterite kia pai te waa.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Ka taea nga tono ka taea te tono hei waahanga whakatakotoranga korero.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Tohu e kia kia tirotiro maui-tiaro.
    Left,
    /// Te tohu kia tika te whakariterite o nga korero.
    Right,
    /// He tohu kia haangai-whakariterite nga tuhinga.
    Center,
    /// I tonoa Kāore he tīaroaro.
    Unknown,
}

/// Whakamahia e [width](https://doc.rust-lang.org/std/fmt/#width) me nga tohu [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Ka whakaputahia ki te tau pono, ka penapena te uara
    Is(usize),
    /// Tohua te whakamahi i `$` ko `*` syntaxes, pupuru ana te taupū ki `args`
    Param(usize),
    /// Ehara i tohua
    Implied,
}