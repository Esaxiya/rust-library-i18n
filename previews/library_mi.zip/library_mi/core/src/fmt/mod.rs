//! Taputapu mō te hōputu me te tā aho.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Ko nga whakahonohono pea i whakahokia mai e `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Tohu e kia kia tirotiro maui-tiaro.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Te tohu kia tika te whakariterite o nga korero.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// He tohu kia haangai-whakariterite nga tuhinga.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Ko te momo hoki e tikanga formatter.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Ko te momo hapa hoki e te i te hōputu he karere ki te awa.
///
/// Kaore tenei momo e tautoko i te tuku hapa mai i tera i puta he raru.
/// Me whakarite tetahi mōhiohio anō ki te kia tuku i roto i etahi atu tikanga.
///
/// He mea nui ki te mahara ko e kore e kia raruraru te momo `fmt::Error` ki [`std::io::Error`] ranei [`std::error::Error`], e ai hoki i a koutou i roto i te hōkai.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// He trait mō te tuhituhi hōputu ki Waehereao-te fariiraa i ngā pūreirei awa ranei ranei.
///
/// Tenei trait anake whakaae raraunga UTF-8-whakawaeheretia me he kahore [flushable].
/// Ki te hiahia noa koe ki te farii i Waehereao, a kihai koutou mahi hiahia te Makere, kia whakatinana koe tenei trait;
/// ki te kore me whakamahi e koe te [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Ka tuhia he poro aho ki tenei kaituhi, ka whakahoki mai mena i angitu nga tuhinga.
    ///
    /// Ka angitu noa tenei tikanga mena i angitu te tuhi o te poro o te aho, a kaore tenei tikanga e hoki kia tuhia ra ano nga tuhinga katoa ka he ranei.
    ///
    ///
    /// # Errors
    ///
    /// Ka hoki mai tenei mahi i tetahi tauira o [`Error`] i runga i te he.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Ka tuhi [`char`] ki tenei kaituhi, ka whakahoki mai mena i angitu nga tuhinga.
    ///
    /// kia kia whakawaeheretia te kotahi [`char`] rite neke atu i te kotahi paita.
    /// Ka angitu noa tenei tikanga mena ka pai te tuhi o te paita paita, a kaore tenei tikanga e hoki kia tuhia ra ano nga tuhinga katoa ka he ranei.
    ///
    ///
    /// # Errors
    ///
    /// Ka hoki mai tenei mahi i tetahi tauira o [`Error`] i runga i te he.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Amuiraa no te whakamahi o te tonotono [`write!`] ki implementors o tenei trait.
    ///
    /// kia kore te tikanga, e maharatia a tenei tikanga ā, engari i roto i te tonotono [`write!`] iho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Whirihoranga mo te whakahōpututanga.
///
/// He `Formatter` tohu ngā kōwhiringa e pā ana ki whakahōputu.
/// e kore e Kaiwhakamahi hanga `Formatter`s tika;he tohutoro mutable ki tetahi haere te ki te tikanga `fmt` o whakahōputu traits katoa, rite [`Debug`] ko [`Display`].
///
///
/// Ki te pāhekoheko ki te `Formatter`, ka karanga koe ngā tikanga ki te huri i te kōwhiringa ngā pā ana ki whakahōputu.
/// No te tauira, tēnā kite te tuhinga o nga tikanga tautuhi i runga i `Formatter` i raro.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Ko te tino tautohe he wāhanga tono mahi papaitia hōputu, ōrite ki `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Tenei struct tohu te "argument" kano tangohia nei e te whānau Xprintf o ngā mahi.Kei reira he mahi ki te whakahōputu i te uara i homai.
/// I te wa e whakahiatohia ana kia mohio he tika nga momo mahi me te uara, katahi ka whakamahia tenei hanganga ki te whakaari i nga tohenga ki tetahi momo.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// whakapūmau i tenei he uara eu kotahi mo te atatohu taumahi e pā ana ki indices/counts i te hanganga whakahōputu.
//
// Kia mahara ko tetahi mahi kua tautuhia penei kaore i te tika na te mea kaore i te tapaina nga mahi i nga ingoa kore ki te whakaheke i te wa ki te LLVM IR, na reira kaore i te whakaarohia he mea nui ki a LLVM ta raatau korero a na te mea ka taea te mahi he i te kaiwhakaari
//
// I roto i te mahi, e kore matou e karanga as_usize i usize-kore kei roto raraunga (kia rite ki te mea o te whakatupuranga pateko o nga tohenga whakahōputu), na ko te noa tenei he taki atu.
//
// hiahia matua tatou ki te whakarite kia te atatohu mahi i `USIZE_MARKER` he wāhitau hāngai *anake* ki ngā mahi e tango hoki `&usize` rite ratou tautohe tuatahi.
// Ma te panui-panui i konei e ahei te whakarite maatau mo te whakamahi mai i te tohutoro kua paahitia, a kaore tenei waaera e tohu ki te mahi kore-whakamahi.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // SAFETY: ptr he korero
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // SAFETY: `mem::transmute(x)` he ahuru na te mea
        //     1. `&'b T` pupuri ana i te ora ahu mai i te reira ki `'b` (kia rite ki kore he ora e oti'a)
        //     2.
        //     `&'b T` ka whai `&'b Opaque` te tahora mahara taua (ka `T` ko `Sized`, rite he reira i konei) he haumaru `mem::transmute(f)` mai i `fn(&T, &mut Formatter<'_>) -> Result` ko `fn(&Opaque, &mut Formatter<'_>) -> Result` te taua Apietere (rite te roa rite `T` ko `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // HAUMARU: Kei te anake whakatakotoria te mara `formatter` ki USIZE_MARKER ki te
            // he moni whakamahi te uara, no reira he ahuru tenei
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// kara e wātea ana i roto i te hōputu v1 o format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// A, no te whakamahi i te format_args! () Tonotono, whakamahia tenei mahi te ki te whakaputa i te hanganga Tohenga.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// whakamahia ana tēnei mahi te ki te tautuhi i ngā tawhā whakahōputu nonstandard.
    /// Ko te kohinga `pieces` me neke atu i te `fmt` hei hanga i tetahi hanganga Tohenga Tautohe.
    /// Ano hoki, ko tetahi `Count` i roto i te `fmt` ko `CountIsParam` ko `CountIsNextParam` me tohu ki tetahi tautohe i hangaia me `argumentusize`.
    ///
    /// Heoi, ki te kore e mahi pera ka kore e awangawanga, engari ka peera tonu.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Tata te roa o te kuputuhi hōputu.
    ///
    /// tikanga tenei te ki kia whakamahia mō te whakanoho kaha `String` tuatahi ka whakamahi i `format!`.
    /// Note: ehara tenei i te rohe o raro, o runga ranei.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Mena ka tiimata te aho whakatakotoranga me te tautohe, kaua e tohatoha i tetahi mea, mena ka nui te roa o nga waahanga.
            //
            //
            0
        } else {
            // He etahi tohenga, ka pena ka reallocate tetahi atu pana te aho.
            //
            // Ki te karo i taua, kei tatou "pre-doubling" te aravihi i konei.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Ko tenei mahinga e whakaatu ana i te waahanga kua ata whakaraupatutia mo te aho whakatakotoranga me ona tohenga.
/// e kore e taea te hanga i tēnei i te wā i te mea e kore e taea humarie te mahi reira, na e hoatu kahore constructors me e tūmataiti ki te ārai i te whakarereke nga mara.
///
///
/// Ko te tonotono [`format_args!`] ka hanga humarie he tauira o tenei hanganga.
/// Ko te tonotono whakamana te aho hōputu i whakahiato-wa kia taea te whakamana humarie whakamahinga o te mahi [`write()`] me [`format()`].
///
/// Ka taea e koe te whakamahi i te `Arguments<'a>` e hoki [`format_args!`] i ngā horopaki `Debug` me `Display` rite kite i raro.
/// Ko te tauira e whakaatu ana ko te whakatakotoranga `Debug` me te `Display` ki taua mea ano: ko te aho whakatakotoranga hono i `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // mongamonga Hōputu string ki tā.
    pieces: &'a [&'static str],

    // Ko nga tohu a te Kaipupuri, ko `None` mena he taunoa nga waahanga katoa (penei i te "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Nga tohe hihiri mo te wehenga, kia honoa ki nga waahanga aho.
    // (Ko nga tohenga katoa kei mua i te aho.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Tikina te aho whakahōpututia, mena kaore he tohenga hei whakahōpututanga.
    ///
    /// Ka taea tenei ki te karo i nga tohatoha i roto i te keehi iti noa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` kia whakatakoto i te putanga ki roto i te horopaki-e anga ana ki te papatono, me te horopaki whakakore.
///
/// I te nuinga o te waa, me `derive` noa koe me te whakamahi `Debug`.
///
/// Ka whakamahia ana me tetahi atu momo whakatakotoranga tohu `#?`, he pai te taarua o te putanga.
///
/// Mō ētahi atu pārongo i runga i formatters, kite [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Ka taea te whakamahi i tēnei trait ki `#[derive]` ki te whakatinana mara katoa `Debug`.
/// Ka "ahu`d mo nga nekehanga, ka whakamahia te ingoa o te `struct`, katahi ka `{`, ka mutu he raarangi kua wehea e te ingoa o ia mara me te uara `Debug`, ka `}`.
/// Mo te `enum`s, ka whakamahia te ingoa o te momo rereke, ana, ki te tika, `(`, ka uara `Debug` o nga mara, ka `)`.
///
/// # Stability
///
/// e kore e kainga ahu hōputu `Debug`, a kia pera te huri ki putanga future Rust.
/// I tua atu, e kore e pūmau `Debug` implementations o momo e whakaratohia ana e te whare pukapuka paerewa (`libstd`, `libcore`, `liballoc`, me ētahi atu), a kia hoki te huri ki putanga future Rust.
///
///
/// # Examples
///
/// Te whakatinana:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Te whakamahi a ringa:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// He he maha o ngā tikanga kaiawhina i runga i te struct [`Formatter`] ki te āwhina ia koutou ki te implementations ā-, pērā i [`debug_struct`].
///
/// `Debug` implementations whakamahi rānei `derive` te patuiro API kaihanga i runga i te tautoko [`Formatter`] tino-tā te whakamahi i te haki kē ranei: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Tino-tā ki `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Whakahōputu te uara mā te whakamahi i te formatter homai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// kōwae motuhake ki reexport te tonotono `Debug` i prelude waho te trait `Debug`.
pub(crate) mod macros {
    /// tonotono ahu whakaputa he impl o te trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Whakahoutia te trait mo te whakatakotoranga putunga, `{}`.
///
/// `Display` He rite ki [`Debug`], engari `Display` he mo te putanga anga-kaiwhakamahi, a kia kore e taea te ahu.
///
///
/// Mō ētahi atu pārongo i runga i formatters, kite [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Te whakatinana i `Display` i runga i te momo:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Whakahōputu te uara mā te whakamahi i te formatter homai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// kia te whakahōputu te `Octal` trait tona putanga rite te tokomaha i roto i base-8.
///
/// Hoki tahito tau tōpu hainatia (`i8` ki `i128`, ko `isize`), kua whakahōpututia uara tōraro rite kanohi ngä o te rua.
///
///
/// Ko te haki rereke, `#`, ka taapiri i te `0o` i mua o te putanga.
///
/// Mō ētahi atu pārongo i runga i formatters, kite [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Te whakamahinga taketake me te `i32`:
///
/// ```
/// let x = 42; // 42 Ko '52' i pīrangi ana
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Te whakatinana i `Octal` i runga i te momo:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // tohaina ki te whakatinanatanga o i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Whakahōputu te uara mā te whakamahi i te formatter homai.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// Ko te `Binary` trait me whakariterite i tana putanga hei tau i roto i te-rua.
///
/// Hoki tahito tau tōpu hainatia ([`i8`] ki [`i128`], ko [`isize`]), kua whakahōpututia uara tōraro rite kanohi ngä o te rua.
///
///
/// Te haki kē, `#`, tāpiri he `0b` i mua o te putanga.
///
/// Mō ētahi atu pārongo i runga i formatters, kite [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// whakamahinga Basic ki [`i32`]:
///
/// ```
/// let x = 42; // 42 Ko te '101010' i te takirua
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Te whakatinana i `Binary` i runga i te momo:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // tohaina ki te whakatinanatanga o i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Whakahōputu te uara mā te whakamahi i te formatter homai.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// kia te whakahōputu te `LowerHex` trait tona putanga rite te tokomaha i roto i hautekaumāono, ki `a` roto `f` roto i te take o raro.
///
/// Hoki tahito tau tōpu hainatia (`i8` ki `i128`, ko `isize`), kua whakahōpututia uara tōraro rite kanohi ngä o te rua.
///
///
/// Te haki kē, `#`, tāpiri he `0x` i mua o te putanga.
///
/// Mō ētahi atu pārongo i runga i formatters, kite [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Te whakamahinga taketake me te `i32`:
///
/// ```
/// let x = 42; // Ko te 42 he '2a' i te hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Te whakamahi i te `LowerHex` i runga i te momo:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // tohaina ki te whakatinanatanga o i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Whakahōputu te uara mā te whakamahi i te formatter homai.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// Ko te `UpperHex` trait me whakariterite i tana putanga hei tau i te hexadecimal, me te `A` tae atu ki te `F` kei runga ake.
///
/// Hoki tahito tau tōpu hainatia (`i8` ki `i128`, ko `isize`), kua whakahōpututia uara tōraro rite kanohi ngä o te rua.
///
///
/// Te haki kē, `#`, tāpiri he `0x` i mua o te putanga.
///
/// Mō ētahi atu pārongo i runga i formatters, kite [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Te whakamahinga taketake me te `i32`:
///
/// ```
/// let x = 42; // 42 Ko '2A' i hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Te whakamahi i te `UpperHex` i runga i te momo:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // tohaina ki te whakatinanatanga o i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Whakahōputu te uara mā te whakamahi i te formatter homai.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// Ko te `Pointer` trait me whakariterite i tana whakaputa hei waahi maumahara.
/// Ka whakaatuhia tenei hei hexadecimal.
///
/// Mō ētahi atu pārongo i runga i formatters, kite [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// whakamahinga Basic ki `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // ka whakaputa tenei i tetahi mea penei i te '0x7f06092ac6d0'
/// ```
///
/// Te whakatinana i `Pointer` i runga i te momo:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // whakamahi `as` ki ului ki he `*const T`, e whakatinana Pointer, e taea tatou te whakamahi i
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Whakahōputu te uara mā te whakamahi i te formatter homai.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// kia te whakahōputu te `LowerExp` trait tona putanga i roto i te momotuhi pūtaiao ki te raro-take `e`.
///
/// Mō ētahi atu pārongo i runga i formatters, kite [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Te whakamahinga taketake me te `f64`:
///
/// ```
/// let x = 42.0; // 42.0 he '4.2e1' i roto i te tuhinga whakapae putaiao
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Te whakatinana i `LowerExp` i runga i te momo:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // tohaina ki te whakatinanatanga o te f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Whakahōputu te uara mā te whakamahi i te formatter homai.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// Ko te `UpperExp` trait me whakatakoto i ona putanga ki roto i te tuhinga pūtaiao me te `E` nui-ake.
///
/// Mō ētahi atu pārongo i runga i formatters, kite [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Te whakamahinga taketake me te `f64`:
///
/// ```
/// let x = 42.0; // 42.0 he '4.2E1' i roto i te tuhinga whakapae putaiao
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Te whakatinana i `UpperExp` i runga i te momo:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // tohaina ki te whakatinanatanga o te f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Whakahōputu te uara mā te whakamahi i te formatter homai.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Ko te mahi `write` e he awa putanga, me he struct `Arguments` e taea te Kohikohia ki te tonotono `format_args!`.
///
///
/// Ko nga tautohetohe ka whakahōpututia kia rite ki te aho whakatakotoranga i whakaritea ki roto i te roma whakaputanga kua tohaina.
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Kia mahara ma te whakamahi i te [`write!`] he pai ake pea.Tauira:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Ka taea e taatau te whakamahi i nga taatai whakatakotoranga taunoa mo nga tohenga katoa.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // He tautohe taitara katoa kei mua i te waahanga o te aho.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // HAUMARU: arg ko args.args mai i te taua Tohenga,
                // e tohu ana ko nga taurangi kei roto tonu i nga rohe.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // He taea e mahue anake kotahi makatea aho wahi.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // HAUMARU: arg me args mai i te taua Tohenga,
    // e tohu ana ko nga taurangi kei roto tonu i nga rohe.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Unuhia te tautohe tika
    debug_assert!(arg.position < args.len());
    // HAUMARU: arg me args mai i te taua Tohenga,
    // i te whakapūmau i ko tona taupū tonu i roto i rohe.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Na me mahi taatai
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // HAUMARU: CNT me args mai i te taua Tohenga,
            // i te whakapūmau i ko tenei taupū tonu i roto i rohe.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Purpuru i muri i te mutunga o te tahi mea.Whakahoki mai e `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Tuhia tenei papa whakairi.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // e hiahia ana matou ki te huri i tenei
            buf: wrap(self.buf),

            // A tiaki enei
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // tikanga kaiawhina whakamahia mō te purpuru me te tukatuka hōputu tohenga e taea te whakamahi i te whakahōputu katoa traits.
    //

    /// He whakamahi i te purpuru tika mo te tau tōpū e kua oti tukuna ki te Str.
    /// kia *kore* i roto i te Str te tohu mo te tau tōpū, kia e ka tapiritia e tenei tikanga.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, ahakoa ko te tau tōpū taketake rānei pai kore ranei.
    /// * kuhimua, ki te te huru '#' whakaratohia (Alternate) te, ko te kuhimua ki te hoatu i roto i mua o te tau tenei.
    ///
    /// * buf, te ngohi paita e kua te tau kua whakahōpututia ki
    ///
    /// Ka pūkete tika tenei mahi mo te haki whakaratohia rite te pai kia rite ki te whanui iti.
    /// E kore e tangohia e te reira i pū ki pūkete.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Me tango e tatou te "-" mai i te whakaputanga tau.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Tuhi te tohu, ki te vai te reira, a ka te kuhimua ki te i tonoa ai
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Ko te mara `width` ko atu o te tawhā `min-width` i tenei wāhi.
        match self.width {
            // Mena kaore he whakaritenga iti roa ka taea noa te tuhi i nga paita.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Tirohia ki te kei i runga i te whanui iti tatou, ki te pera ka tatou e nehenehe e hoki noa tuhituhi i te paita.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Ko te tohu me te pīmua haere i mua i te purpuru ki te ko te pūāhua makona kore
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Kore, te tohu me te pīmua haere i muri i te purpuru
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Tenei mahi e te wāhanga string me tuku hoki reira ki te moka ā-i muri i te tono i te haki whakahōputu hāngai tohua.
    /// Ko nga haki e mohiotia ana mo nga aho noa ko:
    ///
    /// * whānui, te whanui iti o te aha ki te emit
    /// * fill/align - he aha te emit me ana ki te tuku mena e hiahia ana kia whakakii te aho i whakaritea
    /// * pū, te roa mōrahi ki te tuku, ka tuaina te aho mena he roa atu i tenei roa
    ///
    /// Ko tenei mahi kaore e aro ki nga tohu `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Tirohia mēnā i reira te he ara nohopuku ake mua
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Ka taea te whakaatu ai te mara `precision` rite he `max-width` mo te whakahōpututia te aho.
        //
        let s = if let Some(max) = self.precision {
            // Ki te he roa e te pū to tatou string, ka kuo pau ke tau whai poporetanga.
            // Heoi me mahi rite tonu atu haki rite `fill`, `width` ko `align`.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // Kaore e taea e te LLVM o konei te whakaatu ko te `..i` kaore e panic `&s[..i]`, engari e mohio ana taatau kaore e taea te panic.
                // Whakamahia te `get` + `unwrap_or` ki te karo i te `unsafe` ka kore e whakaputa i tetahi waehere e pa ana ki a panic i konei.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Ko te mara `width` ko atu o te tawhā `min-width` i tenei wāhi.
        match self.width {
            // Mena kei raro tatou i te roa roa, a kaore he whakaritenga iti roa, katahi ka taea noa te whakaputa i te aho
            //
            None => self.buf.write_str(s),
            // Mena kei raro tatou i te whanui nui, tirohia mena kei runga ake i te whanui iti, mena he ngawari noa iho i te tuku noa i te aho.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Mena kei raro katoa matou i te rahinga me te whanui iti, ka whakakii i te whanui iti me te aho kua whakaritea + etahi waahanga.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Tuhia te mua purpuru-a hoki te tohia pou-purpuru.
    /// Ko nga Kaitono te kawenga ki te whakarite kia tuhia nga papa-muri i muri i te mea kua oti te whariki.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// E nga wahi whakahōpututia me pā te purpuru.
    /// Kei te kii kua tukuna e te kaiwaea nga waahanga me nga whakaritenga e tika ana, kia kore ai e warewarehia te `self.precision`.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // mo te tohu-mōhio kore purpuru, hoatu tatou te tohu tuatahi, ka tikanga me te mea i tatou kahore tohu i te timatanga.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // he tohu tonu te tuatahi
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // tango i te tohu i te wahi whakahōpututia
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // toe wahi haere i roto i te tukanga purpuru noa.
            let len = formatted.len();
            let ret = if width <= len {
                // kahore purpuru
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // Ko te take noa tenei, me tango tatou i te pokatata
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // Kei te whakamahia ana tēnei mō te `flt2dec::Part::Num` me `flt2dec::Part::Copy`: SAFETY.
            // te reira haumaru ki te whakamahi mō te `flt2dec::Part::Num` mai nga char ko `c` i waenganui `b'0'` ko `b'9'`, i te tikanga `s` he tika UTF-8.
            // Akene he pai ki te whakamahi mo te `flt2dec::Part::Copy(buf)` mai i te mea ko te `buf` he ASCII maamaa, engari ka taea e tetahi te tuku i tetahi uara kino mo te `buf` ki te `flt2dec::to_shortest_str` na te mea he mahi a te iwi.
            //
            // FIXME: Whakatauhia mēnā ka hua te UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 kore
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Tuhi etahi raraunga ki te moka whāriki i roto i roto i tenei formatter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Ko te ōrite ki tenei:
    ///         // tuhi! (kaitahuri, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Tuhi etahi mōhiohio whakahōputu ki tenei tauira.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Flags mō te hōputu
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Pūāhua whakamahia rite 'fill' nga wa i reira he tīaroaro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Ka whakatauhia e maatau ki te taha katau me ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Kara tohu te mea i tonoa puka o tīaroaro.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// He whanui kua tohua ki te whanui tau e tika ana kia puta te putanga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Mena kua tae mai he whanui, ka whakamahia e maatau
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Kore mahi matou tetahi mea motuhake
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// He tika kua tohua mo nga momo nama.
    /// Ano hoki, ko te whanui nui mo nga momo aho.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Mena kua tika ta maatau, ka whakamahia e maatau.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Kore tatou taunoa ki 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Ka whakatau mena kua tohua te haki `+`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Ka whakatau mena kua tohua te haki `-`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // hiahia ana koe i tētahi tohu tango?Kia kotahi!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Ka whakatau mena kua tohua te haki `#`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Whakatau ki te i tohua te haki `0`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Ka waihohia e maatau nga waahanga a te kaitahuri.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Whakatauhia he aha te API a-iwi e hiahia ana maatau mo enei haki e rua.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Ka hangaia he kaihanga [`DebugStruct`] i hangaia hei awhina i te hanganga [`fmt::Debug`] mo nga waahanga.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Ka waihanga te kaihanga `DebugTuple` hangaia ki te āwhina ki te hanga o implementations `fmt::Debug` mō structs tuple.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Ka hangaia he kaihanga `DebugList` kua hoahoatia hei awhina i te hanganga o nga mahi `fmt::Debug` mo nga hanganga raarangi-rite.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Ka waihanga te kaihanga `DebugSet` hangaia ki te āwhina ki te hanga o implementations `fmt::Debug` mō te huinga-rite hanganga.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// I roto i tenei tauira matatini ake, te whakamahi i tatou [`format_args!`] ko `.debug_set()` ki te hanga i te rārangi o ringa kēmu:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Ka hangaia he kaihanga `DebugMap` kua hoahoatia hei awhina i te hanganga o nga mahi `fmt::Debug` mo nga hanga mahere-rite.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Nga whakaritenga o te whakatakotoranga matua traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Mena ka mawhiti a char, peera te tuara o muri ka tuhi, ka kore e peke
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Ko te haki kē kua tirohia e LowerHex he mea motuhake-he tohu mena ka kuhimua ki te 0x.
        // whakamahi tatou ki te mahi i te reira i roto i mehemea kahore ki te kore ranei whakawhānui, a ka noa'tu whakaturia reira ki te tiki i te kuhimua.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Whakatinanatanga o Display/Debug mo ngā momo matua

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // Kei te mutably tono te RefCell kia kore e taea e tatou e titiro ki tona uara konei.
                // Whakaatuhia he waahi.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Mena i tatari koe kia tae mai nga whakamatautau, tirohia te konae core/tests/fmt.rs, he maama ake i te hanga i nga hanganga rt::Piece katoa i konei.
//
// He hoki whakamātautau i roto i te Tiritiri crate, mo te hunga e tohatoha hiahia.