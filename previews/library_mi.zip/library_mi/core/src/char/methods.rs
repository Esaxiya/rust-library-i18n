//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Ko te wāhi tino teitei rawa te tika waehere e taea whai i te `char`.
    ///
    /// Ko te `char` he [Unicode Scalar Value], te tikanga he [Code Point] tera, engari ko nga mea noa kei roto i tetahi waahanga.
    /// `MAX` Ko te tohu waehere whaimana teitei he [Unicode Scalar Value] whaimana.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` whakamahia () te i roto i te Waehereao ki tohu i te hapa wetewaehere.
    ///
    /// Ka puta, hei tauira, i te hoatutanga o te paita UTF-8 kino-hangaia ki te [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Ko te putanga o [Unicode](http://www.unicode.org/) kei runga nga waahanga Unicode o nga tikanga `char` me te `str`.
    ///
    /// Ko nga putanga hou o Unicode ka tukuna i nga waa katoa ka mutu ka whakahouhia nga tikanga katoa i te wharepukapuka paerewa, kei i te Unicode anake.
    /// Na reira te whanonga o etahi tikanga `char` ko `str` me te uara o tenei taimau taui i runga i te wā.
    /// Kaore tenei * e kiia ana he whakarereke pakaru tenei.
    ///
    /// Kua whakamaramahia te mahinga tatauranga putanga i te [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Ka waihangahia he tohu i runga i nga tohu waehere whakawaehere UTF-16 i te `iter`, ka whakahoki i nga taapiri takirua hei `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Ka taea te tango i te pūwetewaehere lossy mā te whakakapi i ngā hua `Err` me te pūāhua whakakapinga:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Ka huri i te `u32` ki te `char`.
    ///
    /// Kia mahara ko nga `char`s katoa he whaimana [`u32`] s, a ka taea te tuku ki tetahi me
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Heoi, e kore te mea pono te whakamuri: e kore katoa tika [`u32`] s e tika`char`s.
    /// `from_u32()` ka hoki mai `None` ki te kahore te mea te tāuru he uara tika mo te `char`.
    ///
    /// Hoki te putanga haumaru o tenei mahi i waihotia enei arowhai, kite [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Whakahoki i te `None` i te mea ehara te whakauru i te `char` whaimana:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Ka huri i te `u32` ki te `char`, kaore e aro ki te mana.
    ///
    /// Kia mahara ko nga `char`s katoa he whaimana [`u32`] s, a ka taea te tuku ki tetahi me
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Heoi, e kore te mea pono te whakamuri: e kore katoa tika [`u32`] s e tika`char`s.
    /// `from_u32_unchecked()` ka warewarehia tenei, ka maka matapo ki te `char`, ka kore pea ka he.
    ///
    ///
    /// # Safety
    ///
    /// Kaore i te haumaru tenei mahi, na te mea ka taea pea te hanga i nga uara `char` hē.
    ///
    /// Hoki te putanga haumaru o tenei mahi, kite te mahi [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // HAUMARU: Me e tautokona ake te kirimana haumaru i te kaiwaea.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Tahuri ai i te mati i te rauropi kua tohaina ki te `char`.
    ///
    /// Kei te te tahi mau taime hoki i huaina te 'radix' konei he 'base'.
    /// Ko te radix o te rua e tohu ana i te tau taarua, te rerenga tekau, ira tekau, me te raurau tekau ma ono, hexadecimal, hei whakaatu i etahi uara noa.
    ///
    /// E tautokona radices noho.
    ///
    /// `from_digit()` ka hoki mai a `None` mena kaore te whakaurunga i te mati i te rauropi kua tohaina.
    ///
    /// # Panics
    ///
    /// Panics mena ka tukuna he radix nui ake i te 36.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Ira 11 Ko te mati kotahi i roto i te turanga 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Hoki mai `None` ka kore te mea te tāuru he mati:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Ma te whakawhiti i te rauropi nui, ka puta he panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Arowhai ki te ko te `char` he mati i roto i te pakiaka homai.
    ///
    /// Kei te te tahi mau taime hoki i huaina te 'radix' konei he 'base'.
    /// Ko te radix o te rua e tohu ana i te tau taarua, te rerenga tekau, ira tekau, me te raurau tekau ma ono, hexadecimal, hei whakaatu i etahi uara noa.
    ///
    /// E tautokona radices noho.
    ///
    /// Whakaritea ki [`is_numeric()`], tenei mahi anake whakaae nga pūāhua `0-9`, `a-z` ko `A-Z`.
    ///
    /// 'Digit' kua tautuhia hei kohinga noa iho:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Mo te maarama ake o te 'digit', tirohia te [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics mena ka tukuna he radix nui ake i te 36.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Ma te whakawhiti i te rauropi nui, ka puta he panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Tahuri ai te `char` ki te mati i roto i te pakiaka homai.
    ///
    /// Kei te te tahi mau taime hoki i huaina te 'radix' konei he 'base'.
    /// Ko te radix o te rua e tohu ana i te tau taarua, te rerenga tekau, ira tekau, me te raurau tekau ma ono, hexadecimal, hei whakaatu i etahi uara noa.
    ///
    /// E tautokona radices noho.
    ///
    /// 'Digit' kua tautuhia hei kohinga noa iho:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Whakahokia `None` ki te kore e te `char` faahiti ki te mati i roto i te pakiaka homai.
    ///
    /// # Panics
    ///
    /// Panics mena ka tukuna he radix nui ake i te 36.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Ma te paahitanga o nga hua-kore ka huakore:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Ma te whakawhiti i te rauropi nui, ka puta he panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kua wehea te waehere ki konei hei whakapai ake i te tere whakahaere mo nga keehi i te wa e mau tonu ana te `radix` me te 10 iti iho ranei
        //
        let val = if likely(radix <= 10) {
            // Ki te kore te mati, ka kia hanga he rahi maha atu pakiaka.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Returns he iterator e hua i te hautekaumāono Unicode rere o te huru rite `char`s.
    ///
    /// Ma tenei ka mawhiti nga tohu me te taarua Rust o te ahua `\u{NNNNNN}` kei reira a `NNNNNN` he whakaaturanga hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Ka rite ki te iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mā te tika `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// He orite enei e rua ki:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Ma te `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // ranei-raa 1 āta whakarite e hoki c==0 nga computes waehere e kia kia tāngia kotahi mati me (e ko te taua) mawehe te (31, 32) underflow
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // te taupū o te mati hex tino nui
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// He putanga whanui o `escape_debug` e ahei ana ki te mawhiti i nga waehere Whanui o te Grapheme.
    /// Tenei taea ki tatou te whakahōputu pūāhua rite nonspacing tohu pai ka kei i te tīmatanga o te aho ratou.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Whakahoki ai i te kaitahuri e whakaputa mai ana i te waehere mawhiti tuuturu o te kiripuaki hei `char`s.
    ///
    /// Tenei ka mawhiti te pūāhua rite ki nga implementations `Debug` o `str` `char` ranei.
    ///
    ///
    /// # Examples
    ///
    /// Ka rite ki te iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mā te tika `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// He orite enei e rua ki:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Ma te `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Whakahoki ai i te kaitahuri e whakaputa mai ana i te waehere mawhiti tuuturu o te kiripuaki hei `char`s.
    ///
    /// whiriwhiri te taunoa te ki te rītaha ki te whakaputa pūrite e te hunga ture i roto i te whānuitanga o ngā reo, tae atu C++ 11 me reo C-whānau rite.
    /// Ko te ture tangohia e:
    ///
    /// * mawhiti Ripa te rite `\t`.
    /// * Ko te hokinga mai o te hariata ka mawhiti ko te `\r`.
    /// * Kua mawhiti mai te kai raina hei `\n`.
    /// * Ko te korero kotahi kua mawhiti hei `\'`.
    /// * Ko te utu taarua kua mawhiti hei `\"`.
    /// * mawhiti rītahamuri te rite `\\`.
    /// * Ko nga tohu o te ASCII 'ka taea te taarua `0x20` .. `0x7e` whakauru kaore i mawhiti.
    /// * Ko etahi atu tohu ka whakawhiwhia ki te Unicode hexadecimal mawhiti;kite [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Ka rite ki te iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mā te tika `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// He orite enei e rua ki:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Ma te `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Whakahokia te maha o ngā paita e hiahia tenei `char` ki te whakawaeheretia i UTF-8.
    ///
    /// Ko taua maha paita kei waenga tonu i te 1 me te 4, whakauru.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Ko te momo `&str` e kii ana ko UTF-8 nga mea o roto, a na reira ka taea e taatau te whakariterite i te roa mo te roa mena ka whakaatuhia mai ia tohu tohu he `char` vs i te `&str` ano:
    ///
    ///
    /// ```
    /// // rite Ngā pū
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // e rua taea te māngai rite e toru paita
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // hei &str, ka whakawaeheretia enei e rua ki te UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // Ka taea e kite tatou e tangohia e ratou e ono ngā paita katoa ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... rite tonu ki te &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Whakahokihia te maha o nga waehere waehere moka-16 e hiahiatia ana e tenei `char` mena ka whakauruhia ki te UTF-16.
    ///
    ///
    /// Tirohia te te tuhinga mō te [`len_utf8()`] hoki atu whakamārama o tenei ariā.
    /// Ko tenei mahi he whakaata, engari mo UTF-16 kaore ko UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Ka whakawaeherehia tenei ahua hei UTF-8 ki roto i te paita paita kua tohaina mai, ana ka whakahoki i te waahanga o te moenga kei roto te tohu whakawaehere.
    ///
    ///
    /// # Panics
    ///
    /// Panics ki te kore e nui te peera.
    /// Ko te kohinga roa e wha he nui hei whakawaehere i tetahi `char`.
    ///
    /// # Examples
    ///
    /// I roto i rua o enei tauira, 'ß' e rua bytes ki whakawaehere.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// He putea iti rawa:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SAFETY: `char` ehara i te kaiwhakauru, na he tika tenei UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Encodes tenei huru rite UTF-16 ki te whakaratohia `u16` te moka, a ka hoki te subslice o te moka e kei te pūāhua whakawaeheretia.
    ///
    ///
    /// # Panics
    ///
    /// Panics ki te kore e nui te peera.
    /// He moka o te roa 2 he nui nui ki te whakawaehere tetahi `char`.
    ///
    /// # Examples
    ///
    /// I roto i rua o enei tauira, '𝕊' e rua, u16`s ki whakawaehere.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// He putea iti rawa:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Returns `true` ki te he te taonga `Alphabetic` tenei `char`.
    ///
    /// `Alphabetic` Kei te whakaahuatia i roto i te Chapter (Āhuatanga Pūāhua) 4 o te [Unicode Standard] ka tohua i roto i te [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // te aroha he maha nga mea, engari ehara i te mea pūrārangi
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Returns `true` ki te he te taonga `Lowercase` tenei `char`.
    ///
    /// `Lowercase` Kei te whakaahuatia i roto i te Chapter (Āhuatanga Pūāhua) 4 o te [Unicode Standard] ka tohua i roto i te [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Ko te ngā hōtuhi Chinese, me te tuhi e kore e whai take, a pera:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Whakahoki `true` mena kei tenei `char` te rawa `Uppercase`.
    ///
    /// `Uppercase` Kei te whakaahuatia i roto i te Chapter (Āhuatanga Pūāhua) 4 o te [Unicode Standard] ka tohua i roto i te [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Ko te ngā hōtuhi Chinese, me te tuhi e kore e whai take, a pera:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Returns `true` ki te he te taonga `White_Space` tenei `char`.
    ///
    /// `White_Space` kua tohua i te [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // he waahi kaore e pakaru
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Whakahoki `true` mena ka makona tenei `char` ahakoa [`is_alphabetic()`], [`is_numeric()`] ranei.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Returns `true` ki te he tenei `char` te kāwai whānui mō waehere mana.
    ///
    /// Ko nga waehere whakahaere (tohu tohu me te waahanga whanui o `Cc`) e whakaahuahia ana i te Upoko 4 (Nga Taonga Tohu) o te [Unicode Standard] ka tohua i te [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // U + 009C, KAUPAPA WHAKAMUTUNGA
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Whakahoki `true` mena kei tenei `char` te rawa `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` kua whakaahuahia i te [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] a kua tohua i te [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Whakahokia `true` ki he tetahi o te kāwai whānui mō ngā tau tenei `char`.
    ///
    /// Ko nga waahanga whaanui mo nga nama (`Nd` mo nga mati a tekau, `Nl` mo nga tohu taatai-penei i te reta, me te `No` mo etahi atu taatai nama) kua tohua i te [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Returns he iterator e hua te mahere pūriki o tenei `char` rite tetahi atu ranei
    /// `char`s.
    ///
    /// Mena kaore he maapara iti a tenei `char`, ka tukuna ano e te kaitautoko te `char` ano.
    ///
    /// Mena ko tenei `char` tetahi mahere iti-kotahi-ma-iti i hoatuhia e te [Unicode Character Database][ucd] [`UnicodeData.txt`], ka tukuna e te miiti te `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Mena ko tenei `char` e hiahia ana kia whai whakaaro motuhake (hei tauira, kia `char` maha) ka tukuna e te kaitohu te`char` (s) na [`SpecialCasing.txt`] i tuku.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ma tenei mahinga e mahi he maheretanga kore me te tuitui.Arā, he motuhake te hurihanga mai i te horopaki me te reo.
    ///
    /// I roto i te [Unicode Standard], Chapter 4 (Āhuatanga Pūāhua) e kōrero ana take mahere i roto i te whānui me te matapaki Chapter 3 (Conformance) te hātepe papatono taunoa mo faafariuraa take.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Ka rite ki te iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mā te tika `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// He orite enei e rua ki:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Ma te `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // I etahi wa ka nui ake te hua i te kotahi:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Pūāhua kore e e whai e rua pūmatua me faafariu pūriki ki a ratou ano.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Returns he iterator e hua te mahere pūmatua o tenei `char` rite tetahi atu ranei
    /// `char`s.
    ///
    /// Ki te kore e tenei `char` i te mahere te pūmatua, hua te iterator te taua `char`.
    ///
    /// Ki te mea he mahere pūmatua tetahi-ki-tetahi homai e te [Unicode Character Database][ucd] [`UnicodeData.txt`], nga loto iterator e `char` tenei `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Mena ko tenei `char` e hiahia ana kia whai whakaaro motuhake (hei tauira, kia `char` maha) ka tukuna e te kaitohu te`char` (s) na [`SpecialCasing.txt`] i tuku.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ma tenei mahinga e mahi he maheretanga kore me te tuitui.Arā, he motuhake te hurihanga mai i te horopaki me te reo.
    ///
    /// I roto i te [Unicode Standard], Chapter 4 (Āhuatanga Pūāhua) e kōrero ana take mahere i roto i te whānui me te matapaki Chapter 3 (Conformance) te hātepe papatono taunoa mo faafariuraa take.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Ka rite ki te iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mā te tika `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// He orite enei e rua ki:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Ma te `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // I etahi wa ka nui ake te hua i te kotahi:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Pūāhua kore e e whai e rua pūmatua me faafariu pūriki ki a ratou ano.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Note i runga i tauwāhi
    ///
    /// I roto i te Turkish, e rima ngā momo hei utu o rua te ōrite o 'i' i Latin:
    ///
    /// * 'Dotless': I/ı, i etahi wa ka tuhia ï
    /// * 'Dotted': İ/i
    ///
    /// Kia mahara he rite tonu te puriki maakuku 'i' me te Riiki.Na reira:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Ko te uara o `upper_i` konei whakawhirinaki i runga i te reo o te kuputuhi: ki te kei i `en-US` tatou, kia waiho ai `"I"`, engari ki te kei i `tr_TR` tatou, kia waiho ai `"İ"`.
    /// `to_uppercase()` e kore e tango i tenei ki pūkete, me pera:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// pupuri puta noa i nga reo.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Ka tirohia mena kei roto te uara i te awhe ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Ka hangaia he kape o te uara kei roto i te ASCII keehi o runga.
    ///
    /// Ko nga reta ASCII 'a' ki 'z' ka maherehia ki te 'A' ki te 'Z', engari ko nga reta kore ASCII kaore i whakarereke.
    ///
    /// Hei whakarahi ake i te uara ki te waahi, whakamahia te [`make_ascii_uppercase()`].
    ///
    /// Hei taapiri i nga tohu ASCII i tua atu i nga tohu-kore ASCII, whakamahia te [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Ka hangaia he kape o te uara kei roto i te ASCII o te keeki iti ake.
    ///
    /// Ko nga reta ASCII 'A' ki 'Z' ka maherehia ki te 'a' ki te 'z', engari ko nga reta kore ASCII kaore i whakarereke.
    ///
    /// Hei pūriki te uara i-wahi, te whakamahi i [`make_ascii_lowercase()`].
    ///
    /// Hei pūriki pūāhua ASCII i roto i te tua ki pūāhua ASCII-kore, te whakamahi i [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Ka tirohia e rua nga uara ko te ASCII take-korekore.
    ///
    /// Ōrite ki `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Tahuri ai tenei momo ki tona ASCII ōrite take runga i-wahi.
    ///
    /// Ko nga reta ASCII 'a' ki 'z' ka maherehia ki te 'A' ki te 'Z', engari ko nga reta kore ASCII kaore i whakarereke.
    ///
    /// Hei whakahoki i tetahi uara taapiri hou me te kore e whakarereke i tetahi, whakamahia [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Ka huri i tenei momo ki tona ASCII take iti iho e rite ana i te waahi.
    ///
    /// Ko nga reta ASCII 'A' ki 'Z' ka maherehia ki te 'a' ki te 'z', engari ko nga reta kore ASCII kaore i whakarereke.
    ///
    /// Hei hoki i tētahi uara lowercased hou i waho te whakakē i te kotahi ngā, te whakamahi i [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Arowhai ki te ko te uara i te pūāhua pūrārangi ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ranei
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Arowhai ki te ko te uara i te ASCII pūmatua pūāhua:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Arowhai ki te ko te uara i te pūāhua ASCII pūriki:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Arowhai ki te ko te uara i te pūāhua ASCII ārepa:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ranei
    /// - U + 0061 'a' ..=U + 007A 'z', ranei
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Arowhai ki te ko te uara i te mati ASCII ira:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Arowhai ki te ko te uara i te mati ASCII hautekaumāono:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', or
    /// - U + 0041 'A' ..=U + 0046 'F', or
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Arowhai ki te ko te uara i te pūāhua ASCII tohutuhi:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, ranei
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, ranei
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, ranei
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Ka tirohia mena ko te uara he tohu whakairoiro ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Arowhai ki te ko te uara i te pūāhua ASCII mokowāmā:
    /// U + 0020 WĀHI, U + 0009 Whakapae TAB, U + 000A LINE KAI A, U + PUKA 000C KAI A, ranei U + 000D Tuhinga RETURN.
    ///
    /// Ka whakamahia e Rust [definition of ASCII whitespace][infra-aw] te WhatWG raro koutou Paerewa o.He maha ano nga whakamaaramatanga e whakamahia whanui ana.
    /// Hoki tauira, [the POSIX locale][pct] ngā U + 000B Poutū TAB me te nga pūāhua runga ake katoa, engari-i te rawa taua specification-[te ture taunoa mo "field splitting" i te Bourne shell][RWP] whakaaro *anake* WĀHI, Whakapae TAB, me LINE FEED hei maatea.
    ///
    ///
    /// Ki te kei te tuhi koe i tētahi hōtaka e ka tukatuka te hōputu kōnae tīariari, tirohia ko te aha whakamāramatanga o taua hōputu o mokowāmā ko i mua i te whakamahi i tenei mahi.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Ka tirohia mena ko te uara he tohu whakahaere ASCII:
    /// U + 0000haora NUL ..=U + 001F KAUPAPA Whakawehe, U + 007F ranei DELETE.
    /// Kia mahara ko te nuinga o nga tohu maamaa ASCII he kaitohu mana, engari kaore ko te WĀHI.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Ka whakawaehere i te uara u32 noa hei UTF-8 ki roto i te paita paita kua tohaina mai, ana ka whakahoki i te waahanga o te moenga kei roto te tohu whakawaehere.
///
///
/// Rerekē `char::encode_utf8`, kakau ano hoki tenei tikanga codepoints i roto i te whānuitanga a Maata.
/// (Ko te hanga `char` i te awhe takirua he UB.) Ko te hua he [generalized UTF-8] engari kaore i te UTF-8 whaimana.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics ki te kore e nui te peera.
/// Ko te kohinga roa e wha he nui hei whakawaehere i tetahi `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Ka whakawaehere i te uara u32 mauruuru hei UTF-16 ki roto i te raima `u16` kua whakawhiwhia, a ka whakahokia mai ano te waahanga o te moenga kei roto te tohu whakawaehere.
///
///
/// Rerekē `char::encode_utf16`, kakau ano hoki tenei tikanga codepoints i roto i te whānuitanga a Maata.
/// (Te hanga i te `char` i te awhe takirua he UB.)
///
/// # Panics
///
/// Panics ki te kore e nui te peera.
/// He moka o te roa 2 he nui nui ki te whakawaehere tetahi `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SAFETY: ka tirohia e ia ringa mena e ranea ana nga waahanga hei tuhi
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Ka taka te BMP
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Ka pakaru te rererangi taapiri hei kai-whakakapi.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}