//! Nga uara mangere me te whakaoho tuatahi kotahi o nga tuhinga pateko.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// He pūtau e taea te tuhituhi ki kotahi anake.
///
/// Kaore i rite ki te `RefCell`, ko te `OnceCell` anake e whakarato ana i nga tohutoro `&T` toha ki tona uara.
/// Rerekē `Cell`, e kore e he `OnceCell` rapua e tārua whakakapi i te uara ki te uru i te reira ranei.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Kaiwhiwhi: i tuhia mai i te wa kotahi.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Hangaia ai he pūtau putu hou.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Ka whiwhi tohutoro ki te uara matua.
    ///
    /// Whakahokia `None` ki he kau te pūtau.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // HAUMARU: Haumaru tika ki `pūmau o inner`
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Whiwhi te tohutoro mutable ki te uara whāriki.
    ///
    /// Whakahokia `None` ki he kau te pūtau.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // SAFETY: Haumaru na te mea he urunga motuhake ta tatou
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Ka tautuhi te tirotiro o te pūtau ki `value`.
    ///
    /// # Errors
    ///
    /// hoki tēnei aratuka `Ok(())` ki he kau, me `Err(value)` te pūtau, ki te ki tonu i reira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // HAUMARU: Haumaru no te mea e kore tatou e taea i inaki tarewa mutable
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // HAUMARU: Ko anake te wahi i reira whakaturia matou te mokamoka, kahore iwi tenei
        // na te reentrancy/concurrency e taea ana, a kua tirohia e maatau ko te mokamoka he `None` i tenei wa, na ko tenei tuhinga e pupuri ana i te hunga o roto.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Riro te tirotiro o te pūtau, arawhiti reira ki `f` ki he kau te pūtau.
    ///
    /// # Panics
    ///
    /// Ki te `f` panics, kua whakatipuria te panic ki te kaiwaea, a ka noho tonu te pūtau Korearawhiti.
    ///
    ///
    /// Ko reira he hapa ki reentrantly arawhiti te pūtau i `f`.Ko te mahi i tenei ka puta he panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Riro te tirotiro o te pūtau, arawhiti reira ki `f` ki he kau te pūtau.
    /// Ki te takoto kau ana, me te `f` rahua te pūtau, hoki he hapa te.
    ///
    /// # Panics
    ///
    /// Ki te `f` panics, kua whakatipuria te panic ki te kaiwaea, a ka noho tonu te pūtau Korearawhiti.
    ///
    ///
    /// Ko reira he hapa ki reentrantly arawhiti te pūtau i `f`.Ko te mahi i tenei ka puta he panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Note e *te tahi mau momo* o te arawhiti reentrant kia arahi ki UB (kite `reentrant_init` whakamātautau).
        // E whakapono ana ahau ko te tango noa i tenei `assert`, i te pupuri i te `set/get` he pai, engari te ahua pai ki a panic, kaua ki te whakamahi puku i te uara tawhito.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Pau te pūtau, e hoki ana i te uara takaia.
    ///
    /// Whakahokia `None` ki he kau te pūtau.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Na te mea `into_inner` he `self` te uara, ka whakamanahia e te kaiwhakaputa kaore i te nama i tenei wa.
        // Na he pai ki te neke atu i te `Option<T>`.
        self.inner.into_inner()
    }

    /// E te uara i o tenei `OnceCell`, neke te reira hoki ki te āhua Korearawhiti.
    ///
    /// Kaore he painga ka hoki mai te `None` mena kaore ano kia tiimata te `OnceCell`.
    ///
    /// Ka whakamanahia te ahuru ma te tono tono kia huri.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// He uara arawhitia nei i runga i te whai wāhi tuatahi.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   rite arawhiti
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Ka waihanga i tetahi uara mangere hou me te mahi arawhiti.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Taruke te aro mātai o tenei uara mangere, me te hoki te tohutoro ki te hua.
    ///
    ///
    /// Ko ōrite ki te impl `Deref` tenei, engari he mārama.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Ka waihanga te uara mangere hou mā te whakamahi i `Default` rite te mahi e arawhiti.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}