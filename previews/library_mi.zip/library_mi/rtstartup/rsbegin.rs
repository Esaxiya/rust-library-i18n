// rsbegin.o ko rsend.o Ko te pera ka karanga "compiler runtime startup objects".
// Kei roto ratou waehere e hiahiatia ana ki te arawhiti tika te wāhaere taupatupatu.
//
// A, no te hono i te whakapakoko whakamahi dylib ranei te, waehere kaiwhakamahi katoa me whare pukapuka e "sandwiched" i waenganui i enei kōnae ahanoa e rua, na waehere ranei raraunga i rsbegin.o hei tuatahi i roto i nga wāhanga tēnā o te whakapakoko, te mea waehere me raraunga i rsend.o riro te hunga o muri.
// Ka taea tenei paanga ki te tuu tohu ki te tiimatanga, ki te mutunga ranei o tetahi waahanga, me te whakauru i nga pane me nga hiku e hiahiatia ana.
//
// Kia mahara ko te tohu whakauru whakauru kei roto i te ahanoa whakaoho C (he `crtX.o` te ingoa), ka karanga i nga hokinga whakaoho mo etahi atu waahanga waahanga (kua rehitatia ma tetahi atu waahanga ahua motuhake).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Tohu timata o te anga tāpae wāhanga info mālōlō
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // wāhi raraku mō ā pukapuka-tauhi o unwinder.
    // Kua tautuhia tenei hei `struct object` i te $ GCC/whakaahuru-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // info mālōlō registration/deregistration ngā mahinga.
    // Tirohia nga tuhinga o libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // rēhita whakamoe korero mo te tiimata o te kōwae
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // te rēhita i runga i whakaweto
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-motuhake rēhita init/uninit mahi
    pub mod mingw_init {
        // Ko nga mea whakaoho a MinGW (crt0.o/dllcrt0.o) ka tono i nga kaihanga o te ao i nga waahanga .ctors me .dtors i te tiimata me te putanga.
        // I roto i te take o PHH, meatia tenei e ka utaina te DLL te ka wetekina ana.
        //
        // Ma te kaitautoko e wehe nga waahanga, e tohu ana kei te pito o te raarangi a tatou waeatanga hoki.
        // Mai i te mea ka rere whakamuri nga kaihanga, ma tenei e mohio ko o taatau piiraa ko te tuatahi me te whakamutunga e mahia ana.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors *: . Callbacks C arawhiti
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .tākuta. *: C waeatanga waea whakamutu
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}