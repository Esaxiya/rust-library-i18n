//! He wharepukapuka tautoko ma nga kaituhi tonotono ina e whakatau ana koe i nga tonotono hou.
//!
//! Ko tenei wharepukapuka, na te tohatoha paerewa, e whakarato nga momo e pau ana i nga waahanga o nga tikanga whakamaramatanga kua tautuhia hei mahi penei i te macros `#[proc_macro]`, me nga huanga tonotono `#[proc_macro_attribute]` me nga huanga whakaheke ritenga`#[proc_macro_derive]`.
//!
//!
//! Tirohia te [the book] mo etahi atu.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Te whakatau mena kua uru mai te proc_macro ki te hotaka e whakahaere ana i tenei wa.
///
/// Ko te proc_macro crate he mea noa hei whakamahi i roto i te whakamahinga o nga tohutao whakahaere.nga mahi katoa i roto i tenei crate panic ki te karanga i waho o te tonotono ngā, pērā i i te hōtuhi hanga ranei whakamātautau wae noa pūtakerua Rust ranei.
///
/// Me te whakaaro ki nga wharepukapuka Rust kua hoahoatia hei tautoko i nga keehi tonotono me te kore tonotono, ka tukuna e `proc_macro::is_available()` tetahi huarahi kore-panui ki te mohio mena kei te waatea nga hanganga e hiahiatia ana hei whakamahi i te API o proc_macro.
/// Returns pono ki te karanga i roto o te tonotono ngā, teka ki te karanga i tetahi atu takirua.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Ko te momo matua na crate tenei, hei tohu mo te rerenga tokens, peera ranei, he raupapa token rakau.
/// Ko te momo whakarato atanga mō te iterating runga i aua rakau token me, hei kōrero, kohikohi he maha o nga rakau token ki tetahi awa.
///
///
/// Ko e rua te kōkuhu me te whakaputa o `#[proc_macro]`, `#[proc_macro_attribute]` ko `#[proc_macro_derive]` whakamāramatanga tenei.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// hoki Hapa i `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Whakahokia te `TokenStream` kau kei roto kahore rakau token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Arowhai ki te he kau tenei `TokenStream`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Ngana ki te wawahi i te aho ki te tokens me te wehe i aua tokens ki te awa token.
/// Ka ngoikore pea mo nga take maha, hei tauira, mena kei te aho kei roto i nga kaiwhakangungu taurite, i nga taera ranei kaore i te reo.
///
/// tokens katoa i roto i te awa parse tiki `Span::call_site()` Tīpae.
///
/// NOTE: te tahi mau hapa e meinga panics hei utu o hoki mai `LexError`.Ka rahuitia e matou te whakarereke i enei he ki te 'LexError`s a muri ake nei.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, ko te piriti anake e whakarato ana i te `to_string`, whakatinana i te `fmt::Display` e pa ana ki a ia (ko te whakamuri o te whanaungatanga i waenganui i te mea e rua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Ka taarua i te awa token hei aho e kiia ana ka kore e taea te whakahoki ki roto i te awa token (waahi modulo), haunga pea ko te `TokenTree: : Nga Ropu` me nga kaiwhakawhiwhi `Delimiter::None` me nga nama kino kino.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Ka taarua i te token i te ahua waatea hei tango
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Ka waihangahia he awa token e mau ana i tetahi rakau token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Kohikohia te maha o nga rakau token ki roto i te awa kotahi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// He mahinga "flattening" i runga i nga awa token, ka kohia nga rakau token mai i nga awa token maha ki roto i te awa kotahi.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Whakamahia te whakatinanatanga papaitia taea if/when.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// taipitopito Public whakatinanatanga mo te momo `TokenStream`, pērā i iterators.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// He iterator mo ``TokenTree`s o TokenStream`.
    /// Ko te taarua he "shallow", hei tauira, kaore e hoki ano te kaitahuri ki nga roopu iti, ka whakahoki i nga roopu katoa hei rakau token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` ka whakaae ki te tokens tauutuutu ka hora ki roto i te `TokenStream` e whakaahua ana i te whakauru.
/// Hei tauira, ka hua `quote!(a + b)` he faaiteraa, e, ka arotakea, Ka hangaia e te `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// mahi Unquoting te ki `$`, ka mahi i tango i te tero e i muri kotahi rite te wā unquoted.
/// Hei faahiti `$` iho, te whakamahi i `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// He rohe waehere waehere, me nga korero roha tonotono.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Ka waihanga te `Diagnostic` hou ki te `message` homai i te whanganga `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// He awhe ka whakatau i te pae whakamaramatanga tonotono.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Te awhe o te tono mo te tonotono mahinga o naianei.
    /// Ka whakatau pūwehe hanga ki tenei whanganga me te mea i tuhituhia e ratou tika i te wāhi tonotono karanga (akuaku karanga-pae) me ētahi atu waehere i te pae karanga tonotono ka taea ki te tirohia ki a ratou rite te pai.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// He awhe e whakaatu ana i te akuaku `macro_rules`, ana i etahi waa ka whakatau i te waahi whakamaramatanga tonotono (taurangi rohe, tapanga, `$crate`) ana i etahi waa kei te pae waea tonotono (nga mea katoa).
    ///
    /// tangohia te tauwāhi whanganga te i te karanga-pae.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Ko te konae putake taketake e tohu ana tenei whanui.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Ko te `Span` mo te tokens i te whanaketanga tonotono o mua i puta mai ai a `self`, mena ana.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Ko te whanganga hoki te waehere pūtake takenga i hanga `self` i.
    /// Mena kaore i hangaia tenei `Span` mai i etahi atu whakarei tonotono ka rite te uara whakahoki ki te `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Whiwhi te line/column tīmata i roto i te kōnae pūtake mō tenei whanganga.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Whiwhi te line/column mutu i roto i te kōnae pūtake mō tenei whanganga.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Ka waihanga te whanganga hou taka `self` me `other`.
    ///
    /// `None` hoki ki te he `self` me `other` i ngā kōnae rerekē.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Ka waihanga te whanganga hou ki te kōrero i taua line/column rite `self` engari e whakaaroaronga tohu me te mea i reira i `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Ka waihanga te whanganga hou ki te whanonga ingoa taumira taua rite `self` engari ki te mōhiohio line/column o `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Whakataurite ki tīpae kia kite, ki te kei rite ratou.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Whakahokia te kuputuhi pūtake i muri te whanganga.
    /// tiakina ana tenei i te waehere pūtake taketake, tae atu ki ngā wāhi me te kōrero.
    /// Reira hoki noa te hua, ki te hāngai te whanganga ki te waehere pūtake tūturu.
    ///
    /// Note: Ko te hua kitea o te tonotono kia anake whakawhirinaki i runga i te tokens, a kahore i runga i tenei kuputuhi pūtake.
    ///
    /// Ko te hua o tenei mahi ko te kaha pai ki te kia whakamahia mō ngā tātaritanga anake.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Tā i te whanganga i roto i te puka watea mō te patuiro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// He takirua pou-raina e tohu ana i te tiimatanga, i te mutunga ranei o te `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Ko te raarangi tohu-1 i te konae maatauranga ka tiimata, ka mutu ranei te (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Ko te tīwae 0-taupūtia (i roto i te pūāhua UTF-8) i roto i te kōnae pūtake i runga i nei i te tīmata whanganga pito ranei (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Ko te kōnae pūtake o te `Span` homai.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Whiwhi te ara ki tenei kōnae pūtake.
    ///
    /// ### Note
    /// Ki te hangaia te whanganga waehere e pā ana ki tenei `SourceFile` i te taha o te tonotono waho, tenei tonotono, e kore ai tenei e te ara tūturu i runga i te pūnaha.
    /// Whakamahia [`is_real`] ki tirohia.
    ///
    /// Kia mahara hoki, ahakoa ka whakahokia mai e `is_real` te `true`, mena i paahitia te `--remap-path-prefix` i runga i te raina whakahau, ko te huarahi e tukuna ana kaore pea e whai mana.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Whakahoki mai ai i te `true` mena he tino putake tenei putake korero, kaore i hangaia e te whanaketanga o te tonotono o waho.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // He hack tenei tae atu ki te whakatinana i nga waahanga intercrate ka taea ai e maatau he konae punaha tuuturu mo nga waahanga i hangaia i nga tohutō o waho.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// He token kotahi ranei te raupapa whakawehe o rakau token (hei tauira, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// He awa token e karapotia ana e nga kaiwehewehe awhi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// He pūtāutu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// He pūāhua kārawarawatanga kotahi (`+`, `,`, `$`, me ētahi atu).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// He pūāhua mau (`'a'`), string (`"hello"`), tau (`2.3`), me ētahi atu
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Whakahokia ai te whanui o tenei rakau, ka toha atu ki te tikanga `span` o te token kei roto raanei te riipene iti ranei.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Whirihora te whanganga hoki *anake tenei* token.
    ///
    /// Kia mahara mena he 0X tenei Z0token kaore tenei tikanga e whirihora i te awhe o ia tokens o roto, ka tukuna noa ki te tikanga `set_span` o ia momo rereke.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Ka taarua i te rakau token i roto i te ahua pai ki te tango.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ia o enei e te ingoa i roto i te momo struct i roto i te patuiro ahu, na e kore e whakararuraru i ki te kahu anō o indirection
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, ko te piriti anake e whakarato ana i te `to_string`, whakatinana i te `fmt::Display` e pa ana ki a ia (ko te whakamuri o te whanaungatanga i waenganui i te mea e rua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Tānga te rakau token rite te string mahara e te ki hei hoki losslessly convertible ki te rakau taua token (Tīpae modulo), ki te kahore hoki pea `TokenTree: : Group`s ki `Delimiter::None` wewehe me kino pūrite tau.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// He whakawehe token awa.
///
/// ä Kei te `Group` he `TokenStream` karapotia nei e `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Whakaahua ana pehea wehe he raupapa o ngā rākau token te.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// He kaiwehe papu, e ai, mo te tauira, puta a tawhio noa tokens haere mai ana i te "macro variable" `$var`.
    /// He mea nui ki te pupuri i nga mea nui ki nga kaiwhakahaere i roto i nga keehi penei i te `$var * 3` kei reira te `$var` ko te `1 + 2`.
    /// e kore ai ngā wewehe te matū ora roundtrip o te awa token i roto i te aho.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Ka waihanga te `Group` hou ki te kaiwehe i homai ko token awa.
    ///
    /// Ka whakaturia tenei hanganga te whanganga mō tenei rōpū ki `Span::call_site()`.
    /// Hei huri i te whanganga taea e koe te whakamahi i te tikanga `set_span` i raro.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Whakahokia te kaiwehe o tenei `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Hoki te `TokenStream` o tokens e kua wehe i roto i tenei `Group`.
    ///
    /// Note e kore e te awa token hoki ngā hoki i runga i te kaiwehe.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Whakahokia te whanganga mo nga wewehe o tenei awa token, puta noa katoa te `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Whakahokia te whanganga tuhu ki te kaiwehe whakatuwhera o tenei rōpū.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Hoki te whanganga tuhu ki te kaiwehe kati o tenei rōpū.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Whirihora te whanganga mō tenei `wewehe a Group`, engari e kore tona tokens ā-.
    ///
    /// Ko tenei tikanga kaore ** e tautuhia te whanui o te tokens o roto e roopuhia ana e tenei roopu, engari ka tautuhia te waa o te kaiwhakawehe tokens ki te taumata o te `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, ko te piriti anake e whakarato ana i te `to_string`, whakatinana i te `fmt::Display` e pa ana ki a ia (ko te whakamuri o te whanaungatanga i waenganui i te mea e rua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Ka taarua te roopu hei taura kia kore e kore e hoki te huri ki roto i te roopu kotahi (waahi modulo), haunga pea ko te `TokenTree: : Roopu` me nga kaiwehe `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// He `Punct` Ko te pūāhua kārawarawatanga kotahi rite `+`, `-` `#` ranei.
///
/// Ko nga kaiwhakahaere ahua-maha penei i te `+=` e rua nga wa o `Punct` me nga momo `Spacing` kua hoki mai.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Ahakoa aru te `Punct` te tonu e tetahi `Punct` ranei aru e tetahi token mokowāmā ranei.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// hei tauira, `+` ko `Alone` i `+ =`, `+ident` `+()` ranei.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// tauira, `+` ko `Joint` i `+=` `'#` ranei.
    /// I tua atu, ka taea e faahitiraa kotahi `'` uru ki pūwehe ki te puka ra katoa `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Ka waihanga te `Punct` hou i te huru i homai, me te mokowā.
    /// Ko te tautohe `ch` me tohu he tohu tuhi e whakaaehia ana e te reo, mena ka kore te mahi e panic.
    ///
    /// Ka whai i te hoki `Punct` te whanganga taunoa o `Span::call_site()` e taea te anō te whirihora ki te tikanga `set_span` i raro.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Whakahokia ai te uara o tenei tohu tohu hei `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Hoki te mokowā o tenei pūāhua kārawarawatanga, tohu ranei te aru i te reira tonu e tetahi `Punct` i te awa token, kia pea e taea te ngā ratou ki te kaiwhakahaere maha-pūāhua (`Joint`), ranei te aru i te reira e etahi atu token ranei mokowāmā (`Alone`) kia kua tino te kaiwhakahaere mutu.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Whakahokia te whanganga mō tenei pūāhua tohutuhi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Whirihorahia te whanui mo tenei tohu tohu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ko te piriti anake e whakarato ana i te `to_string`, whakatinana i te `fmt::Display` e pa ana ki a ia (ko te whakamuri o te whanaungatanga i waenganui i te mea e rua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Ka taarua i te tohu tuhi hei taura kia kore e kore e kore ka hoki ano ki te huri ano.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// He pūtāutu (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Ka hangaia he `Ident` hou me te `string` i homai me te `span` kua tohua.
    /// Ko te tohenga `string` me tohu he kaiwhakauru mana e whakaaetia ana e te reo (tae atu ki nga kupu matua, hei tauira `self`, `fn` ranei).Te kore, ka panic te mahi.
    ///
    /// Kia mahara ko te `span`, kei rustc tenei wa, kei te whirihora i nga korero akuaku mo tenei kaitohu.
    ///
    /// I tenei wa ka maarama te `Span::call_site()` ki te akuaku "call-site" ko te tikanga ko nga kaitohu i hangaia me tenei awhe ka whakatauhia me te mea i tuhia tika ki te waahi o te waea tonotono, me etahi atu waehere kei te pae waea tonotono ka taea te korero ratou rite te pai.
    ///
    ///
    /// Ko nga waahi penei i te `Span::def_site()` ka ahei ki te whakauru ki te akuaku "definition-site" ko te tikanga ko nga kaitohu i hangaia me tenei awhe ka whakatauhia ki te waahi o te whakamaaramatanga tonotono kaore e taea e etahi atu waehere kei te pae waea tonotono te tuku ki a raatau.
    ///
    /// Na te hiranga o te akuaku o tenei wa, ko tenei kaihanga, kaore i rite ki etahi atu tokens, me kii he `Span` i te hanganga.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Rite `Ident::new`, engari hanga he pūtāutu raw (`r#ident`).
    /// Ko te tautohe `string` kia he pūtāutu whaimana tukua e te reo (tae atu ki ngā kupu, hei tauira `fn`).
    /// Keywords e he pai i roto i wāhanga ara (hei tauira
    /// `self`, `Super`) kahore e tautokona, a ka meinga he panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Whakahoki ai i te whanui o tenei `Ident`, e karapoti ana i te aho katoa i whakahokia mai e [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Whirihora te whanganga o tenei `Ident`, pea te huri tona horopaki akuaku.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ko te piriti anake e whakarato ana i te `to_string`, whakatinana i te `fmt::Display` e pa ana ki a ia (ko te whakamuri o te whanaungatanga i waenganui i te mea e rua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tā i te pūtāutu rite te string e kia hoki losslessly convertible ki te pūtāutu taua.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// He aho mau (`"hello"`), paita string (`b"hello"`), huru (`'a'`), pūāhua paita (`b'a'`), he tau tōpū māngi tau ira ranei ki waho te pīmuri ranei (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// e kore e pūrite Boolean rite `true` me `false` no konei, he ratou `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Ka waihanga te hou suffixed tau tōpū mau ki te uara i tohua.
        ///
        /// Ka hanga tēnei mahi i tētahi tau tōpū rite `1u32` te wahi i te uara tōpū tohua ko te wahi tuatahi o te token me te suffixed ano te tōpu i te mutunga.
        /// Pūrite hanga i ngā tau tōraro e kore e ora a tawhio-haerenga i roto i `TokenStream` aho ranei, me te kia pakaru ai ki e rua tokens (`-` me mo'oni pai).
        ///
        ///
        /// Pūrite hanga i roto i tenei tikanga i te whanganga `Span::call_site()` i taunoa, e taea te whirihora ki te tikanga `set_span` i raro.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Ka waihangahia he taurangi hou kaore ano i taapirihia me te uara kua whakaritea.
        ///
        /// Ma tenei mahi e hanga he tau hei penei i te `1`, ko te uara tau taurangi kua tohua ko te waahanga tuatahi o te token.
        /// Kaore he taapiri i tohua i tenei token, te tikanga ko nga karanga penei i te `Literal::i8_unsuffixed(1)` he rite ki te `Literal::u32_unsuffixed(1)`.
        /// Pūrite hanga i ngā tau tōraro e kore e ora rountrips roto `TokenStream` aho ranei, me te kia pakaru ai ki e rua tokens (`-` me mo'oni pai).
        ///
        ///
        /// Pūrite hanga i roto i tenei tikanga i te whanganga `Span::call_site()` i taunoa, e taea te whirihora ki te tikanga `set_span` i raro.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Ka waihangatia he kiko-kore noa te taunga-rere tere.
    ///
    /// He rite ki te hunga rite `Literal::i8_unsuffixed` wahi tukuna uara o te manu kei te tika ki te token engari whakamahia kahore pīmuri te tenei hanganga, kia kia kia hīkarotia reira ki te waiho i te `f64` muri i roto i te e taupatupatu.
    ///
    /// Pūrite hanga i ngā tau tōraro e kore e ora rountrips roto `TokenStream` aho ranei, me te kia pakaru ai ki e rua tokens (`-` me mo'oni pai).
    ///
    /// # Panics
    ///
    /// Ko te mahi ma tenei ko te rewa i tohua he mutunga, hei tauira mena he mutunga kore NaN ranei ka mahi panic tenei mahi.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Waihangatia ai i te tohu-tere tere taapiri hou.
    ///
    /// Ka hanga tēnei hanganga tētahi pūrite rite `1.0f32` te wahi i te uara tohua ko te wahi i mua o te token ko `f32` ko te pīmuri o te token.
    /// Ko tenei token ka kiia he `f32` i roto i te kaiwhakaputu.
    /// Pūrite hanga i ngā tau tōraro e kore e ora rountrips roto `TokenStream` aho ranei, me te kia pakaru ai ki e rua tokens (`-` me mo'oni pai).
    ///
    ///
    /// # Panics
    ///
    /// Ko te mahi ma tenei ko te rewa i tohua he mutunga, hei tauira mena he mutunga kore NaN ranei ka mahi panic tenei mahi.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Ka waihangatia he kiko-kore noa te taunga-rere tere.
    ///
    /// He rite ki te hunga rite `Literal::i8_unsuffixed` wahi tukuna uara o te manu kei te tika ki te token engari whakamahia kahore pīmuri te tenei hanganga, kia kia kia hīkarotia reira ki te waiho i te `f64` muri i roto i te e taupatupatu.
    ///
    /// Pūrite hanga i ngā tau tōraro e kore e ora rountrips roto `TokenStream` aho ranei, me te kia pakaru ai ki e rua tokens (`-` me mo'oni pai).
    ///
    /// # Panics
    ///
    /// Ko te mahi ma tenei ko te rewa i tohua he mutunga, hei tauira mena he mutunga kore NaN ranei ka mahi panic tenei mahi.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Waihangatia ai i te tohu-tere tere taapiri hou.
    ///
    /// Ka hanga tēnei hanganga tētahi pūrite rite `1.0f64` te wahi i te uara tohua ko te wahi i mua o te token ko `f64` ko te pīmuri o te token.
    /// Ka tonu e hīkarotia tenei token ki he `f64` i roto i te e taupatupatu.
    /// Pūrite hanga i ngā tau tōraro e kore e ora rountrips roto `TokenStream` aho ranei, me te kia pakaru ai ki e rua tokens (`-` me mo'oni pai).
    ///
    ///
    /// # Panics
    ///
    /// Ko te mahi ma tenei ko te rewa i tohua he mutunga, hei tauira mena he mutunga kore NaN ranei ka mahi panic tenei mahi.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// mau Aho.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// mau Pūāhua.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Paita pūrite string.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Whakahokia te whanganga i karapoti a tenei mau.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Whirihora te whanganga e pā ana hoki tenei mau.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Whakahokia te `Span` e ko te huinga o `self.span()` kei roto i te puna anake ngā paita i ngā `range`.
    /// Whakahokia `None` ki te ko te whanganga i pai-kia whakapai waho nga rohe o `self`.
    ///
    // FIXME(SergioBenitez): tirohia mena kua tiimata te awhe paita ka mutu i te rohe UTF-8 o te putake.
    // te kore, te reira pea e ka tupu i te panic wāhi kē ka tāngia te kuputuhi pūtake te.
    // FIXME(SergioBenitez): kaore he huarahi kia mohio te kaiwhakamahi ki nga mapi a `self.span()`, no reira ka taea te karanga matapo tenei tikanga.
    // Hei tauira, `to_string()` mo te huru hoki 'c' "'\u{63}'";kaore he huarahi kia mohio te kaiwhakamahi mena ko te tuhinga haangai he 'c' he '\u{63}' ranei.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) te tahi mea tatau ki `Option::cloned`, engari mo `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, ko te piriti anake e whakarato ana i te `to_string`, whakatinana i te `fmt::Display` e pa ana ki a ia (ko te whakamuri o te whanaungatanga i waenganui i te mea e rua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Ka taarua i te taera hei taura kia kore e kore e kore ka hoki ano ki te whakahoki (ki te kore e taea te huri i nga rita rewa).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Uru aroturukihia ki nga taurangi taiao.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Tīkina tētahi tāupe taiao, me te tāpiri i te reira ki te hanga i te mōhiohio whakawhirinaki.
    /// Ko te punaha hanga i te kaiwhakaputa ka mohio ka uru te taurangi i te wa e whakahiatohia ana, a ka taea te whakaora ano i te hanganga ka rereke te uara o taua taurangi.
    ///
    /// Haunga kia ōrite te whakawhirinakitanga aroturuki tenei mahi ki `env::var` i te whare pukapuka paerewa, kore ai e kia te tautohe UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}