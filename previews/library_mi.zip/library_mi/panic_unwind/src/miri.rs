//! Taui i panics hoki Miri.
use alloc::boxed::Box;
use core::any::Any;

// Ko te momo o te ututaumaha e whakanoho te pūkaha Miri roto taui mo tatou.
// Me matua-tohu-rahi.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// He mahi-a-waho a Miri-i tiimata ai te tiimatanga.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Ko te ututaumaha tatou haere ki `miri_start_panic` ka waiho rite te tautohe tatou whiwhi i `cleanup` i raro.
    // Na kotahi pouaka tika matou i te reira ki runga, ki te tiki i te tahi mea atatohu-rahi.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Whakaora i te `Box` whāriki.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}