//! Te Whakatinana i te panics i tautokohia e libgcc/libunwind (i etahi ahua).
//!
//! Hoki papamuri i runga i whāwhā okotahi me te tāpae taui i tēnā kite "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) me ngā tuhinga hono i reira.
//! He pai ano hoki enei hei panui.
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## He whakarāpopototanga poto
//!
//! E rua nga waahanga e kitea ana te whakahaere rereke: he waahanga rapu me te waahanga horoi.
//!
//! I roto i ngā wāhanga e rua i te unwinder haere papa tāpae i runga ki ngā mōhiohio mā te whakamahi i raro i te anga tāpae wāhanga mālōlō o ngā kōwae o te tukanga o nāianei (konei pā "module" ki te kōwae OS, arā, he kawenga he whare pukapuka akiaki ranei).
//!
//!
//! Hoki te papa kotahi tāpae, ei tiaororaa reira te "personality routine" hāngai, tona wāhitau Kei te rongoa hoki i roto i te wāhanga info mālōlō.
//!
//! I roto i te waahanga rapu, ko te mahi o te mahinga tuakiri ko te tirotiro i nga mea okanga e maka ana, me te whakatau mena ka mau ki taua papa taatai.Ka kitea ana te anga o te kaawana, ka tiimata te waahanga horoi.
//!
//! I te waahanga horoi, ka tono ano te kaitautoko i ia momo ahuatanga.
//! Tenei wa whakatau reira i (ki te tetahi) hiahia waehere tamâraa ki te kia rere hoki te anga tāpae nāianei.Mena, ka whakawhitihia te mana ki tetahi branch motuhake i roto i te tinana mahi, te "landing pad", e kii ana i nga kaipahua, ka whakawatea i te mahara, etc.
//! I te mutunga o te papa taunga, whakawhiti te mana kei te hoki ki te unwinder me taui faahou.
//!
//! Kia kua tāpae kua raro tūtū'í ki te taumata anga pūraweke, tūnga taui me te tuakiri whakamutunga whakahaere whakawhitinga ngā ki te poraka hao.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Ko te kaiwhakauru akomanga wehe o Rust.
// Ka whakamahia tenei ma nga mahinga o te tuakiri ki te whakatau mena na te waa ake te waa i panga te okotahi.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // Moz\0 Rust-kaihoko, te reo
    0x4d4f5a_00_52555354
}

// Rēhita i ara ids i TargetLowering::getExceptionPointerRegister() o LLVM me TargetLowering::getExceptionSelectorRegister() mo ia hoahoanga, ka maheretia ki tau rēhita papaka mā tepu whakamāramatanga rēhita (te nuinga<arch>RegisterInfo.td, rapu hoki "DwarfRegNum").
//
// Tirohia hoki http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// E hāngai ana te waehere e whai ake nei i runga i C o GCC me ngā kawa whakahaere tuakiri C++ .Hoki tohutoro, e kite:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Mahinga EHABI tuakiri.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS whakamahi i te mahinga taunoa engari mai i te wa e whakamahia ana te SjLj e tatari ana.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Ka karanga Backtraces i runga i ARM te mahi tuakiri ki kāwanatanga==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // I roto i aua wā e hiahia ana tatou ki te haere tonu taui i te tāpae, te kore katoa e mutu to tatou backtraces i __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Ko te unwinder papaka riro e mau_Unwind_Context mea rite te mahi me atatohu LSDA, Heoi ARM EHABI tuu ratou ki te ahanoa okotahi.
            // Hei pupuri i nga waitohu mahi penei i te _Unwind_GetLanguageSpecificData(), ka mau ki nga tohu noa o te horopaki, ko nga mahinga a GCC e whakaatu ana i te tohu ki te kore_kaupapa i roto i te horopaki, me te whakamahi i te waahi kua rahuitia mo te AR0's "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... He huarahi whai kaupapa ano ko te whakarato i te tino whakamaarama o te ARM's_Unwind_Context i roto i a maatau hononga herekore me te tango i nga korero e hiahiatia ana mai i reira, ma te huri i nga mahi hototahi DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // E hiahia ana a EHABI ki te mahi i tana tuakiri ki te whakahou i te uara SP i roto i te kete aukati o te mea rereke.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // I ARM EHABI te mahi tuakiri te kawenga mō te mau taui i te hoê anga tāpae kotahi i mua i hoki mai (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // tautuhia i roto i te libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // mahi tuakiri Taunoa, whakamahia nei te tika i runga i te nuinga o ngā whāinga, me te autaki i runga i Windows x86_64 mā hipi.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // I runga i nga whaainga x86_64 MinGW, ko te mahinga whakamoe he SEH engari ko nga maamaa o te kaitoro (aka LSDA) e whakamahi ana i te whakawaehere-hototahi GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Ko te mahinga tuakiri mo te nuinga o a maatau whaainga.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Ko te wahitau whakahoki he tohu 1 paita i mua i nga tohutohu piiraa, tera pea kei te raarangi IP e whai ake nei i te tepu awhe LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Te hanga rēhita info mālōlō
//
// image o ia kōwae kei te wāhanga anga mālōlō info (te nuinga o ".eh_frame").A, no te he kōwae ko loaded/unloaded ki te tukanga, me mōhio te unwinder e pā ana ki te wāhi o tenei tekiona i roto i te mahara.Ko nga tikanga mo te whakatutuki ka rereke tena i te papa.
// I runga i etahi (hei tauira, Linux), ka taea e te unwinder ite i ngā wāhanga info mālōlō i runga i ona ake (e hihiri Tatau kōwae utaina tēnei wā mā te dl_iterate_phdr() API and finding their ".eh_frame" sections): etahi, rite Windows, rapu kōwae ki mātātoa rēhita ratou wāhanga info mālōlō mā unwinder API.
//
//
// tautuhi ana tēnei kōwae e rua tohu e kua tohutoro me ka karanga i rsbegin.rs ki te rēhita i to tatou mōhiohio ki te wāhaere GCC.
// Ko te whakatinanatanga o te wetewetewewewewewewewewewewewewewewewewewewewewewewewewewewewememe lahara ki tēnei:
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}