//! Whakatinanatanga o panics mā taui i tāpae
//!
//! Tenei crate Ko te whakatinanatanga o panics i Rust te whakamahi i "most native" tāpae tikanga taui o te tūāpapa tenei kei te haaputuhia hoki.
//! Ko tenei ka wehea ki roto i nga peere e toru i tenei wa:
//!
//! 1. Ko nga whaainga MSVC e whakamahi ana i te SEH i te konae `seh.rs`.
//! 2. Ka whakamahia e Emscripten okotahi C++ i roto i te kōnae `emcc.rs`.
//! 3. atu ngā taumata katoa whakamahi libunwind/libgcc i te kōnae `gcc.rs`.
//!
//! Ka taea te kitea atu tuhinga e pā ana ki ia whakatinanatanga i roto i te kōwae tēnā.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` Ko kāore ki Miri, na whakatūpato puku.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // ahanoa whakaoho Rust wāhaere o whakawhirinaki i runga i enei tohu, na kia tūmatanui ratou.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Ngā taumata e kore e e tautoko i taui i.
        // - arch=wasm32
        // - os=kore (whaainga "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Whakamahia te waaanga Miri.
        // Me uta ano hoki e tatou te waatea noa i runga ake nei, i te mea e tatari ana a rustc me etahi mea noa mai i reira ka tautuhia.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Whakamahia te waaahuru tuuturu.
        use real_imp as imp;
    }
}

extern "C" {
    /// Kairaweke i roto i te libstd huaina ka maturuturu iho te ahanoa panic te waho o `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Kairaweke i roto i te libstd huaina ka mau te okotahi ke te.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// wāhi tāurunga mō te whakatairanga i te okotahi, kau fakafofonga tika ki te whakatinanatanga pūhara-motuhake.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}