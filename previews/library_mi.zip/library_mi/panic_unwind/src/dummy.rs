//! Taui i hoki *wasm32* ūnga.
//!
//! I tenei wa kaore matou e tautoko i tenei, no reira he putunga noa tenei.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}