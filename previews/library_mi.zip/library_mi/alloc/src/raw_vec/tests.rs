use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Te tuhi i te whakamātautau o te kōmitimiti i waenganui i allocators tuatoru-rōpū, me te `RawVec` ko te iti uaua no te mea e kore e te API `RawVec` maka atu tikanga tohatoha sipí, kia kore e taea e tatou e tirohia te mea tupu ka pau allocator te (tua atu kimi i te panic).
    //
    //
    // Engari, ka tiro noa tenei ko nga tikanga `RawVec` ka haere ma te Allocator API ka rahui te penapena.
    //
    //
    //
    //
    //

    // He allocator wahangu e pau te nui whakaritea o te wahie i mua i te tīmata nganatanga tohatoha te kore.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (ka puta he hononga, ka whakamahi i te 50 + 150=200 wae wahie)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Tuatahi, `reserve` tohaina rite `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // Ko te 97 he nui ake i te takirua o te 7, no reira me mahi te `reserve` kia rite ki te `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // Ko te 3 he iti iho i te haurua o te 12, no reira me tipu haere te `reserve`.
        // I te wa e tuhi ana tenei whakamatautau ko te tauwehe tipu 2, no reira he 24 te kaha hou, heoi, ko te tipu o te 1.5 he OK ano hoki.
        //
        // No reira `>= 18` i kii ai.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}