//! # Te Rust matua tohatoha me te whare pukapuka kohikohinga
//!
//! Kei tenei wharepukapuka nga tohu mohio me nga kohinga hei whakahaere i nga uara kua tohaina.
//!
//! Ko tenei wharepukapuka, penei i te libcore, kaore e tika te whakamahi tika na te mea kua kaweake ano nga korero o roto i te [`std` crate](../std/index.html).
//! Crates e whakamahi ana i te huanga `#![no_std]` heoi kaore e whakawhirinaki ki te `std`, na reira ka whakamahia e raatau tenei crate.
//!
//! ## Nga uara honohono
//!
//! Ko te momo [`Box`] he momo tohu atawhai.Ka taea e anake he kotahi rangatira o te [`Box`], a taea te rangatira whakatau ki mutate te tirotiro, e ora i runga i te puranga.
//!
//! Ka taea te tuku i tenei momo ki roto i nga aho ahakoa he rahi te uara `Box` he rite ki te tohu.
//! Ko nga hanganga raraunga penei i te rakau he mea hanga ki nga pouaka na te mea kotahi noa te rangatira, ko te maatua.
//!
//! ## Tohutoro kaute tohu
//!
//! Ko te momo [`Rc`] he momo tohu-kore tohua-kiia hei tohu mo te tohatoha i nga mahara i roto i te aho.
//! Ko te atatohu [`Rc`] ka takai i te momo, `T`, ka ahei noa te uru atu ki `&T`, he tohutoro tiritiri.
//!
//! He whaihua tenei momo mena ka huri ke te rereketanga (penei i te whakamahi i te [`Box`]) he tono, ka honoa ki nga momo [`Cell`] me [`RefCell`] ranei kia pai ai te whakarereke.
//!
//!
//! ## Atomically tohua nga tohu tohu
//!
//! Ko te momo [`Arc`] te taurite o te miro o te momo [`Rc`].Ka whakarato i nga mahi katoa o te [`Rc`], engari me kii ko te momo `T` ka taea te wehewehe.
//! Hei taapiri, ko te [`Arc<T>`][`Arc`] ano ka taea te tuku i te mea kaore a [`Rc<T>`][`Rc`] i te.
//!
//! Ma tenei momo e ahei te uru ngatahi ki nga korero o roto, a he maha nga wa e honohono ana ki nga tuitui tuitui penei i nga mutexes kia taea ai te whakarereke i nga rauemi tohaina.
//!
//! ## Collections
//!
//! Ko nga whakamahinga o nga hanganga raraunga whaainga whanui kua tautuhia ki tenei wharepukapuka.E anō-kaweake ratou i roto i te [standard collections library](../std/collections/index.html).
//!
//! ## Atanga puranga
//!
//! Ko te kōwae [`alloc`](alloc/index.html) tautuhi te atanga taumata-iti ki te allocator ao taunoa.Kaore e hototahi ki te libc API tohatoha.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Tū, Ko te bug i rustdoc tenei: kite rustdoc te tuhinga i runga i ngā poraka `#[lang = slice_alloc]` he hoki `&[T]`, ano nei he tuhinga mā te whakamahi i tēnei āhuatanga i roto i `core`, a ka whiwhi haurangi e kore e whakahohea te-kuwaha āhuatanga.
// Ko te mea pai, kaore e tirohia mo te keehi waahanga mo nga tuhinga mai i etahi atu crates, engari na te mea ka puta noa tenei mo nga taonga noa, kaore e pai kia whakatika.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Whakaaetia te whakamatautau i tenei wharepukapuka

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Tauira me nga tohutō o-roto e whakamahia ana e etahi atu waahanga (me whakauru i mua o etahi atu waahanga).
#[macro_use]
mod macros;

// He puranga i whakaritea mo nga rautaki tohatoha taumata-iti

pub mod alloc;

// Nga momo tawhito e whakamahi ana i nga puranga i runga ake nei

// Me tika te tautuhi i te mod mai i te `boxed.rs` kia kore e pearua nga waahanga-noa ka hanga i te whakamatautau CFg;Me hoki engari ki te tukua waehere ki te whai `use boxed::Box;` parau.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}