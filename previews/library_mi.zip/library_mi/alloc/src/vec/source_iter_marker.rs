use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// He tohu motuhake mo te kohikohi i tetahi paipa iterator ki roto i te Vec i te whakamahi ano i te tohatoha puna, ara
/// te whakamahi i te paipa i tona waahi.
///
/// He tika te matua SourceIter trait mo ki te mahi motuhake i te uru i te tohanga i te ki te kia te makamaka.
/// Engari kaore e ranea kia whai mana te motuhake.
/// Tirohia nga taapiri taapiri i runga i te impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Ko te std-ā SourceIter/InPlaceIterable traits e anake whakatinana e mekameka o Whāurutau <Adapter<Adapter<IntoIter>>> (puritia katoa e core/std).
// rohe atu i runga i nga implementations whāurutau (tua atu `impl<I: Trait> Trait for Adapter<I>`) anake whakawhirinaki i runga i te tahi atu traits kua tohua rite whāiti traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. kaore te tohu e whakawhirinaki ki nga wa roa o nga momo tuku-kaiwhakamahi.Whakatauritea te koha Tārua, kua whirinaki atu ki etahi atu tohunga motuhake.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Nga whakaritenga taapiri e kore e taea te whakaatu ma trait bounds.whakawhirinaki tatou i runga i const eval hei utu:
        // he) kahore ZSTs rite reira e kia kore tohatoha ki te whakamahi anō me atatohu tauhanga e panic b) te rahi ōrite rite hiahiatia e Tiritiri kirimana c) whakaühia ōrite rite hiahiatia e kirimana Tiritiri
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // fallback ki implementations atu kano
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // whakamahia te whakamatau-mai i muri mai
        // - he pai ake te horaina o etahi ki etahi adapter iterator
        // - pērā te nuinga tikanga whitiauau ā, reira anake e he whaiaro &mut
        // - ka waiho ma maatau e tarai te tohu tohu ki roto rawa ka hoki mai ai i te mutunga
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // angitu te iterite, kaua e maturuturu upoko
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // tirohia arai ki te tautoko ake kirimana SourceIter i: ki te i ratou e kore e kore ai matou tae noa hanga i taua ki tenei wāhi
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // tirohia te kirimana InPlaceIterable.Ka taea noa tenei mena ka whitikina e te kaitahuri te tohu tohu ki nga mea katoa.
        // Mena ka whakamahia te urunga kore e tirohia ma te TrustedRandomAccess ka noho tonu te tohu tohu ki tona waahi tuatahi kaore e taea e taatau te whakamahi hei tohutoro
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // whakatakahia nga toenga e toe ana ki te hiku o te putake engari me aukati i te maturuturu o te tohatoha ake i te wa e kore e uru atu te IntoIter ki te taka te panics ka tukuna ano e matou etahi waahanga i kohia ki dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // ko te kirimana InPlaceIterable kaore e taea te whakaatu tika i konei mai i te mea he korero motuhake ta te try_fold ki te tohu tohu ko nga mea katoa ka taea e taatau te tirotiro mena kei te waahi tonu.
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}