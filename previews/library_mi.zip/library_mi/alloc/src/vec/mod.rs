//! He momo pātata growable ngohi ki tirotiro puranga-tohaina, tuhituhia `Vec<T>`.
//!
//! Ko te Vectors he tohu `O(1)`, he pana `O(1)` amortised (ki te pito) me te `O(1)` pop (mai i te mutunga).
//!
//!
//! Ma te Vector e kore e toha atu i te `isize::MAX` paita.
//!
//! # Examples
//!
//! Ka taea e koe te hanga maarama i te [`Vec`] me [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... ma te whakamahi ranei i te tonotono [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // Zeroes kotahi tekau
//! ```
//!
//! Ka taea e koe te [`push`] uara ki te pito o te vector (ka tupu te vector e hiahiatia ana):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! He rite te mahi ki te tuku uara:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Kei te tautoko hoki a Vectors i te taupū (mai i te [`Index`] me te [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// He momo pātata growable ngohi, tuhituhia rite `Vec<T>` me korerotia 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Kua tohaina te tonotono [`vec!`] kia pai ake ai te arawhiti:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Ka taea hoki te arawhiti reira ia huānga o te `Vec<T>` ki te uara i homai.
/// He pai ake pea tenei i te mahi tohatoha me te arawhiti i nga waahanga motuhake, ina koa ka kowhitihia he vector o nga takirua:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Ko nga mea e whai ake nei he rite, engari he puhoi pea:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Mō ētahi atu pārongo, kite [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Whakamahia te `Vec<T>` hei kohinga pai:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Prints 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Ko te momo `Vec` taea ki uara uru i taupū, no te mea whakatinana reira te [`Index`] trait.ka waiho atu mārama He tauira:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // Ka whakaatu i te reira '2'
/// ```
///
/// Heoi kia tupato: ki te ngana koe ki te uru i te taupū e kore ko nei i roto i te `Vec`, e to koutou pūmanawa panic!Kaore e taea e koe tenei:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Whakamahia [`get`] ko [`get_mut`] ki te hiahia koe ki te taki mēnā he te taupū roto te `Vec`.
///
/// # Slicing
///
/// Ka taea e te `Vec` e mutable.I tetahi atu, ko nga poro he taonga panui-anake.
/// Ki te tiki [slice][prim@slice], whakamahia [`&`].Tauira:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... ana koira katoa!
/// // ka taea e koe te mahi penei:
/// let u: &[usize] = &v;
/// // ranei rite tenei:
/// let u: &[_] = &v;
/// ```
///
/// I roto i te Rust, te reira atu noa ki te tika poro rite tohenga, nui atu i vectors ina e hiahia ana tika koe ki te whakarato i te uru pānui.He rite ano mo [`String`] me [`&str`].
///
/// # Te kaha me te whakatikatika
///
/// Ko te kaha o te vector ko te rahinga o te waahi kua tohaina mo nga waahanga future ka tapirihia ki te vector.Kaore tenei e raruraru ki te *roa* o te vector, e tohu ana i te maha o nga waahanga pono i roto i te vector.
/// Mena he roa te roa o te vector i tona kaha, ka kaha ake te whakanui ake i tona kaha, engari me maataki ano nga waahanga.
///
/// Hei tauira, ko te vector me te kaha 10 me te roa 0 ka waiho hei vector waatea me te waahi mo etahi atu waahanga 10.Ko te pana i te 10 iti iho ranei o nga waahanga ki te vector kaore e rereke tona kaha ka puta ranei te tuuturu.
/// Heoi, mena ka piki te roa o te vector ki te 11, me huri ano ia, kaare e ngoikoreHoki tenei take, e tūtohu ana ki te whakamahi i [`Vec::with_capacity`] wa e taea ki te whakapūtā pēhea te nui tūmanakohia te vector te ki te tiki.
///
/// # Guarantees
///
/// Na tona ahuatanga nui whakaharahara, `Vec` he maha nga taurangi mo tana hoahoa.Ma tenei e mohio ai he iti rawa te waahanga ka taea i te keehi whanui, a ka taea te whakahaere tika i nga tikanga tawhito ma te waehere kore haumaru.Kia mōhio e kōrero enei wakaae ki te `Vec<T>` mätou tino.
/// Mena he taapiri taapiri momo taapiri (hei tauira, hei tautoko i nga kaitoha ritenga), ki te takahi i o raatau hapa ka huri pea te whanonga.
///
/// Nuinga faufaa, `Vec` he a tonu ka waiho he (atatohu, kaha, roa) triplet.Kore ake, kore iti iho.Ko te ota o enei mara kaore i te tino tohua, a me whakamahi e koe nga tikanga tika hei whakarereke i enei.
/// Kaore e tika te tohu, na tenei momo ka whakakorengia te tohu-tohu.
///
/// Heoi, kaore pea te atatohu e tohu ki te whakamaharatanga kua tohaina.
/// I roto i ngā, ki te hanga koe i te `Vec` ki te kaha 0 mā [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], na roto i te te karanga [`shrink_to_fit`] i te věc kau ranei, ka kore tohatoha reira mahara.Waihoki, ki te penapenahia e koe nga momo kore-rahi i roto i te `Vec`, kaore e tohaina he waahi mo raatau.
/// *Kia mahara mena ko tenei `Vec` kaore pea e ripoata te [`capacity`] o te 0*.
/// `Vec` Ka tohatoha, ki te me anake, ki te [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// I te nuinga, ko nga taipitopito tohatoha a Vec` he tino mohio-mena kei te hiahia koe ki te toha i te mahara ma te whakamahi i te `Vec` ka whakamahia mo tetahi atu mea (hei paahi ki te waehere kore haumaru, ki te hanga ranei i taau ake kohinga tautoko-maumahara), kia mahara ki te deallocate tenei mahara mā te whakamahi i `from_raw_parts` ki ora te `Vec` a ka iho i te reira.
///
/// Mena he `Vec`*kua* tohaina te mahara, ko te mahara e tohu ana ia kei runga i te puranga (e tautuhia ana e te kaiwhakawhiwhi Rust kua whirihorahia hei whakamahi taunoa), a ko tana tohu tohu ki te [`len`] i whakauruhia, he mea hono ki te raupapa (he aha taau e hiahia ana. tirohia mena i akiakihia e koe ki tetahi waahanga), aru mai ko te [`kaha`]`,`[`len`] kaore i te whakauruhia, he waahanga noa.
///
///
/// He vector e mau ana i nga waahanga `'a'` me `'b'` me te kaha 4 ka taea te whakaatu penei i raro nei.Ko te waahanga o runga ko te hanganga `Vec`, kei roto he tohu ki te upoko o te tohatoha i te puranga, te roa me te kaha.
/// Ko te waahanga o raro ko te tohatoha i runga i te puranga, he poraka mahara hono.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** hei tohu maumahara kaore i te arawhiti, tirohia te [`MaybeUninit`].
/// - Note: kaore i te pumau te ABI ana kaore te `Vec` e whai tohu mo tana whakatakotoranga mahara (tae atu ki te ota mo nga mara).
///
/// `Vec` e kore e mahi i te "small optimization" kei te penapena nga waahanga i runga i te puranga mo nga take e rua:
///
/// * He uaua ake ma te waehere haumaru ki te whakahaere tika i te `Vec`.Kaore nga korero o te `Vec` e whai waahi pumau mena ka nekehia noa, ana ka uaua ki te whakatau mena kua whakawhiwhia e te `Vec` tetahi mahara.
///
/// * Ka whiua te keehi whanui, ka nui ake te branch mo nga urunga katoa.
///
/// `Vec` e kore e mimiti noa, ahakoa he maumau.Ma tenei e kore ai e puta he tohatoha kore, he wehenga ranei.Te putu i te `Vec` me ka whakakī hoki reira ki runga ki te taua [`len`] kia marietia kahore waea ki te allocator.Mena kei te hiahia koe ki te whakaweto i nga mahara kaore i whakamahia, whakamahia te [`shrink_to_fit`], te [`shrink_to`] ranei.
///
/// [`push`] a [`insert`] ka kore (re) tohatoha ki te he rawaka te āheinga korerotia.[`push`] me [`insert`] * ka tohaina (re) mena ka [`len`]`==`[`āheinga`].Arā, ko te kaha kua whakapaehia he tino tika, a ka taea te whakawhirinaki.ara e taea te whakamahi i te reira ki te wewete i ā te mahara tohaina e te `Vec` ki te hiahiatia.
/// Ko nga tikanga whakauru maha *akene* ka huri ano, ahakoa kaore e hiahiatia.
///
/// `Vec` e kore e tohu i tetahi rautaki tipu ka whakatutu ana ina tino ana, kaore hoki i te wa e kiia ana ko [`reserve`].Ko te rautaki o naianei he mea noa, akene he hiahia pea ki te whakamahi i te take tipu-haere totika.Ko nga mea katoa rautaki e whakamahia ana te pai ai o taurangi akoranga *e*(1) whakaheke wäriu [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, me [`Vec::with_capacity(n)`][`Vec::with_capacity`], ka whakaputahia he `Vec` me te tino rite ki te kaha e tonoa ana.
/// Ki te [`len`]`==`[`capacity`], (e rite ana ko te take mo te tonotono [`vec!`]), ka taea te tahuri he `Vec<T>` ki a i te [`Box<[T]>`][owned slice] waho reallocating neke i te huānga ranei.
///
/// `Vec` e kore e āta tuhirua i tetahi raraunga nekehia atu e te i reira, engari ano hoki e kore e āta tiaki i te reira.Ko tana whakamaharatanga kore he waahi mokowhiti hei whakamahi maana engari e hiahia ana ia.Te tikanga ka mahi noa i nga mea e kaha ana, i nga mahi ngawari ranei.Kaua e whakawhirinaki ki runga ki raraunga tangohia ki te kia murua mō ngā take haumarutanga.
/// Ahakoa ka tukuna e koe he `Vec`, ka whakamahia noa pea tana buffer e tetahi atu `Vec`.
/// Ahakoa ka whakakorehia e koe te maumahara o te "Vec` i te tuatahi, kaore pea i te puta na te mea kaore te kaiwhakapai e whakaaro he painga-taha tenei me tiakina.
/// Kotahi tonu te keehi kaore e pakaru taatau, heoi: ma te whakamahi i te waehere `unsafe` ki te tuhi ki te kaha nui, ka whakarahi i te roa ki te taurite, he mana tonu.
///
/// I tenei wa, kaore a `Vec` e kii i te ota e heke iho ai nga waahanga.
/// Kua rereke te ota i mua ake ka huri ano pea.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Nga tikanga whakahekeheke
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Hangaia he `Vec<T>` hou, kau.
    ///
    /// Kaore te vector e tohatoha kia pana ra ano nga waahanga ki runga.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Ka hangaia e te hou, ka ringihia `Vec<T>` ki te kaha kua whakapūtā.
    ///
    /// Ka taea e te vector te pupuri i nga waahanga `capacity` me te kore e whakahou.
    /// Mena ko `capacity` te 0, kaore te vector e tohatoha.
    ///
    /// He mea nui ki te tuhipoka e ahakoa kua te vector hoki te kaha * * tohua, ka whai te vector te kore roa * *.
    ///
    /// Mo te whakamaarama o te rereketanga i waenga i te roa me te kaha, tirohia te *[Raukaha me te waahanga hou]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Kaore he taonga a te vector, ahakoa he kaha ake mo etahi atu
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Ka oti enei katoa kaore he whakawhitinga ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... engari ma tenei pea ka huri ano te vector
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Waihangatia ai tika te `Vec<T>` i te wāhanga raw o tetahi vector.
    ///
    /// # Safety
    ///
    /// He tino haumaru tenei, na te maha o nga kaitaunui kaore i te tirotirohia:
    ///
    /// * `ptr` hiahia ki te kua i tohaina mua mā [`String`]/`věc<T>`(I te iti rawa, te reira tino pea ki te e hē ki te kore i reira).
    /// * `T` Me ki te whai i te rahi taua, me te tīaroaro rite te mea i whakaritea `ptr` ki.
    ///   (Ko te `T` he iti ake te taatai kaore i te rawaka, me tino rite te whakaoronga ki te whakatutuki i te whakaritenga [`dealloc`] me tohaina te mahara me te whakawhiti ki te whakatakotoranga kotahi.)
    ///
    /// * `length` hiahia ki te kia iti iho i te ranei rite ki `capacity`.
    /// * `capacity` me rite te kaha ki te tohu o te tohu.
    ///
    /// Ko te takahi i enei ka raru pea ka kino ki nga hanganga raraunga a roto o te kaitapa.Hei tauira ehara **i te** haumaru ki te hanga `Vec<u8>` mai i te tohu ki tetahi C `char` ngohi me te roa `size_t`.
    /// Kaore hoki i te pai te hanga mai i te `Vec<u16>` me tona roa, na te mea e whakaaro nui ana te kaiwhakarato ki te whakaoritangi, a ko enei momo e rua he rereketanga rereke.
    /// I tohaina te buffer me te whakahoutanga 2 (mo te `u16`), engari i muri i te huri hei `Vec<u8>` ka tukuna ki te waahanga 1.
    ///
    /// Kei te tōtika whakawhiti te mana o `ptr` ki te `Vec<T>` ka ai e deallocate, reallocate huri te tirotiro o te mahara tohu ki te taha o te atatohu i pai ai ranei.
    /// Kia mahara kia kore tetahi atu e whakamahi i te tohu i muri i te karanga i tenei mahi.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Whakahoutia tenei ka whakaū ana te vector_into_raw_parts.
    ///     // Aukati i te whakahaere i te 'v` o te kaitukino kia tino whakahaerehia e tatou te tohatoha.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Hutia nga tini korero nui mo `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Tuhihia te whakamaharatanga me te 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Hoatu hoki tahi nga mea katoa ki roto ki te věc
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Hangaia he `Vec<T, A>` hou, kau.
    ///
    /// Kaore te vector e tohatoha kia pana ra ano nga waahanga ki runga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Hangaia he `Vec<T, A>` hou, kau me te kaha kua tohua me te kaiwhakarato kua tohaina.
    ///
    /// Ka taea e te vector te pupuri i nga waahanga `capacity` me te kore e whakahou.
    /// Mena ko `capacity` te 0, kaore te vector e tohatoha.
    ///
    /// He mea nui ki te tuhipoka e ahakoa kua te vector hoki te kaha * * tohua, ka whai te vector te kore roa * *.
    ///
    /// Mo te whakamaarama o te rereketanga i waenga i te roa me te kaha, tirohia te *[Raukaha me te waahanga hou]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Kaore he taonga a te vector, ahakoa he kaha ake mo etahi atu
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Ka oti enei katoa kaore he whakawhitinga ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... engari ma tenei pea ka huri ano te vector
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Ka waihanga tika i te `Vec<T, A>` mai i nga waahanga mata o tetahi atu vector.
    ///
    /// # Safety
    ///
    /// He tino haumaru tenei, na te maha o nga kaitaunui kaore i te tirotirohia:
    ///
    /// * `ptr` hiahia ki te kua i tohaina mua mā [`String`]/`věc<T>`(I te iti rawa, te reira tino pea ki te e hē ki te kore i reira).
    /// * `T` Me ki te whai i te rahi taua, me te tīaroaro rite te mea i whakaritea `ptr` ki.
    ///   (Ko te `T` he iti ake te taatai kaore i te rawaka, me tino rite te whakaoronga ki te whakatutuki i te whakaritenga [`dealloc`] me tohaina te mahara me te whakawhiti ki te whakatakotoranga kotahi.)
    ///
    /// * `length` hiahia ki te kia iti iho i te ranei rite ki `capacity`.
    /// * `capacity` me rite te kaha ki te tohu o te tohu.
    ///
    /// Ko te takahi i enei ka raru pea ka kino ki nga hanganga raraunga a roto o te kaitapa.Hei tauira ehara **i te** haumaru ki te hanga `Vec<u8>` mai i te tohu ki tetahi C `char` ngohi me te roa `size_t`.
    /// Kaore hoki i te pai te hanga mai i te `Vec<u16>` me tona roa, na te mea e whakaaro nui ana te kaiwhakarato ki te whakaoritangi, a ko enei momo e rua he rereketanga rereke.
    /// I tohaina te buffer me te whakahoutanga 2 (mo te `u16`), engari i muri i te huri hei `Vec<u8>` ka tukuna ki te waahanga 1.
    ///
    /// Kei te tōtika whakawhiti te mana o `ptr` ki te `Vec<T>` ka ai e deallocate, reallocate huri te tirotiro o te mahara tohu ki te taha o te atatohu i pai ai ranei.
    /// Kia mahara kia kore tetahi atu e whakamahi i te tohu i muri i te karanga i tenei mahi.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Whakahoutia tenei ka whakaū ana te vector_into_raw_parts.
    ///     // Aukati i te whakahaere i te 'v` o te kaitukino kia tino whakahaerehia e tatou te tohatoha.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Hutia nga tini korero nui mo `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Tuhihia te whakamaharatanga me te 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Hoatu hoki tahi nga mea katoa ki roto ki te věc
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Ka hurihia te `Vec<T>` ki roto i ona waahanga hou.
    ///
    /// Hoki te atatohu raw ki te raraunga whakakaupapa, te roa o te vector (i roto i ngā huānga), me te āheinga tohaina o te raraunga (i roto i ngā huānga).
    /// He rite ano nga tohenga tautohe i roto i te ota rite ki nga tohenga ki [`from_raw_parts`].
    ///
    /// I muri i te karanga i tenei mahi, ma te kaikaranga te kawenga mo te mahara i whakahaere i mua e te `Vec`.
    /// Ko te ara anake ki te mahi i tenei ko ki te tahuri te atatohu raw, roa, me te hoki kaha ki te `Vec` ki te mahi [`from_raw_parts`], tuku te destructor ki te mahi i te Whakapai.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Ka taea e tatou inaianei te whakarereke i nga waahanga, penei i te tuku i te tohu atawhai ki tetahi momo hototahi.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Ka hurihia te `Vec<T>` ki roto i ona waahanga hou.
    ///
    /// Whakahoki ai i te tohu atarangi ki nga raraunga e whaaia ana, te roa o te vector (i roto i nga waahanga), te waahanga kua tohaina o nga raraunga (i nga waahanga), me te kaiwhakawhiwhi.
    /// He rite ano nga tohenga tautohe i roto i te ota rite ki nga tohenga ki [`from_raw_parts_in`].
    ///
    /// I muri i te karanga i tenei mahi, ma te kaikaranga te kawenga mo te mahara i whakahaere i mua e te `Vec`.
    /// Ko te huarahi anake ki te mahi tenei ko te huri i te tohu tika, te roa, me te kaha ki roto ano i te `Vec` me te mahi [`from_raw_parts_in`], kia taea ai e te kaipahua te mahi horoi.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Ka taea e tatou inaianei te whakarereke i nga waahanga, penei i te tuku i te tohu atawhai ki tetahi momo hototahi.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Whakahoki ai i te maha o nga mea timatanga ka taea e te vector te pupuri me te kore e toro atu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Ka tiakina te kaha mo te iti rawa atu o te `additional` atu waahanga hei whakauru ki te `Vec<T>` i homai.
    /// Ka rahuitia pea e te kohinga etahi atu waahanga hei karo i nga waahi tuuturu.
    /// I muri i te karanga `reserve`, ka nui ake te kaha ki te rite ranei ki te `self.len() + additional`.
    /// Kaore tetahi mea mena kua tau te kaha.
    ///
    /// # Panics
    ///
    /// Panics mena ka neke te kaha hou ki te `isize::MAX` paita.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Ka rahuitia te kaha iti mo te tino `additional` atu waahanga hei whakauru ki te `Vec<T>` kua homai.
    ///
    /// I muri i te karanga `reserve_exact`, ka nui ake te kaha ki te rite ranei ki te `self.len() + additional`.
    /// Kaore he mea mena kua ea te kaha.
    ///
    /// Kia mahara ma te Kaitoha e tuku atu ki te kohinga te nui ake o te waa i runga i ta te tono.
    /// Na reira, kaore e taea te whakawhirinaki ki te kaha kia iti rawa.
    /// He pai te `reserve` mena e tatari ana kia whakauruhia a future.
    ///
    /// # Panics
    ///
    /// Panics mena ka kaha te kaha o te `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Ka ngana ki te rahui i te kaha mo te iti rawa atu o te `additional` atu waahanga hei whakauru ki te `Vec<T>` i homai.
    /// Ka rahuitia pea e te kohinga etahi atu waahanga hei karo i nga waahi tuuturu.
    /// I muri i te karanga `try_reserve`, ka nui ake te kaha ki te rite ranei ki te `self.len() + additional`.
    /// Kaore tetahi mea mena kua tau te kaha.
    ///
    /// # Errors
    ///
    /// Mena ka kaha te kaha, ka ripoatatia ranei e te kaitoha he koretake, ka hoki mai ano he he.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Puritia te maumahara, ka puta ki te kore e taea
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Inaianei kua mohio taatau kaore e taea te OOM i waenga o a maatau mahi uaua
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // tino uaua
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Ka ngana ki te rahui i te kaha iti mo nga waahanga `additional` kia whakauruhia ki roto i te `Vec<T>` i homai.
    /// Whai muri i te waea `try_reserve_exact`, ka nui ake te kaha ki te `self.len() + additional` ranei mena ka whakahokia mai e `Ok(())`.
    ///
    /// Kaore he mea mena kua ea te kaha.
    ///
    /// Kia mahara ma te Kaitoha e tuku atu ki te kohinga te nui ake o te waa i runga i ta te tono.
    /// Na reira, kaore e taea te whakawhirinaki ki te kaha kia iti rawa.
    /// He pai te `reserve` mena e tatari ana kia whakauruhia a future.
    ///
    /// # Errors
    ///
    /// Mena ka kaha te kaha, ka ripoatatia ranei e te kaitoha he koretake, ka hoki mai ano he he.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Puritia te maumahara, ka puta ki te kore e taea
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Inaianei kua mohio taatau kaore e taea te OOM i waenga o a maatau mahi uaua
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // tino uaua
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Ka tiimata te kaha o te vector i te waa e taea ana.
    ///
    /// ka maturuturu te reira i raro rite tata rite taea ki te roa, engari tonu ai te allocator e te vector e reira he wāhi hoki atu i te torutoru huānga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Ko te kaha kaore i te iti iho i te roa, ana kaore he aha ka rite ana, kia taea ai e tatou te karo i te keehi panic i te `RawVec::shrink_to_fit` ma te karanga noa me te kaha ake.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Ka tiitihia te kaha o te vector me te roopu o raro.
    ///
    /// Ko te kaha ka noho ko te iti rawa pea te roa me te uara kua tohaina.
    ///
    ///
    /// Mena he iti ake te kaha o naianei i te rohe o raro, he-kore tenei.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Ka huri i te vector ki te [`Box<[T]>`][owned slice].
    ///
    /// Kia mahara e ka maturuturu tenei tetahi kaha te taikaha.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Ko nga kaha nui atu kua tangohia:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Whakapototia te vector, te haapa'oraa i te āhuatanga tuatahi `len` me maturuturu te toenga.
    ///
    /// Mena he nui ake te `len` i te roa o te vector o tenei wa, kaore he painga.
    ///
    /// Ka taea e te tikanga [`drain`] te whakaari i te `truncate`, engari me whakahoki nga waahanga nui rawa atu kaua ki te taka iho.
    ///
    ///
    /// Kia mahara kaore he painga o tenei tikanga ki te kaha tohaina o te vector.
    ///
    /// # Examples
    ///
    /// Te tapahi i tetahi waahanga vector e rima ki nga waahanga e rua:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Kaore he taapiri e puta ana ka nui ake te `len` i te roa o to vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Te whakaheke i te wa e rite ana te `len == 0` ki te karanga i te tikanga [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Ko te hoki haumaru tenei:
        //
        // * te poro i tukuna ki te `drop_in_place` e whaimana ana;ko te keehi `len > self.len` ka karo i te hanga poro tapatahi, a
        // * te `len` o te vector kua mimiti i mua i te karanga `drop_in_place`, kia kore e heke iho te uara mena ka tae atu a `drop_in_place` ki te panic kia kotahi (mena ka rua te panics, ka whakakorehia te kaupapa).
        //
        //
        //
        unsafe {
            // Note: He mea whakaae e ko `>` me kore `>=` tenei.
            //       Ko te huri ki te `>=` he kino nga mahi kino i etahi waa.
            //       Tirohia te #78884 mo etahi atu.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Ka tangohia he poro kei roto te vector katoa.
    ///
    /// E taurite ana ki te `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Unu i te wāhanga mutable o katoa te vector.
    ///
    /// E taurite ana ki te `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Whakahokia te atatohu raw ki moka o te vector.
    ///
    /// Ma te kaiwaea e whakarite kia ora te vector i te atatohu ka hoki mai tenei mahi, ka kore ka mutu ka tohu ki nga para para.
    /// Ko te whakarereke i te vector ka ahei pea te tohatoha i tana miihini, ka kore pea e tohu nga tohu ki a ia.
    ///
    /// Me whakarite hoki e te kaiwaea kia kore te tuhinga o te atatohu tohu (non-transitively) e tuhia ki (haunga ki roto i te `UnsafeCell`) te whakamahi i tenei tohu tetahi tohu ranei i ahu mai i a ia.
    /// Ki te hiahia koe ki te mutate te tirotiro o te pōro, te whakamahi i [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Ka atarangi tatou i te tikanga poro o taua ingoa ano kia kore e pa atu ki te `deref`, e hanga ana i te tohutoro takawaenga.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Whakahoki ai i tetahi tohu tohu koretake ki te penapena a vector.
    ///
    /// Ma te kaiwaea e whakarite kia ora te vector i te atatohu ka hoki mai tenei mahi, ka kore ka mutu ka tohu ki nga para para.
    ///
    /// Ko te whakarereke i te vector ka ahei pea te tohatoha i tana miihini, ka kore pea e tohu nga tohu ki a ia.
    ///
    /// # Examples
    ///
    /// ```
    /// // Tohatoha vector nui nui mo 4 huānga.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Whakauruhia nga waahanga ma te tohu tohu tika, ka tohua te roa.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // atarangi tatou te tikanga wāhanga o te taua ingoa ki te karo i haere i roto i `deref_mut`, e hanga he tohutoro takawaenga.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Whakahoki ai i te korero ki te kaiwhakarato takatika.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Ka tohe i te roa o te vector ki te `new_len`.
    ///
    /// He mahinga taumata-iti tenei e kore e pupuri i nga kaitautoko noa o te momo.
    /// Ko te tikanga ko te whakarereke i te roa o te vector ka mahia ma te whakamahi i tetahi o nga mahi haumaru, penei i te [`truncate`], [`resize`], [`extend`], te [`clear`] ranei.
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` me iti ake i te orite ki te [`capacity()`].
    /// - Ko nga waahanga o te `old_len..new_len` me matua arahi.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Ka whai hua tenei tikanga mo nga ahuatanga e mahi ana te vector hei kaiparau mo etahi atu waehere, ina koa mo te FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Ko te tika te kōhiwi iti mo te tauira doc tenei;
    /// # // e kore e whakamahi i tenei hei wāhi tīmata mo te whare pukapuka tūturu.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Mo nga tuhinga a te tikanga FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SAFETY: A, no te hoki `deflateGetDictionary` `Z_OK`, mau te reira e:
    ///     // 1. `dict_length` i timatahia nga timatanga.
    ///     // 2.
    ///     // `dict_length` <=te kaha (32_768) e ora ai te `set_len` ki te waea.
    ///     unsafe {
    ///         // Karangahia te FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... me te whakahou i te roa ki nga mea i tiimata.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Ahakoa te tauira e whai ake nei he reo, i reira te mea he turuturu mahara mai kihai i te roto vectors wewete mua ki te karanga `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` he putua no reira kaore e hiahiatia nga timatanga ki te arawhiti.
    /// // 2. `0 <= capacity` mau tonu nga mea katoa `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Te tikanga, i konei, ka whakamahia e te [`clear`] tetahi mea ki te maturuturu tika i nga korero me te kore e pakaru te mahara.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Ka tangohia tetahi waahanga mai i te vector ka whakahoki mai.
    ///
    /// Ko te waahanga kua tangohia kua whakakapihia e te waahanga whakamutunga o te vector.
    ///
    /// Kaore tenei e tiakina te ota, engari he O(1).
    ///
    /// # Panics
    ///
    /// Panics mena kei waho o te rohe te `index`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Ka whakahouhia taatau [taurangi] ki te waahanga whakamutunga.
            // Note e ki te tirohia nga rohe i runga ake muri i reira me waiho he huānga whakamutunga (e taea e whaiaro [taupū] ano).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Kōkuhu ai te huānga i te tūnga `index` roto te vector, neke huānga katoa i muri reira ki te tika.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // waahi mo te waahanga hou
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // pohehe Te waahi hei whakanoho i te uara hou
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Me neke nga mea katoa kia waatea ai.
                // (Te taarua i te waahanga 'taupū` ki nga waahi e rua.)
                ptr::copy(p, p.offset(1), len - index);
                // Tuhia ki roto, me te taarua i te kape tuatahi o te tohu `taupū`th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Tango ai me hoki te huānga i tūnga `index` roto te vector, neke huānga katoa i muri reira ki te maui.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena kei waho o te rohe te `index`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // te waahi e tangohia ana e maatau.
                let ptr = self.as_mut_ptr().add(index);
                // kape atu, kaore pea he kape o te uara kei runga i te puranga me te vector i te wa ano.
                //
                ret = ptr::read(ptr);

                // Me neke nga mea katoa ki raro kia kapi ai te waahi.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Ka mau ki nga mea timatanga kua tohua e te matapae.
    ///
    /// I etahi atu kupu, tangohia nga waahanga katoa `e` penei ka whakahokia mai e `f(&e)` te `false`.
    /// Kei te whakahaerehia tenei tikanga i tona waahi, ka toro totika i ia waahanga ki te raupapa taketake, ka tiakina te raupapa o nga mea pupuri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Na te mea ka toro haerehia nga waahanga i roto i te raupapa taketake, ka taea te whakamahi i te ahua o waho hei whakatau ko wai nga waahanga ka mau.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // A ape i te maturuturunga iho rua ki te kore e mahi ana te kaitiaki taka, mai kia hanga tatou i te tahi mau rua i roto i te tukanga.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-tukatuka len-> |^-muri ki te tirotiro
        //                  | <-CNT Mukua-> |
        //      | <-taketake_len-> |Kei te mau tonu: Ko nga huanga e tohu ana ka hoki pono ano.
        //
        // Hole: Kua nekehia, kua taka ranei te mokamoka huanga.
        // Kaore i tirohia: Nga waahanga huakore kaore i tirohia.
        //
        // Ka karangahia tenei kaitiaki whakaheke ka ohorere ana te predicate, te `drop` ranei o te waahanga.
        // Ka nekehia e ia nga waahanga kaore i tirotirohia kia kapi nga kohao me te `set_len` ki te roa e tika ana.
        // I nga wa kaore te panui me te `drop` kaore e peera, ka pai te whakaputa.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // HAUMARU: whaia tūemi wetetakihia me kia tika mai kore tatou pa ki a ratou.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SAFETY: I muri i te whakakii i nga kohao, ko nga mea katoa kei te maharahara te taha.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SAFETY: Me whai mana te waahanga kaore i tirohia.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Haere wawe atu ki te karo i te maturuturunga rua mena ka raru ana te `drop_in_place`.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SAFETY: Kaore matou e pa ki tenei waahanga i muri i te hingatanga.
                unsafe { ptr::drop_in_place(cur) };
                // Kua anga whakamua te kaute.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SAFETY: `deleted_cnt`> 0, no reira kaua e kopikopiko te mokamoka poka ki te huanga onaianei.
                // Ka whakamahi taarua mo te neke, ka kore e pa ki tenei waahanga.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Ka tukatukahia nga taonga katoa.Ka taea te whakapai ake ki te `set_len` e LLVM.
        drop(g);
    }

    /// Ka tangohia katoa engari ko nga mea tuatahi o te vector e whakatau ana ki taua matua ano.
    ///
    ///
    /// Mena kua tohatohahia te vector, ka tangohia tenei i nga taarua katoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Ka tango i nga mea katoa engari ko nga mea tuatahi o te vector e ngata ana i te whanaungatanga taurite kua hoatu.
    ///
    /// haere te mahi `same_bucket` te tohutoro ki huānga e rua i te vector, a me whakatau ki te whakarite rite nga mea timatanga.
    /// Ko nga waahanga ka tukuna i te ritenga ke mai i te raupapa i te poro, no reira mena ka whakahokia mai e `same_bucket(a, b)` te `true`, ka tangohia te `a`.
    ///
    ///
    /// Mena kua tohatohahia te vector, ka tangohia tenei i nga taarua katoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Ka taapirihia he waahanga ki muri o te kohinga.
    ///
    /// # Panics
    ///
    /// Panics mena ka neke te kaha hou ki te `isize::MAX` paita.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Ka panic tenei ka whakakahoretia ranei mena ka tohaina e matou> isize::MAX paita mena ka piki te piki o te roa mo nga momo kore-rahi.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// He tango i te huānga whakamutunga i te vector me hoki reira, ranei [`None`] ki he reira kau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Ka nekehia nga waahanga katoa o te `other` ki te `Self`, ka waiho he kore noa te `other`.
    ///
    /// # Panics
    ///
    /// Panics mena ka taupoki te `usize` i te maha o nga waahanga o te vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Ka āpiti huānga ki `Self` i ētahi atu moka.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Ka waihanga te riringi iterator e nekehia ana te whānuitanga tauwhāiti i roto i te vector me hua nga tūemi tangohia.
    ///
    /// A, no te te iterator te ** ** maturuturu iho, e nekehia atu āhuatanga katoa i roto i te awhe i te vector, ara, ki te kahore i tino pau te iterator.
    /// Ki te te iterator kore te ** ** maturuturu iho (ki [`mem::forget`] hei tauira), ko reira kāore i te tini o huānga e nekehia atu.
    ///
    /// # Panics
    ///
    /// Panics mena he nui ake te tiimata i te pito mutunga mena he nui ake te pito whakamutunga i te roa o te vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // He whānui tonu ūkui te vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Haumaru Mahara
        //
        // A, no te te tuatahi i hanga te Drain, fakanounoui reira te roa o te pūtake vector ki kia kore Korearawhiti oho-i huānga ranei e wātea i katoa ki te kore destructor o te Drain whiwhi ki te rere.
        //
        //
        // Ma te Drain e ptr::read nga uara hei tango.
        // Ka mutu ana, ka toe taahuahia te toenga o te vector ki te taupoki i te koha, ka whakahokia mai te roa o te vector ki te waa hou.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // tautuhia te roa o te self.vec ki te tiimata, kia haumaru mena ka puta te Drain
            self.set_len(start);
            // Whakamahia te nama i roto i te IterMut hei tohu i te whanonga nama o te kaitahuri Drain katoa (penei i te &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Ka maama i te vector, ka tangohia nga uara katoa.
    ///
    /// Kia mahara kaore he painga o tenei tikanga ki te kaha tohaina o te vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Whakahoki ai i te maha o nga waahanga o te vector, e kiia ana ko tona 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Returns `true` ki te kei te vector kahore huānga.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Wehea te kohinga kia rua i te taurangi kua tohua.
    ///
    /// Whakahoki ai i te vector hou kua tohaina kei roto nga waahanga i te awhe `[at, len)`.
    /// I muri i te karanga, ka mahue te vector taketake kia kei roto i te āhuatanga `[0, at)` me ona tonu kaha o mua.
    ///
    ///
    /// # Panics
    ///
    /// Panics mena ko `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // ka taea e te vector hou te tango i te peara taketake ka karo i te kape
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Kaore i te pai te `set_len` ka kape i nga taonga ki `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Ka whakarahi i te `Vec` i te waahi kia rite ana te `len` ki te `new_len`.
    ///
    /// Mena he nui ake te `new_len` i te `len`, ka roa te `Vec` e te rereketanga, me ia mokamoka taapiri kua whakakiihia ki te hua o te piiraa i te katinga `f`.
    ///
    /// Ka mutu ake nga uara hoki i `f` i te `Vec` i te raupapa kua ratou hanga.
    ///
    /// Mena he iti ake te `new_len` i te `len`, ka tiimata te `Vec`.
    ///
    /// Whakamahia ai i tēnei aratuka he katinga ki te waihanga uara hou i runga i nga pana.Mena he pai ake ki a koe te [`Clone`] i tetahi uara, whakamahia [`Vec::resize`].
    /// Mena kei te hiahia koe ki te whakamahi i te [`Default`] trait ki te whakaputa uara, ka taea e koe te paahitia i te [`Default::default`] hei tautohe tuarua.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Ka pau me te turuturu i te `Vec`, ka hoki mai ano he korero ka taea te whakarereke, `&'a mut [T]`.
    /// Kia mahara ko te momo `T` me ora i te wa katoa i whiriwhiria `'a`.
    /// Mena he momo tohumate tohu noa te momo, kaore noa iho ranei, kaatahi ka kowhihia hei `'static`.
    ///
    /// He rite tenei mahi ki te mahi [`leak`][Box::leak] i runga i te [`Box`] engari kaore he huarahi hei whakahoki mai i te maumahara kua turuturu.
    ///
    ///
    /// He tino whaihua tenei mahi mo nga raraunga ka ora mo te toenga o te hotaka.
    /// Ma te waiho i te tohutoro kua hoki mai ka raru ai te maharatanga.
    ///
    /// # Examples
    ///
    /// Mahinga ngawari:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Whakahoki ai i te toenga e manawapa ana o te vector hei poro o te `MaybeUninit<T>`.
    ///
    /// Ka taea te whakamahi i te waahanga kua whakahokia mai hei whakakii i te vector me nga raraunga (hei tauira
    /// ma te panui mai i tetahi konae) i mua i te tohu i nga raraunga hei arawhiti ma te whakamahi i te tikanga [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Tohaina te vector nui mo te 10 waahanga.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Whakakiia i roto i te 3 ngā huānga tuatahi.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Tohua nga waahanga tuatahi e 3 o te vector kua whakauruhia.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Kaore tenei tikanga i te whakatinana mo te `split_at_spare_mut`, hei aukati i te whakakorenga o nga tohu ki te buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Whakahokia vector ihirangi rite te wāhanga o `T`, me te kaha e manawapa toe o te vector rite te wāhanga o `MaybeUninit<T>`.
    ///
    /// Ka taea te whakamahi i te waahanga miihini kua hoki mai ki te whakakii i te vector me nga raraunga (hei tauira, ma te panui mai i tetahi konae) i mua i te tohu i nga raraunga hei tiimatanga ma te whakamahi i te tikanga [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Kia mahara he API taumata-iti tenei, me maataki nga kaupapa aromautanga.
    /// Mena ka hiahia koe ki te taapiri i nga raraunga ki te `Vec` ka taea e koe te whakamahi i te [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] ko [`resize_with`] ranei, i runga i o hiahia ake.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Rahui i etahi atu waahanga nui mo nga waahanga 10.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Whakakiihia nga waahanga e 4 e whai ake nei.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Tohua nga waahanga e 4 o te vector kua whakauruhia.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - Ka waihohia a len, no reira kaore i whakarereke
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Haumaru: Te huri hoki .2 (&mut usize) whakaaro ko te taua rite karanga `.set_len(_)`.
    ///
    /// Ka whakamahia tenei tikanga kia uru motuhake ki nga waahanga vector katoa i te wa kotahi i te `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` ka whakamanahia kia whai mana mo nga waahanga `len`
        // - `spare_ptr` kei te tohu tetahi o nga waahanga i mua o te buffer, na reira kaore e tarai ki te `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Ka whakarahi i te `Vec` i te waahi kia rite ana te `len` ki te `new_len`.
    ///
    /// Ki te he nui atu i `len` `new_len`, atu te `Vec` e te rerekētanga, me ia mokamoka atu ki tonu ki `value`.
    ///
    /// Mena he iti ake te `new_len` i te `len`, ka tiimata te `Vec`.
    ///
    /// Me whiwhi tēnei aratuka `T` ki te whakatinana i [`Clone`], i roto i te tikanga ki te taea ki te ki tou te uara haere.
    /// Mena e hiahia ana koe kia nui ake te ngawari (ka hiahia ranei koe ki te whakawhirinaki ki te [`Default`] kaore i te [`Clone`]), whakamahia te [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Iramate me āpiti āhuatanga katoa i roto i te wāhanga ki te `Vec`.
    ///
    /// Iterates mo te wāhanga `other`, iramate ia huānga, a ka āpiti reira ki tenei `Vec`.
    /// Ko te `other` vector kua haerehia a-ota.
    ///
    /// Kia mahara he rite tonu tenei mahi ki te [`extend`] engari he mea motuhake te mahi me nga poro hei whakakapi.
    ///
    /// Ki te a ka whiwhi Rust whāiti tenei mahi ka pea e tauwhāitihia (engari e wātea ana tonu).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Tārua huānga i `src` awhe ki te mutunga o te vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` e kī ana he whaimana te awhe kua hoatuhia hei tohu maau ake
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Ko tenei waehere whanui `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Whakawhānuihia te vector e te `n` uara, ma te whakamahi i te kaihanga whakaputa.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Whakamahia te SetLenOnDrop ki te mahi huri noa i te bug kaore pea i te mohio te kaipupuri i te toa i roto i te `ptr` ki te self.set_len() kaua e ingoakete.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Tuhia nga waahanga katoa engari ko te mea whakamutunga
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Whakawhitihia te roa i roto i nga waahanga katoa mena kei next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Ka taea e taatau te tuhi tika i te waahanga whakamutunga kaore he koretake
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len whakaturia e kaitiaki kaitiaki
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Tango āhuatanga karapīpiti faahiti i roto i te vector rite ki te whakatinanatanga [`PartialEq`] trait.
    ///
    ///
    /// Mena kua tohatohahia te vector, ka tangohia tenei i nga taarua katoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Nga tikanga me nga mahi a roto
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` me tika te taupū
    /// - `self.capacity() - self.len()` me tino `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - ka whakapiki ake a len i muri noa i nga waahanga timatanga
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - karanga ana te kaiwaea he tohu tika te src
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - i tika arawhitia Huānga ki `MaybeUninit::write`, na te reira ok ki increace len
            // - nui haere len te i muri i ia huānga ki te ārai i ngā turuturu (kite take #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - ka whakaū i te kaiwaea he tohu tika te `src`
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Ko nga tohu tohu e rua i hangaia mai i nga tohutoro poro motuhake (`&mut [_]`) na reira he whaimana, kaore hoki e tarai.
            //
            // - Ko nga mea timatanga: Taaruahia na he pai ki te kape i a raatau, me te kore e mahi i tetahi mea me nga uara taketake
            // - `count` he orite ki te len o `source`, na he tika te putake mo nga korero `count`
            // - `.reserve(count)` taurangi e `spare.len() >= count` pera manawapa he tika hoki `count` tuhi
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Ko nga mea timatanga i whakauruhia e `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Nga whakatinanatanga trait noa mo Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): ki cfg(test) te tikanga `[T]::to_vec` tūturu, e hiahiatia ana e te mo tenei whakamāramatanga tikanga e kore he wātea,.
    // Engari whakamahi i te mahi `slice::to_vec` i te mea e wātea ana anake ki cfg(test) NB kite te kōwae slice::hack i slice.rs mō ētahi atu mōhiohio
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // whakataka tetahi mea kaore e tuhirua
        self.truncate(other.len());

        // self.len <= other.len na te tumuaki o runga ake, na ko nga poro i konei he-rohe tonu.
        //
        let (init, tail) = other.split_at(self.len());

        // whakamahi ano i nga uara kei roto allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Ka waihanga te kai iterator, e ko, kotahi e neke ia uara i o te vector (i te tīmatanga ki te mutunga).
    /// Kaore e taea te whakamahi i te vector i muri i te karanga i tenei.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s he momo Momo, kaore &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // te tikanga rau ka tukuna e nga momo whakatinanatanga SpecFrom/SpecExtend ka kore o raatau whakaaro ki te tono
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Koinei te keehi mo te whiti whaanui.
        //
        // Ko tenei mahi kia rite ki nga tikanga mo:
        //
        //      hoki tūemi i roto iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // Ka taea e kore rauroha noa mai e kua i matou NB ki Tiritiri te wāhi wāhitau
                self.set_len(len + 1);
            }
        }
    }

    /// Ka waihangahia he miihini wehewehe e whakakapi ana i te awhe kua tohua i te vector me te tohu `replace_with` i homai ka whakaputa i nga taonga kua tangohia.
    ///
    /// `replace_with` e kore Me ki e te roa taua rite `range`.
    ///
    /// `range` ka nekehia ahakoa kaore i pau i te miihini a tae noa ki te mutunga.
    ///
    /// Ko reira kāore i te tini o huānga e nekehia atu i te vector ki te patai i te uara `Splice` te.
    ///
    /// Ka pau noa te kaitautoko whakauru `replace_with` ka heke iho te uara `Splice`.
    ///
    /// Ko te tino pai, ki te tenei:
    ///
    /// * Ko te hiku (āhuatanga i roto i te vector muri `range`) he kau,
    /// * ranei hua `replace_with` huānga iti rite ranei atu te roa, o te range`
    /// * ko te rohe raro ranei o tana `size_hint()` e tino tika ana.
    ///
    /// Ki te kore, ka tohaina he vector poto ka neke rua te neke o te hiku.
    ///
    /// # Panics
    ///
    /// Panics mena he nui ake te tiimata i te pito mutunga mena he nui ake te pito whakamutunga i te roa o te vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Ka waihangahia he taatai e whakamahi ana i te katinga hei whakatau mena ka tangohia tetahi waahanga.
    ///
    /// Mena he pono te katinga, ka tangohia te waahanga ka tukuna.
    /// Mena ka hoki mai te katinga he teka, ka noho tonu te waahanga ki te vector kaore e tukuna e te kaituku.
    ///
    /// Mā te tenei tikanga ko ōrite ki te waehere e whai ake nei:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // tou waehere ki konei
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Engari he maama ake te whakamahi i te `drain_filter`.
    /// `drain_filter` Ko hoki pai atu, no te mea e taea backshift reira nga āhuatanga o te ngohi i roto i te nuinga.
    ///
    /// Kia mahara ma te `drain_filter` e tuku ki a koe kia whakarereke i nga waahanga katoa i te katinga o te taatari, ahakoa e hiahia ana koe ki te pupuri ki te tango atu ranei.
    ///
    ///
    /// # Examples
    ///
    /// Wehea te awhi ki nga ahiahi me nga taarua, me te whakamahi ano i te tohatoha taketake:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Kaitiaki ki a tatou hoko patai (turuturu amplification)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Toro whakatinanatanga e kape āhuatanga i o tohutoro i mua i aki ana ratou ki runga i te věc.
///
/// motuhake ana tēnei whakatinanatanga te hoki iterators wāhanga, te wahi whakamahi reira [`copy_from_slice`] ki tāpirihia te wāhanga katoa i kotahi.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Ka whakatauhia te whakataurite o te vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Ka whakatinana i te ota mo te vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // whakamahia te maturuturunga iho mo te [T] whakamahia he poro poro hei tohu ki nga waahanga o te vector hei momo ngoikore ngoikore rawa atu;
            //
            // ka taea te karo i nga paatai whaimana i roto i etahi keehi
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // Ka whakahaerehia e RawVec te whakawhitinga
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Ka waihanga i te `Vec<T>` kau.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: faaho'i whakamātautau i roto i te libstd, e ai hapa konei
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: faaho'i whakamātautau i roto i te libstd, e ai hapa konei
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Whiwhi ai i nga korero katoa o te `Vec<T>` hei huinga, mena he rite te rahi o tera ki te awhi i tonoa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Mena kaore e taurite te roa, ka hoki mai ano te whakauru ki te `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Ki te kei koe pai ki te whiwhi noa te pīmua o te `Vec<T>`, ka taea e koe te karanga [`.truncate(N)`](Vec::truncate) tuatahi.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SAFETY: He pai tonu te `.set_len(0)`.
        unsafe { vec.set_len(0) };

        // SAFETY: Ko te tohu a te 'Vec` e tika ana te whakatika, a
        // te tīaroaro Me te ngohi ko te taua rite nga tūemi.
        // I tirohia e maatau i mua he nui nga taonga.
        // Kaore nga taonga e rua-maturuturu i te mea e kii ana te `set_len` ki te `Vec` kia kaua e maturuturu.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}