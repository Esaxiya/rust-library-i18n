use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Motuhake trait whakamahia mo Vec::from_iter
///
/// ## Te kauwhata whakahoahoa:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ko tetahi keehi noa ko te tuku i te vector ki tetahi mahi ka kohia ano ki roto i te vector.
        // Ka taea e taiawhio poto tenei ki te kore i whakatu matou te IntoIter i te katoa.
        // Ka oti ana te whanake Ka taea hoki e taatau te whakamahi i te mahara me te neke i nga raraunga ki mua.
        // Engari ka mahia noa e taatau ka kore e nui ake te kaha o te Vec hua ake i te hanga ma te whakamahi mai i te mahi mai i te MahiIterator.
        //
        // e kore te mea tino tika e fakangatangata rite whanonga tohatoha o věc he āta kāore i.
        // Engari he kowhiringa whiriwhiri.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // me tuku ki spec_extend() mai i te extend() ano ka tohaina ki te spec_from mo nga Vecs kau
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ka whakamahia tenei hei `iterator.as_slice().to_vec()` mai i te waahanga_pure me nui ake nga huarahi hei whakaaro mo te kaha whakamutunga + te roa ka nui ake nga mahi.
// `to_vec()` tika tukuna te nui tika, me te hua ana rite.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): ki cfg(test) te tikanga `[T]::to_vec` tūturu, e hiahiatia ana e te mo tenei whakamāramatanga tikanga e kore he wātea,.
    // Engari whakamahi i te mahi `slice::to_vec` i te mea e wātea ana anake ki cfg(test) NB kite te kōwae slice::hack i slice.rs mō ētahi atu mōhiohio
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}