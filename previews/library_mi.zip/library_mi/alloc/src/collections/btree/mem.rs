use core::intrinsics;
use core::mem;
use core::ptr;

/// Ka whakakapi tenei i te uara kei muri o te tohutoro ahurei `v` ma te waea i te mahi e pa ana.
///
///
/// Mena ka puta he panic i te katinga `change`, ka tangohia katoahia te mahinga.
#[allow(dead_code)] // puritia hei whakaahua me te whakamahi i te future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Ka whakakapi tenei i te uara kei muri o te tohutoro ahurei `v` ma te waea i te mahi e pa ana, ka whakahoki i te hua i puta i te huarahi.
///
///
/// Mena ka puta he panic i te katinga `change`, ka tangohia katoahia te mahinga.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}