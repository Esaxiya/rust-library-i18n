use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Ka taapirihia nga takirua uara-matua katoa mai i te hononga o nga kaiwhakarite e rua e piki ana, ka piki ake te taurangi `length` i te huarahi.Ko te whakamutunga ka ngawari ki te kaiwaea ki te karo i te turuturu ina he pania te kaiuru takauru.
    ///
    /// Mena he rite te whakaputa a nga iterator e rua, ka tukuna e te tikanga tenei te takirua mai i te iterator maui ka tapiri i te tokorua mai i te miihini tika.
    ///
    /// Mena kei te hiahia koe kia mutu te rarangi ki runga i te raupapa piki ake, peera mo te `BTreeMap`, me whakaputa e nga kaitohu e rua nga ki i runga i te piki whakarake, nui ake ia i nga ki katoa o te rakau, tae atu ki nga ki kei roto i te rakau ka uru ana.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Ka whakareri maatau ki te whakakotahi i te `left` me te `right` ki roto i te raupapa raupapa i te waa raina.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // I tenei wa, ka hangaia e maatau he rakau mai i te raupapa raupapa i te waa raina.
        self.bulk_push(iter, length)
    }

    /// Ka pana i nga takirua uara-katoa ki te pito o te rakau, ka whakarahihia he taurangi `length` i te huarahi.
    /// Ko te whakamutunga ka ngawari ki te kaiwaea ki te karo i te turuturu ina ka panuku te kaituku.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Whakawhanahia i roto i nga takirua uara-matua katoa, ka peke ki nga kōpuku i te taumata tika.
        for (key, value) in iter {
            // Ngana ki te turaki i te takirua uara-matua ki te kōpuku rau onāianei.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Kaore he waahi i toe, piki ki runga ka pana ki reira.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // I kitea he kohinga me te waahi ka toe, pana i konei.
                                open_node = parent;
                                break;
                            } else {
                                // Haere ano.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Kei runga noa atu tatou, hangahia he pona pakiaka hou ka pana i reira.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Panahia te uara matua-uara me te maaramatanga matau hou.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Haere ano ki te taha matau-tino rau.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Te whakanui i te roa o te taarua, kia maama ai te mahere i nga waahanga kua taapirihia ahakoa ka anga whakamua nga panui.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// He kaitohu mo te whakakotahi i nga raupapa e rua i whakariterite kia kotahi
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Mena he rite nga taviri e rua, whakahokia mai te takirua uara-matua mai i te maataki tika.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}