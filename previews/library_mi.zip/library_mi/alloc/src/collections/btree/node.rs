// He nganatanga tenei ki te whakatinana i muri o te kaupapa pai
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// I te mea kaore a Rust i te whai momo taangata me te whakahoutanga polymorphic, ka mahi maatau me te kore haumaru.
//

// Ko te whainga nui o tenei waahanga ko te karo i nga mahi uaua ma te manaaki i te rakau hei ipu (mena he ahua rereke) ka karo ki te karo i te nuinga o nga kaikiri B-Tree.
//
// Heoi, kaore tenei kaupapa e whakaaro mena ka tohatohahia nga urunga, ko ngahea tohu ka taea te whakakii, ara ko te tikanga o te tikanga o raro.Heoi, e whakawhirinaki tatou i runga i te torutoru invariants:
//
// - Me whai kākahu depth/height i nga Rakau.Ko te tikanga o nga huarahi katoa ki raro ki te rau mai i te kōpuku kua rite te roa rite.
// - Ko te kōpuku o te roa `n` he mau taviri `n`, he uara `n`, me nga taha `n + 1`.
//   E tohu ana tenei ahakoa ko te kōpuku putu, kotahi te edge.
//   Mo te kōpuku rau, "having an edge" ko te tikanga ka taea e taatau te tohu i tetahi tuunga i te kōpuku, na te mea he kau noa nga tapa o nga rau, kaore he take o te whakaaturanga raraunga.
// I roto i te kōpuku o roto, ko te edge e tautuhi ana i tetahi tuunga ka whai tohu ki tetahi kopae tamaiti.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Te whakaaturanga o nga kōpuku rau me tetahi waahanga o te whakaaturanga o nga kōpuku o roto.
struct LeafNode<K, V> {
    /// Kei te pirangi matou kia whakahoahoa i te `K` me te `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Ko te taupū o tenei tohu ki te raarangi `edges` matua o te matua.
    /// `*node.parent.edges[node.parent_idx]` kia rite ki te `node`.
    /// Ka whakamanahia tenei ka arahi ina he kore-kore te `parent`.
    parent_idx: MaybeUninit<u16>,

    /// Te maha o nga taviri me nga uara kei te penapenahia e te kōpuku nei.
    len: u16,

    /// Ko nga raarangi kei te penapena i nga raraunga tuuturu o te kōpuku.
    /// Ko nga mea tuatahi `len` o ia momo e whakauruhia ana e whai mana ana.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Ka tiimata te `LeafNode` hou i te waahi.
    unsafe fn init(this: *mut Self) {
        // Ka rite ki te kaupapa here whanui, ka waihohia e maatau nga mara mena ka taea, na te mea he tere ake tenei me te ngawari ki te whai i Valgrind.
        //
        unsafe {
            // matua_idx, mau taviri, me nga vals he MaybeUninit katoa
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Ka waihanga i te `LeafNode` pouaka hou.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Ko te maaramatanga o nga tohu o roto.Pēnei ki te `LeafNode`s, me huna ēnei i muri o te 'BoxedNode`s kia kore ai e taka nga kī me nga uara kaore i whakauruhia.
/// Ko nga tohu ki te `InternalNode` ka tika te maka ki tetahi tohu ki te waahanga `LeafNode` o te kōpuku, kia ahei te waehere ki te mahi i runga i nga waahanga o te rau me nga kōpuku o roto me te kore e tirohia tehea o nga tohu e rua e tohu ana te tohu.
///
/// Ma te `repr(C)` e whakamahi ai tenei taonga.
///
#[repr(C)]
// gdb_providers.py Ka whakamahia e tenei ingoa momo mo hifo.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Nga tohu ki nga tamariki o tenei kōpuku.
    /// `len + 1` o enei e kiia ana he timatanga, he tika, engari ko tera e tata ana ki te mutunga, i te wa e purihia ana te rakau na roto i te momo nama `Dying`, ko etahi o enei tohu kei te tautau.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Ka waihanga i te `InternalNode` pouaka hou.
    ///
    /// # Safety
    /// Ko te kaitautoko o nga kohinga o roto ko te mea kotahi te edge o te tiimata me te whaimana.
    /// Kaore tenei mahi i te whakatu i tetahi edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Me matua arahi noa tatou i nga raraunga;ko nga tapa ko peaUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// He tohu, kore-tohu tohu ki te kōpuku.Koinei pea tetahi tohu tohu ki `LeafNode<K, V>`, he tohu tohu ranei ki `InternalNode<K, V>`.
///
/// Heoi, kaore he korero mo te `BoxedNode` ko tehea o nga momo kōpuku e rua kei roto tonu, ana, na te koretake o nga korero, ehara i te momo wehe, kaore hoki he kaipatu kino.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Ko te putake pakiaka o te rakau ake.
///
/// Kia mahara kaore he kaipahua tenei, a me horoi horoi a ringa.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Whakahokia ai he rakau hou, me ona ake putake putake kua putua i te timatanga.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` kaua e waiho hei kore.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Ka taea te tono moni i te putake pakiaka.
    /// Kaore i te ahua ki te `reborrow_mut`, he haumaru tenei na te mea kaore e taea te whakamahi te uara whakahoki ki te whakangaro i te pakiaka, kaore hoki e taea etahi atu korero mo te rakau.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ka iti ake te tango i te putake pakiaka.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ka kore e taea te whakawhiti ki tetahi tohutoro e ahei ai te whakawhiti, me te tuku i nga tikanga whakangaro me te mea iti.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// He tāpiri i te kōpuku ā-hou ki te kotahi edge tuhu ki te kōpuku pakiaka o mua, hanga e kōpuku hou te kōpuku pakiaka, a ka hoki mai ai.
    /// Ka whakapiki tenei i te teitei ki te 1 ana ko te ritenga ke o te `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, engari ano kua wareware noa ta maatau kei roto a maatau inaianei:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ka tangohia te putake pakiaka o roto, ma te whakamahi i tana tamaiti tuatahi hei tohu pakiaka hou.
    /// I te mea e kiia ana ka karangahia ka kotahi noa te tamaiti o te putake pakiaka, kaore he horoi ki runga i nga ki, nga uara me etahi atu tamariki.
    ///
    /// Ka whakahekehia te teitei e te 1 ana ko te ritenga ke o te `push_internal_level`.
    ///
    /// Me whai urunga motuhake ki te mea `Root` engari kaore ki te putake pakiaka;
    /// kaore e aukati i etahi atu o nga kakau, o nga tohutoro ranei ki te kōpuku pakiaka.
    ///
    /// Panics mena kaore he taumata o roto, ara, mena he rau te putake o te pakiaka.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SAFETY: i kii ta maatau ki roto.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SAFETY: i nama taatau `self` anake ana ko tana momo nama he motuhake.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // HAUMARU: kua arawhiti tonu te edge tuatahi.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. Ko te `NodeRef` he kaitautoko i nga wa katoa i te `K` me te `V`, ahakoa ko te `BorrowType` ko `Mut`.
// He he tenei i te hangarau, engari kaore e tae mai te awangawanga na te whakamahinga o te `NodeRef` na te mea kei te noho tonu maatau mo te `K` me te `V`.
//
// Heoi, i nga waa katoa e takai ana te `NodeRef`, tirohia kia tika te rereketanga.
//
/// He tohutoro ki te kōpuku.
///
/// Ko tenei momo he maha nga taapiri e whakahaere ana i tana mahinga:
/// - `BorrowType`: He momo momo putea e whakaatu ana i te ahua o te nama me te kawe i te roanga o te tau.
///    - I te wa ko te `Immut<'a>` tenei, ko te `NodeRef` he rite te ahua ki te `&'a Node`.
///    - I te wa ko te `ValMut<'a>` tenei, he rite te mahi a te `NodeRef` ki te `&'a Node` mo nga ki me nga hanganga rākau, engari he maha nga korero e taea ana mo nga uara puta noa i te rakau kia noho tahi.
///    - Ina ko `Mut<'a>` tenei, he rite te mahi a te `NodeRef` ki te `&'a mut Node`, ahakoa ko nga tikanga whakauru ka taea e te tohu tohu te huri ki te uara ki te noho tahi.
///    - I te wa ko te `Owned` tenei, he rite te mahi a te `NodeRef` ki te `Box<Node>`, engari kaore he kaipahua, a me horoi horoi a ringa.
///    - I te wa ko te `Dying` tenei, kei te kaha tonu te mahi a te `NodeRef` penei i te `Box<Node>`, engari he tikanga ki te whakangaro i te rakau ma te iti, me nga tikanga noa, ahakoa kaore i tohuhia he kore haumaru ki te waea, ka ahei te tono i te UB ki te kiia he he.
///
///   Mai i tetahi `NodeRef` e ahei ana ki te whakatere i runga i te rakau, he pai te `BorrowType` ki te rakau katoa, kaua ki te pona anake.
/// - `K` me `V`: Koinei nga momo ki me nga uara e penapena ana i roto i nga kōpuku.
/// - `Type`: Ka taea pea ko `Leaf`, `Internal`, ko `LeafOrInternal` ranei.
/// Ka `Leaf` tenei, ka tohu te `NodeRef` ki te kōpuku rau, ka `Internal` tenei ka tohu te `NodeRef` ki te kōpuku o roto, ana ko te `LeafOrInternal` tenei ka tohu pea te `NodeRef` ki nga momo kōpuku.
///   `Type` ko `NodeType` te ingoa ka whakamahia i waho o `NodeRef`.
///
/// Ko nga `BorrowType` me te `NodeType` e aukati ana he aha nga tikanga hei whakatinana, hei whakamahi i te momo momo momo.He here kei te huarahi e taea ai e taatau te whakamahi i nga aukatinga:
/// - Mo ia momo taapiri, ka taea noa e taatau te whakatau tikanga tetahi tikanga mo te momo kotahi ranei.
/// Hei tauira, kaore e taea te tautuhi i tetahi tikanga penei i te `into_kv` mo te `BorrowType` katoa, kia kotahi ranei mo nga momo katoa e mau ana i te roanga o te tau, na te mea e hiahia ana matou kia whakahokia mai nga tohutoro `&'a`.
///   Na reira, ka tautuhia e maatau mo te momo `Immut<'a>` iti rawa te kaha.
/// - Kaore e taea te whakauru kaha i a maatau mai i te korero `Mut<'a>` ki te `Immut<'a>`.
///   Na reira, me tino karanga maatau ki a `reborrow` i runga i te `NodeRef` kaha ake kia tae atu ai ki tetahi tikanga penei i te `into_kv`.
///
/// Nga tikanga katoa i te `NodeRef` e whakahoki ana i etahi momo tohutoro,
/// - Tangohia te `self` i te uara, ka whakahoki i te roanga o te wa e kawea ana e `BorrowType`.
///   I etahi wa, ki te whakamahi i taua tikanga, me waea atu ki a `reborrow_mut`.
/// - Tangohia te `self` ma te tohutoro, ka whakahoki mai a (implicitly) i nga ra katoa o te tohutoro, hei utu mo te oranga e kawea ana e `BorrowType`.
/// Ma teera, ka tohu te kaitirotiro moni tarewa e nama tonu ana te `NodeRef` mena ka whakamahia te tohutoro kua whakahokia.
///   Ko nga tikanga tautoko i te whakaurunga ka piko i tenei ture ma te whakahoki i tetahi tohu tika, ara he tohutoro kaore he oranga.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Ko te maha o nga reanga e wehe ana te kōpuku me te taumata o nga rau, he toituku o te kōpuku kaore e taea te whakaahua katoahia e `Type`, kaore hoki te kohinga i te penapena.
    /// Me waiho noa e tatou te teitei o te putake o te pakiaka, ka piki mai i tera atu teitei o te kōpuku.
    /// Me kore mena mena ko `Type` te `Leaf` me te kore-kore mena `Type` ko `Internal`.
    ///
    ///
    height: usize,
    /// Ko te tohu ki te rau, ki te kōpuku o roto ranei.
    /// Ko te whakamaaramatanga o te `InternalNode` e whakarite ana he tika te tohu ki tetahi taha.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Wewete tohutoro kōpuku i kikiia hei `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ka whakaatu i nga raraunga o te kōpuku o roto.
    ///
    /// Whakahokia ai he ptr raw kia kore ai e whakakore etahi atu tohutoro ki tenei kōpuku.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SAFETY: te momo kōpuku pateko ko `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// He tono i te urunga motuhake ki nga raraunga o te kōpuku o roto.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Ka kitea te roa o te kōpuku.Ko te maha o te mau taviri uara ranei tenei.
    /// Ko te maha o nga tapa ko te `len() + 1`.
    /// Kia mahara, ahakoa te ahuru, ma te waea atu ki tenei mahi ka pa te mate kino ki te whakakore i nga tohutoro huri noa i hangaia e te waehere kore haumaru.
    ///
    pub fn len(&self) -> usize {
        // Te mea nui, ka uru noa tatou ki te mara `len` i konei.
        // Ki te ko BorrowType marker::ValMut, i reira ai kia tino tohutoro mutable ki ngā uara e kore e ti'a ia tatou whakakahore.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Whakahoki ai i te maha o nga taumata kua wehea te kōpuku me nga rau.
    /// Ko te teitei o te kore e tohu ko te kōpuku he rau ake.
    /// Mena ka whakaahuahia e koe nga rakau me te pakiaka kei runga, e kii ana te nama ko tehea te pari ka puta te kōpuku.
    /// Mena ka whakaahuahia e koe nga rakau me ona rau ki runga, e kii ana te nama he pehea te teitei o te rakau ki runga ake i te kōpuku.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Ka tango poto i tetahi atu korero kaore e taea te whakarereke ki te kōpuku kotahi.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ka whakaatuhia te waahanga rau o tetahi rau, kōpuku o roto ranei.
    ///
    /// Whakahokia ai he ptr raw kia kore ai e whakakore etahi atu tohutoro ki tenei kōpuku.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Me tika te kohinga mo te waahanga LeafNode iti rawa.
        // Ehara tenei i te tohutoro i te momo NodeRef na te mea kaore maatau e mohio mena he motuhake, he waahanga ranei.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Ka kitea te matua o te kōpuku onāianei.
    /// Whakahoki ai i te `Ok(handle)` mena he matua to te pukapuku o naianei, ka tohu te `handle` ki te edge o te matua e tohu ana ki te kōpuku onāianei.
    ///
    /// Whakahoki ai i te `Err(self)` mena kaore he matua o te kopuku o tenei wa, ka whakahoki ano i te `NodeRef` taketake.
    ///
    /// Ma te ingoa tikanga koe e whakaahua nga rakau me te aka o te aka i runga.
    ///
    /// `edge.descend().ascend().unwrap()` me `node.ascend().unwrap().descend()` kia rua, i runga i te angitu, kaua e mahi i tetahi mea.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Me whakamahi nga tohu tohu ki nga kōpuku na te mea, mena ko te BorrowType he marker::ValMut, tera pea he tohutoro tino rereke mo nga uara kaore e tika kia whakakorea e taatau.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Kia mahara ko te `self` me tino kore.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Kia mahara ko te `self` me tino kore.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Ka whakaatu i te waahanga rau o tetahi rau ki tetahi kōpuku o roto ranei i te rakau kaore e taea te neke.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SAFETY: kaore e taea etahi tohu rereke ki tenei rakau i nama hei `Immut`.
        unsafe { &*ptr }
    }

    /// Pinohia he tirohanga ki nga ki kua penapena ki te kōpuku.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// He rite ki te `ascend`, ka whai tohu ki te kōpuku matua o te kōpuku, engari ka huri hoki i te kōpuku onāianei i roto i te hātepe.
    /// Kaore tenei i te haumaru na te mea ka urunga tonu te kōpuku o tenei wa ahakoa kua tohaina.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Kaore i te maia te kii atu ki te kaiwhakaputu i nga korero tuuturu ko tenei kōpuku he `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Kaore i te maia te kii atu ki te kaiwhakaputu i nga korero tuuturu ko tenei kōpuku he `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Ka tangohia mo tetahi wa ano tetahi atu korero ka taea te whakarereke ki te kōpuku kotahi.Kia tupato, na te mea he tino kino tenei tikanga, ruarua na te mea kaore pea i te ahua kino.
    ///
    /// Na te mea ka taea e nga tohu ngawari te kopikopiko i nga taha katoa o te rakau, ka taea te whakamahi i te tohu ki te whakahoki i te tohu tika, i waho o nga rohe, kaore ranei i te tika i raro i nga ture tono tarewa.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) whakaarohia te taapiri i tetahi atu momo taapiri ki te `NodeRef` ka aukati i te whakamahinga o nga tikanga whakatere ki runga tohu kua tohua, kia kore ai e tau tenei.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// He nama totika te uru atu ki te waahanga rau o te rau, o te kōpuku o roto ranei.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SAFETY: he uru motuhake ta to taatau ki te kohanga katoa.
        unsafe { &mut *ptr }
    }

    /// Ka whakaekea te uru motuhake ki te waahanga rau o tetahi rau, o te kōpuku o roto ranei.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SAFETY: he uru motuhake ta to taatau ki te kohanga katoa.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Tikina uru motuhake ki te huānga o te rohe rokiroki matua.
    ///
    /// # Safety
    /// `index` kei roto i te rohe o 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SAFETY: kaore e taea e te kaiwaea te karanga i etahi atu tikanga ki a ia ano
        // tae noa ki te tangohanga o te tohutoro poro matua, na te mea he huarahi motuhake taatau mo te roanga o te nama.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// He tono i te urunga motuhake ki tetahi waahanga waahanga ranei o te waahanga penapena uara o te kōpuku.
    ///
    /// # Safety
    /// `index` kei roto i te rohe o 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SAFETY: kaore e taea e te kaiwaea te karanga i etahi atu tikanga ki a ia ano
        // tae noa ki te tangohanga o te tohanga waahanga uara, na te mea he urunga ahurei taatau mo te roanga o te nama.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// He tono i te urunga motuhake ki tetahi waahanga waahanga ranei o te waahanga rokiroki o te kōpuku mo te ihirangi edge.
    ///
    /// # Safety
    /// `index` kei roto i te rohe o 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SAFETY: kaore e taea e te kaiwaea te karanga i etahi atu tikanga ki a ia ano
        // kia heke ra ano te tohutoro poro edge, na te mea he urunga motuhake ta tatou mo te roanga o te nama.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - He nui ake i te `idx` nga waahanga timatanga o te kōpuku.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Ka hangaia noa he korero mo te waahanga kotahi e hiahia ana matou, ki te karo i te whakaingoa me nga korero tino pai ki etahi atu waahanga, ina koa, ko era i hoki mai ki te kaiwaea i nga korero o mua.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Me kaha ki te akiaki ki nga tohu tohu ohorere na te mea Rust putanga #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Ka tono nama motuhake ki te roa o te kōpuku.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ka tautuhia te hononga o te kōpuku ki tona matua edge, me te kore e whakakore i etahi atu korero ki te kōpuku.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Ka maama te hononga o te pakiaka ki tona matua edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Ka taapirihia he takirua uara-matua ki te pito o te kōpuku.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Ko nga mea katoa i whakahokia mai e `range` he tohu edge tika mo te kōpuku.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ka taapirihia he takirua uara-matua, me te edge kia haere ki te taha matau o taua tokorua, ki te pito o te kōpuku.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Ka tirohia mena ko te kōpuku he kōpuku `Internal` he kōpuku `Leaf` ranei.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// He tohutoro ki te takirua uara-matua edge ranei kei roto i te kōpuku.
/// Ko te tohu `Node` he `NodeRef`, i te `Type` ka taea te `KV` (te tohu i te kakau i runga i te takirua matua-uara) te `Edge` ranei (te tohu i te kakau i runga i te edge).
///
/// Kia mahara tae atu ki nga kohinga `Leaf` ka taea e nga kaikawe `Edge` te pupuri.
/// Kaore i te tohu i tetahi tohu ki tetahi kōpuku tamaiti, hei tohu i nga waahi ka haere nga tohu a nga tamariki i waenga i nga takirua uara-matua.
/// Hei tauira, i te kōpuku whai roa 2, e 3 pea nga waahi edge, kotahi ki te taha maui o te kōpuku, kotahi i waenga i nga takirua e rua, me tetahi i te taha matau o te kōpuku.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Kaore e hiahiatia e maatau te katoa o te `#[derive(Clone)]`, na te mea ko te `Node` anake te wa ko te `Clone`able ka waiho ana hei tohutoro kaore e taea te whakaputa, no reira `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Tangohia te kōpuku kei roto te edge, te takirua uara-matua ranei e tohu ana tenei kakau.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Whakahoki ai i te turanga o tenei kakau ki te kōpuku.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Ka waihangahia he kakau hou ki te takirua uara-matua i te `node`.
    /// Kaore i te haumaru no te mea me whakarite e te kaiwaea `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Ka taea pea te whakamahi hei whanui mo te Wahanga Whaiti, engari ka whakamahia noa i tenei waahanga.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Tangohia ake nei tetahi atu, kakau kore e taea te huri i te waahi kotahi.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Kaore e taea e taatau te whakamahi i te Handle::new_kv me te Handle::new_edge na te mea kaore matou e mohio ki ta maatau momo
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Kaore i te maia te kii atu ki te kaiwhakaputu i nga korero tuuturu ko te kopae o te kakau he `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Ka tangohia mo tetahi wa tetahi atu, kakau ka taea te huri i te waahi kotahi.
    /// Kia tupato, kia rite ki tenei tikanga ko te tino mōrearea, whiunga kia mai kore e tonu puta reira kino.
    ///
    ///
    /// No te taipitopito, kite `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Kaore e taea e taatau te whakamahi i te Handle::new_kv me te Handle::new_edge na te mea kaore matou e mohio ki ta maatau momo
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Ka hangaia he kakau hou ki te edge i te `node`.
    /// Kaore i te haumaru no te mea me whakarite e te kaiwaea `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Homai he taupū edge te wahi e hiahia ana tatou ki te kōkuhu ki te kōpuku ki tonu ki te kaha, computes te taupū KV tika o te pūwāhi wahia, me te wahi ki te mahi i te kōkuhu.
///
/// Ko te whaainga o te waahanga wehe ko tona matua me tona uara kia mutu ki roto i te kopae matua;
/// nga mau taviri, uara, me taha ki te maui o te pūwāhi ritua hei te tamaiti maui;
/// ko nga ki, nga uara me nga taha ki te taha matau o te tohu wehenga hei tamaiti tika.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Ko te putanga Rust #74834 e ngana ana ki te whakamarama i enei ture hangarite.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ka whakauruhia he takirua uara-nui hou i waenga i nga takirua uara-matua ki te taha matau me te maui o tenei edge.
    /// Ko te tikanga tenei he nui te waahi kei roto i te kōpuku kia uru ai te tokorua hou.
    ///
    /// Ka tohu te tohu atawhai ki te uara whakauru.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ka whakauruhia he takirua uara-nui hou i waenga i nga takirua uara-matua ki te taha matau me te maui o tenei edge.
    /// Ka wehe tenei tikanga i te kōpuku mena kaare e nui te ruuma.
    ///
    /// Ka tohu te tohu atawhai ki te uara whakauru.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Whakatika i te atatohu matua me te tohu ki te kopae tamariki e hono ana tenei edge.
    /// He pai tenei ina kua whakarerekehia te ota mo nga taha.
    fn correct_parent_link(self) {
        // Hangaia te kaiwhakawhirinaki kaore e whakakorehia etahi atu korero ki te kōpuku.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ka whakauruhia he takirua uara-matua hou me tetahi edge ka haere ki te taha matau o taua takirua hou i waenga i tenei edge me te takirua uara-matua ki te taha matau o tenei edge.
    /// Ko te tikanga tenei he nui te waahi kei roto i te kōpuku kia uru ai te tokorua hou.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Ka whakauruhia he takirua uara-matua hou me tetahi edge ka haere ki te taha matau o taua takirua hou i waenga i tenei edge me te takirua uara-matua ki te taha matau o tenei edge.
    /// Ka wehe tenei tikanga i te kōpuku mena kaare e nui te ruuma.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ka whakauruhia he takirua uara-nui hou i waenga i nga takirua uara-matua ki te taha matau me te maui o tenei edge.
    /// Ka wehe tenei tikanga i te kōpuku mena kaare e nui te ruuma, ka ngana ki te whakauru i te waahanga wehe ki te kōpuku matua, kia tae ra ano te putake.
    ///
    ///
    /// Mena he `Fit` te hua i whakahokia mai, ko te pona o tana kakau ka taea ko tenei kōpuku o edge, tupuna ranei.
    /// Mena ko te hua i whakahokia mai he `Split`, ko te mara `left` te putake pakiaka.
    /// Ka tohu te tohu atawhai ki te uara whakauru.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Ka kitea te kohinga i tohua e tenei edge.
    ///
    /// Ma te ingoa tikanga koe e whakaahua nga rakau me te aka o te aka i runga.
    ///
    /// `edge.descend().ascend().unwrap()` me `node.ascend().unwrap().descend()` kia rua, i runga i te angitu, kaua e mahi i tetahi mea.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Me whakamahi nga tohu tohu ki nga kōpuku na te mea, mena ko te BorrowType he marker::ValMut, tera pea he tohutoro tino rereke mo nga uara kaore e tika kia whakakorea e taatau.
        // Kaore he awangawanga ki te uru atu ki te mara teitei na te mea kua taarua taua uara.
        // Kia tupato, ka whakatakahia te tohu tohu o te kōpuku, ka uru atu ki nga raarangi tapa me te tohutoro (Rust putanga #73987) ka whakakore i etahi atu korero ki roto ranei o te raarangi, me huri noa.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Kaore e taea te karanga i nga tikanga matua me nga uara motuhake, na te mea ko te karanga i te tuarua ka whakakorengia te tohutoro i whakahokia mai e te tuatahi.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Whakakapihia te matua me te uara e pa ana ki te kakau KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Ka awhina i te whakamahi i te `split` mo te `NodeType` motuhake, ma te tiaki i nga tuhinga rau.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Ka tohatohahia te kohinga matua ki nga waahanga e toru:
    ///
    /// - Ka whakahekehia te kōpuku kia mau noa nga takirua uara-matua ki te maui o tenei kakau.
    /// - Ko te matua me te uara kua tohua e tenei kakau ka tangohia.
    /// - Ko nga takirua uara-matua katoa kei te taha matau o tenei kakau ka hoatu ki roto i te kopae kua tohaina.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Ka tangohia te tokorua uara-matua kua tohua e tenei kakau ka whakahokia mai, me te edge i taka te takirua-uara matua ki roto.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Ka tohatohahia te kohinga matua ki nga waahanga e toru:
    ///
    /// - Ka whakahekehia te kōpuku kia mau ki nga pito me nga takirua uara-matua ki te taha maui o tenei kakau.
    /// - Ko te matua me te uara kua tohua e tenei kakau ka tangohia.
    /// - Ko nga taha katoa me nga takirua uara-matua ki te taha matau o tenei kakau ka hoatu ki roto i te kopae kua tohaina.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// He tohu mo tetahi huihuinga mo te arotake me te whakahaere i tetahi mahi pauna huri noa i te takirua matua-uara o roto.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ka kowhiri i tetahi horopaki taurite e pa ana ki te kōpuku i a koe e tamariki ana, ana i waenga i te KV tonu ki te taha maui, ki te taha matau ranei o te kopu matua.
    /// Whakahokia ai te `Err` mena kaore he matua.
    /// Panics mena he putu te matua.
    ///
    /// He pai ki te taha maui, kia pai mena he iti ake te koromatua, ko te tikanga he iti ake ona waahanga i tana tuakana maui, me ona taina matau, mena kei te noho tonu raatau.
    /// I roto i tena, ko te honohono me te teina maui he tere ake, na te mea me neke noa nga huanga N o te kōpuku, kaua ki te neke ki te taha matau ka neke neke atu i nga waahanga N i mua.
    /// Ko te tahae mai i te teina maui he tere ake hoki, na te mea me huri noa nga huanga N ki te taha matau, kaua ki te neke N iti o nga mea a te teina ki te taha maui.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Ka hoki mai mena ka taea te whakakotahitanga, arā, mena he rahi te waahi i roto i te kōpuku hei whakakotahi i te KV matua me nga pona tamariki e rua e piri ana.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Ka mahi hanumi ka taea ma te katinga e whakatau he aha te whakahoki.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SAFETY: ko te teitei o nga kohinga e honoa ana ko tetahi i raro i te teitei
                // o te kōpuku o tenei edge, kei runga ake nei te kore, na ko a roto ano.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Ka whakauruhia te rua-uara matua o nga maatua me nga pona o te tamaiti e piri ana ki te pona o te tamaiti maui ka whakahoki i te kopae matua whakaheke.
    ///
    ///
    /// Panics ki te kore `.can_merge()` matou.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Ka whakauruhia te matua-uara takirua a nga maatua me nga pona o te tamaiti e piri ana ki te kōpuku tamaiti maui ka whakahoki i te kōpuku tamaiti.
    ///
    ///
    /// Panics ki te kore `.can_merge()` matou.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Ka whakauruhia te matua-uara matua me nga pona e rua e piri ana ki te kopae o te tamaiti maui ka whakahoki i te kakau edge i roto i taua kopae tamaiti ka mutu te tamaiti kua mau i te edge,
    ///
    ///
    /// Panics ki te kore `.can_merge()` matou.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Tango ai i te takirua uara-matua mai i te tamaiti maui ka waiho ki te putunga uara matua o te matua, me te akiaki i te matua-uara matua matua ki te tamaiti matau.
    ///
    /// Whakahoki ai i te kakau ki te edge i roto i te tamaiti matau e hangai ana ki te wahi i tutuki ai te edge taketake e `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Tangohia ai te takirua uara-matua mai i te tamaiti matau ka waiho ki te putunga uara-matua o te matua, me te akiaki i te matua-uara matua matua ki te tamaiti maui.
    ///
    /// Whakahokia ai te kakau ki te edge i te tamaiti maui i kiia e `track_left_edge_idx`, kaore i neke.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// He tahae tenei e rite ana ki te `steal_left` engari he tahae nga waahanga maha i te wa kotahi.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Tirohia mēnā e kia tahae humarie matou.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Nekehia nga tuhinga rau.
            {
                // Whakaritehia he waahi mo nga mea tahae i roto i te tamaiti tika.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Nekehia nga huanga mai i te tamaiti maui ki te taha matau.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Nekehia te tokorua taha maui-tahaetia ki te matua.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Nekehia te matua-uara matua ki te tamaiti matau.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Whakaritehia he waahi mo nga tahae tahaetia.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Tahae tahae.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Ko te kaata hangarite o `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Tirohia mēnā e kia tahae humarie matou.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Nekehia nga tuhinga rau.
            {
                // Nuku te tika-tino tahaetia rua ki te matua.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Nekehia te matua-uara matua ki te tamaiti maui.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Nekehia nga huanga mai i te tamaiti matau ki te maui.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Whakakiia te waatea i nga waahi i tahaetia i mua.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Tahae tahae.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Whakakiia te waahi kua tahaehia nga tahae i mua.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Ka tangohia nga korero tuuturu e kii ana ko tenei kōpuku he kōpuku `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ka tangohia nga korero tuuturu e kii ana ko tenei kōpuku he kōpuku `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Ka tirotirohia ko te kōpuku e whai kiko ana he kōpuku `Internal` he kōpuku `Leaf` ranei.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Nekehia te taapi i muri o te `self` mai i tetahi kōpuku ki tetahi atu.Me noho kore te `right`.
    /// Ko te edge tuatahi o `right` kaore ano kia rereke.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Hua o te whakaurunga, ka hiahiatia ana te kōpuku ki te whakawhānui atu i tōna āheinga.
pub struct SplitResult<'a, K, V, NodeType> {
    // Node rereke i roto i te rakau e mau ana me nga waahanga me nga taha kei te taha maui o `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Kua wehea etahi matua me te uara, ki te whakauru ki etahi atu waahi.
    pub kv: (K, V),
    // Kei a koe, kaore ano kia piri, he kōpuku hou me nga huanga me nga taha kei te taha matau o `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Ahakoa ko nga tohutoro kōpuku o tenei momo nama ka ahei te whakawhiti ki etahi atu kōpuku o te rākau.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Kaore e hiahiatia te whakawhiti, ma te whakamahi i te hua o `borrow_mut`.
        // Ma te whakakore i te whakawhiti, me te hanga tohu hou noa ki nga pakiaka, ka mohio taatau ko nga tohutoro o te momo `Owned` he tohu pakiaka.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Ka whakauruhia he uara ki roto i te waahanga o nga waahanga timatanga ka whai mai tetahi waahanga kaore i whakamanahia.
///
/// # Safety
/// He nui ake i te `idx` nga waahanga o te poro.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Ka tangohia ka whakahoki mai i te uara mai i te waahanga o nga waahanga timatanga katoa, ka waiho i muri i te waahanga e kore e whai mana.
///
///
/// # Safety
/// He nui ake i te `idx` nga waahanga o te poro.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Ka huri i nga waahanga ki nga waahanga `distance` poro ki te taha maui.
///
/// # Safety
/// Ko te poroi he iti rawa nga waahanga `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Ka huri i nga waahanga ki nga waahanga `distance` poro ki te taha matau.
///
/// # Safety
/// Ko te poroi he iti rawa nga waahanga `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Ka nekehia nga uara katoa mai i te waahanga o nga waahanga timatanga ki te waahanga o nga waahanga kaore i whakauruhia, ka waiho ko `src` kaore ano kia whakauruhia.
///
/// Mahi rite `dst.copy_from_slice(src)` engari kaore e hiahiatia te `T` kia `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;