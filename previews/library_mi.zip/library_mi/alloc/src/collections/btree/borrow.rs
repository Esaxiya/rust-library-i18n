use core::marker::PhantomData;
use core::ptr::NonNull;

/// Whakatauhia he moni whakahoki mo etahi korero motuhake, ka mohio ana koe ko te nama me ona uri katoa (ara, ko nga tohu katoa me nga tohutoro i ahu mai i a ia) kaore e whakamahia i etahi wa, ka mutu ka hiahia koe ki te whakamahi ano i te tuhinga motuhake motuhake. .
///
///
/// Ko te kaitono kaitono i te nuinga o te wa ka mahi i tenei puranga pounamu maau, engari ko etahi rerenga whakahaere e tutuki ana i tenei puranga he uaua rawa kia kore e whai ake te kaiwhakangungu.
/// Ma te `DormantMutRef` e ahei te tirotiro i to tarewa i a koe ano, i te wa e whakaputa ana i te ahua o te puranga, me te whakakii i te waehere tohu tika hei mahi i tenei me te kore whanonga kore.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Hopuhia he nama motuhake, ka whakahoki ano i taua wa.
    /// Mo te kaiwhakaputu, ko te roanga o te tohutoro hou he rite ki te oranga o te tohutoro taketake, engari ko koe te promise ki te whakamahi mo te wa poto.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SAFETY: kei te purihia e maatau nga nama puta noa i te 'a ma te `_marker`, ka whakaatu taatau
        // ko tenei tohutoro anake, no reira he mea tuuturu.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Hoki ki te nama motuhake i mau i te timatanga.
    ///
    /// # Safety
    ///
    /// Ko te nama kua mutu, ara, ko te tohutoro i whakahokia mai e `new` me nga tohu tohu katoa me nga tohutoro i ahu mai i roto, kaua e whakamahia ano.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SAFETY: ko ta tatou ake tikanga ahuru e tohu ana he motuhake ano tenei korero.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;