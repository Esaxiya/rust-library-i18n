//! He raarangi hono-hono me nga kopae rangatira.
//!
//! Ma te `LinkedList` e ahei te pana me te pupuhi i nga waahanga i tetahi pito o te waa.
//!
//! NOTE: He pai ake te pai ki te whakamahi i te [`Vec`] ko te [`VecDeque`] na te mea he tere ake te ipu o te rahinga, he pai ake te mahara, me te whakamahi pai i te kete CPU.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// He raarangi hono-hono me nga kopae rangatira.
///
/// Ma te `LinkedList` e ahei te pana me te pupuhi i nga waahanga i tetahi pito o te waa.
///
/// NOTE: He pai ake te pai ki te whakamahi i te `Vec` ko te `VecDeque` na te mea he tere ake te ipu o te rahinga, he pai ake te mahara, me te whakamahi pai i te kete CPU.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// He kaituku hiko mo nga waahanga o te `LinkedList`.
///
/// Ko tenei `struct` na [`LinkedList::iter()`] i hanga.
/// Tirohia ona tuhinga mo te roanga atu.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Tangohia kia pai te `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// He miihini hurihuri mo nga waahanga o te `LinkedList`.
///
/// Ko tenei `struct` na [`LinkedList::iter_mut()`] i hanga.
/// Tirohia ona tuhinga mo te roanga atu.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // Kaore i a matou anake te raarangi katoa o konei, ko nga tohutoro ki te node's `element` kua tohaina e te kaitohu!Na kia tupato ki te whakamahi i tenei;Me kia mōhio e reira e taea e aliasing atatohu ki `element` nga tikanga i huaina.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// He kaituku hiko kei runga ake i nga waahanga o te `LinkedList`.
///
/// Ko tenei `struct` i hangaia e te tikanga [`into_iter`] i runga i te [`LinkedList`] (na te `IntoIterator` trait).
/// Tirohia ona tuhinga mo te roanga atu.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// tikanga tūmataiti
impl<T> LinkedList<T> {
    /// Ka taapirihia te kōpuku kua tukuna ki mua o te raarangi.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Kia tupato tenei tikanga kia kaua e hanga i nga tohu huri ki nga kōpuku katoa, kia mau ai te pono o nga tohu tohu ki te `element`.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Kaore i te hanga i nga tohutoro (unique!) hou ka taea te whakakapi i te `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// Ka tangohia ka whakahoki i te kōpuku ki mua o te raarangi.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Kia tupato tenei tikanga kia kaua e hanga i nga tohu huri ki nga kōpuku katoa, kia mau ai te pono o nga tohu tohu ki te `element`.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Kaore i te hanga i nga tohutoro (unique!) hou ka taea te whakakapi i te `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Ka taapirihia te kōpuku kua hoatuhia ki muri o te raarangi.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Kia tupato tenei tikanga kia kaua e hanga i nga tohu huri ki nga kōpuku katoa, kia mau ai te pono o nga tohu tohu ki te `element`.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Kaore i te hanga i nga tohutoro (unique!) hou ka taea te whakakapi i te `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// Ka tangohia ka whakahoki i te kōpuku kei muri o te raarangi.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Kia tupato tenei tikanga kia kaua e hanga i nga tohu huri ki nga kōpuku katoa, kia mau ai te pono o nga tohu tohu ki te `element`.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Kaore i te hanga i nga tohutoro (unique!) hou ka taea te whakakapi i te `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Ka tango i te tohu kua tohua mai i te raarangi onaianei.
    ///
    /// Whakatūpato: kaore tenei e tirohia ko te kopae kua tohaina no te raarangi o naianei.
    ///
    /// Ko tenei tikanga ka tupato kia kaua e hanga i nga tohu ka taea te whakarereke i te `element`, kia mau tonu ai te tohu tohu tohu.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // ko tenei tetahi mo tatou inaianei, ka taea e taatau te hanga &mut.

        // Kaore i te hanga i nga tohutoro (unique!) hou ka taea te whakakapi i te `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // ko tenei kōpuku te kōpuku upoko
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // ko tenei kōpuku te kohinga hiku
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Ka taapirihia he raupapa kōpuku i waenga i ngā kōpuku e rua.
    ///
    /// Whakatūpato: kaore tenei e tirohia ko nga kohinga e rua kua tohaina ki nga raarangi e rua.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // e tenei tikanga tiaki e kore ki te waihanga tohutoro mutable maha ki kōpuku katoa i te wa ano, ki te mau tonu mana o aliasing atatohu ki `element`.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// Ka wehe i nga kohinga katoa mai i te raarangi hono hei raupapa kōpuku.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Ko te kōpuku wehewehe ko te kōpuku upoko hou o te waahanga tuarua
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Whakatika i te matenga PTR o te wahi tuarua
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Ko te kōpuku wehewehe ko te kōpuku hiku hou o te waahanga tuatahi ka mau ki a ia te mahunga o te waahanga tuarua.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Whakatikahia te hiku ptr o te waahanga tuatahi
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// Ka waihanga i te `LinkedList<T>` kau.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// Ka waihanga i te `LinkedList` kau.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// Ka nekehia nga waahanga katoa mai i te `other` ki te mutunga o te raarangi.
    ///
    /// Ka whakamahi tenei i nga waahanga katoa mai i `other` ka neke ki te `self`.
    /// I muri i tenei mahinga, ka noho kore te `other`.
    ///
    /// Me tatau tenei mahi ki te wa *O*(1) me te mahara *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` kei te pai i konei na te mea e uru motuhake ana taatau ki nga raarangi e rua.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Nekeneke huānga katoa i `other` ki te timata o te rārangi.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` kei te pai i konei na te mea e uru motuhake ana taatau ki nga raarangi e rua.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Ka whakarato i te whiti whakamua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// Ka whakawhiwhia ki tetahi kaituku whakamua ki nga tohutoro ka taea te whakarereke.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// Ka whakarato pehu i te waahanga o mua.
    ///
    /// Kei te tohu te pehu ki te "ghost" kore-huanga mena he putu te raarangi.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// Ka whakarato i te pehu me nga mahi whakatika i te waahanga o mua.
    ///
    /// Kei te tohu te pehu ki te "ghost" kore-huanga mena he putu te raarangi.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// Ka whakarato pehu i te waahanga o muri.
    ///
    /// Kei te tohu te pehu ki te "ghost" kore-huanga mena he putu te raarangi.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Ka whakarato i te pehu me nga mahi whakatika i te waahanga o muri.
    ///
    /// Kei te tohu te pehu ki te "ghost" kore-huanga mena he putu te raarangi.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Whakahoki ai i te `true` mena he putu te `LinkedList`.
    ///
    /// Me tatau tenei mahinga i roto i te *O*(1) wa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// Whakahoki ai i te roa o te `LinkedList`.
    ///
    /// Me tatau tenei mahinga i roto i te *O*(1) wa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Ka tangohia nga waahanga katoa mai i te `LinkedList`.
    ///
    /// Me tatau tenei mahinga i te waa *O*(*n*).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// Whakahoki `true` mena kei te `LinkedList` tetahi huanga rite ki te uara kua whakaritea.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// Ka whakarato tohutoro ki te waahanga o mua, ki te `None` ranei mena he kau te raarangi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Ka whakarato tohutoro ka taea te whakarereke i te waahanga o mua, te `None` ranei mena kaore he rarangi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Ka whakarato tohutoro ki te tuara o muri, ki te `None` mena kaore he raarangi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Ka whakarato tohutoro ka taea te whakarereke i te taha o muri, te `None` ranei mena kaore he raarangi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Ka taapirihia he waahanga i te raarangi.
    ///
    /// Me tatau tenei mahinga i roto i te *O*(1) wa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// Ka tangohia te waahanga tuatahi ka whakahoki mai, `None` mena kaore he raarangi.
    ///
    ///
    /// Me tatau tenei mahinga i roto i te *O*(1) wa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// Ka taapirihia he waahanga ki muri o te raarangi.
    ///
    /// Me tatau tenei mahinga i roto i te *O*(1) wa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// Ka tangohia te waahanga whakamutunga mai i te raarangi ka whakahoki mai, `None` ranei mena he kau.
    ///
    ///
    /// Me tatau tenei mahinga i roto i te *O*(1) wa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// Wehea te raarangi kia rua ki te taurangi kua tohua.
    /// Whakahoki ai i nga mea katoa i muri o te tohu kua tohaina, tae atu ki te taurangi.
    ///
    /// Me tatau tenei mahinga i te waa *O*(*n*).
    ///
    /// # Panics
    ///
    /// Panics mena ko `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // Kei raro nei, ka toro atu ki te kōpuku "i-1", mai i te tīmatanga, i te mutunga ranei, kei whea te tere ake.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // kaua te pekepeke ma te whakamahi i te .skip() (e hanga ana i tetahi waahanga hou), ka pekehia a ringa kia uru ai tatou ki te mara upoko kaore e whakawhirinaki ki nga korero whakatinana o te Hoko.
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // he pai ake ka tiimata mai i te mutunga
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// Ka tango i te waahanga i te taupū i homai ka whakahokia mai.
    ///
    /// Me tatau tenei mahinga i te waa *O*(*n*).
    ///
    /// # Panics
    /// Panics mena kei>=len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // Kei raro nei, ka toro atu ki te kōpuku i te taupūtanga, mai i te tiimata, i te mutunga ranei, ma tehea e tere ake ai.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// Ka waihangahia he taatai e whakamahi ana i te katinga hei whakatau mena ka tangohia tetahi waahanga.
    ///
    /// Mena he pono te katinga, ka tangohia te waahanga ka tukuna.
    /// Mena ka hoki mai te katinga he teka, ka noho tonu te waahanga ki te raarangi kaare e tukuna e te kaitohu.
    ///
    /// Kia mahara ma te `drain_filter` ka ahei koe ki te whakarereke i nga waahanga katoa i te katinga o te taatari, ahakoa e hiahia ana koe ki te pupuri ki te tango atu ranei.
    ///
    ///
    /// # Examples
    ///
    /// Wehea te raarangi ki nga ahiahi me nga taarua, me te whakamahi ano i te raarangi taketake:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // karo i nga take nama.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Haere tonu ki te koropiko e mahia ana e matou i raro.Ka rere noa tenei ka panikiri te kaipahua.
                // Mena tetahi panics tetahi ka whakakorehia.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Me whai oranga kore ki te tiki 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Me whai oranga kore ki te tiki 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Me whai oranga kore ki te tiki 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Me whai oranga kore ki te tiki 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// He pehu kei runga i te `LinkedList`.
///
/// He `Cursor` he rite ki te miihini, haunga tera ka taea te rapu noa-i-muri.
///
/// Ko nga pehu ka okioki i waenga i nga waahanga e rua o te raarangi, ka tohu i te ara porowhita.
/// Hei whakauru i tenei, kei kona tetahi-kore "ghost" waahanga `None` i waenga i te upoko me te hiku o te raarangi.
///
///
/// Ka hangaia ana, ka tiimata nga pehu ki mua o te raarangi, ki te "ghost" ranei kaore i te waahanga mena ka noho kau te raarangi.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// He pehu kei runga i te `LinkedList` me nga mahi whakatika.
///
/// Ko te `Cursor` he rite ki te miihini, engari ka taea e ia te rapu noa-i-muri, ka taea te whakarereke i te raarangi i te waa korerorero.
/// Na te mea ko te oranga o nga tohutoro whakaputa ka herea ki tona ake ao, kaua ki te raarangi e whai take ana.
/// Ko te tikanga kaore e taea e nga kanga te whakaputa i nga waahanga maha i te wa kotahi.
///
/// Ko nga pehu ka okioki i waenga i nga waahanga e rua o te raarangi, ka tohu i te ara porowhita.
/// Hei whakauru i tenei, kei kona tetahi-kore "ghost" waahanga `None` i waenga i te upoko me te hiku o te raarangi.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// Whakahoki ai i te tohu taunga pehu i roto i te `LinkedList`.
    ///
    /// Ka hoki mai tenei i te `None` mena kei te tohu te pehu ki te "ghost" kore-huanga.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Ka nekehia te pehu ki te waahanga o muri o te `LinkedList`.
    ///
    /// Mena kei te tohu te pehu ki te "ghost" kore-huanga ka neke tenei ki te waahanga tuatahi o te `LinkedList`.
    /// Mena kei te tohu atu ki te waahanga whakamutunga o te `LinkedList` ka neke tenei ki te "ghost" kore-huanga.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Kare o maatau timatanga;i noho i te pehu i te tūnga tīmatanga kia huānga Next te matenga o te rārangi
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // He kaupapa o mua ta tatou, na kia haere ki tona panui
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Ka nekehia te pehu ki te waahanga o mua o te `LinkedList`.
    ///
    /// Mena kei te tohu te pehu ki te "ghost" kore-huanga ka neke tenei ki te waahanga whakamutunga o te `LinkedList`.
    /// Mena kei te tohu ki te waahanga tuatahi o te `LinkedList` ka neke tenei ki te "ghost" kore-huanga.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Kaore he au.Kei te timatanga o te raarangi matou.Hua Kore Ka peke ki te pito.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Kia paiTukuna ka haere ki te waahanga o mua.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Whakahoki ai i te korero ki te waahanga e tarai ana te pehu ki tenei wa.
    ///
    /// Ka hoki mai tenei i te `None` mena kei te tohu te pehu ki te "ghost" kore-huanga.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// Whakahoki ai i te korero ki te kaupapa e whai ake nei.
    ///
    /// Mena kei te tohu te pehu ki te "ghost" kore-huanga ka hoki mai tenei i te waahanga tuatahi o te `LinkedList`.
    /// Mena kei te tohu i te waahanga whakamutunga o te `LinkedList` ka hoki mai tenei `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// Whakahoki ai i te korero ki te kaupapa o mua.
    ///
    /// Mena kei te tohu te pehu ki te "ghost" kore-huanga ka hoki mai tenei i te waahanga whakamutunga o te `LinkedList`.
    /// Mena kei te tohu ki te waahanga tuatahi o te `LinkedList` ka hoki mai tenei `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// Whakahoki ai i te tohu taunga pehu i roto i te `LinkedList`.
    ///
    /// Ka hoki mai tenei i te `None` mena kei te tohu te pehu ki te "ghost" kore-huanga.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Ka nekehia te pehu ki te waahanga o muri o te `LinkedList`.
    ///
    /// Mena kei te tohu te pehu ki te "ghost" kore-huanga ka neke tenei ki te waahanga tuatahi o te `LinkedList`.
    /// Mena kei te tohu atu ki te waahanga whakamutunga o te `LinkedList` ka neke tenei ki te "ghost" kore-huanga.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Kare o maatau timatanga;i noho i te pehu i te tūnga tīmatanga kia huānga Next te matenga o te rārangi
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // He kaupapa o mua ta tatou, na kia haere ki tona panui
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Ka nekehia te pehu ki te waahanga o mua o te `LinkedList`.
    ///
    /// Mena kei te tohu te pehu ki te "ghost" kore-huanga ka neke tenei ki te waahanga whakamutunga o te `LinkedList`.
    /// Mena kei te tohu ki te waahanga tuatahi o te `LinkedList` ka neke tenei ki te "ghost" kore-huanga.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Kaore he au.Kei te timatanga o te raarangi matou.Hua Kore Ka peke ki te pito.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Kia paiTukuna ka haere ki te waahanga o mua.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Whakahoki ai i te korero ki te waahanga e tarai ana te pehu ki tenei wa.
    ///
    /// Ka hoki mai tenei i te `None` mena kei te tohu te pehu ki te "ghost" kore-huanga.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// Whakahoki ai i te korero ki te kaupapa e whai ake nei.
    ///
    /// Mena kei te tohu te pehu ki te "ghost" kore-huanga ka hoki mai tenei i te waahanga tuatahi o te `LinkedList`.
    /// Mena kei te tohu i te waahanga whakamutunga o te `LinkedList` ka hoki mai tenei `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// Whakahoki ai i te korero ki te kaupapa o mua.
    ///
    /// Mena kei te tohu te pehu ki te "ghost" kore-huanga ka hoki mai tenei i te waahanga whakamutunga o te `LinkedList`.
    /// Mena kei te tohu ki te waahanga tuatahi o te `LinkedList` ka hoki mai tenei `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// Whakahoki ai i te pehu pānui-anake e tohu ana ki te waahanga o inaianei.
    ///
    /// Ko te oranga o te `Cursor` i hoki mai ka herea ki tera o te `CursorMut`, ko te tikanga kaore e taea te ora ake i te `CursorMut` ana ka hurihia te `CursorMut` mo te roanga o te `Cursor`.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// Na, ko nga mahi whakarereke raarangi

impl<'a, T> CursorMut<'a, T> {
    /// Ka whakauruhia he waahanga hou ki te `LinkedList` i muri i tenei waa.
    ///
    /// Mena kei te tohu te pehu i te "ghost" kore-huanga ka whakauruhia te waahanga hou ki mua o te `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // Kua rereke te taurangi kore-huanga a "ghost".
                self.index = self.list.len;
            }
        }
    }

    /// Ka whakauruhia he waahanga hou ki te `LinkedList` i mua i tenei waa.
    ///
    /// Mena kei te tohu te pehu i te "ghost" kore-huanga ka whakauruhia te waahanga hou ki te pito o te `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// Ka tangohia te waahanga o teianei mai i te `LinkedList`.
    ///
    /// Ko te mea i tangohia i tangohia ka whakahokia mai, ka nekehia te pehu ki te tohu ki te waahanga e whai ake nei i te `LinkedList`.
    ///
    ///
    /// Mena kei te tohu te pehu ki te "ghost" kore-huanga kaore he waahanga i tangohia ka whakahokia mai a `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// Ka tangohia te waahanga o naianei mai i te `LinkedList` me te kore e tohatoha i te kōpuku raarangi.
    ///
    /// Ko te kōpuku i tangohia i whakahokia mai he `LinkedList` hou kei roto noa tenei kōpuku.
    /// Ka nekehia te pehu kia tohu ki te waahanga e whai ake nei i te `LinkedList` o naianei.
    ///
    /// Mena kei te tohu te pehu ki te "ghost" kore-huanga kaore he waahanga i tangohia ka whakahokia mai a `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// Ka whakauruhia nga waahanga mai i te `LinkedList` i homai i muri o nga mea o naianei.
    ///
    /// Mena kei te tohu te pehu i te "ghost" kore-huanga ka whakauruhia nga waahanga hou i te tiimatanga o te `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // Kua rereke te taurangi kore-huanga a "ghost".
                self.index = self.list.len;
            }
        }
    }

    /// Whakauruhia nga waahanga mai i te `LinkedList` i mua i tenei waa.
    ///
    /// Mena kei te tohu te pehu i te "ghost" kore-huanga ka whakauruhia nga waahanga hou ki te pito o te `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// Whakawehe te rārangi i muri i te huānga o nāianei ki rua.
    /// Ka hoki mai tenei i tetahi raarangi hou kei roto katoa i muri i te pehu, me te raarangi taketake ka pupuri i nga mea katoa i mua.
    ///
    ///
    /// Mena kei te tohu te pehu i te "ghost" kore-huanga ka neke nga mea katoa o te `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // Kua puta ke taupū te "ghost" kore huānga-a ki te 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// Ka wahia te raarangi kia rua i mua o te waahanga o teianei.
    /// Ka hoki mai tenei he rārangi hou arā, o nga mea katoa i mua i te pehu, me te rārangi taketake pupuri mea katoa i muri.
    ///
    ///
    /// Mena kei te tohu te pehu i te "ghost" kore-huanga ka neke nga mea katoa o te `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// He miihini kua hangaia ma te waea `drain_filter` ki te LinkedList.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` he pai ki te whakakahore i nga tohutoro `element`.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Ka pau te raarangi ki roto i te miihini e whakaputa ana i nga waahanga ma te uara.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Me whakarite e he covariant i roto i o ratou tawhā momo `LinkedList` me ona iterators pānui-anake.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}