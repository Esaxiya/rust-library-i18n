//! He raarangi takirua takirua kua whakatinanahia me te peera whakatipu whakatipu.
//!
//! Ko tenei rarangi e *O*(1) nga whakauru whakaurunga me nga tangohanga mai i nga pito e rua o te ipu.
//! Kei a ia ano te *O*(1) taupū rite ki te vector.
//! Ko nga waahanga o roto kaore e hiahiatia kia taea te kape, ana ka tukuna te rarangi mena ka tukuna te momo kei roto.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Te mana nui rawa atu o te rua

/// He raarangi takirua takirua kua whakatinanahia me te peera whakatipu whakatipu.
///
/// Ko te whakamahinga "default" o tenei momo hei tuunga he whakamahi i te [`push_back`] hei taapiri ki te raarangi, me te [`pop_front`] ki te tango mai i te raarangi.
///
/// [`extend`] me te [`append`] pana ki tua o tenei tikanga, ana ko te taarua i runga i te `VecDeque` kei mua ki muri.
///
/// I te mea ko te `VecDeque` he miihini mowhiti, kaore i te kaha te hono o nga ahuatanga ki te maumahara.
/// Mena kei te hiahia koe ki te whakauru ki nga waahanga hei waahanga kotahi, peera mo te tohatoha pai, ka taea e koe te whakamahi i te [`make_contiguous`].
/// Ka hurihia te `VecDeque` kia kore e takai ona huanga, ka whakahoki i tetahi waahanga whakarereke ki te waahanga o te waahanga-inaianei.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // ko te hiku me te mahunga he tohu ki roto i te para.
    // Ka tohu tonu te hiku ki te kaupapa tuatahi ka taea te korero, ka tohu tonu te Upoko ki te wahi e tuhia ai nga raraunga.
    //
    // Ki te hiku==upoko ko kau te moka.Ko te roa o te ringbuffer kua tautuhia hei tawhiti i waenga i nga mea e rua.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Whakahaerehia te kaipahua mo nga taonga katoa i te poro ka tohatoha ana (he tikanga, i te waa ranei).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // whakamahia te taka mo te [T]
            ptr::drop_in_place(front);
        }
        // Ka whakahaerehia e RawVec te whakawhitinga
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Ka waihanga i te `VecDeque<T>` kau.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// He pai ake te takataka
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// He pai ake te takataka
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Mo nga momo rahinga kore, kei te kaha tonu to taatau
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Hurihia te ptr ki te poro
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Tahuri PTR ki te wāhanga mut
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Ka nekehia atu tetahi huanga mai i te buffer
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Ka tuhi i tetahi waahanga ki roto i te pararai, neke ana.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Whakahoki ai i te `true` mena he kaha te buffer.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Whakahoki ai i te taupū i te kaupapapapapaku whai take mo te taupū huanga arorau kua hoatu.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Whakahoki ai i te taupū i te kaupapapapapaku whai take mo te taupū huanga arorau + taapiringa.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Whakahoki ai i te taupū i te kaupapapapapaku whai take mo tetahi tohu huanga arorau, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Kape te poraka pātata o te mahara Len roa i src ki dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kape te poraka pātata o te mahara Len roa i src ki dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Ka kape i tetahi poraka maumahara pea mai i te src ki te waahi.
    /// (abs(dst - src) + len) kaua e nui ake i te cap() (Kia kotahi pea te nui o te rohe inaki i waenga i te src me te waahi).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // Kaore a src e takai, kaore e roropi
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // Tuhinga o mua src, src kaore e takai, ka takai
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src i mua i te dst, src kaore e takai, ka takai
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // Tuhinga o mua src, src takai, dst kaore e takai
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src i mua i te dst, src takai, dst kaore e takai
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // Tuhinga o mua src, src takai, dst takai
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src i mua i te dst, src takai, dst takai
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs te upoko me te hiku o nga waahanga huri noa ki te hapai i te meka i toha atu ano taatau.
    /// Kaore i te haumaru na te mea ka whakawhirinaki ki te-tawhito.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Nekehia te waahanga iti rawa o te mowhiti mowhiti TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // He Kore
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Ka waihanga i te `VecDeque` kau.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Ka waihangahia he `VecDeque` kau me te waahi mo nga waahanga `capacity` iti rawa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 mai i te wa ko te ringbuffer e waatea tonu ana i tetahi waahi
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Ka whakarato tohutoro ki te waahanga o te taurangi kua tohua.
    ///
    /// Ko te timatanga o te tohu 0 te mua o te raarangi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Whakarato te tohutoro mutable ki te huānga i te taupū homai.
    ///
    /// Ko te timatanga o te tohu 0 te mua o te raarangi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Hurihia nga huanga ki nga tohu `i` me `j`.
    ///
    /// `i` me te `j` kia orite.
    ///
    /// Ko te timatanga o te tohu 0 te mua o te raarangi.
    ///
    /// # Panics
    ///
    /// Panics mena kei waho o te rohe tetahi tohu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Whakahokia ai te maha o nga mea timatanga ka taea e te `VecDeque` te pupuri me te kore e tuutuhia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Ka rahuitia te kaha iti mo te tino `additional` atu waahanga hei whakauru ki te `VecDeque` kua homai.
    /// Kaore he mea mena kua ea te kaha.
    ///
    /// Kia mahara ma te Kaitoha e tuku atu ki te kohinga te nui ake o te waa i runga i ta te tono.
    /// Na reira kaore e taea te whakawhirinaki ki te kaha kia iti rawa.
    /// He pai ake te [`reserve`] mena e tatari ana kia whakauruhia a future.
    ///
    /// # Panics
    ///
    /// Panics mena ka kaha te kaha o te `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Ka tiakina te kaha mo te iti rawa atu o te `additional` atu waahanga hei whakauru ki te `VecDeque` i homai.
    /// Ka rahuitia pea e te kohinga etahi atu waahanga hei karo i nga waahi tuuturu.
    ///
    /// # Panics
    ///
    /// Panics mena ka kaha te kaha o te `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Ka ngana ki te rahui i te kaha iti mo te tino `additional` etahi atu waahanga hei whakauru ki te `VecDeque<T>` kua homai.
    ///
    /// I muri i te karanga `try_reserve_exact`, ka nui ake te kaha ki te rite ranei ki te `self.len() + additional`.
    /// Kaore he mea mena kua ea te kaha.
    ///
    /// Kia mahara ma te Kaitoha e tuku atu ki te kohinga te nui ake o te waa i runga i ta te tono.
    /// Na reira, kaore e taea te whakawhirinaki ki te kaha kia iti rawa.
    /// He pai te `reserve` mena e tatari ana kia whakauruhia a future.
    ///
    /// # Errors
    ///
    /// Mena ka kaha te kaha o te `usize`, ka ripoatatia ranei e te kaitoha he koretake, ka hoki mai he he.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Puritia te maumahara, ka puta ki te kore e taea
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Inaianei kua mohio taatau kaore e taea te OOM(Out-Of-Memory) i waenga o a maatau mahi uaua
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // tino uaua
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Ka ngana ki te rahui i te kaha mo te iti rawa atu o te `additional` atu waahanga hei whakauru ki te `VecDeque<T>` i homai.
    /// Ka rahuitia pea e te kohinga etahi atu waahanga hei karo i nga waahi tuuturu.
    /// I muri i te karanga `try_reserve`, ka nui ake te kaha ki te rite ranei ki te `self.len() + additional`.
    /// Kaore tetahi mea mena kua tau te kaha.
    ///
    /// # Errors
    ///
    /// Mena ka kaha te kaha o te `usize`, ka ripoatatia ranei e te kaitoha he koretake, ka hoki mai he he.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Puritia te maumahara, ka puta ki te kore e taea
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Inaianei kua mohio taatau kaore e taea te OOM i waenga o a maatau mahi uaua
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // tino uaua
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Ka tiimata te kaha o te `VecDeque` ki te taea.
    ///
    /// Ka heke tonu ki te waa ka taea te roa engari kei te mohio tonu te Kaitoha ki te `VecDeque` he waahi ano mo etahi atu waahanga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Ka tiimata te kaha o te `VecDeque` me te roopu o raro.
    ///
    /// Ko te kaha ka noho ko te iti rawa pea te roa me te uara kua tohaina.
    ///
    ///
    /// Mena he iti ake te kaha o naianei i te rohe o raro, he-kore tenei.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Kaore maatau e awangawanga mo te waipuke kaore e taea e `self.len()` me `self.capacity()` te `usize::MAX`.
        // +1 i te mea e waatea kau ana te ringbuffer i tetahi waahi.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // E toru nga keehi huamoni:
            //   Ko nga mea timatanga kaore i te rohe e hiahiatia ana He honohono nga huanga, a ko te upoko kaore i te rohe e hiahiatia ana He huakore nga huanga, a ko te hiku i nga rohe e hiahiatia ana
            //
            //
            // I etahi atu waa, kaore e raru nga tuunga huanga.
            //
            // E tohu ana me neke nga mea o te upoko.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Nekehia nga waahanga mai i nga rohe e hiahiatia ana (nga tuunga i muri i te whaainga_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Ka whakapoto i te `VecDeque`, ka pupuri i nga waahanga `len` tuatahi ka taka ki te toenga.
    ///
    ///
    /// Mena he nui ake te `len` i te roa o te "VecDeque`, kaore he painga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Whakahaerehia te kaipahua mo nga taonga katoa i te poro ka tohatoha ana (he tikanga, i te waa ranei).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Haumaru na te mea:
        //
        // * Ko nga poro kua tukuna ki te `drop_in_place` e whaimana ana;ko te keehi tuarua he `len <= front.len()` ana ka hoki mai ano ki te `len > self.len()` ka whakarite i te `begin <= back.len()` i te keehi tuatahi
        //
        // * Ka nekehia te upoko o te VecDeque i mua i te karanga i te `drop_in_place`, no reira kaore he utu e heke rua mena `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Kia mahara ki te heke o te haurua tuarua ahakoa he kaipatu whakangaro i te tuatahi o te panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Whakahoki ai i te iterator o mua-ki-muri.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Whakahoki ai i te kaitahuri o muri-ki-muri ka whakahoki i nga tohutoro ka taea te huri.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SAFETY: Ko te kaitautoko haumaru a `IterMut` o roto ka whakapumautia na te mea te
        // `ring` ka hangaia e maatau he poro whakakorea mo te roanga o te tau '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Whakahokia te rua o poro i roto i, i roto i te tikanga, i te tirotiro o te `VecDeque`.
    ///
    /// Mena i karangahia a [`make_contiguous`] i mua, ko nga waahanga katoa o te `VecDeque` ka waiho i te waahanga tuatahi ka noho kau te waahanga tuarua.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Whakahokia te rua o poro i roto i, i roto i te tikanga, i te tirotiro o te `VecDeque`.
    ///
    /// Mena i karangahia a [`make_contiguous`] i mua, ko nga waahanga katoa o te `VecDeque` ka waiho i te waahanga tuatahi ka noho kau te waahanga tuarua.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Whakahokia ai te maha o nga mea timatanga o te `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Whakahoki ai i te `true` mena he putu te `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Ka waihangahia he taatai e hipoki ana i te awhe kua tohua i te `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics mena he nui ake te tiimata i te pito mutunga mena he nui ake te pito whakamutunga i te roa o te vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Ka kapi katoa nga korero i te whānuitanga katoa
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Ko te korero mo taatau kei &self e mau tonu ana i te '_ o Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Ka waihangahia he taarua e hipoki ana i te awhe rereketanga i whakaritea i te `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics mena he nui ake te tiimata i te pito mutunga mena he nui ake te pito whakamutunga i te roa o te vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Ka kapi katoa nga korero i te whānuitanga katoa
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SAFETY: Ko te kaitautoko haumaru a `IterMut` o roto ka whakapumautia na te mea te
        // `ring` ka hangaia e maatau he poro whakakorea mo te roanga o te tau '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Ka waihangahia he miihini whakaheke e tango ana i te awhe kua tohua i te `VecDeque` ka whakaputa i nga taonga kua tangohia.
    ///
    /// Panui 1: Kua tangohia te awhe huanga ahakoa kaore i pau te miihini tae noa ki te mutunga.
    ///
    /// Panui 2: Kaore i te tohuhia he maha nga waahanga ka tangohia mai i te deque, mena ka kore e heke te uara `Drain`, engari ka pau te nama e purihia ana e ia (hei tauira, na `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics mena he nui ake te tiimata i te pito mutunga mena he nui ake te pito whakamutunga i te roa o te vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Ma te whānuitanga o te rangi e whakakore nga korero katoa
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Haumaru Mahara
        //
        // I te wa i hangaia tuatahihia ai te Drain, ka poroa te tuhinga takawaenga kia kore rawa e haangai kia neke atu ranei mai i nga waahanga kaore e taea te toro atu mena kaore rawa kia rere te kaipatu kino o te Drain.
        //
        //
        // Ma te Drain e ptr::read nga uara hei tango.
        // Ka mutu ana, ko nga toenga o nga tuhinga ka kape ano ki te kapi i te kohao, ana ka whakahokia tika nga uara head/tail.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // E wehe huānga o te deque ki toru wāhanga:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Ka penapenahia e maatau te drain_tail hei self.head, me te drain_head me te self.head i muri mai i te waahanga me muri i muri i te Drain.
        // Ka tuaina hoki tenei i te raupapa whaihua mena ka puta te Drain, kua wareware taatau mo nga uara neke pea i muri o te tiimatanga o te drain.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" e pa ana ki nga uara i muri o te tiimata o te drain tae noa ki te otinga o te drain ka whakahaerehia te kaipupuri Drain.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // He mea nui, ka hangaia noa e maatau he korero tohanga mai i te `self` i konei ka panui atu.
                // Kaore matou e tuhi ki a `self` kaore ano hoki e tatai ki te korero ka taea te whakarereke.
                // No reira ko te tohu atawhai i hangaia e matou i runga ake nei, mo te `deque`, kei te mau tonu.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Ka horoia te `VecDeque`, ka tangohia nga uara katoa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Whakahoki `true` mena kei te `VecDeque` tetahi huanga rite ki te uara kua whakaritea.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Ka whakarato tohutoro ki te waahanga o mua, ki te `None` ranei ki te kore he `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Ka whakarato i te korero whakarereke ki te waahanga o mua, ki te `None` ranei mena he putua te `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Ka whakarato tohutoro ki te kaupapa o muri, ki te `None` ranei mena he putua te `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Ka whakarato tohutoro ka taea te whakarereke i te taha o muri, te `None` ranei mena he putua te `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Ka tangohia te waahanga tuatahi ka whakahoki mai, ko `None` mena he putu te `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Ka tangohia te waahanga whakamutunga mai i te `VecDeque` ka whakahoki mai, `None` ranei mena he kau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Ka whakarite i tetahi waahanga ki te `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Ka taapirihia he waahanga ki muri o te `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Me whakaarohia e `head == 0` te tikanga
        // e he pātata `self`?
        self.tail <= self.head
    }

    /// Ka tangohia tetahi waahanga mai i nga wa katoa o te `VecDeque` ka whakahoki mai, ka whakakapihia ki te waahanga tuatahi.
    ///
    ///
    /// Kaore tenei e tiakina te ota, engari ko *O*(1).
    ///
    /// Whakahoki ai i te `None` mena kaore i te rohe te `index`.
    ///
    /// Ko te timatanga o te tohu 0 te mua o te raarangi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Ka tangohia tetahi waahanga mai i nga wa katoa o te `VecDeque` ka whakahoki mai, ka whakakapihia ki te waahanga whakamutunga.
    ///
    ///
    /// Kaore tenei e tiakina te ota, engari ko *O*(1).
    ///
    /// Whakahoki ai i te `None` mena kaore i te rohe te `index`.
    ///
    /// Ko te timatanga o te tohu 0 te mua o te raarangi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Ka whakauruhia he waahanga ki `index` i roto i te `VecDeque`, ka neke i nga waahanga katoa me nga tohu he nui ake i te orite ranei ki te `index` ki muri.
    ///
    ///
    /// Ko te timatanga o te tohu 0 te mua o te raarangi.
    ///
    /// # Panics
    ///
    /// Panics mena he nui ake te `index` i te roa o 'VecDeque`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Nekehia te iti rawa o nga waahanga i roto i te mowhiti mowhiti ka whakauru i te mea kua hoatu
        //
        // I te nuinga o te len/2, 1 nga waahanga ka nekehia. O(min(n, n-i))
        //
        // E toru nga keehi nui:
        //  He honohono nga huānga
        //      - keehi motuhake ina ko te hiku 0 He huakore nga huānga ana ko te whakauru kei roto i te waahanga hiku Kaore i te tino aro nga huānga ana kei te wahanga o te upoko te whakauru.
        //
        //
        // Mo ia o era e rua atu nga keehi:
        //  Whakauruhia te mea tata ki te hiku Ko te whakauru ka tata atu ki te mahunga
        //
        // Kī: H, self.head
        //      T, self.tail o, Huinga tika I, Huinga whakauru A, Ko te waahanga i muri i te tohu whakauru M, he tohu kua nekehia te huanga
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [He oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // pātata, whakauruhia kia tata ki te hiku:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // pātata, kōkuhu tata atu ki te hiku me te hiku ko te 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Kua neke ke te hiku, no reira ka kape noa matou i nga waahanga `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // pātata, whakauruhia kia tata atu ki te upoko:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // koretake, whakauruhia kia tata ki te hiku, waahanga hiku:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // koretake, whakauruhia kia tata ki te upoko, waahanga hiku:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kape i nga huanga tae noa ki te upoko hou
                    self.copy(1, 0, self.head);

                    // kape i te waahanga whakamutunga ki te waahi kau i raro o te buffer
                    self.copy(0, self.cap() - 1, 1);

                    // neke nga huanga mai i te idx ki te whakamutu whakamua kaore i te whakauru ^ huanga
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // mokowhiti, whakauruhia he tata atu ki te hiku, waahanga upoko, a kei te kore o te taupū i roto i te paapiri o roto:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kape i nga huanga tae noa ki te hiku hou
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kape i te waahanga whakamutunga ki te waahi kau i raro o te buffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // mokowhiti, whakauruhia kia tata atu ki te hiku, waahanga upoko:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // kape i nga huanga tae noa ki te hiku hou
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kape i te waahanga whakamutunga ki te waahi kau i raro o te buffer
                    self.copy(self.cap() - 1, 0, 1);

                    // neke nga huanga mai i te idx-1 ki te whakamutu kaore ano kia whakaurua te ^ huanga
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // koretake, whakauruhia kia tata ki te upoko, upoko upoko:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // kua whakarerekehia te hiku na me tatau ano e tatou
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Tango ai me hoki te huānga i `index` i te `VecDeque`.
    /// Ahakoa mutunga te ofi ange ki te wāhi tango ka e whakakorikoria ki te hanga ruma, a ka e whakakorikoria nga āhuatanga pāngia katoa ki tūranga hou.
    ///
    /// Whakahoki ai i te `None` mena kaore i te rohe te `index`.
    ///
    /// Ko te timatanga o te tohu 0 te mua o te raarangi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // E toru nga keehi nui:
        //  He taapiri nga mea timatanga He koretake nga waahanga, a, ko te tangohanga kei roto i te hiku o nga hiku. Kaore i te kaha nga tangohanga, kei te upoko te tangohanga
        //
        //      - keehi motuhake ina he tata te hangarau o nga waahanga, engari self.head =0
        //
        // Mo ia o era e rua atu nga keehi:
        //  Whakauruhia te mea tata ki te hiku Ko te whakauru ka tata atu ki te mahunga
        //
        // Kī: H, self.head
        //      T, self.tail o, Huanga huakore x, Huanga kua tohua mo te tango R, Tohu tohu e tangohia ana M, kua tohu te huanga i nekehia
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // pātata, tangohia tata ki te hiku:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // pātata, tangohia tata ki te upoko:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // mokowhiti, neke tata atu ki te hiku, waahanga hiku:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // mokowhiti, neke tata atu ki te upoko, upoko upoko:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // mokowhiti, tangohia tata ki te upoko, waahanga hiku:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // he koretake ranei, tangohia i te taha o te upoko, te waahanga hiku:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // tuhia nga waahanga i te waahanga hiku
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Ka aukati i te heke.
                    if self.head != 0 {
                        // tārua huānga tuatahi ki te waahi kau
                        self.copy(self.cap() - 1, 0, 1);

                        // neke i nga waahanga o te upoko ki muri
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // puhoi, tangohia tata ki te hiku, upoko upoko:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // tuhia nga waahanga ki te idx
                    self.copy(1, 0, idx);

                    // kape i te waahanga whakamutunga ki te waahi kau
                    self.copy(0, self.cap() - 1, 1);

                    // neke nga huanga mai i te hiku ki te pito whakamua, haunga nga mea whakamutunga
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Wehea te `VecDeque` ki te rua i te taupū i hoatu.
    ///
    /// Whakahoki ai i te `VecDeque` hou kua tohaina.
    /// `self` he huanga `[0, at)`, a ko te `VecDeque` i hoki mai he huanga `[at, len)`.
    ///
    /// Kia mahara kaore e rereke te kaha o `self`.
    ///
    /// Ko te timatanga o te tohu 0 te mua o te raarangi.
    ///
    /// # Panics
    ///
    /// Panics mena ko `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` kei te haurua tuatahi.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // tangohia noa te haurua tuarua.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` kei te haurua tuarua, me matua whakauru ki nga waahanga i pekehia e tatou i te haurua tuatahi.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Whakapai kei hea nga pito o nga buffers
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Ka nekehia nga waahanga katoa o te `other` ki te `self`, ka waiho he kore noa te `other`.
    ///
    /// # Panics
    ///
    /// Panics mena ka taupoki te `usize` i te maha o nga waahanga hou.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // impl naive
        self.extend(other.drain(..));
    }

    /// Ka mau ki nga mea timatanga kua tohua e te matapae.
    ///
    /// I etahi atu kupu, tangohia nga mea katoa `e` penei ka hoki mai a `f(&e)` he teka.
    /// Kei te whakahaerehia tenei tikanga i tona waahi, ka toro totika i ia waahanga ki te raupapa taketake, ka tiakina te raupapa o nga mea pupuri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// He pai pea te ota tika mo te whai i te ahua o waho, peera i te taurangi.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Akene ko te panic ka whakakahoretia ranei
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Whawhati te rahi te moka.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Ka whakarereke i te `VecDeque` i te waahi kia rite ai te `len()` ki te `new_len`, ma te tango i nga waahanga nui mai i te tua, ma te taapiri ranei i nga waahanga i hangaia ma te karanga i te `generator` ki muri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Whakarite ai i te penapena o roto o tenei tiikina na koina tetahi waahanga piri, ka whakahokia mai ana.
    ///
    /// Kaore tenei tikanga e tohatoha ana, kaore hoki e whakarereke te raupapa o nga waahanga kua whakauruhia.I te mea e whakahoki mai ana i te waahanga e taea ana te whakarereke, ka taea tenei ki te wehe i te wairangi.
    ///
    /// Ka poka noa te rokiroki o roto, ka whakahokia e nga tikanga [`as_slices`] me [`as_mut_slices`] nga korero katoa o te `VecDeque` i roto i te waahanga kotahi.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Te tohatoha i nga korero o te deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // kōmaka i te deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // whakaraupapahia kia raupapa
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Te uru urunga ki te poro tata.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // ka mohio tatou inaianei kei roto i te `slice` nga waahanga katoa o te deque, i te wa e uru ana ki te `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // he nui noa atu te waatea ki te kape i te hiku i te wa kotahi, ko te tikanga ka neke whakamuri te upoko ki muri, ka kape i te hiku ki te tuunga tika.
            //
            //
            // mai i: DEFGH .... ABC
            // ki: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Kaore maatau e whakaaro .... ABCDEFGH
            // hei taapiri na te mea `head` ka `0` i tenei keehi.
            // Ahakoa e hiahia ana maatau ki te whakarereke i tenei, ehara i te mea iti noa i te mea e kii ana etahi waahi ko te `is_contiguous` te tikanga ka taea te poro i te `buf[tail..head]`.
            //
            //

            // he nui noa atu te waatea hei kape i te mahunga i te wa kotahi, ko te tikanga ka neke whakamua taatau ki te hiku, ka kape i te upoko ki te waahi tika.
            //
            //
            // mai i: FGH .... ABCDE
            // ki: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // he iti ake te koreutu i te upoko me te hiku, ko te tikanga me ata haere te "swap" o te hiku me te upoko.
            //
            //
            // mai i: EFGHI ... ABCD ko HIJK.ABCDEFG ranei
            // ki: ABCDEFGHI ... ranei ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Ko te raru whanui he penei i tenei GHIJKLM ... ABCDEF, i mua i te whakawhiti atu o te ABCDEFM ... GHIJKL, i muri i te paahitanga 1 o nga swaps ABCDEFGHIJM ... KL, whakawhiti kia tae ra ano te taha maui o edge ki te toa toa.
                //                  - ka whakaara ano i te algorithm me te toa (smaller) hou I etahi wa ka tae te toa toa ka tae ana te edge tika ki te pito o te whara, ko te tikanga kua pa ki a tatou te ota tika me te iti ake o nga huri!
                //
                // E.g
                // EF..ABCD ABCDEF .., i muri i nga huringa e wha kua oti noa
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Ka hurihuri i te waahi tuuturu-`mid` waahi ki te taha maui.
    ///
    /// Equivalently,
    /// - Ka hurihia te nama take `mid` ki te tuunga tuatahi.
    /// - Patohia nga taonga `mid` tuatahi ka peehi atu ki te pito.
    /// - Ka hurihia nga waahi `len() - mid` ki te taha matau.
    ///
    /// # Panics
    ///
    /// Mena he nui ake te `mid` i te `len()`.
    /// Kia mahara ko te `mid == len()` he _not_ panic a he hurihanga no-op.
    ///
    /// # Complexity
    ///
    /// Ka pau te waa `*O*(min(mid, len() - mid))` kaore he waahi taapiri.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Ka hurihuri i nga waahanga taarua-`k` waahi ki te taha matau.
    ///
    /// Equivalently,
    /// - Hurihia te mea tuatahi ki te tuunga `k`.
    /// - Patohia nga taonga `k` whakamutunga ka peia ki mua.
    /// - Ka hurihia nga wahi `len() - k` ki te taha maui.
    ///
    /// # Panics
    ///
    /// Mena he nui ake te `k` i te `len()`.
    /// Kia mahara ko te `k == len()` he _not_ panic a he hurihanga no-op.
    ///
    /// # Complexity
    ///
    /// Ka pau te waa `*O*(min(k, len() - k))` kaore he waahi taapiri.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SAFETY: ko nga tikanga e rua e whai ake nei me nui te takahuri
    // kia iti iho i te haurua o te roa o te deque.
    //
    // `wrap_copy` me kii `min(x, cap() - x) + copy_len <= cap()`, engari ko te `min` kaore rawa e neke atu i te haurua o te kaha, ahakoa te x, na reira he tangi ki te karanga i konei na te mea e karanga ana maatau me tetahi mea iti ake i te haurua o te roa, kaore nei e neke ake i te haurua o te kaha.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Ka rapu a Binary i tenei `VecDeque` ka tohaina mo tetahi waahanga.
    ///
    /// Mena kua kitea te uara ka whakahokia mai te [`Result::Ok`], kei roto te taurangi o te waahanga e taurite ana.
    /// Mena he maha nga whakataetae, ka taea te whakahoki mai i tetahi o nga whakataetae.
    /// Mena kaore i kitea te uara katahi ka whakahokia mai te [`Result::Err`], kei roto te taurangi e taea ai te whakauru i tetahi waahanga taapiri kia mau tonu te raupapa.
    ///
    ///
    /// # Examples
    ///
    /// Tirohia te raupapa o nga waahanga e wha.
    /// Ko te tuatahi ka kitea, me te tuunga motuhake kua whakatauhia;te tuarua me te tuatoru e kore e kitea;te tuawha ka taea te whakarite i tetahi tuunga i te `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Mena kei te hiahia koe ki te whakauru i tetahi taonga ki te `VecDeque` kua tohatohahia, me te pupuri i te raupapa raupapa:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Ka rapua e Binary tenei kohinga `VecDeque` me te mahi whakataurite.
    ///
    /// Ma te mahi whakataurite e whakarite he ota kia rite ki te ota whakaraupapa o te `VecDeque` e whaaia ana, me te whakahoki mai i te waehere ota e tohu ana ko te `Less`, `Equal`, ko te `Greater` ranei te tohenga tautohe i te kaupapa e hiahiatia ana.
    ///
    ///
    /// Mena kua kitea te uara ka whakahokia mai te [`Result::Ok`], kei roto te taurangi o te waahanga e taurite ana.Mena he maha nga whakataetae, ka taea te whakahoki mai i tetahi o nga whakataetae.
    /// Mena kaore i kitea te uara katahi ka whakahokia mai te [`Result::Err`], kei roto te taurangi e taea ai te whakauru i tetahi waahanga taapiri kia mau tonu te raupapa.
    ///
    /// # Examples
    ///
    /// Tirohia te raupapa o nga waahanga e wha.Ko te te kitea tuatahi, ki te tūranga ahurei fakapapau'i;te tuarua me te tuatoru e kore e kitea;te tuawha ka taea te whakarite i tetahi tuunga i te `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Ka rapua e te Binary tenei kohinga `VecDeque` me te mahi tangohanga matua.
    ///
    /// Ki te whakaaro ko te `VecDeque` ka tohatohahia e te matua, hei tauira me te [`make_contiguous().sort_by_key()`](#method.make_contiguous) e whakamahi ana i taua mahi tangohanga matua.
    ///
    ///
    /// Mena kua kitea te uara ka whakahokia mai te [`Result::Ok`], kei roto te taurangi o te waahanga e taurite ana.
    /// Mena he maha nga whakataetae, ka taea te whakahoki mai i tetahi o nga whakataetae.
    /// Mena kaore i kitea te uara katahi ka whakahokia mai te [`Result::Err`], kei roto te taurangi e taea ai te whakauru i tetahi waahanga taapiri kia mau tonu te raupapa.
    ///
    /// # Examples
    ///
    /// Tirohia te raupapa o nga waahanga e wha i roto i te waahanga takirua i tohaina e nga waahanga tuarua.
    /// Ko te tuatahi ka kitea, me te tuunga motuhake kua whakatauhia;te tuarua me te tuatoru e kore e kitea;te tuawha ka taea te whakarite i tetahi tuunga i te `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Ka whakarereke i te `VecDeque` i te waahi kia rite ai te `len()` ki te new_len, ma te tango i nga waahanga nui mai i te tua, ma te taapiri ranei i nga tohu o `value` ki muri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Whakahoki ai i te taupū i te kaupapapapapaku whai take mo te taupū huanga arorau kua hoatu.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // te rahi he kaha tonu ki te 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Tatau i te maha o nga huanga e toe ana hei panui i roto i te buffer
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // te rahi he kaha tonu ki te 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Ka wehe tonu i nga waahanga e toru, hei tauira: ko koe: [a b c|d e f] etahi atu: [0 1 2 3|4 5] mua=3, waenga=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Kaore e taea te whakamahi i te Hash::hash_slice i runga i nga poro i whakahokia mai e te tikanga as_slices na te mea ka rerekee te roa i roto i nga momo tikanga.
        //
        //
        // Ko Hasher anake te tohu i te taurite mo te rite tonu o nga waeatanga ki ona tikanga.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Ka pau te `VecDeque` ki roto i te miihini whakamuri o mua ki te hoki e whakaputa ana i nga waahanga o te uara.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Ko tenei mahi kia rite ki nga tikanga mo:
        //
        //      mo te taonga kei iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Hurihia te [`Vec<T>`] ki te [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Ka karo tenei i te whakawhiti ano ki te waa e taea ana, engari he pakari nga tikanga mo tera, ka whakarerekehia, no reira kaua e whakawhirinaki ki te kore te `Vec<T>` i ahu mai i te `From<VecDeque<T>>` kaore ano kia tukuna.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Kaore he tohatoha tuturu mo nga ZST ki te awangawanga mo te kaha, engari kaore e taea e `VecDeque` te whakahaere i te roa rite te `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Me whakarereke te rahi mena kaore te mana e kaha ki te rua, he iti rawa, kaore ranei kia kotahi te waahi waatea.
            // mahi tatou i tenei i te reira tonu i roto i te `Vec` pena ka maturuturu te tūemi ki runga ki panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Hurihia te [`VecDeque<T>`] ki te [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Kaore tenei e tika ana kia tohatoha ano, engari me mahi *O*(*n*) nekehanga raraunga mena kaore te buffer porohita i te timatanga o te tohatoha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Ko tenei tetahi *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Me tenei tetahi raraunga Pätuhia.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}