//! He tirohanga hihiko-rahi ki te raupapa taapiri, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Ko nga poro te tirohanga ki te poraka whakamaumahara hei tohu me te roa.
//!
//! ```
//! // te tapatapahi i te Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // te akiaki i te ngohi ki te poro
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Ka taea te huri, te tohatoha ranei i nga poro.
//! Ko te momo poro poro ko te `&[T]`, ko te momo poro e taea te whakarereke ko te `&mut [T]`, kei reira te tohu `T` i te momo waahanga.
//! Hei tauira, ka taea e koe te whakarereke i te poraka o te mahara e kiia ana e te poro huri ki:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Anei etahi o nga mea o tenei waahanga:
//!
//! ## Structs
//!
//! He maha nga waahanga e whai kiko ana mo nga poro, penei i te [`Iter`], e tohu ana i te taarua i runga i te poro.
//!
//! ## Trait Whakatinana
//!
//! He maha nga whakamahinga o te traits noa mo nga poro.Ētahi tauira ngā:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], mo nga poro ko te momo momo [`Eq`] ko [`Ord`] ranei.
//! * [`Hash`] - mo nga poro ko te momo momo [`Hash`].
//!
//! ## Iteration
//!
//! Ka whakamahia e nga poro te `IntoIterator`.Ka tukuna e te kaitohu te korero ki nga waahanga poro.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Ko te waahanga e taea ana te whakarereke ka whakaputa i nga korero tere ki nga mea timatanga:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Ko tenei kaitautoko e whakaputa ana i nga korero rerekee ki nga waahanga o te poro, no reira ko te momo waahanga o te poro ko te `i32`, ko te momo waahanga o te whiti ko te `&mut i32`.
//!
//!
//! * [`.iter`] ko [`.iter_mut`] Ko nga tikanga mārama ki te hoki mai te iterators taunoa.
//! * Ko etahi atu tikanga hei whakahoki iterator ko [`.split`], [`.splitn`], [`.chunks`], [`.windows`] me te maha atu.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Ko te nuinga o nga whakamahinga o tenei waahanga ka whakamahia noa i te whirihoranga whakamatautau.
// kaihoroi o te reira ki te tika tahuri atu te unused_imports whakatupato atu ki te whakatika ia ratou.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Nga tikanga whakaraoa poro
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) e hiahiatia ana mo te whakamahinga o te `vec!` tonotono i te wa e whakamatautau ana i te NB, tirohia te waahanga `hack` i roto i tenei konae mo etahi atu taipitopito.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) e hiahiatia ana mo te whakamahi i te `Vec::clone` i te wa e whakamatautau NB, tirohia te waahanga `hack` i tenei konae mo etahi atu taipitopito.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Ki te kore e waatea te cfg(test) `impl [T]`, ko enei mahi e toru he tikanga kei roto i te `impl [T]` engari kaore i te `core::slice::SliceExt`, me tuku e tatou enei mahi mo te whakamatautau `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Kaua e taapirihia te huanga whakaroto ki tenei na te mea ka whakamahia tenei i te tonotono `vec!` te nuinga, na te mea ka hoki ano te whakaheke.
    // Tirohia te #71204 mo nga korerorero me nga hua perf.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // i tohua nga taonga ki te koropiko i raro
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) he mea nui ma te LLVM e tango nga haki rohe a he pai ake te codegen i te zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // i whakaritea te věc me arawhitia runga ake ki te iti rawa tenei roa.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // kua tohaina ki runga ake me te kaha o `s`, ka arahi ki te `s.len()` i te ptr::copy_to_non_overlapping i raro.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Ka tohatohahia te poro.
    ///
    /// He pumau tenei tu ahua (ara, kaore e whakariterite i nga waahanga rite) me te *O*(*n*\*log(* n*)) tino-kino.
    ///
    /// Ka pa ana, he pai ake te tohatoha pumau na te mea he tere ake i te tohatoha pumau a kaore e toha i te whakamaharatanga awhina.
    /// Tirohia te [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Te whakatinanatanga o tenei wa
    ///
    /// Ko te algorithm o naianei he whakarereke, he hanumi whakauru takirua i faauruhia e [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// I hoahoatia kia tere tonu i roto i nga keehi e tata ai te wehe te poro, kei roto ranei e rua neke atu ranei nga raupapa whakaraupapa tetahi i muri i tetahi.
    ///
    ///
    /// Ano hoki, ka tohaina he rokiroki rangitahi te haurua o te rahi o te `self`, engari mo nga poro poto ka whakamahia ke te whakauru whakauru-kore.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Ka tohatohahia te poro me te mahi whakataurite.
    ///
    /// He pumau tenei tu ahua (ara, kaore e whakariterite i nga waahanga rite) me te *O*(*n*\*log(* n*)) tino-kino.
    ///
    /// Ko te mahi whakataurite me tautuhi i te ota katoa mo nga waahanga o te poro.Mena kaore i te katoa te ota, kaore i te tohua te ota o nga waahanga.
    /// Ko te ota he ota katoa mena (mo te `a` katoa, `b` me `c`):
    ///
    /// * katoa, me te antisymmetric: he pono rite tetahi o `a < b`, `a == b` `a > b` ranei, me
    /// * whakawhiti, `a < b` me `b < c` e tohu ana i te `a < c`.Te mau roa taua mo e rua `==` me `>`.
    ///
    /// Hei tauira, ahakoa kaore te [`f64`] e whakatinana i te [`Ord`] na te mea `NaN != NaN`, ka taea e taatau te whakamahi i te `partial_cmp` hei mahi wehe ina mohio ana taatau kaore i te `NaN` tetahi poro.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Ka pa ana, he pai ake te tohatoha pumau na te mea he tere ake i te tohatoha pumau a kaore e toha i te whakamaharatanga awhina.
    /// Tirohia te [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Te whakatinanatanga o tenei wa
    ///
    /// Ko te algorithm o naianei he whakarereke, he hanumi whakauru takirua i faauruhia e [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// I hoahoatia kia tere tonu i roto i nga keehi e tata ai te wehe te poro, kei roto ranei e rua neke atu ranei nga raupapa whakaraupapa tetahi i muri i tetahi.
    ///
    /// Ano hoki, ka tohaina he rokiroki rangitahi te haurua o te rahi o te `self`, engari mo nga poro poto ka whakamahia ke te whakauru whakauru-kore.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // whakatikatika whakamuri
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Ka kōmaka te wāhanga ki te mahi matua tangohanga.
    ///
    /// He pumau tenei momo (ara, kaore e whakaraupapa i nga waahanga rite) me te *O*(*m*\* * n *\* log(*n*)) tino kino rawa atu, ko te mahi matua ko te *O*(*m*).
    ///
    /// Mo nga mahi matua utu nui (hei tauira
    /// nga taumahi ehara i te urunga atu ki nga kaainga ngawari, ki nga mahi taketake ranei), [`sort_by_cached_key`](slice::sort_by_cached_key) tera pea ka tere ake, na te mea kaore e kii ana i nga ki o te timatanga.
    ///
    ///
    /// Ka pa ana, he pai ake te tohatoha pumau na te mea he tere ake i te tohatoha pumau a kaore e toha i te whakamaharatanga awhina.
    /// Tirohia te [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Te whakatinanatanga o tenei wa
    ///
    /// Ko te algorithm o naianei he whakarereke, he hanumi whakauru takirua i faauruhia e [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// I hoahoatia kia tere tonu i roto i nga keehi e tata ai te wehe te poro, kei roto ranei e rua neke atu ranei nga raupapa whakaraupapa tetahi i muri i tetahi.
    ///
    /// Ano hoki, ka tohaina he rokiroki rangitahi te haurua o te rahi o te `self`, engari mo nga poro poto ka whakamahia ke te whakauru whakauru-kore.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ka kōmaka te wāhanga ki te mahi matua tangohanga.
    ///
    /// I te wa e tohatoha ana, ko te mahi matua ka kiia kotahi anake mo ia waahanga.
    ///
    /// He pumau tenei tu ahua (ara, kaore e whakariterite i nga waahanga rite) me te *O*(*m*\* * n *+* n *\* log(*n*)) tino kino, kei reira te mahi matua *O*(*m*) .
    ///
    /// Mo nga mahi matua ngawari (hei tauira, ko nga mahi hei urunga rawa, he mahi noa ranei), ka tere ake te tere o te [`sort_by_key`](slice::sort_by_key).
    ///
    /// # Te whakatinanatanga o tenei wa
    ///
    /// Ko te algorithm o naianei e hangai ana ki te [pattern-defeating quicksort][pdqsort] na Orson Peters, e hono ana i te keehi toharite tere o te tere tere me te keehi tino kino rawa o te puranga, i te wa e tutuki ana te waa ki nga poro me etahi tauira.
    /// Ka whakamahia te matapōkere kia kore ai e heke nga keehi, engari me te seed kua whakaritea kia mau tonu te whanonga whakatau.
    ///
    /// I te keehi kino, ka tohaina e te algorithm te rokiroki poto i roto i te `Vec<(K, usize)>` te roa o te poro.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Helper tonotono mō te fakahokohoko to tatou vector i te momo taea iti rawa, ki te whakaiti i te tohanga.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // He ahurei nga waahanga o te `indices`, na te mea kua tohua, no reira ka pumau tetahi ahua mo te poro taketake.
                // Ka whakamahia e matou te `sort_unstable` i konei na te mea me iti ake te tohatoha mahara.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Ka kape i te `self` ki roto i te `Vec` hou.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // I konei, `s` me `x` ka taea te whakarereke takitahi.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Ka kape i te `self` ki roto i te `Vec` hou me te kaitoha.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // I konei, `s` me `x` ka taea te whakarereke takitahi.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, tirohia te waahanga `hack` kei roto i tenei konae mo etahi atu taipitopito.
        hack::to_vec(self, alloc)
    }

    /// Ka hurihia te `self` ki roto i te vector kaore he taatai, tohatoha ranei.
    ///
    /// Ko te hua o te vector ka taea te whakahoki ki tetahi pouaka ma te 'Vec<T>`into_boxed_slice` tikanga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` kaore e taea te whakamahi inaianei na te mea kua huri hei `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, tirohia te waahanga `hack` kei roto i tenei konae mo etahi atu taipitopito.
        hack::into_vec(self)
    }

    /// Ka waihangahia he vector ma te tukurua i te waahanga `n` waa.
    ///
    /// # Panics
    ///
    /// Ka panic tenei mahi mena ka kaha rawa atu te kaha.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// He panic ki runga ki te waipuke:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Mena he nui ake te `n` i te kore, ka taea te wehe hei `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` ko te nama e tohua ana e te taha maui '1' o `n`, a ko te `rem` te toenga o te `n`.
        //
        //

        // Ma te `Vec` kia uru ki te `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` tukurua ai ma te taarua `buf` expn`-wā.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Mena `m > 0`, ka toe etahi toenga ki te taha maui '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` he kaha te `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) ka mahia te tukurua ma te kape i nga tukurua `rem` tuatahi mai i te `buf` ano.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Kaore tenei i te taarua mai i te `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` he rite ki te `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Whakahauhia ai te poro o `T` ki te uara kotahi `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Whakahauhia ai te poro o `T` ki roto i te uara `Self::Output` kotahi, ka waiho he wehenga i waenga i ia waahanga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Whakahauhia ai te poro o `T` ki roto i te uara `Self::Output` kotahi, ka waiho he wehenga i waenga i ia waahanga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Whakahoki ai i te vector e mau ana he kape o tenei waahanga ki te mapi o ia paita ki te ASCII o runga keehi.
    ///
    ///
    /// Ko nga reta ASCII 'a' ki 'z' ka maherehia ki te 'A' ki te 'Z', engari ko nga reta kore ASCII kaore i whakarereke.
    ///
    /// Hei whakarahi ake i te uara ki te waahi, whakamahia te [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Whakahokia ai he vector e mau ana i te kape o tenei waahanga ki te mapi o ia paita ki te ASCII o te keehi o raro.
    ///
    ///
    /// Ko nga reta ASCII 'A' ki 'Z' ka maherehia ki te 'a' ki te 'z', engari ko nga reta kore ASCII kaore i whakarereke.
    ///
    /// Hei whakaiti i te uara ki te waahi, whakamahia te [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Toronga traits mo nga poro mo etahi momo tuhinga motuhake
////////////////////////////////////////////////////////////////////////////////

/// Kaiawhina trait mo [`[T]: : concat`](poro::concat)
///
/// Note: ko te momo momo `Item` kaore i te whakamahia i roto i tenei trait, engari ka ahei kia nui ake te awhina o nga apiri.
/// Ki te kore, ka hapa taatau:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Ko tenei na te mea ka puta pea nga momo `V` me te maha o nga tono `Borrow<[_]>`, penei ka uru nga momo `T` maha:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Ko te momo hua i muri o te whakakotahi
    type Output;

    /// Te whakamahi i te [`[T]: : concat`](poro::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Kaiawhina trait mo [`[T]: : uru`](poro::uru atu)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Ko te momo hua i muri o te whakakotahi
    type Output;

    /// Te whakatinana i te [`[T]: : whakauru`](poro::uru atu)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Nga whakaritenga trait Paerewa mo nga poro
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // whakatakahia tetahi mea ki te whaainga kaore e tuhia
        target.truncate(self.len());

        // target.len <= self.len na te tumuaki o runga ake, na ko nga poro i konei he-rohe tonu.
        //
        let (init, tail) = self.split_at(target.len());

        // whakamahi ano i nga uara kei roto allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Ka whakauruhia te `v[0]` ki roto i te raupapa `v[1..]` i tohua i mua kia ata wehea te `v[..]` katoa.
///
/// Koinei te subroutine whakauru o te momo whakauru.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // E toru nga huarahi hei whakamahi i te whakauru ki konei:
            //
            // 1. Whakawhitihia nga waahanga e tata ana kia tae atu ra ano te mea tuatahi ki tona mutunga.
            //    Heoi, ma tenei ka kape taatau i nga korero neke atu i te mea e tika ana.
            //    Ki te he hanganga nui (utu ki te kape) āhuatanga, ka waiho tenei tikanga puhoi.
            //
            // 2. Whakahauhia kia kitea ra ano te waahi tika mo te waahanga tuatahi.
            // Na ka nuku i te mea timatanga angitu ki reira kia ruma mo taua mea, me te pae hopea tuu i te reira ki te toe poka.
            // Ko te tikanga pai tenei.
            //
            // 3. Tuhia te waahanga tuatahi ki te taurangi rangitahi.Whakahauhia kia kitea ra ano te waahi tika.
            // I a maatau e haere ana, kape i nga waahanga katoa i haerehia ki roto i te waahi i mua i a ia.
            // Hei whakamutunga, kape i nga raraunga mai i te taurangi rangirua ki te rua toenga.
            // He tino pai tenei tikanga.
            // Ko nga Paearu i whakaatu he pai ake te mahi i ta te tikanga tuarua.
            //
            // Ko nga tikanga katoa he tohu, a ko te 3 i whakaatu i nga hua pai.Na ka whiriwhiria e matou i taua tetahi.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Ko te ahua takawaenga o te tukanga whakauru ka tirohia e `hole`, e rua nga kaupapa e whakamahia ana:
            // 1. Ka tiakina te tapatahi o te `v` mai i te panics i te `is_less`.
            // 2. Whakakihia te kohinga e toe ana ki te `v` i te mutunga.
            //
            // Panic ahuru:
            //
            // Ki te `is_less` panics i tetahi wāhi i roto i te tukanga, `hole` ka kia maturuturu iho, ka kapi hoki i te kohao i roto i `v` ki `tmp`, ko te kupu whakarite e mau tonu `v` katoa ahanoa reira tuatahi puritia rite kotahi.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` ka makaka ka kape `tmp` ki te koha e toe ana i te `v`.
        }
    }

    // A, no te maturuturu iho, kape i `src` ki `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Ko te whakahiato kore-whakaheke e whakahaere i te `v[..mid]` me te `v[mid..]` ma te whakamahi i te `buf` hei rokiroki poto, ka penapena i te hua ki te `v[..]`.
///
/// # Safety
///
/// Ko nga poro e rua me noho kore-kore ana me `mid` me herea.
/// Me kia nui roa ki te pupuri i te kape o te wāhanga poto Buffer `buf`.
/// Ano hoki, ko te `T` kaua e waiho hei momo kore-rahi.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Ko te mahinga hanumi ka kape i te tuatahi ka poto te oma ki te `buf`.
    // Na ka tirotirohia te waahanga hou i taahuahia me te roa o mua ki mua (ki muri ranei), te whakataurite i o raatau waahanga kaore e whai mana ana me te kape i te mea iti (nui ake ranei) ki te `v`.
    //
    // Ka mutu ana te mahinga poto, ka oti te mahi.Mena ka pau te wa roa i te tuatahi, me kape e taatau nga toenga o te waa poto ka rere ki te rua e toe ana i te `v`.
    //
    // Ko te ahua waenga o te mahinga e whai ana i te `hole`, e rua nei nga kaupapa:
    // 1. Ka tiakina te tapatahi o te `v` mai i te panics i te `is_less`.
    // 2. Whakakihia te koha e toe ana ki te `v` mena ka pau te tuatahi i te waa roa.
    //
    // Panic ahuru:
    //
    // Mena te `is_less` panics i nga waahanga katoa o te waahanga, ka heke te `hole` ka whakakiihia te kohao ki te `v` me te awhe kaore i whakaarohia i te `buf`, na te whakarite kei te pupuri tonu a `v` i nga taonga katoa i te timatanga kotahi te wa.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Ko te oma maui he poto ake.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // I te tuatahi, ko enei tohu tohu ki nga timatanga o a raatau raarangi.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Pau te taha iti.
            // Mena he orite, hiahia ki te oma maui kia mau tonu te pumau.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // He poto ake te oma tika.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // I te timatanga, ko enei tohu tohu ka tohu ki tua o nga pito o a raatau raarangi.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Whakamotitia te taha nui.
            // Mena he rite, hiahia ki te oma tika kia mau tonu te pumau.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Hei whakamutunga, ka taka te `hole`.
    // Mena kaore i tino pau te rere o te waa, ko nga toenga o taua mea ka kape ki roto ki te poka `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Ka whakatakahia, kapehia te awhe `start..end` ki te `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ehara i te momo kore-rahi, no reira he pai ki te wehe i te rahi.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Ko tenei momo hanumi ka tono i etahi (engari kaore i te katoa) nga whakaaro mai i TimSort, e whakaahuatia ana i te taipitopito [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Ka tautuhia e te algorithm nga heke e heke iho ana me nga heke-kore e kiia nei ko nga oma maori.He puranga kei te tatari mo nga rerenga kaore ano kia honoa.
/// Ko ia rerenga hou i kitea ka panahia ki runga i te puranga, ana ka honoa etahi o nga oma e tata ana kia ea ra ano nga kaitono e rua:
///
/// 1. mo nga `i` katoa i te `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. mo nga `i` katoa i te `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Ma te hunga whakahoahoa e whakarite ko te wa roa e rere ana ko te *O*(*n*\*log(* n*)) tino kino rawa atu.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ko nga waahanga tae atu ki tenei waa ka whakariterite ma te whakauru momo whakauru.
    const MAX_INSERTION: usize = 20;
    // E whakawhānuitia rere Tino poto te whakamahi i ahua whakaurunga ki te whanganga i te iti rawa i tenei maha āhuatanga.
    const MIN_RUN: usize = 10;

    // Kaore he tikanga whai kiko o te tatai mo nga momo kore-rahi.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Ko nga raarangi poto ka wehe i te waahi ma te whakauru whakauru ki te karo i nga tohatoha.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Tohaina he paapepa hei whakamahara hei whakamahara.Ka mau ki a maatau te roanga 0 kia taea ai e taatau te pupuri i nga kape iti o nga korero o `v` me te kore e raru i nga taakuta e rere ana i nga kape mena `is_less` panics.
    //
    // Ka honohono ana kia rua nga momo whakariterite, kei tenei kaipupuri he kape o te oma poto, ka roa tonu te roa i te nuinga o te `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // I roto i te tikanga ki te tāutu i rere tūturu i roto i `v`, tutei tatou whakamuri reira.
    // Akene he whakatau ke ke tena, engari whakaarohia me hono tonu te hanumi ki te ara tua atu (forwards).
    // E ai ki nga tohu, ko te honohono whakamua he tere ake i te honohono whakamuri.
    // Hei mutunga, ko te tautuhi i nga oma ma te huringa whakamuri ka whakapai ake i te mahinga.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Rapua te rerenga taiao e whai ake nei, ka hurihia mena e tino heke ana.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Whakauruhia etahi atu waahanga ki te oma mena he poto rawa.
        // Ko te whakauru whakauru he tere atu i te hanumi i runga i nga waahanga poto, na tenei ka tino pai ake te mahi.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Panahia tenei rere ki runga i te puranga.
        runs.push(Run { start, len: end - start });
        end = start;

        // Whakauruhia etahi takirua o nga rerenga tata ki te makona i te hunga whakauru.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Hei whakamutunga, kia kotahi te oma me noho ki te puranga.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Ka tirotirohia te puranga rere ka tautuhi i nga rerenga rere e rua ka honohono.
    // Ko te mea nui ake, mena ka whakahokia mai te `Some(r)`, ko te tikanga ko te `runs[r]` me te `runs[r + 1]` me whakakotahi i muri.
    // Ki te kia hanga i tētahi oma hou hei utu tonu i te hātepe, kua hoki mai `None`.
    //
    // He mea kino a TimSort mo ona whakamahinga waka, pera i te korero i konei:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Ko te matü o te kōrero, ko te: me tatou te uruhi i te invariants i runga i te rere wha runga i runga i te tāpae.
    // Ko te whakamana i a raatau ki runga ake i te toru noa iho kaore e ranea ki te whakarite kia mau tonu nga kaitono mo te *katoa* ki te puranga.
    //
    // Ma tenei mahi e tirotiro tika nga kaitautoko mo nga mahinga e wha o runga.
    // Hei taapiri, mena ka tiimata te oma o runga ki te tohu 0, ka tono tonu kia whakakotahihia kia pakaru ra ano te puranga, kia oti ai te momo.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}