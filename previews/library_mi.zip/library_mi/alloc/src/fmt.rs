//! Nga taputapu hei whakahōpututanga me te tā i te `String`s.
//!
//! Kei roto i tenei waahanga te tautoko mo te wa roa mo te toronga taarua [`format!`].
//! whakatinana ana tēnei tonotono e i roto i te e taupatupatu ki te emit waea ki tenei kōwae i roto i te tikanga ki te tohenga hōputu i te wā ki aho.
//!
//! # Usage
//!
//! Ko te tonotono [`format!`] he tikanga kia waia ki te hunga e ahu mai ana i nga mahi a X's `printf`/`fprintf`, i te mahi ranei a Python's `str.format`.
//!
//! Ko etahi tauira o te toronga [`format!`] ko:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" me nga arahi kore
//! ```
//!
//! Mai i enei, ka kite koe ko te tohenga tuatahi he aho whakatakotoranga.E hiahiatia ana e te kaitautoko kia tino whai kiko tenei;kaore e taea te rereke i tukuna (kia pai ai te tirotiro)
//! Ma te kaitoha e wehe te aho whakatakotoranga ka whakatau mena he pai te raarangi o nga tohenga kua tohaina ki tenei aho whakatakotoranga.
//!
//! Hei huri i tetahi uara ki te aho, whakamahia te tikanga [`to_string`].Ka whakamahia tenei i te whakahoutanga [`Display`] trait.
//!
//! ## Tawhā tuunga
//!
//! Ko ia tohenga tautohe e ahei ana ki te tohu ko wai te tohenga uara e tohutohuhia ana, mena ka tangohia ka kiia ko "the next argument".
//! Hei tauira, ko te aho whakatakotoranga `{} {} {}` e toru nga taapiri, a ka rite te mahinga ki a raatau.
//! Ko te aho whakatakotoranga `{2} {1} {0}`, engari, ka whakahua i nga tohenga ki te raupapa whakamuri.
//!
//! Ka taea e mea tiki i te iti uaua tīmata kotahi koutou hononga i te momo e rua o specifiers tū.Ko te kaitautoko "next argument" ka taea te whakaaro he kaikorero mo te tohenga.
//! Ia wa ka kitea he tohu "next argument", ka neke whakamua te whiti.Ko tenei ka arahi ki nga whanonga penei:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Ko te kaitautoko o roto mo te tohenga kaore ano kia piki haere i te wa ka kitea te `{}` tuatahi, na reira ka taia te tohe tuatahi.Na i runga i te taenga tuarua te `{}`, he whakamua arā atu anō ki te rua te tautohe te iterator.
//! Hono mo'oní, e kore e tawhā e āta whakaingoatia ratou tautohe pā ngā tawhā kore e e whakaingoa i te tautohe i roto i ngā o specifiers tū.
//!
//! Ko te aho whakatakotoranga e hiahiatia ana hei whakamahi i ona tautohe katoa, mena he hapa-taima hapa.kia koe kōrero ki te tautohe taua neke atu i te kotahi i roto i te aho hōputu.
//!
//! ## Nga tawhā kua tapaina
//!
//! Kaore a Rust ano i te Python-rite ki nga taapiri kua whakahuatia ki tetahi mahi, engari ko te tonotono [`format!`] he whakaraurite whakawhitinga e taea ai te whakamahi i nga waahanga kua tapaina.
//! whakarārangitia tawhā ingoa e i te mutunga o te rārangi tautohe me te whai i te wetereo:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Hei tauira, ko nga korero [`format!`] e whai ake nei ka whakamahi i te tautohetohe katoa:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Kaore i te tika te whakatakoto i nga waahanga tuunga (ko nga mea kaore he ingoa) i muri i nga tohenga whai ingoa.Ka rite ki nga taatai tuunga, kaore e tika te whakarato i nga taapiri ingoa kaore e whakamahia e te aho whakatakotoranga.
//!
//! # Whakatau Whakatau
//!
//! Ko ia tohenga tautohe e taea ana te whakarereke ma te maha o nga waahanga whakatakotoranga (e pa ana ki te `format_spec` i te [the syntax](#syntax)). Ko enei waahanga e pa ana ki nga tohu aho o nga mea e whakahoutia ana.
//!
//! ## Width
//!
//! ```
//! // Katoa o enei tuhinga "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! He tohu tenei mo te "minimum width" me kii te whakatakotoranga.
//! Mena kaore te aho uara e whakakii i enei kiripuaki maha, katahi ka whakamahia te papa e kiia ana e fill/alignment hei tango i nga waahi e hiahiatia ana (tirohia i raro nei).
//!
//! Ko te uara mo te whanui ka taea te hoatu hei [`usize`] i te raarangi o nga taapiri ma te taapiri i te paerewa `$`, e tohu ana ko te tautohe tuarua ko te [`usize`] e whakaatu ana i te whanui.
//!
//! Ko te korero ki tetahi tautohetohe me te taarua taara e kore e raru ki te kaute "next argument", no reira he pai tonu te korero ki nga tohenga, me te whakamahi tohenga tautohe.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Ko te taera whakakii kapi me te taatai ka whakawhiwhia ki nga waahanga [`width`](#width).Me matua tautuhia i mua o te `width`, i muri tonu o te `:`.
//! He tohu tenei mena ka iti ake i te `width` te uara o te whakahoutanga ka taarua etahi atu taapiri huri noa.
//! Ko te whakakii kei roto i nga momo e whai ake nei mo nga rereketanga rereke:
//!
//! * `[fill]<` - ko te tohenga kei te taha maui-whakatika ki nga pou `width`
//! * `[fill]^` - ko te tohenga kei waenga-waenganui i nga pou `width`
//! * `[fill]>` - he tika te tautohe ki nga pou `width`
//!
//! Ko te [fill/alignment](#fillalignment) taunoa mo nga tau-kore he waahi me te taha maui.Ko te kore taunoa mo nga taatai tau he tohu waahi ano hoki engari he taurite ki te taha-matau.
//! Mena kua tohua te haki `0` (tirohia i raro iho nei) mo te nama, ko te ahua whakakii kiki ko te `0`.
//!
//! Kia mahara kaore e taea e etahi momo te whakatinana te whakaorite.Ina koa, kaore i te whakamahia mo te `Debug` trait.
//! Ko te huarahi pai ki te whakarite kia whakamahia te papa ki te whakahou i to urunga, katahi ka herea tenei aho kia puta ai to putanga:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Kia ora Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Ko enei katoa he haki e whakarereke ana i te whanonga o te kaitahuri.
//!
//! * `+` - He tikanga tenei mo nga momo nama me te tohu me taia tonu te tohu.Ko nga tohu pai kaore i te taarua, a ko nga tohu kino ka taarua noa i te `Signed` trait.
//! Tenei kara tohu e tonu kia tāngia te tohu tika (`+` `-` ranei).
//! * `-` - I tenei wa kaore i te whakamahia
//! * `#` - E tohu ana tenei haki me whakamahi te "alternate" momo taarua.Ko nga puka rereke:
//!     * `#?` - tino taarua te whakatakotoranga [`Debug`]
//!     * `#x` - mua te tautohe ki te `0x`
//!     * `#X` - mua te tautohe ki te `0x`
//!     * `#b` - i mua i te tautohe me te `0b`
//!     * `#o` - mua te tautohe ki te `0o`
//! * `0` - Ka whakamahia tenei hei tohu mo nga taurangi integer me mahi te papa ki te `width` me te tohu `0` me te tohu-mohio hoki.
//! Ko te whakatakotoranga penei i te `{:08}` ka puta te `00000001` mo te `1` integer, i te mea ano he `-0000001` mo te `-1` integer.
//! Kia mahara ko te putanga kino he iti ake te kore i te putanga pai.
//!         Kia mahara ko nga zeros padding i nga wa katoa ka whakanohoia i muri o te tohu (mena he) me mua o nga mati.Ka whakamahia ana me te haki `#`, he ture pera ano: ka whakauruhia nga zeros padding i muri o te kuhimua engari i mua i nga nama.
//!         Ko te kuhimua kei roto i te whanui whanui.
//!
//! ## Precision
//!
//! Mo nga momo kore-tau, ka kiia tenei he "maximum width".
//! Mena he roa ake te aho i puta mai i tenei whanui, katahi ka whakaitihia ki raro ki te maha o nga kiripuaki ana ka tukuna te uara kua tutakina ki te `fill`, `alignment` me te `width` tika mena ka tautuhia aua taapara.
//!
//! Mo nga momo tuuturu, kaore tenei e aro.
//!
//! Mo nga momo tohu-tere, he tohu tenei e hia nga mati i muri o te ira ira ka taarua.
//!
//! E toru nga huarahi ka taea te whakarite i te `precision` e hiahiatia ana:
//!
//! 1. He tauwehenga `.N`:
//!
//!    ko te integer `N` ano ko te tino tika.
//!
//! 2. He tau tōpū, he ingoa rānei e whai ana i te tohu taara `.N$`:
//!
//!    whakamahia te whakatakotoranga *tohenga*`N` (ko te tikanga ko te `usize`) te mea tika.
//!
//! 3. He tohu whetu `.*`:
//!
//!    `.*` te tikanga ko tenei `{...}` e hono ana ki nga whakauru takotoranga *rua* nui atu i te kotahi: ko te whakauru tuatahi kei te pupuri i te tika `usize`, a ko te tuarua kei te pupuri i te uara ki te ta.
//!    Kia mahara ki tenei, mena ka whakamahi tetahi i te aho whakatakotoranga `{<arg>:<spec>.*}`, na ko te waahanga `<arg>` e pa ana ki te* uara * ki te taarua, me te `precision` me uru mai ki roto i te tomokanga o mua o te `<arg>`.
//!
//! Hei tauira, ko nga mea e whai ake nei ka kii i nga mea katoa ka taarua i te mea ano `Hello x is 0.01000`:
//!
//! ```
//! // Kia ora {arg 0 ("x")} he {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Kia ora {arg 1 ("x")} he {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Kia ora {arg 0 ("x")} he {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Kia ora {next arg ("x")} he {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Kia ora {next arg ("x")} he {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Kia ora {next arg ("x")} he {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Ahakoa enei:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! taia nga mea tino rereke e toru:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! I etahi o nga reo papatono, ko te whanonga o nga mahi whakariterite aho e pa ana ki te waahi rohe o te punaha whakahaere.
//! Ko nga mahinga whakatakotoranga i hoatuhia e te wharepukapuka paerewa a Rust kaore he kaupapa o te takiwa, ka rite nga hua ki nga punaha katoa ahakoa te whirihoranga kaiwhakamahi.
//!
//! Hei tauira, ko te waehere e whai ake nei ka taarua tonu te `1.5` ahakoa ka whakamahia e te takiwa o te punaha he wehe wehe ira ke atu i te ira.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Ko nga kiripuaki tuuturu `{` me `}` ka uru pea ki roto i te aho na mua atu i a raatau me nga taera kotahi.Hei tauira, ko te tohu `{` kua mawhiti me te `{{` ka mawhiti te `}` me `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Hei whakarāpopoto, ka kitea e koe i konei te whakamaoritanga o te aho whakatakotoranga.
//! unu i te wetereo mo te reo hōputu whakamahia te i ētahi atu reo, na e kore e waiho te reira manene rawa.Ko nga tohenga kua whakahōpututia me te wetereo Python-rite, te tikanga ko nga tohenga e karapotia ana e `{}` hei utu mo te C-rite `%`.
//! Ko te wetereo pono mo te wetereo whakahōpututanga ko:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! I roto i te wetereo i runga ake nei, kaore pea i te `text` etahi `'{'`, `'}'` ranei.
//!
//! # Whakahōpututanga traits
//!
//! Ka tono koe kia whakaatuhia he tohenga me tetahi momo momo, kei te tono koe kia whakaatuhia he tautohe ki tetahi trait.
//! Ma tenei ka taea te whakahou i nga momo tuuturu ma te `{:x}` (penei i te [`i8`] me te [`isize`]).Ko te mahere o nga momo ki traits ko:
//!
//! * *Kahore* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] me nga tau-iti hexadecimal integers
//! * `X?` ⇒ [`Debug`] me nga tau-maha hexadecimal integers
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Ko te tikanga o tenei ko nga momo tohenga katoa e whakamahi ana i te [`fmt::Binary`][`Binary`] trait ka taea te whakahou me te `{:b}`.E whakaratohia implementations mo enei traits mo te maha o ngā momo i tahito ra i te whare pukapuka paerewa rite te pai.
//!
//! Mena kaore i te whakaatuhia he whakatakotoranga (penei i te `{}` ko te `{:6}` ranei), ko te whakatakotoranga trait e whakamahia ana ko te [`Display`] trait.
//!
//! I a koe e whakamahi ana i te whakatakotoranga trait mo to momo ake, me whakamahi e koe he tikanga mo te waitohu:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // to maatau momo ritenga
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Ka paahihia to momo hei `self` tohutoro-iti, katahi ka tuku te mahi i te putanga ki te awa `f.buf`.Kei i a ia ki te whakatakotoranga trait te whakatinana kia tika te piri ki nga tohu whakatakotoranga e tonoa ana.
//! Ko nga uara o enei waahanga ka tuhia ki nga waahi o te [`Formatter`] hanganga.Hei awhina i a koe, ko te [`Formatter`] hanganga kei te whakarato etahi tikanga awhina.
//!
//! Hei taapiri, ko te uara whakahoki mo tenei mahi ko te [`fmt::Result`] he momo ingoa o [`Hua`]`<(),`[`std: : fmt::Hapa`] `> '.
//! Ko te whakatakotoranga o nga whakatinanatanga me whakarite kia horapa ratau mai i te [`Formatter`] (hei tauira, ka waea ana ki te [`write!`]).
//! Heoi, kaua rawa e whakahoki pohehe nga hapa.
//! Arā, ko te whakatinana i te whakatakotoranga me whakatau pea he he mena ka hoki mai te [`Formatter`] kua hipa.
//! No te mea, he rereke ki ta te waitohu mahi e kii mai ana, ko te whakatakotoranga aho he mahi pohehe.
//! Ko tenei mahi ka whakahoki noa i tetahi hua na te mea ka raru pea te tuhi ki te rerenga waiaro ana me whai huarahi ki te toha i te meka i hapa tetahi i te puranga.
//!
//! Ko tetahi tauira o te whakamahi i te whakatakotoranga traits he penei:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Ko te uara `f` ka whakamahi i te `Write` trait, he aha te tuhi!kei te tatari te tonotono.
//!         // Kia mahara ko tenei whakatakotoranga kaore e aro ki nga momo haki e whakawhiwhia ana ki nga aho whakatakotoranga.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Ma te traits rereke e whakaae nga momo putanga rereke.
//! // Ko te tikanga o tenei whakatakotoranga ko te taarua i te rahi o te vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Whakaute i nga haki whakatakotoranga ma te whakamahi i te tikanga kaiawhina `pad_integral` i runga i te mea Huringa.
//!         // Tirohia nga tuhinga tikanga mo nga taipitopito, a ka taea te whakamahi i te mahi `pad` ki nga aho aho.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Ko enei whakahoutanga e rua traits he motuhake nga kaupapa:
//!
//! - [`fmt::Display`][`Display`] ko nga whakatinana e kii ana ka taea te tohu pono mo te aho UTF-8 i nga wa katoa.Kaore ** i te tumanakohia kia whakatinanahia e nga momo katoa te [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] me whakatinana kia whakatinana mo **katoa** nga momo taangata.
//!   Ko te putanga ka tohu i te ahua o-roto kia pono ka taea.
//!   Ko te kaupapa o te [`Debug`] trait ko te whakahaere i te whakakore i te waehere Rust.I te nuinga o nga keehi, ko te whakamahi i te `#[derive(Debug)]` he ranea me te taunaki.
//!
//! Ētahi tauira o te putanga i traits rua:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # tonotono e pā ana
//!
//! He maha nga tonotono hono i te whanau [`format!`].Ko nga mea e whakatinanahia ana i tenei wa ko:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Ko tenei me [`writeln!`] e rua nga tonotono e whakamahia ana hei whakaputa i te aho whakatakotoranga ki tetahi awa kua tau.Ka whakamahia tenei hei aukati i nga tohatoha waenga o te aho whakatakotoranga me te tuhi tika i te putanga.
//! I raro i te potae, ko tenei mahi kei te kii tonu i te mahi [`write_fmt`] kua tautuhia ki te [`std::io::Write`] trait.
//! Hei tauira whakamahi:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Ko tenei me [`println!`] e whakaputa ana i ta raatau putanga ki stdout.Waihoki ki te tonotono [`write!`], ko te whainga o enei tonotono ko te karo i nga tohatoha waenga i te wa e whakaputa ana i te putanga.Hei tauira whakamahi:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Ko nga tonotono [`eprint!`] ko [`eprintln!`] ōrite ki [`print!`] ko [`println!`], aua, ki te kahore ratou emit ratou putanga ki stderr.
//!
//! ### `format_args!`
//!
//! He tonotono pākiki tenei hei whakamahi i tetahi taonga kuri e whakaahua ana i te aho whakatakotoranga.Kaore tenei mea e hiahiatia he tohatoha puranga hei hanga, engari he korero korero noa kei runga i te puranga.
//! I raro i te taupoki, ka whakamahia katoahia nga tohutao whai paanga mo tenei.
//! Tuatahi, ko etahi tauira whakamahinga ko:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Ko te hua o te tonotono [`format_args!`] he uara o te momo [`fmt::Arguments`].
//! Ko tenei hanganga ka taea te tuku ki nga mahi [`write`] me [`format`] kei roto i tenei waahanga kia taea ai te tukatuka i te aho whakatakotoranga.
//! Ko te whaainga o tenei tonotono kia ara ake te aukati i nga tohatoha waenga i te wa e pa ana ki nga aho whakahono.
//!
//! Hei tauira, ka taea e te wharepukapuka takiuru te whakamahi i te wetewete whakahono paerewa, engari ka huri huri noa i tenei hanganga tae noa ki te wa e whakatauhia ana me ahu te putanga ki hea.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Ko te mahi `format` ka mau ki te [`Arguments`] hanganga ka hoki mai i te aho whakahōpututia.
///
///
/// Ko te tauira [`Arguments`] ka taea te hanga ma te tonotono [`format_args!`].
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Kia mahara ma te whakamahi i te [`format!`] he pai ake pea.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}