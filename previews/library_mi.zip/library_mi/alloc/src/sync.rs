#![stable(feature = "rust1", since = "1.0.0")]

//! atatohu tohutoro-tatau miro-haumaru.
//!
//! Tirohia te tuhinga [`Arc<T>`][Arc] mo etahi atu taipitopito.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// He rohe ngohengohe mo te nui o nga tohutoro ka tukuna pea ki te `Arc`.
///
/// Ko te haere i runga ake i tenei rohe ka whakakorehia to papatono (ahakoa kaore e tika) i nga tohutoro _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// Kaore te ThreadSanitizer e tautoko i nga taiapa mahara.
// Hei karo i nga ripoata pai teka i te Arc/ngoikore te whakamahi ma te whakamahi i nga kawenga ngota hei whakakotahitanga.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// He atatohu tohutoro-tatau miro-haumaru.tu 'Arc' mō 'Atomically Reference kiia'.
///
/// Ko te momo `Arc<T>` e whakarato ana i te rangatira ake o te uara o te momo `T`, kua tohaina ki te puranga.Ko te tono [`clone`][clone] kei runga i te `Arc` e whakaputa ana i tetahi tauira `Arc` hou, e tohu ana ki te tohatoha ano i runga i te puranga me te putake `Arc`, me te whakanui ake i te tatauranga tohutoro.
/// Ka ngaro te tohu `Arc` whakamutunga ki tetahi tohatoha, ka heke iho te uara e penapena ana i taua waahanga (e kiia ana ko "inner value").
///
/// Ko nga tohutoro kua tohaina i te Rust ka aukati i te rereketanga ma te taunoa, a ko te `Arc` kaore i tua atu: kaore e taea e koe te tiki korero mo tetahi mea o roto i te `Arc`.Mena me mutate koe i roto i te `Arc`, whakamahia te [`Mutex`][mutex], [`RwLock`][rwlock], tetahi ranei o nga momo [`Atomic`][atomic].
///
/// ## Haumaru Miro
///
/// Rerekē [`Rc<T>`], whakamahi `Arc<T>` ngā mahi ngota mo tona tatau tohutoro.Tenei tikanga e ko te reira miro-haumaru.Ko te ngoikoretanga ko te nui o te mahi ngota i te urunga o te mahara noa.Mena kaore koe e tohatoha i nga tohatoha-tohanga tohanga i waenga i nga miro, whakaarohia te whakamahi i te [`Rc<T>`] mo te waahanga o raro.
/// [`Rc<T>`] he taunoa ahuru, na te mea ka kaha te kaiwhakatuu ki te tuku [`Rc<T>`] i waenga i nga miro.
/// Heoi, ka kowhiria e te whare pukapuka te `Arc<T>` kia pai ai te ngawari o nga kaihoko o te wharepukapuka.
///
/// `Arc<T>` ka whakatinana i te [`Send`] me te [`Sync`] i nga wa katoa ka whakamahia e te `T` te [`Send`] me te [`Sync`].
/// He aha e kore ai e taea e koe te whakauru i tetahi momo kore-miro-kore `T` ki roto i te `Arc<T>` kia pai ai te miro?Akene he iti noa te whakaaro-kore i te tuatahi: i muri i nga mea katoa, kaore ranei te take o te haumaru o te miro `Arc<T>`?Ko te mea nui tenei: Ma `Arc<T>` e haumaru ai te miro kia maha ai ona rangatira o nga raraunga kotahi, engari kaore e taapirihia te haumaru o te miro ki ona raraunga.
///
/// A feruri i `Arc <` [`RefCell<T>`]>>.
/// [`RefCell<T>`] ehara ko [`Sync`], ana mena ko `Arc<T>` tonu te [`Send`], `Arc <'[' RefCell<T>`]`>` ka pai hoki.
/// Engari ka raru pea maatau:
/// [`RefCell<T>`] kaore te miro i te ahuru;ka mau tonu i a ia te tatau nama e whakamahi ana i nga mahi kore-ngota.
///
/// I te mutunga, ko te tikanga me hono e koe te `Arc<T>` me etahi momo [`std::sync`], te tikanga [`Mutex<T>`][mutex].
///
/// ## Nga huringa pakaru me te `Weak`
///
/// Ka taea te whakamahi i te tikanga [`downgrade`][downgrade] ki te hanga i tetahi tohu-kore [`Weak`]-kore.Ka taea e te [`Weak`] atatohu e [`upgrade`][whakapai ake] d ki te `Arc`, engari ka hoki mai tenei [`None`] ki te uara rongoa i roto i te tohanga kua maturuturu iho.
/// I roto i te mau parau te tahi atu, e kore e `Weak` atatohu pupuri te uara roto ora te tohanga;engari, kei te pupuri tonu ratou i te tohatoha (te toa tuuturu mo te uara) kia ora.
///
/// He huringa i waenga i nga tohu tohu `Arc` e kore e tukuna.
/// Mo tenei take, ka whakamahia te [`Weak`] hei pakaru i nga huringa.Hei tauira, he kaha pea te tohu a te `Arc` mai i nga kopu matua ki nga tamariki, me nga tohu [`Weak`] mai i nga tamariki ki o raatau maatua.
///
/// # Tohutoro Kaute
///
/// whakatinana te hanga i tētahi tohutoro hou i te atatohu tohutoro-kiia ngā te meatia te whakamahi i te `Clone` trait mo [`Arc<T>`][Arc] me [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Ko nga wetereo e rua i raro ake nei he orite.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // he, b, me foo he Pewa katoa e wāhi ki te wāhi mahara taua
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` aukati noa ki `T` (ma te [`Deref`][deref] trait), kia taea ai e koe te karanga i nga tikanga a "T` i runga i te uara o te momo `Arc<T>`.Ki te karo i raruraru hoki ingoa ki `tikanga a T`, nga tikanga o `Arc<T>` e pā ana ano mahi, ka karanga te whakamahi i [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>"Ko nga whakamahinga o te traits penei i te `Clone` ka taea hoki te karanga ma te whakamahi i te wetereo tino tohu.
/// Ko etahi e hiahia ana ki te whakamahi i te wetereo totika tohu, ko etahi e hiahia ana ki te whakamahi i te tikanga-karanga wetereo.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Taputapu-karanga wetereo
/// let arc2 = arc.clone();
/// // Tukutahitanga tohu tika
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] kaore e whakakore-aunoa i te `T`, na te mea kua heke iho pea te uara o roto.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Te tohatoha i etahi raraunga kaore e taea te huri i waenga i nga miro:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Note e tatou kore e ** ** rere enei whakamātautau konei.
// Ka tino harikoa nga kaihanga windows mena ka ora te miro i te miro matua ka puta i te wa kotahi (he mea kati) na te mea ka karohia e tatou tenei ma te kore e whakahaere i enei whakamatautau.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Te tohatoha i te [`AtomicUsize`] ka taea te whakarereke:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Tirohia te [`rc` documentation][rc_examples] mo etahi atu tauira o te tatau tohutoro i te nuinga.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` he putanga o [`Arc`] e pupuri ana i te-kore korero ki te tohatoha whakahaere.
/// I uru atu te tohatoha ma te waea atu ki te [`upgrade`] i runga i te tohu atarangi `Weak`, e whakahoki ana i te ['Kōwhiringa`]`<"[Arc »]`<T>> `.
///
/// I te mea kaore te tohutanga `Weak` e whai mana ki te rangatira, kaore e aukati i te uara e penapena ana i te tohatoha mai i te whakahekehia, a ko `Weak` ano kaore e kii taurangi mo te uara kei reira tonu.
///
/// No reira ka hoki pea te [`None`] ka ['whakahou`] d.
/// Kia mahara engari ko te tohutoro `Weak`*ka* aukati i te tohatoha (te toa tautoko) mai i te whakawhitiwhitinga.
///
/// He pai te tohu atawhai `Weak` hei pupuri i tetahi korero poto mo te tohatoha e whakahaerehia ana e [`Arc`] me te kore e aukati i tona uara o roto kia kore e taka.
/// Ka whakamahia hoki hei aukati i nga tohutoro porowhita i waenga i nga tohu tohu [`Arc`], na te mea kaore e tukuna nga tohutoro ki te tuku i te [`Arc`] kia heke iho ranei.
/// Hei tauira, ka taea e te rakau te tohu [`Arc`] tohu kaha mai i nga kopu matua ki nga tamariki, me nga tohu `Weak` mai i nga tamariki ki o raatau maatua.
///
/// Ko te huarahi angitu ki te whiwhi tohu `Weak` ko te waea ki te [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // He `NonNull` tenei hei tuku i te rahi o tenei momo ki roto i nga inumara, engari ehara i te tohu tika hei tohu.
    //
    // `Weak::new` ka tautuhia tenei ki te `usize::MAX` kaore e hiahiatia te tohatoha waahi i runga i te puranga.
    // E kore te he uara ka ake i te tino atatohu no te he tīaroaro i te iti rawa 2 RcBox.
    // Ka taea noa tenei ka `T: Sized`;kore `T` rahinga kore e tiimata.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Ko te repr(C) tenei ki te future-tohu ki te whakatikatika ano i te mara, ka aukati i te [into|from]_raw() haumaru o nga momo o roto e whakawhiti ana.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // te uara usize::MAX hei kaitutei mo "locking" mo te wa poto te kaha ki te whakahou i nga tohu ngoikore ki te whakaheke i nga mea kaha ranei;ka whakamahia tenei hei karo i nga iwi i `make_mut` me `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Ka hangaia e te `Arc<T>` hou.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Tīmata i te tatau atatohu ngoikore rite 1 i te mea te atatohu ngoikore puritia e ngā i te atatohu kaha katoa (kinda), kite std/rc.rs hoki atu mōhiohio
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Hangaia he `Arc<T>` hou ma te whakamahi i te korero ngoikore ki a ia ano.
    /// Ko te tarai ki te whakahou i te tohutoro ngoikore i mua i te hokinga mai o tenei mahi ka hua mai te uara `None`.
    /// Heoi, ko te tohutoro ngoikore tera pea ka taea te kowhatu noa ka penapena hei whakamahi a muri ake nei.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Hangaia a roto o te "uninitialized" me te tohutoro ngoikore kotahi.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // He mea nui kia kaua e tukuna e tatou te rangatira o te atatohu ngoikore, ki te kore ka watea te mahara ma te hokinga mai o `data_fn`.
        // Mena ka tino hiahia maatau ki te paahitanga rangatira, ka taea e maatau te hanga i tetahi tohu tohu ngoikore maau ake, engari ma tenei ka puta he whakahoutanga ki te kaute tohutoro ngoikore kaore pea e tika ke atu.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Inaianei ka taea e taatau te arawhiti i te wariu o roto ka huri i ta maatau korero ngoikore hei tohu kaha
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ko nga tuhi o runga ake nei ki te mara raraunga me maarama ki nga miro e kite ana i te kaute kaha kore-kore.
            // Na reira me tono e "Release" te ota kia rite tonu te honohono me te `compare_exchange_weak` i te `Weak::upgrade`.
            //
            // "Acquire" kaore e hiahiatia te tono.
            // Ka whakaaro ana ki nga whanonga ka taea o te `data_fn` me titiro taatau ka aha ake me te tohu ki te `Weak` kaore e whakahouhia:
            //
            // - Te reira i taea e *tou* te `Weak`, te whakanui ake i te kaute tohutoro ngoikore.
            // - Ka taea e ia te whakaheke i era kaata, ka whakaheke i te tatauranga ngoikore ngoikore (engari kaore rawa kia kore).
            //
            // e kore e ēnei pānga taha pānga tatou i roto i tetahi ara, a ka ka taea ki te waehere haumaru anake kahore atu pānga taha.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Ma te kaha o te tohutoro e whai kiko tetahi ngoikoretanga ngoikore, no reira kaua e whakahaerea te kaipahua mo te tohutoro ngoikore tawhito.
        //
        mem::forget(weak);
        strong
    }

    /// Ka hangaia e te `Arc` hou ki tirotiro Korearawhiti.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Tuhinga o mua kua whakamanatia:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Hangaia he `Arc` hou me nga tuhinga kaore ano kia whakauruhia, me te mahara ka whakakiihia ki nga paita `0`.
    ///
    ///
    /// Tirohia te [`MaybeUninit::zeroed`][zeroed] mo nga tauira o te whakamahi tika me te he o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Hangaia he `Pin<Arc<T>>` hou.
    /// Mena kaore te `T` i te whakamahi i te `Unpin`, katahi ka piri te `data` ki te mahara kaore e taea te neke.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Ka hangaia he `Arc<T>` hou, ka whakahokia mai he hapa ki te kore e tohatoha.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Tīmata i te tatau atatohu ngoikore rite 1 i te mea te atatohu ngoikore puritia e ngā i te atatohu kaha katoa (kinda), kite std/rc.rs hoki atu mōhiohio
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Hangaia he `Arc` hou me nga tuhinga kaore i whakamanahia, ka whakahoki he hapa ki te kore e tohatoha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Tuhinga o mua kua whakamanatia:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Ka hangaia e te `Arc` hou ki tirotiro Korearawhiti, me te mahara tonu ratou i `0` ngā paita, hoki mai he hapa, ki te kore tohatoha.
    ///
    ///
    /// Tirohia te [`MaybeUninit::zeroed`][zeroed] mo nga tauira o te whakamahi tika me te he o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Whakahokia te uara roto, ki te he te `Arc` rite kotahi tohutoro kaha.
    ///
    /// Ki te kore, ka whakahokia mai he [`Err`] me te `Arc` ano i paahitia.
    ///
    ///
    /// Ka angitu tenei ahakoa he ngoikore nga tohutoro ngoikore.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Hangaia he atatohu ngoikore hei horoi i te tohutoro kaha-ngoikore
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Ka hangaia e te atomically te wāhanga tohutoro-kiia hou ki tirotiro Korearawhiti.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Tuhinga o mua kua whakamanatia:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Hangaia he haahi hou kua whakahuatia mo te tohu-ngota me nga ihirangi koretake, me te mahara ki tonu i te paita `0`.
    ///
    ///
    /// Tirohia te [`MaybeUninit::zeroed`][zeroed] mo nga tauira o te whakamahi tika me te he o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Tahuri ki `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Ka rite ki te [`MaybeUninit::assume_init`], kei te kaikaranga te tohu ko te uara o roto kei roto i te ahuatanga tiimata.
    ///
    /// Ko te karanga i tenei kaore ano kia tiimata nga mahi hei whakaatu i nga whanonga kaore i tino tautuhia.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Tuhinga o mua kua whakamanatia:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Tahuri ki `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Ka rite ki te [`MaybeUninit::assume_init`], kei te kaikaranga te tohu ko te uara o roto kei roto i te ahuatanga tiimata.
    ///
    /// Ko te karanga i tenei kaore ano kia tiimata nga mahi hei whakaatu i nga whanonga kaore i tino tautuhia.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Tuhinga o mua kua whakamanatia:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Ka pau i te `Arc`, ka whakahoki i te atatohu takai.
    ///
    /// Hei karo i te turuturu o te mahara me huri te tohu ki tetahi `Arc` ma te whakamahi i te [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Whakarato he atatohu raw ki te raraunga.
    ///
    /// E kore e te kaute pāngia i roto i tetahi ara, me te kore e te `Arc` pau.
    /// He tika te tohu ki nga wa katoa he kaha nga kaute i te `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // HAUMARU: e kore e taea e tenei te haere i roto i Deref::deref RcBoxPtr::inner no ranei
        // me pupuri tonu te raw/mut whakaturanga penei i te tauira
        // `get_mut` ka taea te tuhi ma te tohu i muri i te whakahoki mai o te Rc ma te `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Hangaia ai he `Arc<T>` mai i te tohu tohu noa.
    ///
    /// Ko te tohu tika me whakahoki mai i mua mai i te piiraa ki [`Arc<U>::into_raw`][into_raw], me rite te rahi me te huringa o te `U` ki te `T`.
    /// He pono noa tenei mena `U` te `T`.
    /// Kia mahara mena kaore te `U` i te `T` engari he rite te rahi me te whakaorite, he rite tonu ki te whakawhiti tohutoro o nga momo rereke.
    /// Tirohia te [`mem::transmute`][transmute] mo etahi atu korero mo nga herenga e pa ana ki tenei keehi.
    ///
    /// Ko te kaiwhakamahi o `from_raw` me maarama ko te uara motuhake o `T` ka taka noa i te wa kotahi.
    ///
    /// Kaore tenei ahuru i te haumaru na te mea ko te whakamahi hē ka arahi pea te kore o te mahara, ahakoa kaore i uru te `Arc<T>` whakahoki.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Tahuri ano ki te `Arc` hei aukati i te turuturu.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ko nga waea waea atu ki te `Arc::from_raw(x_ptr)` he maumahara-kore.
    /// }
    ///
    /// // I wetekina te mahara i te wa i ngaro atu ai te `x` i runga ake nei, no reira kei te tautau a `x_ptr` inaianei!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Huripokihia te taapiri kia kitea te ArcInner taketake.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Ka hangaia he tohu hou [`Weak`] ki tenei tohatoha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // He OK tenei Whakamaangai na te mea ka tirohia te uara i te CAS i raro ake nei.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // tirohia ki te ko tēnei wā te counter ngoikore "locked";ki te penei, miro.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: tenei waehere kaore e aro ki te tuponotanga
            // ki usize::MAX;i te nuinga me whakarereke te Rc me te Arc kia pai ai te toro atu.
            //

            // Rerekē ki Clone(), Me matou tenei ki kia pānui i te Whiwhi ki tukutahi ki te Tuhituhi haere mai i `is_unique`, kia tupu nga ngā mua ki taua tuhituhi i te aroaro o tenei pānui.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Hanga tino kore tatou e hanga i te paruparu nao
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Ka whiwhi i nga tohu tohu [`Weak`] ki tenei tohatoha.
    ///
    /// # Safety
    ///
    /// Ko tenei tikanga ko ia anake te ahuru, engari ma te whakamahi tika ka aata tiaki ano.
    /// Ka taea e tetahi atu miro te whakarereke i te kaute ngoikore i nga waa katoa, tae atu ki te waa i waenga i te karanga i tenei tikanga me te mahi i runga i te otinga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ko tenei korero he whakatau na te mea kaore ano kia tohaina e maatau te `Arc` me te `Weak` ranei i waenga i nga miro.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Mena kua raka te tatauranga ngoikore i tenei wa, ko te uara o te kaute he 0 i mua noa o te mau raka.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Ka whiwhi i te maha o nga tohu kaha (`Arc`) ki tenei tohatoha.
    ///
    /// # Safety
    ///
    /// Ko tenei tikanga ko ia anake te ahuru, engari ma te whakamahi tika ka aata tiaki ano.
    /// Ka taea e tētahi atu miro te huri i te tatau kaha i tetahi wa, tae atu pea i waenganui i karanga tenei tikanga, me te mahi i runga i te hua.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ko tenei korero he whakatau na te mea kaore ano kia tohaina e maatau te `Arc` i waenga i nga miro.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Ka whakanui i te kaha tohutoro kaha ki te `Arc<T>` e pa ana ki te tohu e tohua ana e tetahi.
    ///
    /// # Safety
    ///
    /// Me whiwhi te tohu ki `Arc::into_raw`, ana me tika te tauira `Arc` (arā
    /// te tatau kaha kia neke atu i te 1) mo te roanga o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ko tenei korero he whakatau na te mea kaore ano kia tohaina e maatau te `Arc` i waenga i nga miro.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Pupurihia te Arc, engari kaua e pa ki te utu kaute ma te takai i roto i te TohuTuku-a-ringa
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Whakanuia inaianei te whakahekenga, engari kaua e maturuturu he moni hou ano hoki
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Decrements te tatau tohutoro kaha i runga i te `Arc<T>` e pā ana ki te atatohu whakaratohia e tetahi.
    ///
    /// # Safety
    ///
    /// Me whiwhi te tohu ki `Arc::into_raw`, ana me tika te tauira `Arc` (arā
    /// te tatau kaha kia neke atu i te 1) ka whakahua i tenei tikanga.
    /// Ka taea te whakamahi i tenei tikanga ki te tuku i te `Arc` whakamutunga me te penapena penapena, engari **kaua e** karangahia i muri i te tukunga o te `Arc` whakamutunga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ko aua korero he whakatau na te mea kaore ano kia tohaina e maatau te `Arc` i waenga i nga miro.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ko te pai tenei unsafety no i te mea e ora tenei pewa e kī tatou e he whaimana te atatohu roto.
        // I tua atu, e matau ana tatou e te hanganga `ArcInner` iho ko `Sync` no te raraunga i roto ko rite te pai `Sync`, na kei loaning ok i te atatohu pumau ki enei tirotiro tatou.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // He waahanga-kore o `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Whakangaromia nga raraunga i tenei wa, ahakoa kaore pea e tukuna e maatau te tohatoha pouaka ake (tera pea he tohu tohu ngoikore e takoto noa ana).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Whakatakahia te ngoikore ngoikore ki te pupuri i nga korero kaha katoa
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Returns `true` ki te rua, Arc`s wāhi ki te tohanga taua (i roto i te rite rua ki [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Ka tohaina i te `ArcInner<T>` me te rahi o te waahi mo te uara o-roto-kore kua oti te whakatakotoranga o te uara.
    ///
    /// Ko te mahi `mem_to_arcinner` ka karangahia me te tohu ira me te whakahoki ano i te (pea momona)-tohu mo te `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Tatau tatauranga ma te whakatakotoranga uara i hoatu.
        // I mua, ka taatai te whakatakotoranga i runga i te kupu `&*(ptr as* const ArcInner<T>)`, engari na tenei i hangai he korero tika (tirohia te #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Tukuna he `ArcInner<T>` ki rawaka wāhi mo te uara pea-unsized roto i reira te uara kua te tahora whakaratohia, hoki mai he hapa, ki te kore tohatoha.
    ///
    ///
    /// Ko te mahi `mem_to_arcinner` ka karangahia me te tohu ira me te whakahoki ano i te (pea momona)-tohu mo te `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Tatau tatauranga ma te whakatakotoranga uara i hoatu.
        // I mua, ka taatai te whakatakotoranga i runga i te kupu `&*(ptr as* const ArcInner<T>)`, engari na tenei i hangai he korero tika (tirohia te #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Whakauruhia te ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Ka tohaina i te `ArcInner<T>` me te rahi o te waahi mo te uara o-roto kua rahua.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Tohatoha hoki te `ArcInner<T>` te whakamahi i te uara i homai.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Tārua uara hei paita
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Whakakorea te tohatoha me te kore e makere i nga korero o roto
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Ka tohaina i te `ArcInner<[T]>` me te roa kua whakaritea.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Tuhia nga waahanga mai i te waahanga ki roto i te Arc <\[T\]> hou
    ///
    /// Haumaru hoki me rānei tango te kaiwaea mana bind ranei `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Ka hangaia e te `Arc<[T]>` i te iterator mohiotia ki kia o te rahi etahi.
    ///
    /// Kaore i te tautuhia te whanonga mena kua he te rahi.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic kaitiaki i te taera i nga waahanga T.
        // Mena he panic, ko nga waahanga kua oti te tuhi ki te ArcInner hou ka heke, katahi ka kore te mahara.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Tohu ki te huanga tuatahi
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Maama katoa.Wareware i te kaitiaki kei kore e wetekina te ArcInner hou.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Motuhake trait whakamahia mo `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Ka hangaia he tohu o te atatohu `Arc`.
    ///
    /// Ka hangaia he tohu ano mo te tohatoha ano, ka piki ake te kaute tohutoro kaha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // he pai i konei te whakamahi i te tono māhorahora, kia rite ki te matauranga o te tohutoro taketake ārai atu aho i hetia te muku i te ahanoa.
        //
        // Ka rite ki te korero i te [Boost documentation][1], Ko te whakanui ake i te kaute tohutoro ka taea tonu te mahi me te memory_order_relaxed: Ko nga tohutoro hou ki tetahi mea ka taea mai i tetahi korero kua oti ke, ana ko te whakawhiti i tetahi tohutoro mai i tetahi aho ki tetahi atu me tino whakarato i tetahi tuhirua e hiahiatia ana.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Heoi e hiahia ana tatou ki te tiaki ki refcounts nui i roto i te take te tangata, ko te `mem: : forget`ing Pewa.
        // Mena kaore maatau e mahi i tenei ka taea e te kaute te waipuke ka whakamahi nga kaiwhakamahi i muri-koreutu.
        // Ka ngata to maatau ki te `isize::MAX` i runga i te whakaaro kaore he ~2 piriona miro e whakanui ana i te tatauranga tohutoro i te wa kotahi.
        //
        // Kaore tenei branch e tangohia i roto i tetahi kaupapa whaihua.
        //
        // Ka materahia e taatau na te mea he tino pakupaku te kaupapa penei, a kaore maatau e aro ki te tautoko.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// He whakaahua i te tohutoro mutable ki te `Arc` homai.
    ///
    /// Mena he tohu ano `Arc`, [`Weak`] ranei ki te tohatoha kotahi, ka hangaia e `make_mut` tetahi tohatoha hou ka tono [`clone`][clone] ki te uara o roto hei whakarite i te rangatira motuhake.
    /// Ka kiia tenei ko te toka-to-tuhi.
    ///
    /// Kia mahara he rereke tenei mai i te whanonga o [`Rc::make_mut`] e wehe ana i nga tohu tohu `Weak` e toe ana.
    ///
    /// Tirohia hoki te [`get_mut`][get_mut], kaare ka ngoikore tena ki te whakatauira.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Kaore e kiia tetahi mea
    /// let mut other_data = Arc::clone(&data); // Kaore e taea te whakakii i nga raraunga o roto
    /// *Arc::make_mut(&mut data) += 1;         // Kaute nga raraunga o roto
    /// *Arc::make_mut(&mut data) += 1;         // Kaore e kiia tetahi mea
    /// *Arc::make_mut(&mut other_data) *= 2;   // Kaore e kiia tetahi mea
    ///
    /// // Inaianei `data` me `other_data` tohu ki nga tohatoha rereke.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Kia mahara kei te mau tonu taatau i tetahi korero kaha me tetahi tohutoro ngoikore.
        // Na, ko te tuku i ta maatau korero kaha kaore noa iho, maana anake e kii te mahara ki te heke.
        //
        // Whakamahia te Whiwhi kia mohio ai ka kitea he tuhi ki te `weak` ka pa ana i mua i nga tuhinga tuku (arā, te whakahekenga) ki te `strong`.
        // Mai i te mea he ngoikore taatau kei te pupuri, kaore pea he tupapaku ka taea te tuku i te ArcInner ano.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // He tohu kaha ano kei reira, no reira me tohu tatou.
            // Te tohatoha-i mua i te maharatanga kia ahei ai te tuhi tika i te uara waeina.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // He pai te waatea i runga ake nei na te mea he tino aromautanga tenei: kei te reihi tonu taatau me nga tohu ngoikore e whakataka ana.
            // Ko te keehi kino rawa, ka tohaina he Arc hou ma te kore tikanga.
            //

            // I tangohia e maatau nga waahanga kaha o muri, engari he toe ngoikore ano kei te toe.
            // Ka nekehia e maatau nga korero ki tetahi Arc hou, ka whakakore i era atu ngoikoretanga ngoikore.
            //

            // Kia mahara kaore e taea mo te panui o te `weak` te whakaputa i te usize::MAX (ara, kua raka), na te mea ka taea te raka i te kaute ngoikore e te miro me te korero kaha.
            //
            //

            // Liliu to tatou iho atatohu ngoikore te matū, kia e taea te horoi i te reira ake te ArcInner rite hiahiatia.
            //
            let _weak = Weak { ptr: this.ptr };

            // Ka taea noa te tahae i nga raraunga, ko nga Weaks anake ka toe
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Ko maua anake te korero mo ia momo;hokihia te tatau kaha ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Ka rite ki te `get_mut()`, he pai te kore o te ahuru no te mea he motuhake ta maatau korero mo te tiimata, i riro mai ranei i runga i te whakariterite i nga korero.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Whakahoki ai i te korero whakawhiti ki roto i te `Arc` kua tohaina, mena kaore he tohu tohu `Arc`, [`Weak`] ranei ki taua tohatoha.
    ///
    ///
    /// Whakahoki [`None`] i te mea ke, na te mea kaore e pai te huri i tetahi uara tohaina.
    ///
    /// Tirohia hoki [`make_mut`][make_mut], ka [`clone`][clone] te uara o roto ina he tohu ano etahi.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ko te pai tenei unsafety no te mea e kī tatou e te atatohu hoki ko te *anake* atatohu e ka tonu kia hoki mai ki a T.
            // Ko ta maatau tatauranga toharite he 1 i tenei waa, a ko ta maatau ko te Arc tonu kia `mut`, no reira ka whakahokia e maatau te korero ka taea noa ki nga korero o roto.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Whakahoki ai i te korero whakawhiti ki te `Arc` kua homai, kaore he haki.
    ///
    /// Tirohia hoki te [`get_mut`], e haumaru ana, e tika ana nga arowhai.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// e kore Me dereferenced tetahi atu atatohu `Arc` [`Weak`] ranei ki te tohanga kotahi mo te roanga o te tono he hoki.
    ///
    /// He iti noa tenei keehi mena kaore he tohu penei, hei tauira i muri tonu o te `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Me tupato taatau kia kaua * e hanga i tetahi tohutoro e kapi ana i nga mara "count", na te mea ka uru ke atu tenei ki nga kaute tohutoro (hei tauira
        // e `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Whakatauhia mena koinei te tohutoro ahurei (tae atu ki nga ngoikoretanga ngoikore) ki nga raraunga e whaaia ana.
    ///
    ///
    /// Kia mahara ma tenei e raka ai te tatauranga ngoikore ngoikore.
    fn is_unique(&mut self) -> bool {
        // maukati i te tatau atatohu ngoikore ki te kitea tatou ki kia kapu te taata tei mau atatohu ngoikore.
        //
        // Ko te tapanga whiwhi i konei ka whakarite i te hononga-i mua i tetahi hononga ki a `strong` (ina koa i te `Weak::upgrade`) i mua i nga whakataunga o te tatau `weak` (ma te `Weak::drop`, e whakamahi ana i te tukunga).
        // Ki te kore i maturuturu iho te tohutoro ngoikore ake, ka kore te CAS konei kia kore matou e tiaki ki te tukutahi.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Ko te tikanga he `Acquire` tenei ki te honohono me te paheketanga o te kaute `strong` i te `drop`-koinei anake te uru ka puta ana ka tukuna tetahi korero whakamutunga.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Ko te tuku tuku i konei ka hono tahi me te panui i te `downgrade`, kia aukati i te panui o `strong` i runga ake nei i te paunga o te tuhituhi.
            //
            //
            self.inner().weak.store(1, Release); // tukuna te raka
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Ka maturuturu te `Arc`.
    ///
    /// Ma tenei ka whakaheke te tatauranga kaha kaha.
    /// Mena ka tae te tatauranga toharite kaha ki te kore ka riro ko etahi atu tohutoro (mena) he [`Weak`], na ko `drop` te uara o roto.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // e kore e tā tetahi
    /// drop(foo2);   // Panui "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Na te mea ko te `fetch_sub` he ngota ano, kaore e hiahiatia te hono ki etahi atu aho mēnā ka whakakorehia e maatau te kaupapa.
        // E pā ana tēnei arorau taua ki te raro `fetch_sub` ki te tatau `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Ko tenei taiapa e hiahiatia ana kia aukati i te whakahou i te whakamahinga o nga raraunga me te whakakore i nga raraunga.
        // Na te mea kua tohua te `Release`, ko te heke o te tatauranga tohutoro ka honoa me tenei taiapa `Acquire`.
        // Ko te tikanga ko te whakamahinga o nga korero ka pa ki mua i te whakahekenga o te tatauranga tohutoro, ka puta i mua o tenei taiapa, ka puta i mua o te tangohanga o nga raraunga.
        //
        // Ka rite ki te korero i te [Boost documentation][1],
        //
        // > He mea nui ki te whakakaha i tetahi huarahi ki taua mea kia kotahi
        // > miro (i roto i te tohutoro ngā)*tupu ki te aroaro o te muku*
        // > te ahanoa i roto i te miro rerekē.Ka tutuki tenei i te "release"
        // > mahi i muri i te whakaheke i te tohutoro (tetahi urunga ki te ahanoa
        // > na tenei tohutoro me tino puta i mua), me te
        // > "acquire" mahi i mua i te whakakore i te ahanoa.
        //
        // Ina koa, ahakoa kaore e taea te huri te tirotiro o te Arc, ka taea pea te tuhi o roto ki tetahi mea penei i te Mutex<T>.
        // I te mea kaore i riro mai i a Mutex te wa e mukua ana, kaore e taea e taatau te whakawhirinaki ki te whakarite i nga tuhinga ki te miro He kitea e te kaipahua e rere ana i te miro B.
        //
        //
        // Kia mahara hoki ko te taiepa Whiwhi i konei ka taea pea te whakakapi me te kawenga Hoko, hei whakapai ake i nga mahi i nga wa e tautohetia ana.Tirohia te [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Ngana ki te whakaheke i te `Arc<dyn Any + Send + Sync>` ki tetahi momo raima.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Ka hangaia he `Weak<T>` hou, me te kore e tohatoha i tetahi mahara.
    /// Ko te karanga i te [`upgrade`] i runga i te uara whakahoki ka homai [`None`] i nga wa katoa.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Patohia te kaiawhina kia uru atu ki nga kaute tohutoro me te kore e kii i nga korero mo te waahanga raraunga.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Whakahokia ai he tohu atawhai ki te ahanoa `T` i tohua e tenei `Weak<T>`.
    ///
    /// Ko te tohu he mana noa mena he kaha nga tohu korero.
    /// kia te atatohu e nao, unaligned ara [`null`] te kore ranei.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // E tohu ana nga mea e rua ki te mea kotahi
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ma te kaha o konei e ora ai, kia uru tonu ai tatou ki taua mea.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Engari kaua atu.
    /// // Ka taea e taatau te weak.as_ptr(), engari ko te uru ki te tohu ka tohu ki te whanonga kore.
    /// // assert_eq! ("hello", haumaru {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Mena kei te piirangi te tohu, ka whakahokia e maatau te kaitiaki.
            // Kaore tenei e taea te noho hei waahi utunga tika, na te mea ko te utunga he rite tonu ki te ArcInner (usize).
            ptr as *const T
        } else {
            // SAFETY: mena he teka te whakahoki mai, he kore e tohua te tohu.
            // Ka heke pea te utunga i tenei wa, me mau tonu taatau, na reira whakamahia te raweke tohu tika.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Ka pau te `Weak<T>` ka huri hei tohu tohu noa.
    ///
    /// Ka huri tenei i te atatohu ngoikore hei tohu tika, ahakoa kei te pupuri tonu i te rangatira o tetahi tohutoro ngoikore (kaore te ngoikore e kiia e tenei mahinga).
    /// Ka taea te whakahoki ano ki te `Weak<T>` me te [`from_raw`].
    ///
    /// Ko nga herenga rite mo te uru atu ki te whaainga o te atatohu me te [`as_ptr`] e pa ana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Ka huri i tetahi tohu atawhai ma [`into_raw`] i hangaia i mua hei `Weak<T>`.
    ///
    /// Ka taea te whakamahi kia pai ai te rapu i tetahi korero kaha (ma te waea atu ki te [`upgrade`] a muri ake) ki te whakawhiti ranei i te kaute ngoikore ma te maka i te `Weak<T>`.
    ///
    /// He mana pupuri ki tetahi korero ngoikore (haunga nga tohu tohu i hangaia e [`new`], na te mea kaore enei i a raatau; ka mahi tonu te tikanga ki a raatau).
    ///
    /// # Safety
    ///
    /// I ahu mai te tohu i te [`into_raw`] ana me mau tonu ki tana tohutoro ngoikore pea.
    ///
    /// Ka whakaaetia kia 0 te kaha o te kaute i te wa e waea ana tenei.
    /// Heoi, ko tenei ka mau ki tetahi tohutoro ngoikore e tohuhia ana hei tohu tohu noa (ko te ngoikore ngoikore kaore i te whakarerekehia e tenei mahinga) na reira me hono atu ki te karanga o mua ki te [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Te whakaheke i te tatauranga ngoikore whakamutunga.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Tirohia te Weak::as_ptr mo te horopaki e ahu mai ana te tohu tohu.

        let ptr = if is_dangling(ptr as *mut T) {
            // He ngoikoretanga ngoikore tenei.
            ptr as *mut ArcInner<T>
        } else {
            // Te kore, e kī matou ka haere mai te atatohu i te paruparu nondangling.
            // SAFETY: data_offset he pai ki te karanga, na te mea he tohu ptr he tino (kua heke pea) T.
            let offset = unsafe { data_offset(ptr) };
            // Na, ka hurihia e taatau te waahi kia whiwhi katoa ai te RcBox.
            // SAFETY: na te ngoikore i ahu mai te tohu, no reira he ahuru tenei waahanga.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: kua riro mai i a maatau inaianei te tohu pono ngoikore, na reira ka taea te hanga i te Wera.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Ngana ki te whakahou i te tohu `Weak` ki te [`Arc`], ka whakaroa te heke o te uara o roto mena ka angitu.
    ///
    ///
    /// Whakahoki [`None`] mena kua heke te uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Whakangaromia nga tohu tohu kaha katoa.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Ka whakamahia e maatau he koropiko CAS hei whakanui ake i te kaute kaha kaore i te tiki i te_na te mea kaore tenei mahi e tango i te kaute tohutoro mai i te kore ki te kotahi.
        //
        //
        let inner = self.inner()?;

        // whakapumautia kawenga māhorahora no (ko na lau he "stale" o 0 pai) tetahi tuhituhi o 0 e taea tatou mau rau i te mara i roto i te kore āhua tūturu, me tetahi atu uara te mā te CAS i raro.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Tirohia nga korero i te `Arc::clone` mo te aha i mahia ai e matou tenei (mo `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // He pai te okiokinga mo te keehi rahuatanga no te mea kaore o maatau tumanako mo te kawanatanga hou.
            // Ko te Whiwhi he mea tika kia honoa te keehi angitu me te `Arc::new_cyclic`, ka taea ana te arahi i te uara o roto i muri i te mahinga o nga tohutoro `Weak`.
            // I roto i tena, ko te tumanako ka tirohia e tatou te uara tuatahi kua whakaritea.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null kua tirohia i runga ake nei
                Err(old) => n = old,
            }
        }
    }

    /// Riro te maha o kaha atatohu (`Arc`) tuhu ki tenei tohatoha.
    ///
    /// Ki te i hanga `self` te whakamahi i [`Weak::new`], ka hoki mai tenei 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Ka whiwhi tata ki te maha o nga tohu tohu `Weak` e tohu ana ki tenei tohatoha.
    ///
    /// Mena i hangaia te `self` ma te [`Weak::new`], mena kaore pea he tohu kaha, ka hoki tenei ki te 0.
    ///
    /// # Accuracy
    ///
    /// Na nga korero whakatinana, ka taea te 1 te uara i whakahokia mai i tetahi taha, i etahi atu miro e whakahaere ana i tetahi `Arc`s, i te`Weaks`s e tohu ana ki te waahanga tohatoha.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // I te kitenga o matou kotahi pea te tohu tika i muri i te panui i te kaute ngoikore, e mohio ana matou ko te tohutoro ngoikore (i nga wa e ora ana etahi tohutoro kaha) kei te takiwa tonu i te wa i kite matou i te kaute ngoikore, na reira ka taea te tango maatete.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Whakahokia `None` ka te nao i te atatohu me reira te kore tohatoha `ArcInner`, (arā, i te hanga tenei `Weak` e `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Ka tupato taatau kia *kaua* e hanga i tetahi korero e kapi ana i te mara "data", na te mea ka rite tonu te whakarereke o te mara (hei tauira, mena ka taka te `Arc` whakamutunga, ka whakataka te waahanga raraunga ki te waahi).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Whakahoki `true` mena ka tohu nga `Weak` e rua ki te tohatoha kotahi (he rite ki te [`ptr::eq`]), ki te kore ranei e rua e tohu ki tetahi waahanga (na te mea i hangaia me te `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Na te mea ka whakataurite tenei i nga tohu tohu te tikanga ka rite a `Weak::new()` ki a ratau, ahakoa kaore ratau e tohu ki tetahi tohatoha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Te Whakatairite `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Ka hangaia he tohu o te atatohu `Weak` e tohu ana ki te tohatoha kotahi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Tirohia te kōrero i roto i te Arc::clone() hoki aha mărû te tenei.
        // Ka taea e tenei te whakamahi i te tiki_add (kaore e aro ki te raka) na te mea ko te kaute ngoikore ka raka noa kei hea nga * tohu kore ngoikore e tiimata ana.
        //
        // (Na kaore e taea te whakahaere i tenei waehere i roto i taua keehi).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Tirohia te kōrero i roto i te Arc::clone() mo aha te mahi tatou i tenei (mo mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Hangaia he `Weak<T>` hou, me te kore e tohaina te mahara.
    /// Ko te karanga i te [`upgrade`] i runga i te uara whakahoki ka homai [`None`] i nga wa katoa.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Ka maturuturu i te atatohu `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // e kore e tā tetahi
    /// drop(foo);        // Panui "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Mena ka mohio taatau ko tatou te kaitohu ngoikore whakamutunga, kaati tona waa ki te whakawhiti katoa i nga korero.Tirohia te te kōrero i roto i Arc::drop() e pā ana ki te tikanga mahara
        //
        // Kaore e tika kia tirotirohia te waahi kua raka i konei, na te mea ka taea te raka i te tatauranga ngoikore mena he kotahi ngoikore te ngoikoretanga, ko te tikanga ka heke noa te maturuturu ON te toenga ngoikore e toe ana, ka tupu ana i muri i te tukunga o te raka.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Kei te mahi maatau i konei, kaore hei whakapai ake i te `&T`, na te mea ka taapirihia he utu ki nga huringa taurite katoa o nga ref.
/// Ki ta maatau ko nga `Arc`s e whakamahia ana hei penapena i nga uara nui, he puhoi ki te whakatau, engari he taumaha hoki ki te tirotiro mo te taurite, kia ngawari ake ai te utu o tenei utu.
///
/// Ko te mea pea ka rua nga kaata `Arc`, ka tohu ki te uara kotahi, neke atu i te rua `&T`s.
///
/// Ka taea e anake te mahi tatou i tenei ka ai kia āta irreflexive `T: Eq` rite te `PartialEq`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Te taurite mo nga `Arc 'e rua.
    ///
    /// E rua nga Arc ka rite ki te orite o raatau uara o roto, ahakoa he maha nga waahanga kua penapena.
    ///
    /// Mena ka whakamahia e `T` te `Eq` (e whakaatu ana i te rereketanga o te taurite), e rua nga `Arc` e tohu ana ki te waahanga tohatoha he rite tonu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Te taurite mo e rua `Arc`s.
    ///
    /// E rua nga 'Arc` kaore e taurite mena kaore e uara nga uara o roto.
    ///
    /// Mena kei te whakamahia e `T` te `Eq` (e whakaatu ana i te rereketanga o te taurite), e rua nga `Arc` e tohu ana ki te uara kotahi kaore e taurite.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Whakataurite waahanga mo nga `Arc` e rua.
    ///
    /// Ka whakatauhia nga mea e rua ma te karanga `partial_cmp()` mo o raatau uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// He iti ake i te whakataurite mo nga `Arc` e rua.
    ///
    /// Ka whakatauhia nga mea e rua ma te karanga `<` mo o raatau uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Iti iho i te rite ranei ki' te whakataurite mo nga `Arc 'e rua.
    ///
    /// Ka whakatauhia nga mea e rua ma te karanga `<=` mo o raatau uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// He whakataurite nui-atu mo nga `Arc` e rua.
    ///
    /// Ka whakatauhia nga mea e rua ma te karanga `>` mo o raatau uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Rahi atu i te rite ranei ki te' whakataurite mo nga 'Arc` rua.
    ///
    /// Ka whakatauhia nga mea e rua ma te karanga `>=` mo o raatau uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Whakataurite mo nga `Arc` e rua.
    ///
    /// Ka whakatauhia nga mea e rua ma te karanga `cmp()` mo o raatau uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Ka hangaia he `Arc<T>` hou, me te uara `Default` mo `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Tohaina he waahanga tohutoro-ka tohua ka whakakii ma te tohu i nga taonga o te 'v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Tohatoha i te `str` tohutoro-kiia me tārua `v` ki reira.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Tohatoha i te `str` tohutoro-kiia me tārua `v` ki reira.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Nuku te ahanoa pouaka ki te, tohatoha tohutoro-kiia hou.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Tohaina he waahanga tohutoro-ka tohua ka nekehia nga taonga a 'v` ki roto.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Tukua te Vec ki te tuku i tana mahara, engari kaua e whakangaro i nga korero o roto
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// E ia huānga i roto i te `Iterator` me kohi ki roto ki te `Arc<[T]>`.
    ///
    /// # Nga ahuatanga mahi
    ///
    /// ## Ko te keehi whanui
    ///
    /// I te keehi noa, ko te kohi ki te `Arc<[T]>` ka oti i te kohinga tuatahi ki te `Vec<T>`.Koinei, i te wa e tuhi ana i nga korero e whai ake nei:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// he rite tenei ki a maatau i tuhi:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ko nga waahanga tuatahi o nga tohatoha ka puta i konei.
    ///     .into(); // Ko te tohatoha tuarua mo `Arc<[T]>` ka tupu i konei.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ka tohatoha tenei rite maha nga wa i rite hiahiatia mō te hanga i te `Vec<T>`, a ka ka tohatoha reira kotahi mo tahuri te `Vec<T>` ki te `Arc<[T]>`.
    ///
    ///
    /// ## Iterator o te roa e mohiotia ana
    ///
    /// A, no te whakatinana koutou `Iterator` `TrustedLen` me ko o te rahi tangohia, ka kia hanga he tohaina kotahi mo te `Arc<[T]>`.Hei tauira:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Kotahi noa te tohatoha ka tupu i konei.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Motuhake trait whakamahia mo te kohi ki `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Koinei te keehi mo te miihini `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Me whakarite e taatau kia rite te roa o te kaitapa, a, kei a tatou ano.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Hoki atu ki te whakatinana noa.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Tangohia te utu i roto i te `ArcInner` mo nga utunga i muri o te tohu.
///
/// # Safety
///
/// Me tohu te tohu ki (me whai metadata whaimana hoki) he tauira tika o mua o T, engari ka tukuna te T kia heke.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Whakatikahia te uara kua whakakahoretia ki te pito o te ArcInner.
    // Na te mea ko RcBox te repr(C), ka waiho koinei hei waahi whakamutunga hei whakamahara.
    // SAFETY: mai i nga momo momo kore e taea he poro, trait taonga,
    // me ngā momo extern, he nui tēnei wā ki te makona nga whakaritenga o align_of_val_raw te whakaritenga haumaru tāuru;he taipitopito whakatinana tenei o te reo kaore pea e whirinaki ki waho o te std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}