//! Tohu tohu-tohutoro-tatau kotahi.'Rc' tu mo 'Tohutoro
//! Counted'.
//!
//! Ko te momo [`Rc<T>`][`Rc`] e tohaina ana te rangatiratanga o te momo `T`, kua tohaina ki te puranga.
//! Te whakataranga [`clone`][clone] i runga i [`Rc`] hua i te atatohu hou ki te tohanga taua i roto i te puranga.
//! Ka ngaro te tohu [`Rc`] whakamutunga ki tetahi tohatoha, ka heke iho te uara e penapena ana i taua waahanga (e kiia ana ko "inner value").
//!
//! Ngā tohutoro i roto i te Rust te whakakahoretia e irakētanga i te taunoa, ko [`Rc`] he kahore okotahi: e kore e taea e koe te tikanga whiwhi i te tohutoro mutable ki te tahi mea i roto i te [`Rc`].
//! Ki te hiahia koe mutability, hoatu he [`Cell`] [`RefCell`] ranei roto te [`Rc`];tirohia te [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] ka whakamahi i te tatauranga tohanga kore-ngota.
//! e kore e taea te tonoa tenei tikanga e rererangi ko te tino iti, engari he [`Rc`] i waenganui i miro, a no reira e kore e [`Rc`] whakatinana [`Send`][send].
//! Ka rite ki te hua, ka tirohia te taupatupatu Rust *i wa* whakahiato e kore koutou e unga [`Rc`] s i waenganui miro.
//! Mena e hiahia ana koe ki te maha o nga aho, te tatau tohutoro ngota, whakamahia te [`sync::Arc`][arc].
//!
//! Ka taea te whakamahi i te tikanga [`downgrade`][downgrade] ki te hanga i tetahi tohu kore [`Weak`] rangatira-kore.
//! Ka taea pea te tohu atawhai [`Weak`] hei [`whakahou`]][whakahou] d ki te [`Rc`], engari ka hoki mai tenei [`None`] mena kua heke iho te uara e penapena ana i roto i te tohatoha.
//! I roto i te mau parau te tahi atu, e kore e `Weak` atatohu pupuri te uara roto ora te tohanga;engari, kei te pupuri tonu ratou i te tohatoha (te toa tautoko mo te uara o roto) kia ora.
//!
//! He huringa i waenga i nga tohu tohu [`Rc`] e kore e tukuna.
//! Mo tenei take, ka whakamahia te [`Weak`] hei pakaru i nga huringa.
//! Hei tauira, ka taea e te rakau te tohu [`Rc`] tohu kaha mai i nga kopu matua ki nga tamariki, me nga tohu [`Weak`] mai i nga tamariki ki o raatau maatua.
//!
//! `Rc<T>` whakakore noa i te `T` (ma te [`Deref`] trait), kia taea ai e koe te karanga i nga tikanga a "T` i runga i te uara o te momo [`Rc<T>`][`Rc`].
//! Hei karo i nga tukinga ingoa me nga tikanga a "T`, ko nga tikanga o te [`Rc<T>`][`Rc`] ano he mahi hono, e kiia ana he [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>`Ai hoki e huaina implementations o o traits rite `Clone` whakamahi wetereo tino tohu.
//! Ko etahi e hiahia ana ki te whakamahi i te wetereo totika tohu, ko etahi e hiahia ana ki te whakamahi i te tikanga-karanga wetereo.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Taputapu-karanga wetereo
//! let rc2 = rc.clone();
//! // Tukutahitanga tohu tika
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] kaore e whakakore-aunoa i te `T`, na te mea kua heke iho pea te uara o roto.
//!
//! # Tohutoro Kaute
//!
//! Ko te hanga i tetahi tohutoro hou ki te waahanga tohatoha me te tohu tohu kua tohua hei tohu ma te whakamahi i te `Clone` trait i whakatinanahia mo [`Rc<T>`][`Rc`] me [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Ko nga wetereo e rua i raro ake nei he orite.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a me te tohu a raua i te waahi mahara ano ki te foo.
//! ```
//!
//! Ko te kohinga `Rc::clone(&from)` te mea tauhou na te mea he maarama te whakaatu mai i te tikanga o te waehere.
//! I roto i te tauira i runga ake nei, he maama ake te wetereo tenei ki te kite kei te hangaia e tenei waehere he tohutoro hou kaua ki te kape i nga korero katoa a te foo.
//!
//! # Examples
//!
//! A feruri i te tauari i reira e puritia te huinga o `Gadget`s i te `Owner` homai.
//! Kei te pirangi taatau `Gadget` ki te tohu i to raatau `Owner`.Kaore e taea e maatau tenei me te rangatira motuhake, na te mea neke atu i te kotahi nga taputapu no te `Owner` ano.
//! [`Rc`] taea tatou ki te faaite i te `Owner` i waenganui i maha, Gadget`s, ka whai i te `Owner` noho tohaina rite te roa rite tetahi ngā `Gadget` i reira.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... etahi atu mara
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... etahi atu mara
//! }
//!
//! fn main() {
//!     // Waihanga i te `Owner` tohutoro-kiia.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Hanga `Gget`s no `gadget_owner`.
//!     // Te pūrua i te `Rc<Owner>` homai tatou he atatohu hou ki te tohanga `Owner` taua, incrementing te tatau tohutoro i roto i te tukanga.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Whakakahoretia to taatau taurangi `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Ahakoa te whakaheke i te `gadget_owner`, ka taea tonu e taatau te tuhi i te ingoa o te `Owner` o te `Gadget`s.
//!     // Ko tenei na te mea i tukuna noa e matou tetahi `Rc<Owner>`, kaore ko te `Owner` e tohu ana ia.
//!     // I te mea kei kona ano etahi atu `Rc<Owner>` e tohu ana i te waahanga tohaa `Owner`, ka noho ora tonu.
//!     // Ko te whakaaro o te mara `gadget1.owner.name` ka mahi na te mea `Rc<Owner>` ka whakakore noa i te `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // I te mutunga o te mahi, ka ngaro te `gadget1` me te `gadget2`, ana ko nga tohu whakamutunga e pa ana ki to maatau `Owner`.
//!     // Gadget te tangata inaianei tangata ngaro rite te pai.
//!     //
//! }
//! ```
//!
//! Mena ka rereke o maatau whakaritenga, a me kaha ki te whakawhiti mai i te `Owner` ki te `Gadget`, ka raru taatau.
//! He atatohu [`Rc`] i `Owner` ki `Gadget` whakamōhio te huringa.
//! Ko te tikanga kaore e eke a raatau tatauranga ki te 0, kaore e ngaro te tohatoha:
//! he turuturu mahara.Kia pai ai te huri i tenei, ka taea e taatau te whakamahi tohu tohu [`Weak`].
//!
//! Ko te Rust te mea uaua ki te whakaputa i tenei koropiko i te tuatahi.I roto i te tikanga ki te mutunga ki e rua uara e wāhi i ia atu ki runga, me tetahi o ratou ki te kia mutable.
//! He uaua tenei na te mea ka whakamana te [`Rc`] i te ahuru mahara ma te tuku noa i nga tohutoro tiri ki te uara e takai ana, a kaore enei e whakaae ki te whakarereketanga totika.
//! Me takai e tatou te waahanga o te uara e hiahia ana taatau ki te whakarereke i te [`RefCell`], e whakarato ana i te *whakarereke o roto*: he tikanga hei whakatutuki i te rereketanga ma te korero korero.
//! [`RefCell`] whakamana i nga ture nama a Rust i te wa weto.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... etahi atu mara
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... etahi atu mara
//! }
//!
//! fn main() {
//!     // Waihanga i te `Owner` tohutoro-kiia.
//!     // Kia mahara kua waiho e tatou te vector o `te Kaipupuri` ki roto i te `RefCell` kia taea ai e taatau te huri i roto i te korero korero.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Waihanga `Gadget`s no ki `gadget_owner`, pera i mua.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Taapirihia nga `Gadget` ki ta raatau `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` mutu konei hihiri.
//!     }
//!
//!     // Me aata whakaaro ki a maatau `Gadget`, ka taatai i o raatau taipitopito.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` he `Weak<Gadget>`.
//!         // Na te mea kaore e taea e nga tohu tohu `Weak` te tohu kei te noho tonu te tohatoha, me waea atu ki a `upgrade`, ka whakahoki i te `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // I tenei wa ka mohio taatau ko te tohatoha kei reira tonu, no reira ka `unwrap` noa taatau te `Option`.
//!         // I roto i tetahi papatono uaua ake, akene he hapa te whakahaere i a koe mo te hua `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // I te mutunga o te mahi, kua ngaro `gadget_owner`, `gadget1`, ko `gadget2`.
//!     // I tenei wa kaore he tohu kaha (`Rc`) ki nga taputapu, na ka ngaro.
//!     // Ka kore tenei e kiia te korero tohutoro ki te Tangata Taputapu, na ka ngaro ano hoki ia.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Ko te repr(C) tenei ki te future-tohu ki te whakatikatika ano i te mara, ka aukati i te [into|from]_raw() haumaru o nga momo o roto e whakawhiti ana.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// He tohu kotahi-miro tohumatua-tatau.'Rc' tu mo 'Tohutoro
/// Counted'.
///
/// Tirohia te te [module-level documentation](./index.html) mō ētahi atu kōrero.
///
/// Ko nga tikanga tuuturu o `Rc` he mahi hono katoa, ko te tikanga me karanga e koe kia rite ki te [`Rc::get_mut(&mut value)`][get_mut] hei utu mo te `value.get_mut()`.
/// Ka karo tenei i nga pakanga me nga tikanga o te momo `T` o roto.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // He pai tenei awangawanga na te mea kei te ora tenei Rc kua whakaarohia taatau he tika te tohu a roto.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Hangaia he `Rc<T>` hou.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // He tohu tohu ngoikore tera na nga tohu kaha katoa, e whakarite ana kaore te kaiwhakakahore ngoikore e wetekina te tohatoha i te wa e rere ana te kaipupuri kaha, ahakoa kei te waiho te tohu tohu ngoikore ki roto i te mea kaha.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Hangaia he `Rc<T>` hou ma te whakamahi i te korero ngoikore ki a ia ano.
    /// Ko te tarai ki te whakahou i te tohutoro ngoikore i mua i te hokinga mai o tenei mahi ka hua mai te uara `None`.
    ///
    /// Heoi, ko te tohutoro ngoikore tera pea ka taea te kowhatu noa ka penapena hei whakamahi a muri ake nei.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... atu mara
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Hangaia a roto o te "uninitialized" me te tohutoro ngoikore kotahi.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // He mea nui kia kaua e tukuna e tatou te rangatira o te atatohu ngoikore, ki te kore ka watea te mahara ma te hokinga mai o `data_fn`.
        // Mena ka tino hiahia maatau ki te paahitanga rangatira, ka taea e maatau te hanga i tetahi tohu tohu ngoikore maau ake, engari ma tenei ka puta he whakahoutanga ki te kaute tohutoro ngoikore kaore pea e tika ke atu.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Ma te kaha o te tohutoro e whai kiko tetahi ngoikoretanga ngoikore, no reira kaua e whakahaerea te kaipahua mo te tohutoro ngoikore tawhito.
        //
        mem::forget(weak);
        strong
    }

    /// Hangaia he `Rc` hou me nga tuhinga kaore i whakamanahia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Tuhinga o mua kua whakamanatia:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Hangaia he `Rc` hou me nga tuhinga kaore ano kia whakauruhia, me te mahara ka whakakiihia ki nga paita `0`.
    ///
    ///
    /// Tirohia te [`MaybeUninit::zeroed`][zeroed] mo nga tauira o te whakamahi tika me te he o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ka hangaia he `Rc<T>` hou, ka whakahoki he hapa mena ka kore te tohatoha
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // He tohu tohu ngoikore tera na nga tohu kaha katoa, e whakarite ana kaore te kaiwhakakahore ngoikore e wetekina te tohatoha i te wa e rere ana te kaipupuri kaha, ahakoa kei te waiho te tohu tohu ngoikore ki roto i te mea kaha.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Ka hangaia e te `Rc` hou ki tirotiro Korearawhiti, hoki mai he hapa, ki te kore te tohanga
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Tuhinga o mua kua whakamanatia:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Hangaia he `Rc` hou me nga tuhinga kaore i whakauruhia, me te whakamaharatanga ki tonu i te `0` paita, ka whakahoki he he ka he te tohatoha
    ///
    ///
    /// Tirohia te [`MaybeUninit::zeroed`][zeroed] mo nga tauira o te whakamahi tika me te he o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Hangaia he `Pin<Rc<T>>` hou.
    /// Ki te kore e `T` whakatinana `Unpin`, ka kia pinea na `value` i te mahara, me te taea ki te kia whakakorikoria.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Whakahokia ai te uara o roto, mena he tika te tohutoro kaha a te `Rc`.
    ///
    /// Ki te kore, ka whakahokia mai he [`Err`] me te `Rc` ano i paahitia.
    ///
    ///
    /// Ka angitu tenei ahakoa he ngoikore nga tohutoro ngoikore.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kape i te ahanoa kei roto

                // Tohua ki Weaks e kore e taea te whakatairangatia ana ratou e decrementing te tatau kaha, a ka tango i te atatohu "strong weak" te matū i whāwhā hoki te maturuturunga iho arorau e tika fokotuutuu he rūpahu paruparu.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Hangaia he waahanga hou kua tohua ki te tohutoro me nga tuhinga kaore i whakamanahia.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Tuhinga o mua kua whakamanatia:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Ka hangaia he waahanga tohutoro-kua tohua ki te waahanga kaore ano kia whakauruhia, me te mahara ka whakakiihia ki nga paita `0`.
    ///
    ///
    /// Tirohia te [`MaybeUninit::zeroed`][zeroed] mo nga tauira o te whakamahi tika me te he o tenei tikanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Tahuri ki `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Ka rite ki te [`MaybeUninit::assume_init`], kei te kaikaranga te tohu ko te uara o roto kei roto i te ahuatanga tiimata.
    ///
    /// Ko te karanga i tenei kaore ano kia tiimata nga mahi hei whakaatu i nga whanonga kaore i tino tautuhia.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Tuhinga o mua kua whakamanatia:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Tahuri ki `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Ka rite ki te [`MaybeUninit::assume_init`], kei te kaikaranga te tohu ko te uara o roto kei roto i te ahuatanga tiimata.
    ///
    /// Ko te karanga i tenei kaore ano kia tiimata nga mahi hei whakaatu i nga whanonga kaore i tino tautuhia.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Tuhinga o mua kua whakamanatia:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Ka pau i te `Rc`, ka whakahoki i te atatohu takai.
    ///
    /// Ki te karo i te turuturu mahara me waiho hoki ului ki he `Rc` te whakamahi i [`Rc::from_raw`][from_raw] te atatohu.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Whakarato he atatohu raw ki te raraunga.
    ///
    /// Ko nga kaute kaore e pa ki tetahi ahuatanga, kaore hoki te `Rc` e pau.
    /// He tika te tohu mo te wa roa he kaha nga kaute i te `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: Kaore tenei e puta i te Deref::deref me te Rc::inner na te mea
        // me pupuri tonu te raw/mut whakaturanga penei i te tauira
        // `get_mut` ka taea te tuhi ma te tohu i muri i te whakahoki mai o te Rc ma te `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Hangaia ai he `Rc<T>` mai i te tohu tohu noa.
    ///
    /// Ko te tohu tika me whakahoki mai i mua mai i te piiraa ki [`Rc<U>::into_raw`][into_raw], me rite te rahi me te huringa o te `U` ki te `T`.
    /// He pono noa tenei mena `U` te `T`.
    /// Kia mahara mena kaore te `U` i te `T` engari he rite te rahi me te whakaorite, he rite tonu ki te whakawhiti tohutoro o nga momo rereke.
    /// Tirohia te [`mem::transmute`][transmute] mo etahi atu korero mo nga herenga e pa ana ki tenei keehi.
    ///
    /// Ko te kaiwhakamahi o `from_raw` me maarama ko te uara motuhake o `T` ka taka noa i te wa kotahi.
    ///
    /// Kaore tenei ahuru i te haumaru na te mea ko te whakamahi hē ka arahi pea te kore o te mahara, ahakoa kaore i uru te `Rc<T>` whakahoki.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Tahuri ano ki te `Rc` hei aukati i te turuturu.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ko nga waea waea atu ki te `Rc::from_raw(x_ptr)` he maumahara-kore.
    /// }
    ///
    /// // I wetekina te mahara i te wa i ngaro atu ai te `x` i runga ake nei, no reira kei te tautau a `x_ptr` inaianei!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Huripokihia te taapiri kia kitea te RcBox taketake.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Ka hangaia he tohu hou [`Weak`] ki tenei tohatoha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Hanga tino kore tatou e hanga i te paruparu nao
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Ka whiwhi i nga tohu tohu [`Weak`] ki tenei tohatoha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Ka whiwhi i te maha o nga tohu kaha (`Rc`) ki tenei tohatoha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Whakahoki mai ai i te `true` mena kaore ano etahi atu tohu `Rc`, [`Weak`] ranei ki tenei tohatoha.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Whakahoki ai i te korero whakawhiti ki roto i te `Rc` kua tohaina, mena kaore he tohu tohu `Rc`, [`Weak`] ranei ki taua tohatoha.
    ///
    ///
    /// Whakahoki [`None`] i te mea ke, na te mea kaore e pai te huri i tetahi uara tohaina.
    ///
    /// Tirohia hoki [`make_mut`][make_mut], ka [`clone`][clone] te uara o roto ina he tohu ano etahi.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Whakahoki ai i te korero whakawhiti ki te `Rc` kua homai, kaore he haki.
    ///
    /// Tirohia hoki te [`get_mut`], e haumaru ana, e tika ana nga arowhai.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Ko etahi atu tohu tohu `Rc`, [`Weak`] ranei ki te moni tohaina kaua e whakakorehia mo te roanga o te wa i whakahokia mai ai te nama.
    ///
    /// Ko trivially tenei te take, ki te tīariari kahore kuru taua, hei tauira i muri i tonu `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Kia tupato kaua *e hanga* i tetahi korero hei kapi i nga mara "count", na te mea ka taupatupatu tenei ki nga uru ki nga kaute tohutoro (hei tauira
        // e `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Whakahoki `true` mena ka tohu nga `Rc` e rua ki te tohatoha kotahi (i roto i te uaua rite ki te [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Ka hangaia he korero hei huri ki te `Rc` i homai.
    ///
    /// Mena he tohu `Rc` ano mo te tohatoha ano, ka `make_mut` ka [`clone`] te uara o roto ki tetahi waahanga hou hei whakarite i te rangatira motuhake.
    /// Ka kiia tenei ko te toka-to-tuhi.
    ///
    /// Mena kaore ano etahi atu tohu tohu `Rc` mo tenei tohatoha, katahi ka whakakorehia nga tohu [`Weak`] ki tenei tohatoha.
    ///
    /// Tirohia hoki te [`get_mut`], kaare ka ngoikore tena ki te whakatauira.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Kaore e kiia tetahi mea
    /// let mut other_data = Rc::clone(&data);    // Kaore e taea te whakakii i nga raraunga o roto
    /// *Rc::make_mut(&mut data) += 1;        // Kaute nga raraunga o roto
    /// *Rc::make_mut(&mut data) += 1;        // Kaore e kiia tetahi mea
    /// *Rc::make_mut(&mut other_data) *= 2;  // Kaore e kiia tetahi mea
    ///
    /// // Inaianei `data` me `other_data` tohu ki nga tohatoha rereke.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] kia ka tētehi atatohu:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Me taatai te raraunga, kei kona ano etahi atu Rc.
            // Te tohatoha-i mua i te maharatanga kia ahei ai te tuhi tika i te uara waeina.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Ka taea noa te tahae i nga raraunga, ko nga Weaks anake ka toe
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Tangohia te awhina kaha-ngoikore (kaore e hiahiatia te mahi i tetahi ngoikoretanga ngoikore ki konei-e mohio ana ma etahi atu ngoikore e horoi mo tatou)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ko te pai tenei unsafety no te mea e kī tatou e te atatohu hoki ko te *anake* atatohu e ka tonu kia hoki mai ki a T.
        // Ko ta maatau tatauranga toharite he 1 i tenei waa, ana ko te `Rc<T>` ano kia `mut`, no reira ka whakahokia e maatau te korero mo te tohatoha.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Ngana ki te whakaheke i te `Rc<dyn Any>` ki tetahi momo raima.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Ka tohaina i te `RcBox<T>` me te rahi o te waahi mo te uara o-roto-kore kua oti te whakarite te whakatakotoranga.
    ///
    /// Ko te mahi `mem_to_rcbox` ka karangahia me te tohu ira me te whakahoki ano i te (pea momona)-tohu mo te `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Tatau tatauranga ma te whakatakotoranga uara i hoatu.
        // I mua, tatau tahora i runga i te whakapuaki `&*(ptr as* const RcBox<T>)`, engari hanga tenei he tohutoro hapa, (kite #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Ka tohaina i te `RcBox<T>` me te rahi o te waahi mo te uara o-roto kaore pea-kua oti te whakatakotoranga o te uara, ka whakahoki he he ka he ana te tohatoha.
    ///
    ///
    /// Ko te mahi `mem_to_rcbox` ka karangahia me te tohu ira me te whakahoki ano i te (pea momona)-tohu mo te `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Tatau tatauranga ma te whakatakotoranga uara i hoatu.
        // I mua, tatau tahora i runga i te whakapuaki `&*(ptr as* const RcBox<T>)`, engari hanga tenei he tohutoro hapa, (kite #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Tohaina mo te whakatakotoranga.
        let ptr = allocate(layout)?;

        // Whakauruhia te RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Tukuna he `RcBox<T>` ki rawaka wāhi mo te uara roto unsized
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Tohaina mo te `RcBox<T>` ma te whakamahi i te uara kua whakaritea.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Tārua uara hei paita
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Whakakorea te tohatoha me te kore e makere i nga korero o roto
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Tukuna he `RcBox<[T]>` ki te roa i homai.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Tuhia nga waahanga mai i te waahanga ki te Rc <\[T\]> hou
    ///
    /// Kaore i te haumaru na te mea me tango rangatira te kaiwaea, ka here ranei i te `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Ka hangaia e te `Rc<[T]>` i te iterator mohiotia ki kia o te rahi etahi.
    ///
    /// Kaore i te tautuhia te whanonga mena kua he te rahi.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic kaitiaki i te taera i nga waahanga T.
        // Mena he panic, ko nga waahanga kua oti te tuhituhi ki te RcBox hou ka makere, katahi ka kore te mahara.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Tohu ki te huanga tuatahi
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Maama katoa.Wareware i te kaitiaki kei kore e tukuna te RcBox hou.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Motuhake trait whakamahia mo `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Ka maturuturu te `Rc`.
    ///
    /// Ma tenei ka whakaheke te tatauranga kaha kaha.
    /// Mena ka tae te tatauranga toharite kaha ki te kore ka riro ko etahi atu tohutoro (mena) he [`Weak`], na ko `drop` te uara o roto.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // e kore e tā tetahi
    /// drop(foo2);   // Panui "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // whakangaro i te mea kei roto
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // tangohia te tohu atawhai "strong weak" inaianei kua kore i a maatau nga korero.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Ka hangaia he tohu o te atatohu `Rc`.
    ///
    /// Ka hangaia he tohu ano mo te tohatoha ano, ka piki ake te kaute tohutoro kaha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Ka hangaia he `Rc<T>` hou, me te uara `Default` mo `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack ki te tuku kia motuhake i te `Eq` ahakoa he tikanga to `Eq`.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Kei te mahi maatau i konei, kaore hei whakapai ake i te `&T`, na te mea ka taapirihia he utu ki nga huringa taurite katoa o nga ref.
/// Ki ta maatau ko nga `Rc`s e whakamahia ana hei penapena i nga uara nui, he puhoi ki te tohu, engari he taumaha hoki ki te tirotiro mo te taurite, kia ngawari ake ai te utu o tenei utu.
///
/// Ko te hoki pea atu ki te whai rua iramate `Rc`, e wāhi ki te uara taua, i te rua `&T`s.
///
/// Ka taea e anake te mahi tatou i tenei ka ai kia āta irreflexive `T: Eq` rite te `PartialEq`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Te orite mo te rua `Rc`s.
    ///
    /// He rite E rua `Rc`s ki te he rite ratou uara roto, ara ki te e penapena ratou i roto i te tohanga rerekē.
    ///
    /// Mena ka whakamahia e `T` te `Eq` (e whakaatu ana i te rereketanga o te taurite), e rua nga `Rc` e tohu ana ki te tohatoha kotahi he rite tonu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Te taurite mo te rua 'Rc`.
    ///
    /// E rua nga `Rc` e taurite ana ki te kore e taurite nga uara o roto.
    ///
    /// Mena ka whakamahia e `T` te `Eq` (e whakaatu ana i te rereketanga o te taurite), e rua nga `Rc` e tohu ana ki te tohatoha kotahi kaore e taurite.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Whakataurite waahanga mo nga `Rc` e rua.
    ///
    /// Ka whakatauhia nga mea e rua ma te karanga `partial_cmp()` mo o raatau uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// He iti ake i te whakataurite mo nga `Rc` e rua.
    ///
    /// Ka whakatauhia nga mea e rua ma te karanga `<` mo o raatau uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Iti iho i te rite ranei ki' te whakataurite mo te rua `Rc`s.
    ///
    /// Ka whakatauhia nga mea e rua ma te karanga `<=` mo o raatau uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// He whakataurite nui-atu mo nga `Rc` e rua.
    ///
    /// Ka whakatauhia nga mea e rua ma te karanga `>` mo o raatau uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Nui ake i te orite ranei ki te' whakataurite mo te rua 'Rc`s.
    ///
    /// Ka whakatauhia nga mea e rua ma te karanga `>=` mo o raatau uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Whakataurite mo nga `Rc` e rua.
    ///
    /// Ka whakatauhia nga mea e rua ma te karanga `cmp()` mo o raatau uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Tohaina he waahanga tohutoro-ka tohua ka whakakii ma te tohu i nga taonga o te 'v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Tohaina he poro aho tohua-tohua ka kape `v` ki roto.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Tohaina he poro aho tohua-tohua ka kape `v` ki roto.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Nekehia tetahi ahanoa pouaka ki tetahi mea hou, tohua tohanga, tohatoha.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Tohaina he waahanga tohutoro-ka tohua ka nekehia nga taonga a 'v` ki roto.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Tukua te Vec ki te tuku i tana mahara, engari kaua e whakangaro i nga korero o roto
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Ka mau ki ia waahanga o te `Iterator` ka kohia hei `Rc<[T]>`.
    ///
    /// # Nga ahuatanga mahi
    ///
    /// ## Ko te keehi whanui
    ///
    /// I te keehi noa, ko te kohi ki te `Rc<[T]>` ka oti i te kohinga tuatahi ki te `Vec<T>`.Koinei, i te wa e tuhi ana i nga korero e whai ake nei:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// he rite tenei ki a maatau i tuhi:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ko nga waahanga tuatahi o nga tohatoha ka puta i konei.
    ///     .into(); // Ko te tohatoha tuarua mo `Rc<[T]>` ka tupu i konei.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ka tohatoha tenei rite maha nga wa i rite hiahiatia mō te hanga i te `Vec<T>`, a ka ka tohatoha reira kotahi mo tahuri te `Vec<T>` ki te `Rc<[T]>`.
    ///
    ///
    /// ## Iterator o te roa e mohiotia ana
    ///
    /// Ka whakamahia ana e to `Iterator` te `TrustedLen` a he tino rite te rahi, ka tohaina he tohatoha mo te `Rc<[T]>`.Hei tauira:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Kotahi noa te tohatoha ka tupu i konei.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Whāiti trait whakamahia mō te kohikohi ki `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Koinei te keehi mo te miihini `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Me whakarite e taatau kia rite te roa o te kaitapa, a, kei a tatou ano.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Hoki atu ki te whakatinana noa.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` Ko te putanga o [`Rc`] e mau te tohutoro kore whai-ki te tohanga whakahaere.uru te tohatoha e karanga [`upgrade`] i te atatohu `Weak`, e hoki he [`Option`]`<`[`Rc`] `<T>>`.
///
/// I te mea kaore te tohutanga `Weak` e whai mana ki te rangatira, kaore e aukati i te uara e penapena ana i te tohatoha mai i te whakahekehia, a ko `Weak` ano kaore e kii taurangi mo te uara kei reira tonu.
/// No reira ka hoki pea te [`None`] ka ['whakahou`] d.
/// Kia mahara engari ko te tohutoro `Weak`*ka* aukati i te tohatoha (te toa tautoko) mai i te whakawhitiwhitinga.
///
/// He pai te tohu atawhai `Weak` hei pupuri i tetahi korero poto mo te tohatoha e whakahaerehia ana e [`Rc`] me te kore e aukati i te wariu o roto kia kore e taka.
/// Ka whakamahia hoki hei aukati i nga tohutoro porowhita i waenga i nga tohu tohu [`Rc`], na te mea kaore e tukuna nga tohutoro ki te tuku i te [`Rc`] kia heke iho ranei.
/// Hei tauira, ka taea e te rakau te tohu [`Rc`] tohu kaha mai i nga kopu matua ki nga tamariki, me nga tohu `Weak` mai i nga tamariki ki o raatau maatua.
///
/// Ko te huarahi angitu ki te whiwhi tohu `Weak` ko te waea ki te [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // He `NonNull` tenei hei tuku i te rahi o tenei momo ki roto i nga inumara, engari ehara i te tohu tika hei tohu.
    //
    // `Weak::new` ka tautuhia tenei ki te `usize::MAX` kaore e hiahiatia te tohatoha waahi i runga i te puranga.
    // E kore te he uara ka ake i te tino atatohu no te he tīaroaro i te iti rawa 2 RcBox.
    // Ka taea noa tenei ka `T: Sized`;kore `T` rahinga kore e tiimata.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Ka hangaia he `Weak<T>` hou, me te kore e tohatoha i tetahi mahara.
    /// Ko te karanga i te [`upgrade`] i runga i te uara whakahoki ka homai [`None`] i nga wa katoa.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Patohia te kaiawhina kia uru atu ki nga kaute tohutoro me te kore e kii i nga korero mo te waahanga raraunga.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Whakahokia ai he tohu atawhai ki te ahanoa `T` i tohua e tenei `Weak<T>`.
    ///
    /// Ko te tohu he mana noa mena he kaha nga tohu korero.
    /// kia te atatohu e nao, unaligned ara [`null`] te kore ranei.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // E tohu ana nga mea e rua ki te mea kotahi
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ma te kaha o konei e ora ai, kia uru tonu ai tatou ki taua mea.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Engari kaua atu.
    /// // Ka taea e taatau te weak.as_ptr(), engari ko te uru ki te tohu ka tohu ki te whanonga kore.
    /// // assert_eq! ("hello", haumaru {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Mena kei te piirangi te tohu, ka whakahokia e maatau te kaitiaki.
            // Kaore tenei e taea te noho hei waahi utunga tika, na te mea ko te utunga he rite tonu ki te RcBox (usize).
            ptr as *const T
        } else {
            // SAFETY: mena he teka te whakahoki mai, he kore e tohua te tohu.
            // Ka heke pea te utunga i tenei wa, me mau tonu taatau, na reira whakamahia te raweke tohu tika.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Ka pau te `Weak<T>` ka huri hei tohu tohu noa.
    ///
    /// Ka huri tenei i te atatohu ngoikore hei tohu tika, ahakoa kei te pupuri tonu i te rangatira o tetahi tohutoro ngoikore (kaore te ngoikore e kiia e tenei mahinga).
    /// Ka taea te whakahoki ano ki te `Weak<T>` me te [`from_raw`].
    ///
    /// Ko nga herenga rite mo te uru atu ki te whaainga o te atatohu me te [`as_ptr`] e pa ana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Ka huri i tetahi tohu atawhai ma [`into_raw`] i hangaia i mua hei `Weak<T>`.
    ///
    /// Ka taea te whakamahi kia pai ai te rapu i tetahi korero kaha (ma te waea atu ki te [`upgrade`] a muri ake) ki te whakawhiti ranei i te kaute ngoikore ma te maka i te `Weak<T>`.
    ///
    /// He mana pupuri ki tetahi korero ngoikore (haunga nga tohu tohu i hangaia e [`new`], na te mea kaore enei i a raatau; ka mahi tonu te tikanga ki a raatau).
    ///
    /// # Safety
    ///
    /// I ahu mai te tohu i te [`into_raw`] ana me mau tonu ki tana tohutoro ngoikore pea.
    ///
    /// Ka whakaaetia kia 0 te kaha o te kaute i te wa e waea ana tenei.
    /// Heoi, ko tenei ka mau ki tetahi tohutoro ngoikore e tohuhia ana hei tohu tohu noa (ko te ngoikore ngoikore kaore i te whakarerekehia e tenei mahinga) na reira me hono atu ki te karanga o mua ki te [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Te whakaheke i te tatauranga ngoikore whakamutunga.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Tirohia te Weak::as_ptr mo te horopaki e ahu mai ana te tohu tohu.

        let ptr = if is_dangling(ptr as *mut T) {
            // He ngoikoretanga ngoikore tenei.
            ptr as *mut RcBox<T>
        } else {
            // Te kore, e kī matou ka haere mai te atatohu i te paruparu nondangling.
            // SAFETY: data_offset he pai ki te karanga, na te mea he tohu ptr he tino (kua heke pea) T.
            let offset = unsafe { data_offset(ptr) };
            // Na, ka hurihia e taatau te waahi kia whiwhi katoa ai te RcBox.
            // SAFETY: na te ngoikore i ahu mai te tohu, no reira he ahuru tenei waahanga.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: kua riro mai i a maatau inaianei te tohu pono ngoikore, na reira ka taea te hanga i te Wera.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Ngana ki te whakahou i te tohu `Weak` ki te [`Rc`], ka whakaroa te heke o te uara o roto mena ka angitu.
    ///
    ///
    /// Whakahoki [`None`] mena kua heke te uara o roto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Whakangaromia nga tohu tohu kaha katoa.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Ka whiwhi i nga tohu tohu kaha (`Rc`) e tohu ana ki tenei tohatoha.
    ///
    /// Ki te i hanga `self` te whakamahi i [`Weak::new`], ka hoki mai tenei 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Ka whiwhi i nga tohu tohu `Weak` e tohu ana ki tenei tohatoha.
    ///
    /// Mena kaore e kitea nga tohu kaha, ka hoki kore tenei.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // tangohia te ptr ngoikore whakahua
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Whakahoki ai i te `None` i te wa e piirangi ana te tohu a kaore he `RcBox` tohua, (arā, i te wa i hangaia ai tenei `Weak` e `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Ka tupato taatau kia *kaua* e hanga i tetahi korero e kapi ana i te mara "data", na te mea ka rite tonu te whakarereke o te mara (hei tauira, mena ka taka te `Rc` whakamutunga, ka whakataka te waahanga raraunga ki te waahi).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Whakahoki `true` mena ka tohu nga `Weak` e rua ki te tohatoha kotahi (he rite ki te [`ptr::eq`]), ki te kore ranei e rua e tohu ki tetahi waahanga (na te mea i hangaia me te `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Na te mea ka whakataurite tenei i nga tohu tohu te tikanga ka rite a `Weak::new()` ki a ratau, ahakoa kaore ratau e tohu ki tetahi tohatoha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Te Whakatairite `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Ka maturuturu i te atatohu `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // e kore e tā tetahi
    /// drop(foo);        // Panui "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // ka tiimata te ngoikore ngoikore i te 1, ka haere noa ki te kore mena kua ngaro nga tohu kaha katoa.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Ka hangaia he tohu o te atatohu `Weak` e tohu ana ki te tohatoha kotahi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Ka hangaia he `Weak<T>` hou, ka toha mahara mo te `T` me te kore e arawhiti.
    /// Ko te karanga i te [`upgrade`] i runga i te uara whakahoki ka homai [`None`] i nga wa katoa.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: I tirotirohia_matou ki konei kia pai ai te whakahaere i te mem::forget.Ina koa
// ki te mem::forget Rcs koe (ki te ngoikore ranei), ka taea e te tatau tatau te taapiri, ka taea ai e koe te wewete i te tohatoha i a koe he Rcs tino nui (he ngoikore ranei).
//
// Ka whakatakahia e taatau na te mea he horopaki tino kino tenei kaore matou e aro ki nga mea ka tupu-kaore he tino hotaka e kite i tenei.
//
// Kaore pea tenei e kore e kore e kitea i runga ake na te mea kaore koe e hiahia ki te whakariterite i enei i roto i te Rust na te rangatira me nga nekehanga.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // e hiahia ana matou ki te haukoti i runga i waipuke hei utu o iho i te uara.
        // Kaore e kore te nama tohutoro hei kore ka karangahia tenei;
        // heoi, ka whakauruhia e maatau he waahanga ki konei ki te tohu LLVM ki tetahi aromautanga kaore i tino ngaro.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // e hiahia ana matou ki te haukoti i runga i waipuke hei utu o iho i te uara.
        // Kaore e kore te nama tohutoro hei kore ka karangahia tenei;
        // heoi, ka whakauruhia e maatau he waahanga ki konei ki te tohu LLVM ki tetahi aromautanga kaore i tino ngaro.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Tangohia te utu i roto i te `RcBox` mo nga utunga i muri o te tohu.
///
/// # Safety
///
/// Me tohu te tohu ki (me whai metadata whaimana hoki) he tauira tika o mua o T, engari ka tukuna te T kia heke.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Whakaritehia te uara kua whakarahihia ki te pito o te RcBox.
    // Na te mea ko RcBox te repr(C), ka waiho koinei hei waahi whakamutunga hei whakamahara.
    // SAFETY: mai i nga momo momo kore e taea he poro, trait taonga,
    // me ngā momo extern, he nui tēnei wā ki te makona nga whakaritenga o align_of_val_raw te whakaritenga haumaru tāuru;he taipitopito whakatinana tenei o te reo kaore pea e whirinaki ki waho o te std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}