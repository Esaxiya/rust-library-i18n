//! API tohatoha mahara

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Koinei nga tohu makutu hei karanga i te kaiwhakarato o te ao.Ma te rustc ratou e karanga kia `__rg_alloc` etc.
    // mena he huanga `#[global_allocator]` (ko te waehere whaanui e tohu ana i te tonotono ka hua i era mahi), ki te karanga ranei i nga whakatinana taunoa i roto i te libstd (`__rdl_alloc` etc.
    //
    // i te `library/std/src/alloc.rs`) ka kore.
    // Ko nga rustc fork o LLVM ano hoki-he take motuhake enei ingoa mahi kia ahei ai ratou ki te arotau kia rite ki te `malloc`, `realloc`, me te `free`.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Ko te kaiwhakarato mahara o te ao.
///
/// Ko tenei momo ka whakamahi i te [`Allocator`] trait ma te tuku waea ki te kaiwhakarato kua rehitatia ki te huanga `#[global_allocator]` mena he kotahi, kei te taunoa ranei te `std` crate.
///
///
/// Note: i te wa e kore e pumau tenei momo, ko nga mahi e whakawhiwhia ana e ia, ka uru atu ma te [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Tohaina te maumahara me te kaiwhakawhiwhi o te ao.
///
/// Ka karanga tenei mahi ki mua ki te tikanga [`GlobalAlloc::alloc`] o te kaituku kua rehitatia ki te huanga `#[global_allocator]` mena he kotahi, kei te taunoa ranei te `std` crate.
///
///
/// Ko tenei mahi ka kiia kia kore e manakohia mo te tikanga `alloc` o te momo [`Global`] ka pumau ana me te [`Allocator`] trait.
///
/// # Safety
///
/// Tirohia te [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Whakawhitihia te maumahara ki te kaiwhakarato o te ao.
///
/// Ka karanga tenei mahi ki mua ki te tikanga [`GlobalAlloc::dealloc`] o te kaituku kua rehitatia ki te huanga `#[global_allocator]` mena he kotahi, kei te taunoa ranei te `std` crate.
///
///
/// Ko tenei mahi ka kiia kia kore e manakohia mo te tikanga `dealloc` o te momo [`Global`] ka pumau ana me te [`Allocator`] trait.
///
/// # Safety
///
/// Tirohia te [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Whakakahoretia te maumahara me te kaitoha o te ao.
///
/// Ka karanga tenei mahi ki mua ki te tikanga [`GlobalAlloc::realloc`] o te kaituku kua rehitatia ki te huanga `#[global_allocator]` mena he kotahi, kei te taunoa ranei te `std` crate.
///
///
/// Ko tenei mahi ka kiia kia kore e manakohia mo te tikanga `realloc` o te momo [`Global`] ka pumau ana me te [`Allocator`] trait.
///
/// # Safety
///
/// Tirohia te [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Tohaina i te mahara kore-tiimata me te kaiwhakawhiwhi o te ao.
///
/// Ka karanga tenei mahi ki mua ki te tikanga [`GlobalAlloc::alloc_zeroed`] o te kaituku kua rehitatia ki te huanga `#[global_allocator]` mena he kotahi, kei te taunoa ranei te `std` crate.
///
///
/// Ko tenei mahi ka kiia kia kore e manakohia mo te tikanga `alloc_zeroed` o te momo [`Global`] ka pumau ana me te [`Allocator`] trait.
///
/// # Safety
///
/// Tirohia te [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // SAFETY: `layout` he kore-kore te rahi,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // SAFETY: He rite ki te `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // SAFETY: `new_size` he kore-kore i te mea ko te `old_size` nui ake i te rite ranei ki te `new_size`
            // e hiahiatia ana ma nga tikanga ahuru.Ko etahi atu tikanga me whakatuturu e te kaiwaea
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` pea tirohia nga `new_size >= old_layout.size()` ranei tetahi mea rite.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SAFETY: na te mea ko te `new_layout.size()` me nui ake ki te `old_size` ranei,
            // e rua nga waahanga tawhito me nga waahanga hou e whai kiko ana mo te panui me te tuhi mo te `old_size` paita.
            // Ano hoki, na te mea kaore ano kia tohatohahia te toha tawhito, kaore e taea te taupoki i te `new_ptr`.
            // Na, ko te piiraa ki `copy_nonoverlapping` he ahuru.
            // Ko te kirimana ahuru mo te `dealloc` me tautoko e te kaiwaea.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // SAFETY: `layout` he kore-kore te rahi,
            // etahi atu tikanga me mau e te kaiwaea
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: ko nga tikanga katoa me tautoko e te kaiwaea
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: ko nga tikanga katoa me tautoko e te kaiwaea
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // SAFETY: me mau nga tikanga ki te kaiwaea
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // SAFETY: `new_size` he kore-kore.Ko etahi atu tikanga me whakatuturu e te kaiwaea
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` pea tirohia nga `new_size <= old_layout.size()` ranei tetahi mea rite.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SAFETY: na te mea ko te `new_size` me iti ake i te orite ki te `old_layout.size()`,
            // e rua nga waahanga tawhito me nga waahanga hou e whai kiko ana mo te panui me te tuhi mo te `new_size` paita.
            // Ano hoki, na te mea kaore ano kia tohatohahia te toha tawhito, kaore e taea te taupoki i te `new_ptr`.
            // Na, ko te piiraa ki `copy_nonoverlapping` he ahuru.
            // Ko te kirimana ahuru mo te `dealloc` me tautoko e te kaiwaea.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Ko te kaiwhakarato mo nga tohu tohu ahurei.
// Kaua tenei mahi e whakaweto.Mena ka peera, ka kore te MIR codegen.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Ko tenei hainatanga me rite ki te `Box`, mena ka puta he ICE.
// Ka tapiritia he taapiri taapiri ki te `Box` (penei i te `A: Allocator`), me tapiri ano hoki tenei ki konei.
// Hei tauira mena ka hurihia te `Box` ki te `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, me huri ano tenei mahi ki te `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` hoki.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Kaitoha hapa tohatoha

extern "Rust" {
    // Koinei te tohu makutu ki te karanga i te kaiutu hapa hapa o te ao.
    // Ma te rustc e waea atu ki te `__rg_oom` mena he `#[alloc_error_handler]`, ki te waea ranei i nga whakatinanatanga taunoa i raro ake nei i te (`__rdl_oom`).
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Whakakorea i runga i te hapa tohatoha mahara kaore i tutuki.
///
/// Ko nga Kaitono o nga API tohatoha mahara e hiahia ana ki te whakakore i te tatauranga hei whakautu ki te hapa tohatoha ka whakatenatena kia waea atu ki tenei mahi, kaua ki te karanga tika ki te `panic!` me nga mea pera ranei.
///
///
/// Ko te whanonga taunoa o tenei mahi ko te taarua i tetahi korero ki te hapa paerewa me te whakakore i te mahi.
/// Ka taea te whakakapi me [`set_alloc_error_hook`] me [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Mo te whakamatautau toha `std::alloc::handle_alloc_error` ka taea te whakamahi tika.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // i karangahia ma te `__rust_alloc_error_handler` i hangaia

    // mena kaore he `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // mena he `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Whakamahia nga taera ki roto i te waahanga kua tohatohahia, hei whakamaharatanga kore.
/// Whakamahia e `Box::clone` me `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Ka tohatohahia *tuatahi* ka ahei te kaitautoko ki te waihanga i te uara oona ki te waahi, ka peke i te rohe ka neke.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Ka taea e taatau te kape i nga waahi katoa, me te kore e uru ki te uara o te rohe.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}