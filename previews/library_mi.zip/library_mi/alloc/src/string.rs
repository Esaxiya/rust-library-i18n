//! He UTF-8 - he whakawaehere, he miro whakatipu.
//!
//! Kei roto i tenei waahanga te momo [`String`], te [`ToString`] trait mo te huri ki nga aho, me etahi momo hapa ka hua mai i te mahi me [`String`] s.
//!
//!
//! # Examples
//!
//! He huarahi maha ki te waihanga i tētahi [`String`] hou i te mau string:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Ka taea e koe te hanga [`String`] hou mai i tera waa ma te whakakotahi ki
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Mena he vector o nga paita UTF-8 whaimana, ka taea e koe te hanga [`String`] mai i taua mea.Ka taea e te mahi koe i te tahatua rawa.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // E mohio ana matou he tika enei paita, no reira ka whakamahia e matou te `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// He UTF-8 - he whakawaehere, he miro whakatipu.
///
/// Ko te momo `String` ko te momo aho noa e whai mana ana ki nga mea o te aho.He tata te whanaungatanga me te hoa nama i tonoa, te [`str`] tuatahi.
///
/// # Examples
///
/// Ka taea e koe te hanga `String` mai i [a literal string][`str`] me [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Ka taea e koe te taapiri i te [`char`] ki te `String` me te tikanga [`push`], me te taapiri i te [`&str`] me te tikanga [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Mena he vector o UTF-8 paita koe, ka taea e koe te hanga `String` mai i a ia me te tikanga [`from_utf8`]:
///
/// ```
/// // etahi paita, i roto i te vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // E mohio ana matou he tika enei paita, no reira ka whakamahia e matou te `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Ko nga `aho` e whai mana tonu ana UTF-8.He paku nei nga raru, ko te tuatahi mena ka hiahia koe ki te aho kore-UTF-8, whakaarohia te [`OsString`].He rite, engari kaore he aukati UTF-8.Ko te tohu tuarua ko te kore e taea e koe te whakauru ki te `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Ko te Tauputanga he kaupapa mahi-tonu, engari ko te whakawaehere UTF-8 kaore e ahei ki a maatau ki te mahi i tenei.I tua atu, e kore te ūkui i te reira te mea ahua o te mea e hoki mai i te taupū: he paita, he codepoint, he kāhui grapheme ranei.
/// Ko nga tikanga [`bytes`] me [`chars`] e whakahoki ana i nga kaitarai mo nga mea tuatahi e rua.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s whakatinana [`Deref`] `<Target=str>`, A na te whakarerenga iho mo te katoa o [`str`] 'o tikanga.Hei taapiri, ko te tikanga ka taea e koe te tuku i te `String` ki tetahi mahi ka mutu te [`&str`] ma te whakamahi i te ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Tenei ka hanga he [`&str`] i te `String`, a haere i te reira i roto i. Ko te tino ngāwari tenei faafariuraa, a pera te tikanga, ka manako mahi [`&str`] s rite tohenga te kore hiahia ratou he `String` mo etahi take motuhake.
///
/// I etahi waa kaore i te nui nga korero a te Rust kia huri ai tenei, e mohiotia ana ko te [`Deref`] akiaki.I roto i te tauira e whai ake nei i te wāhanga string [`&'a str`][`&str`] whakatinana te trait `TraitExample`, a e tetahi te mahi `example_func` e ngā te trait.
/// I tenei ka hiahia a Rust ki te huri i nga rereketanga e rua, kaore nei a Rust e whai kiko.
/// Mo taua take, ko te tauira e whai ake nei kaore e whakahiato.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// E rua nga waahanga ka pai hei mahi.Ko te mea tuatahi ko te huri i te raina `example_func(&example_string);` ki te `example_func(example_string.as_str());`, ma te whakamahi i te tikanga [`as_str()`] ki te tango maarama i nga poro o te aho kei roto i te aho.
/// Ko te huarahi tuarua ka huri i te `example_func(&example_string);` ki te `example_func(&*example_string);`.
/// I roto i tenei take e ingoakē tatou he `String` ki te [`str`][`&str`], ka tohutoro te hoki [`str`][`&str`] ki [`&str`].
/// Ko te huarahi tuarua he pai ake te korero, heoi ka mahi ngatahi ki te whakarereke i te hurahuri kaua ki te whakawhirinaki ki te hurihanga kapi.
///
/// # Representation
///
/// E toru nga waahanga o te `String`: he tohu ki etahi paita, he roa, me te kaha.Ka tohu te tohu ki tetahi buffer o roto X01 e whakamahia ana hei penapena i ana raraunga.Ko te roa ko te maha o ngā paita rongoa tēnei wā i roto i te moka, me te kaha, ko te rahi o te moka i roto i paita.
///
/// I penei, ko te roa ka iti ake i te orite ki te kaha ranei.
///
/// Kei te penapena tenei peera i runga i te puranga.
///
/// Ka taea e koe te titiro ki enei me nga tikanga [`as_ptr`], [`len`], me [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Whakahoutia tenei ka whakaū ana te vector_into_raw_parts.
/// // Aukati i te maturuturu iho o nga korero a te aho
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // E iwa paita kōrero
/// assert_eq!(19, len);
///
/// // Ka taea e taatau te hanga ano i te aho mai i te ptr, len, me te kaha.
/// // He haumaru katoa tenei na te mea kei a tatou te kawenga kia tino tika nga waahanga:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ki te mea he `String` nui kaha, tāpiri huānga ki reira e kore-tohatoha anō.Hei tauira, whakaarohia tenei kaupapa:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Ka whakaputaina tenei e whai ake nei:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// I te tuatahi, kaore o maatau mahara i tohatohahia, engari i te mea e hono atu ana matou ki te aho, ka whakanekehia ake tona kaha.Ki te tatou te whakamahi hei utu te tikanga [`with_capacity`] ki te tohatoha i te kaha tika te tīmatanga:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Ka mutu he rereke taatau putanga:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// I konei, kaore he take o te toha atu i nga mahara ki roto i te koropiko.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// He uara hapa pea ka huri i te `String` mai i te UTF-8 byte vector.
///
/// Ko tenei momo ko te momo he mo te [`from_utf8`] tikanga i [`String`].
/// I hoahoahia kia pai ai te karo i nga waahi tuuturu: ko te tikanga [`into_bytes`] ka whakahoki i te paita vector i whakamahia i te nganatanga hurihanga.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Ko te momo [`Utf8Error`] i whakawhiwhia mai e [`std::str`] he tohu he hapa ka puta mai ka huri ana koe i te poro o [`u8`] s ki te [`&str`].
/// I runga i tenei, he tairitenga ki te `FromUtf8Error`, ana ka taea e koe te tiki i tetahi mai i te `FromUtf8Error` ma te tikanga [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// // etahi paita muhu, i te vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// He uara hapa pea ka huri i te `String` mai i te poro paita UTF-16.
///
/// Ko tenei momo ko te momo he mo te [`from_utf16`] tikanga i [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Whakamahi taketake:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Ka waihanga i te `String` kau kau.
    ///
    /// I te mea he koretake te `String`, kaore tenei e tohatoha i tetahi buffer tuatahi.Ahakoa e tikanga e ko te tino ngāwari tenei mahi tuatahi, kia meinga ai tohatoha nui i muri, ka tāpiri koe raraunga.
    ///
    /// Mena he whakaaro koe mo te nui o nga raraunga ka purihia e te `String`, whakaarohia te tikanga [`with_capacity`] kia kore ai e tohatoha rawa.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Ka waihangahia he `String` kau hou me te tino kaha.
    ///
    /// He aho a-roto ta te String` hei pupuri i a raatau raraunga.
    /// Ko te kaha ko te roa o taua buffer, ana ka taea te patapatai me te tikanga [`capacity`].
    /// hanga i tēnei aratuka he kau `String`, engari kotahi ki te moka tuatahi e taea te pupuri `capacity` paita.
    /// He pai tenei ina kei te tapiri koe i nga tini korero ki te `String`, ka whakaheke i te maha o nga waahanga tuuturu me mahi e ia.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Ki te ko te kaha homai `0`, ka puta kore tohatoha, me he ōrite ki te tikanga [`new`] tenei tikanga.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Kaore he mahi a te String, ahakoa he kaha ake mo etahi atu
    /// assert_eq!(s.len(), 0);
    ///
    /// // Ka oti enei katoa kaore he whakawhitinga ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... engari ma tenei pea ka huri te aho
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): ki cfg(test) te tikanga `[T]::to_vec` tūturu, e hiahiatia ana e te mo tenei whakamāramatanga tikanga e kore he wātea,.
    // Mai kore matou e rapua e tenei tikanga mo te whakamatautau take, ka Poro noa ahau NB kite reira te kōwae slice::hack i slice.rs mō ētahi atu mōhiohio
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Ka huri i te vector o nga paita ki te `String`.
    ///
    /// Ko te aho ([`String`]) he paita ([`u8`]), a ko te vector o nga paita ([`Vec<u8>`]) he paita, no reira ka huri tenei mahi i waenga i nga mea e rua.
    /// Ehara ko nga poroatanga paita katoa e whai mana ana `String`s, heoi: `String` me tika te UTF-8.
    /// `from_utf8()` arowhai ki te whakarite kia te paita e tika UTF-8, a ka mahi i te faafariuraa.
    ///
    /// Mena e mohio ana koe he tika te poro byte UTF-8, ana kaore koe e hiahia kia kaha ake te tirotiro o te haki tika, he putanga kore mo tenei mahi, [`from_utf8_unchecked`], he peera ano ona ahua engari ka pekehia te haki.
    ///
    ///
    /// Ma tenei tikanga e tupato kei kape te vector, hei painga maana.
    ///
    /// Mena e hiahia ana koe ki te [`&str`] kaore i te `String`, whakaarohia te [`str::from_utf8`].
    ///
    /// Ko te huringa o tenei tikanga ko te [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Whakahokia [`Err`] ki te kahore te mea te wāhanga UTF-8 ki te whakamārama rite ki te aha e kore e nga paita whakaratohia UTF-8.Ko te vector oho koutou i roto i te ngā ano.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // etahi paita, i roto i te vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // E mohio ana matou he tika enei paita, no reira ka whakamahia e matou te `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Paita hē:
    ///
    /// ```
    /// // etahi paita muhu, i te vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Tirohia nga tuhinga mo [`FromUtf8Error`] mo nga korero taipitopito mo nga mea ka taea e koe ki tenei hapa.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Tahuri ai i te poro paita ki te aho, tae atu ki nga kiripuaki koretake.
    ///
    /// Ko nga aho na te paita ([`u8`]), a ko te poro byte ([`&[u8]`][byteslice]) he paita, no reira ka huri tenei mahi ki waenga i nga mea e rua.Ehara ko nga poro paita katoa he aho tika, heoi: ko nga aho e tika ana kia tika te UTF-8.
    /// I tenei hurihanga, `from_utf8_lossy()` ka whakakapi i nga rarangi UTF-8 muhu ki te [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], e penei ana:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Mena ka mohio koe he tika te poro byte UTF-8, ana kaore koe e hiahia ki te whakarake i te hurihanga, kei kona tetahi momo putanga kore, [`from_utf8_unchecked`], he rite tonu tana whanonga engari ka pekehia nga haki.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Ko tenei mahi ka whakahoki i te [`Cow<'a, str>`].Mena he muhu to taatau poroini paanui UTF-8, me matua whakauru e tatou nga kiripuaki whakakapi, ka huri i te rahi o te aho, no reira me `String`.
    /// Engari mena kua mana te UTF-8, kaore e hiahiatia he waahanga hou.
    /// Ma tenei momo whakahoki ka taea e maatau te whakahaere i nga keehi e rua.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // etahi paita, i roto i te vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Paita hē:
    ///
    /// ```
    /// // etahi paita muhu
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Whakakorea te UTF-16 - whakawaeheretia te vector `v` ki roto i te `String`, me te whakahoki i te [`Err`] mena kei te `v` nga kupu he.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Kaore tenei e mahia ma te kohinga: : <Result<_, _>> () mo nga take mahi.
        // FIXME: ka taea te whakahou i te mahi ka kati ana te #48994.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Tuhia te UTF-16 - whakawaeheretia te poro `v` ki roto i te `String`, hei whakakapi i nga raraunga he ki te [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Kaore i te [`from_utf8_lossy`] e whakahoki ana i te [`Cow<'a, str>`], `from_utf16_lossy` e whakahoki ana i te `String` mai i te hurihanga UTF-16 ki UTF-8 me wehe te mahara.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Ka hurihia te `String` ki roto i ona waahanga hou.
    ///
    /// Whakahoki ai i te tohu tika ki nga raraunga e whaaia ana, te roa o te aho (i nga paita), me te kaha tohaina o nga raraunga (i nga paita).
    /// He rite ano nga tohenga tautohe i roto i te ota rite ki nga tohenga ki [`from_raw_parts`].
    ///
    /// I muri i te karanga i tenei mahi, ma te kaikaranga te kawenga mo te mahara i whakahaere i mua e te `String`.
    /// Ko te huarahi anake ki te mahi tenei ko te huri i te tohu tika, te roa, me te kaha ki roto ano i te `String` me te mahi [`from_raw_parts`], kia taea ai e te kaipahua te mahi horoi.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Ka hangaia he `String` hou mai i te roa, te kaha me te tohu.
    ///
    /// # Safety
    ///
    /// He tino haumaru tenei, na te maha o nga kaitaunui kaore i te tirotirohia:
    ///
    /// * Ko te maharatanga ki te `buf` me matua tohaina e te kaitoha kotahi e whakamahia ana e te wharepukapuka paerewa, me te whakahoutanga e hiahiatia ana kia rite ki te 1.
    /// * `length` hiahia ki te kia iti iho i te ranei rite ki `capacity`.
    /// * `capacity` me tika te uara.
    /// * Ko nga paita `length` tuatahi i te `buf` me tika kia UTF-8.
    ///
    /// Ko te takahi i enei ka raru pea ka kino ki nga hanganga raraunga a roto o te kaitapa.
    ///
    /// Ko te rangatira o `buf` ka whakawhiti pai ki te `String` ka huri pea, ka huri, ka huri ranei i nga tuhinga o te mahara i tohua e te tohu ki tana e hiahia ana.
    /// Kia mahara kia kore tetahi atu e whakamahi i te tohu i muri i te karanga i tenei mahi.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Whakahoutia tenei ka whakaū ana te vector_into_raw_parts.
    ///     // Aukati i te maturuturu iho o nga korero a te aho
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Ka huri i te vector o nga paita ki te `String` me te kore e tohu he UTF-8 te aho o te aho.
    ///
    /// Tirohia te putanga ahuru, [`from_utf8`], mo nga korero taipitopito.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Ko tenei mahi kaore i te ahuru na te mea kaore e tirohia mena nga paita i tukuna ki a ia he tika UTF-8.
    /// Mena kua takahia tenei herenga, ka raru pea nga mahara ki nga kaiwhakamahi future o te `String`, na te toenga o te wharepukapuka paerewa e kii ana he tika te UTF-8 o te aho.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // etahi paita, i roto i te vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Ka huri i te `String` ki te paita vector.
    ///
    /// Ka pau tenei i te `String`, na reira kaore e hiahia ki te kape i nga korero o roto.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Ka tangohia he poro aho e mau ana te `String` katoa.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Ka huri i te `String` ki te poro aho whakarereke.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Ka honoa tetahi waahanga aho ki te pito o tenei `String`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Whakahoki ai i te kaha o tenei `String`, i roto i te paita.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Kia maarama ko te kaha o tenei `String` he iti rawa te `additional` paita neke atu i te roa.
    ///
    /// Ka piki ake pea te kaha ma te nui ake i te `additional` paita mena e hiahia ana ia, ki te aukati i nga whakawhitinga tuuturu.
    ///
    ///
    /// Mena kaore koe e hiahia ki tenei whanonga "at least", tirohia te tikanga [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics ki te ngawha te kaha hou [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Kaore pea tenei e whakanui ake i te kaha:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s inaianei he roa te 2 me te kaha 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // I te mea kua nui atu taatau 8 kaha, e karanga ana ki tenei ...
    /// s.reserve(8);
    ///
    /// // ... e kore e tino piki ake.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// He whakarite kia `additional` paita te kaha o tenei Strtaha` i te roa.
    ///
    /// Whakaarohia te whakamahi i te tikanga [`reserve`] ki te kore koe e tino mohio atu i te kaitoha.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics mena ka kaha te kaha o te `usize`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Kaore pea tenei e whakanui ake i te kaha:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s inaianei he roa te 2 me te kaha 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // I te mea kua nui atu taatau 8 kaha, e karanga ana ki tenei ...
    /// s.reserve_exact(8);
    ///
    /// // ... e kore e tino piki ake.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Ka ngana ki te rahui i te kaha mo te iti rawa atu o te `additional` atu waahanga hei whakauru ki te `String` i homai.
    /// Ka rahuitia pea e te kohinga etahi atu waahanga hei karo i nga waahi tuuturu.
    /// I muri i te karanga `reserve`, ka nui ake te kaha ki te rite ranei ki te `self.len() + additional`.
    /// Kaore tetahi mea mena kua tau te kaha.
    ///
    /// # Errors
    ///
    /// Mena ka kaha te kaha, ka ripoatatia ranei e te kaitoha he koretake, ka hoki mai ano he he.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Puritia te maumahara, ka puta ki te kore e taea
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Inaianei kua mohio taatau kaore e taea te OOM i waenga o a maatau mahi uaua
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Ka ngana ki te rahui i te kaha iti mo te tino `additional` etahi atu waahanga hei whakauru ki te `String` kua homai.
    ///
    /// I muri i te karanga `reserve_exact`, ka nui ake te kaha ki te rite ranei ki te `self.len() + additional`.
    /// Kaore he mea mena kua ea te kaha.
    ///
    /// Kia mahara ma te Kaitoha e tuku atu ki te kohinga te nui ake o te waa i runga i ta te tono.
    /// Na reira, kaore e taea te whakawhirinaki ki te kaha kia iti rawa.
    /// He pai te `reserve` mena e tatari ana kia whakauruhia a future.
    ///
    /// # Errors
    ///
    /// Mena ka kaha te kaha, ka ripoatatia ranei e te kaitoha he koretake, ka hoki mai ano he he.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Puritia te maumahara, ka puta ki te kore e taea
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Inaianei kua mohio taatau kaore e taea te OOM i waenga o a maatau mahi uaua
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Tīngongo ki te kaha o tenei `String` ōrite tona roa.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Ka tiitihia te kaha o tenei `String` me te roopu o raro.
    ///
    /// Ko te kaha ka noho ko te iti rawa pea te roa me te uara kua tohaina.
    ///
    ///
    /// Mena he iti ake te kaha o naianei i te rohe o raro, he-kore tenei.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Ka honoa te [`char`] kua tohaina ki te mutunga o tenei `String`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Whakahoki ai i te poro paita o te tuhinga nei o te `aho '.
    ///
    /// Ko te huringa o tenei tikanga ko te [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Ka poroa tenei `String` ki te roa kua whakaritea.
    ///
    /// Mena he nui ake te `new_len` i te roa o te aho i tenei wa, kaore he painga.
    ///
    ///
    /// Kia mōhio e tenei tikanga e kore pānga i runga i te kaha tohaina o te aho
    ///
    /// # Panics
    ///
    /// Panics ki te kore a `new_len` e takoto i runga i te rohe [`char`].
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Tango ai i te kiripuaki whakamutunga mai i te paapene aho ka whakahokia mai.
    ///
    /// Whakahokia ai te [`None`] mena he putu te `String` nei.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Ka tangohia he [`char`] mai i tenei `String` i te waahi pauna ka whakahoki mai.
    ///
    /// He mahinga *O*(*n*) tenei, na te mea me kape i nga waahanga katoa o te buffer.
    ///
    /// # Panics
    ///
    /// Panics mena he nui ake te `idx` i te orite ranei ki te roa o te `String`, ki te kore ranei e takoto i te rohe [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Tangohia nga whakataetae katoa o te tauira `pat` i te `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Ka kia kitea ngā kēmu, ka nekehia atu iteratively, na i roto i te wā i reira īnaki tauira, ka te tauira tuatahi anake ka nekehia atu:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SAFETY: ko te tiimata me te mutunga ka pa ki nga rohe paita utf8 mo ia
        // nga tuhinga Searcher
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Ko nga tohu anake i tohua e te matapae.
    ///
    /// I etahi atu kupu, tangohia katoa nga tohu `c` penei ka whakahokia mai e `f(c)` te `false`.
    /// Kei te whakahaerehia tenei tikanga i tona waahi, ka toro atu ki ia taangata kia rite tonu i te raupapa taketake, ka tiakina te raupapa o nga tohu pupuri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// He pai pea te ota tika mo te whai i te ahua o waho, peera i te taurangi.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Tohu idx ki te char ka whai ake
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Whakauruhia he tohu ki tenei `String` i te waahi paita.
    ///
    /// He mahinga *O*(*n*) tenei na te mea me kape i nga waahanga katoa o te buffer.
    ///
    /// # Panics
    ///
    /// Panics mena he nui ake te `idx` i te roa o te `aho ', ki te kore ranei e takoto i te rohe [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Whakauruhia he poro aho ki roto i tenei `String` i te waahi paita.
    ///
    /// He mahinga *O*(*n*) tenei na te mea me kape i nga waahanga katoa o te buffer.
    ///
    /// # Panics
    ///
    /// Panics mena he nui ake te `idx` i te roa o te `aho ', ki te kore ranei e takoto i te rohe [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Whakahokia ai he korero whakarereke mo nga korero o tenei `String`.
    ///
    /// # Safety
    ///
    /// Ko tenei mahi kaore i te ahuru na te mea kaore e tirohia mena nga paita i tukuna ki a ia he tika UTF-8.
    /// Mena kua takahia tenei herenga, ka raru pea nga mahara ki nga kaiwhakamahi future o te `String`, na te toenga o te wharepukapuka paerewa e kii ana he tika te UTF-8 o te aho.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Whakahoki ai i te roa o tenei `String`, i roto i nga paita, kaua ki te [`char`] s, ki nga karepe ranei.
    /// I etahi atu kupu, akene kaore pea ko te mea ka whakaarohia e te tangata te roa o te aho.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Whakahoki ai i te `true` mena he roa te kore o tenei `String`, a he kore ke te `false`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Whakawehe te aho ki e rua i te taupū paita homai.
    ///
    /// Whakahoki ai i te `String` hou kua tohaina.
    /// `self` he paita `[0, at)`, a ko te `String` i hoki mai he paita `[at, len)`.
    /// `at` me noho ki te rohe o te tohu waehere UTF-8.
    ///
    /// Kia mahara kaore e rereke te kaha o `self`.
    ///
    /// # Panics
    ///
    /// Panics ki te kahore te mea `at` i runga i te rohe pūwāhi `UTF-8` waehere, ranei ki te he te reira tua atu te wāhi waehere whakamutunga o te aho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Ka tapahia tenei `String`, ka tango i nga korero katoa.
    ///
    /// Ahakoa ko te tikanga ka roa te kore o te `String`, kaore e pa ki tona kaha.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Ka waihangahia he miihini whakaheke e tango ana i te awhe kua tohua i te `String` ka whakaputa i te `chars` kua tangohia.
    ///
    ///
    /// Note: nekehia atu te whānuitanga huānga te ara, ki te kore e pau te iterator noa te mutunga.
    ///
    /// # Panics
    ///
    /// Panics mena kaore te timatanga me te pito mutunga e takoto i te rohe [`char`], mena kei waho o nga rohe.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Tangohia te awhe tae atu ki te β mai i te aho
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Ma te whanui tonu e muru te aho
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Haumaru Mahara
        //
        // Ko te putanga aho o te Drain kaore i a raatau nga take haumaru ahuru o te putanga vector.
        // He paita noa te raraunga.
        // Na te mea ka puta te tangohanga awhe i Drop, mena ka puta te tohu a te Drain, kaore te tangohanga e puta.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Tangohia nga nama e rua i te wa kotahi.
        // e kore e te uru te &mut Aho tae noa ko runga whitiauau, i Taka.
        let self_ptr = self as *mut _;
        // SAFETY: `slice::range` me `is_char_boundary` mahi i nga huringa rohe tika.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Ka tangohia te awhe kua tohua ki te aho, ka whakakapihia ki te aho kua hoatu.
    /// Ko te aho kua hoatu kaua e rite te roa ki te awhe.
    ///
    /// # Panics
    ///
    /// Panics mena kaore te timatanga me te pito mutunga e takoto i te rohe [`char`], mena kei waho o nga rohe.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Whakakapihia te awhe kia tae ra ano ki te β mai i te aho
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Haumaru Mahara
        //
        // Ko te Change_range kaore i a ia nga take haumaru maumahara o te vector Splice.
        // o te putanga vector.He paita noa te raraunga.

        // WHAKAT InPATO: Ko te whakauru i tenei taurangi he koretake te (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // WHAKAT InPATO: Ko te whakauru i tenei taurangi he koretake te (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Ma te whakamahi i te `range` kaore e raru (#81138) Ki ta maatau ko nga rohe i whakapaehia e `range` he rite tonu, engari ka taea te whakarereke i te whakahee i waenga i nga piiraa.
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Ka hurihia tenei `String` ki te [`Pouaka`]`<`[`str`] `> '.
    ///
    /// Ma tenei ka maturuturu te nui o te kaha.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Whakahokia ai he poro o te paita [`u8`] s i ngana ki te huri ki te `String`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // etahi paita muhu, i te vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Whakahokia ai nga paita i ngana ki te huri ki te `String`.
    ///
    /// He mea hanga tenei tikanga kia kore ai e tohatoha.
    /// Ka pau i te hapa, ka neke atu nga paita, kia kore e hiahiatia he kape o nga paita.
    ///
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // etahi paita muhu, i te vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Kohia he `Utf8Error` hei tiki taipitopito mo te ngoikoretanga o te huringa.
    ///
    /// Ko te momo [`Utf8Error`] i whakawhiwhia mai e [`std::str`] he tohu he hapa ka puta mai ka huri ana koe i te poro o [`u8`] s ki te [`&str`].
    /// I runga i tenei, he whakarite ki te `FromUtf8Error`.
    /// Tirohia ona tuhinga mo etahi atu taipitopito mo te whakamahi.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// // etahi paita muhu, i te vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ko te paita tuatahi kaore i te tika i konei
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Na te mea e taatai ana matou i te `String`s, ka taea e taatau te karo i tetahi waahanga ma te tango i te aho tuatahi mai i te miihini me te taapiri ki nga aho e whai ake nei.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Na te mea kei te tirotirohia e maatau nga CoWs, ka taea e (potentially) te karo i te waahanga kotahi ma te tango i te taonga tuatahi me te taapiri atu ki nga mea katoa e whai ake nei.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// He taputapu ngawari e tohaina ana ki te kaupapa mo `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Ka waihanga i te `String` kau.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Whakatinana te operator `+` mō te concatenating rua aho.
///
/// Ka pau tenei i te `String` i te taha maui ka whakamahi ano i tana peera (whakatipu mena e tika ana).
/// Ka mahia tenei hei karo i te tohatoha i tetahi `String` hou me te kape i nga korero katoa o ia mahinga, ka tae atu ki te *O*(*n*^ 2) te waa e haere ana ka hanga i tetahi aho *n*-teita ma te whakahua i nga wa katoa.
///
///
/// Ko te aho kei te taha katau kei te nama noa;ko nga mea o roto ka kape ki te `String` kua whakahokia.
///
/// # Examples
///
/// Ko te whakahua i nga `aho e rua ka mau ki te tuatahi ma te uara ka nama i te tuarua.
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` Kei te oho a taea kore te whakamahi i konei.
/// ```
///
/// Mena kei te hiahia koe ki te whakamahi i te `String` tuatahi, ka taea e koe te taatai ka taapiri atu ki te kaute.
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` he mana tonu kei konei.
/// ```
///
/// Ka taea te whakaoti i nga poro `&str` ma te huri i te tuatahi ki te `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Ka whakatinanahia te kaiwhakahaere `+=` mo te taapiri ki te `String`.
///
/// He rite ano te whanonga ki te tikanga [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// He momo ingoa alias mo [`Infallible`].
///
/// tīariari ana tēnei ingoakē mō whakamuri hototahi, a kia hopea tauwhāitihia ai.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// He trait mo te huri i tetahi uara ki te `String`.
///
/// Ko tenei trait ka whakatinanahia aunoatia mo tetahi momo e whakamahi ana i te [`Display`] trait.
/// I penei, `ToString` kaua e whakatinana tika:
/// [`Display`] kia kia whakatinana hei utu, a ka whiwhi koutou i te whakatinanatanga `ToString` mō te kore utu.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Ka huri i te uara kua tohaina ki te `String`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// I roto i tenei whakatinanatanga, te `to_string` aratuka panics ki te hoki te whakatinanatanga `Display` he hapa.
/// tohu tenei he whakatinanatanga hē `Display` mai kore `fmt::Write for String` hoki he hapa iho.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // He aratohu noa kia kaua e whakahuahua i nga mahi whanui.
    // Heoi, te tango i `#[inline]` i tenei tikanga ai regressions kore-iti.
    // Tirohia te <https://github.com/rust-lang/rust/pull/74852>, ko te nganatanga whakamutunga ki te tarai ki te tango.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Tahuri ai te `&mut str` ki te `String`.
    ///
    /// Ko te hua ka tohaina ki runga ki te puranga.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: faaho'i whakamātautau i roto i te libstd, e ai hapa konei
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Ka huri i te waahanga `str` pouaka ki te `String`.
    /// He mea nui kei te puritia te poro `str`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Ka huri i te `String` kua tohaina ki te poro `str` pouaka e mau ana.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Tahuri ai i te poro aho ki roto i te momo Mono.
    /// Kei te whakamana No tohatoha puranga, a kahore te te aho tārua.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Ka huri i te aho hei momo rangatira.
    /// Kei te whakamana No tohatoha puranga, a kahore te te aho tārua.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Ka huri i te tohutoro aho ki te momo Borrowed.
    /// Kei te whakamana No tohatoha puranga, a kahore te te aho tārua.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Tahuri ai te hoatu `String` ki te `Vec` vector e mau uara o momo `u8`.
    ///
    /// # Examples
    ///
    /// Whakamahi taketake:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// He miihini whakaheke mo `String`.
///
/// Ko tenei hanganga i hangaia e te tikanga [`drain`] i te [`String`].
/// Tirohia ona tuhinga mo te roanga atu.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Ka whakamahia hei&'a mut String i roto i te kaihurihuri
    string: *mut String,
    /// Te tiimata o te waahanga hei tango
    start: usize,
    /// Te mutunga o te waahanga hei tango
    end: usize,
    /// Ko te toenga e toe ana hei tango
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Whakamahia te Vec::drain.
            // "Reaffirm" te arowhai rohe ki te karo i panic waehere e whakaurua ano.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Whakahoki ai i te toenga (raarangi) aho o tenei miihini hei poro.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: ngoikore AsRef impls i raro ka pumau.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Te ngoikoretanga i te wa e whakapumau ana i te `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>mo Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> mo Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}