#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Ko nga korero o te maumahara hou kaore i te whakauruhia.
    Uninitialized,
    /// Ko te maumahara hou ka kiia ka kore.
    Zeroed,
}

/// He mahinga taumata-iti mo te tohatoha noa, te tohatoha, me te whakawhiti i tetahi papa mahara ki runga ake o te puranga me te kore e awangawanga mo nga keehi katoa o te keehi.
///
/// He pai tenei momo mo te hanga i o ake hanganga raraunga penei i te Vec me te VecDeque.
/// Ina koa:
///
/// * Ka whakaputahia te `Unique::dangling()` mo nga momo kore-rahi.
/// * Ka whakaputahia te `Unique::dangling()` mo nga tohatoha kore-roa.
/// * Ka karo i te koreutu `Unique::dangling()`.
/// * Ka hopukina te kaha katoa o te tatauranga o te kaha (ka whakatairanga ki te "capacity overflow" panics).
/// * Kaitiaki ki nga punaha moka-32 e toha atu ana i te isize::MAX paita.
/// * Kaitiaki ki te turaki i to roa.
/// * Karanga `handle_alloc_error` mo nga tohatoha paahitanga.
/// * Kei roto he `ptr::Unique` ana ka whakawhiwhia ki te kaiwhakamahi ki nga painga katoa e pa ana.
/// * Whakamahia ai te toenga nui i whakahokia mai e te Kaitoha ki te whakamahi i te kaha nui rawa atu e waatea ana.
///
/// Kaore tenei momo e tirotirohia te maumahara e whakahaerehia ana.Ka maturuturu ana *ka kore e kore te* mahara, engari kaore e * ngana ki te maturuturu i nga korero o roto.
/// Ka riro ma te kaiwhakamahi o `RawVec` e whakahaere nga mea tuuturu *penapena* i roto o te `RawVec`.
///
/// Kia mahara ko te taikaha o te momo kore-rahi he mutunga kore tonu, na `capacity()` ka whakahoki `usize::MAX` i nga wa katoa.
/// Ko te tikanga me tupato koe i te waa e takahi ana koe i tenei momo me te `Box<[T]>`, na te mea kaore te `capacity()` e tuku i te roa.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Kei te noho tenei na te mea `#[unstable]` `const fn`s kaore e hiahia ki te `min_const_fn` na reira kaore e taea te karanga i roto i te`min_const_fn`s.
    ///
    /// Mena ka huri koe i te `RawVec<T>::new`, i nga whakawhirinaki ranei, koa kia tupato kaua e whakauru i tetahi mea ka takahi i te `min_const_fn`.
    ///
    /// NOTE: i taea e tatou te karo i tenei hack me te Taki conformance ki etahi huanga `#[rustc_force_min_const_fn]` e titau conformance ki `min_const_fn` engari e kore e tika tukua e karanga i te reira i roto i `stable(...) const fn`/waehere kaiwhakamahi kore taea `foo` ina he reira `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Ka waihanga i te `RawVec` nui rawa atu (i runga i te puranga punaha) me te kore e tohatoha.
    /// Ki te `T` rahi pai, ka hanga he `RawVec` ki kaha `0` tenei.
    /// Mena he kore-rahi te `T`, na ka hangaia he `RawVec` me te kaha `usize::MAX`.
    /// He pai mo te whakamahi i te tohatoha roa.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Ka waihanga te `RawVec` (i runga i te puranga pūnaha) ki rite te kaha, me te te tīaroaro whakaritenga mo te `[T; capacity]`.
    /// He rite tenei ki te karanga `RawVec::new` i te wa ko `capacity` te `0` ko te `T` he kore-rahi.
    /// Kia mahara mena he kore-nui te `T` ko te tikanga kaore koe * e whiwhi `RawVec` me te kaha kua tonoa.
    ///
    /// # Panics
    ///
    /// Panics mena ka nui atu te kaha i tonoa `isize::MAX` paita.
    ///
    /// # Aborts
    ///
    /// Tuhinga ka whai mai.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Ka rite ki te `with_capacity`, engari he tohu kei te kore te buffer.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Me whakahou ano i te `RawVec` mai i te tohu me te kaha.
    ///
    /// # Safety
    ///
    /// Ko te `ptr` me tohaina (i runga i te puranga punaha), me te `capacity` kua tohaina.
    /// Kaore e taea e te `capacity` te nui ake i te `isize::MAX` mo nga momo rahi.(he āwangawanga noa kei runga i nga punaha moka-32).
    /// Ko te ZST vectors he kaha pea ki te `usize::MAX`.
    /// Mena te `ptr` me te `capacity` mai i te `RawVec`, na ka pumau tenei.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // He wahangu nga Vecs Iti.Haere ki:
    // - 8 Ki te he te rahi huānga 1, no te mea he pea ki te tawhio ake he tono o iti iho i te 8 paita ki te iti rawa 8 paita tetahi allocators puranga.
    //
    // - 4 mena he paku-rahi te waahanga (<=1 KiB).
    // - 1 mena, kia kore e moumou waatea mo nga Vecs poto rawa.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Ka rite ki te `new`, engari kua taapirihia ki runga ake i te waahanga o te kaiwhakarato mo te `RawVec` i hoki mai.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` te tikanga "unallocated".ka warewarehia nga momo kore-rahi.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Ka rite ki `with_capacity`, engari parameterized mo te pai rawa o te allocator mo te `RawVec` hoki.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Ka rite ki `with_capacity_zeroed`, engari parameterized mo te pai rawa o te allocator mo te `RawVec` hoki.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Tahuri ai te `Box<[T]>` ki te `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Ka hurihia te katoa o te paapaku ki te `Box<[MaybeUninit<T>]>` me te `len` kua tohua.
    ///
    /// Kia mahara ma tenei ka whakakapi tika i nga huringa `cap` tera pea kua mahia.(Tirohia te whakamaarama mo te taipitopito.)
    ///
    /// # Safety
    ///
    /// * `len` me nui ake, kia rite ranei ki te kaha e tonoa ana, a
    /// * `len` me iti ake i te orite ki te `self.capacity()`.
    ///
    /// Kia mahara, ko te kaha i tonoa me te `self.capacity()` ka rereke, i te mea ka taea e te kaitoha te tohatoha me te whakahoki i tetahi poraka mahara nui atu i te waa.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Tirohia te maori ki te haurua o te tikanga mo te ahuru (kaore e taea te tirotiro i tetahi atu haurua)
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Ka karohia e matou te `unwrap_or_else` i konei na te mea ka pupuhi te rahi o te LLVM IR i hangaia.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Me whakahou ano i te `RawVec` mai i te tohu tohu, te kaha me te kaitoha.
    ///
    /// # Safety
    ///
    /// Ko te `ptr` me tohaina (ma te kaituku `alloc` kua tohaina), me te `capacity` kua tohaina.
    /// Kaore e taea e te `capacity` te nui ake i te `isize::MAX` mo nga momo rahi.
    /// (he āwangawanga noa kei runga i nga punaha moka-32).
    /// Ko te ZST vectors he kaha pea ki te `usize::MAX`.
    /// Mena te `ptr` me te `capacity` mai i te `RawVec` i hangaia ma te `alloc`, na ka pumau tenei.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Ka tohua he tohu tika ki te tiimata o te tohatoha.
    /// Kia mahara he `Unique::dangling()` tenei mena he kore-rahi te `capacity == 0` ko te `T` ranei.
    /// I roto i te take o mua, me kia koe tupato.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Ka whiwhi i te kaha o te tohatoha.
    ///
    /// Ka noho `usize::MAX` tenei mena he kore-rahi te `T`.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Whakahoki ai i tetahi korero toha ki te kaiwhakarato e tautoko ana i tenei `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // E tatou te wāhi tohaina o mahara, kia matou e taea karo arowhai wāhaere ki te tiki i to tatou tahora nāianei.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Me whakarite kia nui rawa te waahi kei roto i te buffer hei pupuri i nga waahanga `len + additional`.
    /// Mena kaore ano kia ea te kaha, ka tohatoha ano i te waahi me te waahi mangere kia waihongia *O*(1) te whanonga.
    ///
    /// Ka aukati tenei whanonga mena kaare he take ki panic.
    ///
    /// Ki te nui ake `len` `self.capacity()`, kia kore tenei ki mau tohatoha i te wāhi tonoa.
    /// e kore te mea tino haumaru tenei, engari te waehere haumaru * * koutou tuhituhi e whakawhirinaki i runga i te whanonga o te wahi i ai tenei mahi.
    ///
    /// He pai tenei mo te whakamahi i te mahi pana-nui penei i te `extend`.
    ///
    /// # Panics
    ///
    /// Panics mena ka neke te kaha hou ki te `isize::MAX` paita.
    ///
    /// # Aborts
    ///
    /// Tuhinga ka whai mai.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // kua whakakorehia, kua pororaru ranei te rahui mena i neke atu te len i te `isize::MAX` na te mea he pai tenei kia kore e tirohia inaianei.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Ko te taua rite `reserve`, engari hoki i runga i hapa hei utu o ngohe E waiho ana ranei.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Me whakarite kia nui rawa te waahi kei roto i te buffer hei pupuri i nga waahanga `len + additional`.
    /// Mena kaore ano, ka tohaina ano te iti rawa o te mahara e tika ana.
    /// Ko te tikanga koinei te rahi o nga mahara e tika ana, engari hei te tikanga he waatea te kaiwhakarato ki te whakahoki mai i ta tatou i tono ai.
    ///
    ///
    /// Ki te nui ake `len` `self.capacity()`, kia kore tenei ki mau tohatoha i te wāhi tonoa.
    /// e kore te mea tino haumaru tenei, engari te waehere haumaru * * koutou tuhituhi e whakawhirinaki i runga i te whanonga o te wahi i ai tenei mahi.
    ///
    /// # Panics
    ///
    /// Panics mena ka neke te kaha hou ki te `isize::MAX` paita.
    ///
    /// # Aborts
    ///
    /// Tuhinga ka whai mai.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// He rite ki te `reserve_exact`, engari ka hoki mai i nga hapa kaore i te awangawanga, ki te whakakore ranei.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Ka tiiti i te tohatoha ki raro ki te rahinga kua tohua.
    /// Mena ko te moni kua whakawhiwhia ki te 0, tino whakawhitiwhitinga.
    ///
    /// # Panics
    ///
    /// Panics mena ka nui ake te moni kua hoatuhia * atu i te kaha o inaianei.
    ///
    /// # Aborts
    ///
    /// Tuhinga ka whai mai.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Ka hoki mai mena ka hiahia te tipu whakatipu ki te whakatipu i nga kaha ake e hiahiatia ana.
    /// I whakamahia noa kia pai ai te piihui i nga rahui-waea kaore e whakauruhia te `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ana tēnei tikanga i te nuinga o maha nga wa instantiated.Na ko ta matou hiahia kia iti ake te taea, hei whakapai ake i nga waa whakahiato.
    // Engari e hiahia ana kia kaha te tatau i nga mea katoa o roto, kia tere ai te whakahaere o te waehere i hangaia.
    // Na reira, he mea tuhi tenei tikanga kia uru katoa nga waehere e pa ana ki te `T` ki roto, ana ko te nuinga o te waehere kaore e whakawhirinaki ki te `T` ka taea, kei roto i nga taumahi kaore i te whanui mo te `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Ka whakatutukihia tenei ma nga horopaki karanga.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Mai i te mea ka whakahokia mai e maatau te `usize::MAX` ina `elem_size`
            // 0, te tae ki konei he tikanga kua nui rawa atu te `RawVec`.
            return Err(CapacityOverflow);
        }

        // Kaore e taea e taatau te mahi i enei arowhai, me te pouri.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // He tohu tenei mo te tipu tipu.
        // E kore e taea e te tuaruatia ai te waipuke no `cap <= isize::MAX` me te momo o `cap` ko `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` he kore-whanui i runga i te `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Ko nga herenga i runga i tenei tikanga nui te taua rite te hunga i runga i `grow_amortized`, engari i te nuinga o tenei tikanga instantiated iti maha na te reira iti tino.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Mai i te mea ka whakahokia mai e matou he kaha mo `usize::MAX` i te waa o te momo
            // 0, te tae ki konei he tikanga kua nui rawa atu te `RawVec`.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` he kore-whanui i runga i te `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Kei waho tenei mahinga i te `RawVec` hei whakaiti i nga waa whakahiato.Tirohia te korero i runga ake nei `RawVec::grow_amortized` mo nga korero taipitopito.
// (He kore nui te taapiri `A`, na te mea ko te maha o nga momo `A` rerekee e kitea ana i roto i te mahinga he iti ake i te maha o nga momo `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Tirohia te he o konei hei whakaiti i te rahi o te `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Ka tirohia e te kaiwhakarato te taurite o te taurite
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Ka whakawātea i te pūmahara o te `RawVec`*me te kore* e ngana ana ki te maturuturu i ana korero.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Mahi matua mo te rahui rahui rahui.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Me whakarite taatau e whai ake nei:
// * E kore e matou ake tohatoha `> isize::MAX` ahanoa paita-rahi.
// * Kaore maatau e pakaru i te `usize::MAX` ka tino iti rawa te tohatoha.
//
// I runga i te moka-64 me tiro noa mo te waipuke i te mea ka ngana te tohatoha `> isize::MAX` paita ka kore.
// I moka-32 me moka-16 e ti'a ia tatou ki te tāpiri i te anō kaitiaki mo tenei i roto i te take e rere tatou i runga i te turanga e taea te whakamahi i 4GB katoa i roto i te kaiwhakamahi-wāhi, hei tauira, Pae x32 ranei.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Kotahi te mahi matua hei kawenga mo te tuku purongo.
// Ma tenei ka maarama te whakatupuranga waehere e pa ana ki enei panics he iti na te mea kotahi noa te waahi e panics kaore i te roopu puta noa i te waahanga.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}