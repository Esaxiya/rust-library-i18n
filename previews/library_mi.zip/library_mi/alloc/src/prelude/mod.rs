//! Ko te tohatoha Prelude
//!
//! Ko te kaupapa o tenei waahanga ko te whakamaarama i nga kawemai o nga taonga e whakamahia ana i te `alloc` crate ma te taapiri i te kawemai a-ao ki runga ake o nga waahanga.
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;