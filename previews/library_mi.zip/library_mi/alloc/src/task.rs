#![stable(feature = "wake_trait", since = "1.51.0")]
//! Nga Momo me te Traits mo te mahi me nga mahi hototahi.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Te whakatinanatanga o te whakaohooho i tetahi mahi ki runga i te kaitoha.
///
/// Ka taea te whakamahi i tenei trait ki te hanga [`Waker`].
/// Ka taea e tētahi whakahaere te tautuhi i te whakatinanatanga o tenei trait, ka whakamahi i taua ki te hanga i te Waker ki haere ki te mahi e kua mahi ana i runga i taua whakahaere.
///
/// Tenei trait Ko te mahara-haumaru me te rerekē hāneanea ki hanga te [`RawWaker`].
/// Ka tautokohia te hoahoa kaitoha noa e whakamahia ana nga raraunga hei whakaoho i te mahi kei roto i te [`Arc`].
/// Ko etahi kaitautoko (ina koa ko nga punaha whakauru) kaore e taea te whakamahi i tenei API, na reira ko [`RawWaker`] te mea ke mo era punaha.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// He mahinga `block_on` taketake ka tango i te future ka whakahaere kia oti i runga i te miro onaianei.
///
/// **Note:** Ko tenei tauira e hokohoko ana i te tika mo te maamaa.
/// Hei aukati i nga kati o te mate, me aata whakahaere tonu nga waahanga-whakaputa ki te `thread::unpark` tae atu ki nga karakia whakahua.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// He oho hei oho ake i te aho o te waa ka karangahia.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Whakahaerehia te future kia oti i te miro o teianei.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Puhia te future kia taea ai te pooti.
///     let mut fut = Box::pin(fut);
///
///     // Hangaia he horopaki hou kia tukuna ki te future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Whakahaere i te future ki otinga.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Wake tenei mahi.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Whakaohohia tenei mahi ma te kore e kai i te oho.
    ///
    /// Mena he kaitautoko e tautoko ana i tetahi huarahi iti ake ki te ara ake me te kore e kai i te kaaraara, me turaki tenei tikanga.
    /// Na te taunoa, ka hangai te [`Arc`] ka waea ki te [`wake`] i runga i te tohu.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SAFETY: He haumaru tenei na te mea he hanga humarie a te raw_waker
        // he RawWaker no Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ko tenei mahi muna mo te hanga RawWaker ka whakamahia, kaua ki te
// whakauruhia tenei ki roto i te `From<Arc<W>> for RawWaker` impl, kia kore ai te haumaru o `From<Arc<W>> for Waker` e whakawhirinaki ki te tukunga trait tika, engari ma te kii tika e kii te mahi nei.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Nuku i te tatau tohutoro o te pewa ki te ki tou i te reira.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Whakaoho ma te uara, neke te Arc ki te mahi Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // A ara ake ma te tohutoro, roropi te tangata oho ki te Ringa Ringa kia kore e maturuturu iho
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Decrement te tatau tohutoro o te Arc i taka
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}