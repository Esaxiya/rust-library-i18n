# Te `rustc-std-workspace-core` crate

Ko tenei crate he crate shim me te kore noa e whakawhirinaki ana ki te `libcore` ka whakahoki ano i nga korero katoa o roto.
Ko te crate te kaupapa nui o te whakamana i te wharepukapuka paerewa hei whakawhirinaki ki te crates mai i crates.io

Crates i crates.io e whakawhirinaki te whare pukapuka paerewa i runga i te hiahia ki te whakawhirinaki i runga i te `rustc-std-workspace-core` crate i crates.io, i te mea kau.

Ka whakamahia e matou te `[patch]` hei whakakore i a ia ki tenei crate i roto i tenei putunga.
I te mutunga, ko te crates o te crates.io ka toha mai i te tiakitanga edge ki te `libcore`, ko te putanga kua tautuhia ki tenei putunga.
Kia utu te taha whakawhirinakitanga katoa ki te whakarite Cargo hanga crates pai!

Note e Me crates i runga i crates.io ki whakawhirinaki i runga i tenei crate ki te `core` ingoa mō te katoa ki te mahi tika.Ki te mahi i tena ka taea e raatau te whakamahi:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Na roto i te whakamahi o te kī `package` kua whakaingoatia te crate ki `core`, tikanga ka titiro i te reira rite

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

ina tiaororaa Cargo te taupatupatu, makona i te arata'iraa `extern crate core` te matū patia i te taupatupatu.




