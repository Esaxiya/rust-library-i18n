`core::arch` - Rust o te whare pukapuka matua hoahoanga-motuhake a-roto
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Ko te kohinga `core::arch` e whakamahi ana i nga mahi-a-roto (hei tauira SIMD).

# Usage 

`core::arch` He wātea hei wāhanga o `libcore` me te anō kaweake-reira e `libstd`.Hiahia te whakamahi i te reira mā `core::arch` `std::arch` ranei atu mā tenei crate.
E maha wātea ana i roto i te Rust pō mā te `feature(stdsimd)` āhuatanga iu.

Ma te whakamahi i te `core::arch` ma tenei crate e hiahiatia ana i te po Rust, a ka taea (me te) pakaru tonu.Ko te take anake i roto i nei kia whakaaro koutou te whakamahi i te reira mā tenei crate ko:

* ki te hiahia koe ki te re-whakahiato `core::arch` koe, hei tauira, ki ngā ūnga-āhuatanga whakahohea e kore e i whakahohea mō `libcore`/`libstd`.
Note: ki te hiahia koe ki te re-whakahiato reira mo te ūnga kore-paerewa, tēnā hiahia te whakamahi i `xargo` me re-te whakahiato `libcore`/`libstd` rite tika hei utu o te whakamahi i tenei crate.
  
* te whakamahi i ētahi āhuatanga e kore ai e wātea noa i muri āhuatanga iu Rust.Ka tarai maatau ki te pupuri i enei ki te iti rawa.
Mena me whakamahi e koe etahi o enei ahuatanga, tena koa whakatuwherahia he take kia taea ai e maatau te whakaatu i nga po Rust a ka taea e koe te whakamahi i reira.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` Kei te wehea matua i raro i nga ngā o rua te raihana MIT me te Raihana Apache (Version 2.0), me wahi hipoki e ngā BSD-rite raihana.

Tirohia te RAIHANA-APACHE, me RAIHANA-MIT mō ngā taipitopito.

# Contribution

Te kore koutou te kore āta kāwanatanga, i tetahi takoha te hinaaro tuku mo te whakauru i roto i `core_arch` e koutou, kia rite ki tautuhia i roto i te raihana Apache-2.0, ka kia rua raihana rite runga ake, kahore tetahi atu ngā tikanga ranei.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












