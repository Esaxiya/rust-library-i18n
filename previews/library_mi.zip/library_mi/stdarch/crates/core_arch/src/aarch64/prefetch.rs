#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Tirohia te [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Tirohia te [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Tirohia te [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Tirohia te [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Tirohia te [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Tirohia te [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Tiki i te rārangi keteroki e kei wāhitau `p` te whakamahi i te `rw` homai ko `locality`.
///
/// Ko te `rw` tetahi o:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): kei te whakarite te Tuhinga o mua mo te panui.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): kei te whakareri te tuhinga korero i mua.
///
/// Me kia te `locality` kotahi o:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Rere, whakamau-kore-noa ranei, mo nga raraunga ka whakamahia kotahi noa iho.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Whakauruhia ki te taumata 3 keteroki.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Tiki ki te taumata 2 keteroki.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Whakauruhia ki te reanga taumata 1.
///
/// Ko te tohutohu mahara prefetch tohu ki te pūnaha mahara e whai mahara i te wāhitau whakaritea e pea ki puta i roto i te tata future.
/// Ka taea e te pūnaha mahara urupare mā te tango mahi e kua tūmanakohia ki te tere ake te uru mahara ina e tupu ratou, pērā i preloading te wāhitau tauwhāiti ki tetahi atu ranei keteroki.
///
/// No te mea ko enei tohu tīwhiri anake, ko reira tika hoki ki te PTM ngā hamani i tetahi katoa ranei tohutohu prefetch rite te nop.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Ka whakamahia e matou te tohutohu `llvm.prefetch` me `cache type` =1 (keteroki raraunga).
    // `rw` me te `strategy` kei runga i nga waahanga mahi.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}