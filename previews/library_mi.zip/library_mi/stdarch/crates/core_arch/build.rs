use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Whakamahia ki te korero i to tatou tuhipoka `#[assert_instr]` e he wātea ki te whakamātau i ō rātou codegen intrinsics simd katoa, mai e etahi uipa muri te anō `-Ctarget-feature=+unimplemented-simd128` e kore e whai i tetahi ōrite i roto i `#[target_feature]` tika inaianei.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}