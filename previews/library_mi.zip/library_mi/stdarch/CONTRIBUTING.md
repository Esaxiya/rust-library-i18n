# Te takoha atu ki te rangatira

Ko te `stdarch` crate he nui ake te hiahia ki te whakaae ki nga takoha!Tuatahi ka hiahia pea koe ki te tirotiro i te whare putunga me te whakarite kia paahitia nga whakamatautau maau:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Kei hea `<your-target-arch>` Ko te ūnga reatoru rite whakamahia e `rustup`, tauira `x86_x64-unknown-linux-gnu` (kahore tetahi `nightly-` mua rite ranei).
mahara ano hoki e titau tenei pupuru te hongere pō o Rust!
mahi i roto i te meka i te whakamātautau i runga rapua e pō ki rust hei te taunoa i runga i tou pūnaha, kia whakaturia e whakamahi `rustup default nightly` (ko `rustup default stable` ki Whakahoki).

Mena kaore e mahi tetahi o nga mahi i runga ake nei, [please let us know][new]!

Hei muri ka taea e koe te [find an issue][issues] hei awhina, kua tohua e maatau etahi tohu [`help wanted`][help] me [`impl-period`][impl] ka taea te whakamahi i etahi awhina. 
Akene he hiahia koe ki te [#40][vendor], te whakamahi i nga tuhinga katoa o te kaihoko i te x86.whakatika e te take etahi atatohu pai e pā ana ki te wahi ki te tīmata!

Ki te kua ka koe ite noa ki [join us on gitter][gitter] pātai whānui, me te ui a tawhio noa!Ite noa ki te faahoaraa i rānei@BurntSushi ranei@alexcrichton ki ngā pātai.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Me pehea te tuhi tauira mo te tino tangata uaua

He ruarua nga waahanga me whakahohea kia pai te mahi o te intrinsic kua homai me te tauira me whakahaere noa e `cargo test --doc` ka tautokohia e te PTM te ahuatanga.

Ko te mutunga, ko te `fn main` taunoa e hangaia ana e `rustdoc` kaore e mahi (i te nuinga o nga keehi).
A feruri te whakamahi i te whai kia rite ki te aratohu ki te whakarite koutou mahi tauira rite tūmanakohia.

```rust
/// # // titauhia cfg_target_feature tatou ki te whakarite i te tauira, ko te anake
/// # // whakahaerehia e `cargo test --doc` ka tautoko ana te PTM i te ahuatanga
/// # #![feature(cfg_target_feature)]
/// # // E hiahia ana matou kia whai i te waahanga_hiko kia pai te mahi o te tinana
/// # #![feature(target_feature)]
/// #
/// # // rustdoc i taunoa whakamahi `extern crate stdarch`, engari e hiahia ana matou i te
/// # // `#[macro_use]`
/// # # [Macro_use] extern crate stdarch;
/// #
/// # // Te tino mahi matua
/// # fn main() {
/// #     // Anake whakahaere i tēnei ki te tautoko `<target feature>` te
/// #     ki te cfg_feature_e whakahohea! ("<target feature>"){
/// #         // Waihanga i te mahi `worker` e ka noa kia rere ki te te āhuatanga ūnga
/// #         // Kei te tautoko me te whakarite e te whakahohea `target_feature` mo koutou kaimahi
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         fn haumaru worker() {
/// // Tuhia to tauira ki konei.ka mahi intrinsics āhuatanga motuhake konei!Haere mohoao!
///
/// #         }
///
/// #         haumaru { worker(); }
/// #     }
/// # }
```

Mena ko etahi o nga waahanga o runga ake nei kaore i te tino waia, ko te waahanga [Documentation as tests] o te [Rust Book] e whakaatu tika ana i te kohinga `rustdoc`.
Ka rite ki nga wa katoa, ite noa ki [join us on gitter][gitter] me ui tatou, ki te patua e koe tetahi ngā taitā, a ka whakawhetai koutou mo te āwhina ki te whakapai ake i te tuhinga o `stdarch`!

# He Tohutohu Whakamaatau Atu

Kei te te tikanga tūtohu ana e whakamahi koe `ci/run.sh` ki te rere i te whakamātautau.
Heoi e kore ai tenei mahi mo koutou, hei tauira ki te he koe i runga i Windows.

I roto i taua take e taea hinga koe hoki ki te rere `cargo +nightly test` me `cargo +nightly test --release -p core_arch` mo whakamatautau te whakatupuranga waehere.
Note e rapu enei te toolchain pō ki te tāuta me te mo `rustc` ki mohio e pā ana ki to koutou ūnga reatoru me tona PTM.
I roto i ngā hiahia koe ki te whakaturia te tāupe taiao `TARGET` rite pai koe mo `ci/run.sh`.
I tua atu e hiahia ana koe ki te whakaturia `RUSTCFLAGS` (hiahia te `C`) ki te tohu ngā āhuatanga ūnga, hei tauira `RUSTCFLAGS="-C -target-features=+avx2"`.
Ka taea hoki whakaturia e koe `-C -target-cpu=native` ki te "just" e whakawhanake koe ki tou PTM nāianei.

E ako e ina whakamahi koe i enei tohutohu kē, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], hei tauira
kia kore ako whakatupuranga whakamātautau no te mea rerekē te disassembler huaina ratou, hei tauira
kia whakaputa reira `vaesenc` hei utu o tohutohu `aesenc` ahakoa whanonga ratou te taua.
Hoki enei tohutohu mahia iti whakamātautau i te pai te tikanga kia meatia, kia kore e kia miharo e-tono e wahi ka koe pae hopea kia whakaatu te tahi mau hapa ake mō whakamātautau e kore hipokina konei.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






