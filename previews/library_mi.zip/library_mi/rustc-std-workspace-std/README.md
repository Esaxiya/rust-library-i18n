# Te `rustc-std-workspace-std` crate

Tirohia te tuhinga mo te `rustc-std-workspace-core` crate.