#![feature(no_core)]
#![no_core]

// Tirohia te rustc-std-mokowāmahi-matua mō aha e hiahiatia ana tenei crate te.

// Whakaingoa te crate ki te karo i papā ki te kōwae Tiritiri i liballoc.
extern crate alloc as foo;

pub use foo::*;