use backtrace::Backtrace;

// Ko tenei whakamatautau ka mahi noa i runga i nga papaaho he mahinga `symbol_address` te mahi mo nga papa e whakaatu ana i te timatanga o te tohu.
// Ka rite ki te hua ngā whakahohea anake ki runga ki te torutoru tüäpapa.
//
const ENABLED: bool = cfg!(all(
    // Windows He kore tino i whakamatauria, a kahore OS e tautoko mau te kimi i te anga i karapotia ai, tenei kia mono
    //
    target_os = "linux",
    // I te kitenga o te ARM i te mahi kapi e hoki noa mai ana te ip.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}