use backtrace::Backtrace;

// 50-ingoa ingoa o te waahanga
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50-tohu ingoa ingoa
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Me rāpopototia ingoa mahi roa ki (MAX_SYM_NAME, 1) pūāhua.
// Whakahaerehia tenei whakamatautau mo te msvc, mai i te gnu ka taarua te "<no info>" mo nga papa katoa.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 tukurua o ingoa ingoa, na te mea kua tino tika te ingoa mahi 10 *(50 + 50)* 2=2000 nga roa o te waa.
    //
    // Ko te mau roa mai ano reira ngā `::`, `<>` me te ingoa o te kōwae o nāianei
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}