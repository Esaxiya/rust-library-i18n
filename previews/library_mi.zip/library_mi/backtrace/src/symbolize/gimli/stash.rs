// whakamahia anake i runga i Linux tika inaianei, pera tukua waehere mate kē
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// He allocator ao ohie mō ngā moka paita.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Tukuna he moka o te rahi tauwhāiti me hoki te tohutoro mutable ki reira.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: koinei noa te mahi ka taea te whakarereke
        // tohutoro ki `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // HAUMARU: tatou kore tango huānga i `self.buffers`, na te tohutoro
        // ki nga maatauranga o roto i tetahi piripiri ka ora te roa o te `self`.
        &mut buffers[i]
    }
}