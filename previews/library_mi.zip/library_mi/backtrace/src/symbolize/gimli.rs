//! Tautoko mō te symbolication te whakamahi i te `gimli` crate i crates.io
//!
//! Koinei te whakatinanatanga tohu taunoa mo Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Ko te koiora tuuturu he teka ki te tarai i te kore tautoko mo nga waahanga korero-a-ake.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Tahuri ki 'nga wa tuuturu mai i te mea me nama e nga tohu te `map` me te `stash` ana kei te tiakina e matou i raro.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Mo te utaina i nga wharepukapuka taketake i te Windows, tirohia nga korerorero mo te rust-lang/rust#71060 mo nga momo rautaki i konei.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // I tenei wa kaore nga whare pukapuka MinGW e tautoko i te ASLR (rust-lang/rust#16514), engari ka taea tonu te neke nga DLL ki te waahi wahitau.
            // Te ahua nei ko nga wahitau kei roto i nga korero whakaahuru he penei-mena i utaina tenei wharepukapuka ki tana "image base", he mara kei roto i ona pane COFF pane.
            // Na te mea koinei te rarangi o te debuginfo ka paahihia e maatau te teepu tohu me nga wahitau toa me te mea i utaina te whare pukapuka i te "image base" hoki.
            //
            // Kaore pea te whare pukapuka e utaina i te "image base", engari.
            // (Īhaka kia utaina te tahi mea atu ai ki reira?) Ko tenei te wahi i haere mai te `bias` mara ki te tākaro, ka hiahia tatou ki te feruri i roto i te uara o `bias` konei.Heoi, ahakoa kaore e marama me pehea te tango mai i tenei i tetahi waahanga kawenga.
            // Aha tatou e whai, Heoi, ko te wāhitau kawenga tūturu (`modBaseAddr`).
            //
            // Hei ahua cop-out mo tenei inaianei ka tuhia e maatau te konae, panuihia nga korero pane pane, ka taka te mmap.Ko te moumou tenei no te mea ka tūwhera tatou pea te mmap muri, engari kia mahi i tenei pai nui mo inaianei.
            //
            // Kia whiwhi tatou i te `image_base` (waahi kawenga e hiahiatia ana) me te `base_addr` (waahi kawenga tuuturu) ka taea e taatau te whakakii i te `bias` (rereke i waenga i te mea pono me te hiahia) a ko te wahitau o ia waahanga ko te `image_base` mai i te mea e kii ana te konae.
            //
            //
            // I tenei wa ka puta ke kaore e rite ki te ELF/MachO ka taea e taatau te mahi tetahi waahanga mo ia wharepukapuka, ma te whakamahi i te `modBaseSize` te rahi katoa.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS ka whakamahi i te whakatakotoranga o te konae-Mach me te whakamahi i nga API-motuhake a DYLD hei uta i te raarangi o nga wharepukapuka taketake kei roto i te tono.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Tangohia te ingoa o tenei whare pukapuka e hangai ana ki te ara o te uta ki reira hoki.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Utaina te pane atahanga o tenei wharepukapuka ka toha atu ki te `object` ki te tarai i nga whakahau kawenga katoa kia taea ai e taatau te rapu i nga waahanga katoa e pa ana ki konei.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Whakahauhia nga waahanga ka rehita i nga rohe e mohiotia ana mo nga waahanga ka kitea e maatau.
            // mōhiohio tua record a'ee wāhanga kuputuhi mō te tukatuka i muri, kite kōrero i raro iho.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Whakaritehia te "slide" mo tenei whare pukapuka ka mutu ko te miihini e whakamahia ana e maatau ki te tohu kei hea nga taonga whakamahara e utaina ana.
            // He ahua iti ano tenei ki te kaute taatau ahakoa ko te mutunga o te whakamatautau i etahi mea iti i te ngahere ka kite he aha te rakau.
            //
            // Ko te whakaaro whānui he e te `bias` me `stated_virtual_memory_address` o te wāhanga e haere ana ki te hei te wahi i roto i te wāhi wāhitau tūturu nga noho i wāhanga.
            // Ko tetahi atu mea e whakawhirinaki atu ana matou ko te wahitau he pono ka tangohia te `bias` ko te taupū hei titiro ki te teepu tohu me te debuginfo.
            //
            // Te mea ke, ahakoa, mo nga wharepukapuka kua utaina e te punaha kaore i te tika enei tatauranga.Hoki Kawenga taketake, Heoi, puta reira tika.
            // Ara etahi arorau i pūtake o LLDB kua reira etahi motuhake-casing mo te wāhanga `__TEXT` tuatahi utaina i te kōnae wāhikē 0 ki te rahi kahorekore.
            // Ahakoa he aha te take i te wa tenei, ko te tikanga ko te teepu tohu e pa ana ki te reti vmaddr mo te wharepukapuka.
            // Mena kaore *i te wa* ka ko te teepu tohu e pa ana ki te reti vmaddr me te wahitau o te waahanga.
            //
            // Ki te hapai i tenei āhuatanga, ki te tatou kahore e * * kitea te wāhanga kuputuhi i kōnae wāhikē kore ka whakanui i tatou i te rītaha i te wāhitau i kīia o te wāhanga kuputuhi tuatahi, me te whakaiti wāhitau kī katoa i taua nui rite te pai.
            //
            // Ko e ara ko nga wa katoa te tepu tohu puta whanaunga ki te nui rītaha o te whare pukapuka.
            // Ko te ahua nei he hua tika mo te tohu ma te teepu tohu.
            //
            // Pono e kore au e ahau rawa mohio ranei he tika tenei ranei ki te reira te tahi mea atu e kia tohu pehea ki te mahi i tenei.
            // Mo tenei wa ahakoa he pai te mahi (?) ana me kaha tonu taatau whakaputa i tenei i te waa ki te tika.
            //
            // Mo etahi atu korero tirohia te #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Othertahi atu Unix (hei tauira
        // whakamahi Linux) tüäpapa Elf hei hōputu kōnae ahanoa me te nuinga whakatinana i tētahi API huaina `dl_iterate_phdr` ki te uta i whare pukapuka taketake.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` kia tika hei tohu tohu.
        // `vec` kia tika te tohu tohu ki te `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 kaore e tautokohia e te iwi ake nga korero whakakore, engari ma te punaha hanga e tuku nga korero whakakore i te ara `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Ko nga mea katoa me whakamahi i te ELF, engari kaore e mohio ki te uta i nga wharepukapuka taketake.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Ko nga wharepukapuka tuuturu katoa e mohiotia ana kua utaina.
    libraries: Vec<Library>,

    /// Maakete whakamahere kei reira ka pupuri maatau i nga korero papaka kereme.
    ///
    /// He raarangi kaha tenei raarangi mo te roanga o te neke e kore e piki ake.
    /// Ko te huānga `usize` o ia rua ko te taupū ki `libraries` runga ake te wahi tohu `usize::max_value()` te kawenga o nāianei.
    ///
    /// Ko te `Mapping` he korero whaaiti papaka kerite.
    ///
    /// Note e ko fele tenei he keteroki LRU me ka kia neke tatou mea a tawhio noa i roto i konei rite tohu tatou wāhitau.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// I utaina nga waahanga o tenei wharepukapuka ki te maumahara, me te wahi e utaina ana.
    segments: Vec<LibrarySegment>,
    /// Ko te "bias" o tenei wharepukapuka, ko te waa e utaina ana hei whakamahara.
    /// Ka taapirihia tenei uara ki nga waahanga o ia waahanga hei kii i te wahitau mahara mariko e utaina ana te waahanga.
    /// Hei taapiri ka tangohia tenei taarua mai i nga korero maumahara mariko pono hei tohu ki te debuginfo me te teepu tohu.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Ko te wahitau o tenei waahanga kei roto i te konae konae.
    /// Ehara tenei i te mea kua utaina te waahanga, engari ko tenei wahitau me te `bias` o te whare pukapuka kei reira ka kitea.
    ///
    stated_virtual_memory_address: usize,
    /// Te rahinga o te waahanga ths hei maumahara.
    len: usize,
}

// kaore i te haumaru na te mea me tuku tenei i to taha o waho
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // kaore i te haumaru na te mea me tuku tenei i to taha o waho
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // He iti rawa, tino maamaa te keteroki LRU mo nga maataki korero patuiro.
        //
        // Te tikanga kia nui rawa te tatauranga, na te mea kaore e whiti te puranga i waenga i nga wharepukapuka tuuturu.
        //
        // E tino utu ki te waihanga i te hanganga `addr2line::Context`.
        // tūmanakohia Ko tōna utu te ki kia whakaheke wäriu e pātai `locate` muri, e huanga nga hanganga i hanga ina hanga `addr2line: : Context`s ki te tiki speedups pai.
        //
        // Mena kaore i a maatau tenei peera, kaore e tutuki taua whakahekenga, me nga tohu o muri hei ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Tuatahi, whakamatautau mena kei i tenei `lib` tetahi waahanga kei roto te `addr` (whakahaere huringa).Ki te haere tenei Taki ka taea tatou tonu i raro, me te mau iriti i te wāhitau.
                //
                // Note e e whakamahi tatou `wrapping_add` konei kia karo waipuke te arowhai.Kua kitehia i te wao ka nui te kaha o te tatauranga taatai SVMA +.
                // He ahua rereke pea tera kaare engari kaore he rahi o nga moni ka taea e taatau ki tua atu i te kore e wareware ki era waahanga na te mea e toro atu ana ratau ki te waahi.
                //
                // haere mai tuatahi tenei ake i roto i rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Na, e matau ana tatou `lib` Kei `addr`, ka taea e tatou wāhikē ki te rītaha ki te kitea te wāhitau mahara virutal kī.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Pūmau: i muri i tenei oti te herenga kahore wawe hoki mai
        // mai i tetahi he, ko te urunga keteroki mo tenei ara kei te taupū 0.

        if let Some(idx) = idx {
            // A, no te Ko kē te mahere i roto i te keteroki, neke reira ki te mua.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Ki te kore te mapi ki te kete, hangahia he maheretanga hou, whakauruhia ki mua o te keteroki, ka peia atu te urunga keteroki tawhito mena ka tika.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // kaua e turuturu te ao `'static`, kia maumahara ki a taatau anake
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Whakawhitihia te roanga o te `sym` ki te `'static` mai i te mea e hiahiatia ana maatau ki konei, engari ka haere tonu atu hei tohutoro kia kore ai e tohungia kia tua atu i tenei anga.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Hei whakamutunga, te tiki i te mahere keteroki ranei te hanga i tētahi mahere hōu mo tenei kōnae, ka arotake i te info papaka ki te kitea te file/line/name mo tenei wāhitau.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// I taea e maatau te rapu i nga korero anga mo tenei tohu, ana ko te anga o te "addr2line` kei roto katoa e whai kiko ana.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Kare i kitea nga korero patuiro, engari i kitea i te teepu tohu o te mauri te taea.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}