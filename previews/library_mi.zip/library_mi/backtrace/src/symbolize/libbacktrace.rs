//! rautaki Symbolication te whakamahi i te waehere papaka-poroporo i libbacktrace.
//!
//! Ko te wharepukapuka libbacktrace C, ka tohaina ki te gcc, e tautoko ana ehara i te whakahoki i te tuara (kaore e tino whakamahia e maatau) engari he tohu hoki i te tuara me te hapai i nga korero patuiro papaka mo nga mea penei i nga papa kua raarangi me te aha.
//!
//!
//! He uaua tenei na te maha o nga awangawanga i konei, engari ko te kaupapa ke:
//!
//! * Tuatahi karanga tatou `backtrace_syminfo`.Ka whiwhi tenei i nga korero tohu mai i te teepu tohu hihiri mena ka taea.
//! * Whai muri ka kiia ko `backtrace_pcinfo`.Ma tenei ka paahi nga teepu debuginfo mena kei te waatea ratou ka taea ai e matou te whakahoki mai i nga korero mo nga papa tuarangi, ingoa ingoa, raina raina, etc.
//!
//! He te rota o te tinihanga e pā ana ki te whiwhi i te tepu papaka ki libbacktrace, engari te tūmanako e kore te reira te mutunga o te ao, me te he nui mārama ina pānui i raro.
//!
//! Koinei te rautaki tohu taunoa mo te kore-MSVC me nga papa-kore OSX.I roto i te libstd ahakoa ko te rautaki taunoa mō OS tenei.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Ki te taea hiahia te ingoa `function` e mai i debuginfo a taea nuinga kia tika atu hoki papa rōraina mō te tauira.
                // Mena kaore i teera ahakoa ka hoki ki te ingoa teepu tohu kua tohua i te `symname`.
                //
                // Kia mahara, i etahi wa ka kite a `function` i te ahua tika o te tika, hei tauira ko te `try<i32,closure>` isntead o `std::panicking::try::do_call`.
                //
                // e kore ngā tino ūkui reira he aha, engari whānui te mea tika atu te ingoa `function`.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // kaua e mahi i tetahi mea inaianei
}

/// Te momo o te atatohu `data` i paahitia ki `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Ka tukuna mai tenei hokinga mai i te `backtrace_syminfo` ka tiimata ana ta maatau whakatau ka haere maatau ki te karanga `backtrace_pcinfo`.
    // Ma te mahi `backtrace_pcinfo` e korero nga korero whakakore me te ngana ki te mahi i nga mea penei i te whakahoki mai i nga korero file/line me nga papa whakauru.
    // Kia mahara ahakoa ka ngoikore te `backtrace_pcinfo` kaore ranei e nui te mahi mena kaore he korero whakakore, na ki te tutuki ka karanga ano tatou i te hokinga mai me te tohu kotahi mai i te `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Te momo o te atatohu `data` i paahitia ki `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Ka tautokohia e te libbacktrace API te hanga kawanatanga, engari kaore i te tautoko ki te whakangaro i tetahi kawanatanga.
// Ko taaku ake tenei e kii ana he kaupapa te hanga kia ora tonu ai.
//
// e aroha ahau ki te rēhita he pūnanao at_exit() e cleans ake tenei ahua, engari whakarato libbacktrace kahore ara ki te rave i te reira.
//
// Na enei herenga, kei tenei mahinga he taatai ketekete e taatai ana i te wa tuatahi ka tonohia tenei.
//
// Kia maumahara ko te whakahoki whakamuri i nga mea katoa ka tupu i runga i te waatea (kotahi maukati ao).
//
// Kia mahara ko te korenga o te honohono i konei na te hiahia o `resolve` ka honoa o waho.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Kaua e faaohipa threadsafe kaha o libbacktrace mai e tatou karanga tonu i te reira i roto i te ahua tukutahi.
        //
        0,
        error_cb,
        ptr::null_mut(), // kaore he taapiri taapiri
    );

    return STATE;

    // Kia mōhio e hoki ki te libbacktrace mahi i te katoa me te reira ki te kitea te mōhiohio patuiro papaka mo te kawenga o nāianei.Ko te tikanga ka mahia ma te maha o nga tikanga, tae atu ki te:
    //
    // * /proc/self/exe i runga i nga papaaho tautoko
    // * I tino marama te ingoakame i te wa e hanga ahua ana
    //
    // Ko te whare pukapuka libbacktrace he taonga nui mo te C waehere.Ko te tikanga o tenei ko te ngoikoretanga o te haumaru maumahara, ina koa ki te whakahaere i te debuginfo koretake.
    // Kua rere Libstd ki nui o enei mua.
    //
    // Mena ka whakamahia te /proc/self/exe ka taea e taatau te aro atu i enei ki te whakaaro maatau ko te libbacktrace ko "mostly correct" ana ka kore e mahi i nga mea rereke me te "attempted to be correct" korero whakahekeheke papatu.
    //
    //
    // Mena ka tukuna e taatau tetahi ingoa ingoa, heoi, ka taea i runga i etahi papa (penei i te BSDs) ka taea e tetahi kaiwhakaari kino te tuku i tetahi konae ki taua waahi.
    // Ko te tikanga mena ka korero atu tatou ki te hokinga korero mo tetahi ingoa ingoa pea kei te whakamahi i tetahi konae kore, ma tera pea ka wehe etahi.
    // Mena kaore e korerohia e maatau tetahi waahanga noa ahakoa kaore e mahi i tetahi mea i runga i nga papa e kore e tautoko i nga huarahi penei i te /proc/self/exe!
    //
    // Hoatu katoa e tamata tatou rite pakeke rite taea ki te haere *kore* i roto i te kōnae, engari tatou me i runga i ngä tüäpapa e kore e tautoko i /proc/self/exe i te katoa.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Note e hiahia whakamahi tano tatou `std::env::current_exe`, engari e kore e taea e tatou e rapu utu `std` konei.
            //
            // Whakamahia te `_NSGetExecutablePath` ki te uta i te ara whakahaere o naianei ki roto i te waahi tuuturu (mena he iti rawa ka tuku noa atu).
            //
            //
            // Kia mahara kei te tino whakapono taatau ki te hokinga mai i konei kia kaua e mate ki runga i nga mana whakahaere pirau, engari he tika ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows he momo ki te whakatuwhera i nga konae ka mutu ana te whakatuwherahia kaore e taea te whakakore.
            // Ko te mea noa ta maatau e hiahia ana i konei na te mea e hiahia ana maatau kia kore e rereke te whakahaere mai i raro i a maatau i muri i to taatau tuku ki te hokinga korero, me te tumanako kia kaha ake te tuku tuhinga taapiri ki roto i te hokinga mai (tera pea e he ana te mahi).
            //
            //
            // Hoatu e mahi tatou i tetahi wahi o te kanikani ki konei ki te ngana ki te tiki i te ahua o te raka i runga i to tatou iho image:
            //
            // * Tikina he kakau ki te mahinga o naianei, utaina tona ingoa ingoa.
            // * Whakatūwhera te kōnae ki taua kōnae ki te haki tika.
            // * Uta anō kōnae o te tukanga o nāianei, te mohio te reira te taua
            //
            // Ki te taua haere katoa tatou i roto i te ariā i whakatuwheratia pono kōnae to tatou tukanga o me e kī matou e kore e huri i te reira.FWIW he paihere o tenei ka kape mai i nga korero o mua, no reira koinei taku whakamaarama pai mo nga mahi.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Ka noho tenei ki roto i nga mahara maumahara kia taea ai e tatou te whakahoki mai ..
                static mut BUF: [i8; N] = [0; N];
                // ... ana ka noho tenei i runga i te puranga mai i te mea he poto
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // opua turuturu `handle` konei no te mea he taua tuwhera kia tiaki i to tatou raka i runga i tenei ingoa kōnae.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Kei te hiahia matou ki te whakahoki i tetahi poro kua whakakorehia, na mena i kapi katoa nga mea ka rite ki te roa o te roa ka rite ki te ngoikore.
                //
                //
                // Kore ka hoki mai hanga angitu tino ngā te paita nul te i roto i te wāhanga.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // E kahakina tēnei wā hapa backtrace i raro i te koroka
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Karangahia te `backtrace_syminfo` API (mai i te panui i te waehere) me karanga kia `syminfo_cb` kia kotahi te wa (ka kore pea ka hapa pea)
    // Ka whakahaerehia e maatau etahi atu mea i roto i te `syminfo_cb`.
    //
    // Kia mahara kei te mahi tatou i tenei mai i te mea ka tirohia e `syminfo` te teepu tohu, ka kitea nga ingoa tohu ahakoa kaore he korero patuiro i te rua.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}