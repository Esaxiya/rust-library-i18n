use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Whakatauhia he wahitau ki tetahi tohu, ka tuku i te tohu ki te katinga kua tohua.
///
/// Ma tenei mahi e rapu te korero kua waahihia ki nga waahi penei i te teepu tohu a rohe, teepu tohu hihiri, te korero whakaahuru DWARF ranei (kei i te whakamahinga whakahohe) kia kitea nga tohu hei tuku.
///
///
/// e kore ai e karangatia e te katinga, ki te kore i taea te whakamana i taumira, a reira kia huaina ai hoki neke atu i te kotahi i roto i te take o ngā mahi inlined.
///
/// Ko nga tohu i whakawhiwhia hei tohu mo te mahi i te `addr` kua tohua, me te whakahoki mai i nga takirua file/line mo taua wahitau (mena kei te waatea).
///
/// Note, ki te whai koe i te `Frame` ka ngā tūtohu ana e ki te whakamahi i te mahi `resolve_frame` hei utu o tenei tetahi.
///
/// # Nga waahanga e hiahiatia ana
///
/// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
///
/// # Panics
///
/// Ka ngana tenei mahi kia kaua rawa e panic, engari mena i whakawhiwhia te `cb` ki te panics ka kaha etahi papa ki te akiaki i te panic takirua kia whakakorehia te kaupapa.
/// Ko etahi o nga papa e whakamahi ana i te whare pukapuka C kei roto e whakamahi ana i nga hokinga whakahoki kaore e taea te wetewete, na reira ko te paniko mai i te `cb` ka aukati i te waahanga ka whakakorehia.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // anake titiro i te tāpare runga
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Whakatauhia he anga i mau i mua ki tetahi tohu, ka tuku i te tohu ki te katinga kua tohua.
///
/// He rite tonu te mahi a tenei funcin me te `resolve` engari me waiho he `Frame` hei tautohe hei utu mo tetahi wahitau.
/// Ma tenei ka taea te whakamahi i etahi waahanga papaanga o te hoki whakamuri ki te whakarato i nga korero tohu tika ake, korero ranei mo nga papa raina hei tauira.
///
/// E manakohia ana ki te whakamahi i tenei, ki te taea e koe.
///
/// # Nga waahanga e hiahiatia ana
///
/// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
///
/// # Panics
///
/// Ka ngana tenei mahi kia kaua rawa e panic, engari mena i whakawhiwhia te `cb` ki te panics ka kaha etahi papa ki te akiaki i te panic takirua kia whakakorehia te kaupapa.
/// Ko etahi o nga papa e whakamahi ana i te whare pukapuka C kei roto e whakamahi ana i nga hokinga whakahoki kaore e taea te wetewete, na reira ko te paniko mai i te `cb` ka aukati i te waahanga ka whakakorehia.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // anake titiro i te tāpare runga
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// He uara IP i papa tāpae nuinga (always?) te ako *i muri i* te karanga e te te wahi tāpae tūturu.
// Ko te tohu i tenei na te mea ko te nama filename/line kia kotahi kei mua pea ka kore pea mena kua tata te mutunga o te mahi.
//
// Tenei itehia ki waiwai tonu kia te take i runga i ngä tüäpapa katoa, kia tango tonu tatou tetahi i te ip whakatau ki te whakatau i te reira ki te ako karanga mua hei utu o te ako e hoki ki.
//
//
// Ko te mea pai kaore matou e mahi i tenei.
// Ko te mea tika ka hiahia matou ki nga kaiwaea o nga API `resolve` i konei ki te mahi a ringa i te -1 me te kaute e hiahia ana ratou ki nga korero waahi mo nga tohutohu *o mua*, kaua ki nga waa o tenei wa.
// Ko te mea tika ka whakaatuhia e maatau a `Frame` mena he tino korero tatou mo nga tohutohu a muri ake nei, o naianei ranei.
//
// I tenei wa ahakoa he tino awangawanga motuhake tenei na ka tangohia noa e taatau tetahi.
// Me mahi tonu nga kaihoko me te whiwhi hua tino pai, no reira me tau kia pai.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// He rite ki te `resolve`, he haumaru noa na te mea kaore i te tukutahia.
///
/// Kaore he mana taurangi o tenei mahi engari ka waatea ka kore e whakauruhia te waahanga `std` o tenei crate.
/// Tirohia te te mahi `resolve` mo ake tuhinga, me ngā tauira.
///
/// # Panics
///
/// Tirohia nga korero i te `resolve` mo nga whakatupato i te `cb` awangawanga.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// He rite ki te `resolve_frame`, he haumaru noa na te mea kaore i te tukutahia.
///
/// Kaore he mana taurangi o tenei mahi engari ka waatea ka kore e whakauruhia te waahanga `std` o tenei crate.
/// Tirohia te mahi `resolve_frame` mo etahi atu tuhinga me nga tauira.
///
/// # Panics
///
/// Tirohia te mōhiohio i runga i `resolve_frame` mō reehita i runga i `cb` ngohe.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// He trait e tohu ana i te whakataunga o tetahi tohu i roto i te konae.
///
/// I whakawhiwhia tenei trait hei taonga trait ki te katinga i whakawhiwhia ki te mahi `backtrace::resolve`, a kua tukuna noa atu na te mea kaore e mohiotia ko wai te kaupapa e whai ana i muri.
///
///
/// Ma te tohu e whakaatu nga korero horopaki mo tetahi mahi, hei tauira, te ingoa, te ingoa ingoa, te raina, te kaainga tika, me era atu.
/// Kaore nga korero katoa e waatea i nga wa katoa i roto i te tohu, engari, no reira ko nga tikanga katoa ka whakahoki i te `Option`.
///
///
pub struct Symbol {
    // TODO: tenei ora herea hiahia ki te kia tamau hopea ki `Symbol`,
    // engari he rereketanga tera i tenei wa.
    // I tenei wa he pai tenei mai i te `Symbol` ka tukuna noa ma te tohutoro kaore e taea te tuku i te aarai.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Whakahokia te ingoa o tenei mahi.
    ///
    /// Ka taea te whakamahi i te hanganga ki te uiui i nga momo taonga e pa ana ki te ingoa tohu:
    ///
    ///
    /// * Ma te whakamahinga `Display` e taia te tohu kua mimiti.
    /// * Ko te uara `str` mata o te tohu ka taea te uru atu (mena he tika te utf-8).
    /// * Ko nga paita mataa mo te ingoa tohu ka taea te uru atu.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Whakahoki ai i te wahitau timatanga o tenei mahi.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Whakahokia te ingoa kōnae raw rite te wāhanga.
    /// He tino whaihua tenei mo nga taiao `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Whakahokia ai te tau pou mo te waahi e whakamahia ana tenei tohu.
    ///
    /// whakarato gimli anake tēnei wā he uara konei a tae noa ka anake, ki te hoki mai `filename` `Some`, a na te mea na reira i raro ki reehita rite.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Whakahokia te tau aho mo te wahi e mahi tenei tohu tēnei wā.
    ///
    /// Ko tenei uara hoki te nuinga `Some` ki te hoki mai `filename` `Some`, a ko reira raro ki reehita rite.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Whakahoki ai i te ingoa o te konae i tautuhia ai tenei mahi.
    ///
    /// E waatea ana tenei i tenei wa ka whakamahia ana te libbacktrace me te gimli (hei tauira
    /// unix atamira etahi atu) ana ka whakahiatohia te taarua me te debuginfo.
    /// Ki te tutaki te kore o enei tikanga ka ka pea tenei hoki `None`.
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Pea te parse C++ tohu, ki te pāhi i te tohu ripiripia rite Rust rahua.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Kia mahara ki te pupuri i tenei kore-rahi, kia kore ai he utu mo te waahanga `cpp_demangle` ka monokia ana.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// He Uwhi huri noa te ingoa tohu ki te whakarato accessors hāneanea ki te ingoa demangled, te paita raw, te aho raw, me ētahi atu
///
// Whakaaetia te waehere mate mo te kore e whakahohea te waahanga `cpp_demangle`.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Ka waihanga te ingoa tohu hou i te paita whāriki raw.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Whakahokia te ingoa tohu (mangled) raw rite te `str` ki ko te tohu tika utf-8.
    ///
    /// Whakamahia te whakatinanatanga `Display` ki te hiahia koe i te putanga demangled.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Whakahokia te ingoa tohu raw rite te rārangi o paita
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // kia tenei ki te tā, ki te kahore te mea mau whaimana te tohu demangled, na te hapai i te hapa i konei gracefully e kore whakatō reira whakawaho.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Ngana ki te whakahoki mai i te maumahara keteroki i whakamahia hei tohu i nga wahitau.
///
/// Ka ngana tēnei aratuka ki te tuku i tetahi hanganga raraunga ao e kua kore kua keteroki ao ranei i roto i te miro e te nuinga tohu mōhiohio papaka parse rite ranei.
///
///
/// # Caveats
///
/// Ahakoa he wātea tonu tenei mahi e kore e mau te mahi i reira tetahi mea i runga i te nuinga o implementations.
/// Ko nga wharepukapuka penei i te dbghelp, i te libbacktrace ranei kaore i te whakarato i nga waahi ki te whakawhiti i te ahua me te whakahaere i nga mahara kua tohaina.
/// I tenei wa ko te mahinga `gimli-symbolize` o tenei crate anake te ahuatanga e whai kiko ana tenei mahi.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}