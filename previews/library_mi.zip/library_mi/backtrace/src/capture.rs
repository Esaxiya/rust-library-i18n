use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// He whakaaturanga mo te tuara o muri me tona ake-tuara.
///
/// Ka taea te whakamahi i tenei hangahanga hei hopu i te tuara i nga waahanga rereke o te hotaka a muri iho ka tirohia ki te tirotiro i tera waa i tera waa.
///
///
/// `Backtrace` tautoko tino-tā o backtraces roto i tona whakatinanatanga `Debug`.
///
/// # Nga waahanga e hiahiatia ana
///
/// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Ko nga anga kei konei e raarangi mai i runga-ki-raro o te puranga
    frames: Vec<BacktraceFrame>,
    // Ko te taupū e whakapono ana matou ko te tiimata o te tuara o muri, ka kore e mau nga papa penei i te `Backtrace::new` me te `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// He putanga i mau i te papa i muri i te tuara.
///
/// hoki tēnei momo te rite te rārangi i `Backtrace::frames` me tohu kotahi anga tāpae i roto i te backtrace riro.
///
/// # Nga waahanga e hiahiatia ana
///
/// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// He tohu i mau i tetahi tohu kei muri i te tuara.
///
/// hoki tēnei momo te rite te rārangi i `BacktraceFrame::symbols` me tohu te raraunga mō te tohu i roto i te backtrace.
///
/// # Nga waahanga e hiahiatia ana
///
/// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Ka mau i te tua whakamuri ki te waahi waea o tenei mahi, me te whakahoki mai i tetahi o ana rangatira.
    ///
    /// He pai tenei mahi hei tohu i te tuara o muri hei ahanoa i te Rust.Ko tenei uara kua whakahokia mai ka taea te tuku puta noa i nga miro ka taarua ki etahi atu waahi, a ko te kaupapa o tenei uara kia mau katoa.
    ///
    /// Kia mōhio e i runga i te tahi mau tüäpapa whiwhi i te backtrace tonu, me te whakatau ka taea e te mea tino utu.
    /// Mena he nui rawa te utu mo to tono ka taunaki kia kaua e whakamahi i te `Backtrace::new_unresolved()` ka karo i te taahiraa tohu tohu (ko te mea roa rawa atu) ka ahei te tuku i tena ki tetahi waa o muri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // e hiahia ana kia mohio he anga kei konei hei tango
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// He rite ki te `new` engari kaore tenei e whakatau i nga tohu, ka mau tenei i te tua ki muri hei raarangi o nga wahitau.
    ///
    /// A muri ake nei ka taea te karanga i te mahi `resolve` ki te whakatau i nga tohu o tenei hoki ki nga ingoa panuihia.
    /// Kei te noho tenei mahi na te mea ko te huringa whakataunga ka nui te waa ka nui te waa mena ka kore e taarua tetahi tua.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // kaore he ingoa tohu
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // ingoa tohu inaianei
    /// ```
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    ///
    ///
    #[inline(never)] // e hiahia ana kia mohio he anga kei konei hei tango
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Whakahoki ai i nga papa mai i te wa i mauhia ai tenei tuara.
    ///
    /// Ko te tomokanga tuatahi o tenei wāhanga pea te mahi `Backtrace::new`, me te anga whakamutunga he pea te tahi mea e pā ana ki te āhua o tīmata tenei miro te mahi matua ranei.
    ///
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Mena i hangaia tenei hokinga whakamuri mai i `new_unresolved` katahi ma tenei mahi e whakatau nga wahitau katoa i te tua o muri ki o raatau ingoa tohu.
    ///
    ///
    /// Mena kua whakatauhia i muri tenei, kua hangaia ranei ma te `new`, kaore he mahi a tenei mahi.
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// He rite ki te `Frame::ip`
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// He rite ki te `Frame::symbol_address`
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// He rite ki te `Frame::module_base_address`
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Whakahokia ai te raarangi o nga tohu e rite ana ki tenei anga.
    ///
    /// Te tikanga he kotahi noa te tohu mo ia anga, engari i etahi wa mena ka whakauruhia etahi mahi ki roto i te anga kotahi ka whakahokia mai nga tohu maha.
    /// Ko te tohu tuatahi kua raarangi ko te "innermost function", engari ko te tohu whakamutunga ko te mea o waho (te kaiwaea whakamutunga).
    ///
    /// Kia mōhio ki te haere mai tenei anga i te backtrace i faaafarohia katahi ka hoki mai tenei he rārangi kau.
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// He rite ki te `Symbol::name`
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// He rite ki te `Symbol::addr`
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// He rite ki te `Symbol::filename`
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// He rite ki te `Symbol::lineno`
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// He rite ki te `Symbol::colno`
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Ka taarua nga ara ka ngana ki te tarai i te cwd mena kei kona, kaore keehi me taarua te huarahi kia rite-tonu.
        // Kia mahara kei te mahi noa tatou i tenei mo te whakatakotoranga poto, na te mea mena ka ki katoa ka hiahia taatau ki te taarua nga mea katoa.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}