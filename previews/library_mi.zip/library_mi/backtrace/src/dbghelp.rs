//! He kōwae ki āwhina i roto i te whakahaere i ngā piringa dbghelp i runga i Windows
//!
//! Ko nga tuara kei runga i te Windows (ko te mea iti rawa mo te MSVC) kei te kaha te whakahaere i te `dbghelp.dll` me nga momo momo mahi kei roto.
//! E utaina tēnei wā ēnei mahi *hihiri*, kaua ki te hono ki a `dbghelp.dll` statically.
//! Kei te mahi tenei wā e te whare pukapuka paerewa (me he i roto i te ariā e hiahiatia ana i reira), engari ko te kaha ki te awhina whakaiti te ririki pateko dll o te whare pukapuka mai i backtraces Ko te tikanga he tino kōwhiringa.
//!
//! Ko te korero, `dbghelp.dll` tata tonu ka utaina i runga i te Windows.
//!
//! Kia mahara na te mea kei te utaina maatau i tenei tautoko kaore e taea e taatau te whakamahi i nga whakamaaramatanga mata i te `winapi`, engari me matua whakarite e taatau nga tohu tohu hei whakamahi i taua.
//! E kore matou e hiahia tino ki te hei i roto i te mahi o Tāritehia winapi, na to tatou he āhuatanga Cargo `verify-winapi` e whakapuakina e Here katoa ōrite te hunga i roto i te winapi me te whakahohea tēnei āhuatanga i runga i CI.
//!
//! Hei whakamutunga, ka kite koe i konei ko te dll mo `dbghelp.dll` kaore i te utaina, a he kaupapa noa tenei.
//! Ko te whakaaro, ko te e taea ao tatou keteroki reira, ka whakamahi i te reira i waenganui i ngā waea ki te API, faka'ehi'ehi mei utu loads/unloads.
//! Ki te he te raruraru mo pūhohe turuturu te tahi mea rite e taea tatou whiti i te piriti, ina whiwhi tatou ki reira ranei tenei.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Me mahi tae atu ki te `SymGetOptions` me te `SymSetOptions` kaore i roto i te winapi.
// Ki te kore ka whakamahia tenei ka tirohia ana e taatau nga momo whakaari ki te winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Kaore ano kia tautuhia i roto i te winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Kua whakamaramahia tenei ki te winapi, engari he he (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Kaore ano kia tautuhia i roto i te winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Ka whakamahia tenei tonotono hei tautuhi i te hanganga `Dbghelp` kei roto katoa i nga tohu tohu mahi hei uta.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Ko te utaina DLL mō `dbghelp.dll`
            dll: HMODULE,

            // Ia atatohu mahi mo ia mahi ai tatou whakamahi
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // I te tīmatanga e kore i tatou utaina te DLL
            dll: 0 as *mut _,
            // Initiall ko nga mahi katoa kua whakatauhia ki te kore ki te kii me utaina kaha.
            //
            $($name: 0,)*
        };

        // Momo typedef mo ia momo mahi.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Ngana ki te whakatuwhera `dbghelp.dll`.
            /// Whakahoki ai i te angitu mena ka pai te mahi, ka hapa ranei mena ka kore te `LoadLibraryW`.
            ///
            /// Panics mena kua utaina te whare pukapuka.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Taumahi hoki ia tikanga hiahia ana tatou ki te whakamahi i.
            // Ka karangahia ka panui pea i te tohu tohu mahi keteroki ka utaina ranei ka whakahoki i te uara kua utaina.
            // Ka whakaputahia nga utaina kia angitu.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Haratau takawaenga hei whakamahi i nga raka horoi ki te whakahua i nga mahi dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Whakauruhia nga tautoko katoa kia uru ki nga mahi `dbghelp` API mai i tenei crate.
///
///
/// Note e tenei mahi, ko te haumaru ** **, reira ä he ona ake tukutahitanga.
/// Kia mahara hoki, he pai ki te karanga i tenei mahi i nga waa maha.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Ko te mea tuatahi me mahi e tatou te mahi tahi.Ka taea te huaina tahitia tenei i te tahi atu aho ranei recursively i roto i te kotahi miro.
        // Kia mahara he uaua ake i tera ahakoa na te mea e whakamahia ana e maatau i konei, `dbghelp`,*hoki* me mahi tahi me etahi atu kaiwaea ki `dbghelp` i tenei mahi.
        //
        // Ko te tikanga kaore i te tino nui nga piiraa ki `dbghelp` i roto i nga mahi kotahi a ka taea pea e tatou te kii ko tatou anake te whakauru atu.
        // Heoi, heoi ano, ko tetahi atu o nga kaiwhakamahi me awangawanga mo taatau ake, engari kei te whare pukapuka.
        // Ko te whare pukapuka paerewa Rust e pa ana ki tenei crate hei tautoko i te tuara o te hoki, ana ko tenei crate kei runga ano i te crates.io.
        // Ko te tikanga mena kei te taarua te whare pukapuka panic i te whare pukapuka paerewa tera pea ka reihi mai me tenei crate mai i crates.io, ka wehe nga waahanga.
        //
        // Ki te awhina whakaoti i tēnei raruraru tukutahitanga mahi tatou i te whakapati Windows-motuhake konei (ko reira, i muri i te katoa, he rāhuitanga Windows-motuhake e pā ana ki te tukutahitanga).
        // hanga tatou i te *ko mutex wātū-rohe* ki te tiaki i tenei karanga.
        // Ko te hiahia kei konei ko te wharepukapuka paerewa me tenei crate kaore e hiahia ki te tohatoha i nga API taumata-Rust ki te tuitui i konei engari ka taea te mahi i muri o nga whakaaturanga kia mohio kei te honohono tetahi ki tetahi.
        //
        // E ara, ka huaina tenei mahi ko roto i te whare pukapuka paerewa i roto i crates.io ranei e taea e tatou e mohio e te riro te mutex taua.
        //
        // Na koina katoa ko te kii ko te mea tuatahi e mahia ana e maatau i konei ka hangaia ngota e tatou he `HANDLE` he mutex te ingoa i runga i te Windows.
        // tukutahi tatou he moka ki ētahi atu aho te faaiteraa i tenei mahi āta, ka whakarite i hanga tetahi anake kakau e ia tauira o tenei mahi.
        // Kia mahara kaore e kati te kakau i te wa e rongoa ana i te ao.
        //
        // I muri i to taatau haere i te raka ka whiwhi noa tatou, a, ko ta tatou kakau `Init` ka tohaina e taangata ana ki te maka i te mutunga.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, pai!Na e e tatou tukutahitia humarie katoa, kia mau tīmata o te tukatuka mea katoa.
        // Tuatahi me maatau kia tino utaina te `dbghelp.dll` i roto i tenei mahi.
        // Ka mahia e maatau tenei mahi kia kore ai e whakawhirinaki tuturu.
        // I mahia tenei hei mahi i nga take honohono honohono ana kia kaha ake te kawe i nga whare pukapuka mai i te mea he mahi patuiro noa tenei.
        //
        //
        // Kia kua whakatuwheratia tatou `dbghelp.dll` e ti'a ia tatou ki te karanga i te tahi mau mahi arawhiti roto reira, a ka te ngā i atu i raro.
        // anake te mahi tatou i tenei kotahi, ahakoa, na kua ka tatou he pūreana ao tohu ranei e mahi matou ano e kore ranei.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Me whakarite kua whakatauhia te haki `SYMOPT_DEFERRED_LOADS`, na te mea e ai ki nga tuhinga a MSVC ake mo tenei: "This is the fastest, most efficient way to use the symbol handler.", na me mahi e!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Ko te tohu i nga tohu me te MSVC.Kia mahara ka ngoikore tenei, engari kaore taatau e aro.
        // Kaore he tone o nga toi o mua mo tenei, engari ko te LLVM o roto kaore i te aro ki te uara o te hokinga mai i konei a ko tetahi o nga wharepukapuka horoi horoi i te LLVM e taia ana he whakatupato whakamataku mena ka ngoikore tenei engari kaore e aro atu ki te waa roa.
        //
        //
        // Kotahi take tenei mai ake he rota mo Rust ko e te whare pukapuka paerewa me tenei crate runga crates.io e rua e hiahia ana ki te whakataetae mō te `SymInitializeW`.
        // Ko te wharepukapuka paerewa o mua i hiahia ki te arahi mai ka horoi i te nuinga o nga waa, engari inaianei kei te whakamahi i tenei crate te tikanga ka tae tuatahi tetahi ki te arawhiti ka riro ma tetahi atu e tango taua arawhiti.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}