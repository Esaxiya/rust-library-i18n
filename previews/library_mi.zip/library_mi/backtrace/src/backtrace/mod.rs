use core::ffi::c_void;
use core::fmt;

/// Ka tirotirohia te puranga piiraa-onāianei, ka tuku i nga papa hohe katoa ki te katinga kua tohaina ki te tatau i tetahi tohu taapiri
///
/// Ko tenei mahi te mahi mahi a tenei whare pukapuka ki te tatau i nga tohu taapiri mo tetahi hotaka.Ko te katinga homai `cb` tuku te wā o te `Frame` e tohu mōhiohio e pā ana ki taua anga karanga i runga i te tāpae.
/// tuku te katinga te papa i roto i te ahua runga ki raro-(tino tata i huaina mahi tuatahi).
///
/// uara hoki o te katinga ko te tohu o mehemea kia haere tonu te backtrace.Ko te uara whakahoki o `false` ka whakamutu i te hoki o muri ka hoki wawe mai.
///
/// Kia whiwhi `Frame` ka hiahia pea koe ki te waea `backtrace::resolve` ki te huri i te `ip` (tohu tohu) tohu korero ranei ki te `Symbol` e taea ai te ako te ingoa me te ingoa ingoa/ingoa raina ranei.
///
///
/// Kia mahara he mahi taumata-iti tenei mena ka hiahia koe, hei tauira, hopu i te tua whakamuri kia tirotirohia a muri ake, ka tika pea te momo `Backtrace`.
///
/// # Nga waahanga e hiahiatia ana
///
/// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
///
/// # Panics
///
/// Ka ngana tenei mahi kia kaua rawa e panic, engari mena i whakawhiwhia te `cb` ki te panics ka kaha etahi papa ki te akiaki i te panic takirua kia whakakorehia te kaupapa.
/// Ko etahi o nga papa e whakamahi ana i te whare pukapuka C kei roto e whakamahi ana i nga hokinga whakahoki kaore e taea te wetewete, na reira ko te paniko mai i te `cb` ka aukati i te waahanga ka whakakorehia.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // tonu te backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// He rite ki te `trace`, he haumaru noa na te mea kaore i te tukutahia.
///
/// Kaore he mana taurangi o tenei mahi engari ka waatea ka kore e whakauruhia te waahanga `std` o tenei crate.
/// Tirohia te mahi `trace` mo etahi atu tuhinga me nga tauira.
///
/// # Panics
///
/// Tirohia nga korero i te `trace` mo nga whakatupato i te `cb` awangawanga.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// He trait e tohu ana i tetahi anga o te tuara o muri, i tukuna ki te mahinga `trace` o tenei crate.
///
/// Ka katinga te mahi whakataki o te tuku papa, a kei te tata tonoa te anga rite kore e mohiotia tonu te whakatinanatanga whāriki tae noa ki wāhaere.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Whakahoki ai i te tohu tohutohu o tenei anga.
    ///
    /// Koinei noa nga tohutohu e whai ake nei hei whakamahi i te anga, engari kaore nga mahi katoa e rarangi ana me te 100% o te tika (engari he tata tino tata).
    ///
    ///
    /// E taunaki ana kia tukuna tenei uara ki te `backtrace::resolve` kia huri hei ingoa tohu.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Whakahoki ai i te tohu tohu o tenei anga.
    ///
    /// Mena kaore e taea e te tuauri te whakahoki mai i te tohu tohu mo tenei anga, ka whakahokia mai he tohu kore.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Whakahoki ai i te wahitau tohu tiimata o te anga o tenei mahi.
    ///
    /// Ka ngana tenei ki whakahoki te atatohu ako hoki e `ip` ki te tīmatanga o te mahi, e hoki i taua uara.
    ///
    /// I etahi wa, heoi, ko nga tuara ka whakahoki noa i te `ip` mai i tenei mahi.
    ///
    /// I etahi wa ka taea te whakamahi i te uara i whakahokia mai mena ka hapa te `backtrace::resolve` i te `ip` i runga ake nei.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Whakahoki ai i te wahitau turanga o te waahanga kei a ia te anga.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Ko te tikanga kia matua haere mai tenei, kia aata aro nui atu a Miriana ki runga i te kaupapa manaaki
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // whakamahia noa i te dbghelp tohu
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}