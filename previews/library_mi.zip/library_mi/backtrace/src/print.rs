#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// He whakatakotoranga mo nga tuara o muri.
///
/// Ka taea te whakamahi i tēnei momo ki te tā i te backtrace ahakoa o te wahi i te backtrace iho mai i.
/// Ki te whai koe i te momo `Backtrace` ka whakamahi kē tona whakatinanatanga `Debug` tenei hōputu tā.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Nga momo taarua ka taea e taatau te taarua
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Ka taarua i tetahi tua o muri ake nei me nga korero e tika ana
    Short,
    /// Ka taarua i te tua o muri e mau ana nga korero katoa ka taea
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Hangaia he `BacktraceFmt` hou ka tuhi i te putanga ki te `fmt` kua whakaritea.
    ///
    /// Ma te tautohe a `format` e whakahaere te taera e taia ai te tua o muri, a ka whakamahia te tohe `print_path` ki te taarua i nga waa ingoa `BytesOrWideString`.
    /// Kaore tenei momo e mahi i te taarua o nga ingoa ingoa, engari me whakahoki tenei waeatanga.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Ka taarua i te timatanga mo te tuara o muri e taia ai.
    ///
    /// E hiahiatia ana tenei i runga i etahi papa mo nga tuara kia tino tohu i muri mai, ana mena ko tenei noa te tikanga tuatahi ka waea atu koe i muri i to hanga `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Ka taapirihia he anga ki te putanga o muri.
    ///
    /// Ko tenei mahi ka whakahoki i te tauira RAII o te `BacktraceFrameFmt` ka taea te whakamahi ki te taarua i tetahi anga, a ka ngaro ka piki ake te kaaina anga.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Whakaoti i te putanga o muri.
    ///
    /// Ko te wā tenei he kore-op engari kua tapiritia hoki future hototahi ki ngā backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // I tenei wa kaore he mea-tae atu ki tenei hook kia ahei ai nga tapiritanga future.
        Ok(())
    }
}

/// He formatter mō te kotahi anga tika o te backtrace.
///
/// Ko tenei momo na te mahi `BacktraceFmt::frame` i hanga.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Ka taarua i te `BacktraceFrame` me tenei kaitahuri anga.
    ///
    /// Ka taarua tenei i nga waa `BacktraceSymbol` katoa i roto i te `BacktraceFrame`.
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Ka taarua i te `BacktraceSymbol` i roto i te `BacktraceFrame`.
    ///
    /// # Nga waahanga e hiahiatia ana
    ///
    /// Me whiwhi tēnei mahi te āhuatanga `std` o te `backtrace` crate ki kia whakahohea, ka whakahohea te āhuatanga `std` e taunoa.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: He kore nui tenei e kore tatou e mutu ake tā tetahi
            // me nga ingoa ingoa kore-utf8.
            // Aua'e tata katoa ko utf8 kia kore e tenei e rawa kino rawa.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Ka taarua i te `Frame` me te `Symbol` kua tirohia noa, mai i nga hokinga waeatanga o tenei crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Ka taapirihia he anga mata ki te putanga o muri.
    ///
    /// Ko tenei tikanga, kaore i rite ki nga korero o mua, ka mau ki nga tohetohe mena kei ahu mai ratou i nga waahi rereke.
    /// Kia mahara ka kiia pea he maha nga wa mo te anga kotahi.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Ka taapirihia he anga mata ki te putanga o muri, tae atu ki nga korero o te pou.
    ///
    /// Ko tenei tikanga, penei i nga korero o mua, ka mau ki nga tohetohe mena kei takea mai i etahi atu waahi.
    /// Kia mahara ka kiia pea he maha nga wa mo te anga kotahi.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Kaore e taea e Fuchsia te tohu i roto i tetahi waahanga na he ahuatanga motuhake ka taea te whakamahi hei tohu a muri ake.
        // Tuhia tera hei utu mo te taarua i nga wahitau ki ta maatau ake whakatakotoranga konei.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Kaore he take o te taarua i nga papa "null", ko te tikanga noa ko te hoki o te punaha i te tino hiahia ki te whai mai i tawhiti rawa atu.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Hei whakaheke i te rahi TCB i te Sgx enclave, kaore matou e hiahia ki te whakamahi i nga taumira taumira tohu.
        // 'I hono kehé, ka taea e tatou te tā i te Paraire o te wāhitau i konei, e taea te muri maheretia ki te mahi tika.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Taarua te taurangi o te anga tae atu ki te tohu tohu tohutohu mo te anga.
        // Mena kei tua atu o tatou te tohu tuatahi o tenei anga ahakoa ta taarua noa te waahi ma.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Muri iho tuhia te ingoa tohu, ma te whakamahi i te whakahuringa rereke mo etahi atu korero mena he tino tuara kei muri.
        // I konei hoki ka hapai i nga tohu kaore he ingoa,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Ka mutu ake, taia te nama filename/line mena kei te waatea ratou.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line E tāngia i runga i ngā rārangi i raro i te ingoa tohu, na tā etahi mokowāmā tika ki te kōmaka o matau-tiaro tatou.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Whiriwhiria ki to tatou hokiwaea ā-ki tā te ingoa kōnae, me te ka tā i te tau aho.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Taapirihia te nama pou, ki te waatea.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // anake tatou tiaki e pā ana ki te tohu tuatahi o te anga
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}