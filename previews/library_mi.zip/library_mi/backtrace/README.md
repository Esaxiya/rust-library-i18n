# backtrace-rs

[Documentation](https://docs.rs/backtrace)

He whare pukapuka mō te whiwhi backtraces i te wā mō te Rust.
Ko te whaainga o tenei wharepukapuka ki te whakarei ake i te tautoko o te wharepukapuka paerewa ma te whakarato i tetahi atanga papatono hei mahi, engari he pai noa te tuhi i te tuara o muri penei i te panics o te libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Hei hopu noa i te tua whakamuri me te whakaroa ki te mahi tae atu ki nga wa o muri, ka taea e koe te whakamahi i te momo `Backtrace` taumata-runga.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ki te, Heoi, e hiahia ana koe atu te uru raw ki te taumahinga tapiri tūturu, ka taea e koe te whakamahi i tika nga mahi `trace` me `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Whakatauhia tenei tohu tohu ki tetahi ingoa tohu
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // haere tonu ki te anga e whai ake nei
    });
}
```

# License

He raihana tenei kaupapa i raro i tetahi o

 * Raihana Apache, Putanga 2.0, ([LICENSE-APACHE](LICENSE-APACHE) me http://www.apache.org/licenses/LICENSE-2.0 ranei)
 * Raihana MIT ([LICENSE-MIT](LICENSE-MIT) or http://opensource.org/licenses/MIT ranei)

ki taau e pai ai.

### Contribution

Engari ki te kore e kii koe i nga korero rereke, ko nga takoha kua tono ngatahi kia whakauruhia ki roto i te backtrace-rs e koe, kua tautuhia ki te raihana Apache-2.0, me whai raihana takirua penei i runga ake nei, me te kore he whakaritenga, he here ranei







