#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Шинэ санах ойн агуулгыг эхлүүлээгүй болно.
    Uninitialized,
    /// Шинэ санах ойг тэглэх баталгаатай болно.
    Zeroed,
}

/// Булангийн бүх тохиолдлуудад санаа зоволгүйгээр овоолго дээрх санах ойн буферыг илүү эргономик байдлаар хуваарилах, дахин хуваарилах, хуваарилах бага түвшний хэрэгсэл.
///
/// Энэ төрөл нь Vec, VecDeque гэх мэт өөрийн өгөгдлийн бүтцийг бий болгоход маш сайн тохирдог.
/// Тухайлбал:
///
/// * `Unique::dangling()`-ийг тэг хэмжээтэй хэлбэрээр үйлдвэрлэдэг.
/// * Тэг урттай хуваарилалт дээр `Unique::dangling()` гаргадаг.
/// * `Unique::dangling()`-ийг суллахаас зайлсхийдэг.
/// * Бүх хүчин чадлын тооцооллыг халдаг ("capacity overflow" panics болгоно).
/// * isize::MAX байтаас илүү хуваарилах 32 битийн системээс хамгаалдаг.
/// * Таны уртыг халихаас хамгаална.
/// * Хуурамч хуваарилалтын талаар `handle_alloc_error` руу залгана.
/// * `ptr::Unique` агуулсан тул хэрэглэгчид холбогдох бүх ашиг тусыг өгдөг.
/// * Боломжтой хамгийн том хүчин чадлыг ашиглахын тулд хуваарилагчаас буцаж ирсэн илүүдлийг ашигладаг.
///
/// Энэ төрөл нь удирддаг санах ойг ямар ч тохиолдолд шалгахгүй.Үүнийг хаяхад *санах ойг* чөлөөлөх боловч агуулгыг нь унагаахыг хичээхгүй.
/// `RawVec` дотор байгаа *хадгалагдсан* бодит зүйлийг зохицуулах нь `RawVec`-ийн хэрэглэгчээс хамаарна.
///
/// Тэг хэмжээтэй илүүдэл нь үргэлж хязгааргүй байдаг тул `capacity()` үргэлж `usize::MAX` буцаадаг болохыг анхаарна уу.
/// `capacity()` нь уртыг авчрахгүй тул энэ төрлийг `Box<[T]>`-ээр дугуйруулахдаа болгоомжтой байх хэрэгтэй гэсэн үг юм.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Энэ нь `#[unstable]` `const fn`s нь `min_const_fn`-тэй тохирч байх шаардлагагүй тул тэдгээрийг"min_const_fn`s "-д дуудах боломжгүй тул байгаа юм.
    ///
    /// Хэрэв та `RawVec<T>::new` эсвэл хамаарлыг өөрчилбөл `min_const_fn`-ийг үнэхээр зөрчих зүйл оруулахгүй байхыг анхаарна уу.
    ///
    /// NOTE: Бид энэ хакердахаас зайлсхийж, `min_const_fn`-тэй нийцтэй байхыг шаарддаг зарим `#[rustc_force_min_const_fn]` атрибуттай нийцэж байгаа эсэхийг шалгаж болох боловч `stable(...) const fn` байгаа үед `stable(...) const fn`/хэрэглэгчийн кодоор дуудахыг зөвшөөрөхгүй.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Боломжит хамгийн том `RawVec`-ийг (системийн овоо дээр) хуваарилалгүйгээр үүсгэдэг.
    /// Хэрэв `T` нь эерэг хэмжээтэй бол `0` багтаамжтай `RawVec` болно.
    /// Хэрэв `T` тэг хэмжээтэй бол `usize::MAX` багтаамжтай `RawVec` болгодог.
    /// Хойшлогдсон хуваарилалтыг хэрэгжүүлэхэд хэрэгтэй.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]`-ийн хүчин чадал, тохируулгын яг шаардлагыг хангасан `RawVec` (системийн овоо дээр) үүсгэдэг.
    /// Энэ нь `capacity` нь `0` эсвэл `T` нь тэг хэмжээтэй байх үед `RawVec::new` руу залгасантай тэнцүү юм.
    /// Хэрэв `T` тэг хэмжээтэй бол хүссэн хүчин чадалтай `RawVec`-ийг авахгүй * гэсэн үг гэдгийг анхаарна уу.
    ///
    /// # Panics
    ///
    /// Хэрэв хүссэн багтаамж `isize::MAX` байтаас хэтэрвэл Panics.
    ///
    /// # Aborts
    ///
    /// OOM дээр цуцална.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` шиг, гэхдээ буферийг тэглэх баталгаа.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// `RawVec`-ийг заагч болон багтаамжаас сэргээнэ.
    ///
    /// # Safety
    ///
    /// `ptr`-ийг хуваарилах ёстой (системийн овоо дээр), өгөгдсөн `capacity`-тэй хамт.
    /// `capacity` нь хэмжээтэй төрлүүдийн хувьд `isize::MAX`-ээс хэтрэхгүй байх ёстой.(зөвхөн 32 битийн системтэй холбоотой асуудал).
    /// ZST vectors нь `usize::MAX` хүртэлх багтаамжтай байж болно.
    /// Хэрэв `ptr` ба `capacity` нь `RawVec`-ээс гаралтай бол энэ нь баталгаатай болно.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Бяцхан векүүд хэлгүй.Алгасах:
    // - Хэрэв элементийн хэмжээ 1 бол ямар ч овоо хуваарилагч 8 байтаас бага хүсэлтийг дор хаяж 8 байт болгон нэгтгэх магадлалтай тул 8.
    //
    // - 4 Хэрэв элементүүд дунд зэргийн хэмжээтэй бол (<=1 KiB).
    // - 1 Үгүй бол маш богино Vec-д хэт их зай зарцуулахаас зайлсхийх хэрэгтэй.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new`-тэй адил боловч буцаж ирсэн `RawVec`-ийн хуваарилагчийн сонголтоос параметрлэгдсэн.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" гэсэн үг.тэг хэмжээтэй төрлийг үл тоомсорлодог.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity`-тэй адил боловч буцаж ирсэн `RawVec`-ийн хуваарилагчийн сонголтоос параметрлэгдсэн.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed`-тэй адил боловч буцаж ирсэн `RawVec`-ийн хуваарилагчийн сонголтоос параметрлэгдсэн.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>`-ийг `RawVec<T>` болгон хөрвүүлдэг.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Заасан `len`-тэй буферийг бүхэлд нь `Box<[MaybeUninit<T>]>` болгон хөрвүүлдэг.
    ///
    /// Энэ нь хийгдсэн `cap` өөрчлөлтийг зөв сэргээж өгөх болно гэдгийг анхаарна уу.(Дэлгэрэнгүйг төрлийн тайлбараас харна уу.)
    ///
    /// # Safety
    ///
    /// * `len` хамгийн сүүлд хүссэн хэмжээнээс их эсвэл тэнцүү байх ёстой бөгөөд
    /// * `len` `self.capacity()`-ээс бага эсвэл тэнцүү байх ёстой.
    ///
    /// Хуваарилагч нь хэт хуваарилж, хүссэн хэмжээнээс илүү их санах ойн блок буцааж өгөх тул хүссэн багтаамж ба `self.capacity()` нь ялгаатай байж болохыг анхаарна уу.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Аюулгүй байдлын шаардлагын хагасыг эрүүл эсэхийг шалгана уу (бид нөгөө талыг нь шалгаж чадахгүй).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Энэ нь үүссэн LLVM IR хэмжээг ихэсгэдэг тул бид `unwrap_or_else`-ээс зайлсхийх болно.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Заагч, багтаамж, хуваарилагчаас `RawVec`-ийг сэргээнэ.
    ///
    /// # Safety
    ///
    /// `ptr`-ийг хуваарилсан байх ёстой (өгөгдсөн хуваарилагч `alloc`-ээр дамжуулж), өгөгдсөн `capacity`-тэй.
    /// `capacity` нь хэмжээтэй төрлүүдийн хувьд `isize::MAX`-ээс хэтрэхгүй байх ёстой.
    /// (зөвхөн 32 битийн системтэй холбоотой асуудал).
    /// ZST vectors нь `usize::MAX` хүртэлх багтаамжтай байж болно.
    /// Хэрэв `ptr` ба `capacity` нь `alloc`-ээр бүтээгдсэн `RawVec`-ээс гарвал энэ нь баталгаатай болно.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Хуваарилалтын эхэнд түүхий заагчийг авдаг.
    /// Хэрэв `capacity == 0` эсвэл `T` тэг хэмжээтэй бол энэ нь `Unique::dangling()` болохыг анхаарна уу.
    /// Эхний тохиолдолд та анхааралтай байх ёстой.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Хуваарилалтын хүчин чадлыг олж авдаг.
    ///
    /// Хэрэв `T` тэг хэмжээтэй бол энэ нь үргэлж `usize::MAX` байх болно.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Энэхүү `RawVec`-ийг дэмжиж буй хуваарилагчийн хуваалцсан лавлагааг буцаана.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Бидэнд санах ойн хуваарилагдсан хэсэг байгаа тул одоогийн байршлыг олж авахын тулд ажиллах хугацааны шалгалтыг алгасаж болно.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Буфер нь `len + additional` элементүүдийг багтаахад дор хаяж хангалттай зай агуулсан байхыг баталгаажуулдаг.
    /// Хэрэв энэ нь хангалттай багтаамжтай биш бол хорогдуулсан *O*(1) горимыг авахын тулд хангалттай зай, тохь тухтай сул орон зайг дахин хуваарилах болно.
    ///
    /// Хэрэв энэ нь өөрийгөө panic-д хүргэх шалтгаангүй бол энэ зан үйлийг хязгаарлах болно.
    ///
    /// Хэрэв `len` нь `self.capacity()`-ээс хэтэрвэл энэ нь хүссэн зайг бодитоор хуваарилж чадахгүй байж магадгүй юм.
    /// Энэ нь үнэхээр аюултай биш боловч энэ функцын зан төлөвт суурилсан * таны бичсэн аюулгүй код эвдэрч магадгүй юм.
    ///
    /// Энэ нь `extend` шиг бөөнөөр түлхэх ажиллагааг хэрэгжүүлэхэд тохиромжтой юм.
    ///
    /// # Panics
    ///
    /// Хэрэв шинэ хүчин чадал `isize::MAX` байтаас хэтэрвэл Panics.
    ///
    /// # Aborts
    ///
    /// OOM дээр цуцална.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // Хэрэв линз `isize::MAX`-ээс хэтэрсэн бол нөөцийг цуцлах эсвэл сандрах байсан тул үүнийг одоо шалгахгүйгээр хийх нь аюулгүй юм.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve`-тэй адил боловч сандарч, үр хөндүүлэхийн оронд алдаагаа буцаадаг.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Буфер нь `len + additional` элементүүдийг багтаахад дор хаяж хангалттай зай агуулсан байхыг баталгаажуулдаг.
    /// Хэрэв энэ нь хийгдээгүй бол шаардлагатай хамгийн бага санах ойн хэмжээг дахин хуваарилах болно.
    /// Ерөнхийдөө энэ нь шаардлагатай санах ойн хэмжээ байх болно, гэхдээ зарчмын хувьд хуваарилагч нь бидний хүссэнээс илүү их зүйлийг буцааж өгөх боломжтой.
    ///
    ///
    /// Хэрэв `len` нь `self.capacity()`-ээс хэтэрвэл энэ нь хүссэн зайг бодитоор хуваарилж чадахгүй байж магадгүй юм.
    /// Энэ нь үнэхээр аюултай биш боловч энэ функцын зан төлөвт суурилсан * таны бичсэн аюулгүй код эвдэрч магадгүй юм.
    ///
    /// # Panics
    ///
    /// Хэрэв шинэ хүчин чадал `isize::MAX` байтаас хэтэрвэл Panics.
    ///
    /// # Aborts
    ///
    /// OOM дээр цуцална.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact`-тэй адил боловч сандарч, үр хөндүүлэхийн оронд алдаагаа буцаадаг.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Тодорхойлсон хэмжээгээр хуваарилалтыг багасгадаг.
    /// Хэрэв өгөгдсөн хэмжээ 0 бол бүрэн хуваарилагдана.
    ///
    /// # Panics
    ///
    /// Хэрэв өгөгдсөн хэмжээ нь одоогийн хүчин чадлаас *их* байвал Panics.
    ///
    /// # Aborts
    ///
    /// OOM дээр цуцална.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Шаардлагатай нэмэлт хүчин чадлыг хангахын тулд буфер өсөх шаардлагатай бол буцаана.
    /// `grow`-ийг доторлогоогүйгээр дуудлага хийх боломжтой.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Энэ аргыг ихэвчлэн олон удаа хийдэг.Тиймээс бид эмхэтгэх цаг хугацааг сайжруулахын тулд аль болох бага байхыг хүсч байна.
    // Гэхдээ бид түүний агуулгыг аль болох статикаар тооцоолох боломжтой болгож, үүсгэсэн кодыг илүү хурдан ажиллуулахыг хүсч байна.
    // Тиймээс энэ аргыг `T`-ээс хамааралтай бүх кодууд дотор нь байхаар болгоомжтой бичсэн бөгөөд аль болох `T`-ээс хамааралгүй кодын ихэнх нь `T`-ээс илүү ерөнхий бус функцууд байдаг.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Энэ нь дуудлагын контекстээр хангагдсан байдаг.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` байх үед бид `usize::MAX` хүчин чадлыг буцааж өгдөг
            // 0, энд хүрэх нь `RawVec` хэт их байна гэсэн үг юм.
            return Err(CapacityOverflow);
        }

        // Эдгээр шалгалтын талаар бид үнэхээр юу ч хийж чадахгүй нь харамсалтай.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Энэ нь экспоненциаль өсөлтийг баталгаажуулдаг.
        // `cap <= isize::MAX` ба `cap` төрөл нь `usize` тул хоёр дахин нэмэгдэх боломжгүй юм.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` нь `T`-ээс илүү ерөнхий биш юм.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Энэ аргын хязгаарлалт нь `grow_amortized`-тэй адилхан боловч энэ аргыг ихэвчлэн бага ашигладаг тул шүүмжлэл багатай байдаг.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Хэмжээ нь тохирсон үед бид `usize::MAX` хүчин чадлыг буцааж өгдөг
            // 0, энд хүрэх нь `RawVec` хэт их байна гэсэн үг юм.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` нь `T`-ээс илүү ерөнхий биш юм.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Энэ функц нь хөрвүүлэх хугацааг багасгахын тулд `RawVec`-ээс гадуур байрладаг.Дэлгэрэнгүйг `RawVec::grow_amortized` дээрх тайлбараас үзнэ үү.
// (`A` параметр нь ач холбогдолгүй, яагаад гэвэл практик дээр ажиглагдсан `A` төрлийн тоо `T` төрлөөс хамаагүй бага байдаг.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*`-ийн хэмжээг багасгахын тулд энд байгаа алдааг шалгана уу.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Хуваарилагч тэгшитгэлийн тэгш байдлыг шалгадаг
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Агуулгыг нь унагаахгүйгээр `RawVec` * төхөөрөмжийн эзэмшдэг санах ойг чөлөөлнө.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Нөөцийн алдаатай харьцах төв функц.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Бид дараахь зүйлийг баталгаажуулах хэрэгтэй.
// * Бид хэзээ ч `> isize::MAX` байтын хэмжээтэй объект хуваарилдаггүй.
// * Бид `usize::MAX`-ээс хэтрэхгүй бөгөөд маш бага хэмжээгээр хуваарилдаг.
//
// 64-бит дээр бид хэт халсан эсэхийг шалгах хэрэгтэй, яагаад гэвэл `> isize::MAX` байтыг хуваарилах оролдлого бүтэлгүйтэх болно.
// 32 бит ба 16 бит дээр хэрэглэгчийн орон зайд бүх 4GB ашиглах боломжтой платформ дээр ажиллаж байгаа тохиолдолд бид нэмэлт хамгаалагч нэмэх хэрэгтэй. Жишээ нь PAE эсвэл x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Тооцоолох чадварыг даван туулах үүрэгтэй нэг төв функц.
// Эдгээр panics-тэй холбоотой код үүсгэх нь хамгийн бага байх тул модуль даяар багц биш panics гэсэн ганц л байршил байдаг.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}