use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Эх үүсвэрийн хуваарилалтыг дахин ашиглах үед давталтын дамжуулах хоолойг Vec руу цуглуулах мэргэшсэн тэмдэглэгээ, өөрөөр хэлбэл
/// дамжуулах хоолойг газар дээр нь гүйцэтгэж байна.
///
/// SourceIter parent trait нь дахин ашиглах хуваарилалтад нэвтрэхэд мэргэшсэн функцэд шаардлагатай байдаг.
/// Гэхдээ мэргэшсэн байх нь хангалтгүй юм.
/// Нэвтрүүлгийн нэмэлт хязгаарыг харна уу.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-дотоод SourceIter/InPlaceIterable traits нь зөвхөн Adapter гинжээр хэрэгждэг. <Adapter<Adapter<IntoIter>>> (бүгдийг нь core/std эзэмшдэг).
// Адаптерийн хэрэгжилтийн нэмэлт хязгаарууд (`impl<I: Trait> Trait for Adapter<I>`-ээс цааш) зөвхөн traits мэргэшсэн гэж тэмдэглэгдсэн бусад traits-ээс хамаарна (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. маркер нь хэрэглэгчийн нийлүүлсэн төрлүүдийн ашиглалтын хугацаанаас хамаардаггүй.Бусад хэд хэдэн мэргэжлүүд аль хэдийнэ хамааралтай байдаг Хуулбарлах нүхний модулийг.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bounds-ээр илэрхийлэх боломжгүй нэмэлт шаардлага.Үүний оронд бид const үнэлгээнд найдаж байна:
        // a) дахин ашиглахад хуваарилалт байхгүй тул ZST байхгүй бөгөөд заагч арифметик нь panic байх болно b) хэмжээ нь Alloc гэрээний дагуу тохирно c) Alloc гэрээний дагуу тохируулга таарч байна
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // илүү нийтлэг хэрэгжүүлэлтүүдийн уналт
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // оноос хойш дахин ашиглах
        // - Энэ нь зарим давталтын адаптеруудад илүү сайн вектор болдог
        // - ихэнх дотоод давталтын аргуудаас ялгаатай нь зөвхөн &mut өөрөө хийгддэг
        // - Энэ нь бичих заагчийг гэдэс дотрыг нь дамжуулж, эцэст нь буцааж авах боломжийг бидэнд олгодог
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // давталт амжилттай болсон тул толгойгоо бүү уна
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // SourceIter-ийн гэрээг дагаж мөрдөж байсан эсэхийг шалгаарай: хэрэв тэд биш байсан бол бид өдий хүртэл хүрч чадахгүй байж магадгүй юм
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIterable гэрээ шалгах.Энэ нь давтагч эх заагчийг бүхэлд нь сайжруулсан тохиолдолд л боломжтой юм.
        // Хэрэв энэ нь TrustedRandomAccess-ээр шалгагдаагүй хандалтыг ашигладаг бол эх заагч анхны байрлалдаа үлдэх бөгөөд бид үүнийг лавлагаа болгон ашиглах боломжгүй болно.
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // үлдсэн утгыг эх үүсвэрийн сүүл рүү унагаах боловч IntoIter нь panics уналтанд орвол хуваарилалт өөрөө унахаас сэргийлнэ, дараа нь dst_buf-д цуглуулсан элементүүд алдагдах болно.
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable гэрээг яг энд баталгаажуулах боломжгүй тул try_fold нь зөвхөн эх заагчийн талаар тусгай лавлагаа өгөх боломжтой бөгөөд энэ нь хязгаарлалтад байгаа эсэхийг шалгах явдал юм.
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}