use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter-д ашигладаг төрөлжсөн trait
///
/// ## Төлөөлөгчдийн график:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Нийтлэг тохиолдол бол vector-ийг шууд дахин цуглуулдаг функцэд vector дамжуулах явдал юм.
        // Хэрэв IntoIter огт хөгжөөгүй бол бид үүнийг богино холболтоор дамжуулж болно.
        // Сайжруулсан үед бид санах ойг дахин ашиглаж, өгөгдлийг урд тал руу нь шилжүүлж болно.
        // Үүний үр дүнд бий болсон Vec нь FromIterator-ийн ерөнхий хэрэгжилтээр бий болгохоос илүү ашиглагдаагүй хүчин чадал байхгүй үед л бид үүнийг хийдэг.
        //
        // Vec-ийн хуваарилалтын зан үйлийг санаатайгаар тодорхойлоогүй тул энэ хязгаарлалт нь хатуу шаардлагагүй юм.
        // Гэхдээ энэ бол консерватив сонголт юм.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // spec_extend()-д төлөөлөх ёстой, учир нь extend() өөрөө хоосон Vecs-ийн хувьд spec_from-д шилжүүлдэг
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Энэ нь `iterator.as_slice().to_vec()`-ийг ашигладаг тул spec_extend нь эцсийн хүчин чадал + уртын талаар илүү олон алхам хийж, илүү их ажил хийх ёстой.
// `to_vec()` зөв хэмжээг шууд хуваарилж, яг дүүргэдэг.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test)-тэй хамт энэ аргыг тодорхойлоход шаардагдах уламжлалт `[T]::to_vec` арга байхгүй байна.
    // Үүний оронд зөвхөн cfg(test) NB дээр ашиглах боломжтой `slice::to_vec` функцийг ашиглаарай. slice.rs дахь slice::hack модулийг үзнэ үү.
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}