//! `Vec<T>` гэж бичсэн, нуруулдан хуваарилагдсан агуулгатай, зэргэлдээ томрох массив төрөл.
//!
//! Vectors нь `O(1)` индексжүүлэлт, хорогдуулсан `O(1)` түлхэлт (төгсгөл хүртэл) ба `O(1)` поп (төгсгөлөөс).
//!
//!
//! Vectors нь хэзээ ч `isize::MAX` байтаас илүү хуваарилахгүй байхыг баталгаажуулдаг.
//!
//! # Examples
//!
//! Та [`Vec::new`]-тай [`Vec`]-ийг шууд үүсгэж болно:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... эсвэл [`vec!`] макро ашиглан:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // арван тэг
//! ```
//!
//! Та [`push`] утгыг vector-ийн төгсгөлд хийж болно (шаардлагатай бол vector-ийг өсгөх болно):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping утгууд ижил төстэй байдлаар ажилладаг:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors нь индексжүүлэлтийг ([`Index`] ба [`IndexMut`] traits-ээр дамжуулан) дэмждэг.
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// `Vec<T>` гэж бичигдсэн ба 'vector' гэж тодорсон зэргэлдээ томрох массив төрөл.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] макро нь эхлүүлэх ажлыг илүү тохь тухтай байлгах үүднээс өгдөг.
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Энэ нь өгөгдсөн утга бүхий `Vec<T>` элемент бүрийг эхлүүлж болно.
/// Энэ нь хуваарилалт, эхлүүлэлтийг тусад нь алхам хийхээс илүү үр дүнтэй байж болох юм, ялангуяа vector тэгийг эхлүүлэх үед:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Дараахь нь тэнцүү боловч удаан байж болзошгүй:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Дэлгэрэнгүй мэдээллийг [Capacity and Reallocation](#capacity-and-reallocation)-с үзнэ үү.
///
/// `Vec<T>`-ийг үр дүнтэй стек болгон ашигла:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // 3, 2, 1 хэвлэнэ
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` төрөл нь [`Index`] trait-ийг хэрэгжүүлдэг тул утгад индексээр хандах боломжийг олгодог.Жишээ нь илүү тодорхой байх болно:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // энэ нь '2'-ийг харуулах болно
/// ```
///
/// Гэсэн хэдий ч болгоомжтой байгаарай: хэрэв та `Vec`-т байхгүй индекс рүү нэвтрэхийг оролдвол таны програм panic болно!Та үүнийг хийж чадахгүй:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Индекс `Vec`-т байгаа эсэхийг шалгахыг хүсвэл [`get`] ба [`get_mut`]-ийг ашиглаарай.
///
/// # Slicing
///
/// `Vec` нь өөрчлөгдөх боломжтой.Нөгөөтэйгүүр, зүсмэлүүд нь зөвхөн унших боломжтой объект юм.
/// [slice][prim@slice] авахын тулд [`&`] ашиглана уу.Жишээ:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... тэгээд л боллоо!
/// // та үүнийг дараах байдлаар хийж болно:
/// let u: &[usize] = &v;
/// // эсвэл үүнтэй адил:
/// let u: &[_] = &v;
/// ```
///
/// Rust дээр зөвхөн унших хандалтыг өгөхийг хүсч байхад vectors гэхээсээ илүү зүсмэлүүдийг аргумент болгон дамжуулах нь илүү түгээмэл байдаг.[`String`] ба [`&str`]-т мөн адил хамаарна.
///
/// # Чадавхи ба дахин хуваарилалт
///
/// vector-ийн багтаамж нь vector дээр нэмэх future элементүүдэд хуваарилагдах орон зайн хэмжээ юм.Үүнийг vector доторх бодит элементийн тоог тодорхойлсон vector-ийн *урт*-тай андуурч болохгүй.
/// Хэрэв vector-ийн урт нь багтаамжаас хэтэрвэл түүний багтаамж автоматаар нэмэгдэх боловч элементүүдийг нь дахин хуваарилах шаардлагатай болно.
///
/// Жишээлбэл, 10 багтаамжтай, 0 урттай vector нь 10 элементийн багтаамжтай хоосон vector байх болно.10 ба түүнээс цөөн элементийг vector руу түлхэхэд түүний хүчин чадал өөрчлөгдөхгүй эсвэл дахин хуваарилалт үүсэхгүй.
/// Гэхдээ vector-ийн уртыг 11 болгож өсгөвөл дахин хуваарилах шаардлагатай болох бөгөөд энэ нь удааширч болзошгүй юм.Энэ шалтгааны улмаас vector хэр их хэмжээ авахыг зааж өгөхдөө [`Vec::with_capacity`] ашиглахыг зөвлөж байна.
///
/// # Guarantees
///
/// `Vec` нь гайхалтай үндсэн шинж чанараараа дизайныхаа талаар маш их баталгаа өгдөг.Энэ нь ерөнхий тохиолдолд аль болох бага ачаатай байх, аюулгүй кодоор командын аргаар зөв зохицуулах боломжийг олгодог.Эдгээр баталгаа нь чадваргүй `Vec<T>`-т хамааралтай болохыг анхаарна уу.
/// Хэрэв нэмэлт төрлийн параметрүүдийг нэмж оруулбал (жишээлбэл, гаалийн хуваарилагчийг дэмжих зорилгоор), тэдгээрийн анхдагч утгыг хүчингүй болгох нь тухайн үйлдлийг өөрчилж магадгүй юм.
///
/// Хамгийн үндсэндээ `Vec` нь (заагч, багтаамж, урт) гурвалсан бөгөөд үргэлж байх болно.Илүү их, багагүй.Эдгээр талбаруудын дараалал нь бүрэн тодорхойлогдоогүй тул эдгээрийг өөрчлөхийн тулд зохих аргыг ашиглах хэрэгтэй.
/// Заагч хэзээ ч null байх тул энэ төрөл null-pointer-ийг оновчтой болгоно.
///
/// Гэхдээ заагч нь үнэндээ хуваарилагдсан санах ой руу чиглээгүй байж магадгүй юм.
/// Тодруулбал, хэрэв та [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`]-ээр 0 хүчин чадалтай `Vec`-ийг бүтээх юмуу эсвэл хоосон Vec дээр [`shrink_to_fit`] руу залгах юм бол санах ой хуваарилахгүй.Үүнтэй адил, хэрэв та `Vec` дотор тэг хэмжээтэй төрлийг хадгалах юм бол тэдэнд зай хуваарилахгүй.
/// *Энэ тохиолдолд `Vec` нь [`capacity`]-ийг 0* гэж мэдээлэхгүй байж болохыг анхаарна уу.
/// `Vec` хэрэв ["mem: : size_of::" тохиолдолд л хуваарилна.<T>`]` () * capacity()> 0`.
/// Ерөнхийдөө `Vec`-ийн хуваарилалтын талаархи мэдээлэл маш нарийн байдаг.Хэрэв та `Vec` ашиглан санах ойг хуваарилаад өөр зүйлд ашиглах гэж байгаа бол (аюултай код руу дамжуулах эсвэл өөрийн санах ойтой цуглуулгыг бий болгох). энэ санах ойг `from_raw_parts`-ийг ашиглан `Vec`-ийг сэргээж дараа нь буулгах замаар хуваарилах.
///
/// Хэрэв `Vec`*-т* санах ой хуваарилагдсан бол зааж өгсөн санах ой нь овоо дээр байна (хуваарилагч Rust-ийн тодорхойлсноор анхдагчаар ашиглахаар тохируулагдсан) ба заагч нь [`len`]-ийн эхлүүлсэн, зэргэлдээ элементүүдийг дарааллаар нь зааж өгнө (та юу хийх вэ? Хэрэв та үүнийг зүсэж шахсан бол), дараа нь [`багтаамж ']`, `[` len`] логик байдлаар эхлүүлээгүй, зэргэлдээ элементүүдийг оруулна уу.
///
///
/// 4 багтаамжтай `'a'` ба `'b'` элементүүдийг агуулсан vector-ийг доор харуулав.Дээд хэсэг нь `Vec` бүтэц бөгөөд энэ нь овоо, урт, багтаамжийн хуваарилалтын толгой руу заагчийг агуулна.
/// Доод хэсэг нь овоолгын хуваарилалт, зэргэлдээ санах ойн блок юм.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** нь эхлүүлээгүй санах ойг илэрхийлнэ, [`MaybeUninit`]-г үзнэ үү.
/// - Note: ABI нь тогтвортой биш бөгөөд `Vec` нь санах ойн байршлын талаар ямар ч баталгаа өгдөггүй (талбаруудын дарааллыг оруулаад).
///
/// `Vec` элементүүдийг стек дээр хоёр шалтгаанаар хадгалдаг "small optimization"-ийг хэзээ ч хийхгүй.
///
/// * Аюулгүй код нь `Vec`-ийг зөв удирдахад илүү хэцүү байх болно.`Vec`-ийн агуулгыг зөвхөн зөөвөрлөхөд тогтвортой хаяггүй байх байсан бөгөөд `Vec` нь санах ойг үнэхээр хуваарилсан эсэхийг тодорхойлоход илүү хэцүү байх болно.
///
/// * Энэ нь нэвтрэх болгонд нэмэлт branch гарган ерөнхий хэргийг шийтгэх болно.
///
/// `Vec` бүрэн хоосон байсан ч хэзээ ч өөрөө аяндаа багасахгүй.Энэ нь шаардлагагүй хуваарилалт, хуваарилалт гарахгүй байхыг баталгаажуулдаг.`Vec`-ийг хоослох, дараа нь ижил [`len`]-д дахин дүүргэх нь хуваарилагч руу дуудлага хийх шаардлагагүй.Хэрэв та ашиглагдаагүй санах ойг суллахыг хүсвэл [`shrink_to_fit`] эсвэл [`shrink_to`]-ийг ашиглаарай.
///
/// [`push`] хэрэв мэдээлэгдсэн хүчин чадал хангалттай бол [`insert`] хэзээ ч (дахин) хуваарилахгүй.[`push`] ба [`insert`]*нь [(len`]`==`[`багтаамж`] бол*(дахин) хуваарилах болно.Энэ нь тайлагнасан хүчин чадал нь бүрэн зөв бөгөөд үүнд найдаж болно гэсэн үг юм.Хэрэв та хүсвэл `Vec`-ээс хуваарилагдсан санах ойг гар аргаар чөлөөлөхөд ашиглаж болно.
/// Бөөнөөр оруулах арга *шаардлагагүй* байсан ч дахин хуваарилагдаж болно.
///
/// `Vec` дүүрсэн үед дахин хуваарилалт хийх эсвэл [`reserve`] дуудагдах үед өсөлтийн тодорхой стратегийг баталгаажуулахгүй.Одоогийн стратеги нь үндсэн суурь бөгөөд тогтмол бус өсөлтийн хүчин зүйлийг ашиглах нь зүйтэй болов уу.Ямар ч стратеги ашиглаж байсан нь мэдээж *O*(1) хорогдуулсан [`push`] баталгаатай байх болно.
///
/// `vec![x; n]`, `vec![a, b, c, d]` ба [`Vec::with_capacity(n)`][`Vec::with_capacity`] нь бүгд яг хүссэн хэмжээтэй `Vec` үйлдвэрлэх болно.
/// Хэрэв [`len`]`==`[`багтаамж`], ([`vec!`] макроны хувьд) бол `Vec<T>`-ийг элементүүдийг дахин хуваарилах, шилжүүлэхгүйгээр [`Box<[T]>`][owned slice] болгон хөрвүүлэх боломжтой.
///
/// `Vec` үүнээс хасагдсан өгөгдлийг тусгайлан дарж бичихгүй, гэхдээ тусгайлан хадгалахгүй.Түүний эхлүүлээгүй санах ой нь хүссэн зураасаа ашиглаж болох зурлага юм.Энэ нь ерөнхийдөө хамгийн үр дүнтэй эсвэл хэрэгжүүлэхэд хялбар бүх зүйлийг хийх болно.Аюулгүй байдлын үүднээс устгасан өгөгдөлд найдаж болохгүй.
/// Та `Vec` хаясан ч гэсэн түүний буферыг өөр `Vec` дахин ашиглах боломжтой байж магадгүй юм.
/// Хэрэв та эхлээд "Vec"-ийн санах ойг тэглэсэн ч гэсэн энэ нь үнэндээ ийм байж чадахгүй, учир нь оновчлогч үүнийг хадгалах ёстой гаж нөлөө гэж үзэхгүй.
/// Гэхдээ бид эвдэхгүй нэг тохиолдол байдаг: илүүдэл хүчин чадал дээр `unsafe` кодыг бичээд дараа нь тохирох уртыг нэмэгдүүлэх нь үргэлж хүчинтэй байдаг.
///
/// Одоогийн байдлаар `Vec` нь элемент унах дарааллыг баталгаажуулдаггүй.
/// Захиалга өнгөрсөн хугацаанд өөрчлөгдсөн тул дахин өөрчлөгдөж магадгүй юм.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Уламжлалт аргууд
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Шинэ, хоосон `Vec<T>` бүтээдэг.
    ///
    /// vector нь элементүүдийг түлхэх хүртэл хуваарилахгүй.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Тодорхойлсон хүчин чадалтай шинэ, хоосон `Vec<T>` бүтээдэг.
    ///
    /// vector нь яг `capacity` элементүүдийг дахин хуваарилахгүйгээр хадгалах боломжтой болно.
    /// Хэрэв `capacity` нь 0 бол vector нь хуваарилагдахгүй.
    ///
    /// Буцааж өгсөн vector нь *хүчин чадлыг* заасан боловч vector нь тэг *урттай* байх болно гэдгийг анхаарах нь чухал юм.
    ///
    /// Урт ба багтаамжийн ялгааны талаархи тайлбарыг *[Чадавхи ба дахин хуваарилалт]* хэсгээс авна уу.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector нь илүү их багтаамжтай ч гэсэн ямар ч зүйл агуулаагүй болно
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Эдгээрийг бүгдийг нь хуваарилалгүйгээр хийдэг ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... гэхдээ энэ нь vector-ийг дахин хуваарилахад хүргэж болзошгүй юм
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Өөр vector-ийн түүхий эдээс шууд `Vec<T>` үүсгэдэг.
    ///
    /// # Safety
    ///
    /// Энэ нь шалгагдаагүй хувьсагчийн тоогоор маш аюултай юм.
    ///
    /// * `ptr` өмнө нь [`String`]/`Vec-ээр хуваарилагдсан байх шаардлагатай<T>"(ядаж тийм биш байсан бол буруу байх магадлал өндөр).
    /// * `T` нь `ptr`-т хуваарилагдсан хэмжээтэй ижил хэмжээтэй байх ёстой.
    ///   (`T` нь арай бага зэрэгцүүлэлттэй байх нь хангалтгүй тул санах ойг ижил байрлалаар хуваарилж, хуваарилах ёстой гэсэн [`dealloc`] шаардлагыг хангахын тулд тохируулга нь үнэхээр тэнцүү байх ёстой.)
    ///
    /// * `length` `capacity`-ээс бага эсвэл тэнцүү байх шаардлагатай.
    /// * `capacity` заагчийн хуваарилсан багтаамж байх шаардлагатай.
    ///
    /// Эдгээрийг зөрчих нь хуваарилагчийн дотоод өгөгдлийн бүтцийг эвдэх гэх мэт асуудал үүсгэж болзошгүй юм.Жишээлбэл, заагчаас `size_t` урттай C `char` массив руу `Vec<u8>` бүтээх нь ** аюулгүй биш юм.
    /// Түүнчлэн `Vec<u16>` ба түүний уртаас нэгийг бүтээх нь аюулгүй биш юм, учир нь хуваарилагч нь тохируулгын талаар санаа тавьдаг бөгөөд эдгээр хоёр төрөл нь өөр өөр тохируулгатай байдаг.
    /// Буферийг 2-р эгнээнд хуваарилсан (`u16`-ийн хувьд), гэхдээ `Vec<u8>` болгосны дараа 1-р эгнээнд хуваарилагдах болно.
    ///
    /// `ptr`-ийн өмчлөл нь `Vec<T>`-д үр дүнтэй шилждэг бөгөөд ингэснээр дурын дагуу зааж өгсөн санах ойн агуулгыг хуваарилах, дахин хуваарилах эсвэл өөрчлөх боломжтой.
    /// Энэ функцийг дуудсаны дараа заагчийг өөр зүйл ашиглахгүй байхыг баталгаажуулна уу.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME vec_into_raw_parts тогтворжсон үед үүнийг шинэчлэх.
    ///     // `V`-ийн устгагчийг ажиллуулахаас сэргийлж хуваарилалтыг бид бүрэн хянах болно.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v`-ийн талаархи янз бүрийн чухал мэдээллийг сугалж ав
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // 4, 5, 6-тай санах ойг дарж бичих
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Бүх зүйлийг Vec-д буцааж оруулаарай
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Шинэ, хоосон `Vec<T, A>` бүтээдэг.
    ///
    /// vector нь элементүүдийг түлхэх хүртэл хуваарилахгүй.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Өгөгдсөн хуваарилагчаар заасан хүчин чадалтай шинэ, хоосон `Vec<T, A>`-ийг барина.
    ///
    /// vector нь яг `capacity` элементүүдийг дахин хуваарилахгүйгээр хадгалах боломжтой болно.
    /// Хэрэв `capacity` нь 0 бол vector нь хуваарилагдахгүй.
    ///
    /// Буцааж өгсөн vector нь *хүчин чадлыг* заасан боловч vector нь тэг *урттай* байх болно гэдгийг анхаарах нь чухал юм.
    ///
    /// Урт ба багтаамжийн ялгааны талаархи тайлбарыг *[Чадавхи ба дахин хуваарилалт]* хэсгээс авна уу.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector нь илүү их багтаамжтай ч гэсэн ямар ч зүйл агуулаагүй болно
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Эдгээрийг бүгдийг нь хуваарилалгүйгээр хийдэг ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... гэхдээ энэ нь vector-ийг дахин хуваарилахад хүргэж болзошгүй юм
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Өөр vector-ийн түүхий эдээс шууд `Vec<T, A>` үүсгэдэг.
    ///
    /// # Safety
    ///
    /// Энэ нь шалгагдаагүй хувьсагчийн тоогоор маш аюултай юм.
    ///
    /// * `ptr` өмнө нь [`String`]/`Vec-ээр хуваарилагдсан байх шаардлагатай<T>"(ядаж тийм биш байсан бол буруу байх магадлал өндөр).
    /// * `T` нь `ptr`-т хуваарилагдсан хэмжээтэй ижил хэмжээтэй байх ёстой.
    ///   (`T` нь арай бага зэрэгцүүлэлттэй байх нь хангалтгүй тул санах ойг ижил байрлалаар хуваарилж, хуваарилах ёстой гэсэн [`dealloc`] шаардлагыг хангахын тулд тохируулга нь үнэхээр тэнцүү байх ёстой.)
    ///
    /// * `length` `capacity`-ээс бага эсвэл тэнцүү байх шаардлагатай.
    /// * `capacity` заагчийн хуваарилсан багтаамж байх шаардлагатай.
    ///
    /// Эдгээрийг зөрчих нь хуваарилагчийн дотоод өгөгдлийн бүтцийг эвдэх гэх мэт асуудал үүсгэж болзошгүй юм.Жишээлбэл, заагчаас `size_t` урттай C `char` массив руу `Vec<u8>` бүтээх нь ** аюулгүй биш юм.
    /// Түүнчлэн `Vec<u16>` ба түүний уртаас нэгийг бүтээх нь аюулгүй биш юм, учир нь хуваарилагч нь тохируулгын талаар санаа тавьдаг бөгөөд эдгээр хоёр төрөл нь өөр өөр тохируулгатай байдаг.
    /// Буферийг 2-р эгнээнд хуваарилсан (`u16`-ийн хувьд), гэхдээ `Vec<u8>` болгосны дараа 1-р эгнээнд хуваарилагдах болно.
    ///
    /// `ptr`-ийн өмчлөл нь `Vec<T>`-д үр дүнтэй шилждэг бөгөөд ингэснээр дурын дагуу зааж өгсөн санах ойн агуулгыг хуваарилах, дахин хуваарилах эсвэл өөрчлөх боломжтой.
    /// Энэ функцийг дуудсаны дараа заагчийг өөр зүйл ашиглахгүй байхыг баталгаажуулна уу.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME vec_into_raw_parts тогтворжсон үед үүнийг шинэчлэх.
    ///     // `V`-ийн устгагчийг ажиллуулахаас сэргийлж хуваарилалтыг бид бүрэн хянах болно.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v`-ийн талаархи янз бүрийн чухал мэдээллийг сугалж ав
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // 4, 5, 6-тай санах ойг дарж бичих
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Бүх зүйлийг Vec-д буцааж оруулаарай
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// `Vec<T>`-ийг түүхий эд болгон задалдаг.
    ///
    /// Түүхий заагчийг суурь өгөгдөл, vector-ийн урт (элементээр), өгөгдлийн хуваарилагдсан багтаамж (элементээр) руу буцаана.
    /// Эдгээр нь [`from_raw_parts`]-ийн аргументуудтай ижил дарааллаар ижил аргументууд юм.
    ///
    /// Энэ функцийг дуудсаны дараа дуудагч нь `Vec`-ийн удирддаг санах ойг хариуцдаг.
    /// Үүнийг хийх цорын ганц арга зам бол түүхий заагч, урт, багтаамжийг [`from_raw_parts`] функцээр `Vec` болгож буцааж хөрвүүлэх явдал юм.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Одоо бид түүхий заагчийг тохирох төрөлд шилжүүлэх гэх мэт бүрэлдэхүүн хэсгүүдэд өөрчлөлт оруулах боломжтой.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// `Vec<T>`-ийг түүхий эд болгон задалдаг.
    ///
    /// Түүхий заагчийг суурь өгөгдөл, vector-ийн урт (элементээр), өгөгдлийн хуваарилагдсан хүчин чадал (элементээр), хуваарилагч руу буцаана.
    /// Эдгээр нь [`from_raw_parts_in`]-ийн аргументуудтай ижил дарааллаар ижил аргументууд юм.
    ///
    /// Энэ функцийг дуудсаны дараа дуудагч нь `Vec`-ийн удирддаг санах ойг хариуцдаг.
    /// Үүнийг хийх цорын ганц арга зам бол түүхий заагч, урт, багтаамжийг [`from_raw_parts_in`] функцээр `Vec` болгож буцааж хөрвүүлэх явдал юм.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Одоо бид түүхий заагчийг тохирох төрөлд шилжүүлэх гэх мэт бүрэлдэхүүн хэсгүүдэд өөрчлөлт оруулах боломжтой.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// vector-ийн дахин хуваарилалтгүйгээр барьж чадах элементийн тоог буцаана.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Тухайн `Vec<T>`-т оруулахын тулд дор хаяж `additional` элементийн нөөц багтаамж.
    /// Цуглуулга нь дахин хуваарилалтаас зайлсхийхийн тулд илүү их зай хадгалах боломжтой.
    /// `reserve` руу залгасны дараа хүчин чадал нь `self.len() + additional`-ээс их эсвэл тэнцүү байх болно.
    /// Хэрэв хүчин чадал аль хэдийн хангалттай болсон бол юу ч хийхгүй.
    ///
    /// # Panics
    ///
    /// Хэрэв шинэ хүчин чадал `isize::MAX` байтаас хэтэрвэл Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Өгөгдсөн `Vec<T>`-д яг `additional` илүү элемент оруулах хамгийн бага багтаамжийг нөөцлөнө.
    ///
    /// `reserve_exact` руу залгасны дараа хүчин чадал нь `self.len() + additional`-ээс их эсвэл тэнцүү байх болно.
    /// Хэрэв хүчин чадал аль хэдийн хангалттай бол юу ч хийхгүй.
    ///
    /// Хуваарилагч нь цуглуулгаас хүссэн хэмжээнээс илүү зай гаргаж өгч болохыг анхаарна уу.
    /// Тиймээс хүчин чадлыг яг хамгийн бага гэж найдаж болохгүй.
    /// Хэрэв future оруулах шаардлагатай бол `reserve`-г илүүд үзээрэй.
    ///
    /// # Panics
    ///
    /// Хэрэв шинэ хүчин чадал `usize`-ээс давсан бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Тухайн `Vec<T>`-т оруулах элементээс багагүй `additional` багтаамжийг нөөцлөхийг хичээдэг.
    /// Цуглуулга нь дахин хуваарилалтаас зайлсхийхийн тулд илүү их зай хадгалах боломжтой.
    /// `try_reserve` руу залгасны дараа хүчин чадал нь `self.len() + additional`-ээс их эсвэл тэнцүү байх болно.
    /// Хэрэв хүчин чадал аль хэдийн хангалттай болсон бол юу ч хийхгүй.
    ///
    /// # Errors
    ///
    /// Хэрэв хүчин чадал давсан эсвэл хуваарилагч алдаа гарсан тухай мэдээлсэн бол алдаа буцаж ирнэ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Санах ойг урьдчилан нөөцлөх, хэрэв чадахгүй бол гарах
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Одоо энэ нь бидний нарийн төвөгтэй ажлын дунд OOM чадахгүй байгааг бид мэднэ
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // маш төвөгтэй
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Тухайн `Vec<T>`-д оруулах `additional` элементийн хамгийн бага багтаамжийг хадгалахыг хичээдэг.
    /// `try_reserve_exact` руу залгасны дараа `Ok(())`-ийг буцаах тохиолдолд хүчин чадал нь `self.len() + additional`-ээс их эсвэл тэнцүү байх болно.
    ///
    /// Хэрэв хүчин чадал аль хэдийн хангалттай бол юу ч хийхгүй.
    ///
    /// Хуваарилагч нь цуглуулгаас хүссэн хэмжээнээс илүү зай гаргаж өгч болохыг анхаарна уу.
    /// Тиймээс хүчин чадлыг яг хамгийн бага гэж найдаж болохгүй.
    /// Хэрэв future оруулах шаардлагатай бол `reserve`-г илүүд үзээрэй.
    ///
    /// # Errors
    ///
    /// Хэрэв хүчин чадал давсан эсвэл хуваарилагч алдаа гарсан тухай мэдээлсэн бол алдаа буцаж ирнэ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Санах ойг урьдчилан нөөцлөх, хэрэв чадахгүй бол гарах
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Одоо энэ нь бидний нарийн төвөгтэй ажлын дунд OOM чадахгүй байгааг бид мэднэ
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // маш төвөгтэй
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// vector-ийн багтаамжийг аль болох багасгадаг.
    ///
    /// Энэ нь уртад аль болох ойрхон унах боловч хуваарилагч нь vector-д хэд хэдэн элементийн зай байгаа гэдгийг мэдэгдсээр байж магадгүй юм.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Хүчин чадал нь уртаас хэзээ ч бага байдаггүй бөгөөд тэнцүү байхад хийх зүйл байхгүй тул бид `RawVec::shrink_to_fit` дахь panic хэргийг зөвхөн илүү их хүчин чадлаар дуудахаас зайлсхийж чадна.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// vector-ийн багтаамжийг доод хязгаараар багасгадаг.
    ///
    /// Хүчин чадал нь дор хаяж урт, нийлүүлсэн утгын аль аль нь хэвээр байх болно.
    ///
    ///
    /// Хэрэв одоогийн хүчин чадал нь доод хязгаараас бага бол энэ нь татгалзах болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector-ийг [`Box<[T]>`][owned slice] болгон хөрвүүлдэг.
    ///
    /// Энэ нь илүүдэл хүчин чадлыг бууруулж байгааг анхаарна уу.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Илүүдэл хүчин чадлыг хасна.
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Эхний `len` элементүүдийг хадгалж үлдсэн хэсгийг нь унагаж vector-ийг богиносгодог.
    ///
    /// Хэрэв `len` нь vector-ийн одоогийн уртаас их байвал энэ нь ямар ч нөлөө үзүүлэхгүй.
    ///
    /// [`drain`] арга нь `truncate`-ийг дууриаж чаддаг боловч илүүдэл элементүүдийг унагаахын оронд буцааж өгдөг.
    ///
    ///
    /// Энэ арга нь vector-ийн хуваарилагдсан хүчин чадалд ямар ч нөлөө үзүүлэхгүй гэдгийг анхаарна уу.
    ///
    /// # Examples
    ///
    /// Таван элемент vector-ийг хоёр элемент болгон таслах:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// `len` нь vector-ийн одоогийн уртаас их байх үед таслалт гарахгүй:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// `len == 0` нь [`clear`] аргыг дуудахтай тэнцэх үед таслагдах.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Энэ нь аюулгүй, учир нь:
        //
        // * `drop_in_place` руу дамжуулсан зүсэлт хүчинтэй;`len > self.len` тохиолдолд хүчингүй зүсмэл үүсгэхээс зайлсхийх ба
        // * vector-ийн `len` нь `drop_in_place` руу залгахаасаа өмнө багасч байгаа тул хэрэв `drop_in_place` нэг удаа panic-т орвол хоёр дахин буурахгүй болно (хэрэв panics хоёр удаа байвал програм цуцлагдана).
        //
        //
        //
        unsafe {
            // Note: Энэ нь `>=` биш `>` гэсэн санаатай юм.
            //       Үүнийг `>=` болгож өөрчлөх нь зарим тохиолдолд гүйцэтгэлд сөргөөр нөлөөлдөг.
            //       Дэлгэрэнгүйг #78884-с үзнэ үү.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// vector-ийг бүхэлд нь агуулсан зүсмэлийг гаргаж авна.
    ///
    /// `&s[..]`-тэй тэнцүү.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Бүхэл бүтэн vector-ийн өөрчлөгдөж болох зүсмэлийг гаргаж авдаг.
    ///
    /// `&mut s[..]`-тэй тэнцүү.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Түүхий заагчийг vector буферт буцаана.
    ///
    /// Дуудлага хийж байгаа хүн vector заагчийг энэ функц буцаж ирэхийг эс тооцвол хог руу чиглүүлж дуусгах ёстой.
    /// vector-ийг өөрчлөх нь түүний буферыг дахин хуваарилахад хүргэж болзошгүй бөгөөд ингэснээр түүнд чиглэсэн заагч хүчингүй болно.
    ///
    /// Дуудлага хийж байгаа хүн (non-transitively) заагчийн зааж өгсөн санах ойг энэ заагч эсвэл үүнээс үүдсэн аливаа заагчийг ашиглан хэзээ ч (`UnsafeCell` дотор байгаа тохиолдолд) бичихгүй байхыг баталгаажуулах ёстой.
    /// Хэрэв та зүсмэлийн агуулгыг өөрчлөх шаардлагатай бол [`as_mut_ptr`] ашиглана уу.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Бид `deref`-ээр дамжихаас зайлсхийхийн тулд ижил нэртэй зүсмэлийн аргыг сүүдэрлэдэг бөгөөд энэ нь завсрын лавлагаа үүсгэдэг.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Аюулгүй, өөрчлөгдөж болох заагчийг vector-ийн буферт буцаана.
    ///
    /// Дуудлага хийж байгаа хүн vector заагчийг энэ функц буцаж ирэхийг эс тооцвол хог руу чиглүүлж дуусгах ёстой.
    ///
    /// vector-ийг өөрчлөх нь түүний буферыг дахин хуваарилахад хүргэж болзошгүй бөгөөд ингэснээр түүнд чиглэсэн заагч хүчингүй болно.
    ///
    /// # Examples
    ///
    /// ```
    /// // vector-ийг 4 элементэд хангалттай хэмжээгээр хуваарил.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Түүхий заагчаар дамжуулан элементүүдийг эхлүүлж, дараа нь уртыг тохируулна уу.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Бид `deref_mut`-ээр дамжихаас зайлсхийхийн тулд ижил нэртэй зүсмэлийн аргыг сүүдэрлэдэг бөгөөд энэ нь завсрын лавлагаа үүсгэдэг.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Үндсэн хуваарилагчийн лавлагааг буцаана.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector-ийн уртыг `new_len` болгоно.
    ///
    /// Энэ бол тухайн төрлийн ердийн хувьсах хэмжигдэхүүнүүдийн аль нэгийг нь хадгалдаггүй доод түвшний ажиллагаа юм.
    /// Ердийн үед vector-ийн уртыг өөрчлөх нь [`truncate`], [`resize`], [`extend`] эсвэл [`clear`] гэх мэт аюулгүй ажиллагааны аль нэгийг ашиглан хийгддэг.
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`]-ээс бага эсвэл тэнцүү байх ёстой.
    /// - `old_len..new_len` дээрх элементүүдийг эхлүүлэх ёстой.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Энэ арга нь vector нь бусад код, ялангуяа FFI-д зориулж буфер байдлаар үйлчилдэг нөхцөлд ашигтай байж болох юм.
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Энэ бол документын жишээний хувьд хамгийн бага араг яс юм.
    /// # // үүнийг жинхэнэ номын сангийн эхлэл болгон бүү ашигла.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // FFI аргын баримт бичгийн дагуу "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // АЮУЛГҮЙ БАЙДАЛ: `deflateGetDictionary` нь `Z_OK`-ийг буцааж өгөхөд дараахь зүйлийг агуулна.
    ///     // 1. `dict_length` элементүүдийг эхлүүлсэн.
    ///     // 2.
    ///     // `dict_length` <= (32_768) багтаамж, `set_len`-ийг дуудлага хийхэд аюулгүй болгодог.
    ///     unsafe {
    ///         // FFI дуудлага хийх ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... мөн эхлүүлсэн зүйлд хүртэл уртыг нь шинэчлэх.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Дараах жишээ нь найдвартай боловч `set_len` дуудлага хийхээс өмнө дотоод vectors суллагдаагүй тул санах ойн алдагдал гарсан байна.
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` хоосон тул ямар ч элементийг эхлүүлэх шаардлагагүй болно.
    /// // 2. `0 <= capacity` үргэлж `capacity`-ийг хадгалдаг.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Ердийн тохиолдолд энд [`clear`]-ийг ашиглан агуулгыг зөв унагаж, улмаар санах ой алдагдахгүй болно.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector-ээс элементийг аваад буцаана.
    ///
    /// Устгасан элементийг vector-ийн сүүлчийн элементээр солино.
    ///
    /// Энэ нь захиалгыг хадгалахгүй, гэхдээ O(1) юм.
    ///
    /// # Panics
    ///
    /// Хэрэв `index` хязгаараас хэтэрсэн бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Бид өөрөө [индекс]-ийг сүүлчийн элементээр орлуулдаг.
            // Дээрх хязгаарлалт амжилттай болвол сүүлчийн элемент байх ёстой гэдгийг анхаарна уу (энэ нь өөрөө [индекс] өөрөө байж болно).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Бүх элементүүдийг баруун тийш шилжүүлж vector дотор `index` байрлалд элемент оруулна.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `index > len` бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // шинэ элементийн орон зай
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // алдаа мадаггүй Шинэ үнэ цэнийг бий болгох цэг
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Орон зай гаргахын тулд бүх зүйлийг шилжүүлээрэй.
                // ("Index`th" элементийг дараалан хоёр газарт хувилах.)
                ptr::copy(p, p.offset(1), len - index);
                // Үүнийг "index`th" элементийн эхний хувийг дарж бичнэ үү.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Бүх элементүүдийг зүүн тийш шилжүүлж vector дотор `index` байрлал дахь элементийг арилгаж буцаана.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `index` хязгаараас хэтэрсэн бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // бидний авч байгаа газар.
                let ptr = self.as_mut_ptr().add(index);
                // хуулбарлах, аюулгүй байдлын зэрэгцээ стек болон vector дээрх утгын хуулбартай байх.
                //
                ret = ptr::read(ptr);

                // Тэр газрыг нөхөхийн тулд бүх зүйлийг доош нь шилжүүлээрэй.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Зөвхөн урьдчилж тодорхойлсон элементүүдийг хадгална.
    ///
    /// Өөрөөр хэлбэл `e` нь `false`-ийг буцааж өгөх бүх элементүүдийг устгана уу.
    /// Энэ арга нь тухайн элементэд анхны дарааллаар яг нэг удаа зочлон очиж үйлчилдэг бөгөөд хадгалагдсан элементүүдийн дарааллыг хадгалдаг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Элементүүдийг анхны дарааллаар яг нэг удаа зочилдог тул аль элементийг хадгалахаа шийдэхдээ гадаад төлөвийг ашиглаж болно.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Хэрэв дуслын хамгаалагч хийгдээгүй бол давхар уналтаас зайлсхийх хэрэгтэй.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-боловсруулсан len-> |^-шалгахын хажууд
        //                  | <-устгасан cnt-> |
        //      | <-original_len-> |Хадгалах: Урьдчилан тодорхойлсон элементүүд үнэн буцаана.
        //
        // Нүх: Элементийн үүрийг зөөсөн эсвэл хаясан.
        // Шалгахгүй: Хүчингүй элементүүдийг шалгаагүй.
        //
        // Энэ элементийг урьдчилан таамаглах эсвэл `drop` сандрах үед энэ дусаагуурыг ажиллуулах болно.
        // Энэ нь цоорхойг хучихын тулд шалгагдаагүй элементүүдийг шилжүүлж, `set_len`-ийг зөв урттай болгоно.
        // Урьдчилан таамагласан болон `drop` хэзээ ч сандрахгүй тохиолдолд үүнийг оновчтой болгоно.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // АЮУЛГҮЙ АЖИЛЛАГАА: Хяналтгүй зүйлсийн ард бид хэзээ ч хүрдэггүй тул хүчинтэй байх ёстой.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // АЮУЛГҮЙ БАЙДАЛ: Цоорхойг бөглөсний дараа бүх зүйл ой санамжинд хадгалагдана.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // АЮУЛГҮЙ АЖИЛЛАГАА: Сонгоогүй элемент хүчинтэй байх ёстой.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Хэрэв `drop_in_place` сандрах юм бол давхар уналтаас зайлсхийхийн тулд эрт урагшлуулаарай.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // АЮУЛГҮЙ БАЙДАЛ: Буулгасны дараа бид энэ элементэд дахин хэзээ ч хүрэхгүй.
                unsafe { ptr::drop_in_place(cur) };
                // Бид тоолуурыг аль хэдийн сайжруулсан.
                continue;
            }
            if g.deleted_cnt > 0 {
                // АЮУЛГҮЙ БАЙДАЛ: `deleted_cnt`> 0 тул нүхний нүх нь одоогийн элементтэй давхцахгүй байх ёстой.
                // Бид шилжихдээ хуулбарыг ашигладаг бөгөөд энэ элементэд дахин хэзээ ч хүрэхгүй.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Бүх зүйлийг боловсруулсан болно.Үүнийг LLVM-ээр `set_len` болгож оновчтой болгож болно.
        drop(g);
    }

    /// vector-ийн дараалсан элементүүдийн эхнийхээс бусад бүх зүйлийг ижил түлхүүрээр шийддэг.
    ///
    ///
    /// Хэрэв vector-ийг эрэмбэлсэн бол энэ нь бүх хуулбарыг устгана.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Өгөгдсөн тэгш байдлын харьцааг хангасан vector дахь дараалсан эхний элементүүдээс бусад бүх зүйлийг устгана.
    ///
    /// `same_bucket` функцийг vector-ийн хоёр элементийн лавлагаагаар дамжуулж, элементүүд хоорондоо харьцуулж байгаа эсэхийг тодорхойлох ёстой.
    /// Элементүүдийг зүсмэл дэх дарааллаас эсрэг дарааллаар дамжуулдаг тул хэрэв `same_bucket(a, b)` нь `true`-ийг буцаадаг бол `a` хасагдана.
    ///
    ///
    /// Хэрэв vector-ийг эрэмбэлсэн бол энэ нь бүх хуулбарыг устгана.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Цуглуулгын арын хэсэгт элемент нэмнэ.
    ///
    /// # Panics
    ///
    /// Хэрэв шинэ хүчин чадал `isize::MAX` байтаас хэтэрвэл Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Хэрэв бид> isize::MAX байт хуваарилах эсвэл тэгийн хэмжээнүүдийн хувьд уртын нэмэгдэл халих юм бол энэ нь panic эсвэл цуцлагдах болно.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Сүүлийн элементийг vector-ээс устгаж буцаана, эсвэл хоосон бол [`None`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other`-ийн бүх элементүүдийг `Self` руу шилжүүлж, `other`-ийг хоосон орхино.
    ///
    /// # Panics
    ///
    /// Хэрэв vector дээрх элементийн тоо `usize` хэмжээнээс хэтэрвэл Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Бусад буферын элементүүдийг `Self` дээр нэмнэ.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// vector-д заасан мужийг арилгаж зайлуулсан зүйлийг гаргадаг ус зайлуулах давталтыг бий болгодог.
    ///
    /// Давталтыг **унагаах** үед, давталтыг бүрэн хэрэглээгүй байсан ч хүрээний бүх элементүүдийг vector-ээс хасдаг.
    /// Хэрэв **давталтыг** хаяхгүй бол (жишээ нь [`mem::forget`]-тэй) хичнээн элементийг хасах нь тодорхойгүй байна.
    ///
    /// # Panics
    ///
    /// Хэрэв эхлэх цэг нь төгсгөлийн цэгээс эсвэл төгсгөлийн цэг нь vector-ийн уртаас их байвал Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Бүрэн хүрээ нь vector-ийг цэвэрлэнэ
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Санах ойн аюулгүй байдал
        //
        // Drain-ийг анх үүсгэхдээ vect-ийн эх үүсвэрийн уртыг богиносгож, хэрэв Drain-ийн устгагч хэзээ ч ажиллаж чадахгүй бол эхлүүлээгүй эсвэл шилжсэн элементүүд огт нэвтрэх боломжгүй болно.
        //
        //
        // Drain нь ptr::read утгыг хасах болно.
        // Дууссаны дараа vec-ийн үлдсэн сүүлийг нүхийг таглахын тулд хуулбарлаж, vector уртыг шинэ уртаар сэргээнэ.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // Drain алдагдсан тохиолдолд аюулгүй байхын тулд self.vec уртыг эхлүүлэх
            self.set_len(start);
            // IterMut дээрх зээлийг ашиглан Drain бүхэл бүтэн давталтын зээлдэгч шинж чанарыг харуулна уу (&mut T гэх мэт).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Бүх утгыг арилгаж vector-ийг цэвэрлэнэ.
    ///
    /// Энэ арга нь vector-ийн хуваарилагдсан хүчин чадалд ямар ч нөлөө үзүүлэхгүй гэдгийг анхаарна уу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// 'length' гэж нэрлэгддэг vector дээрх элементийн тоог буцаана.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Хэрэв vector элемент агуулаагүй бол `true` буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Өгөгдсөн индексээр цуглуулгыг хоёр хуваана.
    ///
    /// `[at, len)` муж дахь элементүүдийг агуулсан шинээр хуваарилагдсан vector-ийг буцаана.
    /// Дуудлага хийсний дараа анхны vector нь өмнөх хүчин чадал өөрчлөгдөөгүй, `[0, at)` элементүүдийг агуулсан хэвээр үлдэнэ.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `at > len` бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // шинэ vector анхны буферийг авч, хуулбараас зайлсхийх боломжтой
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Аюулгүй `set_len` ба эд зүйлсийг `other` руу хуулж ав.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec`-ийг байрлал дахь хэмжээг өөрчилснөөр `len` нь `new_len`-тэй тэнцүү байна.
    ///
    /// Хэрэв `new_len` нь `len`-ээс их бол `Vec` нь зөрүүгээр нэмэгдэх бөгөөд нэмэлт оролт бүрийг `f` хаалтын дуудлагын үр дүнгээр дүүргэнэ.
    ///
    /// `f`-ээс буцах утга нь үүссэн дарааллаараа `Vec` болж дуусна.
    ///
    /// Хэрэв `new_len` нь `len`-ээс бага бол `Vec` нь зүгээр л таслагдана.
    ///
    /// Энэ арга нь түлхэлт бүрт шинэ утгыг бий болгохын тулд хаалтыг ашигладаг.Хэрэв та өгөгдсөн утгыг [`Clone`] болгохыг хүсч байвал [`Vec::resize`] ашиглана уу.
    /// Хэрэв та утга үүсгэхийн тулд [`Default`] trait-ийг ашиглахыг хүсвэл [`Default::default`]-ийг хоёр дахь аргумент болгон өгч болно.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec`-ийг хэрэглэж, алдагдуулж, агуулгын талаархи өөрчлөгдөж болох лавлагаа, `&'a mut [T]`.
    /// `T` төрөл нь `'a` насыг сонгосон байх ёстой гэдгийг анхаарна уу.
    /// Хэрэв төрөл нь зөвхөн статик лавлагаа эсвэл огт байхгүй бол `'static` гэж сонгож болно.
    ///
    /// Энэ функц нь алдагдсан санах ойг сэргээх арга байхгүйгээс бусад тохиолдолд [`Box`] дээрх [`leak`][Box::leak] ажиллагаатай төстэй юм.
    ///
    ///
    /// Энэ функц нь програмын үлдсэн хугацаанд амьдардаг өгөгдөлд ихэвчлэн ашиглагддаг.
    /// Буцааж өгсөн лавлагааг унагавал санах ой алдагдах болно.
    ///
    /// # Examples
    ///
    /// Энгийн хэрэглээ:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector-ийн үлдсэн нөөц хүчин чадлыг `MaybeUninit<T>` зүсмэл болгон буцаана.
    ///
    /// Буцааж өгсөн зүсмэлийг vector-ийг өгөгдлөөр дүүргэхэд ашиглаж болно (жишээлбэл
    /// файлыг унших замаар) өгөгдлийг [`set_len`] аргыг ашиглан эхлүүлсэн гэж тэмдэглэхээс өмнө.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // 10 элементийн багтаамжтай vector-ийг хуваарил.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Эхний 3 элементийг бөглөнө үү.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // vector-ийн эхний 3 элементийг эхлүүлсэн гэж тэмдэглэ.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Энэ арга нь буфер руу чиглүүлэгчийг хүчингүй болгохоос сэргийлж `split_at_spare_mut`-ийн хувьд хэрэгждэггүй.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector агуулгыг `T`-ийн зүсэлт, vector-ийн үлдсэн нөөц багтаамжийн хамт `MaybeUninit<T>`-ийн зүсмэл болгон буцаана.
    ///
    /// Буцаасан нөөц багтаамжийн зүсмэлийг [`set_len`] аргыг ашиглан өгөгдлийг эхлүүлсэн гэж тэмдэглэхээс өмнө vector-ийг өгөгдөл (жишээлбэл, файлаас унших замаар) дүүргэхэд ашиглаж болно.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Энэ бол оновчтой болгох үүднээс болгоомжтой ашиглах хэрэгтэй доод түвшний API гэдгийг анхаарна уу.
    /// Хэрэв танд `Vec`-д өгөгдөл нэмэх шаардлагатай бол таны хэрэгцээнээс хамаарч [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] эсвэл [`resize_with`] ашиглаж болно.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // 10 элементийн багтаамжтай нэмэлт зайг нөөцлөөрэй.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Дараагийн 4 элементийг бөглөнө үү.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // vector-ийн 4 элементийг эхлүүлсэн гэж тэмдэглэ.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - ленийг үл тоомсорлодог тул хэзээ ч өөрчлөгддөггүй
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Аюулгүй байдал: буцаж ирсэн .2 (&mut usize)-ийг өөрчлөх нь `.set_len(_)` руу залгахтай ижил байна.
    ///
    /// Энэ аргыг `extend_from_within`-д бүх vec хэсгүүдэд нэгэн зэрэг нэвтрэх боломжийг олгодог.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` нь `len` элементүүдийн хувьд хүчинтэй байх баталгаа юм
        // - `spare_ptr` буферын хажуугаар нэг элементийг зааж байгаа тул `initialized`-тай давхцахгүй байна
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec`-ийг байрлал дахь хэмжээг өөрчилснөөр `len` нь `new_len`-тэй тэнцүү байна.
    ///
    /// Хэрэв `new_len` нь `len`-ээс их байвал `Vec` нь ялгаагаар нэмэгдэх бөгөөд нэмэлт оролт бүрийг `value`-ээр дүүргэнэ.
    ///
    /// Хэрэв `new_len` нь `len`-ээс бага бол `Vec` нь зүгээр л таслагдана.
    ///
    /// Энэ арга нь дамжуулсан утгыг клончлох чадвартай байхын тулд [`Clone`]-ийг хэрэгжүүлэхийн тулд `T`-ийг шаарддаг.
    /// Хэрэв танд илүү уян хатан байдал хэрэгтэй бол (эсвэл [`Clone`]-ийн оронд [`Default`]-д найдахыг хүсвэл) [`Vec::resize_with`]-ийг ашиглаарай.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Бүх элементүүдийг зүсэж хуулж, `Vec` дээр хавсаргана.
    ///
    /// `other` зүсмэл дээр давтаж, элемент тус бүрийг клончилж, дараа нь энэ `Vec` дээр хавсаргана.
    /// `other` vector нь дарааллаар дайран өнгөрдөг.
    ///
    /// Энэ функц нь [`extend`]-тэй адил гэдгийг анхаарна уу, гэхдээ оронд нь зүсмэлүүдтэй ажиллах мэргэшсэн байдаг.
    ///
    /// Хэрэв Rust мэргэшсэн бол энэ функцийг ашиглахаа больсон (гэхдээ боломжтой хэвээр байх болно).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src`-ээс vector-ийн төгсгөл хүртэлх элементүүдийг хуулдаг.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` өгөгдсөн муж нь өөрийгөө индексжүүлэхэд хүчинтэй болохыг баталгаажуулдаг
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Энэ код нь `extend_with_{element,default}`-ийг ерөнхийд нь нэгтгэдэг.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Өгөгдсөн генераторыг ашиглан vector-ийг `n` утгаар сунгана.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // SetLenOnDrop-ийг ашиглан хөрвүүлэгч `ptr`-ээс self.set_len() хүртэлх дэлгүүрийг хөрвүүлээгүй тохиолдолд алдаагаа засах боломжтой.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Сүүлийнхээс бусад бүх элементүүдийг бич
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics тохиолдолд алхам тутамд уртыг нэмэгдүүлэх
                local_len.increment_len(1);
            }

            if n > 0 {
                // Бид сүүлчийн элементийг шаардлагагүй клончлолгүйгээр шууд бичиж болно
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // хүрээ хамгаалагчаар тохируулсан
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait хэрэгжилтийн дагуу vector дахь дараалсан давтагдсан элементүүдийг устгана.
    ///
    ///
    /// Хэрэв vector-ийг эрэмбэлсэн бол энэ нь бүх хуулбарыг устгана.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Дотоод арга, үйл ажиллагаа
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` хүчинтэй индекс байх шаардлагатай
    /// - `self.capacity() - self.len()` `>= src.len()` байх ёстой
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len элементүүдийг эхлүүлсний дараа л нэмэгддэг
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - дуудагч src бол хүчин төгөлдөр индекс гэдгийг баталж байна
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Элементийг `MaybeUninit::write`-ээр эхлүүлсэн тул ленийг нэмэгдүүлэх нь зөв юм
            // - Алдагдал үүсэхээс сэргийлж элемент бүрийн дараа ленийг нэмэгдүүлдэг (#82533 дугаарыг үзнэ үү)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - дуудагч `src` бол хүчин төгөлдөр индекс гэдгийг баталж байна
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Хоёр заагч хоёулаа өвөрмөц зүсмэлийн лавлагаанаас ("&mut [_]") үүсгэсэн тул хүчинтэй тул давхцахгүй.
            //
            // - Элементүүд нь: Хуулбарлах, тиймээс тэдгээрийг анхны утгуудтай нь хамт хийхгүйгээр хуулбарлах нь зөв юм
            // - `count` нь `source` линтэй тэнцүү тул эх сурвалж нь `count` уншихад хүчинтэй
            // - `.reserve(count)` `spare.len() >= count`-ийн нөөц нь `count` бичихэд хүчинтэй болохыг баталгаажуулдаг
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Элементүүдийг `copy_nonoverlapping`-ээр эхлүүлсэн
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vec-ийн нийтлэг trait програмууд
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test)-тэй хамт энэ аргыг тодорхойлоход шаардагдах уламжлалт `[T]::to_vec` арга байхгүй байна.
    // Үүний оронд зөвхөн cfg(test) NB дээр ашиглах боломжтой `slice::to_vec` функцийг ашиглаарай. slice.rs дахь slice::hack модулийг үзнэ үү.
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // дарж бичихгүй зүйлийг унага
        self.truncate(other.len());

        // self.len <=Дээрх таслалтаас болж other.len тул энд байгаа зүсмэлүүд үргэлж хязгаарлагдмал байдаг.
        //
        let (init, tail) = other.split_at(self.len());

        // агуулагдсан утгуудыг дахин ашиглах allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Хэрэглээний давталтыг бий болгодог, өөрөөр хэлбэл vector-ээс утга бүрийг шилжүүлдэг (эхнээс нь дуустал).
    /// Үүнийг дуудсаны дараа vector ашиглах боломжгүй.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s нь &String биш харин String хэлбэртэй байна
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // янз бүрийн SpecFrom/SpecExtend хэрэгжилтийг хэрэгжүүлэх оновчтой хувилбар байхгүй тохиолдолд төлөөлөх навчны арга
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Ерөнхий давталтын хувьд ийм тохиолдол гардаг.
        //
        // Энэ функц нь дараахь зүйлсийн ёс суртахууны тэнцүү байх ёстой.
        //
        //      давталт дахь зүйлийн хувьд {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // Бид хаягийн орон зайг хуваарилах ёстой байсан тул NB хальж чадахгүй
                self.set_len(len + 1);
            }
        }
    }

    /// vector-д заасан мужийг өгөгдсөн `replace_with` давталтаар орлуулж, хасагдсан зүйлийг гаргадаг залгах давталт үүсгэдэг.
    ///
    /// `replace_with` `range`-тэй ижил урттай байх шаардлагагүй.
    ///
    /// `range` давталтыг дуустал хэрэглээгүй байсан ч устгагдсан болно.
    ///
    /// Хэрэв `Splice` утга алдагдсан бол vector-ээс хэдэн элементийг хасах нь тодорхойгүй байна.
    ///
    /// `replace_with` оролтын давталтыг `Splice` утга унах үед л хэрэглэдэг.
    ///
    /// Хэрэв энэ нь оновчтой бол:
    ///
    /// * Сүүл (`range`-ийн дараа vector дээрх элементүүд) хоосон,
    /// * эсвэл `replace_with` нь "муж"-ын уртаас бага эсвэл тэнцүү элементийг өгдөг
    /// * эсвэл түүний `size_hint()`-ийн доод хязгаар яг тодорхой байна.
    ///
    /// Үгүй бол түр зуурын vector-ийг хуваарилж, сүүлийг нь хоёр удаа хөдөлгөдөг.
    ///
    /// # Panics
    ///
    /// Хэрэв эхлэх цэг нь төгсгөлийн цэгээс эсвэл төгсгөлийн цэг нь vector-ийн уртаас их байвал Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Элементийг зайлуулах шаардлагатай эсэхийг тодорхойлох хаалтыг ашигладаг давталтыг үүсгэдэг.
    ///
    /// Хэрэв хаах нь үнэн бол элементийг устгаж, гаргана.
    /// Хэрэв хаалт худал гэсэн утгатай бол элемент нь vector-д үлдэх бөгөөд давталтаас гарахгүй.
    ///
    /// Энэ аргыг ашиглах нь дараахь кодтой тэнцүү байна.
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // энд таны код
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Гэхдээ `drain_filter` ашиглах нь илүү хялбар байдаг.
    /// `drain_filter` массивын элементүүдийг бөөнөөр нь шилжүүлж чаддаг тул илүү үр дүнтэй байдаг.
    ///
    /// `drain_filter` нь шүүлтүүрийг хаах эсвэл устгахаас үл хамааран бүх элементийг мутацлах боломжийг танд олгоно гэдгийг анхаарна уу.
    ///
    ///
    /// # Examples
    ///
    /// Массивыг тэгш ба магадлал болгон хувааж анхны хуваарилалтыг дахин ашиглана уу.
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Биднийг алдахаас хамгаалаарай (гоожих олшруулалт)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Элементүүдийг Vec руу түлхэхээс өмнө лавлагаагаас хуулдаг програмыг өргөжүүл.
///
/// Энэхүү хэрэгжилт нь зүсмэл давталтад зориулагдсан бөгөөд [`copy_from_slice`]-ийг ашиглан зүсмэлийг бүхэлд нь хавсаргана.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors-ийн харьцуулалтыг хэрэгжүүлдэг, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors-ийн захиалга, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T]-ийн дуслыг ашиглах нь vector-ийн элементүүдийг хамгийн сул шаардлагатай төрөл гэж үзэх түүхий зүсмэлийг ашиглах;
            //
            // тодорхой тохиолдолд хүчинтэй эсэх талаархи асуултаас зайлсхийх боломжтой
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec нь хуваарилалтыг зохицуулдаг
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Хоосон `Vec<T>` үүсгэдэг.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: тест нь libstd-ийг татаж авдаг бөгөөд энд алдаа гардаг
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: тест нь libstd-ийг татаж авдаг бөгөөд энд алдаа гардаг
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Хэрэв хэмжээ нь хүссэн массивын хэмжээтэй яг таарч байвал `Vec<T>`-ийн агуулгыг бүхэлд нь массив болгоно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Хэрэв урт нь таарахгүй бол оролт нь `Err` дээр буцаж ирдэг:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Хэрэв та `Vec<T>`-ийн угтвар авахад зүгээр байгаа бол эхлээд [`.truncate(N)`](Vec::truncate) руу залгаж болно.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // АЮУЛГҮЙ БАЙДАЛ: `.set_len(0)` нь үргэлж найдвартай байдаг.
        unsafe { vec.set_len(0) };

        // АЮУЛГҮЙ БАЙДАЛ: A `Vec`-ийн заагч нь үргэлж зөв нийцэж байдаг ба
        // массивын хэрэгцээтэй уялдуулах зүйлүүдтэй ижил байна.
        // Бид өмнө нь хангалттай эд зүйл байгаа эсэхийг шалгасан.
        // `set_len` нь `Vec`-ийг бас хаяхгүй байхыг хэлж байгаа тул эд зүйлс хоёр дахин буурахгүй.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}