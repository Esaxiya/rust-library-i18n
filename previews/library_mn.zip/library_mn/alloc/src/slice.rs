//! Зэрэгцээ дараалал руу динамик хэмжээтэй харагдах байдал, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Зүсмэлүүд нь санах ойн блок руу заагч ба уртаар дүрслэгдсэн харагдац юм.
//!
//! ```
//! // Vec-ийг зүсэх
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // массивыг зүсмэл рүү шахах
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Зүсмэлүүдийг өөрчлөх боломжтой эсвэл хуваалцдаг.
//! Хуваалцсан зүсмэлийн төрөл нь `&[T]`, харин өөрчлөгдөж болох зүсмэл төрөл нь `&mut [T]` бөгөөд `T` нь элементийн төрлийг илэрхийлдэг.
//! Жишээлбэл, та өөрчлөгдөж болох зүсмэлийн зааж өгсөн санах ойн блокыг мутаци хийж болно.
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Энэ модуль нь дараахь зүйлийг агуулдаг.
//!
//! ## Structs
//!
//! Зүсмэл дээр давталтыг илэрхийлдэг [`Iter`] гэх мэт зүсмэлүүдэд хэрэгтэй хэд хэдэн бүтэц байдаг.
//!
//! ## Trait хэрэгжилт
//!
//! Зүсмэлүүдийн хувьд нийтлэг traits-ийн хэд хэдэн хэрэгжүүлэлт байдаг.Зарим жишээнд:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], элементийн төрөл [`Eq`] эсвэл [`Ord`] зүсмэлүүдэд зориулагдсан.
//! * [`Hash`] - элементийн төрөл [`Hash`] байгаа зүсмэлүүдийн хувьд.
//!
//! ## Iteration
//!
//! Зүсмэлүүд `IntoIterator`-ийг хэрэгжүүлдэг.Давтагч нь зүсмэл элементүүдийн талаархи лавлагааг өгдөг.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Өөрчлөгдөх боломжтой зүсмэлүүд нь элементүүдийг өөрчлөх боломжтой лавлагаа өгдөг.
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Энэ давталт нь зүсмэлийн элементүүдийн хувьд өөрчлөгдөж болохуйц лавлагаа өгдөг тул зүсмэлийн элементийн төрөл `i32` байхад давталтын элементийн төрөл `&mut i32` байна.
//!
//!
//! * [`.iter`] ба [`.iter_mut`] нь анхдагч давталтыг буцаах тодорхой арга юм.
//! * Давталтыг буцаах нэмэлт аргууд нь [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ба бусад юм.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Энэ модуль дахь олон ашиглалтыг зөвхөн туршилтын тохиргоонд ашигладаг.
// Ашиглагдаагүй_импортын анхааруулгыг засахаас илүүтэйгээр унтрааж байх нь илүү цэвэрхэн байдаг.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Зүсмэл өргөтгөлийн үндсэн аргууд
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB-г турших явцад `vec!` макро хэрэгжүүлэхэд шаардлагатай бол энэ файл дахь `hack` модулийг үзнэ үү.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB-ийг турших явцад `Vec::clone`-ийг хэрэгжүүлэхэд шаардлагатай бол энэ файл дахь `hack` модулийг үзнэ үү.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` ашиглах боломжгүй тул эдгээр гурван функц нь `impl [T]`-т байдаг боловч `core::slice::SliceExt`-т байдаггүй аргууд тул бид эдгээр функцуудыг `test_permutations` тестэнд өгөх хэрэгтэй.
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Энэ нь `vec!` макро дээр ихэвчлэн ашиглагддаг бөгөөд төгс төгөлдөр регрессийг үүсгэдэг тул бид үүнд доторлогооны шинж чанарыг нэмж оруулах ёсгүй.
    // Хэлэлцүүлэг, төгсгөлийн үр дүнг #71204-ээс үзнэ үү
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // зүйлийг доорхи гогцоонд эхлүүлсэн гэж тэмдэглэсэн болно
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) LLVM нь хязгаарлалтын шалгалтыг арилгахад шаардлагатай бөгөөд zip-ээс илүү сайн кодлогчтой байдаг.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec-ийг дор хаяж ийм урттай хуваарилж, эхлүүлсэн.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` багтаамжтай дээр хуваарилагдсан бөгөөд доорхи ptr::copy_to_non_overlapping-д `s.len()` гэж эхлүүлнэ.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Зүсмэлийг ангилдаг.
    ///
    /// Энэ ангилал нь тогтвортой (өөрөөр хэлбэл тэнцүү элементүүдийг эрэмбэлдэггүй) ба *O*(*n*\*log(* n*)) хамгийн муу тохиолдол юм.
    ///
    /// Боломжтой тохиолдолд тогтворгүй ангилах нь ерөнхийдөө тогтвортой ангилалтаас хурдан бөгөөд нэмэлт санах ой хуваарилдаггүй тул давуу эрх олгоно.
    /// [`sort_unstable`](slice::sort_unstable)-г үзнэ үү.
    ///
    /// # Одоогийн хэрэгжилт
    ///
    /// Одоогийн алгоритм нь [timsort](https://en.wikipedia.org/wiki/Timsort)-ээс санаа авсан дасан зохицох, давталттай нэгтгэх төрөл юм.
    /// Энэ нь зүсмэлийг бараг эрэмбэлэх эсвэл нэг нэгнийхээ араас залгасан хоёр ба түүнээс дээш эрэмбэлэгдсэн дарааллаас бүрдэх тохиолдолд маш хурдан хийгдсэн байхаар хийгдсэн байдаг.
    ///
    ///
    /// Түүнчлэн, энэ нь түр зуурын хадгалалтыг `self`-ийн хэмжээтэй тэнцэх хэмжээгээр хуваарилдаг боловч богино зүсмэлүүдийн хувьд хуваарилалтгүй оруулах ангиллыг ашигладаг.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Зүсмэлийг харьцуулагч функцээр эрэмбэлнэ.
    ///
    /// Энэ ангилал нь тогтвортой (өөрөөр хэлбэл тэнцүү элементүүдийг эрэмбэлдэггүй) ба *O*(*n*\*log(* n*)) хамгийн муу тохиолдол юм.
    ///
    /// Харьцуулагч функц нь зүсмэл дэх элементүүдийн нийт захиалгыг тодорхойлох ёстой.Хэрэв захиалга нийт биш бол элементүүдийн дарааллыг тодорхойлоогүй болно.
    /// Захиалга бол (нийт `a`, `b` ба `c`-ийн хувьд) нийт захиалга юм.
    ///
    /// * нийт ба антисиметрийн: `a < b`, `a == b` эсвэл `a > b`-ийн яг нэг нь үнэн, ба
    /// * дамжуулагч, `a < b` ба `b < c` нь `a < c`-ийг илэрхийлдэг.`==` ба `>` хоёуланд нь ижил байх ёстой.
    ///
    /// Жишээлбэл, [`f64`] нь [`Ord`]-ийг `NaN != NaN`-ийг хэрэгжүүлдэггүй тул бид `partial_cmp`-ийг ялгах функц болгон ашиглаж болно, хэрвээ зүсэлт `NaN` агуулаагүй болохыг мэдвэл.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Боломжтой тохиолдолд тогтворгүй ангилах нь ерөнхийдөө тогтвортой ангилалтаас хурдан бөгөөд нэмэлт санах ой хуваарилдаггүй тул давуу эрх олгоно.
    /// [`sort_unstable_by`](slice::sort_unstable_by)-г үзнэ үү.
    ///
    /// # Одоогийн хэрэгжилт
    ///
    /// Одоогийн алгоритм нь [timsort](https://en.wikipedia.org/wiki/Timsort)-ээс санаа авсан дасан зохицох, давталттай нэгтгэх төрөл юм.
    /// Энэ нь зүсмэлийг бараг эрэмбэлэх эсвэл нэг нэгнийхээ араас залгасан хоёр ба түүнээс дээш эрэмбэлэгдсэн дарааллаас бүрдэх тохиолдолд маш хурдан хийгдсэн байхаар хийгдсэн байдаг.
    ///
    /// Түүнчлэн, энэ нь түр зуурын хадгалалтыг `self`-ийн хэмжээтэй тэнцэх хэмжээгээр хуваарилдаг боловч богино зүсмэлүүдийн хувьд хуваарилалтгүй оруулах ангиллыг ашигладаг.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // урвуу ангилах
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Түлхүүр ялгах функц бүхий зүсмэлийг эрэмбэлнэ.
    ///
    /// Энэ ангилал нь тогтвортой (өөрөөр хэлбэл тэнцүү элементүүдийг эрэмбэлдэггүй) ба *O*(*m*\* * n *\* log(*n*)) хамгийн муу тохиолдолд гол функц нь *O*(*m*) болно.
    ///
    /// Үнэтэй гол функцуудын хувьд (жишээлбэл
    /// энгийн өмчийн хандалт эсвэл үндсэн үйлдлүүд биш функцууд), [`sort_by_cached_key`](slice::sort_by_cached_key) нь элементийн түлхүүрүүдийг дахин тооцоолоогүй тул мэдэгдэхүйц хурдан байх магадлалтай.
    ///
    ///
    /// Боломжтой тохиолдолд тогтворгүй ангилах нь ерөнхийдөө тогтвортой ангилалтаас хурдан бөгөөд нэмэлт санах ой хуваарилдаггүй тул давуу эрх олгоно.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key)-г үзнэ үү.
    ///
    /// # Одоогийн хэрэгжилт
    ///
    /// Одоогийн алгоритм нь [timsort](https://en.wikipedia.org/wiki/Timsort)-ээс санаа авсан дасан зохицох, давталттай нэгтгэх төрөл юм.
    /// Энэ нь зүсмэлийг бараг эрэмбэлэх эсвэл нэг нэгнийхээ араас залгасан хоёр ба түүнээс дээш эрэмбэлэгдсэн дарааллаас бүрдэх тохиолдолд маш хурдан хийгдсэн байхаар хийгдсэн байдаг.
    ///
    /// Түүнчлэн, энэ нь түр зуурын хадгалалтыг `self`-ийн хэмжээтэй тэнцэх хэмжээгээр хуваарилдаг боловч богино зүсмэлүүдийн хувьд хуваарилалтгүй оруулах ангиллыг ашигладаг.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Түлхүүр ялгах функц бүхий зүсмэлийг эрэмбэлнэ.
    ///
    /// Эрэмбэлэх явцад түлхүүр функцийг нэг элементэд нэг л удаа дууддаг.
    ///
    /// Энэ ангилал нь тогтвортой (өөрөөр хэлбэл тэнцүү элементүүдийг эрэмбэлдэггүй) ба *O*(*m*\* * n *+* n *\* log(*n*)) хамгийн муу тохиолдолд гол функц нь *O*(*m*) .
    ///
    /// Энгийн гол функцуудын хувьд (жишээлбэл, өмчийн хандалт эсвэл үндсэн үйлдлүүд гэх мэт) [`sort_by_key`](slice::sort_by_key) илүү хурдан байх магадлалтай.
    ///
    /// # Одоогийн хэрэгжилт
    ///
    /// Одоогийн алгоритм нь Orson Peters-ийн [pattern-defeating quicksort][pdqsort] дээр суурилсан бөгөөд энэ нь санамсаргүй тохиолдлын квиксорсын хамгийн хурдан тохиолдлыг хамгийн хурдан тохиолдлын хэлбэртэй хослуулан, тодорхой хэв маяг бүхий зүсмэлүүд дээр шугаман хугацааг олж авах боломжийг олгодог.
    /// Энэ нь доройтсон тохиолдлоос зайлсхийхийн тулд зарим санамсаргүй аргыг ашигладаг боловч тогтмол seed-тэй детерминик шинж чанарыг байнга өгдөг.
    ///
    /// Хамгийн муу тохиолдолд алгоритм нь зүсмэлийн урттай `Vec<(K, usize)>` хэмжээтэй түр хадгалах санг хуваарилдаг.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Хуваарилалтыг багасгахын тулд манай vector-ийг аль болох жижиг хэлбэрээр индексжүүлэх туслах макро.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices`-ийн элементүүд нь индексжүүлсэн тул өвөрмөц байдаг тул анхны зүсмэлийн хувьд ямар ч ангилал тогтвортой байх болно.
                // Санах ой бага хуваарилах шаардлагатай тул бид `sort_unstable`-ийг энд ашигладаг.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self`-ийг шинэ `Vec` руу хуулна.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Энд `s` ба `x`-ийг бие даан өөрчилж болно.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self`-ийг хуваарилагчтай шинэ `Vec` болгон хуулна.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Энд `s` ба `x`-ийг бие даан өөрчилж болно.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, илүү дэлгэрэнгүйг энэ файл дахь `hack` модулаас үзнэ үү.
        hack::to_vec(self, alloc)
    }

    /// `self`-ийг vector болгон хувилж, хуваарилахгүйгээр хөрвүүлдэг.
    ///
    /// Үүссэн vector-ийг `Vec-ээр дамжуулан хайрцагт буцааж хөрвүүлэх боломжтой<T>`into_boxed_slice` арга.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` `x` болгон хөрвүүлсэн тул цаашид ашиглах боломжгүй.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, илүү дэлгэрэнгүйг энэ файл дахь `hack` модулаас үзнэ үү.
        hack::into_vec(self)
    }

    /// Зүсмэлийг `n` удаа давтаж vector үүсгэдэг.
    ///
    /// # Panics
    ///
    /// Хэрэв хүчин чадал нь хэтэрвэл энэ функц panic болно.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// Халих үед panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Хэрэв `n` нь тэгээс их байвал түүнийг `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` гэж хувааж болно.
        // `2^expn` нь `n`-ийн хамгийн зүүн талын '1' битээр дүрслэгдсэн тоо бөгөөд `rem` бол `n`-ийн үлдсэн хэсэг юм.
        //
        //

        // `set_len()` руу нэвтрэхийн тулд `Vec` ашиглах.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` давталт нь `buf`-ийг "дахин" давтах замаар хийгддэг.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Хэрэв `m > 0` бол '1' хамгийн зүүн тал хүртэл үлдсэн битүүд байна.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` багтаамжтай.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) давталтыг `buf`-ээс анхны `rem` давталтыг хуулж авснаар хийдэг.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Энэ нь `2^expn > rem`-ээс хойш давхцахгүй байна.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T`-ийн зүсмэлийг `Self::Output` гэсэн ганц утга болгон тэгшлэнэ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T`-ийн зүсмэлийг нэг утгатай `Self::Output` болгон тэгшлээд, өгөгдсөн тусгаарлагчийг хооронд нь байрлуулна.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T`-ийн зүсмэлийг нэг утгатай `Self::Output` болгон тэгшлээд, өгөгдсөн тусгаарлагчийг хооронд нь байрлуулна.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Энэ зүсмэлийн хуулбарыг агуулсан vector-ийг бутыг буцааж ASCII том үсэгтэй дүйцүүлэхээр буцаана.
    ///
    ///
    /// 'a'-ээс 'z' хүртэлх ASCII үсгийг 'A'-'Z' гэж буулгасан боловч ASCII бус үсэг өөрчлөгдөөгүй болно.
    ///
    /// Байршлын утгыг томоор харуулахын тулд [`make_ascii_uppercase`] ашиглана уу.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Энэ зүсмэлийн хуулбарыг агуулсан vector-ийг бутыг тус бүрийг нь ASCII жижиг үсгийн эквиваленттай буулгаж буцаана.
    ///
    ///
    /// 'A'-ээс 'Z' хүртэлх ASCII үсгийг 'a'-'z' гэж буулгасан боловч ASCII бус үсэг өөрчлөгдөөгүй болно.
    ///
    /// Орон дахь утгыг багасгахын тулд [`make_ascii_lowercase`] ашиглана уу.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Тодорхой төрлийн өгөгдлийг зүсэх зориулалттай traits өргөтгөл
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`]-д зориулсан trait туслах (зүсмэл::concat).
///
/// Note: `Item` төрлийн параметрийг энэ trait-д ашигладаггүй боловч имплүүдийг илүү ерөнхий болгох боломжийг олгодог.
/// Үүнгүйгээр бид энэ алдааг олж авна.
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Учир нь олон `Borrow<[_]>` имплтэй `V` төрлүүд байж болох бөгөөд ингэснээр олон `T` төрлүүд үйлчлэх болно:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Залгаасны дараа үүссэн төрөл
    type Output;

    /// [`[T]: : concat`]-ийн хэрэгжилт (зүсмэл::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`]-д зориулсан trait туслах (зүсмэл::нэгдэх)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Залгаасны дараа үүссэн төрөл
    type Output;

    /// [`[T]: : нэгдэх`] хэрэгжилт (зүсмэл::нэгдэх)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Зүсмэлүүдийн стандарт trait програмууд
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // дээр дарж бичихгүй зүйлээ хая
        target.truncate(self.len());

        // target.len <=Дээрх таслалтаас болж self.len тул энд байгаа зүсмэлүүд үргэлж хязгаарлагдмал байдаг.
        //
        let (init, tail) = self.split_at(target.len());

        // агуулагдсан утгуудыг дахин ашиглах allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]`-ийг урьдчилж эрэмбэлсэн `v[1..]` дараалалд оруулснаар бүхэл `v[..]` эрэмбэлэгдэх болно.
///
/// Энэ бол оруулах ангиллын салшгүй дэд програм юм.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Энд оруулгыг хэрэгжүүлэх гурван арга зам байдаг.
            //
            // 1. Эхнийх нь эцсийн цэг рүү очих хүртэл зэргэлдээ элементүүдийг хооронд нь солино.
            //    Гэсэн хэдий ч, ийм байдлаар бид шаардлагатай хэмжээнээс илүү мэдээллийг хуулж авдаг.
            //    Хэрэв элементүүд нь том бүтэцтэй бол (хуулах нь үнэтэй) бол энэ арга нь удаан байх болно.
            //
            // 2. Эхний элементэд тохирох газрыг олох хүртэл давталт хийнэ.
            // Үүний дараа элементүүдийг шилжүүлж, зай гаргаж, үлдсэн нүхэнд байрлуулна.
            // Энэ бол сайн арга юм.
            //
            // 3. Эхний элементийг түр зуурын хувьсагч руу хуулах.Тохирох газар нь олтлоо давтана.
            // Явж явахдаа туулсан элемент бүрийг урд талын нүхэнд хуулж ав.
            // Эцэст нь, түр зуурын хувьсагчаас өгөгдлийг үлдсэн нүх рүү хуулж ав.
            // Энэ арга нь маш сайн.
            // Жишиг үзүүлэлтүүд нь 2-р аргынхоос арай илүү сайн гүйцэтгэлийг харуулсан.
            //
            // Бүх аргуудыг харьцуулж үзсэн бөгөөд 3 дахь нь хамгийн сайн үр дүнг үзүүлэв.Тиймээс бид үүнийг сонгосон.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Оруулах процессын завсрын төлөвийг `hole` үргэлж хянадаг бөгөөд энэ нь хоёр зорилгыг агуулдаг.
            // 1. `is_less` дахь panics-ээс `v`-ийн бүрэн бүтэн байдлыг хамгаална.
            // 2. Эцэст нь `v` дахь үлдсэн нүхийг бөглөнө.
            //
            // Panic аюулгүй байдал:
            //
            // Хэрэв процессын явцад аль ч үед `is_less` panics байвал `hole` унаж, `v` дахь нүхийг `tmp`-ээр дүүргэх бөгөөд ингэснээр `v` нь анх барьж байсан объект бүрийг яг нэг удаа хадгалсаар байх болно.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` унаж улмаар `tmp`-ийг `v`-ийн үлдсэн нүх рүү хуулна.
        }
    }

    // Буулгахад `src`-ээс `dest` руу хуулна.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Бууралгүй `v[..mid]` ба `v[mid..]` гүйлтүүдийг `buf`-ийг түр хадгалахад ашиглаж нэгтгэж, үр дүнг `v[..]` болгон хадгална.
///
/// # Safety
///
/// Хоёр зүсмэл хоосон биш байх ёстой бөгөөд `mid` нь хязгаар байх ёстой.
/// Буфер `buf` нь богино зүсмэлийн хуулбарыг хадгалахад хангалттай урт байх ёстой.
/// Мөн `T` нь тэг хэмжээтэй байх ёсгүй.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Нэгдэх процесс нь эхлээд `buf` руу богино хувилбарыг хуулдаг.
    // Дараа нь шинээр хуулагдсан гүйлт, урагшаа урагшаа (эсвэл хойшоо) мөр үлдээж, дараагийн хэрэглээгүй элементүүдийг харьцуулж, бага (эсвэл их)-ийг `v` руу хуулна.
    //
    // Богино хугацааны гүйлт бүрэн дуусмагц процесс дуусна.Хэрэв эхлээд урт хугацаа зарцуулагдах юм бол бид `v` дахь үлдсэн нүх рүү богино хугацааны үлдсэн бүх зүйлийг хуулж авах ёстой.
    //
    // Процессийн завсрын төлөвийг `hole` үргэлж хянадаг бөгөөд энэ нь хоёр зорилгыг агуулдаг.
    // 1. `is_less` дахь panics-ээс `v`-ийн бүрэн бүтэн байдлыг хамгаална.
    // 2. Урт хугацааны туршид эхлээд зарцуулагдах тохиолдолд `v` дахь үлдсэн нүхийг бөглөнө.
    //
    // Panic аюулгүй байдал:
    //
    // Хэрэв процессын явцад ямар ч үед `is_less` panics байвал `hole` унаж, `v` дахь нүхийг `buf` дахь хэрэглээний бус мужаар дүүргэж, улмаар `v` нь анх барьж байсан бүх объектоо яг нэг удаа барьж байх болно.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Зүүн гүйлт богино байна.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Эхэндээ эдгээр заагч нь массивынхаа эхлэлийг зааж өгдөг.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Бага талыг нь хэрэглэ.
            // Хэрэв тэнцүү байвал тогтвортой байдлыг хадгалахын тулд зүүн гүйлтийг илүүд үзээрэй.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Зөв гүйлт нь богино байна.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Эхэндээ эдгээр заагч нь массивынхаа төгсгөлийг заана.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Илүү их талыг нь хэрэглэ.
            // Хэрэв тэнцүү байвал тогтвортой байдлыг хадгалахын тулд зөв гүйлтийг илүүд үзээрэй.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Эцэст нь `hole` унав.
    // Хэрэв богино хугацааг бүрэн ашиглаж чадаагүй бол үлдсэн бүх зүйлийг одоо `v` нүхэнд хуулна.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Буулгахад `start..end` мужийг `dest..` болгон хуулна.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` нь тэг хэмжээтэй төрөл биш тул хэмжээгээр нь хуваахад гэмгүй.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Энэхүү нийлүүлэлтийн төрөл нь XS [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt)-ийн талаар дэлгэрэнгүй тайлбарласан TimSort-ийн зарим (гэхдээ бүгдэд нь биш) санааг зээлж авдаг.
///
///
/// Алгоритм нь байгалийн гүйлт гэж нэрлэгддэг хатуу буурах ба буурахгүй дарааллыг тодорхойлдог.Хүлээгдээгүй байгаа хүлээгдэж буй гүйлтийн стек байна.
/// Шинээр олдсон гүйлт бүрийг стек рүү түлхэж, дараа нь эдгээр хоёр инвариант хангагдах хүртэл зэргэлдээх зарим гүйлтүүдийг нэгтгэнэ.
///
/// 1. `1..runs.len()` дахь `i` бүрийн хувьд: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` дахь `i` бүрийн хувьд: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Инвариантууд нь нийт ажиллах хугацааг *O*(*n*\*log(* n*))-ийн хамгийн муу тохиолдолд) байлгахыг баталгаажуулдаг.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Энэ урттай зүсмэлүүдийг оруулах ангиллыг ашиглан эрэмбэлнэ.
    const MAX_INSERTION: usize = 20;
    // Маш богино гүйлтийг дор хаяж энэ олон элементийг багтаасан оруулах ангиллыг ашиглан сунгадаг.
    const MIN_RUN: usize = 10;

    // Эрэмбэлэх нь тэг хэмжээст төрлүүд дээр утга учиртай шинж чанаргүй байдаг.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Богино массивыг хуваарилалтаас зайлсхийхийн тулд оруулах ангиллаар дамжуулан цэгцэлдэг.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Зураастай санах ой болгон ашиглахын тулд буферийг хуваарил.Бид 0 уртыг хадгалдаг тул хэрэв `is_less` panics бол хуулбар дээр ажилладаг дторуудыг эрсдэлд оруулахгүйгээр `v`-ийн агууламжийн гүехэн хуулбарыг хадгалах боломжтой.
    //
    // Хоёр эрэмбэлэгдсэн гүйлгээг нэгтгэх үед энэ буфер нь богино гүйлтийн хуулбарыг хадгалдаг бөгөөд энэ нь үргэлж хамгийн ихдээ `len / 2` урттай байх болно.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v`-ийн байгалийн гүйлтийг тодорхойлохын тулд бид үүнийг арагш нь туулдаг.
    // Энэ нь хачин шийдвэр мэт санагдаж болох боловч нэгтгэх нь ихэвчлэн (forwards) эсрэг чиглэлд явагддаг болохыг анхаарч үзээрэй.
    // Бенчмаркийн дагуу урагшаа нэгтгэх нь арагшаа нэгтгэхээс арай хурдан байдаг.
    // Дүгнэж хэлэхэд, ухрах замаар гүйлтийг тодорхойлох нь гүйцэтгэлийг сайжруулдаг.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Дараагийн байгалийн гүйлтийг хайж олоод доошоо бууж байвал эргүүлээрэй.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Хэрэв энэ нь хэтэрхий богино байвал зарим элементүүдийг гүйлтэд оруулаарай.
        // Оруулах эрэмбэлэлт нь богино дараалалд нэгтгэхээс илүү хурдан тул гүйцэтгэлийг ихээхэн сайжруулдаг.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Энэ гүйлтийг стек дээр дарна уу.
        runs.push(Run { start, len: end - start });
        end = start;

        // Инвариантуудыг хангахын тулд зэргэлдээх зарим гүйлтүүдийг нэгтгэх.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Эцэст нь яг нэг гүйлт нь стек дээр үлдэх ёстой.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Гүйлтийн стекийг шалгаж, нэгтгэх дараагийн гүйлтийг тодорхойлно.
    // Бүр тодруулбал `Some(r)`-ийг буцааж өгсөн тохиолдолд `runs[r]` ба `runs[r + 1]`-ийг нэгтгэх ёстой гэсэн үг юм.
    // Хэрэв алгоритм нь шинэ ажиллуулалтыг үргэлжлүүлэн хийвэл `None` буцаагдах болно.
    //
    // TimSort нь алдаатай програмуудаа энд дурдсанчлан алдартай.
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Түүхийн гол утга нь: Бид стек дээрх хамгийн дээд дөрвөн гүйлтэд орших хувьсагчдыг хэрэгжүүлэх ёстой.
    // Тэднийг зөвхөн эхний гурваар мөрдүүлэх нь инвариантууд стек дэх *бүх* гүйлтийг үргэлжлүүлэн хадгалахад хангалттай биш юм.
    //
    // Энэ функц нь хамгийн шилдэг дөрвөн гүйлтийн хувьсагчийг зөв шалгадаг.
    // Нэмж дурдахад, хэрэв дээд гүйлт 0 индексээс эхэлсэн бол эрэмбэлж дуусгахын тулд стек бүрэн нурах хүртэл нэгтгэх ажиллагааг үргэлж шаардах болно.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}