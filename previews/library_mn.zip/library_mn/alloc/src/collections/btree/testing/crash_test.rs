use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Тодорхой үйл явдлыг хянах ослын туршилтын дамми тохиолдлуудын зураг төсөл.
/// Зарим тохиолдлуудыг хэзээ нэгэн цагт panic гэж тохируулж болно.
/// Арга хэмжээ нь `clone`, `drop` эсвэл үл мэдэгдэх `query` юм.
///
/// Сүйрлийн туршилтын даммидыг id-ээр тодорхойлж, захиалах тул BTreeMap дээр түлхүүр болгон ашиглаж болно.
/// Хэрэгжилтийг санаатайгаар ашигладаг нь `Debug` trait-ээс гадна crate-д тодорхойлсон зүйлд найддаггүй.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Сүйрлийн туршилтын дамми загварыг бий болгодог.`id` нь тохиолдлын дараалал ба тэгш байдлыг тодорхойлдог.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Ямар үйл явдлууд тохиолдохыг дурдсан panics-ийг бүртгэдэг ослын тестийн дамми жишээг үүсгэдэг.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Дамми хэдэн удаа хувилагдсаныг буцаана.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Дамми хэдэн удаа унасныг буцаана.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// `query`-ийн гишүүнийг хэдэн удаа дуудсан дамми тохиолдлыг буцааж өгдөг.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Зарим нэр нь үл мэдэгдэх асуулга, үр дүнг нь аль хэдийн өгсөн болно.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}