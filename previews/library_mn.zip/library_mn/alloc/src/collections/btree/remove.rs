use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// Түлхүүр утгын хосыг модноос хасаж, тэр хосыг буцааж, мөн өмнөх хосод тохирох навч edge-ийг буцааж өгнө.
    /// Энэ нь дотоод зангилааны хоосон зайг хоослох боломжтой бөгөөд дуудагч нь модыг барьж буй газрын зураг дээр гарч ирэх ёстой.
    /// Дуудлага хийж буй хүн газрын зургийн уртыг багасгах хэрэгтэй.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // Навчны шууд эцэг эхчүүдэд зориулсан зангилааны төрөл байдаггүй тул бид хүүхдийн төрлийг түр мартах ёстой.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // АЮУЛГҮЙ БАЙДАЛ: `new_pos` бол бидний эхлүүлсэн навч эсвэл ах дүү юм.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // Зөвхөн бид нийлсэн тохиолдолд эцэг эх нь (хэрэв байгаа бол) багассан боловч дараахь алхамыг алгасах нь өөр үр дүнд хүрэхгүй.
            //
            // АЮУЛГҮЙ БАЙДАЛ: Бид `pos` байгаа навчийг устгахгүй эсвэл дахин байрлуулахгүй
            // эцэг эхтэйгээ рекурсив байдлаар харьцах замаар;хамгийн муу тохиолдолд бид эцэг эхээ эмээ өвөөгөөр нь устгаж эсвэл өөрчлөнө, ингэснээр навч доторх эцэг эхийн холбоосыг өөрчлөх болно.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // Хөрш зэргэлдээ KV-ийг навчнаас нь аваад дараа нь бидний зайлуулахыг хүссэн элементийн оронд тавь.
        //
        // `choose_parent_kv`-т жагсаасан шалтгаанаар зүүн зэргэлдээ KV-г илүүд үзээрэй.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // Дотоод зангилааг хулгайлсан эсвэл нэгтгэсэн байж болзошгүй.
        // Анхны KV хаана дууссаныг олохын тулд баруун тийшээ эргэж очно уу.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}