use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Ижил хүрээний өөр, өөрчлөгдөхгүй эквивалентийг түр зуур гаргана.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Модны тодорхой мужийг зааглах навчны тодорхой ирмэгийг олдог.
    /// Хоёр өөр бариулыг нэг модонд эсвэл хоосон сонголтыг буцааж өгдөг.
    ///
    /// # Safety
    ///
    /// `BorrowType` нь `Immut` биш бол нэг KV-д хоёр удаа зочлохын тулд давхардсан бариулыг бүү ашигла.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())`-тэй дүйцэх боловч илүү үр дүнтэй.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Модны тодорхой мужийг заагласан навчны хос ирмэгийг олдог.
    ///
    /// `BTreeMap` модны адил модыг түлхүүрээр захиалсан тохиолдолд л үр дүн нь ач холбогдолтой болно.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // АЮУЛГҮЙ БАЙДАЛ: бидний зээлийн төрөл өөрчлөгдөхгүй.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Бүхэл бүтэн модыг зааглаж буй навчны ирмэгийг олно.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Тодорхой мужийг заагласан навчны ирмэг болгон өвөрмөц лавлагааг хуваана.
    /// Үүний үр дүнд (some) мутацийг зөвшөөрсөн өвөрмөц бус лавлагаа байгаа бөгөөд үүнийг анхааралтай ашиглах хэрэгтэй.
    ///
    /// `BTreeMap` модны адил модыг түлхүүрээр захиалсан тохиолдолд л үр дүн нь ач холбогдолтой болно.
    ///
    ///
    /// # Safety
    /// Давхардсан бариулыг нэг KV дээр хоёр удаа очиж үзэхийн тулд бүү ашиглаарай.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Модны бүх хүрээг заагласан хос навчны ирмэг болгон өвөрмөц лавлагааг хуваана.
    /// Үр дүн нь мутацийг зөвшөөрдөг өвөрмөц бус лавлагаа (зөвхөн утгын хувьд) тул болгоомжтой ашиглах хэрэгтэй.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Бид NodeRef язгуурыг энд хуулбарладаг-бид хэзээ ч нэг KV-т хоёр удаа зочлохгүй бөгөөд утга давхцаж хэзээ ч давхцахгүй.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Модны бүх хүрээг заагласан хос навчны ирмэг болгон өвөрмөц лавлагааг хуваана.
    /// Үр дүн нь асар их хор хөнөөлтэй мутацийг бий болгох боломжийг олгодог өвөрмөц бус лавлагаа тул маш болгоомжтой ашиглах хэрэгтэй.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Бид NodeRef язгуурыг энд хуулбарладаг-бид root-аас авсан лавлагаа давхцаж хэзээ ч нэвтрэхгүй.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Навч edge өгөгдсөн бол [`Result::Ok`]-ийг баруун талын хөрш KV руу бариултай буцааж өгдөг бөгөөд энэ нь нэг навчны зангилаа эсвэл өвөг дээдсийн зангилаанд байрладаг.
    ///
    /// Хэрэв навч edge нь модны хамгийн сүүлчийнх бол [`Result::Err`]-ийг эх зангилаагаар буцаана.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Навч edge бариулыг өгсөн бол [`Result::Ok`]-ийг зүүн талдаа хөрш KV руу бариултай буцааж өгдөг бөгөөд энэ нь нэг навчны зангилаа эсвэл өвөг дээдсийн зангилаанд байрладаг.
    ///
    /// Хэрэв навч edge модны эхнийх бол [`Result::Err`]-ийг эх зангилаагаар буцаана.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Дотоод edge бариултай бол [`Result::Ok`]-ийг баруун талын хөрш KV руу бариултай буцааж өгдөг бөгөөд энэ нь ижил дотоод зангилаа эсвэл өвөг дээдсийн зангилаанд байрладаг.
    ///
    /// Хэрэв дотоод edge нь модны сүүлчийнх бол [`Result::Err`]-ийг root зангилаагаар буцаана.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// edge навчны бариулыг үхэж буй модонд өгөөд, дараагийн навч edge-ийг баруун талд буцааж, хооронд нь ижил навчны зангилаа, өвөг дээдсийн зангилаа, эсвэл байхгүй түлхүүр утгын хосыг буцааж өгнө.
    ///
    ///
    /// Энэ арга нь node(s)-ийн төгсгөлд хүрдэг.
    /// Энэ нь түлхүүр утгын хос байхгүй бол модны үлдсэн хэсгийг бүхэлд нь хуваарилсан байх тул буцааж өгөх зүйл үлдэхгүй гэсэн үг юм.
    ///
    /// # Safety
    /// Өгөгдсөн edge-ийг өмнө нь түнш `deallocating_next_back` буцааж өгөөгүй байх ёстой.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// edge навчны бариулыг үхэж буй модонд өгөөд дараагийн навч edge-ийг зүүн талд нь буцааж, хооронд нь ижил навчны зангилаа, өвөг дээдсийн зангилаанд байгаа эсвэл огт байхгүй түлхүүр утгын хосыг буцааж өгнө.
    ///
    ///
    /// Энэ арга нь node(s)-ийн төгсгөлд хүрдэг.
    /// Энэ нь түлхүүр утгын хос байхгүй бол модны үлдсэн хэсгийг бүхэлд нь хуваарилсан байх тул буцааж өгөх зүйл үлдэхгүй гэсэн үг юм.
    ///
    /// # Safety
    /// Өгөгдсөн edge-ийг өмнө нь түнш `deallocating_next` буцааж өгөөгүй байх ёстой.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Навчнаас үндэс хүртэл овоолсон зангилаа хуваарилдаг.
    /// Энэ нь `deallocating_next` ба `deallocating_next_back` модны хоёр талд хазаж, ижил edge цохисноос хойш модны үлдэгдлийг хуваарилах цорын ганц арга юм.
    /// Бүх түлхүүр, утгыг буцааж өгөхөд л дууддаг болохоор товчлуур эсвэл утгын аль нэгэнд нь цэвэрлэгээ хийгддэггүй.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// edge хуудасны бариулыг дараагийн edge хуудас руу шилжүүлж, түлхүүр ба завсрын утгын ишлэлийг буцаана.
    ///
    ///
    /// # Safety
    /// Аялал жуулчлалын чиглэлд өөр нэг KV байх ёстой.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// edge хуудасны бариулыг өмнөх edge хуудас руу зөөж, түлхүүр ба завсрын утгын ишлэлийг буцаана.
    ///
    ///
    /// # Safety
    /// Аялал жуулчлалын чиглэлд өөр нэг KV байх ёстой.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// edge хуудасны бариулыг дараагийн edge хуудас руу шилжүүлж, түлхүүр ба завсрын утгын ишлэлийг буцаана.
    ///
    ///
    /// # Safety
    /// Аялал жуулчлалын чиглэлд өөр нэг KV байх ёстой.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Үүнийг хамгийн сүүлд хийх нь жишиг дагуу илүү хурдан байдаг.
        kv.into_kv_valmut()
    }

    /// Хуудасны бариулыг edge өмнөх навч руу шилжүүлж, түлхүүр ба завсрын утгын ишлэлийг буцаана.
    ///
    ///
    /// # Safety
    /// Аялал жуулчлалын чиглэлд өөр нэг KV байх ёстой.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Үүнийг хамгийн сүүлд хийх нь жишиг дагуу илүү хурдан байдаг.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// edge хуудасны бариулыг дараагийн edge хуудас руу шилжүүлж, хоорондох түлхүүр ба утгыг буцааж, харгалзах edge-ийг үндсэн зангилаандаа үлдээх үед үлдсэн зангилааг хуваарилна.
    ///
    /// # Safety
    /// - Аялал жуулчлалын чиглэлд өөр нэг KV байх ёстой.
    /// - Тэр KV-ийг өмнө нь `next_back_unchecked` хамтрагч модыг дайрч өнгөрөхөд ашигладаг бариулын хуулбар дээр буцааж өгөөгүй байсан.
    ///
    /// Шинэчлэгдсэн бариулыг үргэлжлүүлэх цорын ганц аюулгүй арга бол харьцуулах, унагаах, аюулгүй байдлын нөхцлийг харгалзан энэ аргыг дахин дуудах эсвэл аюулгүй байдлын нөхцлийг харгалзан түнш `next_back_unchecked` руу залгах явдал юм.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// edge навчны бариулыг өмнөх edge хуудас руу шилжүүлж, хоорондох түлхүүр ба утгыг буцааж, харгалзах edge-ийг эх зангилаандаа үлдээх үед үлдсэн зангилаа хуваарилна.
    ///
    /// # Safety
    /// - Аялал жуулчлалын чиглэлд өөр нэг KV байх ёстой.
    /// - Энэхүү навч edge-ийг өмнө нь `next_unchecked` хамтрагч модыг туулахад ашиглаж байсан бариулын хуулбар дээр буцааж өгөөгүй болно.
    ///
    /// Шинэчлэгдсэн бариулыг үргэлжлүүлэх цорын ганц аюулгүй арга бол харьцуулах, унагаах, аюулгүй байдлын нөхцлийг харгалзан энэ аргыг дахин дуудах эсвэл аюулгүй байдлын нөхцлийг харгалзан түнш `next_unchecked` руу залгах явдал юм.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Зүүн зангилаа буюу зангилаан дор edge-ийг буцааж өгдөг, өөрөөр хэлбэл урагшлах үед хамгийн түрүүнд хэрэгтэй edge-ийг буцааж өгдөг (эсвэл хойшоо шилжихэд хамгийн сүүлд).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// edge хамгийн баруун талын навчийг зангилаан дотор эсвэл доор нь буцааж өгдөг, өөрөөр хэлбэл урагшлах үед хамгийн сүүлд хэрэгтэй edge-ийг буцааж өгдөг (эсвэл хойшоо шилжихдээ эхлээд).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Навч зангилаа ба дотоод кВ-ууд дээр түлхүүрүүдийг дээшлүүлэх дарааллаар зочлох, мөн дотоод зангилаа бүхэлд нь гүнзгий дарааллаар зочлох, ингэснээр дотоод зангилаа нь тусдаа KV болон тэдний хүүхдийн зангилааны өмнө байрладаг.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// (Дэд) модны элементийн тоог тооцоолно.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Урагш навигацийн хувьд KV-тэй хамгийн ойрхон edge навчийг буцаана.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// K0-тэй хамгийн ойрхон edge навчийг буцааж навигацийн хувьд буцааж өгдөг.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}