// Энэ бол хамгийн тохиромжтой зүйлийг дагаж хэрэгжүүлэх оролдлого юм
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust нь хамааралтай төрлүүд ба полиморфик рекурсууд байдаггүй тул бид олон аюулгүй байдлыг хангадаг.
//

// Энэхүү модулийн гол зорилго нь модыг ерөнхий (хэрэв хачин хэлбэртэй) сав гэж үзэн, B-Tree инвариантуудтай харьцахаас зайлсхийх замаар төвөгтэй байдлаас зайлсхийх явдал юм.
//
// Иймээс энэ модульд оруулгуудыг эрэмбэлэх, аль зангилаа дутуу байж болох, эсвэл дутуу гэсэн утгыг илэрхийлж байгаа эсэх нь хамаагүй.Гэсэн хэдий ч бид цөөн хэдэн инвариант дээр тулгуурладаг.
//
// - Мод нь depth/height дүрэмт хувцастай байх ёстой.Энэ нь өгөгдсөн зангилаанаас навч руу буух бүх зам яг ижил урттай гэсэн үг юм.
// - `n` урттай зангилаа нь `n` товчлуур, `n` утга, `n + 1` ирмэгтэй байна.
//   Энэ нь хоосон зангилаа хүртэл дор хаяж нэг edge байна гэсэн үг юм.
//   Навчны зангилааны хувьд "having an edge" нь бид зангилаан дахь байрлалыг тодорхойлж чадна гэсэн үг юм, учир нь навчны ирмэгүүд хоосон тул өгөгдөл дүрслэх шаардлагагүй болно.
// Дотоод зангилаанд edge нь хоёулаа байрлалыг тодорхойлдог бөгөөд хүүхдийн зангилааны заагчийг агуулдаг.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Навч зангилааны үндсэн дүрслэл ба дотоод зангилааны төлөөллийн хэсэг.
struct LeafNode<K, V> {
    /// Бид `K` ба `V` дээр ковариант байхыг хүсдэг.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Энэ зангилааны индексийг эх зангилааны `edges` массив руу оруулна.
    /// `*node.parent.edges[node.parent_idx]` `node`-тэй ижил зүйл байх ёстой.
    /// Энэ нь `parent` нь тэг биш үед эхлүүлэх баталгаатай болно.
    parent_idx: MaybeUninit<u16>,

    /// Энэ зангилаа хадгалах түлхүүр ба утгын тоо.
    len: u16,

    /// Зангилааны бодит өгөгдлийг хадгалах массивууд.
    /// Массив бүрийн зөвхөн эхний `len` элементүүдийг эхлүүлсэн бөгөөд хүчинтэй байна.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Шинэ `LeafNode` загварыг эхлүүлнэ.
    unsafe fn init(this: *mut Self) {
        // Ерөнхий бодлогын хувьд бид боломжтой бол талбаруудыг эхлүүлэлгүйгээр үлдээдэг, учир нь энэ нь Валгринд бага зэрэг хурдан бөгөөд хянахад хялбар байх ёстой.
        //
        unsafe {
            // parent_idx, түлхүүрүүд болон vals нь бүгд магадгүй UnUninit юм
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Шинэ хайрцагласан `LeafNode` үүсгэдэг.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Дотоод зангилааны суурь дүрслэл.`LeafNode`-ийн нэгэн адил эдгээр нь эхлүүлээгүй түлхүүрүүд болон утгуудыг хаяхаас урьдчилан сэргийлэхийн тулд тэдгээрийг BoxedNode-ийн ард нуух хэрэгтэй.
/// `InternalNode` руу чиглэсэн аливаа заагчийг зангилааны `LeafNode` хэсэгт шууд зааж өгч, кодыг навч болон дотоод зангилаанууд дээр ерөнхийдөө ажиллахыг зөвшөөрч, заагчийн аль нь зааж байгааг шалгах шаардлагагүй болно.
///
/// Энэ өмчийг `repr(C)` ашиглан идэвхжүүлсэн болно.
///
#[repr(C)]
// gdb_providers.py энэ төрлийг нэрийг судлах зорилгоор ашигладаг.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Энэ зангилааны хүүхдүүдийг заагч.
    /// `len + 1` Эдгээрийг эхлүүлсэн, хүчин төгөлдөр гэж үздэг, гэхдээ төгсгөл ойрхон байхад `Dying` төрлийн зээлээр модыг барьж байх үед эдгээр заагчуудын зарим нь унжиж байна.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Шинэ хайрцагласан `InternalNode` үүсгэдэг.
    ///
    /// # Safety
    /// Дотоод зангилааны инвариант нь дор хаяж нэг эхлүүлсэн, хүчин төгөлдөр edge байх явдал юм.
    /// Энэ функц нь ийм edge тохируулаагүй болно.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Бид зөвхөн өгөгдлийг эхлүүлэх хэрэгтэй;ирмэгүүд магадгүй Uninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Зангилаа руу удирддаг, тэг биш заагч.Энэ нь `LeafNode<K, V>`-ийн эзэмшдэг заагч эсвэл `InternalNode<K, V>`-ийн эзэмшдэг заагч юм.
///
/// Гэсэн хэдий ч `BoxedNode` нь зангилааны аль аль нь яг үнэндээ агуулагдаж байгаа талаар ямар ч мэдээлэл агуулдаггүй бөгөөд хэсэгчлэн энэхүү мэдээллийн хомсдолоос болж тусдаа төрөл биш бөгөөд устгагчгүй байдаг.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Эзэмшсэн модны үндэс зангилаа.
///
/// Үүнд устгагч байхгүй тул гар аргаар цэвэрлэж байх хэрэгтэй.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Эхлээд хоосон байгаа өөрийн эх зангилаа бүхий шинэ эзэмшсэн модыг буцаана.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` тэг байх ёсгүй.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Эзэмшсэн үндэс зангилааг харилцан зээлж авна.
    /// `reborrow_mut`-ээс ялгаатай нь буцаах утгыг үндсийг устгахад ашиглах боломжгүй тул модны талаархи бусад лавлагаа байхгүй тул аюулгүй юм.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Эзэмшсэн root зангилааг бага зэрэг өөрчлөгдөж зээлдэг.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Дамжин өнгөрөхийг зөвшөөрдөг, хөнөөлтэй арга, бусад зүйлийг санал болгодог лавлагаанд эргэлт буцалтгүй шилждэг.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Өмнөх root зангилаа руу чиглүүлсэн ганц edge бүхий шинэ дотоод зангилаа нэмж, тэр шинэ зангилаа root зангилаа болгож буцааж өгнө.
    /// Энэ нь өндрийг 1-ээр ихэсгэдэг бөгөөд `pop_internal_level`-ийн эсрэг юм.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, бид одоо дотоод гэдгээ мартсанаас бусад нь:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Эхний үр хүүхдээ шинэ эх зангилаа болгон ашиглаж дотоод үндэс зангилааг устгана.
    /// Энэ нь зөвхөн root зангилаа нь ганц хүүхэдтэй байх үед л дуудагдах зориулалттай тул түлхүүр, утга болон бусад хүүхдүүдийн аль нэгэнд нь цэвэрлэгээ хийхгүй.
    ///
    /// Энэ нь өндрийг 1-ээр бууруулж, `push_internal_level`-ийн эсрэг байна.
    ///
    /// `Root` объектод онцгой хандалтыг шаарддаг боловч root зангилаа биш;
    /// энэ нь бусад зангилаа эсвэл эх цэгийн лавлагааг хүчингүй болгохгүй.
    ///
    /// Хэрэв дотоод түвшин байхгүй бол Panics, өөрөөр хэлбэл root зангилаа навч байвал.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // АЮУЛГҮЙ БАЙДАЛ: бид дотооддоо байх ёстой гэж мэдэгдсэн.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // АЮУЛГҮЙ БАЙДАЛ: бид зөвхөн `self` зээл авсан бөгөөд зээлийн төрөл нь онцгой юм.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // АЮУЛГҮЙ АЖИЛЛАГАА: эхний edge-ийг үргэлж эхлүүлдэг.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` нь `Mut` байсан ч гэсэн `K` ба `V`-т үргэлж ковариант байдаг.
// Энэ нь техникийн хувьд буруу, гэхдээ `NodeRef`-ийн дотоод хэрэглээний улмаас аюулгүй байдал алдагдахад хүргэж чадахгүй, учир нь бид `K` ба `V`-ээс бүрэн ерөнхий байдалтай байдаг.
//
// Гэсэн хэдий ч олон нийтийн төрөл `NodeRef`-ийг боож боох бүрт түүний зөв зөрүүтэй эсэхийг шалгаарай.
//
/// Зангилааны лавлагаа.
///
/// Энэ төрөл нь хэрхэн ажиллахыг хянах хэд хэдэн параметртэй байдаг.
/// - `BorrowType`: Зээлийн төрлийг тодорхойлдог, насан туршдаа авч явдаг дамми төрөл.
///    - Хэрэв энэ нь `Immut<'a>` бол `NodeRef` нь `&'a Node` шиг ажилладаг.
///    - Хэрэв энэ нь `ValMut<'a>` бол `NodeRef` нь түлхүүрүүд болон модны бүтцийн хувьд ойролцоогоор `&'a Node` шиг ажилладаг боловч модны доторх утгуудын олон өөрчлөгдөж болох эшлэлүүд зэрэгцэн орших боломжийг олгодог.
///    - Хэрэв энэ нь `Mut<'a>` бол `NodeRef` нь ойролцоогоор `&'a mut Node` шиг ажилладаг боловч оруулах аргууд нь өөрчлөгдөж болох заагчийг утгад зэрэгцэн орших боломжийг олгодог.
///    - Хэрэв энэ нь `Owned` бол `NodeRef` нь `Box<Node>` шиг ажилладаг боловч устгагчгүй тул гараар цэвэрлэх ёстой.
///    - Хэрэв энэ нь `Dying` бол `NodeRef` нь `Box<Node>` шиг бараг л ажилладаг боловч модыг бага багаар устгах аргуудтай бөгөөд ердийн аргууд нь дуудлага хийхэд аюултай гэж тэмдэглэгдээгүй боловч буруу дуудвал UB-г дуудаж болно.
///
///   Аливаа `NodeRef` нь модоор дамжин өнгөрөх боломжийг олгодог тул `BorrowType` нь зөвхөн зангилаа биш бүхэл бүтэн модонд үр дүнтэй хэрэглэгддэг.
/// - `K` ба `V`: Эдгээр нь зангилаанд хадгалагдсан түлхүүр ба утгын төрлүүд юм.
/// - `Type`: Энэ нь `Leaf`, `Internal` эсвэл `LeafOrInternal` байж болно.
/// Энэ нь `Leaf` бол `NodeRef` нь навчны зангилааг, `Internal` бол `NodeRef` нь дотоод зангилаа руу чиглүүлдэг бөгөөд хэрэв `LeafOrInternal` бол `NodeRef` нь аль ч төрлийн зангилааг зааж болох юм.
///   `Type` `NodeRef`-ээс гадна ашиглахад `NodeType` гэж нэрлэдэг.
///
/// `BorrowType` ба `NodeType` хоёулаа статик аюулгүй байдлыг ашиглахын тулд бидний хэрэгжүүлж буй аргуудыг хязгаарладаг.Ийм хязгаарлалтыг хэрэгжүүлэхэд хязгаарлалт бий.
/// - Төрөл бүрийн параметрийн хувьд бид аргыг зөвхөн ерөнхий хэлбэрээр эсвэл тодорхой нэг төрөлд тодорхойлж болно.
/// Жишээлбэл, бид `into_kv` шиг аргыг бүх `BorrowType`-д ерөнхийдөө, эсвэл насан туршдаа ашигладаг бүх төрлийн хувьд нэг удаа тодорхойлж чадахгүй, яагаад гэвэл `&'a`-ийн лавлагаа буцааж өгөхийг хүсч байна.
///   Тиймээс бид үүнийг хамгийн бага чадалтай `Immut<'a>` төрлийн хувьд л тодорхойлдог.
/// - Бид `Mut<'a>`-ээс `Immut<'a>` гэж хэлэхийг шаарддаггүй.
///   Тиймээс бид `into_kv` шиг аргад хүрэхийн тулд `reborrow`-ийг илүү хүчирхэг `NodeRef` дээр дуудах ёстой.
///
/// `NodeRef` дээрх бүх аргыг зарим төрлийн лавлагаа буцаадаг:
/// - `self`-ийг утгын дагуу аваад `BorrowType`-ийн зөөсөн хугацааг буцаана.
///   Заримдаа ийм аргыг ашиглахын тулд бид `reborrow_mut` руу залгах хэрэгтэй болдог.
/// - `self`-ийг лавлагаагаар ав, (implicitly) нь `BorrowType`-ийн зөөвөрлөхийн оронд тухайн лавлагааны ашиглалтын хугацааг буцаана.
/// Ийм байдлаар зээлийг шалгагч нь буцааж өгсөн лавлагааг ашиглахад л `NodeRef` зээлсэн хэвээр байх баталгаа болно.
///   Оруулгыг дэмжих аргууд нь түүхий заагчийг буцааж өгөх замаар энэ дүрмийг нугална.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Зангилаа ба навчны түвшин тусдаа байгаа, `Type`-ээр бүрэн дүрслэх боломжгүй, зангилаа өөрөө хадгалдаггүй тогтмол түвшин.
    /// Бид зөвхөн эх зангилааны өндрийг хадгалах хэрэгтэй бөгөөд бусад зангилааны өндрийг үүнээс гаргах хэрэгтэй.
    /// `Type` бол `Leaf` бол тэг байх ёстой, `Type` бол `Internal` бол тэг биш байх ёстой.
    ///
    ///
    height: usize,
    /// Навч эсвэл дотоод зангилаа руу заагч.
    /// `InternalNode`-ийн тодорхойлолт нь заагчийг аль ч тохиолдолд хүчинтэй байхыг баталгаажуулдаг.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` хэлбэрээр савласан зангилааны лавлагааг задлах.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Дотоод зангилааны өгөгдлийг ил гаргадаг.
    ///
    /// Энэ зангилааны бусад лавлагааг хүчингүй болгохгүйн тулд түүхий ptr-г буцаана.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // АЮУЛГҮЙ БАЙДАЛ: статик зангилааны төрөл нь `Internal` юм.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Дотоод зангилааны өгөгдөлд онцгой хандалтыг зээлж авна.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Зангилааны уртыг олно.Энэ бол түлхүүр эсвэл утгын тоо юм.
    /// Ирмэгүүдийн тоо `len() + 1` байна.
    /// Аюулгүй байдлыг үл харгалзан энэхүү функцийг дуудах нь аюултай код үүсгэсэн өөрчлөгдөж болох лавлагааг хүчингүй болгох гаж нөлөөтэй болохыг анхаарна уу.
    ///
    pub fn len(&self) -> usize {
        // Хамгийн чухал нь бид зөвхөн `len` талбарт хандах боломжтой.
        // Хэрэв BorrowType бол marker::ValMut бол бид хүчингүй болгох ёсгүй утгын талаархи өөрчлөгдөж болохуйц лавлагаа байж магадгүй юм.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Зангилаа ба навчны хоорондох зайны түвшинг буцаана.
    /// Тэг өндөр гэдэг нь зангилаа өөрөө навч гэсэн үг юм.
    /// Хэрэв та үндсийг нь модоор дүрсэлсэн бол зангилаа аль өндөрт гарч ирэхийг хэлж өгнө.
    /// Хэрэв та орой дээрээ навчтай модыг дүрсэлбэл уг мод зангилаан дээр хичнээн өндөр сунаж байгааг харуулна.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Ижил зангилаа руу өөр, өөрчлөгдөхгүй лавлагааг түр хугацаагаар гаргана.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Аливаа навч эсвэл дотоод зангилааны навчны хэсгийг ил гаргадаг.
    ///
    /// Энэ зангилааны бусад лавлагааг хүчингүй болгохгүйн тулд түүхий ptr-г буцаана.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Зангилаа нь дор хаяж LeafNode хэсэгт хүчинтэй байх ёстой.
        // Энэ нь өвөрмөц эсвэл хуваалцах ёстойг бид мэдэхгүй тул энэ нь NodeRef төрлийн лавлагаа биш юм.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Одоогийн зангилааны эцэг эхийг олдог.
    /// Хэрэв одоогийн зангилаа эцэг эхтэй бол `Ok(handle)`-ийг буцааж өгдөг бөгөөд `handle` нь одоогийн зангилааг зааж байгаа эцэг эхийн edge-ийг заана.
    ///
    /// Хэрэв одоогийн зангилаа эцэг эхгүй бол анхны `NodeRef`-ийг буцааж өгөх тохиолдолд `Err(self)`-ийг буцаана.
    ///
    /// Аргын нэр нь дээр үндэс зангилаа бүхий модыг дүрслэх болно.
    ///
    /// `edge.descend().ascend().unwrap()` `node.ascend().unwrap().descend()` хоёулаа амжилтанд хүрсэн тохиолдолд юу ч хийх ёсгүй.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Хэрэв бид BorrowType бол marker::ValMut бол бид хүчингүй болгож болохгүй утгуудын талаар өөрчлөгдөж болохуйц лавлагаа байж магадгүй тул түүхий заагчийг зангилаанд ашиглах хэрэгтэй.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` нь хоосон биш байх ёстой гэдгийг анхаарна уу.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` нь хоосон биш байх ёстой гэдгийг анхаарна уу.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Аливаа навч, дотоод зангилааны навчны хэсгийг өөрчлөгдөхгүй модонд ил гаргадаг.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // АЮУЛГҮЙ БАЙДАЛ: `Immut` нэрээр авсан энэ модыг өөрчлөх боломжтой лавлагаа байж болохгүй.
        unsafe { &*ptr }
    }

    /// Зангилаан дээр хадгалагдсан түлхүүрүүдийг харах боломжийг олгодог.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend`-тэй адил зангилааны эх цэгийн талаар лавлагаа авахаас гадна тухайн үйл явц дахь одоогийн зангилааг хуваарилдаг.
    /// Энэ нь аюултай, учир нь одоогийн зангилаа хуваарилагдсан ч гэсэн хандах боломжтой хэвээр байх болно.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Энэ зангилаа нь `Leaf` гэсэн статик мэдээллийг хөрвүүлэгчдэд аюулгүй байдлаар нотолж байна.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Энэ зангилаа нь `Internal` байна гэсэн статик мэдээллийг хөрвүүлэгчдэд аюулгүй байдлаар нотолж байна.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Ижил зангилаа руу өөр, өөрчлөгдөж болох лавлагааг түр хугацаагаар гаргана.Энэ арга нь маш аюултай тул болгоомжтой байгаарай.
    ///
    /// Модны эргэн тойронд өөрчлөгдөж болохуйц заагчуудаар дамжин өнгөрөх боломжтой тул буцааж өгсөн заагчийг ашиглан эх заагчийг унжсан, хил хязгааргүй эсвэл овоолсон зээлийн дүрмийн дагуу хүчингүй болгодог.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef`-д өөр төрлийн параметрийг нэмж, шинэчилсэн заагч дээр навигацийн аргыг ашиглахыг хязгаарлаж, аюулгүй байдлыг хангахаас сэргийлээрэй.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Аливаа навч эсвэл дотоод зангилааны навчны хэсэгт тусгай хандалт зээлдэг.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // АЮУЛГҮЙ БАЙДАЛ: бид бүхэл бүтэн зангилаа руу нэвтрэх онцгой эрхтэй.
        unsafe { &mut *ptr }
    }

    /// Навч эсвэл дотоод зангилааны навчны хэсэгт нэвтрэх боломжийг санал болгодог.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // АЮУЛГҮЙ БАЙДАЛ: бид бүхэл бүтэн зангилаа руу нэвтрэх онцгой эрхтэй.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Түлхүүр хадгалах талбайн элементэд онцгой хандалтыг зээлж авна.
    ///
    /// # Safety
    /// `index` 0. .ХЯМДРАЛЫН хязгаарт байна
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // АЮУЛГҮЙ АЖИЛЛАГАА: дуудлага хийж байгаа хүн өөрөө өөр аргуудыг дуудах боломжгүй болно
        // Зээлийн насан туршдаа өвөрмөц хандалттай тул түлхүүр зүсмэлийн лавлагаа хаях хүртэл.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Зангилааны үнэ цэнэ хадгалах талбайн элемент эсвэл зүсэлтэд онцгой хандалтыг зээлж авна.
    ///
    /// # Safety
    /// `index` 0. .ХЯМДРАЛЫН хязгаарт байна
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // АЮУЛГҮЙ АЖИЛЛАГАА: дуудлага хийж байгаа хүн өөрөө өөр аргуудыг дуудах боломжгүй болно
        // Зээлийн насан туршдаа өвөрмөц хандалттай тул үнэ цэнийн зүсмэлийн лавлагааг хасах хүртэл.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge агуулгад зориулсан зангилааны хадгалах талбайн элемент эсвэл зүсмэл рүү хандах хандалтыг тусгайлан зээлж авна.
    ///
    /// # Safety
    /// `index` 0. .ХЯМДРАЛ + 1-ийн хязгаарт байна
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // АЮУЛГҮЙ АЖИЛЛАГАА: дуудлага хийж байгаа хүн өөрөө өөр аргуудыг дуудах боломжгүй болно
        // edge зүсмэлийн лавлагааг хасах хүртэл, учир нь бид зээл авах хугацаандаа өвөрмөц хандалттай байдаг.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Зангилаа нь `idx`-ээс илүү эхлүүлсэн элементүүдтэй.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Бусад элементүүд, тухайлбал, өмнөх давталтууд руу залгасан хүн рүү буцааж оруулсан онцлох эшлэлүүдтэй холилдохоос зайлсхийхийн тулд бид зөвхөн сонирхсон нэг зүйлийнхээ талаар лавлагаа үүсгэдэг.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // 0Rust #74679 дугаараас болж бид масштабын хэмжээг заагчийг албадах ёстой.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Зангилааны уртад онцгой хандалтыг зээлж авна.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Зангилааны бусад холбоосыг хүчингүй болгохгүйгээр зангилааны холбоосыг эцэг эх edge-тэй тохируулна.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Үндэс холбоосыг эцэг эх edge-ээр арилгана.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Түлхүүрийн утгын хослолыг зангилааны төгсгөлд нэмнэ.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range`-ээр буцааж өгсөн бүх зүйл нь зангилааны хувьд хүчин төгөлдөр edge индекс юм.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Түлхүүр утгын хосыг нэмж, edge-ийг тухайн хосын баруун талд, зангилааны төгсгөлд оруулна.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Зангилаа нь `Internal` эсвэл `Leaf` зангилаа мөн эсэхийг шалгана.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Зангилаан доторх тодорхой түлхүүр утгын хос эсвэл edge-ийн лавлагаа.
/// `Node` параметр нь `NodeRef` байх ёстой бол `Type` нь `KV` (түлхүүрийн утгын хос дээрх бариулыг тэмдэглэх) эсвэл `Edge` (edge дээрх бариулыг тэмдэглэх) байж болно.
///
/// `Leaf` зангилаанууд хүртэл `Edge` бариултай байж болохыг анхаарна уу.
/// Хүүхдийн зангилаан дээр заагчийг төлөөлөхийн оронд эдгээр нь гол заагч хосуудын хоорондох хүүхдийн заагчийг оруулах зайг илэрхийлдэг.
/// Жишээлбэл, 2-р урттай зангилаанд edge гэсэн 3 боломжит байрлал байх бөгөөд нэг нь зангилааны зүүн талд, хоёр хосын хооронд, нөгөө нь зангилааны баруун талд байрлана.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// `#[derive(Clone)]`-ийн бүрэн ерөнхий байдал бидэнд хэрэггүй, яагаад гэвэл `Node` нь зөвхөн Clone`able байх бөгөөд энэ нь хэзээ ч өөрчлөгдөхгүй лавлагаа болох тул `Copy` болно.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Энэ бариулын зааж өгсөн edge эсвэл түлхүүр-утга хосыг агуулсан зангилааг гаргаж авна.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Энэ бариулын зангилаан дахь байрлалыг буцаана.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` дахь түлхүүр утгын хослолын шинэ бариулыг бий болгодог.
    /// Аюулгүй, учир нь дуудлага хийж байгаа хүн `idx < node.len()` гэдгийг баталгаажуулах ёстой.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq-ийн олон нийтийн хэрэгжилт байж болох боловч зөвхөн энэ модульд ашиглагддаг.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Нэг байршилд өөр, өөрчлөгдөхгүй бариулыг түр зуур гаргана.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Бид өөрсдийн төрлийг мэдэхгүй тул Handle::new_kv эсвэл Handle::new_edge ашиглаж чадахгүй
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Бариулын зангилаа нь `Leaf` гэсэн статик мэдээллийг хөрвүүлэгчдээс найдваргүй баталдаг.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Нэг байршилд өөр, өөрчлөгдөж болох бариулыг түр зуур гаргана.
    /// Энэ арга нь маш аюултай тул болгоомжтой байгаарай.
    ///
    ///
    /// Дэлгэрэнгүй мэдээллийг `NodeRef::reborrow_mut`-с үзнэ үү.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Бид өөрсдийн төрлийг мэдэхгүй тул Handle::new_kv эсвэл Handle::new_edge ашиглаж чадахгүй
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` дээр edge-тэй шинэ бариул үүсгэдэг.
    /// Аюулгүй, учир нь дуудлага хийж байгаа хүн `idx <= node.len()` гэдгийг баталгаажуулах ёстой.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Хүчин чадлаар дүүргэсэн зангилаанд оруулахыг хүсч байгаа edge индексийг хувааж, хуваагдсан цэгийн KV индексийг тооцоолж, хаана оруулахыг тооцоолно.
///
/// Хагалах цэгийн зорилго нь түүний түлхүүр ба утга нь эцэг эхийн зангилаанд ороход оршино;
/// хуваах цэгийн зүүн талд байрлах түлхүүр, утга, ирмэг нь зүүн хүүхэд болно;
/// хуваах цэгийн баруун талд байрлах түлхүүр, утга, ирмэг нь зөв хүүхэд болно.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust дугаар #74834 нь эдгээр тэгш хэмтэй дүрмийг тайлбарлахыг хичээдэг.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Энэ edge-ээс баруун ба зүүн талд байгаа түлхүүр утгын хосуудын хооронд шинэ түлхүүр утгын хос оруулна.
    /// Энэ арга нь зангилаан дээр шинэ хос багтах хангалттай зай байна гэж үздэг.
    ///
    /// Буцаагдсан заагч оруулсан утгыг заана.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Энэ edge-ээс баруун ба зүүн талд байгаа түлхүүр утгын хосуудын хооронд шинэ түлхүүр утгын хос оруулна.
    /// Хэрэв хангалттай зай байхгүй бол энэ аргыг зангилааг хуваана.
    ///
    /// Буцаагдсан заагч оруулсан утгыг заана.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Энэ edge холбосон хүүхдийн зангилаан дахь эцэг эхийн заагч ба индексийг засна.
    /// Энэ нь ирмэгийн дарааллыг өөрчилсөн тохиолдолд ашигтай,
    fn correct_parent_link(self) {
        // Зангилааны бусад лавлагааг хүчингүй болгохгүйгээр backpointer үүсгэх.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Энэ edge ба энэ edge-ийн баруун талд байгаа гол утгын хосын хоорондох шинэ хосын баруун талд очих түлхүүр утгын шинэ хослол ба edge оруулна.
    /// Энэ арга нь зангилаан дээр шинэ хос багтах хангалттай зай байна гэж үздэг.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Энэ edge ба энэ edge-ийн баруун талд байгаа гол утгын хосын хоорондох шинэ хосын баруун талд очих түлхүүр утгын шинэ хослол ба edge оруулна.
    /// Хэрэв хангалттай зай байхгүй бол энэ аргыг зангилааг хуваана.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Энэ edge-ээс баруун ба зүүн талд байгаа түлхүүр утгын хосуудын хооронд шинэ түлхүүр утгын хос оруулна.
    /// Энэ арга нь хангалттай зай байхгүй бол зангилаагаа хувааж, салгасан хэсгийг эх цэг рүү рекурсит байдлаар, root-д хүрэх хүртэл оруулахыг оролддог.
    ///
    ///
    /// Хэрэв буцаасан үр дүн нь `Fit` бол түүний бариулын зангилаа нь энэ edge-ийн зангилаа эсвэл өвөг дээдэс байж болно.
    /// Хэрэв буцаасан үр дүн нь `Split` бол `left` талбар нь үндсэн зангилаа болно.
    /// Буцаагдсан заагч оруулсан утгыг заана.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Энэ edge заасан цэгийг олно.
    ///
    /// Аргын нэр нь дээр үндэс зангилаа бүхий модыг дүрслэх болно.
    ///
    /// `edge.descend().ascend().unwrap()` `node.ascend().unwrap().descend()` хоёулаа амжилтанд хүрсэн тохиолдолд юу ч хийх ёсгүй.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Хэрэв бид BorrowType бол marker::ValMut бол бид хүчингүй болгож болохгүй утгуудын талаар өөрчлөгдөж болохуйц лавлагаа байж магадгүй тул түүхий заагчийг зангилаанд ашиглах хэрэгтэй.
        // Өндөр талбарт нэвтрэхэд санаа зовох зүйлгүй, учир нь энэ утгыг хуулсан болно.
        // Зангилааны заагчийг ялгаж салгасны дараа бид ирмэгийн массивыг лавлагаагаар (Rust дугаар #73987) авч, массив болон дотор байгаа бусад лавлагааг хүчингүй болгохоос болгоомжил.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Бид тусдаа түлхүүр ба утгын аргуудыг дуудаж чадахгүй, учир нь хоёрдахийг дуудах нь эхнийх нь буцааж өгсөн лавлагааг хүчингүй болгодог.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// KV-ийн тохируулах түлхүүр ба утгыг солино уу.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Навчны өгөгдөлд анхаарал хандуулах замаар тодорхой `NodeType`-ийн `split`-ийг хэрэгжүүлэхэд тусалдаг.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Үндсэн зангилааг гурван хэсэгт хуваана.
    ///
    /// - Зангилааг тайрч зөвхөн энэ бариулын зүүн талд байрлах түлхүүр утгын хосыг агуулна.
    /// - Энэ бариулаар зааж өгсөн түлхүүр ба утгыг гаргаж авсан болно.
    /// - Энэ бариулын баруун талд байгаа бүх түлхүүр утгын хосуудыг шинээр хуваарилагдсан зангилаанд байрлуулсан болно.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Энэ бариулаар зааж өгсөн түлхүүр утгын хосыг арилгаж, түлхүүр утгын хос нурсан edge-ийн хамт буцаана.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Үндсэн зангилааг гурван хэсэгт хуваана.
    ///
    /// - Зангилааг тайрч зөвхөн энэ бариулын зүүн талд байрлах ирмэг ба түлхүүр утгын хосыг агуулна.
    /// - Энэ бариулаар зааж өгсөн түлхүүр ба утгыг гаргаж авсан болно.
    /// - Энэ бариулын баруун талд байрлах бүх ирмэг ба түлхүүр утгын хосыг шинээр хуваарилагдсан зангилаанд оруулав.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Дотоод түлхүүр-утга хосын эргэн тойронд тэнцвэржүүлэх үйл ажиллагааг үнэлэх, гүйцэтгэх сессийг төлөөлдөг.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Хүүхэд байхаасаа зангилааны оролцоотой тэнцвэржүүлэх контекстийг сонгоно, ингэснээр гол зангилааны эх хэсгийн зангилаан дээр зүүн эсвэл баруун тийш шууд орно.
    /// Эцэг эх байхгүй бол `Err` буцаана.
    /// Эцэг эх нь хоосон байвал Panics.
    ///
    /// Хэрэв тухайн зангилаа ямар нэг хэмжээгээр дутуу байвал хамгийн оновчтой байхын тулд зүүн талыг илүүд үздэг бөгөөд энэ нь зөвхөн зүүн эгчээсээ, хэрэв байгаа бол баруун эгчээсээ цөөн элемент агуулдаг гэсэн үг юм.
    /// Энэ тохиолдолд зүүн ахтайгаа нэгтгэх нь илүү хурдан болдог, учир нь бид зангилааны N элементийг шилжүүлэхийн оронд баруун тийш нь шилжүүлж, урд талын N элементээс илүү шилжих хэрэгтэй болно.
    /// Зүүн ахаас хулгайлах нь ихэвчлэн илүү хурдан байдаг, учир нь бид зөвхөн зангилааны N элементийг зүүн тийш шилжүүлэхийн оронд N элементийг баруун тийш шилжүүлэх хэрэгтэй.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Нэгдэх боломжтой эсэх, өөрөөр хэлбэл төв KV-ийг зэргэлдээ хүүхдийн зангилаануудтай нэгтгэх хангалттай зай байгаа эсэхийг буцаана.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Нэгтгэх ажлыг гүйцэтгэж, хаагдахад юу эргэж ирэхийг шийддэг.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // АЮУЛГҮЙ БАЙДАЛ: зангилааны өндөр нь өндрөөс доогуур байна
                // Энэ edge-ийн зангилааны тэгээс дээш байх тул тэдгээр нь дотоод юм.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Эцэг эхийн түлхүүр утгын хос болон зэргэлдээх хоёр зангилаануудыг зүүн хүүхдийн зангилаанд нэгтгэж, багасгасан эцэг эхийн цэгийг буцаана.
    ///
    ///
    /// Бид `.can_merge()` биш л бол Panics.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Эцэг эхийн түлхүүр утгын хос болон зэргэлдээ хоёр хүүхдийн зангилааг зүүн хүүхдийн зангилаанд нэгтгэж, тэр хүүхдийн зангилааг буцаана.
    ///
    ///
    /// Бид `.can_merge()` биш л бол Panics.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Эцэг эхийн түлхүүр утгын хос болон зэргэлдээх хоёр зангилааныг зүүн хүүхдийн зангилаа болгон нэгтгэж, edge-ийг хянах хүүхдийн edge дууссан хүүхдийн зангилаан дахь edge бариулыг буцааж өгнө.
    ///
    ///
    /// Бид `.can_merge()` биш л бол Panics.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Түлхүүр утгын хосыг зүүн хүүхдээс хасч, эцэг эхийн түлхүүр утгын сан дотор байрлуулж, хуучин эцэг эхийн түлхүүр утгын хосыг зөв хүүхэд рүү түлхэж өгнө.
    ///
    /// `track_right_edge_idx`-ийн тодорхойлсон анхны edge-ийн төгсгөлд тохирох баруун талын edge-тэй бариулыг буцааж өгдөг.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Түлхүүр утгын хосыг зөв хүүхдээс хасаж, эцэг эхийн түлхүүр утгын сан дотор байрлуулж, хуучин эцэг эхийн түлхүүр утгын хосыг зүүн хүүхэд рүү түлхэж өгнө.
    ///
    /// `track_left_edge_idx`-т заасан зүүн хүүхдийн edge-т шилжихгүй бариулыг буцаана.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Энэ нь `steal_left`-тэй адил хулгай хийдэг боловч олон элементийг нэг дор хулгайлдаг.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Бид аюулгүйгээр хулгайлах боломжтой эсэхийг шалгаарай.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Навчны өгөгдлийг зөөх.
            {
                // Хулгайлагдсан элементүүдийг зөв хүүхдэд байрлуул.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Зүүн хүүхдээс баруун тийш шилжих.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Хамгийн их хулгайлагдсан хосыг эцэг эх рүү шилжүүлээрэй.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Эцэг эхийн түлхүүр утгын хослолыг зөв хүүхдэд шилжүүл.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Хулгайлагдсан ирмэгүүдэд зай гаргах.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Ирмэгийг хулгайл.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left`-ийн тэгш хэмтэй клон.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Бид аюулгүйгээр хулгайлах боломжтой эсэхийг шалгаарай.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Навчны өгөгдлийг зөөх.
            {
                // Хамгийн их хулгайлагдсан хосыг эцэг эх рүү нь шилжүүл.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Эцэг эхийн түлхүүр утгын хосыг зүүн хүүхэд рүү шилжүүлээрэй.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Баруун хүүхдээс зүүн тийш шилжих.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Хулгайлагдсан элементүүд байсан газрыг цоорхойгоор нөхнө.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ирмэгийг хулгайл.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Хулгайлагдсан ирмэгүүд байсан газрыг цоорхойгоор нөхнө.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Энэ зангилаа нь `Leaf` зангилаа гэдгийг батлах статик мэдээллийг устгана.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Энэ зангилаа нь `Internal` зангилаа гэдгийг батлах статик мэдээллийг устгана.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Суурь зангилаа нь `Internal` эсвэл `Leaf` зангилаа эсэхийг шалгана.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self`-ийн дараа дагаврыг нэг зангилаанаас нөгөөд шилжүүлэх.`right` хоосон байх ёстой.
    /// `right`-ийн анхны edge нь өөрчлөгдөөгүй хэвээр байна.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Зангилаа нь хүчин чадлаасаа илүү өргөжүүлэх шаардлагатай бол оруулах үр дүн.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv`-ийн зүүн талд орших элементүүд ба ирмэгтэй одоо байгаа модны зангилаа өөрчлөгдсөн.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Зарим түлхүүр ба утгыг өөр газар оруулахын тулд хуваана.
    pub kv: (K, V),
    // `kv`-ийн баруун талд хамаарах элемент, ирмэг бүхий эзэмшсэн, залгаагүй, шинэ зангилаа.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Энэ зээлийн төрлийн зангилааны лавлагаа нь модны бусад зангилаа руу дамжих боломжийг олгодог эсэх.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal шаардлагагүй бөгөөд `borrow_mut`-ийн үр дүнг ашигладаг.
        // Товчлолыг идэвхгүй болгосноор зөвхөн root-ийн талаархи шинэ лавлагаа бий болгосноор бид `Owned` төрлийн лавлагаа бүр нь root зангилаа болохыг мэддэг.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Эхлүүлсэн элементүүдийн зүсмэл дотор утга оруулаад дараа нь нэг эхлүүлээгүй элемент оруулна.
///
/// # Safety
/// Зүсмэл нь `idx`-ээс их элементтэй.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Бүх эхлүүлсэн элементүүдийн зүсмэлээс утгыг арилгаж буцаана.
///
///
/// # Safety
/// Зүсмэл нь `idx`-ээс их элементтэй.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Зүсмэл `distance` байрлал дахь элементүүдийг зүүн тийш шилжүүлнэ.
///
/// # Safety
/// Зүсмэл нь дор хаяж `distance` элементтэй байдаг.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// `distance` зүсмэл дэхь элементүүдийг баруун тийш шилжүүлнэ.
///
/// # Safety
/// Зүсмэл нь дор хаяж `distance` элементтэй байдаг.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Бүх утгыг эхлүүлсэн элементийн зүсмэлээс эхлүүлээгүй элементийн зүсэлт рүү шилжүүлж, `src`-ийг бүх эхлүүлээгүй хэвээр үлдээнэ.
///
/// `dst.copy_from_slice(src)` шиг ажилладаг боловч `T` нь `Copy` байхыг шаарддаггүй.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;