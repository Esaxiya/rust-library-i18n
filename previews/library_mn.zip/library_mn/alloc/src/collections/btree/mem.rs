use core::intrinsics;
use core::mem;
use core::ptr;

/// Энэ нь холбогдох функцийг дуудаж `v` өвөрмөц лавлагааны цаана байгаа утгыг орлуулдаг.
///
///
/// Хэрэв `change` хаагдахад panic тохиолдвол бүх процесс цуцлагдах болно.
#[allow(dead_code)] // жишээ болгон хадгалж, future ашиглахад зориулна
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Энэ нь холбогдох функцийг дуудах замаар `v` өвөрмөц лавлагааны цаана байгаа утгыг орлуулж, үр дүнд хүрэх үр дүнг буцаана.
///
///
/// Хэрэв `change` хаагдахад panic тохиолдвол бүх процесс цуцлагдах болно.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}