use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Хоёр өгсөх давталтын нэгдлээс бүх түлхүүр утгын хосыг нэмж, зам дагуу `length` хувьсагчийг нэмэгдүүлнэ.Сүүлийнх нь дуудлага өгч буй хүн сандрахад дуудлага хийгч алдагдахаас зайлсхийхэд хялбар болгодог.
    ///
    /// Хэрэв давталт хоёулаа ижил түлхүүр гаргадаг бол энэ арга нь зүүн давталтаас хосыг унагаж, баруун давталтаас хосыг хавсаргана.
    ///
    /// Хэрэв та `BTreeMap`-тэй адил модыг яг дээшлэх дарааллаар дуусгахыг хүсч байвал давталт хийгч хоёулаа модны бүх түлхүүрээс илүү түлхүүрүүдийг гаргана.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Бид `left` ба `right`-ийг шугаман хугацаанд эрэмбэлсэн дараалалд нэгтгэхээр бэлтгэж байна.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Үүний зэрэгцээ бид дараалсан дарааллаар модыг шугаман хугацаанд барьдаг.
        self.bulk_push(iter, length)
    }

    /// Бүх түлхүүр утгын хосыг модны төгсгөл рүү түлхэж, зам дагуу `length` хувьсагчийг нэмэгдүүлнэ.
    /// Сүүлд нь давталт хийх хүн сандрахад дуудлага хийгч алдагдахаас зайлсхийхэд хялбар болгодог.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Бүх түлхүүр утгын хосыг давтаж, тэдгээрийг зөв түвшинд зангилаа руу түлхэж оруулаарай.
        for (key, value) in iter {
            // Түлхүүр утгын хосыг одоогийн навчны цэг рүү түлхэхийг хичээ.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Зай үлдэхгүй, дээшээ гараад тийшээ түлх.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Зүүн зай үлдсэн зангилаа олоод энд дарна уу.
                                open_node = parent;
                                break;
                            } else {
                                // Дахин дээш яв.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Бид дээд хэсэгт байна, шинэ эх зангилаа үүсгээд тийшээ түлх.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Түлхүүр утгын хос болон шинэ баруун дэд модыг түлхэх.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Дахин хамгийн баруун тал руу доошоо буу.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Давталт болгонд урагшлахдаа урагш ахисан ч газрын зураг хавсаргасан элементүүдийг унагах эсэхийг баталгаажуулах.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Хоёр эрэмбэлэгдсэн дарааллыг нэг болгон нэгтгэхэд зориулсан давталт
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Хэрэв хоёр түлхүүр тэнцүү бол зөв эх үүсвэрээс түлхүүр-утгын хосыг буцаана.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}