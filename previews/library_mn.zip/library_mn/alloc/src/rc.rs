//! Нэг урсгалтай лавлах тоолох заагч.'Rc' нь 'Reference гэсэн үг юм
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] төрөл нь овооролд хуваарилагдсан `T` төрлийн утгыг дундын өмчлөлд өгдөг.
//! [`clone`][clone]-ийг [`Rc`] дээр дуудахад овоон дахь ижил хуваарилалтад шинэ заагч гарч ирдэг.
//! Тухайн хуваарилалтын сүүлийн [`Rc`] заагч устгагдахад тухайн хуваарилалтад хадгалагдсан утга (ихэвчлэн "inner value" гэж нэрлэдэг) буурдаг.
//!
//! Rust дахь хуваалцсан лавлагаа нь мутацийг анхдагчаар зөвшөөрдөггүй бөгөөд [`Rc`] нь үл хамаарах зүйл биш юм: та ерөнхийдөө [`Rc`] дотор байгаа зүйлийн өөрчлөгдөж болох лавлагаа авч чадахгүй.
//! Хэрэв танд хувирамтгай байдал хэрэгтэй бол [`Cell`] эсвэл [`RefCell`]-ийг [`Rc`] дотор тавь;[an example of mutability inside an `Rc`][mutability]-г үзнэ үү.
//!
//! [`Rc`] атомын бус лавлагаа тооллогыг ашигладаг.
//! Энэ нь нэмэлт зардал маш бага боловч [`Rc`]-ийг утас хооронд дамжуулах боломжгүй тул [`Rc`] нь [`Send`][send]-ийг хэрэгжүүлдэггүй гэсэн үг юм.
//! Үүний үр дүнд Rust хөрвүүлэгч нь *хөрвүүлэх үед* таныг утаснуудын хооронд [`Rc`] s илгээхгүй байгаа эсэхийг шалгана.
//! Хэрэв танд олон урсгалтай, атомын лавлагаа тоолох шаардлагатай бол [`sync::Arc`][arc] ашиглана уу.
//!
//! [`downgrade`][downgrade] аргыг эзэмшдэггүй [`Weak`] заагчийг бий болгоход ашиглаж болно.
//! [`Weak`] заагч нь [`Rc`] руу [`шинэчлэх '][шинэчлэх] d байж болох боловч хэрэв хуваарилалтад хадгалагдсан утга аль хэдийн унасан бол энэ нь [`None`]-ийг буцааж өгөх болно.
//! Өөрөөр хэлбэл, `Weak` заагч нь хуваарилалтын доторх утгыг амьд байлгахгүй;Гэсэн хэдий ч тэд хуваарилалтыг (дотоод үнэ цэнийг дэмжих дэлгүүр) амьд байлгадаг.
//!
//! [`Rc`] заагчийн хоорондох циклийг хэзээ ч хуваарилахгүй.
//! Энэ шалтгааны улмаас [`Weak`] нь мөчлөгийг таслахад ашигладаг.
//! Жишээлбэл, мод нь эцэг эхийн зангилаагаас хүүхдэд чиглэсэн хүчтэй [`Rc`] заагч, хүүхдээс эцэг эх рүүгээ буцаж очдог [`Weak`] заагчтай байж болно.
//!
//! `Rc<T>` автоматаар `T` руу шилжүүлдэг ([`Deref`] trait-ээр), тиймээс та [`Rc<T>`][`Rc`] төрлийн утга дээр `T`-ийн аргуудыг дуудаж болно.
//! "T" аргуудтай нэр зөрөхөөс зайлсхийхийн тулд [`Rc<T>`][`Rc`] аргууд нь [fully qualified syntax] ашиглан холбогдсон функцууд юм.
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! "Rc<T>traits-ийн `Clone` шиг хэрэгжүүлэлтийг бүрэн чадварлаг синтакс ашиглан дуудаж болно.
//! Зарим хүмүүс бүрэн мэргэшсэн синтакс ашиглахыг илүүд үздэг бол зарим нь метод-дуудлагын синтакс ашиглахыг илүүд үздэг.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Арга-дуудлагын синтакс
//! let rc2 = rc.clone();
//! // Бүрэн мэргэшсэн синтакс
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T`-ийг автоматаар хасдаггүй, учир нь дотоод утга нь аль хэдийн унасан байж магадгүй юм.
//!
//! # Лавлагаа хуулбарлах
//!
//! Одоо байгаа лавлагаа тоолсон заагчтай ижил хуваарилалтад шинэ лавлагаа үүсгэх нь [`Rc<T>`][`Rc`] ба [`Weak<T>`][`Weak`]-д хэрэгжүүлсэн `Clone` trait ашиглан хийгддэг.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Доорх хоёр синтакс нь тэнцүү байна.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a ба b хоёулаа foo-той ижил санах ойн байрлалыг зааж өгдөг.
//! ```
//!
//! `Rc::clone(&from)` синтакс нь кодын утгыг илүү тодорхой илэрхийлдэг тул хамгийн хэлц үг юм.
//! Дээрх жишээнд энэ синтакс нь foo-ийн агуулгыг бүхэлд нь хуулахаас илүүтэйгээр энэ код нь шинэ лавлагаа үүсгэж байгааг харахад хялбар болгож байна.
//!
//! # Examples
//!
//! Gadget-ийн багцыг тухайн `Owner` эзэмшдэг хувилбарыг авч үзье.
//! Бид өөрсдийнхөө Gadget-ийг `Owner` руу чиглүүлэхийг хүсч байна.Бид үүнийг өвөрмөц өмчлөлөөр хийж чадахгүй, учир нь ижил `Owner`-д нэгээс олон багаж байх боломжтой.
//! [`Rc`] `Owner`-ийг олон Gadget-ийн хооронд хуваалцах боломжийг олгодог бөгөөд `Owner` нь `Gadget` цэгүүд байгаа л бол хуваарилагдан үлддэг.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... бусад талбарууд
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... бусад талбарууд
//! }
//!
//! fn main() {
//!     // Лавлах тоолсон `Owner` үүсгэх.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner`-т хамаарах "Gadget"-ыг үүсгээрэй.
//!     // `Rc<Owner>`-ийг клончлох нь ижил `Owner` хуваарилалтад шинэ заагчийг өгч, процесс дахь лавлагаа тоог нэмэгдүүлнэ.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Манай орон нутгийн `gadget_owner` хувьсагчийг устгана уу.
//!     drop(gadget_owner);
//!
//!     // Хэдийгээр `gadget_owner`-ийг унагаасан ч бид Gadget-ийн `Owner`-ийн нэрийг хэвлэх боломжтой хэвээр байна.
//!     // Учир нь бид зааж өгсөн `Owner`-ийг биш зөвхөн ганц `Rc<Owner>`-ийг унагав.
//!     // Үүнтэй ижил `Owner` хуваарилалтыг зааж байгаа бусад `Rc<Owner>` байгаа тохиолдолд шууд хэвээр байх болно.
//!     // `gadget1.owner.name` талбайн проекц нь `Rc<Owner>` нь `Owner` руу автоматаар шилждэг тул ажилладаг.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Функцийн төгсгөлд `gadget1` ба `gadget2` устгагдсан бөгөөд тэдгээрийн хамт бидний `Owner`-ийн сүүлчийн тоолсон лавлагаа.
//!     // Gadget Man одоо бас устах болно.
//!     //
//! }
//! ```
//!
//! Хэрэв бидний шаардлага өөрчлөгдөж, мөн бид `Owner`-ээс `Gadget` хүртэл туулах чадвартай байх юм бол бид асуудалтай тулгарах болно.
//! `Owner`-ээс `Gadget` хүртэлх [`Rc`] заагч нь мөчлөгийг танилцуулдаг.
//! Энэ нь тэдгээрийн лавлагааны тоо хэзээ ч 0 хүрч чадахгүй бөгөөд хуваарилалт хэзээ ч устахгүй гэсэн үг юм.
//! санах ойн алдагдал.Үүнийг тойрон гарахын тулд [`Weak`] заагчийг ашиглаж болно.
//!
//! Rust нь энэ давталтыг үйлдвэрлэхэд эхний ээлжинд нэлээд төвөгтэй болгодог.Бие бие рүүгээ чиглэсэн хоёр утгыг дуусгахын тулд тэдгээрийн нэг нь өөрчлөгдөж байх ёстой.
//! [`Rc`] нь санах ойн аюулгүй байдлыг хангаж, зөвхөн оролтын утгын талаар хуваалцсан лавлагаа өгдөг тул эдгээр нь шууд мутацийг зөвшөөрдөггүй тул энэ нь хэцүү юм.
//! Бид мутац хийхийг хүсч буй утгынхаа хэсгийг [`RefCell`]-ээр боох хэрэгтэй бөгөөд үүнд *дотоод хувирал* өгдөг: хуваалцсан лавлагаагаар өөрчлөгдөж болох арга.
//! [`RefCell`] Rust-ийн зээл авах дүрмийг ажлын цагаар мөрддөг.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... бусад талбарууд
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... бусад талбарууд
//! }
//!
//! fn main() {
//!     // Лавлах тоолсон `Owner` үүсгэх.
//!     // Бид Gadget-ийн Эзний vector-ийг `RefCell` дотор байрлуулсан тул үүнийг хуваалцсан лавлагаагаар мутацлах боломжтой гэдгийг анхаарна уу.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Өмнөх шигээ `gadget_owner`-т хамаарах "Gadget"-ыг үүсгээрэй.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Gadget-ыг `Owner` дээр нэмэх.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` динамик зээл энд дуусна.
//!     }
//!
//!     // Манай Gadget-ыг давтаж, тэдгээрийн дэлгэрэнгүй мэдээллийг хэвлэ.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` нь `Weak<Gadget>` юм.
//!         // `Weak` заагч нь хуваарилалтыг баталгаажуулж чадахгүй тул бид `Option<Rc<Gadget>>`-ийг буцаах `upgrade` руу залгах хэрэгтэй.
//!         //
//!         //
//!         // Энэ тохиолдолд бид хуваарилалт байсаар байгаа тул `unwrap` `Option`-ийг ашиглах болно.
//!         // Илүү төвөгтэй програмын хувьд танд `None` үр дүнд алдаа гаргахад хялбар байх шаардлагатай байж магадгүй юм.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Функцийн төгсгөлд `gadget_owner`, `gadget1`, `gadget2` устгагдана.
//!     // Одоо төхөөрөмжүүдэд хүчтэй (`Rc`) заагч байхгүй тул тэдгээрийг устгасан болно.
//!     // Энэ нь Gadget Man-ийн лавлагааны тоог тэглэх тул тэр бас устах болно.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Энэ бол талбарыг дахин өөрчлөхөөс хамгаалагдсан repr(C)-ээс future-тэй нийцэж байгаа бөгөөд энэ нь өөр хэлбэрт шилжих боломжтой дотоод [into|from]_raw()-т саад болох болно.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Нэг урсгалтай лавлагаа тоолох заагч.'Rc' нь 'Reference гэсэн үг юм
/// Counted'.
///
/// Дэлгэрэнгүй мэдээллийг [module-level documentation](./index.html)-с үзнэ үү.
///
/// `Rc`-ийн өвөрмөц аргууд нь бүгд холбоотой функцүүд бөгөөд та тэдгээрийг `value.get_mut()`-ийн оронд [`Rc::get_mut(&mut value)`][get_mut] гэж нэрлэх хэрэгтэй гэсэн үг юм.
/// Энэ нь дотоод төрлийн `T` аргуудтай зөрчилдөхөөс зайлсхийдэг.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Энэ Rc нь амьд байхад бид дотоод заагч хүчинтэй гэсэн баталгаатай тул аюулгүй байдлыг хангахгүй байна.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Шинэ `Rc<T>` бүтээдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Бүх хүчтэй заагчдад эзэмшдэг далд сул заагч байдаг бөгөөд энэ нь хүчирхэг устгагч ажиллаж байх үед сул дорой устгагч хуваарилалтыг хэзээ ч суллахгүй байхыг баталгаажуулдаг.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Өөртөө сул лавлагаа ашиглан шинэ `Rc<T>` бүтээдэг.
    /// Энэ функц буцаж ирэхээс өмнө сул лавлагааг сайжруулахыг оролдох нь `None` утгыг гаргах болно.
    ///
    /// Гэхдээ сул лавлагааг чөлөөтэй хувилж, дараа нь ашиглахаар хадгалж болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... бусад талбарууд
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Нэг сул лавлагаагаар "uninitialized" төлөвт дотор талыг нь байгуул.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Бид сул заагчийг эзэмшихээс татгалзахгүй байх нь чухал бөгөөд эс тэгвээс `data_fn` буцаж ирэхэд санах ой суллагдах болно.
        // Хэрэв бид үнэхээр өмчлөхийг хүсч байсан бол өөрсдөдөө нэмэлт сул заагчийг бий болгож болох боловч энэ нь сул лавлагааны тоонд нэмэлт шинэчлэлт хийх шаардлагатай бөгөөд өөрөөр хэлбэл шаардлагагүй байж магадгүй юм.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Хүчтэй лавлагаа нь хуваалцсан сул лавлагааг хамтад нь эзэмшсэн байх ёстой тул бидний хуучин сул лавлагааг устгагчаар бүү ажиллуул.
        //
        mem::forget(weak);
        strong
    }

    /// Эхлээгүй агуулгатай шинэ `Rc` бүтээдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Хойшлуулсан эхлүүлэх:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Санах ойг `0` байтаар дүүргэсэн, эхлүүлээгүй агуулгатай шинэ `Rc` бүтээдэг.
    ///
    ///
    /// Энэ аргыг зөв, буруу ашигласан жишээг [`MaybeUninit::zeroed`][zeroed]-ээс үзнэ үү.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Шинэ `Rc<T>`-ийг бүтээж, хуваарилалт амжилтгүй болбол алдаа буцааж өгдөг
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Бүх хүчтэй заагчдад эзэмшдэг далд сул заагч байдаг бөгөөд энэ нь хүчирхэг устгагч ажиллаж байх үед сул дорой устгагч хуваарилалтыг хэзээ ч суллахгүй байхыг баталгаажуулдаг.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Эхлээгүй агуулгатай шинэ `Rc`-ийг бүтээж, хуваарилалт амжилтгүй болбол алдаа буцааж өгдөг
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Хойшлуулсан эхлүүлэх:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Санах ойг `0` байтаар дүүргэж, хуваарилалт амжилтгүй болбол алдаа буцааж, шинэчилсэн агуулга бүхий шинэ `Rc` бүтээдэг.
    ///
    ///
    /// Энэ аргыг зөв, буруу ашигласан жишээг [`MaybeUninit::zeroed`][zeroed]-ээс үзнэ үү.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Шинэ `Pin<Rc<T>>` бүтээдэг.
    /// Хэрэв `T` нь `Unpin`-ийг хэрэгжүүлээгүй бол `value` нь санах ойд бэхлэгдэж, шилжих боломжгүй болно.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Хэрэв `Rc` яг нэг хүчтэй лавлагаатай бол дотоод утгыг буцаана.
    ///
    /// Үгүй бол [`Err`]-ийг нэвтрүүлсэн `Rc`-тэй буцаадаг.
    ///
    ///
    /// Гайхамшигтай сул лавлагаа байгаа ч гэсэн энэ нь амжилтанд хүрнэ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // агуулагдах объектыг хуулах

                // Хүчтэй тоог бууруулснаар тэднийг сурталчлах боломжгүй гэдгийг сул талуудад зааж өгөөд, далд "strong weak" заагчийг арилгаж, хуурамч Сул дорой зүйлийг хийх замаар уналтын логиктой харьцах хэрэгтэй.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Эхлээгүй агуулгатай лавлагаа тоолсон шинэ зүсмэлийг барина.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Хойшлуулсан эхлүүлэх:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Санах ойг `0` байтаар дүүргэсэн, эхлэлгүй агуулгатай, лавлагаа тоолсон шинэ зүсмэлийг бүтээдэг.
    ///
    ///
    /// Энэ аргыг зөв, буруу ашигласан жишээг [`MaybeUninit::zeroed`][zeroed]-ээс үзнэ үү.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` руу хөрвүүлдэг.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-тэй адил дотоод үнэ цэнэ нь анхны байдалд байгаа эсэхийг баталгаажуулах нь дуудлага хийгчээс хамаарна.
    ///
    /// Агуулга бүрэн эхлээгүй байхад үүнийг дуудах нь шууд тодорхойлогдохгүй зан үйлийг үүсгэдэг.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Хойшлуулсан эхлүүлэх:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` руу хөрвүүлдэг.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-тэй адил дотоод үнэ цэнэ нь анхны байдалд байгаа эсэхийг баталгаажуулах нь дуудлага хийгчээс хамаарна.
    ///
    /// Агуулга бүрэн эхлээгүй байхад үүнийг дуудах нь шууд тодорхойлогдохгүй зан үйлийг үүсгэдэг.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Хойшлуулсан эхлүүлэх:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Ороосон заагчийг буцааж `Rc`-ийг хэрэглэдэг.
    ///
    /// Санах ой алдагдахаас зайлсхийхийн тулд заагчийг [`Rc::from_raw`][from_raw] ашиглан `Rc` руу буцааж хөрвүүлэх хэрэгтэй.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Өгөгдөлд түүхий заагч өгдөг.
    ///
    /// Тооллогуудад ямар нэгэн байдлаар нөлөөлөхгүй бөгөөд `Rc`-ийг хэрэглэдэггүй.
    /// Заагч нь `Rc`-д хүчтэй тоологдсон тохиолдолд хүчинтэй байна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // АЮУЛГҮЙ БАЙДАЛ: Энэ нь Deref::deref эсвэл Rc::inner-ээр дамжих боломжгүй юм
        // жишээ нь raw/mut туршилтыг хадгалахын тулд шаардлагатай болно
        // `get_mut` `from_raw`-ээр Rc сэргээгдсэний дараа заагчаар бичиж болно.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Түүхий заагчаас `Rc<T>` бүтээдэг.
    ///
    /// Түүхий заагчийг өмнө нь [`Rc<U>::into_raw`][into_raw] руу залгаж буцааж өгсөн байх ёстой бөгөөд `U` нь `T`-тай ижил хэмжээтэй, зэрэгцсэн байх ёстой.
    /// Хэрэв `U` нь `T` бол энэ нь өчүүхэн үнэн юм.
    /// Хэрэв `U` бол `T` биш боловч ижил хэмжээтэй, зэрэгцүүлэлттэй бол энэ нь үндсэндээ өөр өөр төрлийн лавлагаа шилжүүлэхтэй адил гэдгийг анхаарна уу.
    /// Энэ тохиолдолд ямар хязгаарлалт үйлчлэх талаар [`mem::transmute`][transmute]-ээс үзнэ үү.
    ///
    /// `from_raw`-ийн хэрэглэгч `T`-ийн тодорхой утгыг зөвхөн нэг удаа унагаах ёстой.
    ///
    /// Энэ функц нь аюултай, учир нь зохисгүй хэрэглээ нь санах ойн аюулгүй байдалд хүргэж болзошгүй тул буцаж ирсэн `Rc<T>`-д хэзээ ч нэвтрэхгүй байсан ч гэсэн.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Нэвтрэхээс сэргийлж `Rc` руу хөрвүүл.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Цаашид `Rc::from_raw(x_ptr)` руу залгах нь санах ойд аюулгүй байх болно.
    /// }
    ///
    /// // `x` дээрх хамрах хүрээнээс гарах үед санах ой суллагдсан тул `x_ptr` одоо унжиж байна!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Эх RcBox-ийг олохын тулд офсетыг буцааж эргүүл.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Энэхүү хуваарилалтад шинэ [`Weak`] заагч үүсгэдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Бид унжсан Сул талыг бий болгохгүй байхыг анхаараарай
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Энэ хуваарилалтын [`Weak`] заагчийн тоог авна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Энэхүү хуваарилалтад чиглэсэн хүчтэй (`Rc`) заагчийн тоог авна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Хэрэв энэ хуваарилалтад өөр `Rc` эсвэл [`Weak`] заагч байхгүй бол `true` буцаана.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Хэрэв ижил хуваарилалтад өөр `Rc` эсвэл [`Weak`] заагч байхгүй бол өгөгдсөн `Rc` руу өөрчлөгдөж болох лавлагааг буцаана.
    ///
    ///
    /// [`None`]-ийг буцааж өгдөг, учир нь хуваалцсан утгыг өөрчлөх нь аюулгүй байдаг.
    ///
    /// Бусад заагч байгаа үед дотоод утгыг [`clone`][clone] болгох [`make_mut`][make_mut]-ийг үзнэ үү.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Өгөгдсөн `Rc` руу өөрчлөгдөж болох лавлагааг ямар ч шалгалтгүйгээр буцаана.
    ///
    /// Аюулгүй, зохих шалгалтыг хийдэг [`get_mut`]-ийг үзнэ үү.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Үүнтэй ижил хуваарилалтыг зааж өгсөн бусад `Rc` эсвэл [`Weak`] заагчийг буцааж авсан зээлийн хугацаанд хамааруулж болохгүй.
    ///
    /// Хэрэв ийм заагч байхгүй бол, жишээ нь `Rc::new`-ийн дараа шууд л ийм тохиолдол гардаг.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Бид "count" талбаруудыг хамарсан лавлагаа үүсгэхгүй байх *-ыг анхааралтай хийдэг, учир нь энэ нь лавлагааны тооллогын хандалттай зөрчилдөх болно (жишээлбэл.
        // `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Хоёр Rc нь ижил хуваарилалтыг зааж өгсөн бол `true`-ийг буцааж өгдөг ([`ptr::eq`]-тэй төстэй судал дээр).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Өгөгдсөн `Rc`-ийн талаар өөрчлөгдөж болно.
    ///
    /// Хэрэв ижил хуваарилалтад өөр `Rc` заагч байгаа бол өвөрмөц өмчлөлийг баталгаажуулахын тулд `make_mut` нь дотоод хуваарийг шинэ хуваарилалтад [`clone`] болгоно.
    /// Үүнийг бас бичихийг хуулбарлах гэж нэрлэдэг.
    ///
    /// Хэрэв энэ хуваарилалтад өөр `Rc` заагч байхгүй бол энэ хуваарилалтын [`Weak`] заагчийг салгах болно.
    ///
    /// Мөн клончлох биш бүтэлгүйтэх [`get_mut`]-ийг үзнэ үү.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Юу ч хувилахгүй
    /// let mut other_data = Rc::clone(&data);    // Дотоод мэдээллийг хуулбарлахгүй
    /// *Rc::make_mut(&mut data) += 1;        // Дотоод өгөгдлийг хуулбарлана
    /// *Rc::make_mut(&mut data) += 1;        // Юу ч хувилахгүй
    /// *Rc::make_mut(&mut other_data) *= 2;  // Юу ч хувилахгүй
    ///
    /// // Одоо `data` ба `other_data` нь өөр өөр хуваарилалтыг зааж өгдөг.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] заагчийг салгах болно:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Өгөгдлийг клончлох хэрэгтэй, өөр Rcs байна.
            // Клондсон утгыг шууд бичих боломжийг олгохын тулд санах ойг урьдчилан хуваарилна уу.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Зөвхөн өгөгдлийг хулгайлж чадна, зөвхөн сул талууд л үлдэнэ
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Ил далд хүчтэй сул бичгийг арилгах (энд хуурамч сул тал хийх шаардлагагүй-бусад сул талууд бидний төлөө цэвэрлэж чадна гэдгийг бид мэднэ)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Буцааж өгсөн заагч нь T-д буцаагдах *цорын ганц* заагч гэдгийг бид баталж байгаа тул аюулгүй байдал хангалтгүй байна.
        // Энэ үед бидний лавлагааны тоо 1 байх баталгаатай бөгөөд `Rc<T>` өөрөө `mut` байхыг шаардсан тул хуваарилалтын цорын ганц боломжит лавлагааг буцааж өгч байна.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>`-ийг бетоны төрөлд буулгах оролдлого.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Хэмжигдээгүй хэмжээтэй байж болох дотоод утгын хувьд хангалттай зайтай `RcBox<T>`-ийг хуваарилдаг.
    ///
    /// `mem_to_rcbox` функцийг өгөгдлийн заагчтай хамт дууддаг бөгөөд `RcBox<T>`-ийн хувьд (өөх тос байж болзошгүй) заагчийг буцааж өгөх ёстой.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Өгөгдсөн утгын байршлыг ашиглан байршлыг тооцоол.
        // Өмнө нь байршлыг `&*(ptr as* const RcBox<T>)` илэрхийлэл дээр тооцдог байсан боловч энэ нь буруу тохируулсан лавлагаа үүсгэсэн (#54908-г үзнэ үү).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Хэмжигдэхгүй хэмжээтэй дотоод утгын хувьд хангалттай зай бүхий `RcBox<T>`-ийг хуваарилж өгсөн тохиолдолд хуваарилалт амжилтгүй болбол алдаа буцааж өгдөг.
    ///
    ///
    /// `mem_to_rcbox` функцийг өгөгдлийн заагчтай хамт дууддаг бөгөөд `RcBox<T>`-ийн хувьд (өөх тос байж болзошгүй) заагчийг буцааж өгөх ёстой.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Өгөгдсөн утгын байршлыг ашиглан байршлыг тооцоол.
        // Өмнө нь байршлыг `&*(ptr as* const RcBox<T>)` илэрхийлэл дээр тооцдог байсан боловч энэ нь буруу тохируулсан лавлагаа үүсгэсэн (#54908-г үзнэ үү).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Байршлын хувьд хуваарилах.
        let ptr = allocate(layout)?;

        // RcBox-ийг эхлүүлэх
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Хэмжигдээгүй дотоод утгад хангалттай зай бүхий `RcBox<T>`-ийг хуваарилдаг
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Өгөгдсөн утгыг ашиглан `RcBox<T>`-д хуваарилах.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Утга байтыг хуулах
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Агуулгыг унагаалгүйгээр хуваарилалтыг үнэгүй болгоно уу
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Өгөгдсөн урттай `RcBox<[T]>`-ийг хуваарилдаг.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Элементүүдийг зүсмэлээс шинээр хуваарилагдсан Rc <\[T\]> руу хуулах
    ///
    /// Аюулгүй, учир нь залгасан хүн өмчлөх ёстой эсвэл `T: Copy`-ийг холбох ёстой
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Тодорхой хэмжээгээр мэдэгдэж байсан давталтаас `Rc<[T]>` бүтээдэг.
    ///
    /// Хэмжээ нь буруу байвал биеэ авч явах байдал нь тодорхойгүй байдаг.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Т элементүүдийг клончлох үед Panic хамгаалагч.
        // panic гарсан тохиолдолд шинэ RcBox дээр бичигдсэн элементүүдийг унагаж, дараа нь санах ойг чөлөөлнө.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Эхний элемент рүү заагч
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Бүгд тодорхой.Шинэ RcBox-ийг чөлөөлөхгүйн тулд хамгаалагчаа март.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>`-д ашигладаг төрөлжсөн trait.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc`-ийг унагаадаг.
    ///
    /// Энэ нь хүчтэй лавлагааны тоог бууруулна.
    /// Хэрэв хүчтэй лавлагааны тоо тэг болж байвал бусад лавлагаа (хэрэв байгаа бол) нь [`Weak`] тул дотоод утгыг бид `drop` болгож тэмдэглэнэ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Юу ч хэвлэхгүй
    /// drop(foo2);   // "dropped!" хэвлэнэ
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // агуулагдах объектыг устгах
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // агуулгыг устгасан тул далд "strong weak" заагчийг устгана уу.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` заагчийн клоныг гаргадаг.
    ///
    /// Энэ нь ижил хуваарилалтад өөр заагчийг бий болгож, хүчтэй лавлагааны тоог нэмэгдүүлдэг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T`-ийн `Default` утгатай шинэ `Rc<T>` үүсгэдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Хэдийгээр `Eq`-т аргатай боловч `Eq` дээр мэргэшэхийг зөвшөөрч хак.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Бид энэ мэргэшлийг `&T` дээр ерөнхийдөө оновчтой болгох үүднээс биш энд хийж байна, яагаад гэвэл энэ нь бүх тэгш байдлын шалгалтанд зардал нэмэх болно.
/// Бид "Rc`s-ийг клончлоход удаан, гэхдээ тэгш байдлыг шалгахад хүнд, их хэмжээний утгыг хадгалахад ашигладаг тул энэ зардлыг илүү хялбараар барагдуулдаг гэж үздэг.
///
/// Мөн ижил утгыг зааж буй хоёр `Rc` клонтой байх магадлал хоёр&T`-ээс илүү байдаг.
///
/// `T: Eq` нь `PartialEq` хэлбэрээр санаатайгаар эргэлт буцалтгүй байж болзошгүй тохиолдолд бид үүнийг хийж чадна.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Хоёр Rc`-ийн тэгш байдал.
    ///
    /// Хоёр `Rc` нь өөр өөр хуваарилалтад хадгалагдсан байсан ч дотоод утга нь тэнцүү бол тэнцүү байна.
    ///
    /// Хэрэв `T` нь `Eq` (тэгш байдлын рефлекс чанарыг илэрхийлсэн)-ийг хэрэгжүүлдэг бол ижил хуваарилалтыг зааж өгсөн хоёр Rc` нь үргэлж тэнцүү байна.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Хоёр Rc`-ийн тэгш бус байдал.
    ///
    /// Хэрэв дотоод утга нь тэнцүү биш бол хоёр `Rc` нь тэнцүү биш байна.
    ///
    /// Хэрэв `T` нь `Eq`-ийг (тэгш байдлын рефлексийг илэрхийлж байгаа) хэрэгжүүлдэг бол ижил хуваарилалтыг зааж өгсөн хоёр Rc` нь хэзээ ч тэгш бус байдаг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Хоёр Rc`-ийн хэсэгчилсэн харьцуулалт.
    ///
    /// Хоёулаа дотоод үнэ цэнэ дээрээ `partial_cmp()` дуудаж харьцуулсан болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Хоёр Rc-ийн харьцуулалтаас бага.
    ///
    /// Хоёулаа дотоод үнэ цэнэ дээрээ `<` дуудаж харьцуулсан болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Хоёр Rc`-ийн харьцуулалт 'бага буюу тэнцүү'.
    ///
    /// Хоёулаа дотоод үнэ цэнэ дээрээ `<=` дуудаж харьцуулсан болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Хоёр Rc-ийн харьцуулалтаас хамаагүй том.
    ///
    /// Хоёулаа дотоод үнэ цэнэ дээрээ `>` дуудаж харьцуулсан болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Хоёр Rc`-ийн харьцуулалтаас 'их эсвэл тэнцүү'.
    ///
    /// Хоёулаа дотоод үнэ цэнэ дээрээ `>=` дуудаж харьцуулсан болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Хоёр Rc-ийн харьцуулалт.
    ///
    /// Хоёулаа дотоод үнэ цэнэ дээрээ `cmp()` дуудаж харьцуулсан болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Лавлагаагаар тоолсон зүслэгийг хуваарилж, "v"-ийн зүйлийг клончлох замаар бөглөөрэй
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Лавлагаагаар тоолсон мөрний зүслэгийг хуваарилж, `v`-ийг хуулж ав.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Лавлагаагаар тоолсон мөрний зүслэгийг хуваарилж, `v`-ийг хуулж ав.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Хайрцаглагдсан объектыг шинэ, лавлагаа тоолох, хуваарилалт руу шилжүүлэх.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Лавлагаагаар тоолсон зүслэгийг хуваарилж, `v`-ийн зүйлийг оруулна уу.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec-д санах ойгоо суллахыг зөвшөөрч, агуулгыг нь устгахгүй
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Элемент тус бүрийг `Iterator` дээр авч `Rc<[T]>` болгон цуглуулдаг.
    ///
    /// # Гүйцэтгэлийн шинж чанар
    ///
    /// ## Ерөнхий хэрэг
    ///
    /// Ерөнхийдөө `Rc<[T]>`-т цуглуулах ажлыг эхлээд `Vec<T>`-д цуглуулдаг.Энэ нь дараахь зүйлийг бичихдээ:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// энэ нь бид бичсэн юм шиг аашилдаг:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Эхний хуваарилалт энд хийгддэг.
    ///     .into(); // `Rc<[T]>`-ийн хоёр дахь хуваарилалт энд тохиолддог.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Энэ нь `Vec<T>`-ийг бүтээхэд шаардлагатай хэмжээгээр хуваарилах бөгөөд дараа нь `Vec<T>`-ийг `Rc<[T]>` болгон өөрчлөхөд нэг удаа хуваарилагдах болно.
    ///
    ///
    /// ## Урт мэдэгдэж байгаа давталт
    ///
    /// Таны `Iterator` нь `TrustedLen`-ийг хэрэгжүүлж яг ижил хэмжээтэй байх үед `Rc<[T]>`-д зориулж ганц хуваарилалт хийгдэх болно.Жишээлбэл:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Энд ганцхан хуваарилалт болдог.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>` руу цуглуулахад ашигладаг төрөлжсөн trait.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Энэ нь `TrustedLen` давталтын хувьд тохиолддог тохиолдол юм.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // АЮУЛГҮЙ БАЙДАЛ: Бид давталтыг яг урттай байлгах ёстой.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Хэвийн хэрэгжилтэд эргээд унана.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` нь [`Rc`] хувилбар бөгөөд удирдаж буй хуваарилалтын талаар өмчлөхгүй лавлагаа агуулдаг.Хуваарилалтад `Weak` заагч дээр [`upgrade`] руу залгаж ханддаг бөгөөд энэ нь [`Сонголт`]`<`[`Rc`] '<T>> ".
///
/// `Weak` лавлагаа нь өмчлөлд тооцогдохгүй тул хуваарилалтад хадгалагдсан үнэ цэнэ буурахаас сэргийлж чадахгүй бөгөөд `Weak` өөрөө одоо байгаа үнэ цэнийн талаар ямар ч баталгаа өгөхгүй.
/// Тиймээс энэ нь [`None`]-ийг буцааж өгч магадгүй юм.
/// Гэхдээ `Weak` лавлагаа * нь хуваарилалтыг өөрөө (арын дэлгүүр) хуваарилахаас сэргийлдэг болохыг анхаарна уу.
///
/// `Weak` заагч нь [`Rc`]-ийн удирдаж буй хуваарилалтын талаархи түр зуурын лавлагааг дотоод утгыг нь бууруулахаас урьдчилан сэргийлэхэд чухал ач холбогдолтой юм.
/// Энэ нь [`Rc`] заагчийн хоорондох дугуй лавлагаанаас урьдчилан сэргийлэхэд ашиглагддаг, учир нь харилцан өмчлөх лавлагаа нь [`Rc`]-ийн аль нэгийг нь хаяхыг хэзээ ч зөвшөөрөхгүй.
/// Жишээлбэл, мод нь эцэг эхийн зангилаагаас хүүхдэд чиглэсэн хүчтэй [`Rc`] заагчтай, харин хүүхдээс эцэг эх рүүгээ чиглэсэн `Weak` заагчтай байж болно.
///
/// `Weak` заагчийг олж авах ердийн арга бол [`Rc::downgrade`] руу залгах явдал юм.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Энэ бол `NonNull` бөгөөд энэ төрлийн хэмжээг enums дээр оновчтой болгох боломжийг олгодог боловч энэ нь заавал хүчинтэй заагч байх албагүй юм.
    //
    // `Weak::new` үүнийг `usize::MAX` болгож овоолон дээр зай хуваарилах шаардлагагүй болно.
    // RcBox нь дор хаяж 2 тохируулгатай байдаг тул жинхэнэ заагчийн үнэ цэнэ биш юм.
    // Энэ нь `T: Sized` үед л боломжтой юм;хэмжээгүй `T` хэзээ ч унтардаггүй.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Санах ой хуваарилалгүйгээр шинэ `Weak<T>` бүтээдэг.
    /// Буцах утга дээр [`upgrade`] руу залгах нь үргэлж [`None`] өгдөг.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Өгөгдлийн талбайн талаар ямар ч баталгаа гаргахгүйгээр лавлагааны тооллогод хандах боломжийг олгох туслах бичих.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Энэ `Weak<T>`-ийн заасан `T` объект руу түүхий заагчийг буцаана.
    ///
    /// Зарим хүчтэй лавлагаа байгаа тохиолдолд л заагч хүчинтэй байна.
    /// Заагч нь унжсан, тохируулаагүй эсвэл [`null`] байж болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Хоёулаа нэг зүйлийг зааж байна
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Энд байгаа хүчтэй нь түүнийг амьд байлгадаг тул бид тухайн объект руу нэвтрэх боломжтой хэвээр байна.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Гэхдээ үүнээс цаашгүй.
    /// // Бид weak.as_ptr() хийж чадна, гэхдээ заагч руу хандах нь тодорхойгүй зан авирт хүргэх болно.
    /// // assert_eq! ("сайн уу", аюултай {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Хэрэв заагч унжиж байгаа бол бид харуулыг шууд буцаадаг.
            // Ачаалал нь дор хаяж RcBox (usize)-тэй нийцсэн тул энэ нь хүчинтэй ачааны ачааллын хаяг байж болохгүй.
            ptr as *const T
        } else {
            // АЮУЛГҮЙ БАЙДАЛ: хэрэв is_dangling нь худал утгатай бол заагчийг дахин холбож болно.
            // Ачаалал энэ үед буурч магадгүй тул бид туршилтаа хадгалах ёстой тул түүхий заагчийг ашиглах хэрэгтэй.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>`-ийг хэрэглэж түүхий заагч болгоно.
    ///
    /// Энэ нь сул заагчийг түүхий заагч болгон хөрвүүлэх бөгөөд нэг сул лавлагааны өмчлөлийг хадгалсаар байх болно (сул тоог энэ үйлдлээр өөрчлөхгүй).
    /// Үүнийг [`from_raw`]-тэй буцааж `Weak<T>` болгож болно.
    ///
    /// [`as_ptr`]-тэй адил заагчийн бай руу нэвтрэх хязгаарлалтууд хамаарна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Өмнө нь [`into_raw`] үүсгэсэн түүхий заагчийг буцааж `Weak<T>` болгон хөрвүүлдэг.
    ///
    /// Үүнийг хүчтэй лавлагаа авахад ашиглаж болно (дараа нь [`upgrade`] руу залгах замаар) эсвэл сул тоог тоолохын тулд `Weak<T>`-ийг унагаж болно.
    ///
    /// Энэ нь нэг сул лавлагааг эзэмшдэг ([`new`]-ийн бүтээсэн заагчийг эс тооцвол эдгээр нь юу ч эзэмшдэггүй тул арга нь тэдгээр дээр ажилладаг хэвээр байна).
    ///
    /// # Safety
    ///
    /// Заагч нь [`into_raw`]-ээс гаралтай байх ёстой бөгөөд сул сул лавлагааг эзэмшсэн хэвээр байх ёстой.
    ///
    /// Үүнийг дуудах үед хүчтэй тоо 0 байхыг зөвшөөрнө.
    /// Гэсэн хэдий ч энэ нь одоогоор түүхий заагч хэлбэрээр илэрхийлэгдсэн нэг сул лавлагааг эзэмшдэг (сул тоог энэ үйлдлээр өөрчилдөггүй) тул [`into_raw`] руу хийсэн өмнөх дуудлагатай хослуулах ёстой.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Сүүлчийн сул тооллыг багасгах.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Оролтын заагчийг хэрхэн яаж гаргаж авах талаар Weak::as_ptr контексттэй танилцана уу.

        let ptr = if is_dangling(ptr as *mut T) {
            // Энэ бол унжсан Сул.
            ptr as *mut RcBox<T>
        } else {
            // Үгүй бол заагч нь хүний хэл аманд ороогүй сул талаас гарна гэсэн баталгаатай болно.
            // АЮУЛГҮЙ БАЙДАЛ: ptr нь бодит (буурах магадлалтай) T-г иш татдаг тул data_offset руу залгахад аюулгүй.
            let offset = unsafe { data_offset(ptr) };
            // Тиймээс бид RcBox-ийг бүхэлд нь авахын тулд офсетыг буцаана.
            // АЮУЛГҮЙ БАЙДАЛ: заагч нь сул талаас үүссэн тул энэ офсет аюулгүй байна.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // АЮУЛГҮЙ БАЙДАЛ: бид одоо анхны Сул заагчийг сэргээсэн тул Сул талуудыг бий болгож чадна.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` заагчийг [`Rc`] болгож шинэчлэх оролдлого амжилттай бол дотоод утгыг бууруулж хойшлуулна.
    ///
    ///
    /// Хэрэв дотоод утга хойш унасан бол [`None`] буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Бүх хүчтэй заагчдыг устга.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Энэхүү хуваарилалтыг зааж өгсөн хүчтэй (`Rc`) заагчийн тоог авна.
    ///
    /// Хэрэв `self`-ийг [`Weak::new`] ашиглан бүтээсэн бол энэ нь 0-ийг буцаана.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Энэ хуваарилалтыг зааж өгсөн `Weak` заагчийн тоог авна.
    ///
    /// Хэрэв хүчтэй заагч үлдэхгүй бол тэг болно.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // далд сул ptr хасах
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Заагч унжсан, хуваарилагдсан `RcBox` байхгүй үед `None`-ийг буцаана (өөрөөр хэлбэл энэ `Weak`-ийг `Weak::new` бүтээсэн үед).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // "data" талбарыг хамарсан лавлагаа үүсгэхгүй байх тал дээр анхааралтай хандах хэрэгтэй, учир нь талбарыг нэгэн зэрэг мутацид оруулж болзошгүй (жишээлбэл, сүүлчийн `Rc`-ийг унагавал өгөгдлийн талбарыг газар дээр нь хаях болно).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Хоёр сул тал нь ижил хуваарилалтыг зааж өгсөн бол ([`ptr::eq`]-тэй төстэй) эсвэл хоёулаа ямар нэгэн хуваарилалтыг заагаагүй бол (хэрэв тэд `Weak::new()`)-тэй хамт бүтээгдсэн тул) `true`-ийг буцаана.
    ///
    ///
    /// # Notes
    ///
    /// Энэ нь заагчдыг харьцуулж байгаа тул `Weak::new()` нь хуваарилалтыг заагаагүй ч гэсэн хоорондоо тэнцүү байх болно гэсэн үг юм.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new`-ийг харьцуулах.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` заагчийг унагав.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Юу ч хэвлэхгүй
    /// drop(foo);        // "dropped!" хэвлэнэ
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // сул тоо 1-ээс эхэлдэг бөгөөд бүх хүчтэй заагч алга болсон тохиолдолд л тэг болно.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Ижил хуваарилалтыг зааж өгсөн `Weak` заагчийн клоныг гаргадаг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Шинэ `Weak<T>`-ийг бүтээж, `T`-д зориулж санах ойг эхлүүлэхгүйгээр хуваарилдаг.
    /// Буцах утга дээр [`upgrade`] руу залгах нь үргэлж [`None`] өгдөг.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Бид mem::forget-тэй аюулгүй харьцах үүднээс энд шалгасан.Тухайлбал
// хэрэв та mem::forget Rcs (эсвэл сул талууд) байвал дахин тоолох хэмжээ хальж магадгүй бөгөөд дараа нь онцлох Rcs (эсвэл сул талууд) байхад хуваарилалтыг чөлөөлж болно.
//
// Энэ бол доройтсон хувилбар бөгөөд бид юу болох нь хамаагүй гэсэн үүднээс үр хөндөлт хийдэг тул бодит програм хэзээ ч ийм байдалд орох ёсгүй.
//
// Энэ нь үл тоомсоргүй зардалтай байх ёстой, учир нь та өмчлөл, шилжих-семантикын ачаар Rust дээр эдгээрийг маш их хэмжээгээр хувилах шаардлагагүй болно.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Бид үнэ цэнийг хасахын оронд халихаас татгалзахыг хүсч байна.
        // Үүнийг дуудахад лавлагааны тоо хэзээ ч тэг болохгүй;
        // Гэсэн хэдий ч LLVM-ийг өөрөөр алдсан оновчлолын талаар сануулахын тулд энд үр хөндөлт хийдэг.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Бид үнэ цэнийг хасахын оронд халихаас татгалзахыг хүсч байна.
        // Үүнийг дуудахад лавлагааны тоо хэзээ ч тэг болохгүй;
        // Гэсэн хэдий ч LLVM-ийг өөрөөр алдсан оновчлолын талаар сануулахын тулд энд үр хөндөлт хийдэг.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Заагчийн цаана байгаа ачааллыг `RcBox` дотор нөхөж аваарай.
///
/// # Safety
///
/// Заагч нь өмнө нь хүчин төгөлдөр байсан T-ийн жишээг зааж өгөх ёстой (мөн хүчинтэй мета өгөгдөлтэй байх ёстой), гэхдээ T-г хасахыг зөвшөөрдөг.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Хэмжээгүй утгыг RcBox-ийн төгсгөлд зэрэгцүүл.
    // RcBox нь repr(C) тул санах ойн үргэлж хамгийн сүүлийн талбар байх болно.
    // АЮУЛГҮЙ БАЙДАЛ: хэмжээ хязгааргүй цорын ганц төрөл нь зүсмэлүүд тул trait объектууд,
    // болон гадаад төрлүүдийн хувьд оролтын аюулгүй байдлын шаардлага нь одоогоор align_of_val_raw-ийн шаардлагыг хангахад хангалттай байна;Энэ бол std-ээс гадуур найдаж болохгүй хэлний хэрэгжилтийн дэлгэрэнгүй мэдээлэл юм.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}