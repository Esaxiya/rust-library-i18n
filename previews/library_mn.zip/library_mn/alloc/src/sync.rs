#![stable(feature = "rust1", since = "1.0.0")]

//! Аюулгүй лавлах тоолох заагч.
//!
//! Илүү дэлгэрэнгүйг [`Arc<T>`][Arc] баримт бичгээс үзнэ үү.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc`-т хандаж болох лавлагааны хэмжээг хязгаарлах.
///
/// Энэ хязгаараас хэтэрвэл _exactly_ `MAX_REFCOUNT + 1`-ийн лавлагаанд таны програмыг цуцлах болно (гэхдээ заавал биш).
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer нь санах ойн хашааг дэмждэггүй.
// Arc/сул програм дахь хуурамч эерэг тайлангаас зайлсхийхийн тулд синхрончлолын оронд атомын ачааллыг ашиглана уу.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Урсгал аюулгүй лавлагаа тоолох заагч.'Arc' нь 'Atomically Reference Counted' гэсэн үг юм.
///
/// `Arc<T>` төрөл нь овооролд хуваарилагдсан `T` төрлийн утгын дундын өмчлөлийг өгдөг.[`clone`][clone]-ийг `Arc` дээр дуудах нь `Arc`-ийн шинэ жишээг бий болгодог бөгөөд энэ нь эх үүсвэр `Arc`-тэй ижил хуваарилалтыг зааж, лавлагааны тоог нэмэгдүүлдэг.
/// Тухайн хуваарилалтын сүүлийн `Arc` заагч устгагдахад тухайн хуваарилалтад хадгалагдсан утга (ихэвчлэн "inner value" гэж нэрлэдэг) буурдаг.
///
/// Rust дахь хуваалцсан лавлагаа нь мутацийг анхдагчаар зөвшөөрдөггүй бөгөөд `Arc` нь үл хамаарах зүйл биш юм: та ерөнхийдөө `Arc` дотор байгаа зүйлийн өөрчлөгдөж болох лавлагааг авч чадахгүй.Хэрэв та `Arc`-ээр мутаци хийх шаардлагатай бол [`Mutex`][mutex], [`RwLock`][rwlock] эсвэл [`Atomic`][atomic] төрлүүдийн аль нэгийг ашиглаарай.
///
/// ## Утасны аюулгүй байдал
///
/// [`Rc<T>`]-ээс ялгаатай нь `Arc<T>` нь лавлагаа тоолоход атомын ажиллагааг ашигладаг.Энэ нь утасд аюулгүй гэсэн үг юм.Сул тал нь ердийн санах ойн хандалтаас илүү атомын ажиллагаа илүү үнэтэй байдаг.Хэрэв та холбоосуудын хоорондох лавлагаагаар хуваарилагдсан хуваарилалтыг хуваалцахгүй байгаа бол нэмэлт зардалд [`Rc<T>`] ашиглах талаар бодож үзээрэй.
/// [`Rc<T>`] Энэ бол аюулгүй өгөгдмөл хувилбар юм, учир нь хөрвүүлэгч нь [`Rc<T>`]-ийг урсгал хооронд илгээх оролдлогыг барих болно.
/// Гэсэн хэдий ч номын сан нь хэрэглэгчдэд илүү уян хатан байх үүднээс номын сан нь `Arc<T>`-ийг сонгож магадгүй юм.
///
/// `Arc<T>` `T` нь [`Send`] ба [`Sync`]-ийг хэрэгжүүлж байх үед [`Send`] ба [`Sync`]-ийг хэрэгжүүлэх болно.
/// Та яагаад `T`-д утасгүй аюулгүй `T` төрлийг оруулж, үүнийг аюулгүй болгож болохгүй гэж?Энэ нь эхлээд жаахан эсрэг мэдрэмжтэй байж магадгүй юм: эцэст нь `Arc<T>` утас аюулгүй байдлын цэг биш гэж үү?Хамгийн чухал зүйл бол `Arc<T>` нь ижил өгөгдлийг олон удаа өмчлөх боломжийг аюулгүй болгодог боловч энэ нь өгөгдөлд thread аюулгүй байдлыг нэмдэггүй.
///
/// "Arc <" [`RefCell<T>"]">".
/// [`RefCell<T>`] [`Sync`] биш бөгөөд хэрэв `Arc<T>` үргэлж [`Send`] байсан бол "Arc <" [`RefCell<T>`]`>`бас байх болно.
/// Гэхдээ дараа нь бидэнд асуудал тулгарах болно:
/// [`RefCell<T>`] утас аюулгүй биш;энэ нь атомын бус үйлдлүүдийг ашиглан зээлийн тооцоог хөтөлдөг.
///
/// Эцэст нь хэлэхэд та `Arc<T>`-ийг зарим төрлийн [`std::sync`], ихэвчлэн [`Mutex<T>`][mutex]-тэй хослуулах шаардлагатай болж магадгүй юм.
///
/// ## `Weak` ашиглан циклийг таслах
///
/// [`downgrade`][downgrade] аргыг эзэмшдэггүй [`Weak`] заагчийг бий болгоход ашиглаж болно.[`Weak`] заагч нь `Arc` руу [`шинэчлэх '][шинэчлэх] d байж болох боловч хэрэв хуваарилалтад хадгалагдсан утга аль хэдийн унасан бол энэ нь [`None`]-ийг буцааж өгөх болно.
/// Өөрөөр хэлбэл, `Weak` заагч нь хуваарилалтын доторх утгыг амьд байлгахгүй;Гэсэн хэдий ч тэд хуваарилалтыг (үнэ цэнийн арын дэлгүүр) амьд байлгадаг.
///
/// `Arc` заагчийн хоорондох циклийг хэзээ ч хуваарилахгүй.
/// Энэ шалтгааны улмаас [`Weak`] нь мөчлөгийг таслахад ашигладаг.Жишээлбэл, мод нь эцэг эхийн зангилаагаас хүүхдэд чиглэсэн хүчтэй `Arc` заагч, хүүхдээс эцэг эх рүүгээ буцаж очдог [`Weak`] заагчтай байж болно.
///
/// # Лавлагаа хуулбарлах
///
/// Одоо байгаа лавлагаа тоолсон заагчаас шинэ лавлагаа үүсгэх ажлыг [`Arc<T>`][Arc] ба [`Weak<T>`][Weak]-д хэрэгжүүлсэн `Clone` trait-ийг ашиглан хийдэг.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Доорх хоёр синтакс нь тэнцүү байна.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, foo нь бүгд ижил санах ойг заадаг Arcs юм
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` автоматаар `T` руу шилжүүлнэ ([`Deref`][deref] trait-ээр), тиймээс та `Arc<T>` төрлийн утга дээр `T`-ийн аргуудыг дуудаж болно.X-ийн аргуудтай нэр зөрөхөөс зайлсхийхийн тулд `Arc<T>` аргууд нь [fully qualified syntax] ашиглан холбогдсон функцууд юм.
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// Нуман<T>traits-ийн `Clone` шиг хэрэгжүүлэлтийг бүрэн чадварлаг синтакс ашиглан дуудаж болно.
/// Зарим хүмүүс бүрэн мэргэшсэн синтакс ашиглахыг илүүд үздэг бол зарим нь метод-дуудлагын синтакс ашиглахыг илүүд үздэг.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Арга-дуудлагын синтакс
/// let arc2 = arc.clone();
/// // Бүрэн мэргэшсэн синтакс
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T`-ийг автоматаар хасдаггүй, учир нь дотоод утга нь аль хэдийн унасан байж магадгүй юм.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Утаснуудын хооронд зарим өөрчлөгдөхгүй өгөгдлийг хуваалцах:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Эдгээр тестийг бид **энд** хийдэггүйг анхаарна уу.
// Хэрэв утас гол утаснаасаа даваад дараа нь гараад (гацаад байгаа зүйл) байвал windows бүтээгчид туйлын их аз жаргалгүй болдог тул бид эдгээр туршилтыг ажиллуулахгүйгээр үүнээс бүрэн зайлсхийх болно.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Өөрчилж болох [`AtomicUsize`]-г хуваалцах:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Ерөнхийдөө лавлагаа тоолох бусад жишээг [`rc` documentation][rc_examples]-ээс үзнэ үү.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` нь [`Arc`] хувилбар бөгөөд удирдаж буй хуваарилалтын талаар өмчлөхгүй лавлагаа агуулдаг.
/// Хуваарилалтад `Weak` заагч дээр [`upgrade`] руу залгаж ханддаг бөгөөд энэ нь [`Option`]`<`[`Arc`] `<T>>".
///
/// `Weak` лавлагаа нь өмчлөлд тооцогдохгүй тул хуваарилалтад хадгалагдсан үнэ цэнэ буурахаас сэргийлж чадахгүй бөгөөд `Weak` өөрөө одоо байгаа үнэ цэнийн талаар ямар ч баталгаа өгөхгүй.
///
/// Тиймээс энэ нь [`None`]-ийг буцааж өгч магадгүй юм.
/// Гэхдээ `Weak` лавлагаа * нь хуваарилалтыг өөрөө (арын дэлгүүр) хуваарилахаас сэргийлдэг болохыг анхаарна уу.
///
/// `Weak` заагч нь [`Arc`]-ийн удирддаг хуваарилалтын талаархи түр зуурын лавлагаа, түүний дотоод үнэ цэнийг унагаахаас урьдчилан сэргийлэхэд тусалдаг.
/// Энэ нь [`Arc`] заагчийн хоорондох дугуй лавлагаанаас урьдчилан сэргийлэхэд ашиглагддаг, учир нь харилцан өмчлөх лавлагаа нь [`Arc`]-ийн аль нэгийг нь хаяхыг хэзээ ч зөвшөөрөхгүй.
/// Жишээлбэл, мод нь эцэг эхийн зангилаагаас хүүхдэд чиглэсэн хүчтэй [`Arc`] заагч, хүүхдээс эцэг эх рүүгээ буцаж очдог `Weak` заагчтай байж болно.
///
/// `Weak` заагчийг олж авах ердийн арга бол [`Arc::downgrade`] руу залгах явдал юм.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Энэ бол `NonNull` бөгөөд энэ төрлийн хэмжээг enums дээр оновчтой болгох боломжийг олгодог боловч энэ нь заавал хүчинтэй заагч байх албагүй юм.
    //
    // `Weak::new` үүнийг `usize::MAX` болгож овоолон дээр зай хуваарилах шаардлагагүй болно.
    // RcBox нь дор хаяж 2 тохируулгатай байдаг тул жинхэнэ заагчийн үнэ цэнэ биш юм.
    // Энэ нь `T: Sized` үед л боломжтой юм;хэмжээгүй `T` хэзээ ч унтардаггүй.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Энэ бол талбарыг дахин өөрчлөхөөс хамгаалагдсан repr(C)-ээс future-тэй нийцэж байгаа бөгөөд энэ нь өөр хэлбэрт шилжих боломжтой дотоод [into|from]_raw()-т саад болох болно.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX утга нь "locking"-ийн сул заагчийг шинэчлэх эсвэл хүчтэйг нь бууруулах чадвартай түр зуурын харуулын үүрэг гүйцэтгэдэг;үүнийг `make_mut` ба `get_mut`-д уралдахаас зайлсхийхэд ашигладаг.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Шинэ `Arc<T>` бүтээдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Сул заагчийн тооллогыг 1 гэж эхлүүлээрэй, энэ нь бүх хүчтэй (kinda) заагчдын барьж байгаа сул заагч юм, илүү их мэдээлэл авахыг хүсвэл std/rc.rs-ээс үзнэ үү.
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Өөртөө сул лавлагаа ашиглан шинэ `Arc<T>` бүтээдэг.
    /// Энэ функц буцаж ирэхээс өмнө сул лавлагааг сайжруулахыг оролдох нь `None` утгыг гаргах болно.
    /// Гэхдээ сул лавлагааг чөлөөтэй хувилж, дараа нь ашиглахаар хадгалж болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Нэг сул лавлагаагаар "uninitialized" төлөвт дотор талыг нь байгуул.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Бид сул заагчийг эзэмшихээс татгалзахгүй байх нь чухал бөгөөд эс тэгвээс `data_fn` буцаж ирэхэд санах ой суллагдах болно.
        // Хэрэв бид үнэхээр өмчлөхийг хүсч байсан бол өөрсдөдөө нэмэлт сул заагчийг бий болгож болох боловч энэ нь сул лавлагааны тоонд нэмэлт шинэчлэлт хийх шаардлагатай бөгөөд өөрөөр хэлбэл шаардлагагүй байж магадгүй юм.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Одоо бид дотоод үнэ цэнийг зөв эхлүүлж, сул лавлагаагаа хүчтэй лавлагаа болгож чадна.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Дээрх өгөгдлийн талбарт бичих нь тэгээс хэтгүй тооллыг ажиглаж буй аливаа урсгалд харагдах ёстой.
            // Тиймээс `Weak::upgrade` дахь `compare_exchange_weak`-тэй синхрончлохын тулд бидэнд дор хаяж "Release" захиалга хэрэгтэй.
            //
            // "Acquire" захиалга хийх шаардлагагүй.
            // `data_fn`-ийн боломжит зан үйлийг авч үзэхдээ шинэчлэгдэхгүй `Weak`-ийн талаар юу хийж болохыг харах хэрэгтэй.
            //
            // - Энэ нь сул лавлагааны тоог нэмэгдүүлж `Weak`-ийг *клончлох* боломжтой.
            // - Энэ нь эдгээр клонуудыг унагаж, сул лавлагааны тоог бууруулж болно (гэхдээ хэзээ ч тэг болохгүй).
            //
            // Эдгээр гаж нөлөө нь бидэнд ямар ч байдлаар нөлөөлөхгүй бөгөөд зөвхөн аюулгүй кодын тусламжтайгаар өөр гаж нөлөө гарахгүй.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Хүчтэй лавлагаа нь хуваалцсан сул лавлагааг хамтад нь эзэмшсэн байх ёстой тул бидний хуучин сул лавлагааг устгагчаар бүү ажиллуул.
        //
        mem::forget(weak);
        strong
    }

    /// Эхлээгүй агуулгатай шинэ `Arc` бүтээдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Хойшлуулсан эхлүүлэх:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Санах ойг `0` байтаар дүүргэсэн, эхлүүлээгүй агуулгатай шинэ `Arc` бүтээдэг.
    ///
    ///
    /// Энэ аргыг зөв, буруу ашигласан жишээг [`MaybeUninit::zeroed`][zeroed]-ээс үзнэ үү.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Шинэ `Pin<Arc<T>>` бүтээдэг.
    /// Хэрэв `T` нь `Unpin`-ийг хэрэгжүүлээгүй бол `data` нь санах ойд бэхлэгдэж, шилжих боломжгүй болно.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Шинэ `Arc<T>`-ийг бүтээж, хуваарилалт амжилтгүй болбол алдаа буцааж өгдөг.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Сул заагчийн тооллогыг 1 гэж эхлүүлээрэй, энэ нь бүх хүчтэй (kinda) заагчдын барьж байгаа сул заагч юм, илүү их мэдээлэл авахыг хүсвэл std/rc.rs-ээс үзнэ үү.
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Эхлэлгүй агуулгатай шинэ `Arc`-ийг бүтээж, хуваарилалт амжилтгүй болбол алдаа буцааж өгдөг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Хойшлуулсан эхлүүлэх:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Санах ойг `0` байтаар дүүргэж, хуваарилалт амжилтгүй болбол алдаа буцааж, эхлүүлээгүй агуулгатай шинэ `Arc` бүтээдэг.
    ///
    ///
    /// Энэ аргыг зөв, буруу ашигласан жишээг [`MaybeUninit::zeroed`][zeroed]-ээс үзнэ үү.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Хэрэв `Arc` яг нэг хүчтэй лавлагаатай бол дотоод утгыг буцаана.
    ///
    /// Үгүй бол [`Err`]-ийг нэвтрүүлсэн `Arc`-тэй буцаадаг.
    ///
    ///
    /// Гайхамшигтай сул лавлагаа байгаа ч гэсэн энэ нь амжилтанд хүрнэ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Хүчтэй, сул гэсэн ишлэлийг цэвэрлэхийн тулд сул заагчийг гарга
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Шинэлэг бус агуулгатай, атомын лавлагаагаар тоолсон шинэ зүсмэлийг барина.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Хойшлуулсан эхлүүлэх:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Санах ойг `0` байтаар дүүргэсэн, анализ хийгдээгүй агуулгатай шинэ атомын лавлагаагаар тоолсон зүсмэлийг байгуулна.
    ///
    ///
    /// Энэ аргыг зөв, буруу ашигласан жишээг [`MaybeUninit::zeroed`][zeroed]-ээс үзнэ үү.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` руу хөрвүүлдэг.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-тэй адил дотоод үнэ цэнэ нь анхны байдалд байгаа эсэхийг баталгаажуулах нь дуудлага хийгчээс хамаарна.
    ///
    /// Агуулга бүрэн эхлээгүй байхад үүнийг дуудах нь шууд тодорхойлогдохгүй зан үйлийг үүсгэдэг.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Хойшлуулсан эхлүүлэх:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` руу хөрвүүлдэг.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-тэй адил дотоод үнэ цэнэ нь анхны байдалд байгаа эсэхийг баталгаажуулах нь дуудлага хийгчээс хамаарна.
    ///
    /// Агуулга бүрэн эхлээгүй байхад үүнийг дуудах нь шууд тодорхойлогдохгүй зан үйлийг үүсгэдэг.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Хойшлуулсан эхлүүлэх:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Ороосон заагчийг буцааж `Arc`-ийг хэрэглэдэг.
    ///
    /// Санах ой алдагдахаас зайлсхийхийн тулд заагчийг [`Arc::from_raw`] ашиглан `Arc` руу буцааж хөрвүүлэх хэрэгтэй.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Өгөгдөлд түүхий заагч өгдөг.
    ///
    /// Тооллогуудад ямар нэгэн байдлаар нөлөөлөхгүй бөгөөд `Arc`-ийг хэрэглэдэггүй.
    /// Заагч нь `Arc`-д хүчтэй тоологдсон тохиолдолд хүчинтэй байна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // АЮУЛГҮЙ БАЙДАЛ: Энэ нь Deref::deref эсвэл RcBoxPtr::inner-ээр дамжих боломжгүй юм
        // жишээ нь raw/mut туршилтыг хадгалахын тулд шаардлагатай болно
        // `get_mut` `from_raw`-ээр Rc сэргээгдсэний дараа заагчаар бичиж болно.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Түүхий заагчаас `Arc<T>` бүтээдэг.
    ///
    /// Түүхий заагчийг өмнө нь [`Arc<U>::into_raw`][into_raw] руу залгаж буцааж өгсөн байх ёстой бөгөөд `U` нь `T`-тэй ижил хэмжээтэй, зэрэгцсэн байх ёстой.
    /// Хэрэв `U` нь `T` бол энэ нь өчүүхэн үнэн юм.
    /// Хэрэв `U` бол `T` биш боловч ижил хэмжээтэй, зэрэгцүүлэлттэй бол энэ нь үндсэндээ өөр өөр төрлийн лавлагаа шилжүүлэхтэй адил гэдгийг анхаарна уу.
    /// Энэ тохиолдолд ямар хязгаарлалт үйлчлэх талаар [`mem::transmute`][transmute]-ээс үзнэ үү.
    ///
    /// `from_raw`-ийн хэрэглэгч `T`-ийн тодорхой утгыг зөвхөн нэг удаа унагаах ёстой.
    ///
    /// Энэ функц нь аюултай, учир нь зохисгүй хэрэглээ нь санах ойн аюулгүй байдалд хүргэж болзошгүй тул буцаж ирсэн `Arc<T>`-д хэзээ ч нэвтрэхгүй байсан ч гэсэн.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Нэвтрэхээс сэргийлж `Arc` руу хөрвүүл.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Цаашид `Arc::from_raw(x_ptr)` руу залгах нь санах ойд аюулгүй байх болно.
    /// }
    ///
    /// // `x` дээрх хамрах хүрээнээс гарах үед санах ой суллагдсан тул `x_ptr` одоо унжиж байна!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Эх ArcInner-ийг олохын тулд офсетыг эргүүл.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Энэхүү хуваарилалтад шинэ [`Weak`] заагч үүсгэдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Доорх CAS-ийн утгыг шалгаж байгаа тул энэ амралт хэвийн байна.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // сул тоолуур одоогоор "locked" байгаа эсэхийг шалгах;хэрэв тийм бол эргэлдээрэй.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: энэ код нь халих магадлалыг одоогоор үл тоомсорлож байна
            // usize::MAX руу;ерөнхийдөө Rc ба Arc хоёулаа халих асуудлыг зохицуулах хэрэгтэй.
            //

            // Clone()-ээс ялгаатай нь бид үүнийг `is_unique`-ээс ирэх бичээстэй синхрончлохын тулд Acquire унших хэрэгтэй бөгөөд ингэхээс өмнөх үйл явдлууд уншихаас өмнө болох болно.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Бид унжсан Сул талыг бий болгохгүй байхыг анхаараарай
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Энэ хуваарилалтын [`Weak`] заагчийн тоог авна.
    ///
    /// # Safety
    ///
    /// Энэ арга нь өөрөө аюулгүй боловч зөв ашиглах нь илүү анхаарал шаарддаг.
    /// Өөр нэг утас нь сул тооллыг ямар ч үед өөрчлөх боломжтой бөгөөд үүнд энэ аргыг дуудах, үр дүнд нөлөөлөх зэрэг орно.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Бид `Arc` эсвэл `Weak`-ийг хооронд нь холбож өгөөгүй тул энэ нотолгоо нь детерминик шинжтэй юм.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Хэрэв сул тоолол одоогоор түгжигдсэн бол түгжээг авахын өмнөх тооллын утга 0 байна.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Энэхүү хуваарилалтад чиглэсэн хүчтэй (`Arc`) заагчийн тоог авна.
    ///
    /// # Safety
    ///
    /// Энэ арга нь өөрөө аюулгүй боловч зөв ашиглах нь илүү анхаарал шаарддаг.
    /// Өөр нэг утас нь хүчтэй тооллыг ямар ч үед өөрчлөх боломжтой бөгөөд үүнд энэ аргыг дуудах, үр дүнд нөлөөлөх зэрэг орно.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Бид `Arc`-ийг хооронд нь холбож өгөөгүй тул энэ нотолгоо нь детерминик шинжтэй юм.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Өгөгдсөн заагчтай холбоотой `Arc<T>` дээрх хүчтэй лавлагааны тоог нэгээр нэмэгдүүлнэ.
    ///
    /// # Safety
    ///
    /// Заагчийг `Arc::into_raw`-ээр олж авсан байх ёстой бөгөөд холбогдох `Arc` жишээ хүчинтэй байх ёстой (өөрөөр хэлбэл
    /// хүчтэй тоололтыг энэ аргын үргэлжлэх хугацаанд дор хаяж 1) байх ёстой.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Бид `Arc`-ийг хооронд нь холбож өгөөгүй тул энэ нотолгоо нь детерминик шинжтэй юм.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Arc-г хадгалаарай, гэхдээ ManualDrop-т ороод дахин тооллогод хүрч болохгүй
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Одоо дахин тооллогоо нэмэгдүүл, гэхдээ шинэ дахин тоололтыг бүү бууруул
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Өгөгдсөн заагчтай холбоотой `Arc<T>`-ийн хүчтэй лавлагааны тоог нэгээр бууруулна.
    ///
    /// # Safety
    ///
    /// Заагчийг `Arc::into_raw`-ээр олж авсан байх ёстой бөгөөд холбогдох `Arc` жишээ хүчинтэй байх ёстой (өөрөөр хэлбэл
    /// хүчтэй тоололтыг дор хаяж 1) байх ёстой.
    /// Энэ аргыг эцсийн `Arc` болон нөөцлөлтийг гаргахад ашиглаж болох боловч эцсийн `Arc` гарсны дараа ** дуудаж болохгүй.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Бид `Arc`-ийг хооронд нь холбож өгөөгүй тул эдгээр нотолгоо нь детерминик шинжтэй юм.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Энэ аюулгүй байдал нь зүгээр юм, учир нь энэ нум амьд байх үед бид дотоод заагч хүчинтэй гэсэн баталгаатай болно.
        // Цаашилбал, дотоод өгөгдөл нь `Sync` тул `ArcInner` бүтэц нь өөрөө `Sync` гэдгийг бид мэддэг тул эдгээр агуулгад өөрчлөгдөхгүй заагчийг байрлуулах нь зөв юм.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop`-ийн доторлогоогүй хэсэг.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Бид хайрцагны хуваарилалтыг өөрөө чөлөөлөөгүй байж магадгүй ч гэсэн өгөгдлийг энэ үед устга (гэхдээ сул заагчууд хэвтэж байж магадгүй).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Бүх хүчтэй лавлагаагаар хамтад нь багтаасан сул ref-ийг хая
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Хоёр Arc нь ижил хуваарилалтыг зааж өгвөл `true`-ийг буцаана ([`ptr::eq`]-тэй төстэй судал дээр).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Хэмжигдээгүй хэмжээтэй байж болох дотоод утгын хувьд хангалттай зайтай `ArcInner<T>`-ийг хуваарилдаг.
    ///
    /// `mem_to_arcinner` функцийг өгөгдлийн заагчтай хамт дууддаг бөгөөд `ArcInner<T>`-ийн хувьд (өөх тос байж болзошгүй) заагчийг буцааж өгөх ёстой.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Өгөгдсөн утгын байршлыг ашиглан байршлыг тооцоол.
        // Өмнө нь байршлыг `&*(ptr as* const ArcInner<T>)` илэрхийлэл дээр тооцдог байсан боловч энэ нь буруу тохируулсан лавлагаа үүсгэсэн (#54908-г үзнэ үү).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Хэмжигдэхгүй хэмжээтэй дотоод утгын хувьд хангалттай зай бүхий `ArcInner<T>`-ийг хуваарилж өгсөн тохиолдолд хуваарилалт амжилтгүй болбол алдаа буцааж өгдөг.
    ///
    ///
    /// `mem_to_arcinner` функцийг өгөгдлийн заагчтай хамт дууддаг бөгөөд `ArcInner<T>`-ийн хувьд (өөх тос байж болзошгүй) заагчийг буцааж өгөх ёстой.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Өгөгдсөн утгын байршлыг ашиглан байршлыг тооцоол.
        // Өмнө нь байршлыг `&*(ptr as* const ArcInner<T>)` илэрхийлэл дээр тооцдог байсан боловч энэ нь буруу тохируулсан лавлагаа үүсгэсэн (#54908-г үзнэ үү).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner-ийг эхлүүлэх
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Хэмжигдээгүй дотоод утгад хангалттай зай бүхий `ArcInner<T>`-ийг хуваарилдаг.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Өгөгдсөн утгыг ашиглан `ArcInner<T>`-д хуваарилах.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Утга байтыг хуулах
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Агуулгыг унагаалгүйгээр хуваарилалтыг үнэгүй болгоно уу
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Өгөгдсөн урттай `ArcInner<[T]>`-ийг хуваарилдаг.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Элементүүдийг зүсмэлээс шинээр хуваарилагдсан Arc <\[T\]> руу хуулах
    ///
    /// Аюулгүй, учир нь залгасан хүн өмчлөх ёстой эсвэл `T: Copy`-ийг холбох ёстой.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Тодорхой хэмжээгээр мэдэгдэж байсан давталтаас `Arc<[T]>` бүтээдэг.
    ///
    /// Хэмжээ нь буруу байвал биеэ авч явах байдал нь тодорхойгүй байдаг.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Т элементүүдийг клончлох үед Panic хамгаалагч.
        // panic тохиолдсон тохиолдолд шинэ ArcInner дээр бичигдсэн элементүүдийг хаяж, санах ойг чөлөөлнө.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Эхний элемент рүү заагч
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Бүгд тодорхой.Хамгаалагчаа март, ингэснээр шинэ ArcInner-ийг чөлөөлөхгүй.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>`-д ашигладаг төрөлжсөн trait.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` заагчийн клоныг гаргадаг.
    ///
    /// Энэ нь ижил хуваарилалтад өөр заагчийг бий болгож, хүчтэй лавлагааны тоог нэмэгдүүлдэг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Анхны лавлагааны талаархи мэдлэг нь бусад утсыг объектыг устгахаас урьдчилан сэргийлэх тул тайван захиалга ашиглах нь зөв юм.
        //
        // [Boost documentation][1]-д тайлбарласнаар лавлагааны тоолуурыг нэмэгдүүлэх нь үргэлж memory_order_relaxed-ийн тусламжтай хийгддэг: Объектын шинэ лавлагааг зөвхөн одоо байгаа лавлагаанаас үүсгэх боломжтой бөгөөд одоо байгаа лавлагааг нэг урсгалаас нөгөө рүү дамжуулах нь шаардлагатай синхрончлолыг аль хэдийн хангах ёстой.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Гэсэн хэдий ч хэн нэгэн хүн "mem: : forget`ing Arcs" байгаа тохиолдолд бид дахин их хэмжээний тооллого хийхээс сэргийлэх хэрэгтэй.
        // Хэрэв бид үүнийг хийхгүй бол тоо нь хальж, хэрэглэгчид үнэгүй ашиглах боломжтой болно.
        // Бид лавлагааны тоог нэг дор өсгөсөн ~2 тэрбум утас байхгүй гэсэн таамаглалаар `isize::MAX`-ийг хангаж байна.
        //
        // Энэхүү branch-ийг хэзээ ч бодитой хөтөлбөрт оруулахгүй.
        //
        // Ийм хөтөлбөр нь үнэхээр доройтсон тул бид үр хөнддөг бөгөөд үүнийг дэмжих нь бидэнд хамаагүй.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Өгөгдсөн `Arc`-ийн талаар өөрчлөгдөж болно.
    ///
    /// Хэрэв ижил хуваарилалтын өөр `Arc` эсвэл [`Weak`] заагч байгаа бол `make_mut` нь шинэ хуваарилалт үүсгэж, өвөрмөц өмчлөлийг баталгаажуулахын тулд дотоод утга дээр [`clone`][clone]-г дуудах болно.
    /// Үүнийг бас бичихийг хуулбарлах гэж нэрлэдэг.
    ///
    /// Энэ нь үлдсэн `Weak` заагчийг салгаж байгаа [`Rc::make_mut`]-ийн зан байдлаас ялгаатай болохыг анхаарна уу.
    ///
    /// Мөн клончлох биш бүтэлгүйтэх [`get_mut`][get_mut]-ийг үзнэ үү.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Юу ч хувилахгүй
    /// let mut other_data = Arc::clone(&data); // Дотоод мэдээллийг хуулбарлахгүй
    /// *Arc::make_mut(&mut data) += 1;         // Дотоод өгөгдлийг хуулбарлана
    /// *Arc::make_mut(&mut data) += 1;         // Юу ч хувилахгүй
    /// *Arc::make_mut(&mut other_data) *= 2;   // Юу ч хувилахгүй
    ///
    /// // Одоо `data` ба `other_data` нь өөр өөр хуваарилалтыг зааж өгдөг.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Бид хүчтэй, сул лавлагаа хоёуланг нь агуулдаг гэдгийг анхаарна уу.
        // Тиймээс бидний хүчтэй лавлагааг гаргаснаар зөвхөн санах ойг хуваарилахад хүргэхгүй.
        //
        // `strong` руу бичихээс (өөрөөр хэлбэл бууралт) гарахаас өмнө тохиолдох `weak`-д ямар нэгэн бичлэг байгааг харахын тулд Acquire ашиглана уу.
        // Бид сул тоололтой тул ArcInner-ийг өөрөө хуваарилах боломж байхгүй.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Өөр нэг хүчтэй заагч байдаг тул бид клончлох ёстой.
            // Клондсон утгыг шууд бичих боломжийг олгохын тулд санах ойг урьдчилан хуваарилна уу.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Дээрх зүйлүүдэд тайвшрах нь хангалттай бөгөөд учир нь энэ нь үндсэндээ оновчлол юм: бид үргэлж сул заагчдыг унагаж уралдах болно.
            // Хамгийн муу зүйл бол бид шинэ Arc-ийг шаардлагагүй байдлаар хуваарилдаг.
            //

            // Бид сүүлчийн хүчтэй реф-ийг хассан боловч сул сул нэмэлтүүд үлдсэн байна.
            // Бид агуулгыг шинэ Arc руу шилжүүлж, бусад сулхан ref-уудыг хүчингүй болгоно.
            //

            // `weak`-ийн уншилтаар usize::MAX (өөрөөр хэлбэл түгжигдсэн) гарах боломжгүй тул сул тооллыг зөвхөн хүчтэй лавлагаа бүхий утсаар түгжих боломжтой гэдгийг анхаарна уу.
            //
            //

            // ArcInner-ийг шаардлагатай бол цэвэрлэх боломжтой байхын тулд бид өөрсдийн далд сул заагчийг бодитой болгоно.
            //
            let _weak = Weak { ptr: this.ptr };

            // Зөвхөн өгөгдлийг хулгайлж чадна, зөвхөн сул талууд л үлдэнэ
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Бид аль ч төрлийн цорын ганц лавлагаа байсан;хүчтэй тооллогыг буцааж өг.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()`-тэй адил аюулгүй байдал нь сайн байна, учир нь бидний лавлагаа нь өвөрмөц байсан, эсвэл агуулгыг клончлох үед нэг болсон.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Хэрэв ижил хуваарилалтад өөр `Arc` эсвэл [`Weak`] заагч байхгүй бол өгөгдсөн `Arc` руу өөрчлөгдөж болох лавлагааг буцаана.
    ///
    ///
    /// [`None`]-ийг буцааж өгдөг, учир нь хуваалцсан утгыг өөрчлөх нь аюулгүй байдаг.
    ///
    /// Бусад заагч байгаа үед дотоод утгыг [`clone`][clone] болгох [`make_mut`][make_mut]-ийг үзнэ үү.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Буцааж өгсөн заагч нь T-д буцаагдах *цорын ганц* заагч гэдгийг бид баталж байгаа тул аюулгүй байдал хангалтгүй байна.
            // Энэ үед бидний лавлагааны тоо 1 байх баталгаатай бөгөөд Arc өөрөө `mut` байхыг шаардсан тул дотоод өгөгдлийн цорын ганц боломжит лавлагааг буцааж өгч байна.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Өгөгдсөн `Arc` руу өөрчлөгдөж болох лавлагааг ямар ч шалгалтгүйгээр буцаана.
    ///
    /// Аюулгүй, зохих шалгалтыг хийдэг [`get_mut`]-ийг үзнэ үү.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Үүнтэй ижил хуваарилалтыг зааж өгсөн бусад `Arc` эсвэл [`Weak`] заагчийг буцааж авсан зээлийн хугацаанд хамааруулж болохгүй.
    ///
    /// Хэрэв ийм заагч байхгүй бол, жишээ нь `Arc::new`-ийн дараа шууд л ийм тохиолдол гардаг.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Бид "count" талбарыг хамарсан лавлагаа үүсгэхгүй байх *-ыг анхааралтай хийдэг, учир нь энэ нь лавлагаа тооллогод зэрэг хандах хандалттай байдаг.
        // `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Энэ нь суурь өгөгдлийн өвөрмөц лавлагаа (сул лавлагаа орно) эсэхийг тодорхойл.
    ///
    ///
    /// Энэ нь сул тооллогыг түгжих шаардлагатай гэдгийг анхаарна уу.
    fn is_unique(&mut self) -> bool {
        // Хэрэв бид цорын ганц сул заагч эзэмшигч юм шиг байвал сул заагчийн тооллогыг түгжих.
        //
        // Энд олж авах шошго нь `weak`-ийн тоо буурахаас өмнө `strong`-т (ялангуяа `Weak::upgrade`-т) бичихтэй холбоотой харилцааг баталгаажуулдаг (хувилбарыг ашигладаг `Weak::drop`-ээр дамжуулан).
        // Хэрэв сайжруулсан сул ref хэзээ ч унагаагүй бол CAS энд унах тул бид синхрончлох талаар огт санаа зовохгүй байна.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Энэ нь `drop` дахь `strong` тоолуурын бууралттай синхрончлохын тулд `Acquire` байх шаардлагатай бөгөөд хамгийн сүүлийн лавлагаагаас бусад тохиолдолд цорын ганц хандалт хийгдэх болно.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Энд бичсэн бичлэг нь `downgrade`-тэй уншихтай синхрончлогдсон бөгөөд `strong`-ийн дээрх уншилтыг бичсэний дараа гарахаас урьдчилан сэргийлэх болно.
            //
            //
            self.inner().weak.store(1, Release); // түгжээг суллах
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc`-ийг унагаадаг.
    ///
    /// Энэ нь хүчтэй лавлагааны тоог бууруулна.
    /// Хэрэв хүчтэй лавлагааны тоо тэг болж байвал бусад лавлагаа (хэрэв байгаа бол) нь [`Weak`] тул дотоод утгыг бид `drop` болгож тэмдэглэнэ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Юу ч хэвлэхгүй
    /// drop(foo2);   // "dropped!" хэвлэнэ
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` нь аль хэдийн атом болсон тул объектыг устгахгүй бол бусад урсгалуудтай синхрончлох шаардлагагүй болно.
        // Үүнтэй ижил логик нь доорхи `fetch_sub`-т `weak` тоололд хамаарна.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Энэхүү хашаа нь өгөгдлийн ашиглалтын дарааллыг өөрчлөх, өгөгдлийг устгахаас урьдчилан сэргийлэхэд шаардлагатай юм.
        // Энэ нь `Release` гэж тэмдэглэгдсэн тул лавлагааны тоо буурах нь энэ `Acquire` хашаатай синхрончлогддог.
        // Энэ нь өгөгдлийг ашиглах нь өгөгдлийг устгахаас өмнө тохиолддог хашаа барихаас өмнө тохиолддог лавлагааны тоог багасгахаас өмнө тохиолддог гэсэн үг юм.
        //
        // [Boost documentation][1] дээр тайлбарласны дагуу
        //
        // > Объект руу нэвтрэх боломжтой бүх зүйлийг нэг дор хэрэгжүүлэх нь чухал юм
        // > thread (одоо байгаа лавлагаагаар дамжуулан)*устгахаас өмнө* тохиолдох
        // > обьект нь өөр урсгалтай байна.Энэ нь "release"-ийн тусламжтайгаар хийгддэг
        // > лавлагаа унагасны дараа үйл ажиллагаа (объектод хандах хандалт
        // > энэ лавлагаагаар дамжуулан өмнө нь мэдээж тохиолдсон байх ёстой), мөн
        // > "acquire" объектыг устгахаас өмнө ажиллуулах.
        //
        // Ялангуяа Arc-ийн агуулга ихэвчлэн өөрчлөгддөггүй боловч Mutex шиг зүйлд интерьер бичих боломжтой байдаг.<T>.
        // Mutex-ийг устгахад олж авдаггүй тул бид A урсгалд бичих үйлдлийг B урсгалд ажиллаж байгаа устгагчдад харагдуулахын тулд синхрончлолын логик дээр тулгуурлаж чадахгүй.
        //
        //
        // Эндээс олж авах хашаа нь Acquire ачааллаар солигдож магадгүй тул маргаантай нөхцөл байдалд гүйцэтгэлийг сайжруулж болохыг анхаарна уу.[2]-г үзнэ үү.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>`-ийг бетоны төрөлд буулгах оролдлого.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Санах ой хуваарилалгүйгээр шинэ `Weak<T>` бүтээдэг.
    /// Буцах утга дээр [`upgrade`] руу залгах нь үргэлж [`None`] өгдөг.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Өгөгдлийн талбайн талаар ямар ч баталгаа гаргахгүйгээр лавлагааны тооллогод хандах боломжийг олгох туслах бичих.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Энэ `Weak<T>`-ийн заасан `T` объект руу түүхий заагчийг буцаана.
    ///
    /// Зарим хүчтэй лавлагаа байгаа тохиолдолд л заагч хүчинтэй байна.
    /// Заагч нь унжсан, тохируулаагүй эсвэл [`null`] байж болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Хоёулаа нэг зүйлийг зааж байна
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Энд байгаа хүчтэй нь түүнийг амьд байлгадаг тул бид тухайн объект руу нэвтрэх боломжтой хэвээр байна.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Гэхдээ үүнээс цаашгүй.
    /// // Бид weak.as_ptr() хийж чадна, гэхдээ заагч руу хандах нь тодорхойгүй зан авирт хүргэх болно.
    /// // assert_eq! ("сайн уу", аюултай {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Хэрэв заагч унжиж байгаа бол бид харуулыг шууд буцаадаг.
            // Ачаа ачаа нь дор хаяж ArcInner (usize)-тэй нийцсэн тул энэ нь хүчинтэй ачааны хаяг байж болохгүй.
            ptr as *const T
        } else {
            // АЮУЛГҮЙ БАЙДАЛ: хэрэв is_dangling нь худал утгатай бол заагчийг дахин холбож болно.
            // Ачаалал энэ үед буурч магадгүй тул бид туршилтаа хадгалах ёстой тул түүхий заагчийг ашиглах хэрэгтэй.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>`-ийг хэрэглэж түүхий заагч болгоно.
    ///
    /// Энэ нь сул заагчийг түүхий заагч болгон хөрвүүлэх бөгөөд нэг сул лавлагааны өмчлөлийг хадгалсаар байх болно (сул тоог энэ үйлдлээр өөрчлөхгүй).
    /// Үүнийг [`from_raw`]-тэй буцааж `Weak<T>` болгож болно.
    ///
    /// [`as_ptr`]-тэй адил заагчийн бай руу нэвтрэх хязгаарлалтууд хамаарна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Өмнө нь [`into_raw`] үүсгэсэн түүхий заагчийг буцааж `Weak<T>` болгон хөрвүүлдэг.
    ///
    /// Үүнийг хүчтэй лавлагаа авахад ашиглаж болно (дараа нь [`upgrade`] руу залгах замаар) эсвэл сул тоог тоолохын тулд `Weak<T>`-ийг унагаж болно.
    ///
    /// Энэ нь нэг сул лавлагааг эзэмшдэг ([`new`]-ийн бүтээсэн заагчийг эс тооцвол эдгээр нь юу ч эзэмшдэггүй тул арга нь тэдгээр дээр ажилладаг хэвээр байна).
    ///
    /// # Safety
    ///
    /// Заагч нь [`into_raw`]-ээс гаралтай байх ёстой бөгөөд сул сул лавлагааг эзэмшсэн хэвээр байх ёстой.
    ///
    /// Үүнийг дуудах үед хүчтэй тоо 0 байхыг зөвшөөрнө.
    /// Гэсэн хэдий ч энэ нь одоогоор түүхий заагч хэлбэрээр илэрхийлэгдсэн нэг сул лавлагааг эзэмшдэг (сул тоог энэ үйлдлээр өөрчилдөггүй) тул [`into_raw`] руу хийсэн өмнөх дуудлагатай хослуулах ёстой.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Сүүлчийн сул тооллыг багасгах.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Оролтын заагчийг хэрхэн яаж гаргаж авах талаар Weak::as_ptr контексттэй танилцана уу.

        let ptr = if is_dangling(ptr as *mut T) {
            // Энэ бол унжсан Сул.
            ptr as *mut ArcInner<T>
        } else {
            // Үгүй бол заагч нь хүний хэл аманд ороогүй сул талаас гарна гэсэн баталгаатай болно.
            // АЮУЛГҮЙ БАЙДАЛ: ptr нь бодит (буурах магадлалтай) T-г иш татдаг тул data_offset руу залгахад аюулгүй.
            let offset = unsafe { data_offset(ptr) };
            // Тиймээс бид RcBox-ийг бүхэлд нь авахын тулд офсетыг буцаана.
            // АЮУЛГҮЙ БАЙДАЛ: заагч нь сул талаас үүссэн тул энэ офсет аюулгүй байна.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // АЮУЛГҮЙ БАЙДАЛ: бид одоо анхны Сул заагчийг сэргээсэн тул Сул талуудыг бий болгож чадна.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` заагчийг [`Arc`] болгож шинэчлэх оролдлого амжилттай бол дотоод утгыг бууруулж хойшлуулна.
    ///
    ///
    /// Хэрэв дотоод утга хойш унасан бол [`None`] буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Бүх хүчтэй заагчдыг устга.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Энэ функц нь лавлагаа тооллогыг тэгээс нэг рүү хэзээ ч оруулахгүй тул бид fetch_add-ийн оронд хүчтэй тооллыг нэмэгдүүлэхийн тулд CAS давталтыг ашигладаг.
        //
        //
        let inner = self.inner()?;

        // Бидний ажиглаж болох 0 гэсэн бичээс нь талбарыг бүрмөсөн тэг байдалд үлдээдэг тул бусад ачаалал нь доорхи CAS-ээр баталгааждаг тул ачаалал нь тайван байдаг.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Үүнийг яагаад хийдэгийг `Arc::clone` дээрх сэтгэгдлээс үзнэ үү (`mem::forget`-ийн хувьд).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed нь бүтэлгүйтсэн тохиолдолд зүгээр юм, учир нь бид шинэ төлөв байдлын талаар ямар ч хүлээлтгүй байна.
            // Acquire нь `Arc::new_cyclic`-тэй синхрончлогдсон тохиолдолд дотоод утгыг `Weak` лавлагаа үүсгэсний дараа эхлүүлж болох үед амжилтанд хүрэх шаардлагатай.
            // Энэ тохиолдолд бид бүрэн эхлүүлсэн утгыг ажиглах болно гэж найдаж байна.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // дээр тэмдэглэсэн
                Err(old) => n = old,
            }
        }
    }

    /// Энэхүү хуваарилалтыг зааж өгсөн хүчтэй (`Arc`) заагчийн тоог авна.
    ///
    /// Хэрэв `self`-ийг [`Weak::new`] ашиглан бүтээсэн бол энэ нь 0-ийг буцаана.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Энэ хуваарилалтыг зааж өгсөн `Weak` заагчийн тоог ойролцоогоор авна.
    ///
    /// Хэрэв `self`-ийг [`Weak::new`] ашиглан бүтээсэн эсвэл үлдсэн хүчтэй заагч байхгүй бол энэ нь 0 гэсэн утгатай болно.
    ///
    /// # Accuracy
    ///
    /// Хэрэгжүүлэлтийн нарийвчилсан байдлаас шалтгаалан бусад урсгалууд ижил хуваарилалтыг зааж өгөхдөө "Arc`s эсвэл"Weak`s-ийг удирдаж байх үед буцааж өгсөн утгыг аль ч чиглэлд 1-ээр хаах боломжтой.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Сул тооллыг уншсаны дараа дор хаяж нэг хүчтэй заагч байгааг бид ажигласан тул сул тооллыг ажиглахад далд сул лавлагаа (ямар ч хүчтэй эшлэлүүд амьд байх үед байдаг) байсаар байсныг бид мэдэж байсан тул үүнийг аюулгүйгээр хасч чадна.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Заагч унжсан, хуваарилагдсан `ArcInner` байхгүй үед `None`-ийг буцаана (өөрөөр хэлбэл энэ `Weak`-ийг `Weak::new` бүтээсэн үед).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // "data" талбарыг хамарсан лавлагаа үүсгэхгүй байх тал дээр анхааралтай хандах хэрэгтэй, учир нь талбарыг нэгэн зэрэг мутацид оруулж болзошгүй (жишээлбэл, сүүлчийн `Arc`-ийг унагавал өгөгдлийн талбарыг газар дээр нь хаях болно).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Хоёр сул тал нь ижил хуваарилалтыг зааж өгсөн бол ([`ptr::eq`]-тэй төстэй) эсвэл хоёулаа ямар нэгэн хуваарилалтыг заагаагүй бол (хэрэв тэд `Weak::new()`)-тэй хамт бүтээгдсэн тул) `true`-ийг буцаана.
    ///
    ///
    /// # Notes
    ///
    /// Энэ нь заагчдыг харьцуулж байгаа тул `Weak::new()` нь хуваарилалтыг заагаагүй ч гэсэн хоорондоо тэнцүү байх болно гэсэн үг юм.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new`-ийг харьцуулах.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Ижил хуваарилалтыг зааж өгсөн `Weak` заагчийн клоныг гаргадаг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Үүнийг яагаад тайвшруулж байгааг Arc::clone() дээрх сэтгэгдлээс үзнэ үү.
        // Энэ нь fetch_add-ийг ашиглаж болно (түгжээг үл тоомсорлох), учир нь сул тоолол нь *өөр* сул заагч байхгүй газарт л түгжигддэг.
        //
        // (Тэгэхээр бид энэ тохиолдолд энэ кодыг ажиллуулж чадахгүй).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Үүнийг яагаад хийдэгийг Arc::clone() дээрх сэтгэгдлээс үзнэ үү (mem::forget-ийн хувьд).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Санах ой хуваарилалгүйгээр шинэ `Weak<T>` бүтээдэг.
    /// Буцах утга дээр [`upgrade`] руу залгах нь үргэлж [`None`] өгдөг.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` заагчийг унагав.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Юу ч хэвлэхгүй
    /// drop(foo);        // "dropped!" хэвлэнэ
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Хэрэв бид хамгийн сүүлчийн сул заагч байсныг мэдвэл өгөгдлийг бүхэлд нь хуваарилах цаг болжээ.Санах ойн захиалгын талаархи Arc::drop() хэлэлцүүлгийг үзнэ үү
        //
        // Энд түгжигдсэн төлөв байдлыг шалгах шаардлагагүй, учир нь сул сул тоог зөвхөн нэг сул ref байгаа тохиолдолд л түгжих боломжтой, ингэснээр уналт нь дараа нь үлдсэн сул ref-ийг ON ажиллуулах боломжтой бөгөөд түгжээ гарсны дараа л гарч болзошгүй юм.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Бид энэ мэргэшлийг `&T` дээр ерөнхийдөө оновчтой болгох үүднээс биш энд хийж байна, яагаад гэвэл энэ нь бүх тэгш байдлын шалгалтанд зардал нэмэх болно.
/// Бид "Arc`s"-ийг клончлоход удаан, гэхдээ тэгш байдлыг шалгахад хүнд байдаг тул энэ зардлыг илүү хялбараар төлөхөд хүргэдэг том утгуудыг хадгалахад ашигладаг гэж үздэг.
///
/// Мөн ижил утгыг зааж буй хоёр `Arc` клонтой байх магадлал хоёр&T`-ээс илүү байдаг.
///
/// `T: Eq` нь `PartialEq` хэлбэрээр санаатайгаар эргэлт буцалтгүй байж болзошгүй тохиолдолд бид үүнийг хийж чадна.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Хоёр Arc-ийн тэгш байдал.
    ///
    /// Хоёр `Arc` нь өөр өөр хуваарилалтад хадгалагдсан байсан ч дотоод утга нь тэнцүү бол тэнцүү байна.
    ///
    /// Хэрэв `T` нь `Eq` (тэгш байдлын рефлексийг илэрхийлсэн)-ийг хэрэгжүүлдэг бол ижил хуваарилалтыг зааж өгсөн хоёр Arc` нь үргэлж тэнцүү байна.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Хоёр Arc-ийн тэгш бус байдал.
    ///
    /// Хэрэв дотоод утга нь тэнцүү биш бол хоёр `Arc` нь тэнцүү биш байна.
    ///
    /// Хэрэв `T` нь `Eq` (тэгш байдлын рефлекс чанарыг илэрхийлсэн)-ийг хэрэгжүүлдэг бол ижил утгыг зааж буй хоёр "Arc` нь хэзээ ч тэгш бус байдаг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Хоёр Arc-ийн харьцуулсан харьцуулалт.
    ///
    /// Хоёулаа дотоод үнэ цэнэ дээрээ `partial_cmp()` дуудаж харьцуулсан болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Хоёр Arc-ийн харьцуулалтаас бага.
    ///
    /// Хоёулаа дотоод үнэ цэнэ дээрээ `<` дуудаж харьцуулсан болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Хоёр "Arc`-ийн харьцуулалт"бага буюу тэнцүү"байна.
    ///
    /// Хоёулаа дотоод үнэ цэнэ дээрээ `<=` дуудаж харьцуулсан болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Хоёр Arc-ийн харьцуулалтаас илүү том.
    ///
    /// Хоёулаа дотоод үнэ цэнэ дээрээ `>` дуудаж харьцуулсан болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Хоёр "Arc`-ийн харьцуулалтаас"их буюу тэнцүү"харьцуулалт.
    ///
    /// Хоёулаа дотоод үнэ цэнэ дээрээ `>=` дуудаж харьцуулсан болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Хоёр Arc-ийн харьцуулалт.
    ///
    /// Хоёулаа дотоод үнэ цэнэ дээрээ `cmp()` дуудаж харьцуулсан болно.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T`-ийн `Default` утгатай шинэ `Arc<T>` үүсгэдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Лавлагаагаар тоолсон зүслэгийг хуваарилж, "v"-ийн зүйлийг клончлох замаар бөглөөрэй
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Лавлагааны тоолсон `str` хуваарилж, `v`-ийг хуулж ав.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Лавлагааны тоолсон `str` хуваарилж, `v`-ийг хуулж ав.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Хайрцаглагдсан объектыг лавлагаагаар тоолсон шинэ хуваарилалт руу шилжүүлэх.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Лавлагаагаар тоолсон зүслэгийг хуваарилж, `v`-ийн зүйлийг оруулна уу.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec-д санах ойгоо суллахыг зөвшөөрч, агуулгыг нь устгахгүй
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Элемент тус бүрийг `Iterator` дээр авч `Arc<[T]>` болгон цуглуулдаг.
    ///
    /// # Гүйцэтгэлийн шинж чанар
    ///
    /// ## Ерөнхий хэрэг
    ///
    /// Ерөнхийдөө `Arc<[T]>`-т цуглуулах ажлыг эхлээд `Vec<T>`-д цуглуулдаг.Энэ нь дараахь зүйлийг бичихдээ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// энэ нь бид бичсэн юм шиг аашилдаг:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Эхний хуваарилалт энд хийгддэг.
    ///     .into(); // `Arc<[T]>`-ийн хоёр дахь хуваарилалт энд тохиолддог.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Энэ нь `Vec<T>`-ийг бүтээхэд шаардлагатай хэмжээгээр хуваарилах бөгөөд дараа нь `Vec<T>`-ийг `Arc<[T]>` болгон өөрчлөхөд нэг удаа хуваарилагдах болно.
    ///
    ///
    /// ## Урт мэдэгдэж байгаа давталт
    ///
    /// Таны `Iterator` нь `TrustedLen`-ийг хэрэгжүүлж яг ижил хэмжээтэй байх үед `Arc<[T]>`-д зориулж ганц хуваарилалт хийгдэх болно.Жишээлбэл:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Энд ганцхан хуваарилалт болдог.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>` руу цуглуулахад ашигладаг төрөлжсөн trait.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Энэ нь `TrustedLen` давталтын хувьд тохиолддог тохиолдол юм.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // АЮУЛГҮЙ БАЙДАЛ: Бид давталтыг яг урттай байлгах ёстой.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Хэвийн хэрэгжилтэд эргээд унана.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Заагчийн цаана байгаа ачааллыг `ArcInner` дотор нөхөж аваарай.
///
/// # Safety
///
/// Заагч нь өмнө нь хүчин төгөлдөр байсан T-ийн жишээг зааж өгөх ёстой (мөн хүчинтэй мета өгөгдөлтэй байх ёстой), гэхдээ T-г хасахыг зөвшөөрдөг.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Хэмжээгүй утгыг ArcInner-ийн төгсгөлд зэрэгцүүл.
    // RcBox нь repr(C) тул санах ойн үргэлж хамгийн сүүлийн талбар байх болно.
    // АЮУЛГҮЙ БАЙДАЛ: хэмжээ хязгааргүй цорын ганц төрөл нь зүсмэлүүд тул trait объектууд,
    // болон гадаад төрлүүдийн хувьд оролтын аюулгүй байдлын шаардлага нь одоогоор align_of_val_raw-ийн шаардлагыг хангахад хангалттай байна;Энэ бол std-ээс гадуур найдаж болохгүй хэлний хэрэгжилтийн дэлгэрэнгүй мэдээлэл юм.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}