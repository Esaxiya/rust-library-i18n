//! # Rust үндсэн хуваарилалт ба цуглуулгын номын сан
//!
//! Энэхүү номын сан нь овоо хуваарилагдсан утгыг удирдах ухаалаг заагч, цуглуулгатай.
//!
//! Энэ номын сан нь libcore шиг ердийн үед шууд ашиглагдах шаардлагагүй байдаг тул агуулгыг нь [`std` crate](../std/index.html) дээр дахин экспортлох боломжтой байдаг.
//! `#![no_std]` шинж чанарыг ашигладаг Crates нь ихэвчлэн `std`-ээс хамаардаггүй тул оронд нь энэ crate-ийг ашиглах болно.
//!
//! ## Хайрцагласан утга
//!
//! [`Box`] төрөл нь ухаалаг заагчийн төрөл юм.[`Box`]-ийн зөвхөн нэг эзэн байж болох бөгөөд эзэмшигч нь овоолго дээр амьдардаг агуулгыг мутацлахаар шийдэж болно.
//!
//! Энэ төрлийг `Box` утгын хэмжээ нь заагчийн хэмжээтэй ижил тул үр дүнтэй дамжуулж болно.
//! Мод шиг өгөгдлийн бүтцийг ихэвчлэн хайрцгаар бүтээдэг бөгөөд учир нь зангилаа бүр зөвхөн нэг л эцэг эхтэй байдаг.
//!
//! ## Лавлагаа тоолсон заагч
//!
//! [`Rc`] төрөл нь урсгал доторх санах ойг хуваалцахад зориулагдсан, аюулгүй бус лавлагаа тоолсон заагчийн төрөл юм.
//! [`Rc`] заагч нь `T` төрлийг ороож, зөвхөн `&T`-т хандах боломжийг олгодог.
//!
//! Энэ төрөл нь удамшлын дагуу өөрчлөгддөг ([`Box`]-ийг ашиглах гэх мэт) програмын хувьд хэтэрхий хязгаарлагдмал үед ашигтай байдаг ба мутацийг зөвшөөрөх үүднээс ихэвчлэн [`Cell`] эсвэл [`RefCell`] төрлүүдтэй хослуулдаг.
//!
//!
//! ## Атомын хувьд тоолсон заагч
//!
//! [`Arc`] төрөл нь [`Rc`] хэлбэртэй тэнцэх threadsafe юм.Энэ нь [`Rc`]-ийн ижил ажиллагааг хангаж өгдөг, гэхдээ `T` төрлийн хуваалцах боломжтой байхыг шаарддаг.
//! Нэмж дурдахад [`Arc<T>`][`Arc`] нь өөрөө илгээх боломжтой, харин [`Rc<T>`][`Rc`] биш юм.
//!
//! Энэ төрөл нь агуулагдсан өгөгдөлд дундын хандалт хийх боломжийг олгодог бөгөөд ихэнхдээ мутекс зэрэг синхрончлолын командуудтай хослуулан дундын нөөцийг мутацлах боломжийг олгодог.
//!
//! ## Collections
//!
//! Хамгийн нийтлэг өгөгдлийн бүтцийн хэрэгжилтийг энэ номын санд тодорхойлсон болно.Тэд [standard collections library](../std/collections/index.html)-ээр дамжуулан дахин экспортлогдоно.
//!
//! ## Нуруулдан интерфейс
//!
//! [`alloc`](alloc/index.html) модуль нь доод түвшний интерфэйсийг анхдагч дэлхийн хуваарилагчаар тодорхойлдог.Энэ нь libc хуваарилагч API-тай нийцэхгүй байна.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Техникийн хувьд энэ нь rustdoc-ийн алдаа юм: rustdoc нь `#[lang = slice_alloc]` блок дээрх баримт бичгийг `&[T]`-т зориулж хардаг бөгөөд энэ функцийг `core` дээр ашигладаг баримт бичигтэй байдаг бөгөөд энэ функц-хаалга идэвхжээгүйд галзуурдаг.
// Энэ нь бусад crates-ийн документуудын онцлог хаалгыг шалгахгүй байсан ч энэ нь зөвхөн lang зүйлүүдэд л гарч ирдэг тул засах шаардлагагүй юм шиг санагдаж байна.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Энэ номын санг туршиж үзэхийг зөвшөөрөх

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Бусад модулиудад ашигладаг дотоод макро бүхий модуль (бусад модулиудын өмнө оруулах шаардлагатай).
#[macro_use]
mod macros;

// Доод түвшний хуваарилалтын стратегид зориулж овоолсон болно

pub mod alloc;

// Дээрх нуруулаг ашиглан анхдагч төрлүүд

// Туршилтын cfg файлыг бүтээхэд lang-зүйлүүдийг хуулбарлахаас зайлсхийхийн тулд `boxed.rs`-ээс модыг нөхцөлт байдлаар тодорхойлох шаардлагатай.гэхдээ `use boxed::Box;` тунхаглалтай байх кодыг зөвшөөрөх хэрэгтэй.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}