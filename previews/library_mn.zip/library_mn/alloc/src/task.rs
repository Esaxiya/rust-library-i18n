#![stable(feature = "wake_trait", since = "1.51.0")]
//! Асинхрон даалгавартай ажиллах төрөл ба Traits.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Гүйцэтгэгч дээр даалгаврыг сэрээх.
///
/// Энэ trait-ийг [`Waker`] үүсгэхэд ашиглаж болно.
/// Гүйцэтгэгч энэхүү trait-ийн хэрэгжилтийг тодорхойлж, түүнийг ашиглан Вейкерийг уг гүйцэтгэгч дээр гүйцэтгэж буй даалгаварт шилжүүлэхэд ашиглаж болно.
///
/// Энэхүү trait нь санах ойд аюулгүй, эргономикийн хувьд [`RawWaker`] бүтээх хувилбар юм.
/// Энэ нь даалгаврыг сэрээхэд ашигладаг өгөгдлийг [`Arc`]-д хадгалдаг нийтлэг гүйцэтгэгч дизайныг дэмждэг.
/// Зарим гүйцэтгэгчид (ялангуяа суулгагдсан системүүдийн хувьд) энэ API-г ашиглаж чадахгүй байгаа тул [`RawWaker`] нь эдгээр системүүдийн хувьд өөр хувилбар байдаг.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// future-ийг аваад одоогийн урсгал дээр дуустал ажиллуулдаг үндсэн `block_on` функц.
///
/// **Note:** Энэ жишээ нь зөв байдлыг энгийн байдлаар арилжаалдаг.
/// Түгжрэлээс урьдчилан сэргийлэхийн тулд үйлдвэрлэлийн түвшний хэрэгжүүлэлтүүд нь `thread::unpark` руу завсрын дуудлага хийх, мөн үүрэн дуудлага хийх шаардлагатай болно.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Дуудлага хийхэд одоогийн утсыг сэрээдэг сэрээч.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Одоогийн урсгал дээр дуусгахын тулд future ажиллуулна уу.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Санал авах боломжтой тул future-ийг зүүнэ үү.
///     let mut fut = Box::pin(fut);
///
///     // future руу дамжуулах шинэ контекст үүсгээрэй.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // future-ийг дуустал ажиллуулна уу.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Энэ даалгаврыг сэрээ.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Энэ даалгаврыг сэрээгчийг ашиглахгүйгээр сэрээ.
    ///
    /// Хэрэв гүйцэтгэгч сэрээгчийг ашиглахгүйгээр сэрээх хямд аргыг дэмжиж байгаа бол энэ аргыг хүчингүй болгох хэрэгтэй.
    /// Анхдагч байдлаар, энэ нь [`Arc`]-ийг хувилж, [`wake`]-ийг клон дээр дууддаг.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // АЮУЛГҮЙ БАЙДАЛ: raw_waker аюулгүй бүтээдэг тул аюулгүй
        // Arc-ийн RawWaker<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker-ийг бүтээх энэхүү хувийн функцийг ашиглахын оронд ашигладаг
// Үүнийг `From<Arc<W>> for RawWaker` имплд багтааж, `From<Arc<W>> for Waker`-ийн аюулгүй байдал нь зөв trait диспетчерээс хамаарахгүй гэдгийг баталгаажуулахын тулд хоёулаа энэ функцийг шууд ба тодорхой дууддаг.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Клончлохын тулд нумын лавлах тоог нэмэгдүүлнэ үү.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Arc-ийг Wake::wake функц руу шилжүүлээд утгаар нь сэрээ
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Лавлагаагаар сэрээгээд унагаахгүйн тулд сэрээгээ ManualDrop дээр боож боох хэрэгтэй
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Arc-ийн лавлагааны тоог дусал дээр бууруул
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}