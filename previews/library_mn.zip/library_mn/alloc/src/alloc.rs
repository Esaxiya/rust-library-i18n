//! Санах ойн хуваарилалтын API

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Эдгээр нь дэлхийн хуваарилагчийг дуудах шидэт тэмдэг юм.rustc нь `__rg_alloc` гэх мэтийг дуудахын тулд тэдгээрийг үүсгэдэг.
    // хэрэв `#[global_allocator]` шинж чанар байгаа бол (тухайн макротыг өргөжүүлэх код нь эдгээр функцийг үүсгэдэг), эсвэл libstd (`__rdl_alloc` гэх мэт) дэх анхдагч хэрэгжилтийг дуудах.
    //
    // `library/std/src/alloc.rs`-д) өөрөөр хэлбэл.
    // LLVM-ийн rustc fork нь эдгээр функцын нэрсийг `malloc`, `realloc`, `free` тус тусад нь оновчтой болгохын тулд тусгай тохиолдол байдаг.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Дэлхийн санах ойн хуваарилагч.
///
/// Энэ төрөл нь [`Allocator`] trait-ийг `#[global_allocator]` шинж чанараар бүртгэгдсэн хуваарилагч руу дуудлага дамжуулах эсвэл `std` crate-ийн анхдагчаар дамжуулах замаар хэрэгжүүлдэг.
///
///
/// Note: энэ төрөл нь тогтворгүй боловч түүний хангаж өгсөн функцэд [free functions in `alloc`](self#functions)-ээр хандах боломжтой.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Глобал хуваарилагчтай санах ой хуваарилах.
///
/// Энэ функц нь `#[global_allocator]` атрибутад бүртгэгдсэн хуваарилагчийн [`GlobalAlloc::alloc`] арга руу эсвэл `std` crate-ийн анхдагчаар дамжуулдаг.
///
///
/// Энэ функц болон [`Allocator`] trait тогтвортой болоход [`Global`] төрлийн `alloc` аргын ашиг тусын тулд хүчингүй болох төлөвтэй байна.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`]-г үзнэ үү.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Глобал хуваарилагчтай санах ойг хуваарилах.
///
/// Энэ функц нь `#[global_allocator]` атрибутад бүртгэгдсэн хуваарилагчийн [`GlobalAlloc::dealloc`] арга руу эсвэл `std` crate-ийн анхдагчаар дамжуулдаг.
///
///
/// Энэ функц болон [`Allocator`] trait тогтвортой болоход [`Global`] төрлийн `dealloc` аргын ашиг тусын тулд хүчингүй болох төлөвтэй байна.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`]-г үзнэ үү.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Глобал хуваарилагчтай санах ойг дахин хуваарилах.
///
/// Энэ функц нь `#[global_allocator]` атрибутад бүртгэгдсэн хуваарилагчийн [`GlobalAlloc::realloc`] арга руу эсвэл `std` crate-ийн анхдагчаар дамжуулдаг.
///
///
/// Энэ функц болон [`Allocator`] trait тогтвортой болоход [`Global`] төрлийн `realloc` аргын ашиг тусын тулд хүчингүй болох төлөвтэй байна.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`]-г үзнэ үү.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Глобал хуваарилагчтай тэгээс эхлүүлсэн санах ойг хуваарилах.
///
/// Энэ функц нь `#[global_allocator]` атрибутад бүртгэгдсэн хуваарилагчийн [`GlobalAlloc::alloc_zeroed`] арга руу эсвэл `std` crate-ийн анхдагчаар дамжуулдаг.
///
///
/// Энэ функц болон [`Allocator`] trait тогтвортой болоход [`Global`] төрлийн `alloc_zeroed` аргын ашиг тусын тулд хүчингүй болох төлөвтэй байна.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`]-г үзнэ үү.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // АЮУЛГҮЙ БАЙДАЛ: `layout` нь тэг биш хэмжээтэй,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // Аюулгүй байдал: `Allocator::grow`-тэй ижил
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // Аюулгүй байдал: `old_size` нь `new_size`-ээс их эсвэл тэнцүү тул `new_size` нь тэг биш байна
            // аюулгүй байдлын нөхцлийн дагуу.Бусад нөхцөлийг дуудлага өгсөн хүн дагаж мөрдөх ёстой
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` `new_size >= old_layout.size()` эсвэл үүнтэй төстэй зүйлийг шалгаж магадгүй юм.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // Аюулгүй байдал: `new_layout.size()` нь `old_size`-ээс их эсвэл тэнцүү байх ёстой,
            // хуучин болон шинэ санах ойн хуваарилалт хоёулаа `old_size` байтаар унших, бичихэд хүчинтэй.
            // Түүнчлэн хуучин хуваарилалтыг хараахан хуваарилж амжаагүй байсан тул `new_ptr`-тай давхцах боломжгүй юм.
            // Тиймээс `copy_nonoverlapping` руу залгах нь аюулгүй юм.
            // `dealloc`-ийн аюулгүй ажиллагааны гэрээг дуудлага өгсөн хүн дагаж мөрдөх ёстой.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // АЮУЛГҮЙ БАЙДАЛ: `layout` нь тэг биш хэмжээтэй,
            // бусад нөхцөлийг дуудлага өгсөн хүн дагаж мөрдөх ёстой
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч бүх нөхцлийг хангасан байх ёстой
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч бүх нөхцлийг хангасан байх ёстой
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // АЮУЛГҮЙ АЖИЛЛАГАА: нөхцөлийг дуудлага өгсөн хүн дагаж мөрдөх ёстой
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // Аюулгүй байдал: `new_size` нь тэг биш байна.Бусад нөхцөлийг дуудлага өгсөн хүн дагаж мөрдөх ёстой
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` `new_size <= old_layout.size()` эсвэл үүнтэй төстэй зүйлийг шалгаж магадгүй юм.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // Аюулгүй байдал: `new_size` нь `old_layout.size()`-ээс бага эсвэл тэнцүү байх ёстой,
            // хуучин болон шинэ санах ойн хуваарилалт хоёулаа `new_size` байтаар унших, бичихэд хүчинтэй.
            // Түүнчлэн хуучин хуваарилалтыг хараахан хуваарилж амжаагүй байсан тул `new_ptr`-тай давхцах боломжгүй юм.
            // Тиймээс `copy_nonoverlapping` руу залгах нь аюулгүй юм.
            // `dealloc`-ийн аюулгүй ажиллагааны гэрээг дуудлага өгсөн хүн дагаж мөрдөх ёстой.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Өвөрмөц заагчийн хуваарилагч.
// Энэ функц нь тайлагдах ёсгүй.Хэрэв ингэсэн бол MIR код үүсгэгч нь бүтэлгүйтэх болно.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Энэ гарын үсэг нь `Box`-тэй ижил байх ёстой, эс тэгвээс ICE тохиолдох болно.
// `Box`-д нэмэлт параметр нэмэх үед (`A: Allocator` гэх мэт) энд нэмэх шаардлагатай болно.
// Жишээлбэл, `Box`-ийг `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` болгож өөрчилсөн бол энэ функцийг `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` болгож өөрчлөх хэрэгтэй.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Хуваарилалтын алдааны зохицуулагч

extern "Rust" {
    // Энэ бол дэлхийн хуваарилалтын алдааны зохицуулагчийг дуудах шидэт тэмдэг юм.
    // rustc нь `#[alloc_error_handler]` байгаа тохиолдолд `__rg_oom` руу залгах, эс тэгвэл (`__rdl_oom`)-ээс доош анхдагч хэрэгжилтийг дуудах зорилгоор үүсгэдэг.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Санах ойн хуваарилалтын алдаа эсвэл алдаа гарсан тохиолдолд цуцлах.
///
/// Хуваарилалтын алдааны хариуд тооцооллыг зогсоохыг хүсч буй санах ойн хуваарилалтын API-ийн дуудлага хийгчид шууд `panic!` эсвэл үүнтэй төстэй дуудлага хийхийн оронд энэ функцийг дуудахыг уриалж байна.
///
///
/// Энэ функцын анхдагч үйлдэл нь мессежийг стандарт алдаанд хэвлэж, процессыг зогсоох явдал юм.
/// Үүнийг [`set_alloc_error_hook`] ба [`take_alloc_error_hook`]-ээр сольж болно.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Хувилбарын хувьд `std::alloc::handle_alloc_error`-ийг шууд ашиглаж болно.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // үүсгэсэн `__rust_alloc_error_handler`-ээр дамжуулан дууддаг

    // хэрэв `#[alloc_error_handler]` байхгүй бол
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // хэрэв `#[alloc_error_handler]` байгаа бол
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Урьдчилан хуваарилагдсан, эхлүүлээгүй санах ойд клонуудыг мэргэшүүлэх.
/// `Box::clone` ба `Rc`/`Arc::make_mut` ашигладаг.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *Эхний* хуваарилалт хийснээр оновчлогч нь клончлогдсон утгыг байрандаа үүсгэж, локалийг алгасаад хөдөлж болно.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Бид орон нутгийн үнэ цэнийг оролцуулахгүйгээр үргэлж байрандаа хуулж чаддаг.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}