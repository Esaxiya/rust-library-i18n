use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Гуравдагч этгээдийн хуваарилагчид болон `RawVec`-ийн хоорондох интеграцийн тест бичих нь жаахан төвөгтэй байдаг тул `RawVec` API нь хуваарилалтын алдаатай аргуудыг харуулдаггүй тул хуваарилагч дуусахад юу болохыг шалгаж чадахгүй (panic-ийг илрүүлэхээс цаашгүй).
    //
    //
    // Үүний оронд энэ нь `RawVec` аргууд нь хадгалах санд нөөцлөхдөө хамгийн багадаа Allocator API-ээр дамждаг эсэхийг шалгадаг.
    //
    //
    //
    //
    //

    // Хуваарилах оролдлогын өмнө тогтмол хэмжээний түлш хэрэглэдэг дүлий хуваарилагч бүтэлгүйтэж эхэлдэг.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (realloc үүсгэдэг тул 50 + 150=200 нэгж түлш хэрэглэдэг)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Нэгдүгээрт, `reserve` нь `reserve_exact` шиг хуваарилдаг.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 нь 7-оос хоёр дахин их тул `reserve` нь `reserve_exact` шиг ажиллах ёстой.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 нь 12-ын талаас бага хувь тул `reserve` нь хурдаар өсөх ёстой.
        // Энэхүү туршилтыг бичиж байх үед өсөлтийн коэффициент 2 байна, тиймээс шинэ хүчин чадал 24 байна, гэхдээ 1.5-ийн өсөлтийн коэффициент бас зүгээр байна
        //
        // Тиймээс `>= 18` баталж байна.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}