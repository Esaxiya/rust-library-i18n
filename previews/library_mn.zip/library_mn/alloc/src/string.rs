//! UTF-8 - кодлогдсон, ургадаг утас.
//!
//! Энэ модуль нь [`String`] төрөл, мөрт хөрвүүлэх [`ToString`] trait болон [`String`] s-тэй ажиллахад гарах хэд хэдэн алдааны төрлийг агуулдаг.
//!
//!
//! # Examples
//!
//! Үг үсэгнээс шинэ [`String`] үүсгэх олон арга байдаг:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Та одоо байгаагаас шинэ [`String`] үүсгэх боломжтой
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Хэрэв танд хүчинтэй UTF-8 байт vector байгаа бол та үүнээс [`String`] хийж болно.Та бас урвуу зүйлийг хийж болно.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Эдгээр байт хүчинтэй гэдгийг бид мэддэг тул бид `unwrap()` ашиглах болно.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8 - кодлогдсон, ургадаг утас.
///
/// `String` төрөл нь мөрийн агуулгыг эзэмшдэг хамгийн түгээмэл мөрийн төрөл юм.Энэ нь зээлсэн хамтрагч, эртний [`str`]-тэй ойр дотно харилцаатай байдаг.
///
/// # Examples
///
/// Та [a literal string][`str`]-ээс [`String::from`] ашиглан `String` үүсгэх боломжтой:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Та [`char`]-ийг `String`-т [`push`] аргаар нэмж, [`&str`]-ийг [`push_str`] аргаар нэмж болно.
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Хэрэв танд UTF-8 байтын vector байгаа бол [`from_utf8`] аргаар `String` үүсгэж болно:
///
/// ```
/// // зарим байт, vector дээр
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Эдгээр байт хүчинтэй гэдгийг бид мэддэг тул бид `unwrap()` ашиглах болно.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String` нь үргэлж UTF-8 хүчинтэй байдаг.Энэ нь цөөн хэдэн үр дагавартай бөгөөд эхнийх нь хэрэв танд UTF-8 биш мөр шаардлагатай бол [`OsString`]-ийг бодоорой.Энэ нь ижил төстэй боловч UTF-8 хязгаарлалтгүйгээр.Хоёрдахь утга нь `String` дээр индексжүүлж чадахгүй гэсэн үг юм.
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Индексжүүлэлт нь байнгын ажиллагаатай байх зорилготой боловч UTF-8 кодчилол нь үүнийг хийхийг зөвшөөрдөггүй.Цаашилбал, индекс ямар төрлийн зүйлийг буцааж өгөх нь тодорхойгүй байна: байт, кодоо цэг эсвэл графемийн кластер.
/// [`bytes`] ба [`chars`] аргууд нь эхний хоёроос илүү давталтыг буцааж өгдөг.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// ``String`s ["Deref`]"-ийг хэрэгжүүлдэг<Target=str>", ингэснээр [[str`]-ийн бүх аргыг өвлөнө үү.Нэмж дурдахад та `String`-ийг амперсанд (`&`) ашиглан [`&str`]-ийг авах функцэд дамжуулж болно гэсэн үг юм.
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Энэ нь `String`-ээс [`&str`]-ийг үүсгэж дамжуулах болно. Энэ хөрвүүлэлт нь маш хямд тул ерөнхийдөө функцууд нь тодорхой шалтгаанаар `String` шаардлагагүй бол ["&str`]-г аргумент болгон хүлээн авах болно.
///
/// Зарим тохиолдолд Rust нь [`Deref`] албадлага гэгддэг энэхүү хөрвүүлэлтийг хийхэд хангалттай мэдээлэлгүй байдаг.Дараах жишээнд [`&'a str`][`&str`] мөрт зүсмэл trait `TraitExample`-ийг хэрэгжүүлдэг бөгөөд `example_func` функц trait-ийг хэрэгжүүлдэг бүх зүйлийг авдаг.
/// Энэ тохиолдолд Rust нь хоёр далд хөрвүүлэлт хийх шаардлагатай бөгөөд үүнийг Rust хийх арга байхгүй.
/// Ийм учраас дараах жишээг эмхэтгэхгүй болно.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Үүний оронд ажиллах хоёр сонголт байна.Эхнийх нь `example_func(&example_string);` мөрийг ашиглан мөрийг агуулсан мөрний зүсмэлийг задлан гаргаж авахын тулд `example_func(&example_string);` мөрийг `example_func(example_string.as_str());` болгон өөрчлөх явдал юм.
/// Хоёрдахь арга нь `example_func(&example_string);`-ийг `example_func(&*example_string);` болгон өөрчилдөг.
/// Энэ тохиолдолд бид `String`-ийг [`str`][`&str`]-ээс салгаж, дараа нь [`str`][`&str`]-ийг буцааж [`&str`] руу шилжүүлж байна.
/// Хоёрдахь арга нь илүү утга учиртай боловч хоёулаа шууд бус хөрвүүлэлтэд найдахаас илүүтэйгээр хөрвүүлэлтийг тодорхой хийхийг хичээдэг.
///
/// # Representation
///
/// `String` нь гурван байтаас бүрдэнэ: зарим байтыг заагч, урт, багтаамж.Заагч нь өгөгдлийг хадгалахад ашигладаг дотоод буфер `String`-ийг заана.Урт нь өнөө үед буферт хадгалагдаж байгаа байтуудын тоо бөгөөд багтаамж нь байт дахь буферын хэмжээ юм.
///
/// Иймээс урт нь үргэлж багтаамжаас бага эсвэл тэнцүү байх болно.
///
/// Энэ буфер нь үргэлж овооролд хадгалагддаг.
///
/// Та эдгээрийг [`as_ptr`], [`len`], [`capacity`] аргуудаар харах боломжтой:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME vec_into_raw_parts тогтворжсон үед үүнийг шинэчлэх.
/// // String-ийн өгөгдлийг автоматаар унагахаас урьдчилан сэргийлэх
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // өгүүллэг арван ес байттай
/// assert_eq!(19, len);
///
/// // Бид ptr, len, багтаамжаас String-ийг дахин бүтээх боломжтой.
/// // Бүрэлдэхүүн хэсэг нь хүчин төгөлдөр байгаа эсэхийг баталгаажуулах үүрэгтэй тул энэ нь аюултай юм.
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Хэрэв `String` хангалттай багтаамжтай бол түүнд элемент нэмэх нь дахин хуваарилагдахгүй.Жишээлбэл, энэ програмыг авч үзье.
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Энэ нь дараахь зүйлийг гаргах болно.
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Эхэндээ бидэнд санах ой огт хуваарилагдаагүй боловч мөрөнд бэхлэгдэх үед түүний багтаамж зохих ёсоор нэмэгддэг.Хэрэв бид эхлээд зөв хүчин чадлыг хуваарилахын тулд [`with_capacity`] аргыг ашиглавал:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Бид эцэст нь өөр гаргалт хийдэг.
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Энд гогцоонд илүү их санах ой хуваарилах шаардлагагүй болно.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// `String`-ийг UTF-8 байтаас vector-ээс хөрвүүлэхэд гарч болзошгүй алдааны утга.
///
/// Энэ төрөл нь [`String`] дээрх [`from_utf8`] аргын алдааны төрөл юм.
/// Үүнийг дахин хуваарилалтаас болгоомжлохгүй байхаар зохион бүтээсэн болно: [`into_bytes`] арга нь хөрвүүлэх оролдлогод ашиглаж байсан vector байтыг буцааж өгөх болно.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`]-ийн өгсөн [`Utf8Error`] төрөл нь [`u8`] s-ийн зүсэлтийг [`&str`] болгон хөрвүүлэхэд гарч болзошгүй алдааг илэрхийлдэг.
/// Энэ утгаараа энэ нь `FromUtf8Error`-ийн аналог бөгөөд `FromUtf8Error`-ээс [`utf8_error`] аргаар авах боломжтой.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// // зарим хүчингүй байт, vector дээр
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// `String`-ийг UTF-16 байтын зүсэлтээс хөрвүүлэхэд гарч болзошгүй алдааны утга.
///
/// Энэ төрөл нь [`String`] дээрх [`from_utf16`] аргын алдааны төрөл юм.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Шинэ хоосон `String` үүсгэдэг.
    ///
    /// `String` хоосон байгаа тул эхний буферийг хуваарилахгүй.Энэ нь анхны ажиллагаа нь маш хямд гэсэн үг боловч өгөгдөл нэмж оруулахад хэт их хуваарилалт үүсгэж болзошгүй юм.
    ///
    /// Хэрэв танд `String`-д хичнээн их хэмжээний өгөгдөл багтаах талаар мэдээлэл байгаа бол дахин хуваарилалтаас урьдчилан сэргийлэхийн тулд [`with_capacity`] аргыг анхаарч үзээрэй.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Тодорхой хүчин чадалтай шинэ хоосон `String` үүсгэдэг.
    ///
    /// String`s нь өгөгдлийг хадгалах дотоод буфертай байдаг.
    /// Хүчин чадал нь тухайн буферийн урт бөгөөд [`capacity`] аргаар асууж болно.
    /// Энэ арга нь хоосон `String` үүсгэдэг боловч `capacity` байтыг багтаах анхны буфертай байдаг.
    /// Энэ нь `String`-д олон тооны өгөгдөл нэмж оруулахад шаардлагатай хуваарилалтын тоог бууруулж болзошгүй үед ашигтай юм.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Хэрэв өгөгдсөн хүчин чадал `0` бол хуваарилалт гарахгүй бөгөөд энэ арга нь [`new`] аргатай ижил байна.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // String нь илүү их багтаамжтай ч гэсэн ямар ч тэмдэг агуулаагүй болно
    /// assert_eq!(s.len(), 0);
    ///
    /// // Эдгээрийг бүгдийг нь хуваарилалгүйгээр хийдэг ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... гэхдээ энэ нь мөрийг дахин хуваарилахад хүргэж болзошгүй юм
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test)-тэй хамт энэ аргыг тодорхойлоход шаардагдах уламжлалт `[T]::to_vec` арга байхгүй байна.
    // Бид туршилтын зорилгоор энэ аргыг шаарддаггүй тул NB-ийг slice.rs дээрх slice::hack модулаас үзнэ үү.
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// vector байтыг `String` болгож хөрвүүлдэг.
    ///
    /// ([`String`]) мөрийг ([`u8`]) байт, ([`Vec<u8>`]) байтыг vector байтыг хийсэн тул энэ функц нь хоёрын хооронд хөрвүүлэгддэг.
    /// Бүх байтын зүсмэлүүд `String`s хүчинтэй биш боловч `String` нь UTF-8 хүчинтэй байхыг шаарддаг.
    /// `from_utf8()` байт хүчинтэй UTF-8 байгаа эсэхийг шалгаад хөрвүүлэлт хийдэг.
    ///
    /// Хэрэв та байтын зүсэлт UTF-8 хүчин төгөлдөр гэдэгт итгэлтэй байгаа бөгөөд хүчинтэй байдлын шалгалтын нэмэлт зардлыг төлөхийг хүсэхгүй байгаа бол [`from_utf8_unchecked`] гэсэн энэ функцын аюултай, хувилбар нь ижил ажиллагаатай боловч чекийг алгасах болно.
    ///
    ///
    /// Энэ арга нь үр ашгийн үүднээс vector-ийг хуулбарлахгүй байхад анхаарах болно.
    ///
    /// Хэрэв танд `String`-ийн оронд [`&str`] хэрэгтэй бол [`str::from_utf8`]-ийг бодоорой.
    ///
    /// Энэ аргын урвуу тал нь [`into_bytes`] юм.
    ///
    /// # Errors
    ///
    /// Хэрэв зүсэлт UTF-8 биш бол өгөгдсөн байт яагаад UTF-8 биш болохыг тайлбарласан тохиолдолд [`Err`]-ийг буцаана.Таны шилжсэн vector-ийг оруулсан болно.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// // зарим байт, vector дээр
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Эдгээр байт хүчинтэй гэдгийг бид мэддэг тул бид `unwrap()` ашиглах болно.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Буруу байт:
    ///
    /// ```
    /// // зарим хүчингүй байт, vector дээр
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Энэ алдааг ашиглан юу хийж болох талаар илүү дэлгэрэнгүйг [`FromUtf8Error`]-ийн баримтаас үзнэ үү.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Хүчин төгөлдөр бус тэмдэгтүүдийг багтаасан зүссэн байтыг мөр болгон хөрвүүлдэг.
    ///
    /// Мөрүүдийг ([`u8`]) байтаар, ([`&[u8]`][byteslice]) байтын зүсмэлийг байтаар хийсэн тул энэ функц нь хоёрын хооронд хөрвүүлэгддэг.Бүх байтын зүсмэлүүд нь мөрүүд биш, гэхдээ UTF-8 мөрүүд байх ёстой.
    /// Энэ хөрвүүлэлтийн явцад `from_utf8_lossy()` нь хүчин төгөлдөр бус UTF-8 дарааллыг [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]-ээр солих бөгөөд энэ нь дараах байдалтай байна.
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Хэрэв та байтын зүсэлт UTF-8 хүчин төгөлдөр гэдэгт итгэлтэй байгаа бөгөөд хөрвүүлэлтийн нэмэлт зардал гарахыг хүсэхгүй байгаа бол [`from_utf8_unchecked`] гэсэн энэ функцын аюултай, хувилбар нь ижил зантай боловч шалгалтыг алгасдаг.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Энэ функц нь [`Cow<'a, str>`]-ийг буцаана.Хэрэв манай байтын зүсэлт хүчингүй UTF-8 бол орлуулах тэмдэгтүүдийг оруулах хэрэгтэй бөгөөд ингэснээр мөрний хэмжээг өөрчлөх бөгөөд ингэснээр `String` шаардагдана.
    /// Гэхдээ энэ нь UTF-8 хүчин төгөлдөр болсон бол бидэнд шинэ хуваарилалт хэрэггүй болно.
    /// Энэ буцах төрөл нь бид хоёр тохиолдлыг зохицуулах боломжийг олгодог.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// // зарим байт, vector дээр
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Буруу байт:
    ///
    /// ```
    /// // зарим хүчингүй байт
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// UTF-16 кодчилсон vector `v`-ийг `String` болгон декодлоод, хэрэв `v`-д хүчингүй өгөгдөл байвал [`Err`]-г буцааж өгнө.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Энэ нь цуглуулах замаар хийгддэггүй: : <Result<_, _>> () гүйцэтгэлийн шалтгаанаар.
        // FIXME: #48994 хаагдахад функцийг дахин хялбарчилж болно.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// UTF-16 кодлогдсон `v` зүсмэлийг `String` болгон декодлож, хүчингүй өгөгдлийг [the replacement character (`U+FFFD`)][U+FFFD]-ээр солино.
    ///
    /// [`from_utf8_lossy`]-ээс [`Cow<'a, str>`]-ийг буцааж өгдөг [`from_utf8_lossy`]-ээс ялгаатай нь `String`-ийг буцааж өгдөг, учир нь UTF-16-ээс UTF-8 руу хөрвүүлэх нь санах ойн хуваарилалт шаарддаг.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// `String`-ийг түүхий эд болгон задалдаг.
    ///
    /// Түүхий заагчийг суурь өгөгдөл, мөрийн урт (байтаар), өгөгдлийн хуваарилагдсан багтаамж (байтаар) руу буцаана.
    /// Эдгээр нь [`from_raw_parts`]-ийн аргументуудтай ижил дарааллаар ижил аргументууд юм.
    ///
    /// Энэ функцийг дуудсаны дараа дуудагч нь `String`-ийн удирддаг санах ойг хариуцдаг.
    /// Үүнийг хийх цорын ганц арга зам бол түүхий заагч, урт, багтаамжийг [`from_raw_parts`] функцээр `String` болгож буцааж хөрвүүлэх явдал юм.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Урт, багтаамж, заагч зэргээс шинэ `String` үүсгэдэг.
    ///
    /// # Safety
    ///
    /// Энэ нь шалгагдаагүй хувьсагчийн тоогоор маш аюултай юм.
    ///
    /// * `buf` дээрх санах ойг өмнө нь стандарт номын сангийн ашигладаг хуваарилагчаас яг 1-тэй тэнцүү хуваарилсан байх ёстой.
    /// * `length` `capacity`-ээс бага эсвэл тэнцүү байх шаардлагатай.
    /// * `capacity` зөв утга байх шаардлагатай.
    /// * `buf` дээрх эхний `length` байт хүчинтэй UTF-8 байх шаардлагатай.
    ///
    /// Эдгээрийг зөрчих нь хуваарилагчийн дотоод өгөгдлийн бүтцийг эвдэх гэх мэт асуудал үүсгэж болзошгүй юм.
    ///
    /// `buf`-ийн өмчлөл нь `String`-д үр дүнтэй шилждэг бөгөөд ингэснээр дурын дагуу зааж өгсөн санах ойн агуулгыг хуваарилах, дахин хуваарилах эсвэл өөрчлөх боломжтой.
    /// Энэ функцийг дуудсаны дараа заагчийг өөр зүйл ашиглахгүй байхыг баталгаажуулна уу.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME vec_into_raw_parts тогтворжсон үед үүнийг шинэчлэх.
    ///     // String-ийн өгөгдлийг автоматаар унагахаас урьдчилан сэргийлэх
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// vector байтыг `String` болгож мөрөнд хүчинтэй UTF-8 агуулсан эсэхийг шалгахгүйгээр хөрвүүлдэг.
    ///
    /// Илүү дэлгэрэнгүйг [`from_utf8`] аюулгүй хувилбараас үзнэ үү.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Энэ функц нь түүнд дамжуулсан байтыг хүчинтэй UTF-8 эсэхийг шалгадаггүй тул аюултай юм.
    /// Хэрэв энэ хязгаарлалтыг зөрчвөл стандарт номын сангийн бусад хэсэг нь "String`s UTF-8 хүчинтэй гэж үздэг тул `String`-ийн future хэрэглэгчид санах ойн аюулгүй байдалд асуудал үүсгэж болзошгүй юм.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// // зарим байт, vector дээр
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String`-ийг vector байт болгон хөрвүүлдэг.
    ///
    /// Энэ нь `String`-ийг ашигладаг тул бид түүний агуулгыг хуулбарлах шаардлагагүй болно.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Бүхэл бүтэн `String` агуулсан мөрний зүсмэлийг гаргаж авна.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String`-ийг өөрчлөгдөж болох мөрийн зүсмэл болгон хөрвүүлдэг.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Өгөгдсөн мөрний зүсмэлийг энэ `String`-ийн төгсгөлд хавсаргана.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Энэ `мөрийн 'багтаамжийг байтаар буцаана.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Энэ `String`-ийн багтаамж нь уртаас дор хаяж `additional` байт байхаар баталгаажуулдаг.
    ///
    /// Байнга хуваарилахаас урьдчилан сэргийлэхийн тулд багтаамжийг `additional` байтаас ихээр нэмэгдүүлж болно.
    ///
    ///
    /// Хэрэв та энэ "at least" үйлдлийг хүсэхгүй байгаа бол [`reserve_exact`] аргыг үзнэ үү.
    ///
    /// # Panics
    ///
    /// Хэрэв шинэ хүчин чадал [`usize`]-ээс давсан бол Panics.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Энэ нь хүчин чадлыг нэмэгдүүлэхгүй байж магадгүй юм.
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s одоо 2 урт, 10 хүчин чадалтай болсон
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Бид нэмэлт 8 хүчин чадалтай болсон тул үүнийг дуудаж ...
    /// s.reserve(8);
    ///
    /// // ... үнэндээ нэмэгддэггүй.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Энэ "String"-ийн багтаамж нь уртаасаа `additional` байт илүү байхыг баталгаажуулдаг.
    ///
    /// Хэрэв та хуваарилагчаас илүү сайн мэдэхгүй бол [`reserve`] аргыг ашиглах талаар бодож үзээрэй.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Хэрэв шинэ хүчин чадал `usize`-ээс давсан бол Panics.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Энэ нь хүчин чадлыг нэмэгдүүлэхгүй байж магадгүй юм.
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s одоо 2 урт, 10 хүчин чадалтай болсон
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Бид нэмэлт 8 хүчин чадалтай болсон тул үүнийг дуудаж ...
    /// s.reserve_exact(8);
    ///
    /// // ... үнэндээ нэмэгддэггүй.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Тухайн `String`-т оруулах элементээс багагүй `additional` багтаамжийг нөөцлөхийг хичээдэг.
    /// Цуглуулга нь дахин хуваарилалтаас зайлсхийхийн тулд илүү их зай хадгалах боломжтой.
    /// `reserve` руу залгасны дараа хүчин чадал нь `self.len() + additional`-ээс их эсвэл тэнцүү байх болно.
    /// Хэрэв хүчин чадал аль хэдийн хангалттай болсон бол юу ч хийхгүй.
    ///
    /// # Errors
    ///
    /// Хэрэв хүчин чадал давсан эсвэл хуваарилагч алдаа гарсан тухай мэдээлсэн бол алдаа буцаж ирнэ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Санах ойг урьдчилан нөөцлөх, хэрэв чадахгүй бол гарах
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Одоо энэ нь бидний нарийн төвөгтэй ажлын дунд OOM чадахгүй байгааг бид мэднэ
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Тухайн `String`-д яг `additional` элемент оруулахад хамгийн бага багтаамжийг хадгалахыг хичээдэг.
    ///
    /// `reserve_exact` руу залгасны дараа хүчин чадал нь `self.len() + additional`-ээс их эсвэл тэнцүү байх болно.
    /// Хэрэв хүчин чадал аль хэдийн хангалттай бол юу ч хийхгүй.
    ///
    /// Хуваарилагч нь цуглуулгаас хүссэн хэмжээнээс илүү зай гаргаж өгч болохыг анхаарна уу.
    /// Тиймээс хүчин чадлыг яг хамгийн бага гэж найдаж болохгүй.
    /// Хэрэв future оруулах шаардлагатай бол `reserve`-г илүүд үзээрэй.
    ///
    /// # Errors
    ///
    /// Хэрэв хүчин чадал давсан эсвэл хуваарилагч алдаа гарсан тухай мэдээлсэн бол алдаа буцаж ирнэ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Санах ойг урьдчилан нөөцлөх, хэрэв чадахгүй бол гарах
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Одоо энэ нь бидний нарийн төвөгтэй ажлын дунд OOM чадахгүй байгааг бид мэднэ
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Энэхүү `String`-ийн багтаамжийг урттай нь тааруулж багасгана.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Энэхүү `String`-ийн багтаамжийг доод хязгаарлалтаар багасгадаг.
    ///
    /// Хүчин чадал нь дор хаяж урт, нийлүүлсэн утгын аль аль нь хэвээр байх болно.
    ///
    ///
    /// Хэрэв одоогийн хүчин чадал нь доод хязгаараас бага бол энэ нь татгалзах болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Өгөгдсөн [`char`]-ийг энэ `String`-ийн төгсгөлд хавсаргана.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Энэ мөрийн агуулгын байтын зүсэлтийг буцаана.
    ///
    /// Энэ аргын урвуу тал нь [`from_utf8`] юм.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Энэ `String`-ийг заасан уртаар богиносгодог.
    ///
    /// Хэрэв `new_len` нь мөрний одоогийн уртаас их байвал энэ нь ямар ч нөлөө үзүүлэхгүй.
    ///
    ///
    /// Энэ арга нь мөрний хуваарилагдсан хүчин чадалд ямар ч нөлөө үзүүлэхгүй гэдгийг анхаарна уу
    ///
    /// # Panics
    ///
    /// Хэрэв `new_len` нь [`char`] хил дээр ороогүй бол Panics.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Сүлжээний буферээс сүүлчийн тэмдэгтийг арилгаж буцаана.
    ///
    /// Хэрэв энэ `String` хоосон байвал [`None`] буцаана.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Энэ `String`-ээс байт байрлалаар [`char`]-г аваад буцааж өгнө.
    ///
    /// Энэ нь буфер дахь бүх элементийг хуулах шаардлагатай тул *O*(*n*) ажиллагаа юм.
    ///
    /// # Panics
    ///
    /// Хэрэв `idx` нь `String`-ийн уртаас их эсвэл түүнтэй тэнцүү эсвэл [`char`] заагт ороогүй бол Panics.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` загвар дахь `pat` загварын бүх тохирлыг устгана уу.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Тохиролыг давтаж илрүүлж устгана, тиймээс хээ давхацсан тохиолдолд зөвхөн эхний загварыг хасах болно.
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // АЮУЛГҮЙ БАЙДАЛ: эхлэл ба төгсгөл нь utf8 байтын хил хязгаар дээр байх болно
        // хайгч баримтууд
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Зөвхөн урьдчилсан үгээр заасан тэмдэгтүүдийг хадгална.
    ///
    /// Өөрөөр хэлбэл, `c` нь `false`-ийг буцааж өгөх бүх `c` тэмдэгтүүдийг устгана уу.
    /// Энэ арга нь үйл ажиллагаагаа явуулдаг бөгөөд дүр тус бүрт яг нэг удаа анхны дарааллаар зочилдог бөгөөд хадгалагдсан дүрүүдийн дарааллыг хадгалдаг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Яг захиалга нь гадаад байдлыг хянахад ашигтай байж болох юм.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Дараагийн char руу idx-ийг заана уу
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Энэ `String`-д тэмдэгтийг байтын байрлалд оруулна.
    ///
    /// Энэ нь буфер дахь бүх элементийг хуулах шаардлагатай тул *O*(*n*) ажиллагаа юм.
    ///
    /// # Panics
    ///
    /// Хэрэв 0Panics бол `idx` нь `String`-ийн уртаас том эсвэл [`char`] зааг дээр ороогүй бол.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Энэ `String`-д мөрний зүсмэлийг байтын байрлалд оруулна.
    ///
    /// Энэ нь буфер дахь бүх элементийг хуулах шаардлагатай тул *O*(*n*) ажиллагаа юм.
    ///
    /// # Panics
    ///
    /// Хэрэв 0Panics бол `idx` нь `String`-ийн уртаас том эсвэл [`char`] зааг дээр ороогүй бол.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Энэхүү `String`-ийн агуулгын өөрчлөгдөж болох лавлагааг буцаана.
    ///
    /// # Safety
    ///
    /// Энэ функц нь түүнд дамжуулсан байтыг хүчинтэй UTF-8 эсэхийг шалгадаггүй тул аюултай юм.
    /// Хэрэв энэ хязгаарлалтыг зөрчвөл стандарт номын сангийн бусад хэсэг нь "String`s UTF-8 хүчинтэй гэж үздэг тул `String`-ийн future хэрэглэгчид санах ойн аюулгүй байдалд асуудал үүсгэж болзошгүй юм.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Энэ `String`-ийн уртыг [`char`] s эсвэл graphemes биш байтаар илэрхийлнэ.
    /// Өөрөөр хэлбэл, хүний мөрний уртыг авч үздэг зүйл биш байж магадгүй юм.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Хэрэв энэ `String` тэгийн урттай бол `true`-ийг буцааж, харин эсрэгээр `false`-ийг буцаана.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Өгөгдсөн байтын индекс дээр мөрийг хоёр хуваана.
    ///
    /// Шинээр хуваарилагдсан `String`-ийг буцаана.
    /// `self` нь `[0, at)` байтыг, харин буцаж ирсэн `String` нь `[at, len)` байтыг агуулдаг.
    /// `at` нь UTF-8 кодын заагт байх ёстой.
    ///
    /// `self`-ийн багтаамж өөрчлөгдөхгүй гэдгийг анхаарна уу.
    ///
    /// # Panics
    ///
    /// Хэрэв `at` нь `UTF-8` кодын цэгийн хил дээр байхгүй бол эсвэл мөрийн хамгийн сүүлийн кодын цэгээс хэтэрсэн бол Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Бүх агуулгыг устгаж энэ `String`-ийг таслана.
    ///
    /// Энэ нь `String` нь тэгийн урттай гэсэн үг боловч түүний хүчин чадалд хүрэхгүй байна.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String`-ийн заасан мужийг арилгаж, арилгасан `chars`-ийг гаргадаг ус зайлуулах давталтыг бий болгодог.
    ///
    ///
    /// Note: Итераторыг дуустал хэрэглээгүй байсан ч гэсэн элементийн мужийг хасах болно.
    ///
    /// # Panics
    ///
    /// Хэрэв эхлэх цэг эсвэл төгсгөлийн цэг нь [`char`] заагт ороогүй эсвэл хязгаараас хэтэрсэн бол Panics.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Мөрнөөс until хүртэлх мужийг ав
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Бүрэн хүрээ нь мөрийг арилгадаг
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Санах ойн аюулгүй байдал
        //
        // Drain-ийн String хувилбар нь vector хувилбарын санах ойн аюулгүй байдлын асуудалгүй байна.
        // Өгөгдөл нь ердөө л энгийн байт юм.
        // Хүрээг арилгах нь Drop дээр тохиолддог тул хэрэв Drain давталт алдагдсан бол устгах боломжгүй болно.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Нэгэн зэрэг хоёр зээл авах.
        // Давталт дуустал Drop дээр &mut String-д хандах боломжгүй болно.
        let self_ptr = self as *mut _;
        // АЮУЛГҮЙ БАЙДАЛ: `slice::range` ба `is_char_boundary` нь зохих хязгаарын шалгалтыг хийдэг.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Мөр дэх заасан мужийг арилгаж, өгөгдсөн мөрөөр солино.
    /// Өгөгдсөн мөр нь мужтай ижил урттай байх шаардлагагүй.
    ///
    /// # Panics
    ///
    /// Хэрэв эхлэх цэг эсвэл төгсгөлийн цэг нь [`char`] заагт ороогүй эсвэл хязгаараас хэтэрсэн бол Panics.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Мөрөөс β хүртэл мужийг солино
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Санах ойн аюулгүй байдал
        //
        // Replace_range-д vector Splice-ийн санах ойн аюулгүй байдлын асуудал байхгүй.
        // vector хувилбарын.Өгөгдөл нь ердөө л энгийн байт юм.

        // СЭРЭМЖЛҮҮЛЭГ: Энэ хувьсагчийг дотор нь оруулах нь үндэслэлгүй (#81138) байх болно
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // СЭРЭМЖЛҮҮЛЭГ: Энэ хувьсагчийг дотор нь оруулах нь үндэслэлгүй (#81138) байх болно
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range`-ийг дахин ашиглах нь үндэслэлгүй (#81138) байх болно. Бид `range`-ийн мэдээлсэн хязгаарыг хэвээр хадгална гэж бодож байгаа боловч дуудлага хийх хооронд өрсөлдөөний хэрэгжилт өөрчлөгдөж магадгүй юм.
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Энэ `String`-ийг [`Box`]`<`[`str`] `>" болгож хөрвүүлнэ.
    ///
    /// Энэ нь илүүдэл хүчин чадлыг бууруулна.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// `String` руу хөрвүүлэхийг оролдсон [`u8`] байтын зүсмэлийг буцаана.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// // зарим хүчингүй байт, vector дээр
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` руу хөрвүүлэхийг оролдсон байтыг буцаана.
    ///
    /// Энэ аргыг хуваарилалтаас зайлсхийхийн тулд сайтар боловсруулсан болно.
    /// Энэ нь байтыг нүүлгэн шилжүүлэх явцад алдааг зарцуулах бөгөөд ингэснээр байтын хуулбарыг хийх шаардлагагүй болно.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// // зарим хүчингүй байт, vector дээр
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Хөрвүүлэлтийн алдааны талаар илүү дэлгэрэнгүй мэдээлэл авахын тулд `Utf8Error`-ийг татаж аваарай.
    ///
    /// [`std::str`]-ийн өгсөн [`Utf8Error`] төрөл нь [`u8`] s-ийн зүсэлтийг [`&str`] болгон хөрвүүлэхэд гарч болзошгүй алдааг илэрхийлдэг.
    /// Энэ утгаараа энэ нь `FromUtf8Error`-ийн аналог юм.
    /// Үүнийг ашиглах талаархи дэлгэрэнгүй мэдээллийг түүний баримт бичгээс үзнэ үү.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// // зарим хүчингүй байт, vector дээр
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // эхний байт энд буруу байна
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Бид "String`s" дээр давтаж байгаа тул давталтаас эхний мөрийг аваад дараагийн бүх мөрүүдийг нэмж оруулснаар дор хаяж нэг хуваарилалтаас зайлсхийх боломжтой.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Бид CoW-ээр давтаж байгаа тул (potentially) нь эхний зүйлийг аваад дараагийн бүх зүйлд нэмж оруулах замаар дор хаяж нэг хуваарилалтаас зайлсхийх боломжтой.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str`-ийн импл төлөөлөгчдөд тав тухтай байдал.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Хоосон `String` үүсгэдэг.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Хоёр мөрийг холбоход зориулж `+` операторыг хэрэгжүүлдэг.
///
/// Энэ нь `String`-ийг зүүн гар талд ашигладаг бөгөөд түүний буферийг дахин ашигладаг (шаардлагатай бол өсгөх).
/// Энэ нь шинэ `String` хуваарилахаас зайлсхийж, бүх үйлдэл дээрх бүх агуулгыг хуулж авахаас зайлсхийх бөгөөд ингэснээр *n*-байтын мөрийг давтаж залгах замаар ажиллуулахад *O*(*n*^ 2) ажиллах цаг болно.
///
///
/// Баруун талын мөрийг зөвхөн зээлдэг;түүний агуулгыг буцаж ирсэн `String` руу хуулна.
///
/// # Examples
///
/// Хоёр мөрийг нэгтгэх нь эхнийх нь утгаар нь авч, хоёр дахь нь зээлдэг:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` зөөсөн тул энд ашиглах боломжгүй болсон.
/// ```
///
/// Хэрэв та анхны `String`-ийг үргэлжлүүлэн ашиглахыг хүсвэл үүнийг хувилж, клонд хавсаргаж болно:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` энд хүчинтэй хэвээр байна.
/// ```
///
/// `&str` зүсмэлүүдийг нэгтгэх ажлыг эхнийхийг `String` болгон хөрвүүлэх замаар хийж болно.
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` дээр нэмэхийн тулд `+=` операторыг хэрэгжүүлдэг.
///
/// Энэ нь [`push_str`][String::push_str] аргын адил зан авиртай байдаг.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`]-т зориулсан төрөл бүрийн нэр.
///
/// Энэ нэр нь ар талдаа нийцтэй байх үүднээс байдаг бөгөөд эцэст нь хуучирсан байж магадгүй юм.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// `String` руу утгыг хөрвүүлэх trait.
///
/// Энэ trait нь [`Display`] trait-ийг хэрэгжүүлдэг бүх төрлийн хувьд автоматаар хэрэгждэг.
/// Ийм байдлаар `ToString` шууд хэрэгжих ёсгүй:
/// [`Display`] Үүний оронд хэрэгжих ёстой бөгөөд та `ToString` програмыг үнэгүй ашиглах боломжтой болно.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Өгөгдсөн утгыг `String` болгон хөрвүүлдэг.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Энэхүү хэрэгжүүлэлтэд `Display` хэрэгжилт алдаа гаргасан тохиолдолд panics аргыг ашигладаг.
/// Энэ нь буруу `Display` хэрэгжилтийг харуулж байгаа тул `fmt::Write for String` нь хэзээ ч алдаа өөрөө буцаадаггүй.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Нийтлэг удирдамж бол ерөнхий функцийг дотор нь оруулахгүй байх явдал юм.
    // Гэсэн хэдий ч `#[inline]`-ийг энэ аргаас хасах нь үл тоомсорлох регресс үүсгэдэг.
    // Үүнийг арилгахыг оролдсон сүүлийн оролдлого болох <https://github.com/rust-lang/rust/pull/74852>-ийг үзнэ үү.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str`-ийг `String` болгон хөрвүүлдэг.
    ///
    /// Үр дүн нь овоо дээр хуваарилагдана.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: тест нь libstd-ийг татаж авдаг бөгөөд энд алдаа гардаг
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Өгөгдсөн хайрцагласан `str` зүсмэлийг `String` болгож хөрвүүлдэг.
    /// `str` зүсмэлийг эзэмшдэг нь анхаарал татаж байна.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Өгөгдсөн `String`-ийг эзэмшдэг хайрцагласан `str` зүсмэл болгон хөрвүүлдэг.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Мөрний зүсмэлийг зээлсэн хувилбар болгон хөрвүүлдэг.
    /// Нуруулдан хуваарилалт хийгдээгүй бөгөөд мөрийг хуулбарлахгүй.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Мөрийг эзэмшсэн хувилбарт хөрвүүлдэг.
    /// Нуруулдан хуваарилалт хийгдээгүй бөгөөд мөрийг хуулбарлахгүй.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// String ишлэлийг Borrowed хувилбарт хөрвүүлдэг.
    /// Нуруулдан хуваарилалт хийгдээгүй бөгөөд мөрийг хуулбарлахгүй.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Өгөгдсөн `String`-ийг `u8` төрлийн утгыг агуулдаг vector `Vec` болгон хөрвүүлдэг.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String`-д зориулсан ус зайлуулах давталт.
///
/// Энэ бүтцийг [`String`] дээр [`drain`] аргаар үүсгэдэг.
/// Дэлгэрэнгүй мэдээллийг түүний баримт бичгээс үзнэ үү.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Устгагч доторх&мөрийн мөр болгон ашиглах болно
    string: *mut String,
    /// Устгах хэсгийн эхлэл
    start: usize,
    /// Хасах хэсгийн төгсгөл
    end: usize,
    /// Устгах одоогийн үлдсэн муж
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain ашиглана уу.
            // "Reaffirm" panic кодыг дахин оруулахаас зайлсхийхийн тулд хязгаарыг шалгана.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Энэ давталтын үлдсэн (дэд) мөрийг зүсмэл хэлбэрээр буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef тогтворжуулахдаа доор дурдсан болно.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str`-ийг тогтворжуулах үед тайлбар өгөхгүй байх.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain <'a> {fn as_ref(&self)-> &str {-д зориулсан
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> for Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}