# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate-ийн баримт бичгийг үзнэ үү.