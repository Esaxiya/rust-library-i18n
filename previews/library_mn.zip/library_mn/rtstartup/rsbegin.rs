// rsbegin.o ба rsend.o нь "compiler runtime startup objects" гэж нэрлэгддэг.
// Эдгээр нь хөрвүүлэгчийн ажиллах хугацааг зөв эхлүүлэхэд шаардлагатай кодыг агуулдаг.
//
// Ажиллаж болохуйц эсвэл дибилийн дүрсийг холбосон тохиолдолд хэрэглэгчийн бүх кодууд болон сангууд нь эдгээр хоёр объектын файлуудын хооронд "sandwiched" байдаг тул rsbegin.o-ийн код эсвэл өгөгдөл нь тухайн зургийн холбогдох хэсгүүдэд эхний байр эзэлдэг бол rsend.o-ийн кодууд болон өгөгдлүүд хамгийн сүүлд ордог.
// Энэ эффектийг хэсгийн эхэнд эсвэл төгсгөлд тэмдэг байрлуулах, шаардлагатай толгой ба хөлийг оруулахад ашиглаж болно.
//
// Бодит модулийн нэвтрэх цэг нь C runtime эхлүүлэх объектод байрладаг (ихэвчлэн `crtX.o` гэж нэрлэдэг) байдаг бөгөөд дараа нь бусад ажиллах хугацааны бүрэлдэхүүн хэсгүүдийн эхлүүлэх дуудлага (өөр тусгай зургийн хэсэгт бүртгэгдсэн) дууддаг.
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Стекийн хүрээ тайлах мэдээллийн хэсгийн эхлэлийг тэмдэглэнэ
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Хүсэлт гаргагчийн дотоод дэвтэр хадгалах зориулалттай зураасны орон зай.
    // Үүнийг `struct object` гэж $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // registration/deregistration горимыг салгах.
    // Libpanic_unwind-ийн баримт бичгүүдийг үзнэ үү.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // модулийг эхлүүлэх талаар задлах мэдээллийг бүртгүүлэх
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // унтраах үед бүртгэлээс хасах
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-тэй холбоотой init/uninit тогтмол бүртгэл
    pub mod mingw_init {
        // MinGW-ийн эхлүүлэх объектууд (crt0.o/dllcrt0.o) нь эхлүүлэх, гарах хэсэгт .ctors ба .dtors хэсгүүдэд дэлхийн байгуулагчдыг дуудна.
        // DLL-ийн хувьд DLL-г ачиж буулгах үед үүнийг хийдэг.
        //
        // Холбогч нь хэсгүүдийг эрэмбэлэх бөгөөд энэ нь бидний дуудлагыг жагсаалтын төгсгөлд байрлуулах болно.
        // Конструкторуудыг урвуу дарааллаар ажиллуулдаг тул энэ нь бидний дуудлагад хамгийн анхны бөгөөд хамгийн сүүлд хийгдсэн байхыг баталгаажуулдаг.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C эхлүүлэх дуудлага
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C-ийн төгсгөлийн дуудлага
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}