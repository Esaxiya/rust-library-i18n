//! Мирид зориулж panics-ийг задалж байна.
use alloc::boxed::Box;
use core::any::Any;

// Мири хөдөлгүүр нь бидний хувьд тайлах замаар тархдаг ачааны төрөл.
// Заагчийн хэмжээтэй байх ёстой.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-ээр хангагдсан extern функцийг задалж эхлэв.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Бидний `miri_start_panic`-д дамжуулж буй ачаа ачаа нь доорхи `cleanup` дээр гарах аргумент байх болно.
    // Тиймээс бид заагч хэмжээтэй зүйлийг авахын тулд үүнийг нэг удаа л хайрцагт хийдэг.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Үүний суурь `Box`-ийг сэргээнэ үү.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}