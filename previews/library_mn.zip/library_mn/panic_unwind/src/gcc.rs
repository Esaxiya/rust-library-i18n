//! libgcc/libunwind-ийн дэмжлэгтэй panics-ийн хэрэгжилт (зарим хэлбэрээр).
//!
//! Үл хамаарах зүйл, стекийг задлах талаархи мэдээллийг "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) болон түүнтэй холбоотой баримт бичгүүдийг үзнэ үү.
//! Эдгээр нь сайн уншдаг:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Товч тойм
//!
//! Үл хамаарах зүйлтэй харьцах нь хайлтын үе ба цэвэрлэх үе шат гэсэн хоёр үе шаттай явагдана.
//!
//! Хоёр шатанд хоёулаа стекийн хүрээг дээш нь доош нь чиглүүлж, одоогийн процессын модулиудын хэсгийг задлах хэсгийг ашигладаг ("module" нь OS модулийг, өөрөөр хэлбэл, гүйцэтгэгдэх боломжтой эсвэл динамик номын санг хэлнэ).
//!
//!
//! Стекийн хүрээ бүрийн хувьд энэ нь холбогдох "personality routine"-ийг дуудаж, хаягийг нь задлах мэдээллийн хэсэгт хадгалдаг.
//!
//! Хайлтын үе шатанд хувийн зан үйлийн ажил бол хаясан онцгой объектыг шалгаж, уг стекийн хүрээн дээр баригдах эсэхийг шийдэх явдал юм.Боловсруулагчийн хүрээг тодорхойлсны дараа цэвэрлэх үе шат эхэлнэ.
//!
//! Цэвэрлэгээний үе шатанд хүсээгүй хүн хувийн зан үйл бүрийг дахин дууддаг.
//! Энэ удаад одоогийн стекийн хүрээнд аль (хэрэв байгаа бол) цэвэрлэх кодыг ажиллуулах шаардлагатайг шийднэ.Хэрэв тийм бол хяналтыг функцын их бие дэх "landing pad" тусгай branch руу шилжүүлдэг бөгөөд энэ нь устгагчдыг дуудах, санах ойг суллах гэх мэт.
//! Буултын талбайн төгсгөлд хяналтыг буцааж, задлах горим руу шилжүүлдэг.
//!
//! Стекийг боловсруулагчийн хүрээний түвшинд буулгасны дараа тайлах зогсолт хийгддэг бөгөөд хувийн хэвшлийн сүүлчийн горим нь хяналтыг барих блок руу шилжүүлдэг.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust-ийн онцгой ангийн танигч.
// Үүнийг хувийн зан үйлийн дагуу ашигладаг бөгөөд үл хамаарах зүйл нь өөрсдийн ажлын цагаар хийгдсэн эсэхийг тодорхойлдог.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-үйлдвэрлэгч, хэл
    0x4d4f5a_00_52555354
}

// Бүртгэлийн дугаарыг LLVM-ийн TargetLowering::getExceptionPointerRegister() ба TargetLowering::getExceptionSelectorRegister()-ээс архитектур бүрийн хувьд өргөж, дараа нь регистрийн тодорхойлолтын хүснэгтээр дамжуулан DWARF регистрийн дугаарууд дээр буулгасан.<arch>БүртгүүлэхInfo.td, "DwarfRegNum" гэж хайна уу).
//
// Мөн http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register-г үзнэ үү.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Дараах кодыг GCC-ийн C ба C++ хувийн хэвшилд үндэслэсэн болно.Лавлагаа авахын тулд:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI хувийн зан үйл.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS SjLj задлах аргыг ашигладаг тул оронд нь анхдагч горимыг ашигладаг.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM дээрх арын бичлэгүүд нь хувийн хэвшлийг төлөв байдал==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Ийм тохиолдолд бид стекээ үргэлжлүүлэн тайлахыг хүсч байна, эс тэгвэл бидний бүх арын бичлэг __rust_try дээр дуусах болно.
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF унтраалга нь _Unwind_Context нь функц болон LSDA заагч зэрэг зүйлийг агуулдаг гэж үздэг боловч ARM EHABI нь тэдгээрийг онцгой объект болгон байрлуулдаг.
            // Зөвхөн контекст заагчийг авдаг _Unwind_GetLanguageSpecificData() гэх мэт функцүүдийн гарын үсгийг хадгалахын тулд ARM-ийн "scratch register" (r12)-д зориулж хадгалагдсан байршлыг ашиглан GCC хувийн хэвшлүүд заагчийг context_object руу хадгалдаг.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Манай libunwind холбоос дахь ARM-ийн _Unwind_Context-ийн бүрэн тодорхойлолтыг өгч, шаардлагатай өгөгдлийг DWARF нийцтэй функцуудыг тойрч тэндээс шууд авчрах нь илүү зарчимтай арга юм.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI нь онцгой объектын саад тотгор дахь SP утгыг шинэчлэх хувийн хэвшлийг шаарддаг.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // ARM EHABI дээр хувийн хэвшлийн горим нь буцаж ирэхээсээ өмнө нэг стекийн хүрээг тайлах үүрэгтэй (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc дээр тодорхойлогдсон
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Ихэнх зорилтот хэсэгт шууд ашигладаг ба SEH-ээр дамжуулан Windows x86_64 дээр шууд бус байдлаар ашигладаг хувийн зан үйлийн хэвшмэл байдал.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW зорилтот бүлэгт тайлах механизм нь SEH боловч боловсруулагчийн өгөгдөл (LSDA гэх мэт) нь GCC-тэй нийцтэй кодчиллыг ашигладаг.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Бидний ихэнх зорилгын хувийн зан үйл.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Буцах хаяг нь LSDA муж хүснэгтийн дараагийн IP мужид байж болох дуудлагын зааврын хажуугаар 1 байтыг зааж өгдөг.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Хүрээлэн задлах мэдээллийн бүртгэл
//
// Модуль бүрийн зураг нь хүрээ тайлах мэдээллийн хэсгийг агуулдаг (ихэвчлэн ".eh_frame").Модулийг процесст loaded/unloaded оруулах үед санах ойд энэ хэсгийн байршлын талаар мэдээлэл өгөх шаардлагатай.Үүнийг хэрэгжүүлэх арга нь платформоос хамаарч өөр өөр байдаг.
// Зарим (жишээлбэл, Linux) дээр дургүйцэгч нь тайлах мэдээллийн хэсгүүдийг өөрөө олох боломжтой (dl_iterate_phdr() API and finding their ".eh_frame" sections)-ээр дамжуулан ачаалагдсан модулиудыг динамикаар тоолох замаар; Бусад нь, Windows гэх мэт, тайлах мэдээллийн хэсгүүдийг тайлах API-ээр дамжуулан идэвхтэй бүртгүүлэхийг шаарддаг.
//
//
// Энэ модуль нь GCC-ийн мэдээллийг бүртгэхийн тулд rsbegin.rs-ээс лавлагаа авсан, дуудсан хоёр тэмдгийг тодорхойлдог.
// Стек задлах ажлыг (одоогоор) libgcc_eh гэж хойшлуулсан боловч Rust crates нь Rust-тэй холбоотой нэвтрэх цэгүүдийг ашиглаж, ямар ч GCC ажиллах хугацаатай зөрчилдөхөөс сэргийлнэ.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}