//! Windows SEH
//!
//! Windows дээр (одоогоор зөвхөн MSVC дээр), анхдагч үл хамаарах харьцах механизм нь Structured Exception Handling (SEH) юм.
//! Энэ нь хөрвүүлэгчийн дотоод хувьд Одой дээр суурилсан үл хамаарах зүйлтэй харьцуулбал (жишээлбэл, бусад unix платформуудыг ашигладаг) харьцангуй өөр тул LLVM нь SEH-д нэмэлт дэмжлэг үзүүлэх шаардлагатай байна.
//!
//! Товчхондоо энд юу тохиолдох вэ?
//!
//! 1. `panic` функц нь стандарт Windows функцийг `_CxxThrowException` гэж нэрлэдэг бөгөөд C++ -ийг хаяхын тулд тайлах процессыг өдөөдөг.
//! 2.
//! Хөрвүүлэгчээс үүсгэсэн бүх буух дэвсгэрүүд нь CRT-ийн функц болох `__CxxFrameHandler3` хувийн функцийг ашигладаг бөгөөд Windows дээрх задлах код нь энэхүү хувийн функцийг ашиглан стек дээрх бүх цэвэрлэх кодыг гүйцэтгэдэг.
//!
//! 3. `invoke` руу хөрвүүлэгчээс үүсгэсэн бүх дуудлага нь буух дэвсгэрийг `cleanuppad` LLVM заавар болгон тохируулсан байдаг бөгөөд энэ нь цэвэрлэх горим эхэлж байгааг илтгэнэ.
//! Хувь хүн (CRT-д тодорхойлсон 2-р алхам) нь цэвэрлэх журмыг ажиллуулах үүрэгтэй.
//! 4. Эцэст нь `try` дотоод хэл дээрх "catch" кодыг (хөрвүүлэгчээс үүсгэсэн) гүйцэтгэж, хяналт буцаж Rust руу буцах ёстойг харуулж байна.
//! Үүнийг `catchswitch` дээр нэмээд `catchpad` заавраар LLVM IR нэр томъёогоор хийж, ердийн хяналтыг `catchret` заавраар програмд буцааж өгдөг.
//!
//! gcc дээр суурилсан үл хамаарах зүйлээс зарим онцлог ялгаа нь дараах байдалтай байна.
//!
//! * Rust нь өөрчлөн тохируулсан хувийн функцгүй бөгөөд түүний оронд *үргэлж*`__CxxFrameHandler3` байдаг.Нэмж дурдахад нэмэлт шүүлтүүр хийгддэггүй тул бидний хаяж байгаа зүйл шиг санагдах C++ үл хамаарах зүйлүүдийг олж авах болно.
//! Үл хамаарах зүйлийг Rust руу хаях нь тодорхойгүй зан авир тул анхааралдаа авах хэрэгтэй гэдгийг анхаарна уу.
//! * Бид `Box<dyn Any + Send>`-ийг задлах хил хязгаарыг дамжуулах зарим өгөгдлийг авсан.Одой үл хамаарах зүйлсийн нэгэн адил эдгээр хоёр заагч нь үл хамаарах зүйлд ашиг тустай байдлаар хадгалагддаг.
//! Гэхдээ MSVC дээр шүүлтүүрийн функцуудыг гүйцэтгэж байх үед дуудлагын стек хадгалагдах тул нэмэлт овоо хуваарилах шаардлагагүй болно.
//! Энэ нь заагчдыг `_CxxThrowException` руу шууд дамжуулж, дараа нь шүүлтүүрийн функцэд сэргээж, `try` дотоод стекийн хүрээ дээр бичихийг хэлнэ.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Энэ нь сонголт байх ёстой, учир нь бид үл хамаарах зүйлийг лавлагаагаар барьж авдаг бөгөөд түүний устгагчийг C++ ажиллах хугацаанд гүйцэтгэдэг.
    // Шигтгээ нь үл хамаарах зүйлээс хасах үед бид түүнийг устгагч нь хайрцгийг давхар унагахгүйгээр ажиллуулахын тулд үл хамаарах зүйлийг хүчинтэй байдалд үлдээх хэрэгтэй.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Нэгдүгээрт, бүхэл бүтэн төрлийн тодорхойлолтууд.Энд платформд хамааралтай цөөн хэдэн сонин хачин зүйлс байгаа бөгөөд LLVM-ээс шууд хуулж авсан маш олон зүйл байна.Энэ бүхний зорилго нь `_CxxThrowException` руу залгах замаар доорх `panic` функцийг хэрэгжүүлэх явдал юм.
//
// Энэ функц нь хоёр аргумент шаарддаг.Эхнийх нь бидний дамжуулж буй өгөгдлийн заагч бөгөөд энэ тохиолдолд бидний trait объект болно.Хайхад хялбар!Дараагийнх нь илүү төвөгтэй байдаг.
// Энэ бол `_ThrowInfo` бүтцийн заагч бөгөөд ерөнхийдөө хаяж буй үл хамаарах зүйлийг л дүрслэх зорилготой юм.
//
// Одоогийн байдлаар энэ төрлийн [1]-ийн тодорхойлолт нь бага зэрэг үстэй бөгөөд гол хачин байдал нь (мөн онлайн нийтлэлээс ялгаа нь) 32 бит дээр заагч, харин 64 бит дээр заагчийг 32 битийн зөрүүгээр илэрхийлж байгаа явдал юм. `__ImageBase` тэмдэг.
//
// Үүнийг илэрхийлэхийн тулд доорх модулиуд дахь `ptr_t` ба `ptr!` макро ашиглагддаг.
//
// Төрлийн тодорхойлолтуудын төөрдөг байшин нь LLVM нь энэ төрлийн үйл ажиллагаанд юу ялгаруулж байгааг нягт нямбай дагадаг.Жишээлбэл, хэрэв та энэ C++ кодыг MSVC дээр хөрвүүлээд LLVM IR ялгаруулдаг бол:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      хүчингүй foo() { rust_panic a = {0, 1};
//          шидэх а;}
//
// Энэ бол үндсэндээ бидний дууриахыг хичээдэг зүйл юм.Доорх ихэнх тогтмол утгуудыг LLVM-ээс хуулсан болно,
//
// Ямар ч тохиолдолд эдгээр байгууламжууд бүгд ижил төстэй байдлаар баригдсан байдаг бөгөөд энэ нь бидний хувьд тодорхой утга агуулгатай юм.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Бид энд нэр солих дүрмийг санаатайгаар үл тоомсорлодог болохыг анхаарна уу: бид C++ нь зүгээр л `struct rust_panic` зарласнаар Rust panics-ийг барьж авахыг хүсэхгүй байна.
//
//
// Өөрчлөлт хийхдээ тухайн төрлийн нэрийн мөрийг `compiler/rustc_codegen_llvm/src/intrinsic.rs`-т ашигласантай яг таарч байгаа эсэхийг шалгаарай.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Энд тэргүүлэх `\x01` байт нь LLVM-д ид шидийн дохио бөгөөд `_` тэмдэгт бүхий угтвар шиг бусад аливаа зүйлийг хэрэглэхгүй байх.
    //
    //
    // Энэ тэмдэг нь C++ -ийн `std::type_info` ашигладаг vtable юм.
    // `std::type_info` төрлийн объектууд, тодорхойлогчид энэ хүснэгтэд заагчтай байна.
    // Төрөл тодорхойлогчид дээр тодорхойлсон C++ EH бүтцүүдээс иш татан доор байрлуулсан болно.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Энэ төрлийн тодорхойлогчийг зөвхөн үл хамаарах зүйл хаяхад ашигладаг.
// Баригдах хэсгийг try intrinsic зохицуулдаг бөгөөд энэ нь өөрийн TypeDescriptor үүсгэдэг.
//
// MSVC-ийн ажиллах хугацаа нь заагчийн тэгш байдал биш харин TypeDescriptors-тэй нийцүүлэхийн тулд төрлийн нэр дээрх мөрийн харьцуулалтыг ашигладаг тул энэ нь зүгээр юм.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Хэрэв C++ код нь онцгой тохиолдлыг барьж, тараахгүйгээр хаяхаар шийдсэн бол устгагчийг ашигладаг.
// Try intrinsic-ийн барих хэсэг нь үл хамаарах объектын эхний үгийг устгагч алгасахаар 0 болгож тохируулна.
//
// x86 Windows нь анхдагч "C" дуудлагын оронд C++ гишүүн функцуудад "thiscall" дуудлагын конвенцийг ашигладаг болохыг анхаарна уу.
//
// Exception_copy функц нь энд жаахан онцгой юм: үүнийг MSVC-ийн ажиллуулах цаг try/catch блок дээр дуудагддаг бөгөөд энд бидний үүсгэсэн panic нь үл хамаарах хуулбарын үр дүнд ашиглагдах болно.
//
// Үүнийг C++ ажиллах цаг нь std::exception_ptr-тэй үл хамаарах тохиолдлуудыг тэмдэглэхэд ашигладаг бөгөөд үүнийг Box ашиглах боломжгүй юм<dyn Any>клончлох боломжгүй.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException нь бүхэлдээ энэ стекийн хүрээ дээр ажилладаг тул `data`-ийг овоолго руу шилжүүлэх шаардлагагүй болно.
    // Бид энэ функцэд стек заагчийг дамжуулдаг.
    //
    // ManuallyDrop нь энд хэрэгтэй болно, учир нь бид тайлах үед Exception-ийг хасахыг хүсэхгүй байна.
    // Үүний оронд C++ ажиллах хугацааг дуудсан exception_cleanup хаягаар оруулна.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Энэ ... гайхмаар юм шиг санагдаж магадгүй юм.32 битийн MSVC дээр эдгээр бүтцийн хоорондох заагч нь яг л заагч юм.
    // Гэхдээ 64-бит MSVC дээр бүтцийн хоорондох заагчийг `__ImageBase`-ээс 32 битийн зайтай илэрхийлэх болно.
    //
    // Үүний үр дүнд 32 битийн MSVC дээр бид эдгээр бүх заагчийг дээрх "static"-д зарлаж болно.
    // 64 битийн MSVC дээр бид Rust одоогоор зөвшөөрөөгүй байгаа статик дахь заагчийг хасахыг илэрхийлэх ёстой тул бид үүнийг хийж чадахгүй.
    //
    // Дараагийн хамгийн сайн зүйл бол эдгээр бүтцийг ажлын цагаар бөглөх явдал юм (сандрах нь аль хэдийн "slow path" болсон).
    // Тиймээс бид эдгээр бүх заагч талбаруудыг 32 битийн бүхэл тоо болгон тайлбарлаж, холбогдох утгыг хадгална (panics зэрэгцэн тохиолдож магадгүй тул атомын хувьд).
    //
    // Техникийн хувьд эдгээр талбайнуудыг атомын бус унших боломжтой байх боловч онолын хувьд тэд *буруу* утгыг хэзээ ч уншихгүй тул тийм ч муу биш байх ёстой ...
    //
    // Ямар ч тохиолдолд бид илүү олон үйлдлийг статикаар илэрхийлэх хүртэл иймэрхүү зүйлийг үндсэндээ хийх хэрэгтэй (мөн бид хэзээ ч чадахгүй байж магадгүй).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Энд NULL ачаа ачих нь бид XrxX-ийн __rust_try-ээс ирсэн гэсэн үг юм.
    // Энэ нь Rust бус гадны онцгой тохиолдлыг барихад тохиолддог.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Үүнийг хөрвүүлэгч оршин тогтнохыг шаарддаг (жишээлбэл, энэ нь lang зүйл юм), гэхдээ __C_specific_handler эсвэл _except_handler3 нь үргэлж хэрэглэгддэг хувь хүний функц тул үүнийг хөрвүүлэгч хэзээ ч дууддаггүй.
//
// Эндээс энэ бол зүгээр л үр хөндүүлэх үзэгдэл юм.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}