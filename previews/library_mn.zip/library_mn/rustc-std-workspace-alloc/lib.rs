#![feature(no_core)]
#![no_core]

// Энэ crate яагаад хэрэгтэй байгааг rustc-std-ажлын талбарын цөмөөс үзнэ үү.

// Liballoc дахь хуваарилалтын модультай зөрчилдөхөөс зайлсхийхийн тулд crate-ийн нэрийг өөрчил.
extern crate alloc as foo;

pub use foo::*;