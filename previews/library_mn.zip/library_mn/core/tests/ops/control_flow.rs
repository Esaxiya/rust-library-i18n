use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Энэ нь гадаргуугийн тогтвортой байдал биш боловч LLVM нь одоогоор давуу талыг ашиглах боломжгүй байсан ч `?`-ийг хооронд нь хямд байлгахад тусалдаг.
    //
    // (Харамсалтай нь Үр дүн ба Сонголт нь хоорондоо нийцэхгүй байгаа тул ControlFlow нь хоёуланг нь тааруулах боломжгүй байна.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}