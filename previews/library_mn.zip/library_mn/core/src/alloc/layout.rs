use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Энэ функцийг нэг газарт ашигладаг бөгөөд түүний хэрэгжилтийг тоймлож болох боловч үүнийг хийх оролдлогууд rustc-ийг удаашруулсан:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Санах ойн блокийн зохион байгуулалт.
///
/// `Layout`-ийн жишээ нь санах ойн тодорхой байршлыг тодорхойлдог.
/// Та `Layout`-ийг хуваарилагчид өгөх оролт болгон бүтээх болно.
///
/// Бүх зохион байгуулалт нь холбогдох хэмжээтэй ба хоёрын зэрэгцүүлэлттэй байна.
///
/// (`GlobalAlloc` нь бүх санах ойн хүсэлтүүд тэгээс бусад хэмжээтэй байхыг шаарддаг ч гэсэн байршлыг тэгээс бусад хэмжээтэй байлгахыг шаарддаггүй гэдгийг анхаарна уу.
/// Залгагч нь ийм нөхцөл хангагдсан эсэхийг баталгаажуулах, илүү сул шаардлага бүхий тодорхой хуваарилагч ашиглах эсвэл илүү зөөлөн `Allocator` интерфэйсийг ашиглах ёстой.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // хүссэн санах ойн блокийн хэмжээ, байтаар хэмжигдэнэ.
    size_: usize,

    // хүссэн санах ойн блокыг байтаар хэмжих.
    // API нь `posix_memalign`-тэй адил шаардагддаг тул Layout байгуулагчдад тулгах нь боломжийн хязгаарлалт тул бид үүнийг үргэлж хоёрын хүчээр ажиллуулдаг.
    //
    //
    // (Гэхдээ бид ижил төстэй байдлаар "align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) шаарддаггүй
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Өгөгдсөн `size` ба `align`-ээс `Layout` бүтээх буюу дараах нөхцлүүдийн аль нэг нь хангагдаагүй тохиолдолд `LayoutError`-ийг буцаана.
    ///
    /// * `align` тэг байх ёсгүй,
    ///
    /// * `align` хоёр хүний хүч байх ёстой,
    ///
    /// * `size`, `align`-ийн хамгийн ойрын үржвэр хүртэл бөөрөнхийлөх үед халих ёсгүй (өөрөөр хэлбэл бөөрөнхий утга нь `usize::MAX`-ээс бага эсвэл тэнцүү байх ёстой).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (хоёрын хүч нь зэрэгцүүлэхийг илэрхийлнэ!=0.)

        // Бөөрөнхий хэмжээ нь:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Дээрх шугамыг!=0 гэдгийг бид дээрээс мэднэ.
        // Хэрэв нэмэх (тохируулах, 1) халихгүй бол бөөрөнхийлөх нь зөв болно.
        //
        // Үүний эсрэгээр,&-masking нь! (Align, 1) нь зөвхөн бага эрэмбийн битүүдийг хасах болно.
        // Хэрэв нийлбэртэй хамт халих тохиолдол гарвал&-mask нь халалтыг буцааж авахад хангалттай хэмжээгээр хасаж чадахгүй.
        //
        //
        // Дээрхээс харахад нийлбэрээс халих эсэхийг шалгах шаардлагатай бөгөөд хангалттай юм.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // Аюулгүй байдал: `from_size_align_unchecked`-ийн нөхцлүүд байсан
        // дээр шалгасан.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Бүх шалгалтыг алгасаж байршил үүсгэдэг.
    ///
    /// # Safety
    ///
    /// Энэ функц нь [`Layout::from_size_align`]-ээс урьдчилсан нөхцөлийг баталгаажуулаагүй тул аюултай юм.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `align` тэгээс их байхыг баталгаажуулах ёстой.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Энэ бүдүүвчийн санах ойн блокийн байт дахь хамгийн бага хэмжээ.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Энэ байршлын санах ойн блокийн хамгийн бага байцын тохируулга.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `T` төрлийн утгыг барихад тохиромжтой `Layout`-ийг барьдаг.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // АЮУЛГҮЙ БАЙДАЛ: зэрэгцүүлэлтийг Rust нь хоёр ба
        // size + align combo нь манай хаягийн орон зайд багтах баталгаатай болно.
        // Үүний үр дүнд panics кодыг хангалттай оновчтой болгоогүй бол оруулахаас зайлсхийхийн тулд шалгагдаагүй байгуулагчийг ашиглана уу.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T`-ийн арын бүтцийг хуваарилахад ашиглаж болох бичлэгийг дүрсэлсэн байрлалыг гаргадаг (энэ нь trait эсвэл зүсмэл шиг хэмжээгүй бусад хэлбэр байж болно).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // АЮУЛГҮЙ БАЙДАЛ: яагаад аюултай хувилбарыг ашиглаж байгааг `new` дээрх үндэслэлийг үзнэ үү
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T`-ийн арын бүтцийг хуваарилахад ашиглаж болох бичлэгийг дүрсэлсэн байрлалыг гаргадаг (энэ нь trait эсвэл зүсмэл шиг хэмжээгүй бусад хэлбэр байж болно).
    ///
    /// # Safety
    ///
    /// Дараахь нөхцлүүд байвал энэ функцийг дуудахад л аюулгүй байдаг.
    ///
    /// - Хэрэв `T` нь `Sized` бол энэ функцийг дуудахад үргэлж аюулгүй байдаг.
    /// - Хэрэв `T`-ийн хэмжээгүй сүүл нь:
    ///     - [slice], дараа нь зүсмэлийн сүүлний урт нь бүхэл тоо байх ёстой бөгөөд *бүх утга*(динамик сүүлний урт + статик хэмжээтэй угтвар)-ын хэмжээ `isize`-т багтах ёстой.
    ///     - [trait object], дараа нь заагчийн vtable хэсэг нь хэмжээгүй coersion-ээр олж авсан `T` төрлийн хүчин төгөлдөр vtable руу зааж өгөх ёстой бөгөөд *бүх утга*(динамик сүүлний урт + статик хэмжээтэй угтвар)-ийн хэмжээ `isize`-т багтах ёстой.
    ///
    ///     - (unstable) [extern type] бол энэ функцийг дуудахад үргэлж аюулгүй байдаг, гэхдээ extern төрлийн зохион байгуулалт нь тодорхойгүй тул panic эсвэл өөр утгыг буруу утгатай болгож магадгүй юм.
    ///     Энэ бол [`Layout::for_value`]-тэй адил extern төрлийн сүүлний талаархи зан үйл юм.
    ///     - өөр тохиолдолд энэ функцийг дуудахыг консерватив байдлаар зөвшөөрөхгүй.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // АЮУЛГҮЙ БАЙДАЛ: бид эдгээр функцын урьдчилсан нөхцөлийг дуудагч руу дамжуулдаг
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // АЮУЛГҮЙ БАЙДАЛ: яагаад аюултай хувилбарыг ашиглаж байгааг `new` дээрх үндэслэлийг үзнэ үү
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Унжсан, гэхдээ энэ Layout-т сайн нийцсэн `NonNull` үүсгэдэг.
    ///
    /// Заагчийн утга нь хүчин төгөлдөр заагчийг төлөөлж болзошгүй тул үүнийг "not yet initialized" харуулын утга болгон ашиглаж болохгүй гэсэн үг юм.
    /// Залхуугаар хуваарилдаг төрлүүд нь эхлүүлэлтийг өөр аргаар хянах ёстой.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // АЮУЛГҮЙ БАЙДАЛ: тэгшлэх нь тэг биш байх баталгаатай болно
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self`-тэй ижил бүдүүвчийн утгыг багтаах боломжтой бичлэгийг дүрсэлсэн байрлалыг бий болгодог боловч `align` (байтаар хэмжигдэх)-тэй зэрэгцүүлсэн байна.
    ///
    ///
    /// Хэрэв `self` нь тогтоосон шугамыг аль хэдийн хангаж байвал `self`-ийг буцаана.
    ///
    /// Буцааж байрлуулсан схем нь өөр тохируулгатай эсэхээс үл хамааран энэ арга нь нийт хэмжээст ямар ч дэвсгэр нэмдэггүй болохыг анхаарна уу.
    /// Өөрөөр хэлбэл, хэрэв `K` 16 хэмжээтэй бол `K.align_to(32)` нь 16 хэмжээтэй * хэвээр байх болно.
    ///
    /// Хэрэв `self.size()` ба өгөгдсөн `align`-ийн хослол нь [`Layout::from_size_align`]-д жагсаасан нөхцлийг зөрчвөл алдаа буцаана.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Дараах хаягийг `align` (байтаар хэмжсэн) хангаж байгаа эсэхийг баталгаажуулахын тулд `self`-ээс хойш оруулах ёстой дэвсгэрийн хэмжээг буцаана.
    ///
    /// жишээлбэл, хэрэв `self.size()` нь 9 бол `self.padding_needed_for(4)` нь 3-ийг буцааж өгдөг, учир нь энэ нь 4 эгнээтэй хаягийг авахад шаардагдах хамгийн бага байт байт (харгалзах санах ойн блок нь 4 эгнээтэй хаягаас эхэлдэг гэж үзвэл).
    ///
    ///
    /// Хэрэв `align` нь хоёрын хүч биш бол энэ функцын буцах утга нь утгагүй болно.
    ///
    /// Буцаагдсан утгын хэрэгсэл нь `align`-ийг бүх хуваарилагдсан санах ойн блокын эхлэлийн хаягийн тохиргооноос бага эсвэл тэнцүү байхыг шаарддаг болохыг анхаарна уу.Энэхүү хязгаарлалтыг хангах нэг арга бол `align <= self.align()`-ийг баталгаажуулах явдал юм.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Бөөрөнхий утга нь:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // дараа нь бид дүүргэлтийн ялгааг буцааж өгнө. `len_rounded_up - len`.
        //
        // Бид модульчлагдсан арифметикийг дараахь байдлаар ашигладаг.
        //
        // 1. align нь> 0 байх баталгаатай тул align, 1 нь үргэлж хүчинтэй байдаг.
        //
        // 2.
        // `len + align - 1` хамгийн ихдээ `align - 1`-ээр халих боломжтой тул `!(align - 1)` бүхий&-mask нь халих тохиолдолд `len_rounded_up` өөрөө 0 байх болно.
        //
        //    Ийнхүү буцааж хийсэн дэвсгэрийг `len`-д нэмэхэд 0 гарах бөгөөд энэ нь `align` тохируулгыг үл ялиг хангаж өгдөг.
        //
        // (Мэдээжийн хэрэг хэмжээ, дүүргэлт нь хэтэрсэн санах ойн блокуудыг хуваарилах оролдлого нь хуваарилагч ямар ч тохиолдолд алдаа гаргахад хүргэдэг.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Энэ бүдүүвчийн хэмжээг олон тооны байршлын тохируулга хүртэл бөөрөнхийлж байршлыг бий болгодог.
    ///
    ///
    /// Энэ нь `padding_needed_for`-ийн үр дүнг байршлын одоогийн хэмжээнд нэмсэнтэй тэнцэнэ.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Энэ нь халих боломжгүй юм.Байршлын инвариантаас иш татав:
        // > `size`, `align`-ийн хамгийн ойрын үржвэр хүртэл бөөрөнхийлөхөд
        // > халих ёсгүй (өөрөөр хэлбэл бөөрөнхий утга нь-ээс бага байх ёстой
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self`-ийн `n` тохиолдлуудын бичлэгийг дүрсэлсэн байршлыг бий болгож, жишээ бүрийг хүссэн хэмжээ, тохируулгатай байлгахын тулд тэдгээрийн хооронд зохих хэмжээгээр дүүргэж байрлуулна.
    /// Амжилтанд хүрвэл `(k, offs)` буцаана, энд `k` бол массивын байршил, `offs` бол массив дахь элемент бүрийн эхлэл хоорондын зай юм.
    ///
    /// Арифметик халалт дээр `LayoutError` буцаана.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Энэ нь халих боломжгүй юм.Байршлын инвариантаас иш татав:
        // > `size`, `align`-ийн хамгийн ойрын үржвэр хүртэл бөөрөнхийлөхөд
        // > халих ёсгүй (өөрөөр хэлбэл бөөрөнхий утга нь-ээс бага байх ёстой
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // АЮУЛГҮЙ БАЙДАЛ: self.align нь аль хэдийн хүчин төгөлдөр болох нь мэдэгдэж байгаа бөгөөд хуваарилалтын хэмжээ нь хүчинтэй байсан
        // аль хэдийн жийргэв.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self`-ийн бичлэгийг дүрслэн байрлуулж, `next`-ийг оруулаад, үүнд `next`-ийг зөв тохируулах шаардлагатай бүх дэвсгэрийг оруулна, гэхдээ * арын дэвсгэр байхгүй болно.
    ///
    /// C дүрсний байршлыг `repr(C)`-тэй тааруулахын тулд бүх талбаруудтай байршлыг өргөжүүлсний дараа `pad_to_align` руу залгах хэрэгтэй.
    /// (Анхдагч Rust дүрсний байршлыг `repr(Rust)`, as it is unspecified.)-тэй тааруулах арга байхгүй
    ///
    /// Үүссэн схемийн тохируулга нь `self` ба `next`-ийн хамгийн дээд хэмжээ байх болно гэдгийг анхаарна уу.
    ///
    /// `Ok((k, offset))`-ийг буцаана, энд `k` нь нэгтгэсэн бичлэгийн байршил бөгөөд `offset` нь хавсаргасан бичлэгт багтсан `next`-ийн эхлэлийн харьцангуй байршил юм (бичлэг өөрөө 0 оффисоос эхэлдэг гэж үзвэл).
    ///
    ///
    /// Арифметик халалт дээр `LayoutError` буцаана.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` бүтцийн зохион байгуулалт ба талбайн байршлыг түүний талбайн байршлаас тооцоолохын тулд:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align`-ээр дуусгахаа мартуузай!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // Энэ нь ажиллаж байгаа эсэхийг шалгаарай
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self`-ийн `n` тохиолдлуудын бичлэгийг дүрсэлсэн байршлыг бий болгодог.
    ///
    /// `repeat`-ээс ялгаатай нь `repeat_packed` нь тухайн `self`-ийн жишээг зөв тохируулсан байсан ч гэсэн `self`-ийн давтагдсан тохиолдлууд зөв уялдаатай байх баталгаа өгөхгүй гэдгийг анхаарна уу.
    /// Өөрөөр хэлбэл, хэрэв `repeat_packed`-ээр буцааж байрлуулсан схемийг массив хуваарилахад ашигладаг бол массив доторх бүх элементүүдийг зохих ёсоор нь тааруулах баталгаагүй болно.
    ///
    /// Арифметик халалт дээр `LayoutError` буцаана.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self`-ийн бичлэгийг дүрсэлсэн байршлыг бий болгож, дараа нь `next`-ийг хооронд нь нэмэлт дэвсгэргүйгээр байрлуулна.
    /// Бичигт оруулаагүй тул `next`-ийн тохируулга нь хамааралгүй бөгөөд үр дүнд нь *огт* оруулаагүй болно.
    ///
    ///
    /// Арифметик халалт дээр `LayoutError` буцаана.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]`-ийн бичлэгийг тайлбарласан байршлыг бий болгодог.
    ///
    /// Арифметик халалт дээр `LayoutError` буцаана.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` эсвэл бусад `Layout` байгуулагчид өгсөн параметрүүд нь түүний баримтжуулсан хязгаарлалтыг хангаж чадахгүй байна.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (бидэнд trait алдааны доод урсгал дахь импл хэрэгтэй болно)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}