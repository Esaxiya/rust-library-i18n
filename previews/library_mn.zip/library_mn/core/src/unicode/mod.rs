#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// `char` ба `str` аргуудын Unicode хэсгүүдэд суурилсан [Unicode](http://www.unicode.org/) хувилбар.
///
/// Юникодын шинэ хувилбарууд тогтмол гардаг бөгөөд дараа нь Юникод хамаарч стандарт номын сангийн бүх аргууд шинэчлэгддэг.
/// Тиймээс зарим `char` ба `str` аргуудын зан байдал, энэ тогтмол утга нь цаг хугацааны явцад өөрчлөгдөж байдаг.
/// Үүнийг * өөрчлөлт хийхгүй гэж үзэж байна.
///
/// Хувилбарыг дугаарлах схемийг [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) дээр тайлбарласан болно.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Liballoc-д ашиглахын тулд libstd-д дахин экспортлохгүй.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;