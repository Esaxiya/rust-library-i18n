//! Энэ бол ifmt-ийн ашигладаг дотоод модуль юм!ажиллах хугацаа.Эдгээр байгууламжууд нь форматын мөрүүдийг хугацаанаас нь өмнө хөрвүүлэх зорилгоор статик массивуудад ялгардаг.
//!
//! Эдгээр тодорхойлолтууд нь `ct` эквиваленттай төстэй боловч тэдгээрийг статик байдлаар хуваарилж болох ба ажиллах хугацаандаа бага зэрэг оновчтой болгосноороо ялгаатай.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Форматлах удирдамжийн нэг хэсэг болгон хүсэж болох тохируулга.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Агуулгыг зүүн зэрэгцүүлсэн байх ёстой гэсэн заалт.
    Left,
    /// Агуулга зөв зэрэгцсэн байх ёстойг заана.
    Right,
    /// Агуулга нь төвд зэрэгцсэн байх ёстой гэсэн заалт.
    Center,
    /// Тохируулах шаардлагагүй.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) ба [precision](https://doc.rust-lang.org/std/fmt/#precision) үзүүлэлтүүд ашигладаг.
#[derive(Copy, Clone)]
pub enum Count {
    /// Үгийн тоогоор заасан, утгыг хадгалдаг
    Is(usize),
    /// `$` ба `*` синтаксуудыг ашиглан тодорхойлсон индексийг `args` болгон хадгалдаг
    Param(usize),
    /// Тодорхойлоогүй байна
    Implied,
}