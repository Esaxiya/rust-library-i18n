/// Дуудлагын операторын өөрчлөгддөггүй хүлээн авагч хувилбар.
///
/// `Fn`-ийн тохиолдлуудыг мутацийн төлөвгүйгээр дахин дахин дуудаж болно.
///
/// *Энэ trait (`Fn`)-ийг [function pointers] (`fn`)-тэй андуурч болохгүй.*
///
/// `Fn` автоматаар хэрэгждэг бөгөөд энэ нь зөвхөн баригдсан хувьсах хэмжигдэхүүнүүдийн талаар өөрчлөгддөггүй лавлагаа авах эсвэл огт юу ч авдаггүй, мөн (safe) [function pointers] (зарим анхааруулгатай бол тэдгээрийн баримтыг үзнэ үү).
///
/// Нэмж дурдахад `Fn`-ийг хэрэгжүүлдэг `F` төрлийн хувьд `&F` нь `Fn`-ийг бас хэрэгжүүлдэг.
///
/// [`FnMut`] ба [`FnOnce`] хоёулаа `Fn`-ийн супертрайтууд тул `Fn`-ийн дурын жишээг [`FnMut`] эсвэл [`FnOnce`] хүлээгдэж буй параметр болгон ашиглаж болно.
///
/// `Fn`-ийг функцтэй ижил төстэй параметрийг хүлээн авахыг хүсч байгаа бөгөөд үүнийг мутацгүйгээр дахин дахин дуудах шаардлагатай үед (жишээлбэл, нэгэн зэрэг дуудах үед) хязгаарлалт болгон ашигла.
/// Хэрэв танд ийм хатуу шаардлага шаардлагагүй бол [`FnMut`] эсвэл [`FnOnce`]-ийг хязгаар болгон ашигла.
///
/// Энэ сэдвийн талаархи нэмэлт мэдээллийг [chapter on closures in *The Rust Programming Language*][book]-ээс үзнэ үү.
///
/// `Fn` traits-ийн тусгай синтакс (жишээлбэл
/// `Fn(usize, bool) -> usize`).Энэ талаархи техникийн дэлгэрэнгүй мэдээллийг сонирхсон хүмүүс [the relevant section in the *Rustonomicon*][nomicon]-ээс лавлаж болно.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Хаалтыг дуудаж байна
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` параметрийг ашиглах
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // Ингэснээр regex нь `&str: !FnMut`-т найдаж болно
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Дуудлагын ажиллагааг гүйцэтгэдэг.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Дуудлагын операторын өөрчлөгдөж болох хүлээн авагчийг авдаг хувилбар.
///
/// `FnMut`-ийн тохиолдлуудыг дахин дахин дуудаж болох бөгөөд мутацийг өөрчлөх боломжтой.
///
/// `FnMut` баригдсан хувьсагчууд, мөн [`Fn`]-ийг хэрэгжүүлдэг бүх төрлүүд, жишээ нь (safe) [function pointers] (`FnMut` бол [`Fn`]-ийн супер хоолой юм) тул өөрчлөгдөж болохуйц лавлагаа бүхий хаалтуудаар автоматаар хэрэгждэг.
/// Нэмж дурдахад `FnMut`-ийг хэрэгжүүлдэг `F` төрлийн хувьд `&mut F` нь `FnMut`-ийг бас хэрэгжүүлдэг.
///
/// [`FnOnce`] нь `FnMut`-ийн супер хоолой тул [`FnOnce`]-ийн хүлээгдэж буй газарт `FnMut`-ийн дурын жишээг ашиглаж болох бөгөөд [`Fn`] нь `FnMut`-ийн дэд хоолой тул `FnMut`-ийн хүлээгдэж буй газарт [`Fn`]-ийн дурын жишээг ашиглаж болно.
///
/// `FnMut`-ийг функцтэй төстэй параметрийг хүлээн авахыг хүсч байгаа бөгөөд үүнийг мутацийг өөрчлөх боломжийг олгохын зэрэгцээ үүнийг дахин дахин дуудах шаардлагатай болно.
/// Хэрэв та параметрийг мутацид оруулахыг хүсэхгүй байгаа бол [`Fn`]-ийг хязгаарлалт болгон ашигла;хэрэв та дахин дахин залгах шаардлагагүй бол [`FnOnce`] ашиглана уу.
///
/// Энэ сэдвийн талаархи нэмэлт мэдээллийг [chapter on closures in *The Rust Programming Language*][book]-ээс үзнэ үү.
///
/// `Fn` traits-ийн тусгай синтакс (жишээлбэл
/// `Fn(usize, bool) -> usize`).Энэ талаархи техникийн дэлгэрэнгүй мэдээллийг сонирхсон хүмүүс [the relevant section in the *Rustonomicon*][nomicon]-ээс лавлаж болно.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Өөрчлөлттэй барьж буй хаалтыг дуудаж байна
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` параметрийг ашиглах
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // Ингэснээр regex нь `&str: !FnMut`-т найдаж болно
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Дуудлагын ажиллагааг гүйцэтгэдэг.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Дуудлага хүлээн авах операторын хувилбар.
///
/// `FnOnce`-ийн тохиолдлуудыг дуудаж болох боловч олон удаа залгах боломжгүй байж магадгүй юм.Үүнээс болоод `FnOnce`-ийг хэрэгжүүлж байгаа нь тухайн зүйлийн талаар мэддэг цорын ганц зүйл бол үүнийг зөвхөн нэг удаа дуудаж болно.
///
/// `FnOnce` нь баригдсан хувьсагчдыг ашиглаж болох хаалтууд, мөн [`FnMut`]-ийг хэрэгжүүлдэг бүх төрлүүд, жишээлбэл, (safe) [function pointers] (`FnOnce` бол [`FnMut`]-ийн супер хоолой тул) автоматаар хэрэгждэг.
///
///
/// [`Fn`] ба [`FnMut`] хоёулаа `FnOnce`-ийн дэд зургууд тул [`Fn`] эсвэл [`FnMut`]-ийн аль ч жишээг `FnOnce` хүлээгдэж буй газарт ашиглаж болно.
///
/// `FnOnce`-ийг функц маягийн төрлийн параметрийг хүлээн авахыг хүсч байгаа үед үүнийг хязгаарлалт болгон ашигла.
/// Хэрэв та параметрийг дахин дахин дуудах шаардлагатай бол [`FnMut`]-ийг хязгаарлалт болгон ашигла;Хэрэв танд мутацийг өөрчлөхгүй байх шаардлагатай бол [`Fn`] ашиглана уу.
///
/// Энэ сэдвийн талаархи нэмэлт мэдээллийг [chapter on closures in *The Rust Programming Language*][book]-ээс үзнэ үү.
///
/// `Fn` traits-ийн тусгай синтакс (жишээлбэл
/// `Fn(usize, bool) -> usize`).Энэ талаархи техникийн дэлгэрэнгүй мэдээллийг сонирхсон хүмүүс [the relevant section in the *Rustonomicon*][nomicon]-ээс лавлаж болно.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` параметрийг ашиглах
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` баригдсан хувьсагчдыг ашигладаг тул нэгээс илүү удаа ажиллуулах боломжгүй юм.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()`-ийг дахин оролдох нь `func`-ийн хувьд `use of moved value` алдаа гаргана.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` Энэ үед дахин дуудах боломжгүй
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // Ингэснээр regex нь `&str: !FnMut`-т найдаж болно
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Дуудлагын операторыг ашигласны дараа буцах төрөл.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Дуудлагын ажиллагааг гүйцэтгэдэг.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}