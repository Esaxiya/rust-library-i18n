use crate::marker::Unsize;

/// Trait нь Pointee дээр хэмжээсийг багасгах боломжтой заагч эсвэл боодол гэдгийг харуулж байна.
///
/// Дэлгэрэнгүй мэдээллийг [DST coercion RFC][dst-coerce] ба [the nomicon entry on coercion][nomicon-coerce]-ээс үзнэ үү.
///
/// Суулгасан заагчийн төрлүүдийн хувьд `T` руу чиглүүлэгч нь `T: Unsize<U>`-ийг нимгэн заагчаас бүдүүн заагч болгон хөрвүүлбэл `U` руу чиглүүлнэ.
///
/// Захиалгат төрлүүдийн хувьд энд албадлага нь `Foo<T>`-ээс `Foo<U>`-ийг шахах замаар ажилладаг бөгөөд хэрэв `CoerceUnsized<Foo<U>> for Foo<T>` гэсэн утгатай байсан бол.
/// Хэрэв `Foo<T>` нь `T`-тэй холбоотой зөвхөн нэг фантомдатын бус талбартай бол ийм имплийг бичиж болно.
/// Хэрэв тухайн талбарын төрөл нь `Bar<T>` бол `CoerceUnsized<Bar<U>> for Bar<T>` програм заавал байх ёстой.
/// Албадлага нь `Bar<T>` талбарыг `Bar<U>`-д шахаж, `Foo<T>`-ээс үлдсэн талбаруудыг бөглөж, `Foo<U>` үүсгэх замаар ажиллана.
/// Энэ нь заагчийн талбар руу үр дүнтэй өрөмдөж, үүнийг албадах болно.
///
/// Ерөнхийдөө ухаалаг заагчийн хувьд та `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`-ийг ашиглах бөгөөд заавал `T` дээр `?Sized`-ийг холбодог.
/// `T`, `Cell<T>`, `RefCell<T>` зэрэг шууд оруулдаг боодлын төрлүүдийн хувьд та `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`-ийг шууд хэрэгжүүлж болно.
///
/// Энэ нь `Cell<Box<T>>` гэх мэт төрлийн шахалтыг ажиллуулах боломжийг олгоно.
///
/// [`Unsize`][unsize] нь заагчийн ард байвал DST-д тулгаж болох төрлийг тэмдэглэхэд ашигладаг.Үүнийг хөрвүүлэгч автоматаар хэрэгжүүлдэг.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Энэ нь арга хүлээн авагчийн төрлийг илгээх боломжтой эсэхийг шалгахын тулд объектын аюулгүй байдалд ашиглагддаг.
///
/// trait-ийн хэрэгжүүлэлтийн жишээ:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}