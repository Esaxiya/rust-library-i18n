/// `*v` гэх мэт өөрчлөгддөггүй хойшлуулах үйл ажиллагаанд ашигладаг.
///
/// Х001X `*` оператортой өөрчлөгдөхгүй нөхцөл байдалд тодорхой давтагдах үйл ажиллагаанд ашиглахаас гадна `Deref` нь хөрвүүлэгч олон тохиолдолд далд хэлбэрээр ашиглагддаг.
/// Энэ механизмыг ['`Deref` coercion'][more] гэж нэрлэдэг.
/// Хувьсах боломжтой нөхцөлд [`DerefMut`]-ийг ашигладаг.
///
/// Ухаалаг заагчдад зориулсан `Deref`-ийг хэрэгжүүлснээр ард байгаа өгөгдөлд хандах нь тохиромжтой байдаг тул `Deref`-ийг хэрэгжүүлдэг.
/// Нөгөөтэйгүүр, `Deref` ба [`DerefMut`]-ийн дүрмийг ухаалаг заагчийг багтаахын тулд тусгайлан боловсруулсан болно.
/// Ийм учраас төөрөлдөхөөс зайлсхийхийн тулд **`Deref`-ийг зөвхөн ухаалаг заагч** дээр хэрэгжүүлэх ёстой.
///
/// Үүнтэй ижил шалтгаанаар **энэ trait хэзээ ч бүтэлгүйтэх ёсгүй**.`Deref`-ийг шууд утгаар нь дуудах үед дарааллыг хасах явцад бүтэлгүйтэх нь туйлын төөрөгдөл үүсгэдэг.
///
/// # `Deref` албадлагын талаар дэлгэрэнгүй
///
/// Хэрэв `T` нь `Deref<Target = U>`-ийг хэрэгжүүлж байгаа бол `x` бол `T` төрлийн утга юм.
///
/// * Үл өөрчлөгдөх нөхцөл байдалд `*x` (`T` нь лавлагаа ч биш, түүхий заагч ч биш) нь `* Deref::deref(&x)`-тэй тэнцүү юм.
/// * `&T` төрлийн утгыг `&U` төрлийн утгад тулгана
/// * `T` `U` төрлийн бүх (immutable) аргыг далд байдлаар хэрэгжүүлдэг.
///
/// Дэлгэрэнгүй мэдээллийг [the chapter in *The Rust Programming Language*][book], мөн [the dereference operator][ref-deref-op], [method resolution], [type coercions] дээрх лавлах хэсгүүдээс авна уу.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Бүтцийг цуцлах замаар нэвтрэх боломжтой нэг талбар бүхий бүтэц.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Үр дүнгийн дараахь хэлбэр.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Үнэ цэнийг хасах.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;`-тэй адил өөрчлөгдөх боломжтой цуцлах үйл ажиллагаанд ашигладаг.
///
/// (unary) `*` операторыг өөрчлөгдөж болох нөхцөл байдалд тодорхой давтагдах үйл ажиллагаанд ашиглахаас гадна `DerefMut` нь хөрвүүлэгч олон тохиолдолд далд хэлбэрээр ашиглагддаг.
/// Энэ механизмыг ['`Deref` coercion'][more] гэж нэрлэдэг.
/// Үл өөрчлөгдөх нөхцөл байдалд [`Deref`] ашигладаг.
///
/// Ухаалаг заагчдад зориулсан `DerefMut`-ийг хэрэгжүүлснээр тэдгээрийн ард байгаа өгөгдлийг өөрчлөх нь тохиромжтой байдаг тул `DerefMut`-ийг хэрэгжүүлдэг.
/// Нөгөөтэйгүүр, [`Deref`] ба `DerefMut`-ийн дүрмийг ухаалаг заагчийг багтаахын тулд тусгайлан боловсруулсан болно.
/// Ийм учраас төөрөлдөхөөс зайлсхийхийн тулд **`DerefMut`-ийг зөвхөн ухаалаг заагч** дээр хэрэгжүүлэх ёстой.
///
/// Үүнтэй ижил шалтгаанаар **энэ trait хэзээ ч бүтэлгүйтэх ёсгүй**.`DerefMut`-ийг шууд утгаар нь дуудах үед дарааллыг хасах явцад бүтэлгүйтэх нь туйлын төөрөгдөл үүсгэдэг.
///
/// # `Deref` албадлагын талаар дэлгэрэнгүй
///
/// Хэрэв `T` нь `DerefMut<Target = U>`-ийг хэрэгжүүлж байгаа бол `x` бол `T` төрлийн утга юм.
///
/// * Хувьсах боломжтой нөхцөлд `*x` (энд `T` нь лавлагаа ч биш, түүхий заагч ч биш) нь `* DerefMut::deref_mut(&mut x)`-тэй тэнцүү байна.
/// * `&mut T` төрлийн утгыг `&mut U` төрлийн утгад тулгана
/// * `T` `U` төрлийн бүх (mutable) аргыг далд байдлаар хэрэгжүүлдэг.
///
/// Дэлгэрэнгүй мэдээллийг [the chapter in *The Rust Programming Language*][book], мөн [the dereference operator][ref-deref-op], [method resolution], [type coercions] дээрх лавлах хэсгүүдээс авна уу.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Бүтцийг цуцлах замаар өөрчлөх боломжтой нэг талбар бүхий бүтэц.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Үнэ цэнийг харилцан өөрчлөх.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Бүтцийг `arbitrary_self_types` функцгүйгээр арга хүлээн авагч болгон ашиглаж болохыг заана.
///
/// Үүнийг `Box<T>`, `Rc<T>`, `&T`, `Pin<P>` гэх мэт stdlib заагч төрлүүд хэрэгжүүлдэг.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}