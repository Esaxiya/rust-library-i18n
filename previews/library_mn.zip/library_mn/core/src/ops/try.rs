/// `?` операторын зан үйлийг өөрчлөх trait.
///
/// `Try`-ийг хэрэгжүүлж буй төрөл бол үүнийг success/failure диототомийн үүднээс үзэх каноник аргатай төрөл юм.
/// Энэ trait нь эдгээр тохиолдлын амжилтын эсвэл алдааны утгыг аль хэдийн байгаа жишээнээс гаргаж авах, мөн амжилт эсвэл бүтэлгүйтлийн утгаас шинэ жишээг үүсгэх боломжийг олгодог.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Амжилттай гэж үзэхэд энэ утгын төрөл.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Бүтэлгүй гэж үзэхэд энэ утгын төрөл.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" операторыг ашигладаг.`Ok(t)`-ийн өгөөж нь гүйцэтгэл хэвийн үргэлжлэх ёстой гэсэн үг бөгөөд `?`-ийн үр дүн нь `t` утга болно.
    /// `Err(e)`-ийн өгөөж нь гүйцэтгэл нь `catch`-ийн хамгийн гадна тал руу branch буюу функцээс буцах ёстой гэсэн үг юм.
    ///
    /// Хэрэв `Err(e)` үр дүнг буцааж өгсөн бол `e` утга нь хаалтын хамрах хүрээний буцах төрөлд "wrapped" байх болно (энэ нь өөрөө `Try`-ийг хэрэгжүүлэх ёстой).
    ///
    /// Тодруулбал, `X::from_error(From::from(e))` утгыг буцаана, энд `X` нь хаах функцын буцах төрөл юм.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Нийлмэл үр дүнг байгуулахын тулд алдааны утгыг боож боох.
    /// Жишээлбэл, `Result::Err(x)` ба `Result::from_error(x)` нь тэнцүү байна.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Нийлмэл үр дүнг бий болгохын тулд OK утгыг боож өгнө.
    /// Жишээлбэл, `Result::Ok(x)` ба `Result::from_ok(x)` нь тэнцүү байна.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}