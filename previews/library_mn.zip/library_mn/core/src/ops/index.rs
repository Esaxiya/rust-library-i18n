/// (`container[index]`) үйлдлийг өөрчлөгдөхгүй нөхцөл байдалд индексжүүлэхэд ашигладаг.
///
/// `container[index]` нь `*container.index(index)`-ийн хувьд синтаксийн элсэн чихэр боловч өөрчлөгдөхгүй үнэ цэнэ болгон ашиглахад л хангалттай.
/// Хэрэв өөрчлөгдөх утгыг хүсвэл оронд нь [`IndexMut`] ашиглана.
/// Энэ нь `value` төрлийн [`Copy`]-ийг хэрэгжүүлдэг бол `let value = v[index]` гэх мэт сайхан зүйлсийг зөвшөөрдөг.
///
/// # Examples
///
/// Дараах жишээ нь `Index`-ийг зөвхөн унших боломжтой `NucleotideCount` контейнер дээр хэрэгжүүлж, хувь хүний тооллогыг индекс синтакс ашиглан авах боломжийг олгодог.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Индексжүүлсний дараа буцаж ирсэн төрөл.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Индексжүүлэх (`container[index]`) үйлдлийг гүйцэтгэдэг.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// (`container[index]`) үйлдлийг өөрчлөгдөж болох нөхцөлд индексжүүлэхэд ашигладаг.
///
/// `container[index]` нь `*container.index_mut(index)`-д зориулсан синтаксийн сахар боловч үүнийг өөрчлөгдөж болохуйц үнэ цэнэ болгон ашиглахад л хангалттай.
/// Хэрэв өөрчлөгдөхгүй утгыг хүсвэл оронд нь [`Index`] trait-ийг ашигладаг.
/// Энэ нь `v[index] = value` гэх мэт сайхан зүйлсийг зөвшөөрдөг.
///
/// # Examples
///
/// Тус бүрийг нь өөрчлөгдөж, өөрчлөгдөөгүй байдлаар индексжүүлж болох хоёр талтай `Balance` бүтцийн маш энгийн хэрэгжилт.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Энэ тохиолдолд `balance[Side::Right]` нь `*balance.index(Side::Right)`-ийн элсэн чихэр юм, яагаад гэвэл бид үүнийг бичих бус зөвхөн* уншиж байгаа *.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Гэсэн хэдий ч, энэ тохиолдолд `balance[Side::Left]` нь `*balance.index_mut(Side::Left)`-ийн элсэн чихэр юм.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// (`container[index]`)-ийн өөрчлөгдөж болох индексжүүлэлтийг гүйцэтгэдэг.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}