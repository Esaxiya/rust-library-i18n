//! Хэт ачаалалтай операторууд.
//!
//! Эдгээр traits-ийг хэрэгжүүлэх нь тодорхой операторуудыг хэт их ачааллах боломжийг олгодог.
//!
//! Эдгээр traits-ийн заримыг prelude импортлодог тул Rust програм бүрт ашиглах боломжтой.Зөвхөн traits-ээр дэмжигдсэн операторуудыг хэт ачаалах боломжтой.
//! Жишээлбэл, (`+`) нэмэх операторыг [`Add`] trait-ээр дамжуулан хэт ачаалах боломжтой боловч (`=`) даалгаврын оператор trait-ийн ар талгүй тул семантикийг нь хэт ачаалах арга байхгүй.
//! Нэмж дурдахад энэхүү модуль нь шинэ оператор үүсгэх механизмыг хангаж өгдөггүй.
//! Хэрэв шинж чанаргүй хэт ачаалал эсвэл өөрчлөн тохируулсан операторууд шаардлагатай бол та Rust-ийн синтаксийг өргөжүүлэхийн тулд макро эсвэл хөрвүүлэгч залгаасуудыг харах хэрэгтэй.
//!
//! traits операторын хэрэгжилт нь ердийн утга болон [operator precedence]-ийг санаж, тухайн нөхцөл байдалд гайхах зүйлгүй байх ёстой.
//! Жишээлбэл, [`Mul`]-ийг хэрэгжүүлэхдээ үйл ажиллагаа нь үржүүлэхтэй ижил төстэй байх ёстой (мөн ассоциатив гэх мэт хүлээгдэж буй шинж чанаруудыг хуваалцах).
//!
//! `&&` ба `||` операторууд богино холболттой, өөрөөр хэлбэл, үр дүнд нь хувь нэмэр оруулсан тохиолдолд л хоёр дахь операндаа үнэлдэг болохыг анхаарна уу.Энэ зан үйлийг traits хэрэгжүүлдэггүй тул `&&` ба `||` нь хэт ачаалалтай операторын хувьд дэмжигддэггүй.
//!
//! Олон операторууд өөрсдийн операндыг үнэ цэнээр нь авч үздэг.Суурилуулсан төрлийг агуулсан ерөнхий бус нөхцөлд энэ нь ихэвчлэн асуудал үүсгэдэггүй.
//! Гэсэн хэдий ч эдгээр операторуудыг ерөнхий кодод ашиглах нь операторуудыг ашиглахыг зөвшөөрөхийн оронд утгыг дахин ашиглах шаардлагатай бол зарим анхаарлыг шаарддаг.Нэг сонголт бол үе үе [`clone`] ашиглах явдал юм.
//! Өөр нэг хувилбар бол лавлагаа авахад нэмэлт операторын хэрэгжилтийг хангаж буй төрлүүдэд найдах явдал юм.
//! Жишээлбэл, нэмэлтийг дэмжих ёстой хэрэглэгчийн тодорхойлсон `T` төрлийн хувьд `T` ба `&T` хоёулаа traits [`Add<T>`][`Add`] ба [`Add<&T>`][`Add`]-ийг хэрэгжүүлэх нь зүйтэй бөгөөд ингэснээр ерөнхий кодыг шаардлагагүй клончлолгүйгээр бичиж болно.
//!
//!
//! # Examples
//!
//! Энэ жишээ нь [`Add`] ба [`Sub`]-ийг хэрэгжүүлдэг `Point` бүтцийг бий болгож, дараа нь хоёр цэгийг нэмж хасахыг харуулдаг.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Жишээ хэрэгжүүлэх талаар trait тус бүрийн баримт бичгийг үзнэ үү.
//!
//! [`Fn`], [`FnMut`], [`FnOnce`] traits нь функцууд шиг дуудагдах төрлөөр хэрэгждэг.[`Fn`] нь `&self`, [`FnMut`] нь `&mut self`, [`FnOnce`] нь `self` авдаг болохыг анхаарна уу.
//! Эдгээр нь жишээн дээр дуудаж болох гурван төрлийн аргатай тохирч байна: лавлагаагаар дуудах, дуудаж өөрчлөгдөж болохуйц лавлагаа, дуудлага-утга.
//! Эдгээр traits-ийн хамгийн түгээмэл хэрэглээ бол функцууд эсвэл хаалтыг аргумент болгон ашигладаг дээд түвшний функцүүдийн хязгаарлалт юм.
//!
//! [`Fn`]-ийг параметр болгон авах:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`]-ийг параметр болгон авах:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`]-ийг параметр болгон авах:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` баригдсан хувьсагчдыг ашигладаг тул нэгээс илүү удаа ажиллуулах боломжгүй юм
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()`-ийг дахин оролдох нь `func`-ийн хувьд `use of moved value` алдаа гаргана
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` Энэ үед дахин дуудах боломжгүй
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;