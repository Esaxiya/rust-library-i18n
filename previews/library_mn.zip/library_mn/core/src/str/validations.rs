//! UTF-8 баталгаажуулалттай холбоотой үйлдлүүд.

use crate::mem;

use super::Utf8Error;

/// Эхний байтын анхны код цэгийн аккумляторыг буцаана.
/// Эхний байт нь онцгой бөгөөд зөвхөн доод талын 5 битийг 2-р өргөн, 4 битийг 3-аас, 4-ийн өргөнөөс 3 битийг хүснэ.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// Үргэлжилсэн байт `byte`-ээр шинэчлэгдсэн `ch`-ийн утгыг буцаана.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// Байт нь UTF-8 үргэлжлэх байт мөн эсэхийг шалгана (өөрөөр хэлбэл `10` битүүдээс эхэлнэ).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// Байтын давталтаас гарч буй дараагийн кодыг уншина (UTF-8 төстэй кодчиллыг тооцвол).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // UTF-8 декодчилох
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // Multibayte case нь Decode-ийг байтын хослолоос дагана: [[[x y] z] w]
    //
    // NOTE: Гүйцэтгэл нь энд байгаа томъёололд нарийн мэдрэмжтэй байдаг
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] хэрэг
        // 0xE0 дахь 5-р бит .. 0xEF үргэлж тодорхой байдаг тул `init` хүчин төгөлдөр хэвээр байна
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] тохиолдолд зөвхөн `init`-ийн доод 3 битийг ашиглана уу
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// Байтын давталтаас гарч буй сүүлчийн кодыг уншина (UTF-8 төстэй кодчиллыг тооцвол).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // UTF-8 декодчилох
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // Multibayte case нь Decode-ийг байтын хослолоос дагана. [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// u64-ийг usize-д тохируулахын тулд таслалтыг ашигла
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// `x` гэсэн үгний байт нь nonascii (>=128) байвал `true` буцаана.
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// Энэ нь хүчинтэй UTF-8 дараалал байгаа эсэхийг шалгаж, энэ тохиолдолд `Ok(())`-ийг буцааж өгөх эсвэл хэрэв хүчингүй бол `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // бидэнд өгөгдөл хэрэгтэй байсан, гэхдээ нэг ч байхгүй: алдаа!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2 байтын кодчилол нь эхний C2 80 сүүлчийн DF BF кодын цэгүүдэд зориулагдсан\u {0080}-\u {07ff}
            // 3 байт кодчилол нь кодлогч цэгүүд\u {0800}-\u {ffff} эхний E0 A0 80 сүүлчийн EF BF BF орлуулагч кодоо оруулалгүйгээр\u {d800}-\u {dfff} ED A0 80-ED BF BF
            // 4 байт кодчилол нь кодын цэгүүдэд зориулагдсан\u {1000} 0-\u {10ff} ff эхний F0 90 80 80 сүүлийн F4 8F BF BF
            //
            // RFC-ээс UTF-8 синтаксийг ашиглана уу
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-сүүл UTF8-3= %xE0% xA0-BF UTF8-сүүл/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-сүүл/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii тохиолдолд хурдан урагш алгасахыг хичээ.
            // Заагчийг зэрэгцүүлэх үед ascii байт агуулаагүй үг олох хүртэл давталт бүрт 2 үг өгөгдлийг уншина уу.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // Аюулгүй байдал: `align - index` ба `ascii_block_size` нь байдаг
                    // `usize_bytes`, `block = ptr.add(index)`-ийн үржвэрүүд үргэлж `usize`-тэй нийцдэг тул `block` ба `block.offset(1)`-ийн аль алиныг нь хасах нь аюулгүй юм.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // nonascii байт байгаа бол завсарлага
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // үгийн дагуу давталт зогссон цэгээс алхам
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// Эхний байтыг өгөөд энэ UTF-8 тэмдэгтэд хэдэн байт байгааг тодорхойлно уу.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// Үргэлжлэх байтын утгын битүүдийн маск.
const CONT_MASK: u8 = 0b0011_1111;
/// Үргэлжлүүлэх байтын тэмдэглэгээний битийн утга (тагны маск нь !CONT_MASK).
const TAG_CONT_U8: u8 = 0b1000_0000;

// хэрвээ `&str`-ийг хамгийн ихдээ `max`-тэй тэнцүү бол таславал `true`-ийг буцааж, шинэ str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}