//! Байт зүсмэлээс `str` үүсгэх арга замууд.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Зүссэн байтыг мөрний зүсэм болгон хөрвүүлдэг.
///
/// ([`&str`]) тэмдэгт мөрийг ([`u8`]) байтаар, ([`&[u8]`][byteslice]) байтын зүсэлтийг байтаар хийсэн тул энэ функц нь хоёрын хооронд хөрвүүлэгддэг.
/// Бүх байтын зүсмэлүүд мөрийн зүсмэлүүд биш боловч [`&str`] нь UTF-8 хүчинтэй байхыг шаарддаг.
/// `from_utf8()` байт хүчинтэй UTF-8 байгаа эсэхийг шалгаад хөрвүүлэлт хийдэг.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Хэрэв та байтын зүсэлт UTF-8 хүчин төгөлдөр гэдэгт итгэлтэй байгаа бөгөөд хүчинтэй байдлын шалгалтын нэмэлт зардлыг төлөхийг хүсэхгүй байгаа бол [`from_utf8_unchecked`] гэсэн энэ функцын аюултай, хувилбар нь ижил ажиллагаатай боловч чекийг алгасах болно.
///
///
/// Хэрэв танд `&str`-ийн оронд `String` хэрэгтэй бол [`String::from_utf8`][string]-ийг бодоорой.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Та `[u8; N]`-ийг стекээр хуваарилах боломжтой бөгөөд [`&[u8]`][byteslice]-ийг авах боломжтой тул энэ функц нь стекээр хуваарилагдсан мөртэй болох нэг арга юм.Үүний жишээг доорх жишээний хэсэгт оруулсан болно.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Хэрэв зүсмэл яагаад UTF-8 биш болохыг тайлбарласан хэрчмээр UTF-8 биш бол `Err`-ийг буцаана.
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// use std::str;
///
/// // зарим байт, vector дээр
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Эдгээр байтууд хүчин төгөлдөр болохыг бид мэддэг тул зөвхөн `unwrap()` ашиглана уу.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Буруу байт:
///
/// ```
/// use std::str;
///
/// // зарим хүчингүй байт, vector дээр
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Буцаах боломжтой алдааны талаархи дэлгэрэнгүй мэдээллийг [`Utf8Error`]-ийн баримтаас үзнэ үү.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // стекээр хуваарилагдсан массив дахь зарим байт
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Эдгээр байтууд хүчин төгөлдөр болохыг бид мэддэг тул зөвхөн `unwrap()` ашиглана уу.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // АЮУЛГҮЙ БАЙДАЛ: Баталгаажуулалтыг ажиллуулав
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Байтын өөрчлөгдөж болох зүсмэлийг өөрчлөгдөж болох мөрийн зүсэлт болгон хөрвүүлдэг.
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" өөрчлөгдөж болох vector байдлаар
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Эдгээр байт хүчинтэй болохыг бид мэдэж байгаа тул `unwrap()` ашиглаж болно
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Буруу байт:
///
/// ```
/// use std::str;
///
/// // Хувьсах боломжтой vector дахь зарим буруу байт
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Буцаах боломжтой алдааны талаархи дэлгэрэнгүй мэдээллийг [`Utf8Error`]-ийн баримтаас үзнэ үү.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // АЮУЛГҮЙ БАЙДАЛ: Баталгаажуулалтыг ажиллуулав
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Мөр нь хүчинтэй UTF-8 агуулсан эсэхийг шалгахгүйгээр байтын зүсмэлийг мөрний зүсэлт болгон хөрвүүлдэг.
///
/// Дэлгэрэнгүй мэдээллийг [`from_utf8`] аюулгүй хувилбараас авна уу.
///
/// # Safety
///
/// Энэ функц нь түүнд дамжуулсан байтыг хүчинтэй UTF-8 эсэхийг шалгадаггүй тул аюултай юм.
/// Хэрэв энэ хязгаарлалтыг зөрчвөл Rust-ийн үлдсэн хэсэг нь [`&str`] 'ийг хүчинтэй UTF-8 гэж үздэг тул тодорхойгүй зан үйлийн үр дүн гарна.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// use std::str;
///
/// // зарим байт, vector дээр
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `v` байтыг UTF-8 хүчинтэй гэдгийг баталгаажуулах ёстой.
    // Мөн `&str` ба `&[u8]`-т ижил байршилтай байдаг.
    unsafe { mem::transmute(v) }
}

/// Мөр нь хүчинтэй UTF-8 агуулсан эсэхийг шалгахгүйгээр байтын зүсмэлийг мөрний зүсэлт болгон хөрвүүлдэг;өөрчлөгдөж болох хувилбар.
///
///
/// Дэлгэрэнгүй мэдээллийг өөрчлөгдөхгүй хувилбар [`from_utf8_unchecked()`]-с үзнэ үү.
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь байт `v` гэдгийг баталгаажуулах ёстой
    // хүчинтэй UTF-8 тул `*mut str` руу дамжуулах нь аюулгүй юм.
    // Мөн заагчийг хасах нь аюулгүй бөгөөд учир нь тухайн заагч нь бичихэд хүчинтэй байх баталгаатай лавлагаанаас ирдэг.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}