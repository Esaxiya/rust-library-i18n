//! Энэ модуль нь `Any` trait-ийг хэрэгжүүлдэг бөгөөд ингэснээр `'static` төрлийн аливаа зүйлийг динамикаар бичих боломжийг ажлын цагаар тусгадаг.
//!
//! `Any` өөрөө `TypeId` авахад ашиглаж болох бөгөөд trait объект болгон ашиглахад илүү олон онцлог шинж чанартай байдаг.
//! `&dyn Any` (зээлсэн trait объект) тул `is` ба `downcast_ref` аргуудтай бөгөөд агуулагдах утга нь өгөгдсөн төрөлд байгаа эсэхийг шалгаж, дотоод утгын төрлийг лавлагаа хэлбэрээр авна.
//! `&mut dyn Any`-ийн хувьд дотоод утгыг өөрчлөх боломжтой лавлагаа авах `downcast_mut` арга бас байдаг.
//! `Box<dyn Any>` нь `Box<T>` руу хөрвүүлэх оролдлого хийдэг `downcast` аргыг нэмдэг.
//! Бүх дэлгэрэнгүй мэдээллийг [`Box`] баримт бичгээс үзнэ үү.
//!
//! `&dyn Any` нь утга нь тогтоосон бетоны төрөл эсэхийг шалгахад хязгаарлагддаг бөгөөд trait хэлбэрийг хэрэгжүүлж байгаа эсэхийг шалгахад ашиглах боломжгүй гэдгийг анхаарна уу.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Ухаалаг заагч ба `dyn Any`
//!
//! `Any`-ийг trait объект болгон ашиглахдаа, ялангуяа `Box<dyn Any>` эсвэл `Arc<dyn Any>` гэх мэт төрлүүдийг ашиглахдаа анхаарах нэг зан үйл бол `.type_id()`-ийг утгаар нь дуудахад trait объект биш харин *контейнер*-ийн `TypeId` гарах болно.
//!
//! Үүний оронд ухаалаг заагчийг `&dyn Any` болгож хөрвүүлснээр объектын `TypeId`-ийг буцааж өгөх болно.
//! Жишээлбэл:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Та үүнийг хүсэх магадлал өндөр байна:
//! let actual_id = (&*boxed).type_id();
//! // ... үүнээс:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Функцэд шилжүүлсэн утгыг гаргахыг хүсч буй нөхцөл байдлыг авч үзье.
//! Бид Debug програмыг хэрэгжүүлж байгаа талаархи үнэ цэнийг мэддэг боловч түүний бетоны төрлийг мэддэггүй.Бид тодорхой төрлүүдэд тусгай эмчилгээ хийхийг хүсч байна.Энэ тохиолдолд String-ийн утгыг тэдгээрийн утгын өмнө хэвлэх болно.
//! Бид хөрвүүлэх үед өөрийн үнэ цэнийн бетоны төрлийг мэдэхгүй тул оронд нь ажиллах цагийн тусгалыг ашиглах хэрэгтэй.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Debug-ийг хэрэгжүүлдэг дурын төрөлд зориулсан Logger функц.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Бидний үнэ цэнийг `String` болгож хөрвүүлэхийг хичээ.
//!     // Хэрэв амжилттай болбол бид String`-ийн уртыг мөн түүний утгыг гаргахыг хүсч байна.
//!     // Хэрэв үгүй бол энэ нь өөр хэлбэр юм: зүгээр л чимэглэлгүй хэвлэ.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Энэ функц нь түүнтэй ажиллахаасаа өмнө параметрээ нэвтрэхийг хүсдэг.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... өөр ажил хийх
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Аливаа trait
///////////////////////////////////////////////////////////////////////////////

/// Динамик бичихийг дууриах trait.
///
/// Ихэнх төрлүүд `Any`-ийг хэрэгжүүлдэг.Гэсэн хэдий ч, "статик" бус лавлагаа агуулсан ямар ч төрөлд хамаарахгүй.
/// Дэлгэрэнгүй мэдээллийг [module-level documentation][mod]-с үзнэ үү.
///
/// [mod]: crate::any
// Энэ trait нь аюултай биш боловч аюулгүй кодонд (жишээ нь, `downcast`) цорын ганц имплийн `type_id` функцын онцлогт тулгуурладаг.Ихэнхдээ энэ нь асуудалтай байх болно, гэхдээ `Any`-ийн цорын ганц утга нь хөнжлийн хэрэгжилт тул өөр ямар ч код `Any`-ийг хэрэгжүүлж чадахгүй.
//
// Бид энэхүү trait-ийг аюултай болгож болох юм. Энэ нь эвдрэл үүсгэхгүй, учир нь бид бүх хэрэгжилтийг хянадаг-гэхдээ энэ нь хоёулаа тийм ч чухал биш тул хэрэглэгчдийг аюултай traits болон аюултай аргуудыг (өөрөөр хэлбэл, `type_id` нь залгахад аюулгүй хэвээр байх болно, гэхдээ бид баримт бичигт үүнийг зааж өгөхийг хүсч магадгүй юм).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self`-ийн `TypeId`-ийг авдаг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Аливаа trait объектын өргөтгөлийн аргууд.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Жишээлбэл, утсыг холбох үр дүнг хэвлэж, `unwrap`-тэй ашиглаж болно гэдгийг баталгаажуул.
// Хэрэв диспетчерийн ажил нь шинэчлэлттэй ажилладаг бол эцэст нь шаардлагагүй болж магадгүй юм.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Хайрцагласан төрөл нь `T`-тэй ижил байвал `true`-ийг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Энэ функцийг бий болгосон төрлийн `TypeId`-ийг аваарай.
        let t = TypeId::of::<T>();

        // `TypeId` объектыг trait (`self`) дээр аваарай.
        let concrete = self.type_id();

        // Тэгш байдлын талаар "TypeId" хоёуланг нь харьцуул.
        t == concrete
    }

    /// Хайрцаглагдсан утга нь `T` төрлийн, эсвэл тийм биш бол `None` гэсэн утгыг буцаана.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // АЮУЛГҮЙ БАЙДАЛ: бид зөв төрлийг зааж байгаа эсэхээ шалгаад л итгэж болно
            // Бүх төрлийн Any програмыг хэрэгжүүлсэн тул санах ойн аюулгүй байдлыг шалгах;бидний имплтэй зөрчилдөх шиг өөр импл байхгүй болно.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Хайрцаглагдсан утгын зарим өөрчлөгдөж болох лавлагааг `T` төрлийн, эсвэл тийм биш бол `None` буцаана.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // АЮУЛГҮЙ БАЙДАЛ: бид зөв төрлийг зааж байгаа эсэхээ шалгаад л итгэж болно
            // Бүх төрлийн Any програмыг хэрэгжүүлсэн тул санах ойн аюулгүй байдлыг шалгах;бидний имплтэй зөрчилдөх шиг өөр импл байхгүй болно.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` төрөлд тодорхойлсон аргыг дамжуулна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` төрөлд тодорхойлсон аргыг дамжуулна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` төрөлд тодорхойлсон аргыг дамжуулна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` төрөлд тодорхойлсон аргыг дамжуулна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` төрөлд тодорхойлсон аргыг дамжуулна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` төрөлд тодорхойлсон аргыг дамжуулна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ба түүний аргууд
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` нь дэлхийн хэмжээнд өвөрмөц танигчийг илэрхийлдэг.
///
/// `TypeId` бүр нь тунгалаг бус объект бөгөөд дотор нь байгаа зүйлийг шалгахыг зөвшөөрдөггүй боловч клончлох, харьцуулах, хэвлэх, харуулах зэрэг үндсэн үйл ажиллагааг зөвшөөрдөг.
///
///
/// `TypeId` нь одоогоор зөвхөн `'static`-т хамаарах төрлүүдэд боломжтой боловч энэ хязгаарлалтыг future дээр арилгаж болно.
///
/// `TypeId` нь `Hash`, `PartialOrd`, `Ord`-ийг хэрэгжүүлж байгаа боловч хэш болон захиалга нь Rust хувилбаруудын хооронд харилцан адилгүй байгааг тэмдэглэх нь зүйтэй.
/// Кодынхоо дотор тэдгээрт найдахаас болгоомжил!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Энэхүү ерөнхий функцэд суурилуулсан `TypeId` төрлийг буцаана.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Нэг төрлийн нэрийг мөрний зүсмэл болгон буцаана.
///
/// # Note
///
/// Энэ нь оношлогоонд ашиглахад зориулагдсан болно.
/// Өгөгдсөн мөрийн агуулга, форматыг тодорхой заагаагүй бөгөөд энэ нь тухайн төрлийн хамгийн сайн хүчин чармайлт бүхий тайлбар юм.
/// Жишээлбэл, `type_name::<Option<String>>()`-ийн буцаж ирэх мөрүүдийн дунд `"Option<String>"` ба `"std::option::Option<std::string::String>"` байна.
///
///
/// Буцаасан мөрийг тухайн төрлийн өвөрмөц танигч гэж үзэж болохгүй, учир нь олон төрлүүд ижил төрлийн нэр дээр таарч болно.
/// Үүнтэй адилаар бүх төрлийн хэсгүүд буцаж ирсэн мөрөнд гарч ирэх баталгаа байхгүй: жишээлбэл, насан туршийн тодорхойлогчид одоогоор ороогүй байна.
/// Нэмж дурдахад хөрвүүлэгчийн хувилбаруудын хооронд гаралт өөрчлөгдөж магадгүй юм.
///
/// Одоогийн хэрэгжүүлэлт нь хөрвүүлэгч оношлогоо, debuginfo-тэй ижил дэд бүтцийг ашиглаж байгаа боловч энэ нь баталгаагүй болно.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Мөрний зүсмэл хэлбэрээр зааж өгсөн утгын төрлийг буцаана.
/// Энэ нь `type_name::<T>()`-тэй адил боловч хувьсагчийн төрөл нь тийм ч хялбар байдаггүй тохиолдолд ашиглаж болно.
///
/// # Note
///
/// Энэ нь оношлогоонд ашиглахад зориулагдсан болно.Мөрний яг агуулга, форматыг заагаагүй бөгөөд энэ нь тухайн төрлийн хамгийн сайн хүчин чармайлт бүхий тайлбар юм.
/// Жишээлбэл, `type_name_of_val::<Option<String>>(None)` нь `"Option<String>"` эсвэл `"std::option::Option<std::string::String>"`-ийг буцааж өгч болох боловч `"foobar"` биш юм.
///
/// Нэмж дурдахад хөрвүүлэгчийн хувилбаруудын хооронд гаралт өөрчлөгдөж магадгүй юм.
///
/// Энэ функц нь trait объектыг шийддэггүй тул `type_name_of_val(&7u32 as &dyn Debug)` нь `"dyn Debug"`-ийг буцааж болох боловч `"u32"` биш юм.
///
/// Төрлийн нэрийг тухайн төрлийн өвөрмөц танигч гэж үзэж болохгүй;
/// олон төрлүүд ижил төрлийн нэрийг хуваалцаж болно.
///
/// Одоогийн хэрэгжүүлэлт нь хөрвүүлэгч оношлогоо, debuginfo-тэй ижил дэд бүтцийг ашиглаж байгаа боловч энэ нь баталгаагүй болно.
///
/// # Examples
///
/// Анхдагч бүхэл тоо болон хөвөх төрлийг хэвлэнэ.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}