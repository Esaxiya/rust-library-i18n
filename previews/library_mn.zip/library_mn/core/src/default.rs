//! Анхдагч утгатай утга агуулж болох төрлүүдийн хувьд `Default` trait.

#![stable(feature = "rust1", since = "1.0.0")]

/// Төрөлд өгөгдсөн анхдагч утгыг өгөх trait.
///
/// Заримдаа та ямар нэгэн анхдагч утгыг буцааж авахыг хүсдэг бөгөөд энэ нь юу болохыг огтхон ч анхаардаггүй.
/// Энэ нь олон тохиргоог тодорхойлдог "struct`s"-тэй хамт ирдэг.
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Анхдагч утгыг хэрхэн тодорхойлох вэ?Та `Default` ашиглаж болно:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Одоо та анхдагч утгуудыг бүгдийг нь авах болно.Rust нь `Default`-ийг янз бүрийн командлалд ашигладаг.
///
/// Хэрэв та тодорхой нэг сонголтыг хүчингүй болгохыг хүсч байгаа боловч бусад тохиргоог хэвээр хадгалсаар байвал:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// Бүх төрлийн талбарууд `Default`-ийг хэрэгжүүлдэг бол энэ trait-ийг `#[derive]`-тэй ашиглаж болно.
/// `Derive`d үед талбарын төрөл бүрийн анхдагч утгыг ашиглана.
///
/// ## Би `Default`-ийг хэрхэн хэрэгжүүлэх вэ?
///
/// Анхдагч байх ёстой таны төрлийг буцаах `default()` аргын хэрэгжилтийг хангаж өгнө үү.
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// "default value" төрлийг буцаана.
    ///
    /// Анхдагч утга нь ихэнхдээ анхдагч утга, таних утга эсвэл анхдагч утга учиртай байж болох бусад зүйлийг хэлдэг.
    ///
    ///
    /// # Examples
    ///
    /// Суурилуулсан анхдагч утгуудыг ашиглах:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Өөрийгөө хийх:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait-ийн дагуу нэг төрлийн анхдагч утгыг буцаана уу.
///
/// Буцаах төрлийг контекстээс дүгнэдэг;Энэ нь `Default::default()`-тэй тэнцэх боловч бичихэд богино байна.
///
/// Жишээлбэл:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default`-ийн импл үүсгэх макро гаргаж авах.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }