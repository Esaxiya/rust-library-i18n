//! Хэт их утгагүй аргууд болж хувирдаг bignums-ийн хэрэгслийн функцууд.

// FIXME Энэ модулийн нэр жаахан харамсалтай байна, яагаад гэвэл бусад модулиуд `core::num` импортолдог.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// `ones_place`-ээс бага ач холбогдол бүхий бүх битүүдийг таслах нь харьцангуй алдааг 0.5 ULP-ээс бага, тэнцүү эсвэл их хэмжээгээр гаргаж байгаа эсэхийг шалгана.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Хэрэв үлдсэн бүх битүүд тэг байвал энэ нь= 0.5 ULP, өөрөөр хэлбэл> 0.5 Хэрэв бит байхгүй бол (half_bit==0), доорхи нь мөн Equal-ийг зөв буцааж өгдөг.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Зөвхөн аравтын оронтой тоо бүхий ASCII мөрийг `u64` болгож хөрвүүлдэг.
///
/// Давхардсан эсвэл хүчингүй тэмдэгтүүдийг шалгадаггүй тул залгасан хүн болгоомжтой хандахгүй бол үр дүн нь хуурамч бөгөөд panic болно (гэхдээ `unsafe` биш байх болно).
/// Нэмж дурдахад хоосон мөрүүдийг тэг гэж үздэг.
/// Энэ функц нь байдаг
///
/// 1. `&[u8]` дээр `FromStr` ашиглах нь `from_utf8_unchecked` шаарддаг бөгөөд энэ нь муу бөгөөд
/// 2. `integral.parse()` ба `fractional.parse()`-ийн үр дүнг нэгтгэх нь энэ бүх функцээс илүү төвөгтэй юм.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII цифрүүдийн мөрийг bignum болгон хөрвүүлдэг.
///
/// `from_str_unchecked`-ийн нэгэн адил энэ функц нь цифрээс ангид байхын тулд задлагч дээр тулгуурладаг.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Bignum-ийг 64 битийн бүхэл тоо болгон задална.Хэрэв тоо хэт том байвал Panics.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Олон тооны битийг задалдаг.

/// Индекс 0 нь хамгийн бага ач холбогдолтой бит бөгөөд хүрээ ердийн байдлаар хагас нээлттэй байна.
/// Буцаах төрөлд багтахаас илүү битийг гаргаж авахыг хүсвэл Panics.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}