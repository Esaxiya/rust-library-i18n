//! Маягтын аравтын мөрийг баталгаажуулах ба задлах:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Өөрөөр хэлбэл, тэмдэглэгээ байхгүй, "inf" ба "NaN"-тэй харьцуулахгүй гэсэн хоёр үл хамаарах ердийн хөвөгч цэгийн синтакс юм.Эдгээрийг (super::dec2flt) драйверын функцээр зохицуулдаг.
//!
//! Хүчин төгөлдөр оролтыг таних нь харьцангуй хялбар боловч энэ модуль нь panic-ийг хэзээ ч тоолохын аргагүй олон тооны хүчингүй хувилбаруудаас татгалзаж, бусад модулиуд panic биш (эсвэл халих)-т найдаж байгаа олон тооны шалгалтыг хийх ёстой.
//!
//! Үүнийг улам дордуулахын тулд бүх зүйл оролтын дээгүүр өнгөрөх болно.
//! Тиймээс аливаа зүйлийг өөрчлөхдөө болгоомжтой байж, бусад модулиудыг давхар шалгаарай.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Аравтын тэмдэгт мөрийн сонирхолтой хэсгүүд.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Аравтын оронтой тоо, 18-аас цөөн аравтын оронтой байх баталгаатай.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Оролтын мөр нь зөв хөвөгч цэгийн дугаар мөн эсэхийг шалгаж, хэрэв тийм бол салшгүй хэсэг, бутархай хэсэг ба экспонентийг олоорой.
/// Тэмдгүүдтэй харьцдаггүй.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e'-ээс өмнө цифр байхгүй
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Бид цэгээс өмнө эсвэл дараа нь дор хаяж нэг оронтой тоог шаарддаг.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Бутархай хэсгийн дараахь хог хаягдал
            }
        }
        _ => Invalid, // Эхний оронтой мөрний араас хог хаягдлыг дагаж байна
    }
}

/// Аравтын оронтой тоог эхний оронгүй тэмдэгт хүртэл хасна.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Бүрэлдэхүүн хэсгийг ялган авах, алдаа шалгах.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Экспонентын дараа хог хаягдлыг дагаж байна
    }
    if number.is_empty() {
        return Invalid; // Хоосон үзүүлэлт
    }
    // Энэ үед бид хүчинтэй цифрүүдийн мөртэй байх нь гарцаагүй.`i64`-д оруулахад хэтэрхий урт байж магадгүй, гэхдээ хэрэв тийм том бол оролт нь тэг эсвэл хязгааргүй байх нь дамжиггүй.
    // Аравтын оронтой тэг бүр нь зөвхөн үзүүлэлтийг +/-1-ээр тохируулдаг тул exp=10 ^ 18 үед төгсгөлтэй болоход алсаас ойртохын тулд оролт нь 17 эксабайт (!) тэг байх ёстой.
    //
    // Энэ бол бидний анхаарах ёстой хэрэг биш юм.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}