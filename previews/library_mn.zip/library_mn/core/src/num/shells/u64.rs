//! 64 битийн тэмдэггүй бүхэл тоон төрлийн тогтмолууд.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Шинэ код нь холбогдох тогтмолуудыг командын төрөлд шууд ашиглах ёстой.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }