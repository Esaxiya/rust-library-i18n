//! "Хөвөгч цэгийн тоог хурдан бөгөөд үнэн зөв хэвлэх" 3-р зургийн бараг шууд (гэхдээ бага зэрэг оновчтой) орчуулсан Rust орчуулга.
//!
//!
//! [^1]: Burger, RG and Dybvig, RK 1996. Хөвөгч цэгийг хэвлэх
//!   хурдан бөгөөд үнэн зөв.Тэмдэглэл биш.31, 5 (1996 оны 5-р сар), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n)-ийн хувьд Digit`-ийн урьдчилан тооцоолсон массивууд
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// зөвхөн `x < 16 * scale` үед ашиглах боломжтой;`scaleN` нь `scale.mul_small(N)` байх ёстой
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Луунд зориулсан хамгийн богино горимын хэрэгжилт.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // форматлах `v` дугаарыг дараахь байдлаар мэддэг:
    // - `mant * 2^exp`-тэй тэнцүү;
    // - өмнө нь анхны төрөлд `(mant - 2 *minus)* 2^exp`;болон
    // - дараа нь анхны төрөлд `(mant + 2 *plus)* 2^exp`.
    //
    // Мэдээжийн хэрэг, `minus` ба `plus` нь тэг байж чадахгүй.(хязгааргүй байдлын хувьд бид хүрээнээс гадуур утгыг ашигладаг.) мөн бид дор хаяж нэг цифр бий болно гэж үздэг, өөрөөр хэлбэл `mant` нь тэг байж чадахгүй.
    //
    // энэ нь мөн `low = (mant - minus)*2^exp` ба `high = (mant + plus)* 2^exp` хоорондох ямар ч тоо анхны мантисса жигд байх үед (өөрөөр хэлбэл, `!mant_was_odd`) хязгаарыг багтаасан яг энэ хөвөгч цэгийн дугаарыг харуулна гэсэн үг юм.
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` нь `if d.inclusive {a <= b} else {a < b}` юм
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)`-ийг хангасан анхны оролтоос `k_0`-ийг тооцоолох.
    // `10^(k-1) < high <= 10^k`-ийг хангасан нягт хязгаартай `k`-ийг дараа нь тооцоолно.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp`-ийг бутархай хэлбэрт шилжүүлээд дараахь байдлаар хийнэ.
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant`-ийг `10^k`-т хуваа.одоо `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // `mant + plus > scale` (эсвэл `>=`) үед засах.
    // Бид анхны үржүүлгийн оронд алгасах боломжтой тул `scale`-ийг өөрчлөхгүй байна.
    // одоо `scale < mant + plus <= scale * 10`, бид цифр үүсгэхэд бэлэн байна.
    //
    // `scale - plus < mant < scale` байх үед `d[0]` * нь тэг байж болохыг анхаарна уу.
    // энэ тохиолдолд бөөрөнхий нөхцөлийг (доорхи `up`) нэн даруй ажиллуулах болно.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // `scale`-ийг 10-оор томруулсантай тэнцэнэ
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // кэш `(2, 4, 8) * scale` оронтой болгох.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // `d[0..n-1]` бол өнөөг хүртэл үүссэн цифрүүд юм.
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (ингэснээр `mant / scale < 10`), энд `d[i..j]` бол `d [i] * 10 ^ (ji) + ... гэсэн товчлол юм.
        // + d [j-1] * 10 + d[j]`.

        // нэг орон үүсгэх: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // Энэ бол өөрчлөгдсөн Dragon алгоритмын хялбаршуулсан тодорхойлолт юм.
        // тохь тухыг хангах үүднээс олон завсрын гаргалгаа, бүрэн байдлын аргументуудыг орхигдуулсан болно.
        //
        // `n`-ийг шинэчилсэн тул өөрчлөгдсөн өөрчлөгдөөгүй хувилбаруудаас эхэлнэ үү.
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // `d[0..n-1]` бол `low` ба `high` хоорондох хамгийн богино дүрслэл гэж үзье, өөрөөр хэлбэл `d[0..n-1]` нь дараахь зүйлийг хоёуланг нь хангаж байгаа боловч `d[0..n-2]` нь тийм биш юм:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (биектив байдал: `v` хүртэлх цифрүүд);болон
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (сүүлчийн орон зөв байна).
        //
        // хоёр дахь нөхцөл нь `2 * mant <= scale` хүртэл хялбаршуулдаг.
        // `mant`, `low` ба `high`-ийн хувьд өөрчлөгдөхгүй хувилбаруудыг шийдвэрлэх нь эхний нөхцлийн илүү хялбар хувилбарыг гаргаж өгдөг. `-plus < mant < minus`.
        // `-plus < 0 <= mant` оноос хойш `mant < minus` ба `2 * mant <= scale` байх үед бид хамгийн богино дүрслэлийг зөв гаргадаг.
        // (анхны mantissa жигд байх үед эхнийх нь `mant <= minus` болдог.)
        //
        // хоёр дахь нь ажиллахгүй бол (`2 * mant> масштаб`), бид сүүлийн цифрийг нэмэгдүүлэх хэрэгтэй.
        // Энэ нь тухайн нөхцлийг сэргээхэд хангалттай юм: тоон үе нь `0 <= v / 10^(k-n) - d[0..n-1] < 1`-ийг баталгаажуулдаг гэдгийг бид аль хэдийн мэддэг болсон.
        // энэ тохиолдолд эхний нөхцөл нь `-plus < mant - scale < minus` болно.
        // `mant < scale` үеэс хойш `scale < mant + plus` байна.
        // (дахин, анхны мантисса жигд байх үед энэ нь `scale <= mant + plus` болно.)
        //
        // товчхондоо:
        // - `mant < minus` (эсвэл `<=`) үед `down`-ийг зогсоож (цифрүүдийг хэвээр нь хадгална).
        // - `scale < mant + plus` (эсвэл `<=`) үед `up` зогсоох ба дугуйруулах (сүүлийн цифрийг нэмэгдүүлэх).
        // - өөрөөр үүсгэж байгаарай.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // Бид хамгийн богино төлөөлөлтэй, бөөрөнхийлөлтийг үргэлжлүүлээрэй

        // өөрчлөгдөөгүй байдлыг сэргээх.
        // Энэ нь алгоритмийг үргэлж цуцлахад хүргэдэг: `minus` ба `plus` үргэлж нэмэгддэг боловч `mant` нь `scale` модулийг хайчилж, `scale` нь тогтмол байдаг.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // бөөрөнхийлөлт нь i) зөвхөн нэгтгэх нөхцлийг өдөөсөн тохиолдолд тохиолддог, эсвэл ii) хоёулаа нөхцөл байдал үүсч, тэнцсэн тохиолдолд дугуйрсан дугуй илүүд үздэг.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // хэрэв бөөрөнхийлөх нь уртыг өөрчилдөг бол илэрхийлэгч мөн өөрчлөгдөх ёстой.
        // Энэ нөхцлийг хангахад маш хэцүү юм шиг санагдаж байна (гэхдээ боломжгүй байж магадгүй), гэхдээ бид энд аюулгүй, тууштай байх болно.
        //
        // АЮУЛГҮЙ БАЙДАЛ: бид дээрх санах ойг эхлүүлсэн.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // АЮУЛГҮЙ БАЙДАЛ: бид дээрх санах ойг эхлүүлсэн.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Луунд яг тохирсон, тогтмол горимыг хэрэгжүүлэх.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)`-ийг хангасан анхны оролтоос `k_0`-ийг тооцоолох.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant`-ийг `10^k`-т хуваа.одоо `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // `mant + plus >= scale` үед засах, хаана `plus / scale = 10^-buf.len() / 2`.
    // тогтмол хэмжээтэй bignum-ийг хадгалахын тулд бид `mant + floor(plus) >= scale` ашигладаг.
    // Бид анхны үржүүлгийн оронд алгасах боломжтой тул `scale`-ийг өөрчлөхгүй байна.
    // хамгийн богино алгоритмаар дахин `d[0]` тэг байж болох боловч эцэст нь нэгтгэх болно.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // `scale`-ийг 10-оор томруулсантай тэнцэнэ
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // хэрэв бид сүүлийн оронтой хязгаарлалттай ажиллаж байгаа бол давхар бөөрөнхийлөлтөөс зайлсхийхийн тулд орчуулгыг бодитоор үзүүлэхээс өмнө богиносгох хэрэгтэй.
    //
    // Бөөрөнхийлөх үед бид буферийг дахин томруулах хэрэгтэй гэдгийг анхаарна уу!
    let mut len = if k < limit {
        // бид *нэг* оронтой тоог ч гаргаж чадахгүй.
        // Энэ нь 9.5 гэх мэт зүйлийг олж аваад 10 болгож тоймлоход боломжтой юм.
        // Бид хоосон буферийг буцааж өгдөг, дараа нь `k == limit` үед тохиолддог бөгөөд яг нэг оронтой тоог гаргах шаардлагатай болдог.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // кэш `(2, 4, 8) * scale` оронтой болгох.
        // (энэ нь үнэтэй байж болох тул буфер хоосон байхад тэдгээрийг тооцож болохгүй.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // дараахь цифрүүд нь бүгд тэг юм, бид энд бөөрөнхийлөхийг хичээх хэрэггүй!харин үлдсэн цифрүүдийг бөглөх хэрэгтэй.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // АЮУЛГҮЙ БАЙДАЛ: бид дээрх санах ойг эхлүүлсэн.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // хэрэв бид дараахь цифрүүд яг 5000 ... бол цифрүүдийн дунд зогсох юм бол өмнөх цифрийг шалгаад тэгшитгэхийг хичээгээрэй (өөрөөр хэлбэл өмнөх цифр тэгш байх үед бөөрөнхийлөхөөс зайлсхийх хэрэгтэй).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // АЮУЛГҮЙ БАЙДАЛ: `buf[len-1]`-ийг эхлүүлсэн.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // хэрэв бөөрөнхийлөх нь уртыг өөрчилдөг бол илэрхийлэгч мөн өөрчлөгдөх ёстой.
        // гэхдээ бид тодорхой тооны цифр хүссэн тул буферийг өөрчилж болохгүй ...
        // АЮУЛГҮЙ БАЙДАЛ: бид дээрх санах ойг эхлүүлсэн.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... үүний оронд бид нарийвчлалтай нарийвчлалтай байхыг шаардаагүй бол.
            // хэрэв бид анхны буфер хоосон байсан бол нэмэлт цифрийг зөвхөн `k == limit` (edge тохиолдол) үед нэмэх боломжтой гэдгийг шалгах хэрэгтэй.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // АЮУЛГҮЙ БАЙДАЛ: бид дээрх санах ойг эхлүүлсэн.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}