//! Хөвөгч цэгийн утгыг тус тусад нь хэсэг ба алдааны муж болгон декодчилдог.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Декодчилсон гарын үсэггүй хязгаарлагдмал утга, үүнд:
///
/// - Анхны утга нь `mant * 2^exp`-тэй тэнцүү байна.
///
/// - `(mant - minus)*2^exp`-ээс `(mant + plus)* 2^exp` хүртэлх бүх тоо анхны утга руу эргэлдэнэ.
/// Зөвхөн `inclusive` нь `true` байхад хүрээг хамарна.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Масштаб.
    pub mant: u64,
    /// Алдааны доод хязгаар.
    pub minus: u64,
    /// Дээд алдааны хүрээ.
    pub plus: u64,
    /// 2-р суурь дахь хуваалцсан үзүүлэлт.
    pub exp: i16,
    /// Алдааны хязгаарыг багтаасан тохиолдолд үнэн болно.
    ///
    /// IEEE 754-д анхны мантисса жигд байсан үед энэ нь үнэн юм.
    pub inclusive: bool,
}

/// Гарын үсэггүй утгыг декодчилсон.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Хязгааргүй, эерэг эсвэл сөрөг.
    Infinite,
    /// Эерэг эсвэл сөрөг аль аль нь тэг.
    Zero,
    /// Цааш нь декодчилсон талбар бүхий хязгаартай тоо.
    Finite(Decoded),
}

/// `Decode`d байж болох хөвөгч цэгийн төрөл.
pub trait DecodableFloat: RawFloat + Copy {
    /// Хамгийн бага эерэг хэвийн утга.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Өгөгдсөн хөвөгч цэгийн тэмдэг (сөрөг үед үнэн) ба `FullDecoded` утгыг буцаана.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // хөршүүд: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode үргэлж экспоненцийг хадгалдаг тул мантисса нь хэвийн бус амьтдын хувьд хэмжигддэг.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // хөршүүд: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // энд maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // хөршүүд: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}