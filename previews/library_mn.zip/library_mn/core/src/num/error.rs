//! Интеграл хэлбэрт шилжүүлэх алдааны төрлүүд.

use crate::convert::Infallible;
use crate::fmt;

/// Алдааны төрлийг шалгасан интеграл хэлбэрийн хөрвүүлэлт амжилтгүй болох үед буцаана
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Дээрх `From<Infallible> for TryFromIntError` шиг код нь `Infallible` нь `!`-ийн нэр болж хувирахад үргэлжлүүлэн ажиллана гэдгийг баталгаажуулахын тулд албадлагын оронд тааруул.
        //
        //
        match never {}
    }
}

/// Бүхэл тоог задлахад буцааж болох алдаа.
///
/// Энэ алдааг [`i8::from_str_radix`] гэх мэт бүхэл тооны бүхэл төрлийн `from_str_radix()` функцын алдааны төрөл болгон ашигладаг.
///
/// # Боломжит шалтгаанууд
///
/// Бусад шалтгаанаас гадна `ParseIntError` нь стандарт оролтоос олж авсан тохиолдолд мөрөнд хоосон зайг тэргүүлж эсвэл араар тавьж байгаа тул хаяж болно.
///
/// [`str::trim()`] аргыг ашигласнаар задлан шинжлэхээс өмнө хоосон зай үлдэхгүй.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Бүхэл тоог задлахад хүргэж болзошгүй янз бүрийн алдааг хадгалахын тулд enum.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Утга задлах нь хоосон байна.
    ///
    /// Бусад шалтгаанаас гадна хоосон мөрийг задлахад энэ хувилбарыг бий болгоно.
    Empty,
    /// Агуулгын хувьд хүчингүй цифр агуулсан байна.
    ///
    /// Бусад шалтгаанаас гадна энэ хувилбар нь ASCII бус char агуулсан мөрийг задлахад зориулагдсан болно.
    ///
    /// Энэ хувилбарыг `+` эсвэл `-` мөрөнд дангаар нь эсвэл тооны дунд байрлуулахдаа буруу байрлуулсан тохиолдолд бас байгуулна.
    ///
    ///
    InvalidDigit,
    /// Бүхэл тоо хэт том тул зорилтот бүхэл тоогоор хадгалах боломжгүй юм.
    PosOverflow,
    /// Бүхэл тоо нь зорилтот бүхэл тоогоор хадгалахад хэтэрхий бага байна.
    NegOverflow,
    /// Утга нь тэг байсан
    ///
    /// Энэ хувилбар нь ялгах мөр нь тэгийн утгатай үед гарах бөгөөд энэ нь тэг биш төрлүүдийн хувьд хууль бус болно.
    ///
    Zero,
}

impl ParseIntError {
    /// Бүхэл тоог задалж хаясан дэлгэрэнгүй шалтгааныг гаргана.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}