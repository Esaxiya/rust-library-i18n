//! Анхдагч traits ба төрлүүдийн үндсэн шинж чанарыг илэрхийлсэн төрлүүд.
//!
//! Rust төрлийг дотоод шинж чанараар нь янз бүрийн ашигтай аргаар ангилж болно.
//! Эдгээр ангиллыг traits гэж төлөөлдөг.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Мөрний хил хязгаар дамжуулж болох төрлүүд.
///
/// Энэ trait нь хөрвүүлэгч тохиромжтой гэж үзсэн тохиолдолд автоматаар хэрэгждэг.
///
/// "Илгээгүй" төрлийн жишээ бол [`rc::Rc`][`Rc`] лавлах тоолох заагч юм.
/// Хэрэв ижил урсгалтай ижил утгыг зааж өгсөн хоёр утас [`Rc`]-г хуулбарлахыг оролдвол [`Rc`] нь атомын үйлдлийг ашигладаггүй тул [undefined behavior][ub] болох лавлагааны тооллыг нэгэн зэрэг шинэчлэхийг оролдож магадгүй юм.
///
/// Түүний үеэл [`sync::Arc`][arc] нь атомын ажиллагааг ашигладаг (зарим нэмэлт зардал гардаг) тул `Send` юм.
///
/// Дэлгэрэнгүй мэдээллийг [the Nomicon](../../nomicon/send-and-sync.html)-с авна уу.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Эмхэтгэхэд мэдэгдэж байсан тогтмол хэмжээтэй төрлүүд.
///
/// Бүх төрлийн параметрүүд нь `Sized` гэсэн далд хязгаартай байдаг.Хэрэв энэ тохиромжгүй бол тусгай синтакс `?Sized`-ийг ашиглаж болно.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//алдаа: [i32]-ийн хувьд хэмжээ нь хийгдээгүй байна
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Үүний нэг үл хамаарах зүйл бол trait-ийн далд хэлбэрийн `Self` төрөл юм.
/// trait нь тодорхой бус `Sized` холболттой байдаггүй тул [trait объект]-тай таарахгүй тул trait нь бүх боломжит хэрэгжүүлэгчидтэй ажиллах шаардлагатай тул ямар ч хэмжээтэй байж болно.
///
///
/// Хэдийгээр Rust нь `Sized`-ийг trait-тэй холбох боломжийг танд олгож байгаа боловч та үүнийг ашиглан trait объект үүсгэх боломжгүй болно.
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y: &dyn Bar= &Impl;//алдаа: trait `Bar`-ийг объект болгох боломжгүй
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // Жишээ нь, `[T]: !Default`-ийг үнэлэх боломжтой байхыг шаарддаг Default-ийн хувьд
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// "unsized" хэмжээтэй динамик хэмжээтэй байж болох төрлүүд.
///
/// Жишээлбэл, `[i8; 2]` массивын хэмжээ нь `Unsize<[i8]>` ба `Unsize<dyn fmt::Debug>`-ийг хэрэгжүүлдэг.
///
/// `Unsize`-ийн бүх хэрэгжилтийг хөрвүүлэгч автоматаар өгдөг.
///
/// `Unsize` дараахь зорилгоор хэрэгжиж байна.
///
/// - `[T; N]` нь `Unsize<[T]>` юм
/// - `T` `T: Trait` байх үед `Unsize<dyn Trait>` байна
/// - `Foo<..., T, ...>` хэрэв `Unsize<Foo<..., U, ...>>` бол:
///   - `T: Unsize<U>`
///   - Foo бол бүтэц юм
///   - Зөвхөн `Foo`-ийн хамгийн сүүлийн талбар нь `T`-тэй холбоотой төрөлтэй байдаг
///   - `T` нь бусад талбаруудын нэг хэсэг биш юм
///   - `Bar<T>: Unsize<Bar<U>>`, хэрэв `Foo`-ийн сүүлийн талбар `Bar<T>` төрөлтэй бол
///
/// `Unsize` - ийг [`ops::CoerceUnsized`]-тэй хамт ашигладаг бөгөөд [`Rc`] зэрэг "user-defined" савыг динамик хэмжээтэй төрлийг агуулдаг.
/// Дэлгэрэнгүй мэдээллийг [DST coercion RFC][RFC982] ба [the nomicon entry on coercion][nomicon-coerce]-ээс үзнэ үү.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Загвар тохируулахад хэрэглэгддэг тогтмолуудад trait шаардлагатай.
///
/// `PartialEq` гаргадаг аливаа төрөл нь энэ trait-ийг *параметрүүд нь `Eq` хэрэгжүүлж байгаа эсэхээс үл хамааран* автоматаар хэрэгжүүлдэг.
///
/// Хэрэв `const` зүйлд энэ trait-ийг хэрэгжүүлдэггүй төрөл орсон бол (1.)-ийн аль нэг нь `PartialEq`-ийг хэрэгжүүлдэггүй (энэ нь кодыг үүсгэх боломжтой гэж харьцуулах аргыг тогтмол өгөхгүй гэсэн үг юм) эсвэл (2.)-ийг өөрөө хэрэгжүүлдэг гэсэн үг юм. * `PartialEq`-ийн хувилбар (энэ нь бүтцийн тэгш байдлын харьцуулалтад нийцэхгүй гэж бид үзэж байна).
///
///
/// Дээрх хоёр хувилбарын аль нэгэнд бид ийм тогтмолыг хэв маягийн тохиргоонд ашиглахаас татгалздаг.
///
/// Аттрибут дээр суурилсан дизайнаас энэхүү trait руу шилжихэд түлхэц болсон [structural match RFC][RFC1445] ба [issue 63438]-ийг үзнэ үү.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Загвар тохируулахад хэрэглэгддэг тогтмолуудад trait шаардлагатай.
///
/// `Eq` гаргадаг аливаа төрөл нь түүний параметрүүд `Eq`-ийг хэрэгжүүлж байгаа эсэхээс үл хамааран * энэ trait-ийг автоматаар хэрэгжүүлдэг.
///
/// Энэ бол манай төрлийн системийн хязгаарлалтыг даван туулах хакердсан арга юм.
///
/// # Background
///
/// Загварын тохиргоонд ашигладаг const-ийн төрлүүд `#[derive(PartialEq, Eq)]` атрибуттай байхыг бид хүсч байна.
///
/// Илүү тохиромжтой ертөнцөд бид энэ шаардлагыг `StructuralPartialEq` trait *ба*`Eq` trait хоёуланг нь хоёуланг нь хэрэгжүүлж байгаа эсэхийг шалгах замаар шалгаж болно.
/// Гэсэн хэдий ч, та *хийх*`derive(PartialEq, Eq)` гэсэн ADT-тэй байж болох бөгөөд бид хөрвүүлэгчээс хүлээн авахыг хүсч байгаа тохиолдол байх болно, гэхдээ константын төрөл нь `Eq`-ийг хэрэгжүүлж чадахгүй байна.
///
/// Тухайлбал, иймэрхүү тохиолдол:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Дээрх кодын асуудал бол `Wrap<fn(&())>` нь `PartialEq`, эсвэл `Eq`-ийг хэрэгжүүлдэггүй явдал юм, учир нь "for a" fn(&'a _)` does not implement those traits.)
///
/// Тиймээс бид `StructuralPartialEq` ба ердөө `Eq` гэсэн гэнэн шалгалтанд найдаж болохгүй.
///
/// Үүнийг тойрон гарах хакерын хувьд бид (`#[derive(PartialEq)]` ба `#[derive(Eq)]`) гарал үүсэл тус бүрт тарьсан хоёр тусдаа traits-ийг ашиглаж, хоёулаа бүтцийн тохирлын нэг хэсэг болох эсэхийг шалгана.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Битийг хуулах замаар утгыг нь хуулбарлах боломжтой төрлүүд.
///
/// Анхдагч байдлаар, хувьсах холбоосууд нь "шилжих семантиктай" байдаг.Өөрөөр хэлбэл:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` руу шилжсэн тул ашиглах боломжгүй юм
///
/// // println! ("{: ?}", x);//алдаа: шилжүүлсэн утгыг ашиглах
/// ```
///
/// Гэсэн хэдий ч хэрэв төрөл нь `Copy`-ийг хэрэгжүүлдэг бол түүний оронд 'хуулах семантик' орсон байна:
///
/// ```
/// // Бид `Copy` програмыг гаргаж авах боломжтой.
/// // `Clone` Энэ нь `Copy`-ийн супер хоолой тул шаардлагатай байдаг.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` нь `x`-ийн хуулбар юм
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Эдгээр хоёр жишээн дээр цорын ганц ялгаа нь даалгавар өгсний дараа `x` руу нэвтрэх зөвшөөрөл өгөх эсэх нь л чухал гэдгийг анхаарах нь чухал юм.
/// Бүрээсний дор хуулбар болон шилжүүлгийн аль аль нь санах ойд бит хуулагдах боломжтой байдаг боловч үүнийг заримдаа оновчтой болгодог.
///
/// ## Би `Copy`-ийг хэрхэн хэрэгжүүлэх вэ?
///
/// Таны төрөл дээр `Copy`-ийг хэрэгжүүлэх хоёр арга бий.Хамгийн хялбар нь `derive` ашиглах явдал юм.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Та мөн `Copy` ба `Clone`-ийг гараар хэрэгжүүлж болно:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Энэ хоёрын хооронд ялимгүй ялгаа бий: `derive` стратеги нь `Copy`-ийг төрөл бүрийн параметрүүд дээр холбодог бөгөөд энэ нь үргэлж хүсээд байдаггүй.
///
/// ## `Copy` ба `Clone` хооронд ямар ялгаа байдаг вэ?
///
/// Хуулбарууд нь далд хэлбэрээр гардаг, жишээлбэл, `y = x` даалгаврын нэг хэсэг юм.`Copy`-ийн үйлдлийг хэт ачаалах боломжгүй;энэ бол үргэлж энгийн ухаалаг хуулбар юм.
///
/// Клонжуулах нь `x.clone()` гэсэн тодорхой арга хэмжээ юм.[`Clone`]-ийн хэрэгжилт нь утгыг аюулгүй хуулбарлахад шаардлагатай аливаа төрлийн онцлог шинж чанарыг хангаж өгдөг.
/// Жишээлбэл, [`String`]-т зориулсан [`Clone`]-ийг хэрэгжүүлэхэд овоолго дотогш чиглэсэн мөрний буферийг хуулах шаардлагатай.
/// [`String`]-ийн утгуудын энгийн битийн хуулбар нь заагчийг хуулж, мөрөнд доошоо хоёр дахин суллахад хүргэдэг.
/// Энэ шалтгааны улмаас [`String`] нь [`Clone`] боловч `Copy` биш юм.
///
/// [`Clone`] нь `Copy`-ийн супер хоолой юм, тиймээс `Copy` гэсэн бүх зүйл [`Clone`]-ийг хэрэгжүүлэх ёстой.
/// Хэрэв төрөл нь `Copy` бол түүний [`Clone`] хэрэгжүүлэлт нь зөвхөн `*self`-ийг буцааж өгөх шаардлагатай (дээрх жишээг үзнэ үү).
///
/// ## Миний төрөл хэзээ `Copy` байж болох вэ?
///
/// Бүх бүрэлдэхүүн хэсгүүд нь `Copy`-ийг хэрэгжүүлдэг бол төрөл нь `Copy`-ийг хэрэгжүүлж чадна.Жишээлбэл, энэ бүтэц нь `Copy` байж болно:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Бүтэц нь `Copy`, [`i32`] нь `Copy` байж болох тул `Point` нь `Copy` байх боломжтой.
/// Үүний эсрэгээр авч үзье
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` бүтэц нь `Copy`-ийг хэрэгжүүлж чадахгүй, учир нь [`Vec<T>`] нь `Copy` биш юм.Хэрэв бид `Copy` програмыг гаргахыг оролдвол алдаа гарах болно.
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// (`&T`) хуваалцсан лавлагаа нь бас `Copy` тул *биш*`Copy` төрлийн `T` хуваалцсан лавлагаа агуулсан байсан ч гэсэн нэг төрөл нь `Copy` байж болно.
/// `Copy`-ийг хэрэгжүүлж болох дараахь бүтцийг авч үзье.Учир нь энэ нь дээр дурдсан манай "Хуулж авахгүй" төрлийн `PointList`-т зөвхөн *хуваалцсан лавлагаа* агуулдаг.
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Хэзээ * миний төрөл `Copy` байж болохгүй вэ?
///
/// Зарим төрлийг аюулгүй хуулах боломжгүй.Жишээлбэл, `&mut T`-ийг хуулж авбал өөрчлөгдөх боломжтой лавлагаа үүсгэх болно.
/// [`String`]-ийг хуулах нь ["String`] '-ийн буферийг удирдах үүргийг давхардуулж хоёр дахин үнэгүй болгох болно.
///
/// Сүүлийн тохиолдлыг ерөнхийд нь авч үзвэл [`Drop`]-ийг хэрэгжүүлж буй аливаа хэлбэр нь `Copy` байж болохгүй, учир нь энэ нь өөрийн [`size_of::<T>`] байтаас гадна зарим нөөцийг удирддаг.
///
/// Хэрэв та `Copy`-ийг `Copy` бус өгөгдөл агуулсан бүтэц эсвэл enum дээр хэрэгжүүлэхийг оролдвол [E0204] алдаа гарах болно.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Миний төрөл хэзээ `Copy` байх ёстой вэ?
///
/// Ерөнхийдөө таны _can_ төрөл `Copy`-ийг хэрэгжүүлдэг бол үүнийг хийх ёстой.
/// Гэхдээ `Copy`-ийг хэрэгжүүлэх нь таны төрлийн нийтийн API-ийн нэг хэсэг гэдгийг санаарай.
/// Хэрэв төрөл нь future дээр "хуулбарлахгүй" байж болзошгүй бол API өөрчлөлтийг зөрчихгүйн тулд `Copy` програмыг одоо орхих нь ухаалаг байж болох юм.
///
/// ## Нэмэлт хэрэгжүүлэгчид
///
/// [implementors listed below][impls]-ээс гадна дараахь төрлүүд `Copy`-ийг хэрэгжүүлдэг.
///
/// * Чиг үүргийн төрлүүд (өөрөөр хэлбэл функц тус бүрт тодорхойлсон ялгаатай төрлүүд)
/// * Функцийн заагчийн төрлүүд (жишээлбэл, `fn() -> i32`)
/// * Массивын төрлүүд, бүх төрлийн хувьд `Copy` (жишээлбэл, `[i32; 123456]`)
/// * Tuple төрөл, хэрэв бүрэлдэхүүн хэсэг бүр `Copy` (жишээлбэл, `()`, `(i32, bool)`)-ийг хэрэгжүүлдэг бол
/// * Хэрэв тэдгээр нь хүрээлэн буй орчноос ямар ч үнэ цэнэ авдаггүй эсвэл эдгээр бүх авсан утгууд нь `Copy`-ийг өөрсдөө хэрэгжүүлдэг бол хаалтын төрөл.
///   Хуваалцсан лавлагаагаар авсан хувьсагчид үргэлж `Copy`-ийг хэрэгжүүлдэг (лавлагаа оруулаагүй ч гэсэн), харин өөрчлөгдөх боломжтой лавлагаагаар авсан хувьсагчид хэзээ ч `Copy`-ийг хэрэгжүүлдэггүйг анхаарна уу.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Энэ нь насан туршдаа сэтгэл ханамжгүй байдаг тул `Copy`-ийг хэрэгжүүлдэггүй төрлийг хуулах боломжийг олгодог (зөвхөн `A<'static>: Copy` ба `A<'_>: Clone` байхад `A<'_>`-ийг хуулах).
// Стандарт номын санд байдаг `Copy` дээр цөөхөн хэдэн мэргэшил байдаг тул одоохондоо бидэнд ийм шинж чанар байгаа бөгөөд энэ зан үйлийг аюулгүй хийх арга одоохондоо байхгүй байна.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy`-ийн импл үүсгэх макро гаргаж авах.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Утас хоорондын холбоосыг хуваалцахад аюулгүй байдаг төрлүүд.
///
/// Энэ trait нь хөрвүүлэгч тохиромжтой гэж үзсэн тохиолдолд автоматаар хэрэгждэг.
///
/// Нарийн тодорхойлолт нь: `T` төрөл нь [`Sync`] бөгөөд зөвхөн `&T` бол [`Send`] бол л болно.
/// Өөрөөр хэлбэл, `&T` лавлагаа утаснуудын хооронд дамжуулж байх үед [undefined behavior][ub] (өгөгдлийн уралдааныг оруулаад) боломж байхгүй бол.
///
/// [`u8`] ба [`f64`] гэх мэт командын төрлүүд бүгд [`Sync`] бөгөөд тэдгээрийг агуулсан энгийн нэгтгэсэн төрлүүд, жишээлбэл, коридор, бүтэц, enum гэх мэт.
/// [`Sync`] төрлийн үндсэн жишээнүүдэд `&T`, [`Box<T>`][box], [`Vec<T>`][vec] болон бусад ихэнх цуглуулгын төрлүүд гэх мэт удамшлын хувирамтгай шинж чанартай "immutable" төрлүүд орно.
///
/// (Тэдний параметрүүд нь "Sync`" байхын тулд ерөнхий параметрүүд нь [`Sync`] байх шаардлагатай.)
///
/// Тодорхойлолтын хувьд гайхмаар үр дагавар бол `&mut T` бол `Sync` (хэрэв `T` бол `Sync` бол) боловч энэ нь синхрончлолгүй мутацийг бий болгож магадгүй юм.
/// Заль мэх нь хуваалцсан лавлагааны (өөрөөр хэлбэл `& &mut T`) цаана өөрчлөгдөж болох лавлагааг зөвхөн `& &T` шиг унших боломжтой болгодог.
/// Тиймээс мэдээллийн уралдаан болох эрсдэлгүй болно.
///
/// `Sync` биш төрлүүд нь "interior mutability"-ийг [`Cell`][cell], [`RefCell`][refcell] гэх мэт аюулгүй хамгаалалттай хэлбэрээр агуулдаг.
/// Эдгээр төрлүүд нь өөрчлөгдөөгүй, хуваалцсан лавлагаагаар дамжуулан агуулгынхаа мутацийг өөрчлөх боломжийг олгодог.
/// Жишээлбэл, [`Cell<T>`][cell] дээрх `set` арга нь `&self`-ийг шаарддаг тул зөвхөн хуваалцсан [`&Cell<T>`][cell] лавлагааг шаарддаг.
/// Энэ арга нь ямар ч синхрончлол хийдэггүй тул [`Cell`][cell] нь `Sync` байж болохгүй.
///
/// `Sync` бус хэлбэрийн өөр нэг жишээ бол [`Rc`][rc] лавлах тоолох заагч юм.
/// Аливаа лавлагаа [`&Rc<T>`][rc]-ийг харгалзан та лавлагааны тоог атомын бус аргаар өөрчилж шинэ [`Rc<T>`][rc]-ийг хувилж болно.
///
/// Утасны аюулгүй интерьер өөрчлөгдөх шаардлагатай тохиолдолд Rust нь [atomic data types] болон [`sync::Mutex`][mutex], [`sync::RwLock`][rwlock]-ээр дамжуулан түгжигдэх боломжийг олгодог.
/// Эдгээр төрлүүд нь аливаа мутаци нь өгөгдлийн уралдаан үүсгэж чадахгүй тул `Sync` төрөл юм.
/// Үүнтэй адилаар [`sync::Arc`][arc] нь [`Rc`][rc]-ийн утастай аюулгүй аналогийг хангаж өгдөг.
///
/// Дотоод хувирамтгай бүх төрлүүд value(s)-ийн эргэн тойронд [`cell::UnsafeCell`][unsafecell] боолтыг ашиглах ёстой бөгөөд үүнийг хуваалцсан лавлагаагаар мутацлах боломжтой.
/// Үүнийг хийж чадахгүй байгаа нь [undefined behavior][ub] юм.
/// Жишээлбэл, `&T`-ээс `&mut T` хүртэл [`transmute`][transmute]-ing хүчингүй байна.
///
/// `Sync`-ийн талаархи дэлгэрэнгүй мэдээллийг [the Nomicon][nomicon-send-and-sync]-ээс үзнэ үү.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): нэг удаа `rustc_on_unimplemented`-д тэмдэглэл нэмж бета хувилбарт оруулахыг дэмжиж, хаалтын шаардлага гинжин хэлхээний аль нэг хэсэгт байгаа эсэхийг шалгахын тулд өргөтгөсөн бол үүнийг (#48534) хэлбэрээр сунгана уу:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Тэг хэмжигдэхүүн нь "act like"-ийг `T` эзэмшдэг зүйлийг тэмдэглэхэд ашигладаг.
///
/// Таны төрөл дээр `PhantomData<T>` талбар нэмэхэд хөрвүүлэгч таны төрөл яг үнэндээ биш ч гэсэн `T` төрлийн утгыг хадгалж байгаа юм шиг ажилладаг болохыг хэлнэ.
/// Эдгээр мэдээллийг аюулгүй байдлын зарим шинж чанарыг тооцоолохдоо ашигладаг.
///
/// `PhantomData<T>`-ийг хэрхэн ашиглах талаар илүү гүнзгий тайлбар авахыг хүсвэл [the Nomicon](../../nomicon/phantom-data.html)-ээс үзнэ үү.
///
/// # Аймшигтай тэмдэглэл 👻👻👻
///
/// Хэдийгээр хоёулаа аймшигтай нэртэй боловч `PhantomData` ба 'хий үзэгдэл' нь хоорондоо холбоотой боловч ижил биш юм.Phantom төрлийн параметр нь ердөө л хэзээ ч ашиглагддаггүй төрлийн параметр юм.
/// Rust дээр энэ нь ихэвчлэн хөрвүүлэгчийг гомдоллоход хүргэдэг бөгөөд шийдэл нь `PhantomData` аргаар "dummy" хэрэглээг нэмэх явдал юм.
///
/// # Examples
///
/// ## Ашиглаагүй насан туршийн параметрүүд
///
/// `PhantomData`-ийн хамгийн түгээмэл хэрэглэгддэг тохиолдол бол ашиглагдаагүй ашиглалтын хугацааны параметртэй, ихэвчлэн зарим аюултай кодын хэсэг болох бүтэц юм.
/// Жишээлбэл, `*const T` төрлийн хоёр заагчтай, хаа нэг газар массив руу чиглүүлж байгаа `Slice` бүтцийг энд оруулав.
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Үүний зорилго нь суурь өгөгдөл нь зөвхөн `'a` насан туршдаа хүчинтэй тул `Slice` нь `'a`-ээс хэтрэхгүй байх ёстой.
/// Гэсэн хэдий ч `'a`-ийн ашиглалтын хугацаа байхгүй тул энэ нь ямар өгөгдөлд хамаарах нь тодорхойгүй тул энэ зорилгыг кодонд илэрхийлээгүй болно.
/// Бид үүнийг хөрвүүлэгчд *`Slice` бүтцэд `&'a T` лавлагаа агуулсан мэт* ажиллахыг хэлснээр засах боломжтой.
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Энэ нь эргээд `T: 'a` тэмдэглэгээг шаарддаг бөгөөд `T` дээрх лавлагаа нь `'a`-ийн туршид хүчинтэй болохыг харуулж байна.
///
/// `Slice`-ийг эхлүүлэхдээ `phantom` талбарт `PhantomData` гэсэн утгыг өгөх болно.
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Ашиглагдаагүй төрлийн параметрүүд
///
/// Заримдаа танд ашиглагдаагүй төрлийн параметрүүд байдаг бөгөөд энэ нь бүтцийн хувьд "tied" өгөгдлийг ямар төрлийн болохыг харуулдаг, гэхдээ тэр бүтэц нь өөрөө өөрөө олддоггүй.
/// Энэ нь [FFI]-тэй холбоотой жишээ юм.
/// Гадаад интерфейс нь `*mut ()` төрлийн бариулуудыг ашиглан янз бүрийн төрлийн Rust утгыг ашигладаг.
/// Бид бариулыг боож өгдөг `ExternalResource` struct дээрх хий үзэгдэл төрлийн параметрийг ашиглан Rust төрлийг дагаж мөрддөг.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Эзэмшил ба уналтын шалгалт
///
/// `PhantomData<T>` төрлийн талбар нэмэх нь таны төрөл `T` төрлийн өгөгдлийг эзэмшдэг болохыг харуулж байна.Энэ нь эргээд таны төрлийг хасахад `T` төрлийн нэг буюу хэд хэдэн тохиолдлыг хаяж магадгүй гэсэн үг юм.
/// Энэ нь Rust хөрвүүлэгчийн [drop check] шинжилгээнд хамаатай юм.
///
/// Хэрэв таны бүтэц `T` төрлийн өгөгдлийг үнэндээ *эзэмшдэггүй бол `PhantomData<&'a T>` (ideally) эсвэл `PhantomData<* const T>` гэх мэт лавлагааны төрлийг ашиглах нь илүү дээр юм.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Enum ялгаварлан гадуурхах төрлийг тодорхойлоход ашигладаг хөрвүүлэгч дотоод trait.
///
/// Энэхүү trait нь төрөл бүрийн хувьд автоматаар хэрэгждэг бөгөөд [`mem::Discriminant`] дээр ямар ч баталгаа нэмдэггүй.
/// `DiscriminantKind::Discriminant` ба `mem::Discriminant` хооронд шилжих нь **тодорхойгүй зан байдал** юм.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// `mem::Discriminant`-д шаардагдах trait bounds-ийг хангах ёстой ялгаварлан гадуурхагчийн төрөл.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Төрөлд ямар нэгэн `UnsafeCell` агуулагдаж байгаа эсэхийг тодорхойлохын тулд ашигладаг хөрвүүлэгч-дотоод trait, харин шууд бус хэлбэрээр ашигладаггүй.
///
/// Энэ нь жишээлбэл, ийм төрлийн `static`-ийг зөвхөн унших боломжтой статик санах ойд эсвэл бичигдэх статик санах ойд байрлуулахад нөлөөлдөг.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Төмөрлөсний дараа аюулгүй зөөж болох төрлүүд.
///
/// Rust нь өөрөө үл хөдлөх хэлбэрийн талаар ямар ч ойлголтгүй бөгөөд хөдөлгөөнийг (жишээлбэл, даалгавар эсвэл [`mem::replace`]-ээр дамжуулан) үргэлж аюулгүй гэж үздэг.
///
/// [`Pin`][Pin] төрлийг оронд нь төрлийн системээр дамжихаас сэргийлдэг.[`Pin<P<T>>`][Pin] боодолтой `P<T>` заагчийг зөөж гаргах боломжгүй.
/// Пинонгийн талаархи нэмэлт мэдээллийг [`pin` module] баримт бичгээс үзнэ үү.
///
/// `T`-ийн хувьд `Unpin` trait-ийг хэрэгжүүлснээр уг төрлийг бэхлэх хязгаарлалтыг өргөж, улмаар `T`-ийг [`Pin<P<T>>`][Pin]-ээс [`mem::replace`] гэх мэт функцээр шилжүүлэх боломжийг олгодог.
///
///
/// `Unpin` хавчуулагдаагүй мэдээллийн хувьд ямар ч үр дагаваргүй болно.
/// Ялангуяа [`mem::replace`] нь `!Unpin` өгөгдлийг баяртайгаар хөдөлгөдөг (энэ нь зөвхөн `T: Unpin` үед биш ямар ч `&mut T`-т ажилладаг).
/// Гэсэн хэдий ч та [`Pin<P<T>>`][Pin]-ийг ороосон өгөгдөлд [`mem::replace`] ашиглах боломжгүй, учир нь танд шаардлагатай `&mut T`-ийг авч чадахгүй бөгөөд *энэ* нь энэ системийг ажиллуулахад хүргэдэг.
///
/// Жишээлбэл, үүнийг зөвхөн `Unpin` хэрэгжүүлэгч төрлүүд дээр хийж болно:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` руу залгахын тулд бидэнд өөрчлөгдөх боломжтой лавлагаа хэрэгтэй.
/// // Бид (implicitly)-ийг дуудаж (implicitly)-ээр ийм лавлагаа авах боломжтой боловч `String` нь `Unpin`-ийг хэрэгжүүлдэг тул ийм боломжтой юм.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Энэхүү trait нь бараг бүх төрөлд автоматаар хэрэгждэг.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin`-ийг хэрэгжүүлдэггүй тэмдэглэгээний төрөл.
///
/// Хэрэв төрөл нь `PhantomPinned` агуулсан бол `Unpin`-ийг анхдагчаар хэрэгжүүлэхгүй.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Балар эртний төрлүүдэд зориулсан `Copy` хэрэгжилт.
///
/// Rust дээр тайлбарлах боломжгүй хэрэгжилтийг `traits::SelectionContext::copy_clone_conditions()` дээр `rustc_trait_selection` дээр хэрэгжүүлдэг.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Хуваалцсан лавлагаа материалыг хуулж болох боловч өөрчлөгдөх боломжтой лавлагаа *чадахгүй*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}