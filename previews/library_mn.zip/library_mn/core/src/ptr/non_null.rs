use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` гэхдээ тэг биш ба ковариант.
///
/// Энэ нь ихэвчлэн өгөгдлийн бүтцийг түүхий заагч ашиглан бүтээхэд ашиглах зөв зүйл боловч нэмэлт шинж чанараасаа болоод ашиглах нь илүү аюултай байдаг.Хэрэв та `NonNull<T>` ашиглах хэрэгтэй эсэхээ сайн мэдэхгүй байгаа бол `*mut T`-ийг ашиглаарай!
///
/// `*mut T`-ээс ялгаатай нь заагч хэзээ ч ялгаагүй байсан ч гэсэн заагч нь үргэлж тэг байх ёстой.Энэ нь хориотой утгыг enum-ийг ялгаварлан гадуурхагч болгон ашиглаж болзошгүй тул `Option<NonNull<T>>` нь `* mut T`-тай ижил хэмжээтэй байна.
/// Гэсэн хэдий ч заагчийг ялгахгүй бол унжсан хэвээр байж магадгүй юм.
///
/// `*mut T`-ээс ялгаатай нь `NonNull<T>` нь `T` дээр ковариант байхаар сонгогдсон.Энэ нь ковариантын төрлийг бүтээхдээ `NonNull<T>`-ийг ашиглах боломжтой болох боловч үнэндээ ковариант байх ёсгүй төрлөөр ашиглах нь үндэслэлгүй болох эрсдлийг бий болгодог.
/// (Техникийн хувьд үндэслэлгүй байдал нь зөвхөн аюултай функцийг дуудахаас үүдэлтэй байж болох ч эсрэгээр `*mut T`-ийг сонгосон.)
///
/// Коварианс нь `Box`, `Rc`, `Arc`, `Vec`, `LinkedList` зэрэг хамгийн аюулгүй хийсвэрлэлийн хувьд зөв байдаг.Энэ нь Rust-ийн ердийн хуваалцсан XOR өөрчлөгдөх дүрмийг дагаж мөрдөх олон нийтийн API-г хангаж өгдөг тул ийм тохиолдол гардаг.
///
/// Хэрэв таны төрөл аюулгүй ковариант байж чадахгүй бол өөрчлөгдөөгүй байдлыг хангах нэмэлт талбарыг агуулсан байх ёстой.Ихэнхдээ энэ талбар нь `PhantomData<Cell<T>>` эсвэл `PhantomData<&'a mut T>` гэх мэт [`PhantomData`] төрөл байх болно.
///
/// `NonNull<T>` нь `&T`-д зориулсан `From` жишээтэй болохыг анхаарна уу.Гэхдээ энэ нь мутаци нь [`UnsafeCell<T>`] дотор тохиолдоогүй тохиолдолд (а-аас үүсгэсэн заагч) хуваалцсан лавлагаагаар мутаци хийх нь тодорхой бус зан байдал болохыг өөрчлөхгүй.Хуваалцсан лавлагаанаас өөрчлөгдөж болох лавлагаа үүсгэхэд мөн адил хамаарна.
///
/// Энэхүү `From` жишээг `UnsafeCell<T>`-гүй ашиглах үед `as_mut`-ийг хэзээ ч дууддаггүй бөгөөд `as_ptr`-ийг хэзээ ч мутацид ашиглахгүй байх үүрэгтэй.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` заагч нь `Send` биш, учир нь тэдгээрийн иш татсан өгөгдлийг өөр нэрээр сольж болно.
// NB, энэ импл шаардлагагүй тул илүү сайн алдааны мэдэгдлийг өгөх ёстой.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` заагч нь `Sync` биш, учир нь тэдгээрийн иш татсан өгөгдлийг өөр нэрээр сольж болно.
// NB, энэ импл шаардлагагүй тул илүү сайн алдааны мэдэгдлийг өгөх ёстой.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Унжсан, гэхдээ сайн зохицсон шинэ `NonNull` үүсгэдэг.
    ///
    /// Энэ нь `Vec::new` шиг залхуугаар хуваарилдаг төрлийг эхлүүлэхэд хэрэгтэй юм.
    ///
    /// Заагчийн утга нь `T`-ийн зөв заагчийг төлөөлж болзошгүй тул үүнийг "not yet initialized" харуулын утга болгон ашиглаж болохгүй гэсэн үг юм.
    /// Залхуугаар хуваарилдаг төрлүүд нь эхлүүлэлтийг өөр аргаар хянах ёстой.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // АЮУЛГҮЙ АЖИЛЛАГАА: mem::align_of() тэг биш хэрэглээг буцаана
        // а * мут Т.
        // Тиймээс `ptr` нь тэг биш бөгөөд new_unchecked() руу залгах нөхцлийг хүндэтгэдэг.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Утга хуваалцсан ишлэлийг буцаана.[`as_ref`]-ээс ялгаатай нь энэ утгыг эхлүүлэх шаардлагагүй болно.
    ///
    /// Өөрчлөгдөх боломжтой түншийн талаар [`as_uninit_mut`]-ээс үзнэ үү
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Энэ аргыг дуудахдаа та дараахь бүх зүйл үнэн болохыг баталгаажуулах ёстой.
    ///
    /// * Заагчийг зөв тааруулсан байх ёстой.
    ///
    /// * Энэ нь [the module documentation]-д тодорхойлсон утгаараа "dereferencable" байх ёстой.
    ///
    /// * Буцаж ирсэн ашиглалтын хугацааг `'a` дур мэдэн сонгосон тул өгөгдлийн бодит хугацааг тусгах албагүй тул та Rust-ийн хуурамч дүрмийг хэрэгжүүлэх ёстой.
    ///
    ///   Ялангуяа, энэ амьдралын туршид заагчийн зааж өгсөн санах ой нь мутацид орох ёсгүй (`UnsafeCell` дотроос бусад тохиолдолд).
    ///
    /// Энэ аргын үр дүнг ашиглаагүй байсан ч хамаатай!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `self` нь бүх стандартыг хангасан болохыг баталгаажуулах ёстой
        // тодорхойлолтод тавигдах шаардлага.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Утгад зориулсан өвөрмөц лавлагаа буцаана.[`as_mut`]-ээс ялгаатай нь энэ утгыг эхлүүлэх шаардлагагүй болно.
    ///
    /// Хуваалцсан түншийн хувьд [`as_uninit_ref`]-г үзнэ үү.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Энэ аргыг дуудахдаа та дараахь бүх зүйл үнэн болохыг баталгаажуулах ёстой.
    ///
    /// * Заагчийг зөв тааруулсан байх ёстой.
    ///
    /// * Энэ нь [the module documentation]-д тодорхойлсон утгаараа "dereferencable" байх ёстой.
    ///
    /// * Буцаж ирсэн ашиглалтын хугацааг `'a` дур мэдэн сонгосон тул өгөгдлийн бодит хугацааг тусгах албагүй тул та Rust-ийн хуурамч дүрмийг хэрэгжүүлэх ёстой.
    ///
    ///   Тодруулбал, энэ амьдралын туршид заагчийн зааж өгсөн санах ойд бусад заагчаар хандах (унших эсвэл бичих) боломжгүй байх ёстой.
    ///
    /// Энэ аргын үр дүнг ашиглаагүй байсан ч хамаатай!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `self` нь бүх стандартыг хангасан болохыг баталгаажуулах ёстой
        // тодорхойлолтод тавигдах шаардлага.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Шинэ `NonNull` үүсгэдэг.
    ///
    /// # Safety
    ///
    /// `ptr` тэг биш байх ёстой.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // АЮУЛГҮЙ АЖИЛЛАГАА: дуудлага хийж байгаа хүн `ptr` нь тэг биш болохыг баталгаажуулах ёстой.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Хэрэв `ptr` нь тэг биш бол шинэ `NonNull` үүсгэдэг.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // АЮУЛГҮЙ БАЙДАЛ: Заагчийг аль хэдийн шалгасан бөгөөд тэг биш байна
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Түүхий `*const` заагчийн эсрэг `NonNull` заагчийг буцааж өгөхөөс бусад тохиолдолд [`std::ptr::from_raw_parts`]-тэй ижил функцийг гүйцэтгэдэг.
    ///
    ///
    /// Илүү дэлгэрэнгүйг [`std::ptr::from_raw_parts`]-ийн баримт бичгээс үзнэ үү.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // АЮУЛГҮЙ АЖИЛЛАГАА: `ptr::from::raw_parts_mut`-ийн үр дүн нь тэг биш, учир нь `data_address` нь тэг юм.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// (Өргөн байж магадгүй) заагчийг хаяг ба мета өгөгдлийн бүрэлдэхүүн хэсэг болгон задална.
    ///
    /// Дараа нь заагчийг [`NonNull::from_raw_parts`] төхөөрөмжөөр сэргээж болно.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// `*mut` заагчийг олж авдаг.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Утга хуваалцсан лавлагааг буцаана.Хэрэв утгыг эхлүүлээгүй байж магадгүй бол [`as_uninit_ref`]-ийг ашиглах хэрэгтэй.
    ///
    /// Өөрчлөгдөх боломжтой түншийн талаар [`as_mut`]-ээс үзнэ үү.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Энэ аргыг дуудахдаа та дараахь бүх зүйл үнэн болохыг баталгаажуулах ёстой.
    ///
    /// * Заагчийг зөв тааруулсан байх ёстой.
    ///
    /// * Энэ нь [the module documentation]-д тодорхойлсон утгаараа "dereferencable" байх ёстой.
    ///
    /// * Заагч нь `T`-ийн эхлүүлсэн жишээг зааж өгөх ёстой.
    ///
    /// * Буцаж ирсэн ашиглалтын хугацааг `'a` дур мэдэн сонгосон тул өгөгдлийн бодит хугацааг тусгах албагүй тул та Rust-ийн хуурамч дүрмийг хэрэгжүүлэх ёстой.
    ///
    ///   Ялангуяа, энэ амьдралын туршид заагчийн зааж өгсөн санах ой нь мутацид орох ёсгүй (`UnsafeCell` дотроос бусад тохиолдолд).
    ///
    /// Энэ аргын үр дүнг ашиглаагүй байсан ч хамаатай!
    /// (Эхлүүлэх хэсэг нь бүрэн шийдэгдээгүй байгаа боловч энэ болтол цорын ганц аюулгүй хандлага нь тэдгээрийг үнэхээр эхлүүлсэн эсэхийг баталгаажуулах явдал юм.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `self` нь бүх стандартыг хангасан болохыг баталгаажуулах ёстой
        // тодорхойлолтод тавигдах шаардлага.
        unsafe { &*self.as_ptr() }
    }

    /// Утгын талаархи өвөрмөц лавлагааг буцаана.Хэрэв утгыг эхлүүлээгүй байж магадгүй бол [`as_uninit_mut`]-ийг ашиглах хэрэгтэй.
    ///
    /// Хуваалцсан түншийн хувьд [`as_ref`]-г үзнэ үү.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Энэ аргыг дуудахдаа та дараахь бүх зүйл үнэн болохыг баталгаажуулах ёстой.
    ///
    /// * Заагчийг зөв тааруулсан байх ёстой.
    ///
    /// * Энэ нь [the module documentation]-д тодорхойлсон утгаараа "dereferencable" байх ёстой.
    ///
    /// * Заагч нь `T`-ийн эхлүүлсэн жишээг зааж өгөх ёстой.
    ///
    /// * Буцаж ирсэн ашиглалтын хугацааг `'a` дур мэдэн сонгосон тул өгөгдлийн бодит хугацааг тусгах албагүй тул та Rust-ийн хуурамч дүрмийг хэрэгжүүлэх ёстой.
    ///
    ///   Тодруулбал, энэ амьдралын туршид заагчийн зааж өгсөн санах ойд бусад заагчаар хандах (унших эсвэл бичих) боломжгүй байх ёстой.
    ///
    /// Энэ аргын үр дүнг ашиглаагүй байсан ч хамаатай!
    /// (Эхлүүлэх хэсэг нь бүрэн шийдэгдээгүй байгаа боловч энэ болтол цорын ганц аюулгүй хандлага нь тэдгээрийг үнэхээр эхлүүлсэн эсэхийг баталгаажуулах явдал юм.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `self` нь бүх стандартыг хангасан болохыг баталгаажуулах ёстой
        // өөрчлөгдөж болох лавлагааны шаардлага.
        unsafe { &mut *self.as_ptr() }
    }

    /// Өөр төрлийн заагч руу шиддэг.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // АЮУЛГҮЙ АЖИЛЛАГАА: `self` бол `NonNull` заагч бөгөөд тэг байх ёстой
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Нимгэн заагч ба уртаас хоосон биш түүхий зүсмэлийг үүсгэдэг.
    ///
    /// `len` аргумент нь байтын тоо биш ** элементийн тоо юм.
    ///
    /// Энэ функц нь аюулгүй боловч буцаах утгыг бууруулах нь аюултай юм.
    /// Зүсмэлийн аюулгүй байдлын шаардлагыг [`slice::from_raw_parts`]-ийн баримт бичгээс үзнэ үү.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // эхний элемент рүү заагчаар эхлэхдээ зүсмэлийн заагчийг бий болгох
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Энэ жишээг зохиомлоор энэ аргыг ашиглахыг харуулсан болохыг анхаарна уу, гэхдээ `slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // АЮУЛГҮЙ АЖИЛЛАГАА: `data` бол `NonNull` заагч бөгөөд тэг байх ёстой
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Хоосон бус зүсмэлийн уртыг буцаана.
    ///
    /// Буцааж өгсөн утга нь байтын тоо биш харин ** элементийн тоо юм.
    ///
    /// Хоосон түүхий зүсмэлийг зүсмэл рүү шилжүүлж болохгүй ч гэсэн заагч нь зөв хаяггүй тул энэ функц аюулгүй болно.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Хоосон заагчийг зүсмэлийн буферт буцаана.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // АЮУЛГҮЙ АЖИЛЛАГАА: Бид `self` нь ямар ч утгагүй гэдгийг мэддэг.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Түүхий заагчийг зүсмэлийн буферт буцаана.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Эхлээгүй утгын зүсмэлийн хуваалцсан лавлагааг буцаана.[`as_ref`]-ээс ялгаатай нь энэ утгыг эхлүүлэх шаардлагагүй болно.
    ///
    /// Өөрчлөгдөх боломжтой түншийн талаар [`as_uninit_slice_mut`]-ээс үзнэ үү.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Энэ аргыг дуудахдаа та дараахь бүх зүйл үнэн болохыг баталгаажуулах ёстой.
    ///
    /// * `ptr.len() * mem::size_of::<T>()` олон байтыг уншихад заагч нь [valid] байх ёстой бөгөөд зөв тааруулсан байх ёстой.Энэ нь ялангуяа:
    ///
    ///     * Энэ зүсмэлийн санах ойн хязгаарыг бүхэлд нь нэг хуваарилагдсан объект дотор багтаах ёстой!
    ///       Зүсмэлүүд нь олон хуваарилагдсан объектуудын дунд хэзээ ч тархаж чадахгүй.
    ///
    ///     * Заагч нь тэг урттай зүсмэлүүдийн хувьд ч зэрэгцсэн байх ёстой.
    ///     Үүний нэг шалтгаан бол enum байршлын оновчлол нь бусад өгөгдлөөс ялгахын тулд тохирсон, хоосон биш эшлэлүүдэд (ямар ч урт зүсмэлийг оруулаад) найдаж болно.
    ///
    ///     [`NonNull::dangling()`] ашиглан тэг урттай зүсмэлүүдийг `data` хэлбэрээр ашиглах боломжтой заагчийг авах боломжтой.
    ///
    /// * Зүсмэлийн нийт хэмжээ `ptr.len() * mem::size_of::<T>()` нь `isize::MAX`-ээс ихгүй байх ёстой.
    ///   [`pointer::offset`]-ийн аюулгүй байдлын баримт бичгийг үзнэ үү.
    ///
    /// * Буцаж ирсэн ашиглалтын хугацааг `'a` дур мэдэн сонгосон тул өгөгдлийн бодит хугацааг тусгах албагүй тул та Rust-ийн хуурамч дүрмийг хэрэгжүүлэх ёстой.
    ///   Ялангуяа, энэ амьдралын туршид заагчийн зааж өгсөн санах ой нь мутацид орох ёсгүй (`UnsafeCell` дотроос бусад тохиолдолд).
    ///
    /// Энэ аргын үр дүнг ашиглаагүй байсан ч хамаатай!
    ///
    /// Мөн [`slice::from_raw_parts`]-г үзнэ үү.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `as_uninit_slice`-ийн аюулгүй ажиллагааны гэрээг дагаж мөрдөх ёстой.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Эхлээгүй утгын зүсмэлийн өвөрмөц лавлагааг буцаана.[`as_mut`]-ээс ялгаатай нь энэ утгыг эхлүүлэх шаардлагагүй болно.
    ///
    /// Хуваалцсан түншийн хувьд [`as_uninit_slice`]-г үзнэ үү.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Энэ аргыг дуудахдаа та дараахь бүх зүйл үнэн болохыг баталгаажуулах ёстой.
    ///
    /// * Заагч нь `ptr.len() * mem::size_of::<T>()` олон байтыг унших, бичихэд [valid] байх ёстой бөгөөд зөв тааруулсан байх ёстой.Энэ нь ялангуяа:
    ///
    ///     * Энэ зүсмэлийн санах ойн хязгаарыг бүхэлд нь нэг хуваарилагдсан объект дотор багтаах ёстой!
    ///       Зүсмэлүүд нь олон хуваарилагдсан объектуудын дунд хэзээ ч тархаж чадахгүй.
    ///
    ///     * Заагч нь тэг урттай зүсмэлүүдийн хувьд ч зэрэгцсэн байх ёстой.
    ///     Үүний нэг шалтгаан бол enum байршлын оновчлол нь бусад өгөгдлөөс ялгахын тулд тохирсон, хоосон биш эшлэлүүдэд (ямар ч урт зүсмэлийг оруулаад) найдаж болно.
    ///
    ///     [`NonNull::dangling()`] ашиглан тэг урттай зүсмэлүүдийг `data` хэлбэрээр ашиглах боломжтой заагчийг авах боломжтой.
    ///
    /// * Зүсмэлийн нийт хэмжээ `ptr.len() * mem::size_of::<T>()` нь `isize::MAX`-ээс ихгүй байх ёстой.
    ///   [`pointer::offset`]-ийн аюулгүй байдлын баримт бичгийг үзнэ үү.
    ///
    /// * Буцаж ирсэн ашиглалтын хугацааг `'a` дур мэдэн сонгосон тул өгөгдлийн бодит хугацааг тусгах албагүй тул та Rust-ийн хуурамч дүрмийг хэрэгжүүлэх ёстой.
    ///   Тодруулбал, энэ амьдралын туршид заагчийн зааж өгсөн санах ойд бусад заагчаар хандах (унших эсвэл бичих) боломжгүй байх ёстой.
    ///
    /// Энэ аргын үр дүнг ашиглаагүй байсан ч хамаатай!
    ///
    /// Мөн [`slice::from_raw_parts_mut`]-г үзнэ үү.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // `memory` нь `memory.len()` олон байтыг унших, бичихэд хүчинтэй тул аюулгүй юм.
    /// // Агуулга нь эхлүүлээгүй байж болзошгүй тул `memory.as_mut()` руу залгахыг хориглоно.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `as_uninit_slice_mut`-ийн аюулгүй ажиллагааны гэрээг дагаж мөрдөх ёстой.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Түүхий заагчийг элемент эсвэл дэд хэсэг рүү буцааж өгдөг.
    ///
    /// Энэ аргыг зааг хязгааргүй индексээр дуудах эсвэл `self`-ийг дууриах боломжгүй үед дуудах нь үр дүнгийн заагчийг ашиглаагүй байсан ч *[тодорхойгүй зан байдал]* юм.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `self`-ийг хойшлуулах боломжтой, `index`-ийг хязгаарлаж байгаа эсэхийг баталгаажуулдаг.
        // Үүний үр дүнд үүссэн заагч нь NULL байж болохгүй.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // АЮУЛГҮЙ АЖИЛЛАГАА: Өвөрмөц заагч нь тэг байх боломжгүй тул нөхцлийг бүрдүүлэх болно
        // new_unchecked() хүндэтгэдэг.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // АЮУЛГҮЙ БАЙДАЛ: Хувьсах боломжтой лавлагаа нь null байж болохгүй.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // АЮУЛГҮЙ БАЙДАЛ: Лавлагаа нь null байж болохгүй тул дараахь нөхцлийг бүрдүүлэх шаардлагатай
        // new_unchecked() хүндэтгэдэг.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}