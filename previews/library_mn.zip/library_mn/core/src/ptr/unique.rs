use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Хоосон бус түүхий `*mut T`-ийн эргэн тойрон дахь боодол, энэ боодлыг эзэмшигч нь референтийг эзэмшдэг болохыг харуулж байна.
/// `Box<T>`, `Vec<T>`, `String`, `HashMap<K, V>` зэрэг хийсвэрлэл хийхэд ашигтай.
///
/// `*mut T`-ээс ялгаатай нь `Unique<T>` нь "as if"-ийг ажиллуулдаг бөгөөд энэ нь `T`-ийн жишээ байв.
/// Хэрэв `T` бол `Send`/`Sync` бол `Send`/`Sync`-ийг хэрэгжүүлдэг.
/// Энэ нь `T`-ийн жишээг хүлээж болох хүчтэй хуурамч баталгааны төрлийг илэрхийлнэ.
/// заагчийн лавлагаа нь Unique-ийг эзэмших өвөрмөц замгүйгээр өөрчлөгдөх ёсгүй.
///
/// Хэрэв та `Unique`-ийг өөрийн зорилгод ашиглах нь зөв эсэх талаар эргэлзэж байгаа бол сул семантиктай `NonNull`-ийг ашиглах талаар бодож үзээрэй.
///
///
/// `*mut T`-ээс ялгаатай нь заагч хэзээ ч ялгаагүй байсан ч гэсэн заагч нь үргэлж тэг байх ёстой.
/// Энэ нь хориотой утгыг enum-ийг ялгаварлан гадуурхагч болгон ашиглаж болзошгүй тул `Option<Unique<T>>` нь `Unique<T>`-тай ижил хэмжээтэй байна.
/// Гэсэн хэдий ч заагчийг ялгахгүй бол унжсан хэвээр байж магадгүй юм.
///
/// `*mut T`-ээс ялгаатай нь `Unique<T>` нь `T`-ээс илүү ковариант юм.
/// Энэ нь Unique-ийн хуурамч шаардлагыг хангаж буй аливаа хэлбэрийн хувьд үргэлж зөв байх ёстой.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: Энэ маркер нь зөрүү үүсгэх үр дагаваргүй боловч зайлшгүй шаардлагатай
    // бид dropbox-д зориулж `T`-ийг логикоор эзэмшдэг гэдгийг ойлгох болно.
    //
    // Дэлгэрэнгүй мэдээллийг:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` заагч өгөгдөл нь үндэслэлгүй тул `T` бол `Send` бол заагч нь `Send` юм.
/// Энэхүү өөрчлөгдөх инвариант нь төрлийн системээр хэрэгждэггүй болохыг анхаарна уу;`Unique` ашиглан хийсвэрлэл үүнийг хэрэгжүүлэх ёстой.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` заагч өгөгдөл нь үндэслэлгүй тул `T` бол `Sync` бол заагч нь `Sync` юм.
/// Энэхүү өөрчлөгдөх инвариант нь төрлийн системээр хэрэгждэггүй болохыг анхаарна уу;`Unique` ашиглан хийсвэрлэл үүнийг хэрэгжүүлэх ёстой.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Унжсан, гэхдээ сайн зохицсон шинэ `Unique` үүсгэдэг.
    ///
    /// Энэ нь `Vec::new` шиг залхуугаар хуваарилдаг төрлийг эхлүүлэхэд хэрэгтэй юм.
    ///
    /// Заагчийн утга нь `T`-ийн зөв заагчийг төлөөлж болзошгүй тул үүнийг "not yet initialized" харуулын утга болгон ашиглаж болохгүй гэсэн үг юм.
    /// Залхуугаар хуваарилдаг төрлүүд нь эхлүүлэлтийг өөр аргаар хянах ёстой.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // АЮУЛГҮЙ БАЙДАЛ: mem::align_of() нь хүчин төгөлдөр, тэг биш заагчийг буцаана.The
        // new_unchecked() руу залгах нөхцлийг хүндэтгэх болно.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Шинэ `Unique` үүсгэдэг.
    ///
    /// # Safety
    ///
    /// `ptr` тэг биш байх ёстой.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // АЮУЛГҮЙ АЖИЛЛАГАА: дуудлага хийж байгаа хүн `ptr` нь тэг биш болохыг баталгаажуулах ёстой.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Хэрэв `ptr` нь тэг биш бол шинэ `Unique` үүсгэдэг.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // АЮУЛГҮЙ БАЙДАЛ: Заагчийг аль хэдийн шалгасан бөгөөд тэг биш байна.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// `*mut` заагчийг олж авдаг.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Агуулгыг хасах.
    ///
    /// Үүний үр дүнд ашиглагдах хугацаа нь өөрөө өөртөө хамааралтай тул "as if"-тэй нийцдэг тул энэ нь зээлсэн Т-ийн жишээ юм.
    /// Хэрэв (unbound)-ийн урт хугацааг ашиглах шаардлагатай бол `&*my_ptr.as_ptr()`-ийг ашиглаарай.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `self` нь бүх стандартыг хангасан болохыг баталгаажуулах ёстой
        // тодорхойлолтод тавигдах шаардлага.
        unsafe { &*self.as_ptr() }
    }

    /// Агуулгыг агуулгаар нь өөрчлөнө.
    ///
    /// Үүний үр дүнд ашиглагдах хугацаа нь өөрөө өөртөө хамааралтай тул "as if"-тэй нийцдэг тул энэ нь зээлсэн Т-ийн жишээ юм.
    /// Хэрэв (unbound)-ийн урт хугацааг ашиглах шаардлагатай бол `&mut *my_ptr.as_ptr()`-ийг ашиглаарай.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `self` нь бүх стандартыг хангасан болохыг баталгаажуулах ёстой
        // өөрчлөгдөж болох лавлагааны шаардлага.
        unsafe { &mut *self.as_ptr() }
    }

    /// Өөр төрлийн заагч руу шиддэг.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // АЮУЛГҮЙ БАЙДАЛ: Unique::new_unchecked() нь шинэ өвөрмөц, хэрэгцээ шаардлагыг бий болгодог
        // өгсөн заагч нь тэг байх ёсгүй.
        // Бид өөрийгөө заагчаар дамжуулж байгаа тул тэг байж болохгүй.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // АЮУЛГҮЙ БАЙДАЛ: Хувьсах боломжтой лавлагаа нь null байж болохгүй
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}