#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Аливаа үзүүртэй мета өгөгдлийн төрлийг өгдөг.
///
/// # Заагчийн мета өгөгдөл
///
/// Түүхий заагчийн төрлүүд ба Rust дээрх лавлагааны төрлийг хоёр хэсгээс бүрдсэн гэж үзэж болно.
/// утгын санах ойн хаяг, зарим мета өгөгдлийг агуулсан өгөгдлийн заагч.
///
/// Статик хэмжээтэй (`Sized` traits-ийг хэрэгжүүлдэг) болон `extern` төрлийн хувьд заагчийг "нимгэн" гэж нэрлэдэг: мета өгөгдөл нь тэг хэмжээтэй, түүний төрөл нь `()` байна.
///
///
/// [dynamically-sized types][dst] руу чиглүүлэгчийг "өргөн" эсвэл "бүдүүн" гэж нэрлэдэг бөгөөд тэдгээр нь тэг биш хэмжээтэй мета өгөгдөлтэй байдаг.
///
/// * Сүүлийн талбар нь DST-тэй бүтэц зохион байгуулагчдын хувьд мета өгөгдөл нь сүүлчийн талбарын мета өгөгдөл юм
/// * `str` төрлийн хувьд мета өгөгдөл нь `usize` байт дахь урт юм
/// * `[T]` гэх мэт зүсмэл төрлүүдийн хувьд мета өгөгдөл нь `usize` хэмжээтэй байна
/// * `dyn SomeTrait` гэх мэт trait объектын хувьд мета өгөгдөл нь [`DynMetadata<Self>`][DynMetadata] (жишээ нь `DynMetadata<dyn SomeTrait>`)
///
/// future дээр Rust хэл нь заагчийн мета өгөгдөл өөр өөр төрлийг олж авах боломжтой.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Энэ trait-ийн цэг нь түүний `Metadata` холбоотой төрөл бөгөөд дээр дурдсанчлан `()` эсвэл `usize` эсвэл `DynMetadata<_>` юм.
/// Энэ нь бүх төрлийн хувьд автоматаар хэрэгждэг.
/// Үүнийг харгалзах хязгаарлалтгүй байсан ч гэсэн ерөнхий агуулгаар хэрэгжүүлсэн гэж үзэж болно.
///
/// # Usage
///
/// Түүхий заагчийг [`to_raw_parts`] аргаар өгөгдлийн хаяг болон мета өгөгдлийн бүрэлдэхүүн хэсэг болгон задалж болно.
///
/// Эсвэл мета өгөгдлийг дангаараа [`metadata`] функцээр гаргаж авах боломжтой.
/// Лавлагаа [`metadata`] руу дамжуулж, далд байдлаар албадаж болно.
///
/// (possibly-wide) заагчийг хаяг, мета өгөгдлөөс нь [`from_raw_parts`] эсвэл [`from_raw_parts_mut`] ашиглан буцааж байрлуулж болно.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// `Self`-ийн заагч болон лавлагааны мета өгөгдлийн төрөл.
    #[lang = "metadata_type"]
    // NOTE: trait bounds-ийг `static_assert_expected_bounds_for_metadata` дээр байлга
    //
    // `library/core/src/ptr/metadata.rs` дээр энд байгаа хүмүүстэй синхрончлох:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Энэхүү trait нэрийг хэрэгжүүлж буй төрлүүдийн заагч нь "нимгэн" байдаг.
///
/// Үүнд статик хэлбэрийн "Хэмжээ" ба `extern` төрлүүд орно.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: үүнийг trait нэрнүүд хэл дээр тогтвортой байхаас өмнө үүнийг тогтворжуулахгүй юу?
pub trait Thin = Pointee<Metadata = ()>;

/// Заагчийн мета өгөгдлийн бүрэлдэхүүн хэсгийг задлах.
///
/// `*mut T`, `&T` эсвэл `&mut T` төрлийн утгуудыг шууд `* const T`-д тулгадаг тул энэ функцэд шууд дамжуулж болно.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // АЮУЛГҮЙ БАЙДАЛ: * const T-ээс хойш `PtrRepr` холболтоос утгад нэвтрэх нь аюулгүй юм
    // болон PtrComponents<T>ижил санах ойн байршилтай байх.
    // Зөвхөн std энэ баталгааг гаргаж чадна.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Өгөгдлийн хаяг болон мета өгөгдлөөс (possibly-wide) түүхий заагчийг бүрдүүлдэг.
///
/// Энэ функц нь аюулгүй боловч буцааж өгсөн заагчийг хасах нь аюулгүй байх албагүй.
/// Зүсмэлүүдийн хувьд аюулгүй байдлын шаардлагыг [`slice::from_raw_parts`]-ийн баримт бичгээс үзнэ үү.
/// trait объектын хувьд мета өгөгдлийг заагчаас ижил буурсан төрөлд оруулах ёстой.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // АЮУЛГҮЙ БАЙДАЛ: * const T-ээс хойш `PtrRepr` холболтоос утгад нэвтрэх нь аюулгүй юм
    // болон PtrComponents<T>ижил санах ойн байршилтай байх.
    // Зөвхөн std энэ баталгааг гаргаж чадна.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// [`from_raw_parts`]-тэй ижил функцийг гүйцэтгэдэг, гэхдээ түүхий `*const` заагчийн эсрэг түүхий `* mut` заагчийг буцааж өгдөг.
///
///
/// Илүү дэлгэрэнгүйг [`from_raw_parts`]-ийн баримт бичгээс үзнэ үү.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // АЮУЛГҮЙ БАЙДАЛ: * const T-ээс хойш `PtrRepr` холболтоос утгад нэвтрэх нь аюулгүй юм
    // болон PtrComponents<T>ижил санах ойн байршилтай байх.
    // Зөвхөн std энэ баталгааг гаргаж чадна.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` холболтоос зайлсхийхэд шаардлагатай гарын авлагын импл.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` холболтоос зайлсхийхэд шаардлагатай гарын авлагын импл.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait объектын мета өгөгдөл.
///
/// Энэ нь trait обьект дотор хадгалагдсан бетоны төрлийг удирдахад шаардлагатай бүх мэдээллийг илэрхийлдэг vtable (виртуал дуудлагын хүснэгт) рүү чиглүүлэгч юм.
/// Vtable нь дараахь зүйлийг агуулдаг.
///
/// * төрөл хэмжээ
/// * төрлийн тохируулга
/// * төрлийн `drop_in_place` имплийн заагч (энгийн хуучин өгөгдөлд татгалзах зүйл байж болно)
/// * trait-ийг хэрэгжүүлэх бүх аргуудыг заана
///
/// Эхний гурван нь ямар ч trait объектыг хуваарилах, хаях, хуваарилахад зайлшгүй шаардлагатай тул онцгой байдгийг анхаарна уу.
///
/// Энэ бүтцийг `dyn` trait объект биш (жишээ нь `DynMetadata<u64>`) төрлийн параметрээр нэрлэх боломжтой боловч тухайн бүтцийн утга учиртай утгыг олж авах боломжгүй юм.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Бүх vtables-ийн нийтлэг угтвар.Үүний дараа trait аргуудын чиг үүргийн заагч дагалддаг.
///
/// `DynMetadata::size_of` гэх мэт хувийн хэрэгжилтийн нарийвчилсан мэдээлэл.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Энэ vtable-тэй холбоотой төрлийн хэмжээг буцаана.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Энэ vtable-тэй холбоотой төрлийн тохируулгыг буцаана.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Хэмжээ ба зэрэгцүүлэлтийг `Layout` хэлбэрээр буцаана
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // АЮУЛГҮЙ БАЙДАЛ: хөрвүүлэгч энэ бетон зуурмагийг Rust төрлийн бетонд зориулж ялгаруулсан
        // хүчин төгөлдөр зохион байгуулалттай гэдгийг мэддэг.`Layout::for_value`-тэй ижил үндэслэл.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` хязгаараас зайлсхийхэд шаардлагатай гарын авлагын импл.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}