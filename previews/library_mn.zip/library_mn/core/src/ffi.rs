#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Гадаад функцын интерфэйс (FFI) холболттой холбоотой хэрэгслүүд.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// [pointer] хэлбэрээр ашиглахад C-ийн `void` төрөлтэй тэнцэнэ.
///
/// Үндсэндээ `*const c_void` нь C-ийн `const void*`, `*mut c_void` нь C-ийн `void*`-тай тэнцүү юм.
/// Энэ нь Rust-ийн `()` төрөл болох C-ийн `void` буцах төрөлтэй адил *биш* гэсэн үг юм.
///
/// FFI-ийн тунгалаг бус төрлүүдийн заагчийг загварчлахын тулд `extern type`-ийг тогтворжуулах хүртэл хоосон байтын массивын эргэн тойронд newtype боодол ашиглахыг зөвлөж байна.
///
/// Дэлгэрэнгүйг [Nomicon]-с үзнэ үү.
///
/// Хэрэв тэд хуучин Rust хөрвүүлэгчийг 1.1.0 хүртэл дэмжихийг хүсвэл `std::os::raw::c_void` ашиглаж болно.
/// Rust 1.30.0-ийн дараа энэ тодорхойлолтоор дахин экспортолжээ.
/// Дэлгэрэнгүй мэдээллийг [RFC 2521]-с авна уу.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, LLVM нь хоосон заагчийн төрлийг болон malloc() гэх мэт өргөтгөлийн функцуудаар танихын тулд бид үүнийг LLVM bitcode-д i8 * гэж дүрслэх хэрэгтэй.
// Энд ашигласан enum нь үүнийг баталгаажуулж, зөвхөн хувийн хувилбаруудтай байх замаар "raw" төрлийг буруу ашиглахаас сэргийлдэг.
// Хөрвүүлэгч repr атрибутын талаар өөрөөр гомдоллодог тул бидэнд хамгийн багадаа нэг хувилбар хэрэгтэй, эс тэгвээс enum нь хүн амьдардаггүй тул ядаж ийм заагчийг ялгаж салгах нь UB байх тул бидэнд хоёр хувилбар хэрэгтэй болно.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list`-ийн үндсэн хэрэгжилт.
// Нэр нь WIP бөгөөд одоогоор `VaListImpl` ашиглаж байна.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f`-ээс өөрчлөгдөхгүй тул `VaListImpl<'f>` объект бүр тодорхойлогдсон функцын мужид холбогддог
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 `va_list`-ийн ABI хэрэгжилт.
/// Дэлгэрэнгүй мэдээллийг [AArch64 Procedure Call Standard]-с үзнэ үү.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC `va_list`-ийн ABI хэрэгжилт.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 `va_list`-ийн ABI хэрэгжилт.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list`-ийн боодол
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl`-ийг C-ийн `va_list`-тэй таарах `VaList` болгон хөрвүүлэх.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl`-ийг C-ийн `va_list`-тэй таарах `VaList` болгон хөрвүүлэх.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait-ийг олон нийтийн интерфейст ашиглах шаардлагатай боловч trait өөрөө энэ модулийн гадна ашиглахыг зөвшөөрөх ёсгүй.
// Хэрэглэгчдэд trait-ийг шинэ төрөлд хэрэгжүүлэх боломжийг олгох (ингэснээр дотоод болон vaarg-ийг шинэ төрөлд ашиглах боломжийг олгох) нь тодорхойгүй зан авир гаргахад хүргэж болзошгүй юм.
//
// FIXME(dlrobertson): VaArgSafe trait-ийг нийтийн интерфейст ашиглахын зэрэгцээ өөр газар ашиглах боломжгүй болгохын тулд trait-ийг хувийн модулийн хүрээнд нийтэд мэдээлэх шаардлагатай.
// RFC 2145 хэрэгжиж эхэлсний дараа үүнийг сайжруулах талаар анхаарч үзээрэй.
//
//
//
//
mod sealed_trait {
    /// Зөвшөөрөгдсөн төрлийг [super::VaListImpl::arg]-тэй ашиглахыг зөвшөөрдөг Trait.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Дараагийн аргуманд шилжүүлээрэй.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `va_arg`-ийн аюулгүй ажиллагааны гэрээг дагаж мөрдөх ёстой.
        unsafe { va_arg(self) }
    }

    /// `va_list`-ийг одоогийн байршилд хуулна.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `va_end`-ийн аюулгүй ажиллагааны гэрээг дагаж мөрдөх ёстой.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // АЮУЛГҮЙ БАЙДАЛ: бид `MaybeUninit` руу бичдэг тул энэ нь эхэлж, `assume_init` нь хууль ёсны юм
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: Энэ нь `va_end` руу залгах ёстой, гэхдээ цэвэр арга байхгүй
        // `drop` нь үргэлж дуудлагад холбогддог тул `va_end` нь харгалзах `va_copy`-тэй ижил функцээс шууд дуудагдах болно.
        // `man va_end` C үүнийг шаарддаг бөгөөд LLVM нь үндсэндээ C семантикийг дагаж мөрддөг тул `va_end` нь `va_copy`-тэй ижил функцээс үргэлж дуудагддаг гэдгийг баталгаажуулах хэрэгтэй.
        //
        // Илүү дэлгэрэнгүйг, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // `va_end` нь одоогийн LLVM бүх зорилтуудыг ашиглахыг хориглодог тул энэ нь одоогоор ажиллаж байна.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` эсвэл `va_copy`-ээр эхлүүлсний дараа `ap` аргумент жагсаалтыг устгана уу.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Arglist `src`-ийн одоогийн байршлыг arglist `dst` руу хуулна.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `T` төрлийн аргументийг `va_list` `ap`-ээс ачаалж, `ap` цэгийг нэмэгдүүлнэ.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}