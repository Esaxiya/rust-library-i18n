//! Төрлүүдийн хооронд хөрвүүлэх Traits.
//!
//! Энэ модуль дахь traits нь нэг төрлөөс нөгөө төрөл рүү хөрвүүлэх боломжийг олгодог.
//! trait бүр өөр зорилготой байдаг.
//!
//! - [`AsRef`] trait-ийг хямд үнэтэй лавлагаа-хөрвүүлэх зорилгоор хэрэгжүүлээрэй
//! - [`AsMut`] trait-ийг хямд үнэтэй өөрчлөгдөж, өөрчлөгдөж хөрвүүлэх зорилгоор хэрэгжүүлнэ
//! - [`From`] trait-ийг үнэ цэнэ, хөрвүүлэлтийг ашиглахад зориулж хэрэгжүүлээрэй
//! - [`Into`] trait-ийг одоогийн crate-ээс гадуурх төрлүүдээс утга руу хөрвүүлэхэд ашиглах.
//! - [`TryFrom`] ба [`TryInto`] traits нь [`From`], [`Into`] шиг ажилладаг боловч хөрвүүлэлт амжилтгүй болох үед хэрэгжих ёстой.
//!
//! Энэ модуль дахь traits нь ихэвчлэн trait bounds хэлбэрээр ашиглагддаг бөгөөд олон төрлийн аргументуудыг дэмжих боломжтой байдаг.Жишээ авахын тулд trait бүрийн баримтжуулалтыг үзнэ үү.
//!
//! Номын сангийн зохиогчийн хувьд та [`Into<U>`][`Into`] эсвэл [`TryInto<U>`][`TryInto`] гэхээсээ илүү [`From<T>`][`From`] эсвэл [`TryFrom<T>`][`TryFrom`]-ийг хэрэгжүүлэхийг илүүд үзээрэй.Учир нь [`From`] ба [`TryFrom`] нь илүү уян хатан байдлыг хангаж, стандарт номын санд хөнжил хэрэгжүүлсний ачаар [`Into`] эсвэл [`TryInto`]-ийн хэрэгжилтийг үнэгүй санал болгодог.
//! Rust 1.41-ээс өмнөх хувилбарыг чиглүүлэхдээ одоогийн crate-ээс гадуурх төрөлд хөрвүүлэхдээ [`Into`] эсвэл [`TryInto`]-ийг шууд хэрэгжүүлэх шаардлагатай болж магадгүй юм.
//!
//! # Ерөнхий хэрэгжилт
//!
//! - [`AsRef`] мөн дотоод төрөл нь лавлагаа бол [`AsMut`] автоматаар хасах
//! - [`From`]`<U>нь T` нь [`Into`]"гэсэн утгатай</u><T><U>U`-ийн хувьд</u>
//! - [`TryFrom`] `<U>нь T`-д [`TryInto`] "гэсэн утгатай</u><T><U>U`-ийн хувьд</u>
//! - [`From`] ба [`Into`] нь рефлекс шинжтэй байдаг тул бүх төрлүүд өөрсдөө `into` болон `from`-ийг өөрөө хийж чаддаг гэсэн үг юм
//!
//! Хэрэглээний жишээг trait бүрээс үзнэ үү.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Таних функц.
///
/// Энэ функцын талаар хоёр зүйлийг анхаарах нь чухал юм.
///
/// - Энэ нь `|x| x` шиг хаалттай үргэлж дүйцдэггүй, учир нь хаалт нь `x`-ийг өөр хэлбэрт оруулж болзошгүй юм.
///
/// - Энэ нь функцэд дамжуулсан `x` оролтыг шилжүүлдэг.
///
/// Зөвхөн оролтыг буцааж өгдөг функцтэй байх нь хачирхалтай санагдаж болох ч сонирхолтой хэрэглээ бий.
///
///
/// # Examples
///
/// `identity` ашиглан өөр, сонирхолтой функцүүдийн дарааллаар юу ч хийхгүй байх:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Нэгийг нэмэх нь сонирхолтой функц гэж жүжиглэе.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity`-ийг "do nothing" үндсэн тохиолдол болгон нөхцөлт байдлаар ашиглах нь:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Илүү сонирхолтой зүйл хий ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` давталтын `Some` хувилбаруудыг хадгалахын тулд `identity` ашиглах:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Лавлагаагаас хямд үнээр хөрвүүлэхэд ашигладаг.
///
/// Энэхүү trait нь өөрчлөгдөж болох лавлагааны хооронд хөрвүүлэхэд ашигладаг [`AsMut`]-тэй төстэй юм.
/// Хэрэв та үнэтэй хөрвүүлэлт хийх шаардлагатай бол [`From`]-ийг `&T` төрлөөр хэрэгжүүлэх эсвэл захиалгат функц бичих нь дээр.
///
/// `AsRef` [`Borrow`]-тэй ижил гарын үсэгтэй боловч [`Borrow`] нь цөөн талаараа ялгаатай:
///
/// - `AsRef`-ээс ялгаатай нь [`Borrow`] нь `T`-ийн хувьд хөнжлийн имплтэй бөгөөд үүнийг лавлагаа эсвэл утгын аль алиныг нь ашиглахад ашиглаж болно.
/// - [`Borrow`] мөн зээлсэн үнийн хувьд [`Hash`], [`Eq`] ба [`Ord`] нь эзэмшиж буй үнэ цэнэтэй тэнцүү байхыг шаарддаг.
/// Энэ шалтгааны улмаас та бүтцийн зөвхөн нэг талбарыг зээлэхийг хүсвэл `AsRef`-г хэрэгжүүлж болох боловч [`Borrow`] биш юм.
///
/// **Note: Энэ trait нь бүтэлгүйтэх ёсгүй **.Хэрэв хөрвүүлэлт бүтэлгүйтвэл [`Option<T>`] эсвэл [`Result<T, E>`] буцаах зориулалтын аргыг ашиглаарай.
///
/// # Ерөнхий хэрэгжилт
///
/// - `AsRef` хэрэв дотоод төрөл нь лавлагаа эсвэл өөрчлөгдөх боломжтой лавлагаа бол (жишээ нь: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds-ийг ашигласнаар бид төрөл бүрийн аргументуудыг заасан `T` төрөлд хөрвүүлэх боломжтой л бол хүлээн авах боломжтой.
///
/// Жишээлбэл: `AsRef<str>`-ийг авах ерөнхий функцийг бий болгосноор бид [`&str`] руу хөрвүүлж болох бүх лавлагааг аргумент болгон хүлээн авахыг хүсч байгаагаа илэрхийлж байна.
/// [`String`] ба [`&str`] хоёулаа `AsRef<str>`-ийг хэрэгжүүлдэг тул хоёуланг нь оролтын аргумент болгон хүлээн авах боломжтой.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Хөрвүүлэлтийг гүйцэтгэдэг.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Хямдхан өөрчлөгдөж, өөрчлөгдөж болох лавлагаа хөрвүүлэлтийг хийхэд ашигладаг.
///
/// Энэ trait нь [`AsRef`]-тэй төстэй боловч өөрчлөгдөж болох лавлагааны хооронд хөрвүүлэхэд ашиглагддаг.
/// Хэрэв та үнэтэй хөрвүүлэлт хийх шаардлагатай бол [`From`]-ийг `&mut T` төрлөөр хэрэгжүүлэх эсвэл захиалгат функц бичих нь дээр.
///
/// **Note: Энэ trait нь бүтэлгүйтэх ёсгүй **.Хэрэв хөрвүүлэлт бүтэлгүйтвэл [`Option<T>`] эсвэл [`Result<T, E>`] буцаах зориулалтын аргыг ашиглаарай.
///
/// # Ерөнхий хэрэгжилт
///
/// - `AsMut` дотоод төрөл нь өөрчлөгдөх боломжтой лавлагаа бол автоматаар хасах (жишээ нь: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Ерөнхий функцэд зориулж `AsMut`-ийг trait bound гэж ашигласнаар бид `&mut T` төрөл рүү хөрвүүлж болох бүх өөрчлөгдөж болох лавлагааг хүлээн авах боломжтой.
/// [`Box<T>`] нь `AsMut<T>`-ийг хэрэгжүүлдэг тул `&mut u64` болгон хөрвүүлж болох бүх аргументуудыг авдаг `add_one` функцийг бичиж болно.
/// [`Box<T>`] нь `AsMut<T>`-ийг хэрэгжүүлдэг тул `add_one` нь `&mut Box<u64>` төрлийн аргументуудыг хүлээн авдаг.
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Хөрвүүлэлтийг гүйцэтгэдэг.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Оролтын утгыг ашигладаг утгыг утга руу хөрвүүлэх.[`From`]-ийн эсрэг.
///
/// [`Into`]-ийг хэрэгжүүлэхээс зайлсхийж, оронд нь [`From`]-ийг хэрэгжүүлэх хэрэгтэй.
/// [`From`]-ийг хэрэгжүүлснээр стандарт номын санд хөнжил хэрэгжүүлсний ачаар [`Into`]-ийн хэрэгжилтийг автоматаар хангаж өгдөг.
///
/// Ерөнхий функц дээр trait bounds-ийг зааж өгөхдөө [`Into`]-ээс илүү [`Into`] ашиглахыг илүүд үзээрэй.
///
/// **Note: Энэ trait нь бүтэлгүйтэх ёсгүй **.Хэрэв хөрвүүлэлт амжилтгүй болбол [`TryInto`] ашиглана уу.
///
/// # Ерөнхий хэрэгжилт
///
/// - ["Эхлэл"]<T>Учир нь U` нь `Into<U> for T` гэсэн үг юм
/// - [`Into`] нь рефлекс шинжтэй бөгөөд энэ нь `Into<T> for T` хэрэгжиж байна гэсэн үг юм
///
/// # Rust-ийн хуучин хувилбаруудад гадаад төрлийг хөрвүүлэхэд зориулж [`Into`]-ийг хэрэгжүүлэх
///
/// Rust 1.41-ээс өмнө, очих газрын төрөл нь одоогийн crate-ийн хэсэг биш байсан бол та [`From`]-ийг шууд хэрэгжүүлж чадахгүй.
/// Жишээлбэл, энэ кодыг авна уу.
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Rust-ийн өнчин өгөх дүрэм журам нь арай илүү хатуу байсан тул үүнийг хэлний хуучин хувилбаруудад нэгтгэх боломжгүй болно.
/// Үүнийг тойрч гарахын тулд та [`Into`]-ийг шууд хэрэгжүүлж болно.
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// [`Into`] нь [`From`] хэрэгжилтийг хангаж чадахгүй гэдгийг ойлгох нь чухал юм ([`From`] нь [`Into`]-тэй адил).
/// Тиймээс та үргэлж [`From`]-ийг хэрэгжүүлэхийг хичээгээд [`From`] хэрэгжих боломжгүй бол буцаж [`Into`] руу унах хэрэгтэй.
///
/// # Examples
///
/// [`String`] хэрэгжүүлдэг [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Нийтлэг функцийг тодорхойлсон `T` төрөлд хөрвүүлж болох бүх аргументийг авахыг хүсч байгаагаа илэрхийлэхийн тулд бид [`Into`]"-ийн trait bound-г ашиглаж болно.<T>".
///
/// Жишээлбэл: `is_hello` функц нь [`Vec`]`<`[`u8`] `>` болгон хөрвүүлж болох бүх аргументийг авдаг.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Хөрвүүлэлтийг гүйцэтгэдэг.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Оролтын утгыг зарцуулахдаа утгын утгыг хөрвүүлэхэд ашигладаг.Энэ бол [`Into`]-ийн хариу үйлдэл юм.
///
/// `From`-ийг [`Into`] дээр хэрэгжүүлэхийг үргэлж илүүд үздэг байх ёстой, учир нь `From`-ийг хэрэгжүүлснээр стандарт номын сангийн хөнжлийн хэрэгжилтийн ачаар [`Into`]-ийн хэрэгжилтийг автоматаар хангадаг.
///
///
/// Зөвхөн Rust 1.41-ээс өмнөх хувилбарыг чиглүүлж, одоогийн crate-ээс гадуурх хэлбэрт шилжүүлэх үед [`Into`]-ийг хэрэгжүүлнэ.
/// `From` Rust-ийн өнчрөх дүрмээс болж эдгээр төрлийн хөрвүүлэлтийг өмнөх хувилбаруудад хийх боломжгүй байсан.
/// Дэлгэрэнгүй мэдээллийг [`Into`]-с авна уу.
///
/// Ерөнхий функц дээр trait bounds-ийг зааж өгөхдөө [`Into`] ашиглахаас илүү `From` ашиглахыг илүүд үзээрэй.
/// Энэ аргаар [`Into`]-ийг шууд хэрэгжүүлдэг төрлийг аргумент болгон ашиглаж болно.
///
/// `From` нь алдаатай харьцах явцад маш их хэрэгтэй байдаг.Алдаа гаргах чадвартай функцийг бүтээхдээ буцах төрөл нь ерөнхийдөө `Result<T, E>` хэлбэртэй байх болно.
/// `From` trait нь алдааны харьцуулалтыг хялбарчилж, функцэд олон алдааны төрлийг багтаасан нэг алдааны төрлийг буцааж өгөх боломжийг олгодог.Илүү дэлгэрэнгүйг "Examples" хэсэг ба [the book][book] хэсгээс үзнэ үү.
///
/// **Note: Энэ trait нь бүтэлгүйтэх ёсгүй **.Хэрэв хөрвүүлэлт амжилтгүй болбол [`TryFrom`] ашиглана уу.
///
/// # Ерөнхий хэрэгжилт
///
/// - `From<T> for U` нь T`-ийн <U>хувьд</u> [`Into`]` гэсэн үг <U>юм</u>
/// - `From` нь рефлекс шинжтэй бөгөөд энэ нь `From<T> for T` хэрэгжиж байна гэсэн үг юм
///
/// # Examples
///
/// [`String`] `From<&str>`-ийг хэрэгжүүлдэг:
///
/// `&str`-ээс String руу тодорхой хөрвүүлэлтийг дараах байдлаар хийнэ.
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Алдаатай харьцах явцад `From`-ийг өөрийн алдааны төрөлд хэрэгжүүлэх нь ихэвчлэн ашиг тустай байдаг.
/// Суурь алдааны төрлийг багтаасан өөрийн тохируулсан алдааны төрөлд үндсэн алдааны төрлийг хөрвүүлснээр үндсэн алдааны талаархи мэдээллийг алдалгүйгээр нэг алдааны төрлийг буцааж өгөх боломжтой.
/// '?' оператор нь `From` програмыг хэрэгжүүлэхэд автоматаар хангагдсан `Into<CliError>::into` руу залгаж үндсэн алдааны төрлийг манай өөрчлөн тохируулсан алдааны төрөлд автоматаар хөрвүүлдэг.
/// Дараа нь хөрвүүлэгч нь `Into`-ийн аль хэрэгжилтийг ашиглахыг зааж өгдөг.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Хөрвүүлэлтийг гүйцэтгэдэг.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// `self`-ийг ашигладаг эсвэл үнэтэй биш байж болох хөрвүүлэх оролдлого.
///
/// Номын сангийн зохиогчид ихэвчлэн энэ trait-ийг шууд хэрэгжүүлэх ёсгүй, гэхдээ илүү их уян хатан чанарыг санал болгодог [`TryFrom`] trait-ийг хэрэгжүүлэхийг илүүд үздэг бөгөөд стандарт номын санд хөнжил хэрэгжүүлсний ачаар `TryInto`-тэй дүйцэхүйц хэрэгжилтийг үнэ төлбөргүй өгдөг.
/// Энэ талаархи нэмэлт мэдээллийг [`Into`]-ийн баримтжуулалтаас үзнэ үү.
///
/// # `TryInto` хэрэгжүүлж байна
///
/// Энэ нь [`Into`]-ийг хэрэгжүүлэхтэй ижил хязгаарлалт, үндэслэлтэй тулгардаг, дэлгэрэнгүйг эндээс үзнэ үү.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Хөрвүүлэлтийн алдаа гарсан тохиолдолд төрөл нь буцаж ирэв.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Хөрвүүлэлтийг гүйцэтгэдэг.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Зарим тохиолдолд хяналттай байдлаар бүтэлгүйтдэг энгийн бөгөөд аюулгүй төрлийн хөрвүүлэлт.Энэ бол [`TryInto`]-ийн хариу үйлдэл юм.
///
/// Энэ нь үл тоомсорлож амжилтанд хүрч болох боловч тусгай боловсруулалт шаардагдах төрлийг хөрвүүлэх үед танд хэрэгтэй болно.
/// Жишээлбэл, [`i64`]-ийг [`From`] trait ашиглан [`i32`] болгон хөрвүүлэх арга байхгүй, учир нь [`i64`] нь [`i32`]-ийн илэрхийлж чадахгүй утгыг агуулж болох тул хөрвүүлэлт нь өгөгдлийг алдах болно.
///
/// Үүнийг [`i64`]-ийг [`i32`]-д тайрч (үндсэндээ [i64`-ийн утгыг [`i32::MAX`] модулийг өгөх) эсвэл [`i32::MAX`]-ийг буцааж өгөх эсвэл өөр аргаар зохицуулж болно.
/// [`From`] trait нь төгс хөрвүүлэхэд зориулагдсан тул `TryFrom` trait нь програмын төрлийг хөрвүүлэхэд хэзээ муудаж болохыг мэдэгдэж, үүнийг хэрхэн зохицуулахаа шийдэх боломжийг олгодог.
///
/// # Ерөнхий хэрэгжилт
///
/// - `TryFrom<T> for U` нь T`-ийн <U>хувьд</u> [`TryInto`]` гэсэн үг <U>юм</u>
/// - [`try_from`] нь рефлексив шинжтэй бөгөөд энэ нь `TryFrom<T> for T` хэрэгжиж байгаа бөгөөд бүтэлгүйтэх боломжгүй гэсэн үг юм-`T` төрлийн утга дээр `T::try_from()` руу залгахад холбогдох `Error` төрөл нь [`Infallible`] юм.
/// [`!`] төрөл тогтворжсон үед [`Infallible`] ба [`!`] нь тэнцүү байх болно.
///
/// `TryFrom<T>` дараах байдлаар хэрэгжүүлж болно.
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Тодорхойлсны дагуу [`i32`] нь TryFrom <`[` i64`]">`-ийг хэрэгжүүлдэг:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // `big_number`-ийг чимээгүйхэн таслана, баримтын дараа тайралтыг олж илрүүлэх хэрэгтэй.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // `big_number` нь `i32`-т багтахааргүй хэмжээтэй тул алдаа буцаана.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` буцаана.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Хөрвүүлэлтийн алдаа гарсан тохиолдолд төрөл нь буцаж ирэв.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Хөрвүүлэлтийг гүйцэтгэдэг.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ЕРӨНХИЙ БҮРТГЭЛ
////////////////////////////////////////////////////////////////////////////////

// Дахин өргөхөд
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut-ээс дээш өргөлтөөр
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): &/&mut гэсэн дээрх имплуудыг дараахь ерөнхий хувилбараар орлуул:
// // Дерефийг өргөхөд
// импл <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut нь &mut-ээс дээш өргөгддөг
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut-ийн хувьд дээрх имплийг дараахь ерөнхий хувилбараар орлуул:
// // AsMut нь DerefMut дээр өргөдөг
// импл <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Үүнээс Into гэсэн үг
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (ба ингэснээр Into) нь рефлекс шинжтэй байдаг
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Тогтвортой байдлын тэмдэглэл:** Энэ импл хараахан байхгүй байгаа боловч бид үүнийг future дээр нэмэх "reserving space" байна.
/// Дэлгэрэнгүйг [rust-lang/rust#64715][#64715]-с үзнэ үү.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): оронд нь зарчмын засвар хий.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom нь TryInto гэсэн үг юм
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Алдаагүй хөрвүүлэлт нь утга агуулгын хувьд оршин суудаггүй алдааны төрөл бүхий алдаатай хөрвүүлэлттэй тэнцдэг.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// БЕТОН БҮРТГЭЛ
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// АЛДАШГҮЙ АЛДААНЫ ТӨРӨЛ
////////////////////////////////////////////////////////////////////////////////

/// Хэзээ ч тохиолдохгүй алдааны алдааны төрөл.
///
/// Энэ enum нь өөр хувилбаргүй тул энэ төрлийн утга хэзээ ч оршин тогтнох боломжгүй юм.
/// Энэ нь үр дүн нь үргэлж [`Ok`] байгааг харуулахын тулд [`Result`] ашигладаг ба алдааны төрлийг параметрчилдэг ерөнхий API-д ашигтай байж болох юм.
///
/// Жишээлбэл, [`TryFrom`] trait ([`Result`]-ийг буцааж өгдөг хөрвүүлэлт) урвуу [`Into`] хэрэгжүүлэлт байдаг бүх төрлийн хувьд хөнжил хэрэгжүүлдэг.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future нийцтэй байдал
///
/// Энэ enum нь [the `!`“never”type][never]-тэй ижил үүрэг гүйцэтгэдэг бөгөөд энэ нь Rust хувилбарын хувьд тогтворгүй байдаг.
/// `!`-ийг тогтворжуулснаар бид `Infallible`-ийг өөр төрлийн хиймэл нэр болгохоор төлөвлөж байна.
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... эцэст нь `Infallible`-ийг ашиглахаа больсон.
///
/// Гэсэн хэдий ч `!` синтаксийг `!`-ийг бүрэн хэлбэрт оруулахаас өмнө тогтворжуулахаас өмнө ашиглаж болох нэг тохиолдол байдаг: функцийн буцах хэлбэрийн байрлалд.
/// Тодруулбал, функцын заагчийн хоёр өөр төрлийг хэрэгжүүлэх боломжтой:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` нь enum байх тул энэ код хүчинтэй болно.
/// Гэсэн хэдий ч `Infallible` нь never type-ийн нэр болж хувирахад хоёр "impl`" давхцаж эхлэх тул хэлний trait уялдаа холбооны дүрмээр зөвшөөрөхгүй.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}