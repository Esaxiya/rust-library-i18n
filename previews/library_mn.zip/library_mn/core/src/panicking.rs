//! Libcore-д зориулсан Panic дэмжлэг
//!
//! Үндсэн номын сан нь сандрахыг тодорхойлж чадахгүй, гэхдээ *тунхаглах* сандрах болно.
//! Энэ нь libcore доторх функцуудыг panic-д зөвшөөрсөн гэсэн үг боловч crate-ийн ашиг тустай байхын тулд libcore-ийг ашиглахын тулд сандрахыг тодорхойлох хэрэгтэй.
//! Одоо сандрах интерфэйс нь:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Энэ тодорхойлолт нь ямар ч ерөнхий мессежээр сандрах боломжийг олгодог боловч `Box<Any>` утгаар бүтэлгүйтэхийг зөвшөөрдөггүй.
//! (`PanicInfo` нь `&(dyn Any + Send)` агуулдаг бөгөөд үүнд бид "PanicInfo: : internal_constructor"-д дамми утгыг бөглөдөг.) Үүний шалтгаан нь libcore-ийг хуваарилах эрхгүй юм.
//!
//!
//! Энэ модуль нь сандрах бусад цөөн функцийг агуулдаг боловч эдгээр нь хөрвүүлэгчийн шаардлагатай зүйл юм.Бүх panics-ийг энэ нэг функцээр дамжуулж өгдөг.
//! Бодит тэмдгийг `#[panic_handler]` атрибутаар дамжуулан зарладаг.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Libcore-ийн `panic!` макро хэлбэржүүлэлт хийгдэхгүй байх үеийн суурь хэрэгжилт.
#[cold]
// дуудлагын сайтууд дээр аль болох кодыг хавагнахаас зайлсхийхийн тулд panic_immediate_abort хийхээс нааш хэзээ ч бүү оруул
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // халих болон бусад `Assert` MIR терминаторууд дээр panic-д зориулж codegen-т шаардлагатай
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Format_args-ийн оронд Arguments::new_v1 ашигла! ("{}", Expr) нэмэлт ачааллыг багасгах боломжтой.
    // Format_args!макро нь str-ийн Display trait-ийг expr бичихэд ашигладаг бөгөөд Formatter::pad-г дууддаг бөгөөд үүнд мөр таслах ба дүүргэлтийг багтаасан байх ёстой (гэхдээ энд ашиглагдаагүй ч гэсэн).
    //
    // Arguments::new_v1 ашиглах нь хөрвүүлэгчийг гаралтын хоёртын хувилбараас хасахад хэдэн килобайт хүртэл хэмнэх боломжийг олгоно.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // const-үнэлгээтэй panics-д шаардлагатай
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice хандалт дээр panic-д зориулж codegen-д шаардлагатай
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Libcore-ийн `panic!` макро хэлбэршүүлэлт хийх үед хэрэгжүүлж буй үндсэн аргыг ашиглаж байна.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Тэмдэглэл Энэ функц нь FFI-ийн хил хязгаарыг хэзээ ч давахгүй;Энэ бол `#[panic_handler]` функцэд тохирсон Rust-Rust дуудлага юм.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // АЮУЛГҮЙ БАЙДАЛ: `panic_impl` нь аюулгүй Rust кодоор тодорхойлогдсон тул дуудлага хийхэд аюулгүй байдаг.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` ба `assert_ne!` макросуудын дотоод функц
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}