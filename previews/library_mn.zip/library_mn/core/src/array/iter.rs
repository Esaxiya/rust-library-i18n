//! Массивын хувьд `IntoIter` эзэмшдэг давталтыг тодорхойлдог.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// [array] давталтын утга.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Энэ бол бидний давтаж байгаа массив юм.
    ///
    /// `i` индекс бүхий `alive.start <= i < alive.end` хараахан гараагүй байгаа бөгөөд хүчинтэй массив оруулгатай элементүүд.
    /// `i < alive.start` эсвэл `i >= alive.end` индекстэй элементүүд аль хэдийн гарчихсан байгаа тул дахиж хандах боломжгүй болно!Эдгээр үхсэн элементүүд нь бүрэн эхлээгүй байдалд байж магадгүй юм!
    ///
    ///
    /// Тэгэхээр инвариантууд нь:
    /// - `data[alive]` амьд байна (өөрөөр хэлбэл хүчин төгөлдөр элемент агуулсан)
    /// - `data[..alive.start]` ба `data[alive.end..]` нь үхсэн байна (өөрөөр хэлбэл элементүүд нь аль хэдийн уншигдсан байсан тул дахин хүрч болохгүй!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` дээрх хараахан гараагүй байгаа элементүүд.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Өгөгдсөн `array` дээр шинэ давталт үүсгэдэг.
    ///
    /// *Тэмдэглэл*:[`IntoIterator` is implemented for arrays][array-into-iter]-ийн дараа future дээр энэ аргыг хүчингүй болгож магадгүй юм.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value`-ийн төрөл нь `&i32`-ийн оронд `i32` юм
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // АЮУЛГҮЙ БАЙДАЛ: Энд шилжүүлсэн нь аюулгүй юм.`MaybeUninit`-ийн баримт бичиг
        // promise:
        //
        // > `MaybeUninit<T>` ижил хэмжээтэй, зэрэгцүүлэлттэй байх баталгаатай болно
        // > `T` байдлаар.
        //
        // Доксууд нь `MaybeUninit<T>` массиваас `T` массив руу шилжиж байгааг харуулдаг.
        //
        //
        // Үүний ачаар энэхүү эхлүүлэлт нь хувьсагчдыг хангаж өгдөг.

        // FIXME(LukasKalbertodt): үнэхээр `mem::transmute`-ийг энд ашиглах хэрэгтэй.
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Тэр болтол бид `mem::transmute_copy`-ийг ашиглан битийн хувилбарыг өөр төрлөөр үүсгэж дараа нь унагаахгүйн тулд `array`-ийг мартаж болно.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Одоохондоо гараагүй байгаа бүх элементүүдийн хувиршгүй зүсмэлийг буцаана.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // АЮУЛГҮЙ БАЙДАЛ: `alive` доторх бүх элементүүдийг зөв эхлүүлсэн гэдгийг бид мэднэ.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Одоохондоо хараахан гараагүй байгаа бүх элементийн өөрчлөгдөж болох зүсмэлийг буцаана.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // АЮУЛГҮЙ БАЙДАЛ: `alive` доторх бүх элементүүдийг зөв эхлүүлсэн гэдгийг бид мэднэ.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Дараагийн индексийг урд талаас нь аваарай.
        //
        // `alive.start`-ийг 1-ээр ихэсгэх нь `alive`-тай холбоотой өөрчлөгдөхгүй байдлыг хадгална.
        // Гэсэн хэдий ч энэхүү өөрчлөлтийн улмаас богино хугацаанд амьд бүс `data[alive]` биш харин `data[idx..alive.end]` болжээ.
        //
        self.alive.next().map(|idx| {
            // Массиваас элементийг уншина уу.
            // АЮУЛГҮЙ АЖИЛЛАГАА: `idx` бол хуучин "alive" мужид хамаарах индекс юм
            // массив.Энэ элементийг унших нь `data[idx]`-ийг одоо үхсэн гэж үзэж байна гэсэн үг (өөрөөр хэлбэл хүрч болохгүй).
            // `idx` нь амьд бүсийн эхлэл байсан тул амьд бүс дахин `data[alive]` болж, бүх хувьсагчдыг сэргээж байна.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Дараагийн индексийг ар талаас нь аваарай.
        //
        // `alive.end`-ийг 1-ээр бууруулах нь `alive`-тай холбоотой өөрчлөгдөхгүй байдлыг хадгална.
        // Гэсэн хэдий ч энэхүү өөрчлөлтийн улмаас богино хугацаанд амьд бүс `data[alive]` биш харин `data[alive.start..=idx]` болжээ.
        //
        self.alive.next_back().map(|idx| {
            // Массиваас элементийг уншина уу.
            // АЮУЛГҮЙ АЖИЛЛАГАА: `idx` бол хуучин "alive" мужид хамаарах индекс юм
            // массив.Энэ элементийг унших нь `data[idx]`-ийг одоо үхсэн гэж үзэж байна гэсэн үг (өөрөөр хэлбэл хүрч болохгүй).
            // `idx` нь амьд бүсийн төгсгөл байсан тул амьд бүс дахин `data[alive]` болж, бүх хувьсагчдыг сэргээж байна.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // АЮУЛГҮЙ БАЙДАЛ: Энэ нь аюулгүй: `as_mut_slice` нь яг дэд зүсэлтийг буцааж өгдөг
        // хараахан зөөгдөөгүй байгаа бөгөөд хасах хэвээр байгаа элементүүдийн.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // "Live.start <=өөрчлөгдөхгүй тул хэзээ ч урсахгүй
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Давталт нь зөв уртыг үнэхээр тайлагнадаг.
// "alive" элементийн тоо (гарсаар байх болно) бол `alive` мужийн урт юм.
// Энэ мужийг `next` эсвэл `next_back`-ийн аль алинд нь багасгасан.
// Эдгээр аргуудад үүнийг үргэлж 1-ээр бууруулдаг боловч зөвхөн `Some(_)`-ийг буцааж өгсөн тохиолдолд л өгдөг.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Бид яг ижил хэмжээтэй яг таарч тохирох шаардлага байхгүй тул `self` хаана байгаагаас үл хамааран 0-ийг офсет болгож клон хийж болно.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Бүх амьд элементүүдийг хуулбарлах.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Шинэ массив руу клоноо бичээд, түүний мужийг шинэчил.
            // Хэрэв panics-ийг клончлох юм бол бид өмнөх зүйлийг зөв хаях болно.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Зөвхөн хараахан гараагүй байгаа элементүүдийг л хэвлэ: бид цаашид өгөгдсөн элементүүдэд хандах боломжгүй.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}