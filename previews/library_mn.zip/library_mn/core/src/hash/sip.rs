//! SipHash програм.

#![allow(deprecated)] // энэ модулийн төрлүүд хуучирсан болно

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// SipHash 1-3-ийн хэрэгжилт.
///
/// Энэ нь одоогоор стандарт номын сангийн ашигладаг анхдагч хэш функц юм (жишээлбэл, `collections::HashMap` үүнийг анхдагчаар ашигладаг).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// SipHash 2-4 програмыг хэрэгжүүлэх.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// SipHash 2-4 програмыг хэрэгжүүлэх.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash бол ерөнхий зориулалтын хэш функц юм: сайн хурдтай ажилладаг (Spooky ба City-тай өрсөлдөх чадвартай) бөгөөд хүчтэй _keyed_ хэш хийхийг зөвшөөрдөг.
///
/// Энэ нь [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) гэх мэт хүчтэй RNG-ээс хэш хүснэгтүүдийг түлхүүр болгох боломжийг танд олгоно.
///
/// SipHash алгоритм нь ерөнхийдөө хүчтэй гэж тооцогддог боловч энэ нь криптографийн зорилгоор хийгдээгүй болно.
/// Иймээс энэхүү хэрэгжилтийн бүх криптографийн хэрэглээ нь _strongly discouraged_ юм.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // бид хичнээн байт боловсруулсан бэ?
    state: State,  // хэш муж
    tail: u64,     // боловсруулаагүй байт le
    ntail: usize,  // сүүл дэх хэдэн байт хүчинтэй байна
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 ба v1, v3 нь алгоритмдаа хосоороо гарч ирдэг бөгөөд SipHash-ийн simd програмууд нь v02 ба v13-ийн vectors-ийг ашиглах болно.
    //
    // Тэдгээрийг бүтцэд ийм дарааллаар байрлуулснаар хөрвүүлэгч хэдхэн симд оновчлолыг дангаар нь авах боломжтой.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Хүссэн төрлийн бүхэл тоог LE дарааллаар байтын урсгалаас ачаална.
/// `copy_nonoverlapping`-ийг ашиглан хөрвүүлэгчийг тохиргоогүй хаягаас ачаалах хамгийн үр дүнтэй аргыг бий болгох боломжийг олгодог.
///
///
/// Аюулгүй, учир нь: i..i+size_of(int_ty) дээр шалгагдаагүй индексжүүлэлт
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// 7 байт хүртэлх зүсмэлийг ашиглан u64-ийг ачаална.
/// Энэ нь болхи харагдаж байгаа боловч гарч ирдэг `copy_nonoverlapping` дуудлага (`load_int_le!`-ээр дамжин) бүгд тогтсон хэмжээтэй тул `memcpy` руу залгахаас зайлсхийх нь хурданд сайнаар нөлөөлдөг.
///
///
/// Аюулгүй, учир нь: эхлэхэд шалгагдаагүй индексжүүлэлт..start + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // одоогийн байтын индекс (LSB-ээс) гаралтын u64
    let mut out = 0;
    if i + 3 < len {
        // АЮУЛГҮЙ БАЙДАЛ: `i` нь `len`-ээс их байж болохгүй бөгөөд дуудлага өгсөн хүн баталгаа өгөх ёстой
        // индекс эхлэх..start + len хязгаарлагдмал байна.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // Аюулгүй байдал: дээрхтэй ижил.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // Аюулгүй байдал: дээрхтэй ижил.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Эхний хоёр товчлуурыг 0 болгож тохируулсан шинэ `SipHasher` үүсгэдэг.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Өгөгдсөн түлхүүрүүд дээр дарагдсан `SipHasher` үүсгэдэг.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Эхний хоёр товчлуурыг 0 болгож тохируулсан шинэ `SipHasher13` үүсгэдэг.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Өгөгдсөн түлхүүрүүд дээр дарагдсан `SipHasher13` үүсгэдэг.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: бүхэл тоогоор хэш хийх аргыг тодорхойлоогүй (`write_u *`, `write_i*`)
    // энэ төрлийн хувьд.
    // Бид тэдгээрийг нэмж, `short_write` програмыг librustc_data_structures/sip128.rs дээр хуулж, `SipHasher`, `SipHasher13`, `DefaultHasher` дээр `write_u *`/`write_i*` аргуудыг нэмж болно.
    //
    // Энэ нь зарим жишиг дээрх хөрвүүлэлтийн хурдыг бага зэрэг удаашруулах зардлаар эдгээр хэшүүдийн бүхэл тоогоор хэш хийхийг ихээхэн хурдасгах болно.
    // Дэлгэрэнгүйг #69152-с үзнэ үү.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // АЮУЛГҮЙ БАЙДАЛ: `cmp::min(length, needed)` нь `length`-ээс хэтрэхгүй байх баталгаа юм
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Буфержуулсан сүүл нь одоо угааж байна, шинэ оролтыг боловсруулна уу.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // АЮУЛГҮЙ БАЙДАЛ: `len - left` бол 8-ийн хамгийн том үржүүлэгч юм
            // `len`, `i` нь `needed`-ээс эхэлдэг тул `len` нь `length - needed` тул `i + 8` нь `length`-ээс бага эсвэл тэнцүү байх баталгаатай болно.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // АЮУЛГҮЙ БАЙДАЛ: `i` нь одоо `needed + len.div_euclid(8) * 8`,
        // `i + left` = `needed + len` = `length`, энэ нь `msg.len()`-тэй тэнцүү байна.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// 0-ийг тохируулсан анхны хоёр түлхүүрээр `Hasher<S>` үүсгэдэг.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}