//! Libcore prelude
//!
//! Энэ модуль нь libcore-той холбодоггүй libcore хэрэглэгчдэд зориулагдсан болно.
//! Энэ модулийг стандарт номын сангийн prelude-тэй адил `#![no_std]` ашиглаж байх үед анхдагчаар импортлодог.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// prelude цөмийн 2015 оны хувилбар.
///
/// Дэлгэрэнгүйг [module-level documentation](self)-с үзнэ үү.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude цөмийн 2018 оны хувилбар.
///
/// Дэлгэрэнгүйг [module-level documentation](self)-с үзнэ үү.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude цөмийн 2021 оны хувилбар.
///
/// Дэлгэрэнгүйг [module-level documentation](self)-с үзнэ үү.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Илүү их зүйл нэмнэ үү.
}