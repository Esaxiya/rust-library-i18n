//! Залхуу утга ба статик өгөгдлийг нэг удаа эхлүүлэх.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Зөвхөн нэг удаа бичих боломжтой нүд.
///
/// `RefCell`-ээс ялгаатай нь `OnceCell` нь зөвхөн түүний утгын талаар хуваалцсан `&T` лавлагаа өгдөг.
/// `Cell`-ээс ялгаатай нь `OnceCell` нь түүнд хандахын тулд утгыг хуулах эсвэл солих шаардлагагүй болно.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Хувьсашгүй: хамгийн ихдээ нэг удаа бичсэн.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Шинэ хоосон нүд үүсгэдэг.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Суурь утгын лавлагаа авах.
    ///
    /// Хэрэв нүд хоосон байвал `None` буцаана.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // АЮУЛГҮЙ БАЙДАЛ: "дотоод" нь өөрчлөгдөхгүй тул аюулгүй
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Суурь утгын хувьд өөрчлөгдөж болох лавлагааг авна.
    ///
    /// Хэрэв нүд хоосон байвал `None` буцаана.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // АЮУЛГҮЙ БАЙДАЛ: Бид өвөрмөц хандалттай тул аюулгүй
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Нүдний агуулгыг `value` болгож тохируулна.
    ///
    /// # Errors
    ///
    /// Энэ арга нь нүд хоосон байсан бол `Ok(())`, хэрэв дүүрсэн бол `Err(value)`-ийг буцаана.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // АЮУЛГҮЙ БАЙДАЛ: Бид өөрчлөгдөж болохуйц зээл авах боломжгүй тул аюулгүй
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // АЮУЛГҮЙ АЖИЛЛАГАА: Энэ бол уралдаан тэмцээн хийхгүйгээр цоорхойг байрлуулдаг цорын ганц газар юм
        // reentrancy/concurrency-ийн улмаас боломжтой бөгөөд бид одоогоор `None` оролт байгаа эсэхийг шалгасан тул энэ бичвэр нь "дотоод"-ын өөрчлөгдөхгүй чанарыг хадгална.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Нүдний агуулгыг авч, хэрэв нүд хоосон байвал `f`-ээр эхлүүлнэ.
    ///
    /// # Panics
    ///
    /// Хэрэв `f` panics бол panic нь дуудагч руу тархаж, эс нь эхлээгүй хэвээр үлдэнэ.
    ///
    ///
    /// `f`-ээс нүдийг дахин эхлүүлэх нь алдаа юм.Ингэснээр panic гарч ирдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Нүдний агуулгыг авч, хэрэв нүд хоосон байвал `f`-ээр эхлүүлнэ.
    /// Хэрэв нүд хоосон байсан бөгөөд `f` бүтэлгүйтсэн бол алдаа буцаагдана.
    ///
    /// # Panics
    ///
    /// Хэрэв `f` panics бол panic нь дуудагч руу тархаж, эс нь эхлээгүй хэвээр үлдэнэ.
    ///
    ///
    /// `f`-ээс нүдийг дахин эхлүүлэх нь алдаа юм.Ингэснээр panic гарч ирдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // *Зарим* дахин эхлүүлэх хэлбэрүүд нь UB руу хүргэж болзошгүйг анхаарна уу (`reentrant_init` тестийг үзнэ үү).
        // Энэ `assert`-ийг устгахад л `set/get`-ийг хадгалах нь оновчтой байх болно гэдэгт би итгэж байна, гэхдээ panic-д хуучин утгыг чимээгүй ашиглахаас илүү дээр юм шиг санагдаж байна.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Ороосон утгыг буцааж нүдийг зарцуулна.
    ///
    /// Хэрэв нүд хоосон байсан бол `None` буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // `into_inner` нь `self`-ийг утгаар нь авдаг тул хөрвүүлэгч нь одоогоор зээллэгдээгүй гэдгийг статикаар баталгаажуулдаг.
        // Тиймээс `Option<T>`-ээс гарах нь аюулгүй юм.
        self.inner.into_inner()
    }

    /// Энэ `OnceCell`-ийн утгыг буцааж эхлүүлээгүй төлөв рүү шилжүүлнэ.
    ///
    /// Хэрэв `OnceCell`-ийг эхлүүлээгүй бол ямар ч нөлөө үзүүлэхгүй бөгөөд `None` буцаана.
    ///
    /// Аюулгүй байдал нь өөрчлөгдөх боломжтой лавлагаа шаардах замаар баталгааждаг.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Эхний хандалт дээр эхлүүлсэн утга.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   бэлэн эхлүүлэх
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Өгөгдсөн эхлүүлэх функцээр шинэ залхуу утгыг бий болгодог.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Энэхүү залхуу утгын үнэлгээг албадаж, үр дүнгийн талаархи лавлагааг буцаана.
    ///
    ///
    /// Энэ нь `Deref` импл-тэй дүйх боловч тодорхой байна.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// `Default`-ийг эхлүүлэх функц болгон ашиглаж шинэ залхуу утгыг бий болгодог.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}