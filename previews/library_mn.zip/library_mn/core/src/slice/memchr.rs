// Жинхэнэ хэрэгжилтийг rust-memchr-ээс авав.
// Зохиогчийн эрх 2015 Эндрю Галлант, блюс, Николас Кох

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Таслалтыг ашигла.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Хэрэв `x` нь ямар ч тэг байт агуулсан бол `true` буцаана.
///
/// *Matters Computational*-аас, Ж.Арндт:
///
/// "Энэ санаа нь байт тус бүрээс нэгийг хасаад дараа нь зээл хамгийн их утга хүртлээ тархсан байтыг хайх явдал юм.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` дахь байт `x`-тэй тохирох эхний индексийг буцаана.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Жижиг зүсмэлүүдэд зориулсан хурдан зам
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Нэг удаа хоёр `usize` үг уншаад нэг байтын утгыг хайж олох.
    //
    // `text`-ийг гурван хэсэгт хуваана
    // - тохируулагдаагүй эхний хэсэг, текстийн хаягийн зэрэгцсэн эхний үгийн өмнө
    // - бие, нэг удаад 2 үгээр сканнердах
    // - сүүлчийн үлдсэн хэсэг, <2 үгийн хэмжээ

    // тохируулсан хил хязгаар хүртэл хайх
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // текстийн үндсэн хэсгийг хайх
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // АЮУЛГҮЙ БАЙДАЛ: while-ийн урьдчилсан утга нь дор хаяж 2 * usize_bytes зайг баталгаажуулдаг
        // офсет ба зүсмэлийн төгсгөлийн хооронд.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // тохирох байт байгаа бол завсарлага
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Биеийн гогцоо зогссон цэгийн дараа байтыг ол.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` дахь байт `x`-тэй тохирсон сүүлийн индексийг буцаана.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Нэг удаа хоёр `usize` үг уншаад нэг байтын утгыг хайж олох.
    //
    // Split `text`-ийг гурван хэсэгт хуваана.
    // - сүүлчийн үгийн дараа текстэнд зэрэгцүүлсэн хаяг,
    // - бие, нэг дор 2 үгээр сканнердсан,
    // - эхний үлдсэн байт, <2 үгийн хэмжээ.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Бид үүнийг угтвар ба дагаварын уртыг олж авахын тулд л нэрлэдэг.
        // Дунд хэсэгт бид хоёр хэсгийг нэг дор үргэлж боловсруулдаг.
        // АЮУЛГҮЙ БАЙДАЛ: `[u8]`-ийг `[usize]` руу шилжүүлэх нь `align_to`-ийн зохицуулдаг хэмжээнээс бусад тохиолдолд аюулгүй байдаг.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Текстийн үндсэн хэсгээс хайж, бид min_aligned_offset-ийг гатлахгүй байхыг анхаарна уу.
    // офсет нь үргэлж тохирч байдаг тул зөвхөн `>`-ийг турших нь хангалттай бөгөөд халихаас сэргийлдэг.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // АЮУЛГҮЙ БАЙДАЛ: офсет нь len, suffix.len()-ээс их байвал л эхэлнэ
        // X_(prefix.len())-ийн үлдсэн зай нь дор хаяж 2 * ширхэг_байт байна.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Таарах байт байгаа бол завсарла.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Биеийн гогцоо зогсох цэгээс өмнө байтыг ол.
    text[..offset].iter().rposition(|elt| *elt == x)
}