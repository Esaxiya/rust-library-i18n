// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` мужийг `mid` дээрх элемент эхний элемент болохын тулд эргүүлнэ.Үүнтэй адил `left` элементүүдийг зүүн тийш буюу `right` элементүүдийг баруун тийш эргүүлнэ.
///
/// # Safety
///
/// Тодорхойлсон хүрээ нь унших, бичихэд хүчинтэй байх ёстой.
///
/// # Algorithm
///
/// Алгоритм 1 нь `left + right`-ийн бага утга эсвэл том `T`-д ашиглагддаг.
/// Элементүүдийг `mid - left`-ээс эхлэн нэг нэгээр нь эцсийн байрлалд нь шилжүүлж `left + right` модулийн `left + right` алхамуудаар урагшлуулах бөгөөд ингэснээр зөвхөн нэг түр зуурын шаардлагатай болно.
/// Эцэст нь бид `mid - left` дээр буцаж ирдэг.
/// Гэсэн хэдий ч, хэрэв `gcd(left + right, right)` нь 1 биш бол дээрх алхмууд элементүүдийг алгасах болно.
/// Жишээлбэл:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Аз болоход эцсийн элементүүдийн хоорондох алгассан элементүүдийн тоо үргэлж тэнцүү байдаг тул бид эхний байрлалаа сольж, илүү олон тойрог хийж болно (нийт тойргийн тоо `gcd(left + right, right)` value) байна).
///
/// Эцсийн үр дүн нь бүх элементүүдийг нэг удаа, зөвхөн нэг удаа эцэслэх болно.
///
/// Алгоритм 2 нь `left + right` том боловч `min(left, right)` нь стек буферт багтахаар бага бол ашиглагдана.
/// `min(left, right)` элементүүдийг буферт хуулж, `memmove`-ийг бусдад түрхэж, буфер дээрх элементүүдийг үүссэн газрынхаа эсрэг талын нүх рүү буцааж шилжүүлнэ.
///
/// Векторжуулж болох алгоритмууд нь `left + right` хангалттай том болсны дараа дээрхээс давж гардаг.
/// Алгоритм 1-ийг олон удаа тойрч, нэг дор гүйцэтгэх замаар векторжуулж болох боловч `left + right` бол асар их дугуй гарах хүртэл дунджаар цөөн тооны тойрог байдаг бөгөөд ганц тойргийн хамгийн муу тохиолдол үргэлж байдаг.
/// Үүний оронд 3-р алгоритм нь `min(left, right)` элементүүдийг эргүүлэх жижиг асуудал үлдэх хүртэл олон удаа сольж ашигладаг.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right`-ийн оронд солих нь зүүнээс гарна.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. Хэрэв эдгээр тохиолдлуудыг шалгаагүй бол доорх алгоритмууд бүтэлгүйтэх болно
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Алгоритм 1 Microbenchmarks нь санамсаргүй ээлжийн дундаж гүйцэтгэл нь `left + right == 32` хүртэл бүхэлдээ илүү сайн байгааг харуулж байгаа боловч хамгийн муу үзүүлэлт нь 16 хүртэл зөрдөг.
            // 24-ийг дундын хувилбараар сонгов.
            // Хэрэв `T` хэмжээ нь 4 `usize`s-ээс их байвал энэ алгоритм нь бусад алгоритмуудаас давж гардаг.
            //
            //
            let x = unsafe { mid.sub(left) };
            // эхний шатны эхлэл
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)`-ийг тооцоолох замаар гараас нь өмнө олж болно, гэхдээ gcd-ийг гаж нөлөө гэж тооцдог нэг давталт хийгээд дараа нь үлдсэн хэсгийг нь хийх нь илүү хурдан байдаг.
            //
            //
            let mut gcd = right;
            // жишиг үзүүлэлтүүдээс харахад түр зуурын нэгийг уншаад, хойш нь хуулж аваад эцэст нь түр зуурынхыг бичихийн оронд түр зуурын хугацааг солих нь илүү хурдан байдаг.
            // Энэ нь түр зуурын цагийг солих эсвэл солих нь хоёрыг удирдахын оронд циклийн зөвхөн нэг санах ойн хаягийг ашигладагтай холбоотой байж болох юм.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i`-ийг ихэсгэж, дараа нь хил хязгаараас гадуур байгаа эсэхийг шалгахын оронд `i` дараагийн нэмэгдэл дээр хил хязгаараас гарах эсэхийг шалгана.
                // Энэ нь заагч эсвэл `usize`-ийг боохоос сэргийлдэг.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // эхний тойргийн төгсгөл
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // хэрэв `left + right >= 15` бол энэ болзолт энд байх ёстой
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // хэсгийг илүү олон дугуйгаар дуусга
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` нь тэг хэмжээтэй төрөл биш тул хэмжээгээр нь хуваахад гэмгүй.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Алгоритм 2 Энд байгаа `[T; 0]` нь T-тэй нийцэж байгааг баталгаажуулах явдал юм
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Алгоритм 3 Энэ солилцооны өөр нэг арга байдаг бөгөөд энэ алгоритмын хамгийн сүүлчийн своп хаана байх вэ, зэргэлдээ хэсгүүдийг энэ алгоритм шиг солихын оронд тэр сүүлчийн хэсгийг ашиглан солих хэрэгтэй, гэхдээ энэ арга нь илүү хурдан хэвээр байна.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Алгоритм 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}