//! ASCII `[u8]` дээрх үйлдлүүд.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Энэ зүсэлтийн бүх байт ASCII хязгаарт байгаа эсэхийг шалгана.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Хоёр зүсмэл нь ASCII-ийн тохиолдол мэдрэмжгүй таарч байгаа эсэхийг шалгана.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)`-тэй адил боловч түр зуурын хуваарилалт, хуулахгүйгээр.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Энэ зүсмэлийг оронд нь том хэмжээтэй ASCII том үсэг болгон хөрвүүлдэг.
    ///
    /// 'a'-ээс 'z' хүртэлх ASCII үсгийг 'A'-'Z' гэж буулгасан боловч ASCII бус үсэг өөрчлөгдөөгүй болно.
    ///
    /// Одоо байгаа утгыг өөрчлөхгүйгээр шинэ дээд үсгийг буцаахын тулд [`to_ascii_uppercase`] ашиглана уу.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Энэ зүсмэлийг оронд нь том хэмжээтэй ASCII жижиг үсэгт хөрвүүлдэг.
    ///
    /// 'A'-ээс 'Z' хүртэлх ASCII үсгийг 'a'-'z' гэж буулгасан боловч ASCII бус үсэг өөрчлөгдөөгүй болно.
    ///
    /// Одоо байгаа утгыг өөрчлөхгүйгээр шинэ жижиг утгыг буцаахын тулд [`to_ascii_lowercase`] ашиглана уу.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` гэсэн үгний байт нь nonascii (>=128) байвал `true` буцаана.
/// utf8-тэй ижил төстэй зүйл хийдэг `../str/mod.rs`-ээс Snarfed.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Нэг цагт нэг удаа ашиглахын оронд usize-at үйлдлүүдийг ашиглах боломжтой ASCII тестийг оновчтой болгосон (боломжтой бол).
///
/// Бидний энд ашигладаг алгоритм нь маш энгийн.Хэрэв `s` хэтэрхий богино бол бид байт бүрийг шалгаж, үүнийг хийх хэрэгтэй.Үгүй бол:
///
/// - Эхний үгийг тохируулаагүй ачаалалтай уншина уу.
/// - Заагчийг тэгшлээд дараачийн үгсийг тохируулсан ачаалалтай дуустал уншина уу.
/// - `s`-ээс сүүлийн `usize`-ийг тохируулаагүй ачаалалтай уншина уу.
///
/// Хэрэв эдгээр ачааллын аль нэг нь `contains_nonascii` (above)-ийг буцааж өгөх ямар нэгэн зүйлийг бий болговол бид хариулт нь худлаа гэдгийг бид мэднэ.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Хэрэв бид цаг тухай бүрт нь хэрэгжүүлснээс юу ч олж авахгүй бол скаляр гогцоонд буцаж орно уу.
    //
    // `size_of::<usize>()` нь `usize`-т хангалттай тохирохгүй байгаа архитектурын хувьд бид үүнийг хийдэг, учир нь энэ нь хачин edge тохиолдол юм.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Бид `align_offset` гэсэн утгатай эхний эгнээний эгнээг үргэлж уншдаг
    // 0, бид ижил утгыг уншилтын хувьд унших болно.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // АЮУЛГҮЙ БАЙДАЛ: Дээрх `len < USIZE_SIZE`-ийг баталгаажуулдаг.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Бид үүнийг зарим талаар далд хэлбэрээр шалгасан.
    // `offset_to_aligned` нь `align_offset` эсвэл `USIZE_SIZE` хоёулаа хоёулаа дээр дурьдсан болохыг анхаарна уу.
    //
    debug_assert!(offset_to_aligned <= len);

    // Аюулгүй байдал: word_ptr бол бидний уншихад ашигладаг (зөв зэрэгцүүлсэн) usize ptr юм
    // зүсмэлийн дунд хэсэг.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` нь давталтын төгсгөлийн шалгалтанд ашигладаг `word_ptr`-ийн байтын индекс юм.
    let mut byte_pos = offset_to_aligned;

    // Паранойя нь уялдааны талаар шалгаж үзээрэй, учир нь бид олон тооны тохируулаагүй ачааллыг хийх гэж байна.
    // Практик дээр энэ нь `align_offset` дахь алдааг хориглох боломжгүй байх ёстой.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Дараа нь сүүлд сүүлд хийсэн сүүлд зэрэгцсэн үгийг оруулалгүйгээр сүүлд зэрэгцүүлсэн үг хүртэл дараагийн үгсийг уншаад сүүл нь үргэлж хамгийн ихдээ нэг `usize` байхаас гадна нэмэлт branch `byte_pos == len` байх ёстой.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Унших заалт хязгаарлагдмал эсэхийг эрүүл ухаанаар шалгах
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // `byte_pos`-ийн талаархи бидний таамаглал биелж байна.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // АЮУЛГҮЙ АЖИЛЛАГАА: Бид `word_ptr`-ийг зөв тохируулсан гэдгийг мэддэг
        // `align_offset`), бид `word_ptr` ба төгсгөлийн хооронд хангалттай байттай гэдгээ мэддэг
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // АЮУЛГҮЙ БАЙДАЛ: `byte_pos <= len - USIZE_SIZE` гэдгийг бид мэднэ
        // энэ `add`-ийн дараа `word_ptr` нь хамгийн дээд тал нь эцсийн эцэст байх болно.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Зөвхөн ганц `usize` үлдсэн эсэхийг шалгах эрүүл мэндийн шалгалт.
    // Энэ нь бидний давталтын нөхцлөөр баталгаажсан байх ёстой.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // АЮУЛГҮЙ БАЙДАЛ: Энэ нь `len >= USIZE_SIZE` дээр тулгуурладаг бөгөөд үүнийг бид эхнээс нь шалгаж үздэг.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}