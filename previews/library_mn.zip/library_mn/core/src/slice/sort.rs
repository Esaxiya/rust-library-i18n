//! Зүсмэлүүдийг ангилах
//!
//! Энэхүү модуль нь Орсон Питерсийн хэв загварыг ялсан киксорт дээр үндэслэн ялгах алгоритмыг агуулдаг. <https://github.com/orlp/pdqsort>
//!
//!
//! Тогтворгүй эрэмбэлэлт нь libcore-тэй нийцтэй байдаг тул санах ой хуваарилдаггүй тул бидний тогтвортой эрэмбэлэх хэрэгжилтээс ялгаатай юм.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Буулгахад `src`-ээс `dest` руу хуулна.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // АЮУЛГҮЙ БАЙДАЛ: Энэ бол туслах анги юм.
        //          Зөв эсэхийг нь ашиглахын тулд ашиглана уу.
        //          Тухайлбал, `src` ба `dst` нь `ptr::copy_nonoverlapping`-ийн шаардлагын дагуу давхцахгүй гэдэгт итгэлтэй байх ёстой.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Илүү их эсвэл тэнцүү элемент таарах хүртэл эхний элементийг баруун тийш шилжүүлнэ.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // АЮУЛГҮЙ АЖИЛЛАГАА: Доорхи аюултай үйлдлүүдэд хязгаарлалтгүй индексжүүлэлт орно (`get_unchecked` ба `get_unchecked_mut`)
    // болон (`ptr::copy_nonoverlapping`) санах ойг хуулах.
    //
    // а.Индексжүүлэх:
    //  1. Бид массивын хэмжээг>=2 болгож шалгасан.
    //  2. Бидний хийх бүх индексжүүлэлт нь хамгийн ихдээ {0 <= index < len} хооронд үргэлж байдаг.
    //
    // б.Санах ойн хуулбар
    //  1. Бид хүчинтэй байх баталгаатай лавлагааны лавлагаа авч байна.
    //  2. Бид зүсмэлийн ялгаатай индексийг зааж өгдөг тул тэдгээр нь давхцаж чадахгүй.
    //     Тухайлбал, `i` ба `i-1`.
    //  3. Хэрэв зүсмэлийг зөв тааруулсан бол элементүүдийг зөв тааруулна.
    //     Зүсмэлийг зөв тааруулах эсэхийг шалгах нь дуудлага хийгчийн үүрэг юм.
    //
    // Илүү дэлгэрэнгүйг доорхи тайлбаруудаас үзнэ үү.
    unsafe {
        // Хэрэв эхний хоёр элемент нь дэг журамгүй бол ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Эхний элементийг стекээр хуваарилагдсан хувьсагч болгон унших.
            // Хэрэв panics харьцуулалтын дараах үйлдлийг хийвэл `hole` унаж элементийг автоматаар зүсэлт рүү бичнэ.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // "I`-р" элементийг нэг газар зүүн тийш хөдөлгөн нүхийг баруун тийш шилжүүлнэ.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` унаж улмаар `tmp`-ийг `v`-ийн үлдсэн нүх рүү хуулна.
        }
    }
}

/// Сүүлийн элементийг бага буюу тэнцүү элементтэй тулгарах хүртэл зүүн тийш шилжүүлнэ.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // АЮУЛГҮЙ АЖИЛЛАГАА: Доорхи аюултай үйлдлүүдэд хязгаарлалтгүй индексжүүлэлт орно (`get_unchecked` ба `get_unchecked_mut`)
    // болон (`ptr::copy_nonoverlapping`) санах ойг хуулах.
    //
    // а.Индексжүүлэх:
    //  1. Бид массивын хэмжээг>=2 болгож шалгасан.
    //  2. Бидний хийх бүх индексжүүлэлт нь хамгийн ихдээ `0 <= index < len-1` хооронд үргэлж байдаг.
    //
    // б.Санах ойн хуулбар
    //  1. Бид хүчинтэй байх баталгаатай лавлагааны лавлагаа авч байна.
    //  2. Бид зүсмэлийн ялгаатай индексийг зааж өгдөг тул тэдгээр нь давхцаж чадахгүй.
    //     Тухайлбал, `i` ба `i+1`.
    //  3. Хэрэв зүсмэлийг зөв тааруулсан бол элементүүдийг зөв тааруулна.
    //     Зүсмэлийг зөв тааруулах эсэхийг шалгах нь дуудлага хийгчийн үүрэг юм.
    //
    // Илүү дэлгэрэнгүйг доорхи тайлбаруудаас үзнэ үү.
    unsafe {
        // Хэрэв сүүлийн хоёр элемент нь дэг журамгүй бол ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Сүүлийн элементийг стекээр хуваарилагдсан хувьсагч болгон унших.
            // Хэрэв panics харьцуулалтын дараах үйлдлийг хийвэл `hole` унаж элементийг автоматаар зүсэлт рүү бичнэ.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // "I`-р" элементийг баруун тийш нэг газар хөдөлгөн нүхийг зүүн тийш шилжүүлнэ.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` унаж улмаар `tmp`-ийг `v`-ийн үлдсэн нүх рүү хуулна.
        }
    }
}

/// Захиалгагүй хэд хэдэн элементийг эргэн тойронд шилжүүлэн зүсмэлийг хэсэгчлэн ангилдаг.
///
/// Зүсмэлийг төгсгөлд нь эрэмбэлсэн бол `true` буцаана.Энэ функц нь *O*(*n*) хамгийн муу тохиолдол юм.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Захиалгагүй, зэргэлдээ орших хос шилжилтийн хамгийн их тоо.
    const MAX_STEPS: usize = 5;
    // Хэрэв зүсмэл нь үүнээс богино байвал ямар ч элемент шилжүүлж болохгүй.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // АЮУЛГҮЙ БАЙДЛЫГ: Бид `i < len`-тэй холбоотой чекийг аль хэдийн тодорхой хийсэн.
        // Бидний дараагийн бүх индексжүүлэлт зөвхөн `0 <= index < len` хүрээнд байна
        unsafe {
            // Дараагийн дараалалгүй элементүүдийн дараагийн хосыг олоорой.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Бид дууссан уу?
        if i == len {
            return true;
        }

        // Богино массив дээр элементүүдийг бүү шилжүүлээрэй.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Олдсон хос элементийг солих.Энэ нь тэдгээрийг зөв дараалалд оруулдаг.
        v.swap(i - 1, i);

        // Жижиг элементийг зүүн тийш шилжүүлнэ үү.
        shift_tail(&mut v[..i], is_less);
        // Илүү их элементийг баруун тийш шилжүүлэх.
        shift_head(&mut v[i..], is_less);
    }

    // Хязгаарлагдмал тооны алхмаар зүсмэлийг ялгаж чадсангүй.
    false
}

/// Оруулах эрэмбийг ашиглан зүсмэлийг эрэмбэлдэг бөгөөд энэ нь *O*(*n*^ 2) хамгийн муу тохиолдол юм.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// He00ort ашиглан `v`-ийг эрэмбэлдэг бөгөөд энэ нь *O*(*n*\*log(* n*))-ийн хамгийн муу тохиолдол юм.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Энэ хоёртын овоо нь өөрчлөгдөхгүй `parent >= child`-ийг хүндэтгэдэг.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node`-ийн хүүхдүүд:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Илүү том хүүхдийг сонго.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Хэрэв хувьсах хэмжигдэхүүн `node` дээр байвал зогсоох.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Том хүүхэдтэй `node`-ийг сольж, нэг алхам доошлоод шигшээд үргэлжлүүлээрэй.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Овоолгыг шугаман хугацаанд барь.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Нуруулдан хамгийн их элементүүдийг поп.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v`-ийг `pivot`-ээс бага элемент болгон хувааж, дараа нь `pivot`-ээс их эсвэл тэнцүү элементүүдийг хуваана.
///
///
/// `pivot`-ээс бага элементийн тоог буцаана.
///
/// Салаалах үйл ажиллагааны зардлыг багасгахын тулд хуваалтуудыг блок-блокоор гүйцэтгэдэг.
/// Энэхүү санааг [BlockQuicksort][pdf] цаасан дээр толилуулсан болно.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Ердийн блок дахь элементийн тоо.
    const BLOCK: usize = 128;

    // Хуваалтын алгоритм нь дуусах хүртэл дараахь алхмуудыг давтана.
    //
    // 1. Эргүүлэлтээс их буюу тэнцүү элементүүдийг тодорхойлохын тулд зүүн талаас блок зурж ав.
    // 2. Эргэлтийн хэмжээнээс бага элементүүдийг тодорхойлохын тулд баруун талаас блокыг хус.
    // 3. Тодорхойлсон элементүүдийг зүүн ба баруун талуудын хооронд солилцох.
    //
    // Блок элементийн хувьд бид дараах хувьсагчуудыг хадгалдаг.
    //
    // 1. `block` - Блок дахь элементийн тоо.
    // 2. `start` - `offsets` массив руу заагчийг эхлүүлнэ үү.
    // 3. `end` - `offsets` массив руу заагчийг төгсгөл болгоно уу.
    // 4. `офсет, блок доторх захиалгат бус элементүүдийн индекс.

    // Зүүн талын одоогийн блок (`l`-ээс `l.add(block_l)`) хүртэл).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Баруун талын одоогийн блок (`r.sub(block_r)` to `r`)-ээс).
    // АЮУЛГҮЙ БАЙДАЛ: .add()-ийн баримт бичигт `vec.as_ptr().add(vec.len())` нь үргэлж аюулгүй байдаг гэдгийг тусгайлан дурдсан байдаг
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Бид VLA авахдаа `min(v.len() урттай нэг массив үүсгэхийг хичээгээрэй, 2 * BLOCK)
    // `BLOCK` урттай тогтмол хэмжээтэй хоёр массиваас илүү.VLA нь илүү хэмнэлттэй байж магадгүй юм.

    // `l` (inclusive) ба `r` (exclusive) заагчуудын хоорондох элементийн тоог буцаана.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` ба `r` нь маш ойртох үед бид блокуудыг блокоор хувааж дууссан.
        // Дараа нь үлдсэн элементүүдийг хооронд нь хуваахын тулд бид нөхөөс хийх ажил хийдэг.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Үлдсэн элементүүдийн тоо (тэнхлэгтэй харьцуулаагүй хэвээр байна).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Блокны хэмжээг баруун, зүүн блок хоорондоо давхцахгүй байхаар тохируул, гэхдээ үлдсэн цоорхойг бүрэн төгс тохируулах хэрэгтэй.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // `block_l` элементүүдийг зүүн талаас нь тэмдэглээрэй.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // АЮУЛГҮЙ АЖИЛЛАГАА: Доорхи аюулгүй ажиллагааны бус ажиллагаа нь `offset`-ийг ашиглахтай холбоотой юм.
                //         Функцэд шаардагдах нөхцлийн дагуу бид дараахь зүйлийг хангасан болно.
                //         1. `offsets_l` нь стекээр хуваарилагдсан тул тусад нь хуваарилагдсан объект гэж үздэг.
                //         2. `is_less` функц нь `bool`-ийг буцаадаг.
                //            `bool` хийснээр `isize` хэзээ ч халихгүй.
                //         3. Бид `block_l` нь `<= BLOCK` байх баталгаатай.
                //            Дээрээс нь `end_l` нь эхлээд стек дээр зарлагдсан `offsets_` эхлэх заагч дээр тохируулагдсан байсан.
                //            Тиймээс бид хамгийн муу тохиолдолд ч гэсэн (`is_less`-ийн бүх дуудлага хуурамчаар ирдэг) бид зөвхөн хамгийн дээд тал нь 1 байт өнгөрөх болно.
                //        Аюулгүй ажиллагааны өөр нэг ажиллагаа бол `elem`-ийг ялгах явдал юм.
                //        Гэсэн хэдий ч, `elem` нь анхандаа үргэлж хүчинтэй байдаг зүсмэлийн эхлэх заагч байсан.
                unsafe {
                    // Салбаргүй харьцуулалт.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // `block_r` элементүүдийг баруун талаас нь ул мөрөөр зурах.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // АЮУЛГҮЙ АЖИЛЛАГАА: Доорхи аюулгүй ажиллагааны бус ажиллагаа нь `offset`-ийг ашиглахтай холбоотой юм.
                //         Функцэд шаардагдах нөхцлийн дагуу бид дараахь зүйлийг хангасан болно.
                //         1. `offsets_r` нь стекээр хуваарилагдсан тул тусад нь хуваарилагдсан объект гэж үздэг.
                //         2. `is_less` функц нь `bool`-ийг буцаадаг.
                //            `bool` хийснээр `isize` хэзээ ч халихгүй.
                //         3. Бид `block_r` нь `<= BLOCK` байх баталгаатай.
                //            Дээрээс нь `end_r` нь эхлээд стек дээр зарлагдсан `offsets_` эхлэх заагч дээр тохируулагдсан байсан.
                //            Тиймээс бид хамгийн муу тохиолдолд ч гэсэн (`is_less`-ийн бүх дуудлага үнэн болно) бид зөвхөн хамгийн ихдээ 1 байт төгсгөлийг өнгөрөх болно.
                //        Аюулгүй ажиллагааны өөр нэг ажиллагаа бол `elem`-ийг ялгах явдал юм.
                //        Гэсэн хэдий ч `elem` нь анх `1 *sizeof(T)` төгсгөлөөс хэтэрсэн байсан бөгөөд бид үүнийг нэвтрэхээсээ өмнө `1* sizeof(T)`-ээр багасгасан.
                //        Дээрээс нь `block_r` нь `BLOCK` ба `elem`-ээс бага гэж мэдэгдэж байсан тул зүсмэлийн эхлэлийг зааж өгөх болно.
                unsafe {
                    // Салбаргүй харьцуулалт.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Зүүн ба баруун талыг хооронд нь солих захиалгагүй элементүүдийн тоо.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Тухайн үед нэг хосыг солихын оронд циклийн сэлгэлт хийх нь илүү үр дүнтэй байдаг.
            // Энэ нь солихтой яг адилхан биш боловч цөөн тооны санах ойн үйлдлийг ашиглан ижил төстэй үр дүнг гаргадаг.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Зүүн блок дахь бүх дэг журамгүй элементүүдийг зөөсөн.Дараагийн блок руу шилжих.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Баруун блок дахь бүх дэг журамгүй элементүүдийг зөөсөн.Өмнөх блок руу шилжих.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Одоо үлдэхийн тулд хамгийн дээд тал нь нэг блок (зүүн эсвэл баруун), захиалгад ороогүй элементүүдийг шилжүүлэх шаардлагатай байна.
    // Ийм үлдсэн элементүүдийг блок дотор нь эцэс хүртэл шилжүүлж болно.
    //

    if start_l < end_l {
        // Зүүн блок хэвээр байна.
        // Үлдсэн захиалгад ороогүй элементүүдийг хамгийн баруун тийш шилжүүлэх.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Баруун блок хэвээр байна.
        // Үлдсэн захиалгад ороогүй элементүүдийг хамгийн зүүн тийш шилжүүлэх.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Өөр хийх зүйл байхгүй, бид дууслаа.
        width(v.as_mut_ptr(), l)
    }
}

/// `v`-ийг `v[pivot]`-ээс бага элемент болгон хувааж, дараа нь `v[pivot]`-ээс их эсвэл тэнцүү элементүүдийг хуваана.
///
///
/// Товшлыг буцаана:
///
/// 1. `v[pivot]`-ээс бага элементийн тоо.
/// 2. Хэрэв `v` аль хэдийн хуваагдсан байсан бол үнэн.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Пивот зүсмэлийн эхэнд байрлуулна.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Үр ашгийг дээшлүүлэхийн тулд эргэлтийг стекээр хуваарилагдсан хувьсагч болгон уншина уу.
        // Хэрэв дараахь panics харьцуулалтын үйлдлийг хийвэл тэнхлэгийг зүсэлт рүү автоматаар бичнэ.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Захиалгагүй элементүүдийн эхний хосыг олоорой.
        let mut l = 0;
        let mut r = v.len();

        // Аюулгүй байдал: Доорхи аюулгүй байдал нь массивыг индексжүүлэх явдал юм.
        // Эхнийх нь: Бид `l < r`-тэй хил хязгаараа аль хэдийн шалгаж байна.
        // Хоёрдахь хувьд: Бид эхлээд `l == 0` ба `r == v.len()`-тэй байсан бөгөөд индексжүүлэх ажил бүр дээр `l < r`-ийг шалгаж байсан.
        //                     Эндээс бид `r` нь дор хаяж `r == l` байх ёстой бөгөөд эхнийхээс хүчин төгөлдөр болохыг харуулсан болно.
        unsafe {
            // Пивотоос их буюу тэнцүү эхний элементийг ол.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Пивот хэмжээнээс бага сүүлчийн элементийг олоорой.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` хамрах хүрээнээс гарч пивотыг (энэ нь стекээр хуваарилагдсан хувьсагч) буцааж анх байсан зүсмэл рүү бичнэ.
        // Энэ алхам нь аюулгүй байдлыг хангахад маш чухал юм!
        //
    };

    // Хоёр хуваалт хооронд тэнхлэгийг байрлуул.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v`-ийг `v[pivot]`-тэй тэнцүү элемент болгон хувааж дараа нь `v[pivot]`-ээс их элементүүдийг оруулна.
///
/// Пивот тэнцүү элементийн тоог буцаана.
/// `v` нь эргэлтээс бага элемент агуулаагүй гэж үздэг.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Пивот зүсмэлийн эхэнд байрлуулна.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Үр ашгийг дээшлүүлэхийн тулд эргэлтийг стекээр хуваарилагдсан хувьсагч болгон уншина уу.
    // Хэрэв дараахь panics харьцуулалтын үйлдлийг хийвэл тэнхлэгийг зүсэлт рүү автоматаар бичнэ.
    // АЮУЛГҮЙ БАЙДАЛ: Энд заагч нь зүсмэлийн лавлагаанаас авсан тул хүчинтэй байна.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Одоо зүсмэлийг хуваана.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // Аюулгүй байдал: Доорхи аюулгүй байдал нь массивыг индексжүүлэх явдал юм.
        // Эхнийх нь: Бид `l < r`-тэй хил хязгаараа аль хэдийн шалгаж байна.
        // Хоёрдахь хувьд: Бид эхлээд `l == 0` ба `r == v.len()`-тэй байсан бөгөөд индексжүүлэх ажил бүр дээр `l < r`-ийг шалгаж байсан.
        //                     Эндээс бид `r` нь дор хаяж `r == l` байх ёстой бөгөөд эхнийхээс хүчин төгөлдөр болохыг харуулсан болно.
        unsafe {
            // Пивотоос их эхний элементийг олоорой.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Пивот тэнцүү сүүлчийн элементийг ол.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Бид дууссан уу?
            if l >= r {
                break;
            }

            // Олдсон захиалгад ороогүй хослолыг солих.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Бид Pivot-тэй тэнцүү `l` элементүүдийг олсон.Пивотыг тооцоолохын тулд 1-ийг нэмнэ үү.
    l + 1

    // `_pivot_guard` хамрах хүрээнээс гарч пивотыг (энэ нь стекээр хуваарилагдсан хувьсагч) буцааж анх байсан зүсмэл рүү бичнэ.
    // Энэ алхам нь аюулгүй байдлыг хангахад маш чухал юм!
}

/// Quicksort-д тэнцвэргүй хуваалт үүсгэж болзошгүй хэв маягийг эвдэх гэж зарим элементүүдийг тойрч тараадаг.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Жорж Марсаглигийн бичсэн "Xorshift RNGs" цааснаас хуурамч санамсаргүй тооны генератор.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Энэ тоог модулийн дагуу санамсаргүй тоогоор авна уу.
        // `len` нь `isize::MAX`-ээс ихгүй тул тоо нь `usize`-т багтах болно.
        let modulus = len.next_power_of_two();

        // Зарим гол нэр дэвшигчид энэ индексийн ойролцоо байх болно.Тэднийг санамсаргүй байдлаар авч үзье.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // `len` модулийг санамсаргүй тоогоор үүсгэх.
            // Гэсэн хэдий ч өртөг өндөртэй үйл ажиллагаанаас зайлсхийхийн тулд эхлээд үүнийг хоёр хүчин чадлаар нь аваад `[0, len - 1]` хязгаарт багтах хүртэл `len`-ээр бууруулна.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len`-ээс бага байх баталгаатай болно.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v`-д тэнхлэгийг сонгож, хэрчмийг аль хэдийн эрэмбэлсэн бол индекс болон `true`-ийг буцаана.
///
/// Энэ процесст `v` дахь элементүүдийг эрэмбэлж болно.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Медиануудын аргыг сонгох хамгийн бага урт.
    // Богинохон зүсмэлүүд нь гурвын дундаж аргыг ашигладаг.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Энэ функцэд гүйцэтгэж болох хамгийн их своп тоо.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Бидний ойролцоо чиглэлийг сонгох гурван индекс.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Индексүүдийг ялгах явцад бидний хийх гэж буй свопуудын нийт тоог тоолно.
    let mut swaps = 0;

    if len >= 8 {
        // `v[a] <= v[b]` болгож индексүүдийг солино.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // `v[a] <= v[b] <= v[c]` болгож индексүүдийг солино.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]`-ийн медианыг олж индексийг `a` болгон хадгална.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b`, `c` хорооллоос медиануудыг хайж олох.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b`, `c`-ийн дунджийг ол.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Хамгийн их своп тоог хийсэн.
        // Зүсмэл нь буурах эсвэл ихэвчлэн буурах магадлалтай тул ухрах нь илүү хурдан эрэмбэлэхэд тусална.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v`-ийг рекурсив байдлаар ангилдаг.
///
/// Хэрэв зүсмэл нь анхны массивт өмнөх хувилбартай байсан бол үүнийг `pred` гэж зааж өгсөн болно.
///
/// `limit` нь `heapsort` руу шилжихээс өмнө зөвшөөрөгдсөн тэнцвэргүй хуваалтуудын тоо юм.
/// Хэрэв тэг байвал энэ функц тэр даруй нуруулдан руу шилжих болно.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Энэ урттай зүсмэлүүдийг оруулах ангиллыг ашиглан эрэмбэлнэ.
    const MAX_INSERTION: usize = 20;

    // Сүүлийн хуваалт боломжийн тэнцвэртэй байсан бол үнэн.
    let mut was_balanced = true;
    // Хэрэв сүүлчийн хуваалт нь элементүүдийг хольсонгүй бол үнэн (зүсмэлийг аль хэдийн хуваасан байсан).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Маш богино зүсмэлүүдийг оруулах ангиллыг ашиглан ангилдаг.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Хэрэв эргүүлэх сонголтыг хэт олон удаа хийсэн бол `O(n * log(n))`-ийн хамгийн муу тохиолдлыг баталгаажуулахын тулд нуруундаа буцаж очно уу.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Хэрэв сүүлчийн хуваалт тэнцвэргүй байсан бол эргэн тойронд зарим элементүүдийг хольж зүсмэл дэх хэв маягийг эвдэж үзээрэй.
        // Энэ удаад бид илүү сайн пивотыг сонгоно гэж найдаж байна.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Пивот сонгоод зүсмэлийг аль хэдийн эрэмбэлсэн эсэхийг тааж үзээрэй.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Хэрэв сүүлчийн хуваалт нь зохистой тэнцвэртэй байсан бөгөөд элементүүдийг хооронд нь хольсонгүй, мөн пивот сонголтоор урьдчилан таамагласан бол зүсмэлийг аль хэдийн эрэмбэлсэн байх магадлалтай ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Захиалгад ороогүй хэд хэдэн элементийг тодорхойлж, зөв байрлалд шилжүүлэхийг хичээ.
            // Хэрэв зүсмэлийг бүрэн ангилж дуусвал бид бэлэн боллоо.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Хэрэв сонгосон тэнхлэг нь өмнөх загвартай тэнцүү бол энэ нь зүсмэл дэх хамгийн жижиг элемент юм.
        // Зүсмэлийг тэнхлэгтэй тэнцүү ба тэнхлэгээс их элемент болгон хуваана.
        // Энэ тохиолдол нь ихэвчлэн олон тооны давхардсан элемент агуулсан тохиолдолд цохигддог.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Пивотоос их элементүүдийг эрэмбэлж үргэлжлүүлээрэй.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Зүсмэлийг хуваана.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Зүсмэлийг `left`, `pivot`, `right` болгон хуваа.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Нийт рекурсив дуудлагыг багасгах, стекийн зай бага зарцуулахын тулд зөвхөн богино тал руугаа эргэж орно уу.
        // Дараа нь урт талыг нь үргэлжлүүлээрэй (энэ нь сүүлний рекурстэй адил юм).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// *O*(*n*\*log(* n*))-ийн хамгийн муу тохиолдол) загварыг ялсан quicksort ашиглан `v`-ийг ангилдаг.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Эрэмбэлэх нь тэг хэмжээст төрлүүд дээр утга учиртай шинж чанаргүй байдаг.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Тэнцвэржүүлээгүй хуваалтын тоог `floor(log2(len)) + 1` хүртэл хязгаарлаарай.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Энэ урттай зүсмэлүүдийн хувьд тэдгээрийг ялгахад илүү хурдан байдаг.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Пивот сонгоно уу
        let (pivot, _) = choose_pivot(v, is_less);

        // Хэрэв сонгосон тэнхлэг нь өмнөх загвартай тэнцүү бол энэ нь зүсмэл дэх хамгийн жижиг элемент юм.
        // Зүсмэлийг тэнхлэгтэй тэнцүү ба тэнхлэгээс их элемент болгон хуваана.
        // Энэ тохиолдол нь ихэвчлэн олон тооны давхардсан элемент агуулсан тохиолдолд цохигддог.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Хэрэв бид индексээ давсан бол бид сайн байна гэсэн үг юм.
                if mid > index {
                    return;
                }

                // Эс тэгвэл пивотоос их элементүүдийг эрэмбэлж үргэлжлүүлээрэй.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Зүсмэлийг `left`, `pivot`, `right` болгон хуваа.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Хэрэв mid==индекс бол partition() нь дундаас хойшхи бүх элементүүд дундаас их эсвэл тэнцүү байх баталгаатай тул бид дууссан болно.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Эрэмбэлэх нь тэг хэмжээст төрлүүд дээр утга учиртай шинж чанаргүй байдаг.Юу ч хийхгүй.
    } else if index == v.len() - 1 {
        // Max элементийг олоод массивын хамгийн сүүлийн байрлалд байрлуул.
        // V нь хоосон байж болохгүй гэдгийг бид мэддэг тул бид энд `unwrap()` ашиглах боломжтой.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Min элементийг олоод массивын эхний байрлалд байрлуул.
        // V нь хоосон байж болохгүй гэдгийг бид мэддэг тул бид энд `unwrap()` ашиглах боломжтой.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}