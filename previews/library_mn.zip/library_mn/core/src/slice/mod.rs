// ignore-tidy-filelength

//! Зүсмэлийн менежмент ба манипуляци.
//!
//! Дэлгэрэнгүй мэдээллийг [`std::slice`]-с авна уу.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// rust-memchr-ээс авсан цэвэр rust memchr хэрэгжилт
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Туршилтын овоо нурууг нэгтгэх өөр арга байхгүй тул энэ функц олон нийтэд нээлттэй болно.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Зүсмэл дэх элементийн тоог буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // АЮУЛГҮЙ БАЙДАЛ: бид урт талбарыг usize болгон хувиргадаг тул const дуу чимээ (заавал байх ёстой)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // АЮУЛГҮЙ БАЙДАЛ: `&[T]` ба `FatPtr<T>` нь ижил загвартай тул аюулгүй юм.
            // Зөвхөн `std` энэ баталгааг гаргаж чадна.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Энэ нь тогтвортой байх үед `crate::ptr::metadata(self)`-ээр солино.
            // Үүнийг бичиж байх үед энэ нь "Const-stable functions can only call other const-stable functions" алдаа үүсгэдэг.
            //

            // АЮУЛГҮЙ БАЙДАЛ: * const T-ээс хойш `PtrRepr` холболтоос утгад нэвтрэх нь аюулгүй юм
            // болон PtrComponents<T>ижил санах ойн байршилтай байх.
            // Зөвхөн std энэ баталгааг гаргаж чадна.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Хэрэв зүсэлт 0 урттай бол `true` буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Зүсмэлийн эхний элемент эсвэл хоосон бол `None`-ийг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Зүсмэлийн эхний элементэд өөрчлөгдөж болох заагчийг буцааж өгнө, эсвэл хоосон бол `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Зүсмэлийн эхний болон үлдсэн бүх элементүүдийг буцааж өгдөг, эсвэл хоосон бол `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Зүсмэлийн эхний болон үлдсэн бүх элементүүдийг буцааж өгдөг, эсвэл хоосон бол `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Зүсмэлийн сүүлчийн болон үлдсэн бүх элементийг буцааж, эсвэл хоосон бол `None`-ийг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Зүсмэлийн сүүлчийн болон үлдсэн бүх элементийг буцааж, эсвэл хоосон бол `None`-ийг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Зүсмэлийн сүүлчийн элементийг эсвэл хоосон бол `None`-ийг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Зүсмэлийн сүүлчийн зүйлд өөрчлөгдөж болох заагчийг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Индексийн төрлөөс хамааран элемент эсвэл дэд зүйлд зориулсан лавлагааг буцаана.
    ///
    /// - Хэрэв байрлал өгсөн бол тухайн байрлал дахь элементийн заалт эсвэл хязгаараас хэтэрсэн бол `None`-ийг буцааж өгнө.
    ///
    /// - Хэрэв муж өгсөн бол тухайн мужид харгалзах дэд хязгаарыг эсвэл хязгаараас хэтэрсэн тохиолдолд `None`-ийг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Индексийн төрөл ([`get`]-ийг үзнэ үү) эсвэл индекс хязгаараас хэтэрсэн бол `None`-ээс хамаарч элемент эсвэл дэд зүйл рүү шилжих боломжтой лавлагааг буцаана.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Хязгаарлалтгүйгээр элемент эсвэл дэд зүйлд өгсөн лавлагааг буцаана.
    ///
    /// Аюулгүй хувилбарыг [`get`]-ээс үзнэ үү.
    ///
    /// # Safety
    ///
    /// Энэ аргыг хязгаараас хэтэрсэн индексээр дуудах нь үр дүнгийн лавлагаа ашиглаагүй байсан ч *[тодорхойгүй зан байдал]* юм.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `get_unchecked`-ийн аюулгүй байдлын ихэнх шаардлагыг хангасан байх ёстой;
        // `self` нь аюулгүй лавлагаа тул зүсмэлийг салгаж авах боломжтой.
        // Буцаасан заагч нь аюулгүй, учир нь `SliceIndex`-ийн имплүүд үүнийг баталгаажуулах ёстой.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Хязгаарлалтгүйгээр элемент эсвэл дэд зүйлд хувьсах боломжтой лавлагааг буцаана.
    ///
    /// Аюулгүй хувилбарыг [`get_mut`]-ээс үзнэ үү.
    ///
    /// # Safety
    ///
    /// Энэ аргыг хязгаараас хэтэрсэн индексээр дуудах нь үр дүнгийн лавлагаа ашиглаагүй байсан ч *[тодорхойгүй зан байдал]* юм.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `get_unchecked_mut`-ийн аюулгүй байдлын шаардлагыг хангах ёстой;
        // `self` нь аюулгүй лавлагаа тул зүсмэлийг салгаж авах боломжтой.
        // Буцаасан заагч нь аюулгүй, учир нь `SliceIndex`-ийн имплүүд үүнийг баталгаажуулах ёстой.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Түүхий заагчийг зүсмэлийн буферт буцаана.
    ///
    /// Дуудлага хийж буй хүн буцааж заагагч заагчаас хэтэрсэн эсэхийг баталгаажуулах ёстой, эс тэгвээс хог руу чиглүүлж дуусах болно.
    ///
    /// Дуудлага хийж байгаа хүн (non-transitively) заагчийн зааж өгсөн санах ойг энэ заагч эсвэл үүнээс үүдсэн аливаа заагчийг ашиглан хэзээ ч (`UnsafeCell` дотор байгаа тохиолдолд) бичихгүй байхыг баталгаажуулах ёстой.
    /// Хэрэв та зүсмэлийн агуулгыг өөрчлөх шаардлагатай бол [`as_mut_ptr`] ашиглана уу.
    ///
    /// Энэхүү зүсмэлийн иш татсан савыг өөрчлөх нь түүний буферыг дахин хуваарилахад хүргэж болзошгүй бөгөөд ингэснээр түүнд чиглэсэн заагч хүчингүй болно.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Аюулгүй, өөрчлөгдөж болох заагчийг зүсмэлийн буферт буцаана.
    ///
    /// Дуудлага хийж буй хүн буцааж заагагч заагчаас хэтэрсэн эсэхийг баталгаажуулах ёстой, эс тэгвээс хог руу чиглүүлж дуусах болно.
    ///
    /// Энэхүү зүсмэлийн иш татсан савыг өөрчлөх нь түүний буферыг дахин хуваарилахад хүргэж болзошгүй бөгөөд ингэснээр түүнд чиглэсэн заагч хүчингүй болно.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Зүсмэлийг хамарсан хоёр түүвэр заагчийг буцаана.
    ///
    /// Буцаагдсан муж хагас нээлттэй байна, энэ нь төгсгөлийн заагч нь зүсмэлийн сүүлчийн элементийг *нэг өнгөрсөн* зааж байгааг харуулж байна.
    /// Ингэснээр хоосон зүсмэлийг хоёр тэнцүү заагчаар, хоёр заагчийн зөрүү нь зүсмэлийн хэмжээг илэрхийлнэ.
    ///
    /// Эдгээр заагчийг ашиглах талаархи анхааруулгыг [`as_ptr`]-ээс үзнэ үү.Төгсгөлийн заагч нь зүсмэл дэх хүчин төгөлдөр элементийг заагаагүй тул илүү болгоомжтой байхыг шаарддаг.
    ///
    /// Энэ функц нь C++ хэл дээр нийтлэг байдаг тул санах ой дахь хэд хэдэн элементийг дурьдахын тулд хоёр заагчийг ашигладаг гадаад интерфэйстэй харьцахад ашигтай байдаг.
    ///
    ///
    /// Элементийн заагч нь энэ зүсмэлийн элементийг хэлдэг эсэхийг шалгах нь бас ашигтай байж болох юм.
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // АЮУЛГҮЙ БАЙДАЛ: Энд байгаа `add` аюулгүй, учир нь:
        //
        //   - Объектын шууд хажуу тийш чиглүүлэх нь бас тооцогдох тул хоёулаа ижил заагчийн нэг хэсэг юм.
        //
        //   - Зүсмэлийн хэмжээ хэзээ ч isize::MAX байтаас их байдаггүй.
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Зүсмэлүүд хаягийн талбайн төгсгөлд ороогүй тул үүнд хамрагдах зүйл байхгүй.
        //
        // pointer::add-ийн баримт бичгийг үзнэ үү.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Зүсмэлийг хамарсан хоёр аюултай, өөрчлөгдөж болохуйц заагчийг буцаана.
    ///
    /// Буцаагдсан муж хагас нээлттэй байна, энэ нь төгсгөлийн заагч нь зүсмэлийн сүүлчийн элементийг *нэг өнгөрсөн* зааж байгааг харуулж байна.
    /// Ингэснээр хоосон зүсмэлийг хоёр тэнцүү заагчаар, хоёр заагчийн зөрүү нь зүсмэлийн хэмжээг илэрхийлнэ.
    ///
    /// Эдгээр заагчийг ашиглах талаархи анхааруулгыг [`as_mut_ptr`]-ээс үзнэ үү.
    /// Төгсгөлийн заагч нь зүсмэл дэх хүчин төгөлдөр элементийг заагаагүй тул илүү болгоомжтой байхыг шаарддаг.
    ///
    /// Энэ функц нь C++ хэл дээр нийтлэг байдаг тул санах ой дахь хэд хэдэн элементийг дурьдахын тулд хоёр заагчийг ашигладаг гадаад интерфэйстэй харьцахад ашигтай байдаг.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // АЮУЛГҮЙ БАЙДАЛ: Энд байгаа `add` яагаад аюулгүй байдгийг as_ptr_range() дээрээс үзнэ үү.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Зүсмэл дэх хоёр элементийг солино.
    ///
    /// # Arguments
    ///
    /// * a, Эхний элементийн индекс
    /// * b, Хоёрдахь элементийн индекс
    ///
    /// # Panics
    ///
    /// Хэрэв `a` эсвэл `b` хязгаараас хэтэрсэн бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Нэг vector-ээс хоёр өөрчлөгдөх зээл авах боломжгүй тул түүхий заагч ашиглана уу.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // АЮУЛГҮЙ БАЙДАЛ: `pa` ба `pb`-ийг аюулгүй, өөрчлөгдөж болохуйц лавлагаанаас бүтээсэн болно
        // зүсмэлийн элементүүдэд тул хүчинтэй, зэрэгцүүлсэн баталгаатай болно.
        // `a` ба `b`-ийн ард байгаа элементүүдэд нэвтрэх нь шалгагдсан бөгөөд хил хязгаараас гарах үед panic болно гэдгийг анхаарна уу.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Зүсмэл доторх элементүүдийн дарааллыг өөрчилнө.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Маш жижиг төрлүүдийн хувьд ердийн зам дээр уншдаг бүх хүмүүс тааруухан гүйцэтгэлтэй байдаг.
        // Илүү том хэсэг ачаалж, регистрийг буцааж өгснөөр бид үр дүнтэй, тохируулаагүй load/store өгөгдсөн тохиолдолд илүү сайн хийж чадна.
        //

        // Зэрэглээгүй унших нь үр дүнтэй эсэх (жишээ нь ARM-ийн янз бүрийн хувилбаруудын хооронд өөрчлөгдөж байгаа эсэх) болон хамгийн сайн хэмжээтэй хэсэг нь ямар байх вэ гэдгийг биднээс илүү сайн мэддэг тул LLVM нь бидний хувьд үүнийг хийх нь зүйтэй болов уу.
        // Харамсалтай нь LLVM 4.0 (2017-05)-ийн хувьд энэ нь зөвхөн гогцоог задалдаг тул бид өөрсдөө хийх хэрэгтэй.
        // (Таамаглал: урвуу тал нь өөр өөр зэрэгцүүлж болдог тул урвуу тал нь төвөгтэй байдаг тул урт нь сондгой байх тохиолдолд дунд нь бүрэн нийцсэн SIMD ашиглахын тулд урьдчилсан ба дараахь ялтас ялгаруулах ямар ч боломжгүй юм.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Хэрэглэгдэхүүн дэх u8-уудыг буцаахын тулд дотоод llvm.bswap-ийг ашиглана уу
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // АЮУЛГҮЙ БАЙДАЛ: Энд шалгах хэд хэдэн зүйл байна:
                //
                // - Дээрх cfg шалгалтын улмаас `chunk` нь 4 эсвэл 8 байна гэдгийг анхаарна уу.Тиймээс `chunk - 1` эерэг байна.
                // - `i` индексээр индексжүүлэлт хийх нь давталтын баталгаа болж өгдөг
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - `ln - i - chunk = ln - (i + chunk)` индексээр индексжүүлэх нь зөв юм.
                //   - `i + chunk > 0` өчүүхэн үнэн юм.
                //   - Давталтын баталгаа нь дараахь зүйлийг баталгаажуулдаг.
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, ингэснээр хасах нь урсахгүй.
                // - `read_unaligned` ба `write_unaligned` дуудлага зүгээр байна:
                //   - `pa` `i` индексийг зааж өгсөн бол `i < ln / 2 - (chunk - 1)` (дээр дурдсаныг үзнэ үү) ба `pb` нь `ln - i - chunk` индексийг зааж байгаа тул хоёулаа `self` төгсгөлөөс дор хаяж `chunk` олон байт зайтай байна.
                //
                //   - Аливаа эхлүүлсэн санах ой хүчин төгөлдөр `usize` байна.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // u32-д u16-уудыг эргүүлэхийн тулд 16-р эргэлтийг ашиглана уу
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // АЮУЛГҮЙ АЖИЛЛАГАА: `i + 1 < ln` бол `i`-ээс тохируулаагүй u32-ийг унших боломжтой
                // (мөн мэдээж `i < ln`), учир нь элемент бүр нь 2 байт бөгөөд бид 4 уншиж байна.
                //
                // `i + chunk - 1 < ln / 2` # харин нөхцөл байдал
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Энэ нь 2-т хуваагдсан уртаас бага тул хил хязгаартай байх ёстой.
                //
                // Энэ нь `0 < i + chunk <= ln` нөхцлийг үргэлж хүндэтгэж, `pb` заагчийг аюулгүй ашиглаж болохыг баталгаажуулдаг гэсэн үг юм.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // АЮУЛГҮЙ БАЙДАЛ: `i` нь зүсмэлийн уртын тэн хагасаас доогуур байдаг
            // `i` ба `ln - i - 1`-т хандах нь аюулгүй (`i` нь 0-ээс эхэлдэг бөгөөд `ln / 2 - 1`-ээс хэтрэхгүй).
            // Үүний үр дүнд үүссэн `pa` ба `pb` заагчууд хүчинтэй, зэрэгцсэн тул уншиж, бичиж болно.
            //
            //
            unsafe {
                // Хил хязгаараас зайлсхийхийн тулд аюулгүй свопыг аюулгүй своп дээр шалгах хэрэгтэй.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Зүсмэл дээрх давталтыг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Утга бүрийг өөрчлөх боломжийг олгодог давталтыг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// `size` урттай бүх windows давталтыг буцаана.
    /// windows давхцаж байна.
    /// Хэрэв зүсэлт нь `size`-ээс богино бол давталт нь ямар ч утга өгөхгүй.
    ///
    /// # Panics
    ///
    /// Хэрэв `size` нь 0 бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Хэрэв зүсэлт `size`-ээс богино бол:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Зүсмэлийн эхлэлээс эхлэн нэг удаад зүсмэлийн `chunk_size` элемент дээр давтагчийг буцаана.
    ///
    /// Хэсэг нь зүсмэл бөгөөд хоорондоо давхцахгүй.Хэрэв `chunk_size` нь зүсмэлийн уртыг хуваахгүй бол сүүлчийн хэсэг нь `chunk_size` урттай байх болно.
    ///
    /// Үргэлж яг `chunk_size` элементийн хэсгүүдийг буцаадаг энэ давталтын хувилбарыг [`chunks_exact`]-с үзнэ үү, мөн ижил давталтын хувьд [`rchunks`]-ийг зүсмэлийн төгсгөлөөс эхэлнэ.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `chunk_size` нь 0 бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Зүсмэлийн эхлэлээс эхлэн нэг удаад зүсмэлийн `chunk_size` элемент дээр давтагчийг буцаана.
    ///
    /// Эдгээр хэсгүүд нь өөрчлөгдөх боломжтой зүсмэлүүд бөгөөд хоорондоо давхцахгүй.Хэрэв `chunk_size` нь зүсмэлийн уртыг хуваахгүй бол сүүлчийн хэсэг нь `chunk_size` урттай байх болно.
    ///
    /// Үргэлж яг `chunk_size` элементийн хэсгүүдийг буцаадаг энэ давталтын хувилбарыг [`chunks_exact_mut`]-с үзнэ үү, мөн ижил давталтын хувьд [`rchunks_mut`]-ийг зүсмэлийн төгсгөлөөс эхэлнэ.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `chunk_size` нь 0 бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Зүсмэлийн эхлэлээс эхлэн нэг удаад зүсмэлийн `chunk_size` элемент дээр давтагчийг буцаана.
    ///
    /// Хэсэг нь зүсмэл бөгөөд хоорондоо давхцахгүй.
    /// Хэрэв `chunk_size` нь зүсмэлийн уртыг хуваахгүй бол `chunk_size-1` хүртэлх хамгийн сүүлийн элементүүдийг орхих бөгөөд давталтын `remainder` функцээс авах боломжтой болно.
    ///
    ///
    /// Хэсэг бүр яг `chunk_size` элементтэй тул хөрвүүлэгч нь кодыг [`chunks`]-ээс илүү оновчтой болгож чаддаг.
    ///
    /// Энэ давталтын хувилбарыг [`chunks`] хэсгээс үзнэ үү, мөн үлдэгдлийг жижиг хэсэг болгон буцаана, мөн ижил давталтын хувьд [`rchunks_exact`] боловч зүсмэлийн төгсгөлөөс эхэлнэ.
    ///
    /// # Panics
    ///
    /// Хэрэв `chunk_size` нь 0 бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Зүсмэлийн эхлэлээс эхлэн нэг удаад зүсмэлийн `chunk_size` элемент дээр давтагчийг буцаана.
    ///
    /// Эдгээр хэсгүүд нь өөрчлөгдөх боломжтой зүсмэлүүд бөгөөд хоорондоо давхцахгүй.
    /// Хэрэв `chunk_size` нь зүсмэлийн уртыг хуваахгүй бол `chunk_size-1` хүртэлх хамгийн сүүлийн элементүүдийг орхих бөгөөд давталтын `into_remainder` функцээс авах боломжтой болно.
    ///
    ///
    /// Хэсэг бүр яг `chunk_size` элементтэй тул хөрвүүлэгч нь кодыг [`chunks_mut`]-ээс илүү оновчтой болгож чаддаг.
    ///
    /// Энэ давталтын хувилбарыг [`chunks_mut`] хэсгээс үзнэ үү, мөн үлдэгдлийг жижиг хэсэг болгон буцаана, мөн ижил давталтын хувьд [`rchunks_exact_mut`] боловч зүсмэлийн төгсгөлөөс эхэлнэ.
    ///
    /// # Panics
    ///
    /// Хэрэв `chunk_size` нь 0 бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Үлдсэн зүйл байхгүй гэж үзээд зүсмэлийг `N` элементийн массивын зүсмэл болгон хуваадаг.
    ///
    ///
    /// # Safety
    ///
    /// Үүнийг зөвхөн хэзээ гэж нэрлэж болох юм
    /// - Зүсмэл нь яг N` элементийн хэсгүүдэд хуваагддаг (`self.len() % N == 0`) гэж нэрлэдэг).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // АЮУЛГҮЙ БАЙДАЛ: 1 элементийн хэсгүүд хэзээ ч үлдэхгүй
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // АЮУЛГҮЙ БАЙДАЛ: Зүсмэл урт (6) нь 3-ын үржвэр юм
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Эдгээр нь үндэслэлгүй байх болно:
    /// // хэсэг хэсгүүдийг зөвшөөрөх: &[[_;5]]= slice.as_chunks_unchecked()//Зүсмэлийн урт нь 5 ширхэгээс хэтрэхгүй:&[[_;0]]= slice.as_chunks_unchecked()//Тэг урттай хэсгүүдийг хэзээ ч зөвшөөрөхгүй
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // АЮУЛГҮЙ АЖИЛЛАГАА: Үүнийг урьдчилж нэрлэхэд бидний урьдчилсан нөхцөл бол яг хэрэгтэй зүйл юм
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // АЮУЛГҮЙ БАЙДАЛ: Бид `new_len * N` элементийн зүсмэлийг дотор нь хаядаг
        // `new_len` зүсмэл олон `N` элементүүд.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Зүсмэлийг эхнээс нь эхлэн N` элементийн массивын зүсмэл болгон хувааж, урт нь `N`-ээс бага урттай үлдсэн зүсмэлийг хуваана.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `N` бол Panics бол энэ аргыг тогтворжуулахаас өмнө энэ шалгалтыг хөрвүүлэлтийн хугацааны алдаа болгон өөрчилсөн байх болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // АЮУЛГҮЙ АЖИЛЛАГАА: Бид аль хэдийн тэг гэж сандарч, барилгын ажлыг хангаж өгсөн
        // sublice-ийн урт нь N-ийн үржвэр юм.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Зүсмэлийг төгсгөлөөс нь эхлэн N` элементийн массивын зүсмэл болгон хувааж, урт нь `N`-ээс бага урттай үлдсэн зүсмэлийг хуваана.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `N` бол Panics бол энэ аргыг тогтворжуулахаас өмнө энэ шалгалтыг хөрвүүлэлтийн хугацааны алдаа болгон өөрчилсөн байх болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // АЮУЛГҮЙ АЖИЛЛАГАА: Бид аль хэдийн тэг гэж сандарч, барилгын ажлыг хангаж өгсөн
        // sublice-ийн урт нь N-ийн үржвэр юм.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Зүсмэлийн эхлэлээс эхлэн нэг удаад зүсмэлийн `N` элемент дээр давтагчийг буцаана.
    ///
    /// Эдгээр хэсгүүд нь массивын лавлагаа бөгөөд давхцахгүй байна.
    /// Хэрэв `N` нь зүсмэлийн уртыг хуваахгүй бол `N-1` хүртэлх хамгийн сүүлийн элементүүдийг орхих бөгөөд давталтын `remainder` функцээс авах боломжтой болно.
    ///
    ///
    /// Энэ арга нь [`chunks_exact`]-ийн ерөнхий эквивалент юм.
    ///
    /// # Panics
    ///
    /// Хэрэв `N` бол Panics бол энэ аргыг тогтворжуулахаас өмнө энэ шалгалтыг хөрвүүлэлтийн хугацааны алдаа болгон өөрчилсөн байх болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Үлдсэн зүйл байхгүй гэж үзээд зүсмэлийг `N` элементийн массивын зүсмэл болгон хуваадаг.
    ///
    ///
    /// # Safety
    ///
    /// Үүнийг зөвхөн хэзээ гэж нэрлэж болох юм
    /// - Зүсмэл нь яг N` элементийн хэсгүүдэд хуваагддаг (`self.len() % N == 0`) гэж нэрлэдэг).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // АЮУЛГҮЙ БАЙДАЛ: 1 элементийн хэсгүүд хэзээ ч үлдэхгүй
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // АЮУЛГҮЙ БАЙДАЛ: Зүсмэл урт (6) нь 3-ын үржвэр юм
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Эдгээр нь үндэслэлгүй байх болно:
    /// // хэсэг хэсгүүдийг зөвшөөрөх: &[[_;5]]= slice.as_chunks_unchecked_mut()//Зүсмэлийн урт нь 5 ширхэгээс хэтрэхгүй:&[[_;0]]= slice.as_chunks_unchecked_mut()//Тэг урттай хэсгүүдийг хэзээ ч зөвшөөрөхгүй
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // АЮУЛГҮЙ АЖИЛЛАГАА: Үүнийг урьдчилж нэрлэхэд бидний урьдчилсан нөхцөл бол яг хэрэгтэй зүйл юм
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // АЮУЛГҮЙ БАЙДАЛ: Бид `new_len * N` элементийн зүсмэлийг дотор нь хаядаг
        // `new_len` зүсмэл олон `N` элементүүд.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Зүсмэлийг эхнээс нь эхлэн N` элементийн массивын зүсмэл болгон хувааж, урт нь `N`-ээс бага урттай үлдсэн зүсмэлийг хуваана.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `N` бол Panics бол энэ аргыг тогтворжуулахаас өмнө энэ шалгалтыг хөрвүүлэлтийн хугацааны алдаа болгон өөрчилсөн байх болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // АЮУЛГҮЙ АЖИЛЛАГАА: Бид аль хэдийн тэг гэж сандарч, барилгын ажлыг хангаж өгсөн
        // sublice-ийн урт нь N-ийн үржвэр юм.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Зүсмэлийг төгсгөлөөс нь эхлэн N` элементийн массивын зүсмэл болгон хувааж, урт нь `N`-ээс бага урттай үлдсэн зүсмэлийг хуваана.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `N` бол Panics бол энэ аргыг тогтворжуулахаас өмнө энэ шалгалтыг хөрвүүлэлтийн хугацааны алдаа болгон өөрчилсөн байх болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // АЮУЛГҮЙ АЖИЛЛАГАА: Бид аль хэдийн тэг гэж сандарч, барилгын ажлыг хангаж өгсөн
        // sublice-ийн урт нь N-ийн үржвэр юм.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Зүсмэлийн эхлэлээс эхлэн нэг удаад зүсмэлийн `N` элемент дээр давтагчийг буцаана.
    ///
    /// Эдгээр хэсгүүд нь өөрчлөгдөж болох массивын лавлагаа бөгөөд хоорондоо давхцахгүй байна.
    /// Хэрэв `N` нь зүсмэлийн уртыг хуваахгүй бол `N-1` хүртэлх хамгийн сүүлийн элементүүдийг орхих бөгөөд давталтын `into_remainder` функцээс авах боломжтой болно.
    ///
    ///
    /// Энэ арга нь [`chunks_exact_mut`]-ийн ерөнхий эквивалент юм.
    ///
    /// # Panics
    ///
    /// Хэрэв `N` бол Panics бол энэ аргыг тогтворжуулахаас өмнө энэ шалгалтыг хөрвүүлэлтийн хугацааны алдаа болгон өөрчилсөн байх болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Зүсмэлийн эхнээс эхлэн `N` элементийн давхардсан windows давталтыг буцаана.
    ///
    ///
    /// Энэ бол [`windows`]-ийн ерөнхий ерөнхий эквивалент юм.
    ///
    /// Хэрэв `N` нь зүсмэлийн хэмжээнээс их байвал windows-ийг өгөхгүй.
    ///
    /// # Panics
    ///
    /// Хэрэв `N` нь 0 бол Panics.
    /// Энэ аргыг тогтворжуулахаас өмнө энэ шалгалтыг хөрвүүлэх хугацааны алдаа болгон өөрчилсөн байх магадлалтай.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Зүсмэлийн төгсгөлөөс эхлэн нэг удаад зүсмэлийн `chunk_size` элементээр давтагчийг буцаана.
    ///
    /// Хэсэг нь зүсмэл бөгөөд хоорондоо давхцахгүй.Хэрэв `chunk_size` нь зүсмэлийн уртыг хуваахгүй бол сүүлчийн хэсэг нь `chunk_size` урттай байх болно.
    ///
    /// Үргэлж яг `chunk_size` элементийн хэсгүүдийг буцаадаг энэ давталтын хувилбарыг [`rchunks_exact`]-с үзнэ үү, мөн ижил давталтын хувьд [`chunks`]-ийг зүсмэлийн эхнээс эхэлнэ.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `chunk_size` нь 0 бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Зүсмэлийн төгсгөлөөс эхлэн нэг удаад зүсмэлийн `chunk_size` элементээр давтагчийг буцаана.
    ///
    /// Эдгээр хэсгүүд нь өөрчлөгдөх боломжтой зүсмэлүүд бөгөөд хоорондоо давхцахгүй.Хэрэв `chunk_size` нь зүсмэлийн уртыг хуваахгүй бол сүүлчийн хэсэг нь `chunk_size` урттай байх болно.
    ///
    /// Үргэлж яг `chunk_size` элементийн хэсгүүдийг буцаадаг энэ давталтын хувилбарыг [`rchunks_exact_mut`]-с үзнэ үү, мөн ижил давталтын хувьд [`chunks_mut`]-ийг зүсмэлийн эхнээс эхэлнэ.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `chunk_size` нь 0 бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Зүсмэлийн төгсгөлөөс эхлэн нэг удаад зүсмэлийн `chunk_size` элементээр давтагчийг буцаана.
    ///
    /// Хэсэг нь зүсмэл бөгөөд хоорондоо давхцахгүй.
    /// Хэрэв `chunk_size` нь зүсмэлийн уртыг хуваахгүй бол `chunk_size-1` хүртэлх хамгийн сүүлийн элементүүдийг орхих бөгөөд давталтын `remainder` функцээс авах боломжтой болно.
    ///
    /// Хэсэг бүр яг `chunk_size` элементтэй тул хөрвүүлэгч нь кодыг [`chunks`]-ээс илүү оновчтой болгож чаддаг.
    ///
    /// Энэ давталтын хувилбарыг [`rchunks`] хэсгээс үзнэ үү, мөн үлдэгдлийг жижиг хэсэг болгон буцаана, мөн ижил давталтын хувьд [`chunks_exact`] боловч зүсмэлийн эхнээс эхэлнэ.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `chunk_size` нь 0 бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Зүсмэлийн төгсгөлөөс эхлэн нэг удаад зүсмэлийн `chunk_size` элементээр давтагчийг буцаана.
    ///
    /// Эдгээр хэсгүүд нь өөрчлөгдөх боломжтой зүсмэлүүд бөгөөд хоорондоо давхцахгүй.
    /// Хэрэв `chunk_size` нь зүсмэлийн уртыг хуваахгүй бол `chunk_size-1` хүртэлх хамгийн сүүлийн элементүүдийг орхих бөгөөд давталтын `into_remainder` функцээс авах боломжтой болно.
    ///
    /// Хэсэг бүр яг `chunk_size` элементтэй тул хөрвүүлэгч нь кодыг [`chunks_mut`]-ээс илүү оновчтой болгож чаддаг.
    ///
    /// Энэ давталтын хувилбарыг [`rchunks_mut`] хэсгээс үзнэ үү, мөн үлдэгдлийг жижиг хэсэг болгон буцаана, мөн ижил давталтын хувьд [`chunks_exact_mut`] боловч зүсмэлийн эхнээс эхэлнэ.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `chunk_size` нь 0 бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Зүсмэл дээр давтагчийг буцааж өгч, элементүүдийг хооронд нь давхцуулахгүйгээр тэдгээрийг ялгаж өгнө.
    ///
    /// Предикат нь өөрсдийгөө дагаж хоёр элемент дээр дуудагдах бөгөөд энэ нь `slice[0]` ба `slice[1]` дээр, дараа нь `slice[1]` ба `slice[2]` дээр гэх мэтийг дууддаг гэсэн үг юм.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Энэ аргыг эрэмбэлэгдсэн дэд хэсгүүдийг задлахад ашиглаж болно:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Зүсмэл дээр давтагчийг буцааж өгч, элементүүдийг хооронд нь давхцуулж, өөрчлөгдөж болохуйц хувьсах элементүүдийг ялгаж өгнө.
    ///
    /// Предикат нь өөрсдийгөө дагаж хоёр элемент дээр дуудагдах бөгөөд энэ нь `slice[0]` ба `slice[1]` дээр, дараа нь `slice[1]` ба `slice[2]` дээр гэх мэтийг дууддаг гэсэн үг юм.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Энэ аргыг эрэмбэлэгдсэн дэд хэсгүүдийг задлахад ашиглаж болно:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Индекс дээр нэг зүсмэлийг хоёр хуваана.
    ///
    /// Эхнийх нь `[0, mid)`-ийн бүх индексүүдийг агуулна (`mid` индексийг эс тооцвол), хоёр дахь нь `[mid, len)`-ийн бүх индексүүдийг агуулна (`len` индексийг эс тооцвол).
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `mid > len` бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // Аюулгүй байдал: `[ptr; mid]` ба `[mid; len]` нь `self` дотор байдаг бөгөөд энэ нь
        // `from_raw_parts_mut`-ийн шаардлагыг хангаж өгдөг.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Нэг өөрчлөгдөж болох зүсмэлийг индекс дээр хоёр хуваана.
    ///
    /// Эхнийх нь `[0, mid)`-ийн бүх индексүүдийг агуулна (`mid` индексийг эс тооцвол), хоёр дахь нь `[mid, len)`-ийн бүх индексүүдийг агуулна (`len` индексийг эс тооцвол).
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв `mid > len` бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // Аюулгүй байдал: `[ptr; mid]` ба `[mid; len]` нь `self` дотор байдаг бөгөөд энэ нь
        // `from_raw_parts_mut`-ийн шаардлагыг хангаж өгдөг.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Хязгаарлалтгүйгээр нэг зүсмэлийг индекс дээр хоёр хуваана.
    ///
    /// Эхнийх нь `[0, mid)`-ийн бүх индексүүдийг агуулна (`mid` индексийг эс тооцвол), хоёр дахь нь `[mid, len)`-ийн бүх индексүүдийг агуулна (`len` индексийг эс тооцвол).
    ///
    ///
    /// Аюулгүй хувилбарыг [`split_at`]-ээс үзнэ үү.
    ///
    /// # Safety
    ///
    /// Энэ аргыг хязгаараас хэтэрсэн индексээр дуудах нь үр дүнгийн лавлагаа ашиглаагүй байсан ч *[тодорхойгүй зан байдал]* юм.Залгагч нь `0 <= mid <= self.len()` гэдгийг баталгаажуулах ёстой.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // АЮУЛГҮЙ БАЙДАЛ: Дуудлага хийж байгаа хүн `0 <= mid <= self.len()` гэдгийг шалгах ёстой
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Хязгаарлалтгүйгээр нэг өөрчлөгдөж болох зүсмэлийг индекс дээр хоёр хуваана.
    ///
    /// Эхнийх нь `[0, mid)`-ийн бүх индексүүдийг агуулна (`mid` индексийг эс тооцвол), хоёр дахь нь `[mid, len)`-ийн бүх индексүүдийг агуулна (`len` индексийг эс тооцвол).
    ///
    ///
    /// Аюулгүй хувилбарыг [`split_at_mut`]-ээс үзнэ үү.
    ///
    /// # Safety
    ///
    /// Энэ аргыг хязгаараас хэтэрсэн индексээр дуудах нь үр дүнгийн лавлагаа ашиглаагүй байсан ч *[тодорхойгүй зан байдал]* юм.Залгагч нь `0 <= mid <= self.len()` гэдгийг баталгаажуулах ёстой.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // АЮУЛГҮЙ БАЙДАЛ: Дуудлага хийж байгаа хүн `0 <= mid <= self.len()` гэдгийг шалгах ёстой.
        //
        // `[ptr; mid]` болон `[mid; len]` давхцахгүй байгаа тул өөрчлөгдөж болох лавлагааг буцааж өгөх нь зөв юм.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred`-тэй тохирох элементүүдээр тусгаарлагдсан дэд хэсгүүдийн давталтыг буцаана.
    /// Тохирсон элемент нь дэд хэсгүүдэд ороогүй болно.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Хэрэв эхний элемент таарч байвал хоосон зүсмэл нь давталтын буцаах эхний зүйл болно.
    /// Үүнтэй адилаар хэрчсэн хэсгийн хамгийн сүүлчийн элемент таарч байвал хоосон зүсмэл нь давталтын буцааж өгсөн сүүлчийн зүйл байх болно.
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Хэрэв таарч тохирсон хоёр элемент шууд зэргэлдээ байвал тэдгээрийн хооронд хоосон зүсмэл гарч ирнэ.
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred`-тэй тохирох элементүүдээр тусгаарлагдсан өөрчлөгдөж болох дэд хэсгүүдийн давталтыг буцаана.
    /// Тохирсон элемент нь дэд хэсгүүдэд ороогүй болно.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred`-тэй тохирох элементүүдээр тусгаарлагдсан дэд хэсгүүдийн давталтыг буцаана.
    /// Тохирсон элемент нь өмнөх дэд самбарын төгсгөлд терминатор байдлаар агуулагддаг.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Хэрэв зүсэлтийн сүүлчийн элемент таарч байвал тухайн элементийг өмнөх зүсэлтийн төгсгөлд тооцно.
    ///
    /// Энэ зүсмэл нь давталтын буцааж өгсөн сүүлчийн зүйл байх болно.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred`-тэй тохирох элементүүдээр тусгаарлагдсан өөрчлөгдөж болох дэд хэсгүүдийн давталтыг буцаана.
    /// Тохирсон элемент нь өмнөх дэд загварт терминатор байдлаар агуулагддаг.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// `pred`-тэй таарч тохирсон элементүүдээр тусгаарлагдсан дэд хэсгүүдийн давталтыг буцаана.
    /// Тохирсон элемент нь дэд хэсгүүдэд ороогүй болно.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()`-тэй адилаар эхний эсвэл сүүлчийн элемент таарч байвал хоосон зүсмэл нь давталтын буцааж өгсөн эхний (эсвэл сүүлчийн) зүйл байх болно.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// `pred`-тэй таарч тохирох элементүүдээр тусгаарлагдсан өөрчлөгдөж болох дэд хэсгүүдийн давталтыг буцаана.
    /// Тохирсон элемент нь дэд хэсгүүдэд ороогүй болно.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Хамгийн ихдээ `n` зүйлийг буцааж өгөхөд хязгаарлагдмал, `pred`-тэй тохирох элементүүдээр тусгаарлагдсан дэд хэсгүүдийн давталтыг буцаана.
    /// Тохирсон элемент нь дэд хэсгүүдэд ороогүй болно.
    ///
    /// Буцаасан сүүлчийн элемент нь хэрвээ үлдсэн бол зүсмэлийн үлдсэн хэсгийг агуулна.
    ///
    /// # Examples
    ///
    /// Зүсмэлийг 3-т хуваагдах тоогоор нэг удаа хэвлэ (өөрөөр хэлбэл `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Хамгийн ихдээ `n` зүйлийг буцааж өгөхөд хязгаарлагдмал, `pred`-тэй тохирох элементүүдээр тусгаарлагдсан дэд хэсгүүдийн давталтыг буцаана.
    /// Тохирсон элемент нь дэд хэсгүүдэд ороогүй болно.
    ///
    /// Буцаасан сүүлчийн элемент нь хэрвээ үлдсэн бол зүсмэлийн үлдсэн хэсгийг агуулна.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Хамгийн ихдээ `n` зүйлийг буцааж өгөхөд хязгаарлагдмал `pred`-тэй тохирох элементүүдээр тусгаарлагдсан дэд хэсгүүдийн давталтыг буцаана.
    /// Энэ нь зүсмэлийн төгсгөлөөс эхэлж, арагшаа ажиллана.
    /// Тохирсон элемент нь дэд хэсгүүдэд ороогүй болно.
    ///
    /// Буцаасан сүүлчийн элемент нь хэрвээ үлдсэн бол зүсмэлийн үлдсэн хэсгийг агуулна.
    ///
    /// # Examples
    ///
    /// Зүсмэлийг 3-т хуваагдах тоогоор (өөрөөр хэлбэл `[50]`, `[10, 40, 30, 20]`) төгсгөлөөс нь эхлэн нэг удаа хэвлэ.
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Хамгийн ихдээ `n` зүйлийг буцааж өгөхөд хязгаарлагдмал `pred`-тэй тохирох элементүүдээр тусгаарлагдсан дэд хэсгүүдийн давталтыг буцаана.
    /// Энэ нь зүсмэлийн төгсгөлөөс эхэлж, арагшаа ажиллана.
    /// Тохирсон элемент нь дэд хэсгүүдэд ороогүй болно.
    ///
    /// Буцаасан сүүлчийн элемент нь хэрвээ үлдсэн бол зүсмэлийн үлдсэн хэсгийг агуулна.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Хэрэв зүсэлт нь өгөгдсөн утгатай элемент агуулсан бол `true` буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Хэрэв танд `&T` байхгүй, гэхдээ `&U` байгаа бол `T: Borrow<U>` (жишээлбэл
    /// Мөр: Зээл авах<str>`), та `iter().any` ашиглаж болно:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String`-ийн зүсмэл
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` ашиглан хайх
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Хэрэв `needle` нь зүсмэлийн угтвар бол `true` буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Хэрэв `needle` нь хоосон зүсмэл бол `true`-ийг үргэлж буцаадаг.
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Хэрэв `needle` нь зүсмийн дагавар бол `true`-ийг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Хэрэв `needle` нь хоосон зүсмэл бол `true`-ийг үргэлж буцаадаг.
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Угтварыг устгасан дэд хэсгийг буцаана.
    ///
    /// Хэрэв зүсэлт `prefix`-ээр эхэлсэн бол угтварыг `Some`-т ороож буцаана.
    /// Хэрэв `prefix` хоосон байвал анхны зүсмэлийг буцааж өг.
    ///
    /// Хэрэв зүсэлт `prefix`-ээр эхлэхгүй бол `None`-ийг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // SlicePattern илүү боловсронгуй болсон тохиолдолд энэ функцийг дахин бичих шаардлагатай болно.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Үр дагаврыг арилгаж дагалдагчийг буцаана.
    ///
    /// Хэрэв зүсэлт `suffix`-ээр төгссөн бол `Some`-т ороосон дагаварын өмнө дэд хэсгийг буцаана.
    /// Хэрэв `suffix` хоосон байвал анхны зүсмэлийг буцааж өг.
    ///
    /// Хэрэв зүсэлт `suffix`-ээр төгсөөгүй бол `None`-ийг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // SlicePattern илүү боловсронгуй болсон тохиолдолд энэ функцийг дахин бичих шаардлагатай болно.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Хоёртын файл нь энэ эрэмбэлэгдсэн зүсэлтийг тухайн элементийг хайж олдог.
    ///
    /// Хэрэв утга олдсон бол тохирох элементийн индексийг агуулсан [`Result::Ok`]-ийг буцаана.
    /// Хэрэв олон таарсан бол аль нэг тоглолтыг буцааж өгөх боломжтой.
    /// Хэрэв утга олдохгүй бол эрэмбэлэгдсэн дарааллыг хадгалахын зэрэгцээ тохирох элемент оруулж болох индексийг багтаасан [`Result::Err`]-ийг буцаана.
    ///
    ///
    /// Мөн [`binary_search_by`], [`binary_search_by_key`], [`partition_point`]-ийг үзнэ үү.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Дөрвөн элементийн цувралыг хайж олох.
    /// Эхнийх нь өвөрмөц шийдсэн байр суурьтай олддог;хоёр дахь, гурав дахь нь олдсонгүй;дөрөв дэх нь `[1, 4]`-ийн аль ч байрлалтай таарч болно.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Хэрэв та ангилах дарааллыг хадгалахын зэрэгцээ эрэмбэлэгдсэн vector-д зүйл оруулахыг хүсвэл:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Хоёртын файл нь харьцуулсан функцээр энэхүү эрэмбэлэгдсэн зүсмэлийг хайж олдог.
    ///
    /// Харьцуулагч функц нь үндсэн зүсмэлийн эрэмбэлэх дараалалд нийцсэн дарааллыг хэрэгжүүлж, түүний аргумент нь `Less`, `Equal` эсвэл `Greater` байгаа эсэхийг харуулсан захиалгын кодыг буцааж өгөх ёстой.
    ///
    ///
    /// Хэрэв утга олдсон бол тохирох элементийн индексийг агуулсан [`Result::Ok`]-ийг буцаана.Хэрэв олон таарсан бол аль нэг тоглолтыг буцааж өгөх боломжтой.
    /// Хэрэв утга олдохгүй бол эрэмбэлэгдсэн дарааллыг хадгалахын зэрэгцээ тохирох элемент оруулж болох индексийг багтаасан [`Result::Err`]-ийг буцаана.
    ///
    /// Мөн [`binary_search`], [`binary_search_by_key`], [`partition_point`]-ийг үзнэ үү.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Дөрвөн элементийн цувралыг хайж олох.Эхнийх нь өвөрмөц шийдсэн байр суурьтай олддог;хоёр дахь, гурав дахь нь олдсонгүй;дөрөв дэх нь `[1, 4]`-ийн аль ч байрлалтай таарч болно.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // АЮУЛГҮЙ АЖИЛЛАГАА: дуудлага нь дараахь өөрчлөгдөөгүй байдлаар хийгддэг.
            // - `mid >= 0`
            // - `mid < size`: `mid` нь `[left; right)` холболтоор хязгаарлагддаг.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Бид яагаад if/else хяналтын урсгалыг тааруулахаас илүүтэй ашигладаг вэ гэхээр төгс тохирох тоглолтын харьцуулалтыг харьцуулах үйлдлийг хийдэг.
            //
            // Энэ бол u8-ийн x86 asm юм: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Хоёртын файл нь энэ ялгасан зүсмэлийг түлхүүр гарган авах функцээр хайж олдог.
    ///
    /// Зүсмэлийг түлхүүрээр нь эрэмбэлсэн гэж үзье, жишээ нь [`sort_by_key`]-тэй ижил түлхүүр олборлох функцийг ашиглана уу.
    ///
    /// Хэрэв утга олдсон бол тохирох элементийн индексийг агуулсан [`Result::Ok`]-ийг буцаана.
    /// Хэрэв олон таарсан бол аль нэг тоглолтыг буцааж өгөх боломжтой.
    /// Хэрэв утга олдохгүй бол эрэмбэлэгдсэн дарааллыг хадгалахын зэрэгцээ тохирох элемент оруулж болох индексийг багтаасан [`Result::Err`]-ийг буцаана.
    ///
    ///
    /// Мөн [`binary_search`], [`binary_search_by`], [`partition_point`]-ийг үзнэ үү.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Дөрвөн элементийн цувралыг хоёр дахь элементээр нь эрэмбэлсэн хос зүсмэл дотор хайж олно.
    /// Эхнийх нь өвөрмөц шийдсэн байр суурьтай олддог;хоёр дахь, гурав дахь нь олдсонгүй;дөрөв дэх нь `[1, 4]`-ийн аль ч байрлалтай таарч болно.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // `slice::sort_by_key` нь crate `alloc`-т байрладаг тул Lint rustdoc::broken_intra_doc_links-ийг зөвшөөрдөг бөгөөд `core` бүтээхэд одоогоор байхгүй байна.
    //
    // адаг crate: #74481 руу холбоосууд.Командын командууд зөвхөн libstd (#73423) дээр бичигдсэн байдаг тул энэ нь практик дээр хэзээ ч эвдэрсэн холбоос руу хөтөлдөггүй.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Зүсмэлийг эрэмбэлэх боловч тэнцүү элементүүдийн дарааллыг хадгалахгүй байж магадгүй юм.
    ///
    /// Энэ ангилал нь тогтворгүй (өөрөөр хэлбэл тэнцүү элементүүдийг эрэмбэлж болно), байрандаа (өөрөөр хэлбэл хуваарилахгүй),*O*(*n*\*log(* n*)) хамгийн муу тохиолдол юм.
    ///
    /// # Одоогийн хэрэгжилт
    ///
    /// Одоогийн алгоритм нь Orson Peters-ийн [pattern-defeating quicksort][pdqsort] дээр суурилсан бөгөөд энэ нь санамсаргүй тохиолдлын квиксорсын хамгийн хурдан тохиолдлыг хамгийн хурдан тохиолдлын хэлбэртэй хослуулан, тодорхой хэв маяг бүхий зүсмэлүүд дээр шугаман хугацааг олж авах боломжийг олгодог.
    /// Энэ нь доройтсон тохиолдлоос зайлсхийхийн тулд зарим санамсаргүй аргыг ашигладаг боловч тогтмол seed-тэй детерминик шинж чанарыг байнга өгдөг.
    ///
    /// Энэ нь ихэвчлэн тогтвортой ангилалтаас хурдан байдаг, жишээлбэл, зүсмэл нь хэд хэдэн нийлсэн эрэмбэлэгдсэн дарааллаас бүрдэх тохиолдолд л тохиолддог.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Зүсмэлийг харьцуулагч функцээр эрэмбэлэх боловч тэнцүү элементүүдийн дарааллыг хадгалахгүй байж магадгүй юм.
    ///
    /// Энэ ангилал нь тогтворгүй (өөрөөр хэлбэл тэнцүү элементүүдийг эрэмбэлж болно), байрандаа (өөрөөр хэлбэл хуваарилахгүй),*O*(*n*\*log(* n*)) хамгийн муу тохиолдол юм.
    ///
    /// Харьцуулагч функц нь зүсмэл дэх элементүүдийн нийт захиалгыг тодорхойлох ёстой.Хэрэв захиалга нийт биш бол элементүүдийн дарааллыг тодорхойлоогүй болно.Захиалга бол (нийт `a`, `b` ба `c`-ийн хувьд) нийт захиалга юм.
    ///
    /// * нийт ба антисиметрийн: `a < b`, `a == b` эсвэл `a > b`-ийн яг нэг нь үнэн, ба
    /// * дамжуулагч, `a < b` ба `b < c` нь `a < c`-ийг илэрхийлдэг.`==` ба `>` хоёуланд нь ижил байх ёстой.
    ///
    /// Жишээлбэл, [`f64`] нь [`Ord`]-ийг `NaN != NaN`-ийг хэрэгжүүлдэггүй тул бид `partial_cmp`-ийг ялгах функц болгон ашиглаж болно, хэрвээ зүсэлт `NaN` агуулаагүй болохыг мэдвэл.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Одоогийн хэрэгжилт
    ///
    /// Одоогийн алгоритм нь Orson Peters-ийн [pattern-defeating quicksort][pdqsort] дээр суурилсан бөгөөд энэ нь санамсаргүй тохиолдлын квиксорсын хамгийн хурдан тохиолдлыг хамгийн хурдан тохиолдлын хэлбэртэй хослуулан, тодорхой хэв маяг бүхий зүсмэлүүд дээр шугаман хугацааг олж авах боломжийг олгодог.
    /// Энэ нь доройтсон тохиолдлоос зайлсхийхийн тулд зарим санамсаргүй аргыг ашигладаг боловч тогтмол seed-тэй детерминик шинж чанарыг байнга өгдөг.
    ///
    /// Энэ нь ихэвчлэн тогтвортой ангилалтаас хурдан байдаг, жишээлбэл, зүсмэл нь хэд хэдэн нийлсэн эрэмбэлэгдсэн дарааллаас бүрдэх тохиолдолд л тохиолддог.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // урвуу ангилах
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Түлхүүр ялгах функц бүхий зүсмэлийг эрэмбэлэх боловч тэнцүү элементүүдийн дарааллыг хадгалахгүй байж магадгүй юм.
    ///
    /// Энэ ангилал нь тогтворгүй (өөрөөр хэлбэл тэнцүү элементүүдийг эрэмбэлж болно), байрандаа (өөрөөр хэлбэл хуваарилахгүй),*O*(m\* * n *\* log(*n*)) хамгийн муу тохиолдолд, гол функц нь *O*(*м*).
    ///
    /// # Одоогийн хэрэгжилт
    ///
    /// Одоогийн алгоритм нь Orson Peters-ийн [pattern-defeating quicksort][pdqsort] дээр суурилсан бөгөөд энэ нь санамсаргүй тохиолдлын квиксорсын хамгийн хурдан тохиолдлыг хамгийн хурдан тохиолдлын хэлбэртэй хослуулан, тодорхой хэв маяг бүхий зүсмэлүүд дээр шугаман хугацааг олж авах боломжийг олгодог.
    /// Энэ нь доройтсон тохиолдлоос зайлсхийхийн тулд зарим санамсаргүй аргыг ашигладаг боловч тогтмол seed-тэй детерминик шинж чанарыг байнга өгдөг.
    ///
    /// Түлхүүр дуудлага хийх стратегийн ачаар [`sort_unstable_by_key`](#method.sort_unstable_by_key) нь түлхүүр функц нь үнэтэй тохиолдолд [`sort_by_cached_key`](#method.sort_by_cached_key)-ээс удаан байх магадлалтай.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// `index` дээрх элемент эцсийн эрэмбэлэгдсэн байрлалд байхаар зүсмэлийг дахин байрлуулна уу.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// `index` дээрх элемент эцсийн эрэмбэлэгдсэн байрлалд байхаар харьцуулагчийн функцээр зүсмэлийг дахин байрлуул.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// `index` дээрх элемент эцсийн эрэмбэлэгдсэн байрлалд байхаар гол ялгах функцээр зүсмэлийг эрэмбэл.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// `index` дээрх элемент эцсийн эрэмбэлэгдсэн байрлалд байхаар зүсмэлийг дахин байрлуулна уу.
    ///
    /// Энэхүү дахин захиалга нь `i < index` байрлал дахь аливаа утга нь `j > index` байрлал дахь ямар ч утгаас бага эсвэл тэнцүү байх нэмэлт шинж чанартай болно.
    /// Нэмж дурдахад энэ захиалга тогтворгүй байна (өөрөөр хэлбэл
    /// хэд хэдэн тэнцүү элементүүд `index` байрлалд хүрч болно, байрандаа (өөрөөр хэлбэл
    /// хуваарилдаггүй),*O*(*n*) хамгийн муу тохиолдол.
    /// Энэ функцийг бусад номын санд "kth element" гэж нэрлэдэг.
    /// Энэ нь дараахь утгуудын гурвалсан гурвыг буцааж өгдөг: өгөгдсөн индекс дээрх бүх элементүүд, өгөгдсөн индекс дээрх утга ба өгөгдсөн индексээс том бүх элементүүд.
    ///
    ///
    /// # Одоогийн хэрэгжилт
    ///
    /// Одоогийн алгоритм нь [`sort_unstable`]-т ашиглагдаж байсан quicksort алгоритмын хурдан сонгосон хэсэгт суурилсан болно.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` үед Panics, энэ нь хоосон зүсмэл дээр үргэлж panics гэсэн үг юм.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Дундажийг ол
    /// v.select_nth_unstable(2);
    ///
    /// // Бид заасан индексийг ангилах арга дээр үндэслэн зүсмэлүүд нь дараахь зүйлсийн аль нэг нь байх болно.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` дээрх элемент эцсийн эрэмбэлэгдсэн байрлалд байхаар харьцуулагчийн функцээр зүсмэлийг дахин байрлуул.
    ///
    /// Энэхүү эрэмбэлэлт нь `i < index` байрлал дахь ямар ч утга харьцуулах функцийг ашиглан `j > index` байрлал дахь ямар ч утгаас бага эсвэл тэнцүү байх нэмэлт шинж чанартай болно.
    /// Нэмж дурдахад энэ дахин захиалга нь тогтворгүй (өөрөөр хэлбэл тэнцүү тооны элементүүд `index` байрлалд дуусч магадгүй), байрандаа (өөрөөр хэлбэл хуваарилдаггүй),*O*(*n*) хамгийн муу тохиолдол юм.
    /// Энэ функцийг бусад номын санд "kth element" гэж нэрлэдэг.
    /// Энэ нь өгөгдсөн индекс дээрх нэг элементээс бага бүх элемент, өгөгдсөн индекс дээрх утга ба өгөгдсөн индекс дээрх бүх элементүүдийг харьцуулсан функцийг ашиглан дараахь гурван утгыг буцаана.
    ///
    ///
    /// # Одоогийн хэрэгжилт
    ///
    /// Одоогийн алгоритм нь [`sort_unstable`]-т ашиглагдаж байсан quicksort алгоритмын хурдан сонгосон хэсэгт суурилсан болно.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` үед Panics, энэ нь хоосон зүсмэл дээр үргэлж panics гэсэн үг юм.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Зүсмэлийг буурах дарааллаар эрэмбэлсэн мэт медианыг ол.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Бид заасан индексийг ангилах арга дээр үндэслэн зүсмэлүүд нь дараахь зүйлсийн аль нэг нь байх болно.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` дээрх элемент эцсийн эрэмбэлэгдсэн байрлалд байхаар гол ялгах функцээр зүсмэлийг эрэмбэл.
    ///
    /// Энэхүү эрэмбэлэлт нь `i < index` байрлал дахь аливаа утга нь түлхүүр ялгах функцийг ашиглан `j > index` байрлал дахь аливаа утгаас бага эсвэл тэнцүү байх нэмэлт шинж чанартай байдаг.
    /// Нэмж дурдахад энэ дахин захиалга нь тогтворгүй (өөрөөр хэлбэл тэнцүү тооны элементүүд `index` байрлалд дуусч магадгүй), байрандаа (өөрөөр хэлбэл хуваарилдаггүй),*O*(*n*) хамгийн муу тохиолдол юм.
    /// Энэ функцийг бусад номын санд "kth element" гэж нэрлэдэг.
    /// Энэ нь өгөгдсөн индекст ороогүй бүх элементүүд, өгөгдсөн индекс дээрх утга ба өгөгдсөн индекст орших бүх элементүүд өгөгдсөн түлхүүр олборлох функцийг ашиглан дараахь гурван утгыг буцаана.
    ///
    ///
    /// # Одоогийн хэрэгжилт
    ///
    /// Одоогийн алгоритм нь [`sort_unstable`]-т ашиглагдаж байсан quicksort алгоритмын хурдан сонгосон хэсэгт суурилсан болно.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` үед Panics, энэ нь хоосон зүсмэл дээр үргэлж panics гэсэн үг юм.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Массивыг үнэмлэхүй утгын дагуу эрэмбэлсэн мэт медианийг буцаана.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Бид заасан индексийг ангилах арга дээр үндэслэн зүсмэлүүд нь дараахь зүйлсийн аль нэг нь байх болно.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Бүх дараалсан давтагдсан элементүүдийг [`PartialEq`] trait хэрэгжүүлэлтийн дагуу зүсмэлийн төгсгөлд шилжүүлдэг.
    ///
    ///
    /// Хоёр зүсмэлийг буцаана.Эхнийх нь дараалсан давтагдах элемент агуулаагүй болно.
    /// Хоёр дахь нь бүх хуулбарыг тодорхой дарааллаар агуулаагүй болно.
    ///
    /// Хэрэв зүсмэлийг эрэмбэлсэн бол эхний буцаасан зүсмэл нь давхардсан агуулаагүй болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Өгөгдсөн тэгш байдлын харьцааг хангасан эхний дараалсан элементүүдээс бусад бүх зүйлийг зүсмэлийн төгсгөл рүү шилжүүлнэ.
    ///
    /// Хоёр зүсмэлийг буцаана.Эхнийх нь дараалсан давтагдах элемент агуулаагүй болно.
    /// Хоёр дахь нь бүх хуулбарыг тодорхой дарааллаар агуулаагүй болно.
    ///
    /// `same_bucket` функцийг зүсмэлээс хоёр элементийн лавлагаагаар дамжуулж, элементүүд хоорондоо тэнцүү байгаа эсэхийг тодорхойлох ёстой.
    /// Элементүүдийг зүсмэл дэх дарааллаас нь эсрэг дарааллаар дамжуулдаг тул хэрвээ `same_bucket(a, b)` `true`-ийг буцааж өгвөл зүсмэлийн төгсгөлд `a`-ийг зөөнө.
    ///
    ///
    /// Хэрэв зүсмэлийг эрэмбэлсэн бол эхний буцаасан зүсмэл нь давхардсан агуулаагүй болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Хэдийгээр бид `self`-ийн талаар өөрчлөгдөж болох лавлагаатай боловч *дурын* өөрчлөлт хийж чадахгүй.`same_bucket` дуудлага нь panic байж болох тул бид зүсмэлийг үргэлж хүчин төгөлдөр байдалд байлгах ёстой.
        //
        // Бидний үүнийг шийдвэрлэх арга бол своп хэлцлийг ашиглах явдал юм.Бид эцэст нь бидний хадгалахыг хүссэн элементүүд урд талд, харин татгалзахыг хүссэн хүмүүс ар талдаа байхаар сольж, бүх элементүүд дээр давталт хийдэг.
        // Дараа нь бид зүсмэлийг хувааж болно.
        // Энэ ажиллагаа `O(n)` хэвээр байна.
        //
        // Жишээ: Бид энэ төлөвөөс эхэлж, `r` нь "next"-ийг илэрхийлнэ
        // унших "ба `w` нь" next_write`-г илэрхийлнэ.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // self[r]-ийг өөрийгөө [w-1]-тэй харьцуулж үзэхэд энэ нь давхардсан зүйл биш тул бид self[r] ба self[w]-г сольж (r==w гэх мэт ямар ч нөлөө үзүүлэхгүй) дараа нь r ба w-ийг хоёуланг нь нэмээд дараахь зүйлийг үлдээнэ үү.
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r]-ийг self [w-1]-тэй харьцуулж үзэхэд энэ утга нь давхардсан тул бид `r`-ийг нэмэгдүүлж, бусад бүх зүйлийг хэвээр үлдээнэ.
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r]-ийг өөрийгөө [w-1]-тэй харьцуулж үзэхэд энэ нь давхардсан зүйл биш тул self[r] ба self[w]-г сольж, r ба w-ийг ахиул:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Давхардсан зүйл биш.
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Хуулбар, advance r. End зүсмэл.W дээр хуваах.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // АЮУЛГҮЙ БАЙДАЛ: `while` нөхцөл нь `next_read` ба `next_write`-ийг баталгаажуулдаг
        // `len`-ээс бага тул `self` дотор байна.
        // `prev_ptr_write` `ptr_write`-ээс өмнө нэг элементийг зааж өгөх боловч `next_write` 1-ээс эхэлдэг тул `prev_ptr_write` нь хэзээ ч 0-ээс багагүй бөгөөд зүсмэл дотор байрлана.
        // Энэ нь `ptr_read`, `prev_ptr_write` ба `ptr_write`-ийг ялгах, `ptr.add(next_read)`, `ptr.add(next_write - 1)` ба `prev_ptr_write.offset(1)`-ийг ашиглах шаардлагыг хангасан болно.
        //
        //
        // `next_write` мөн давталт тутамд хамгийн ихдээ нэг удаа нэмэгддэг тул солих шаардлагатай тохиолдолд ямар ч элемент алгасахгүй гэсэн үг юм.
        //
        // `ptr_read` ба `prev_ptr_write` хэзээ ч ижил элемент рүү чиглүүлдэггүй.Энэ нь `&mut *ptr_read`, `&mut* prev_ptr_write` аюулгүй байхын тулд шаардлагатай болно.
        // Тайлбар нь `next_read >= next_write` үргэлж үнэн байдаг тул `next_read > next_write - 1` нь бас үнэн байдаг.
        //
        //
        //
        //
        //
        unsafe {
            // Түүхий заагч ашиглан хязгаарыг шалгахаас зайлсхий.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Дараалсан элементүүдийн эхнийхээс бусад бүх зүйлийг ижил түлхүүр хүртэл шийдсэн зүсмэлийн төгсгөл рүү шилжүүлдэг.
    ///
    ///
    /// Хоёр зүсмэлийг буцаана.Эхнийх нь дараалсан давтагдах элемент агуулаагүй болно.
    /// Хоёр дахь нь бүх хуулбарыг тодорхой дарааллаар агуулаагүй болно.
    ///
    /// Хэрэв зүсмэлийг эрэмбэлсэн бол эхний буцаасан зүсмэл нь давхардсан агуулаагүй болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Зүсмэлийг эхний `mid` элементүүд төгсгөл хүртэл, харин сүүлчийн `self.len() - mid` элементүүд урд тал руу шилжих байдлаар зүсмэлийг байрандаа эргүүлнэ.
    /// `rotate_left` руу залгасны дараа `mid` индекс дээр байсан элемент нь зүсмэлийн эхний элемент болно.
    ///
    /// # Panics
    ///
    /// Хэрэв `mid` нь зүсмэлийн уртаас их байвал энэ функц panic болно.`mid == self.len()` нь _not_ panic хийдэг бөгөөд энэ нь ямар ч сонголтгүй эргэлт гэдгийг анхаарна уу.
    ///
    /// # Complexity
    ///
    /// Шугаман (`self.len()`) цагт) авдаг.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Хадгаламжийг эргүүлэх:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // АЮУЛГҮЙ БАЙДАЛ: `[p.add(mid) - mid, p.add(mid) + k)` муж нь тийм ч чухал биш юм
        // `ptr_rotate`-ийн шаардлагын дагуу унших, бичихэд хүчинтэй.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Зүсмэлийг эхний `self.len() - k` элементүүд төгсгөл хүртэл, харин сүүлчийн `k` элементүүд урд тал руу шилжих байдлаар зүсмэлийг байрандаа эргүүлнэ.
    /// `rotate_right` руу залгасны дараа `self.len() - k` индекс дээр байсан элемент нь зүсмэлийн эхний элемент болно.
    ///
    /// # Panics
    ///
    /// Хэрэв `k` нь зүсмэлийн уртаас их байвал энэ функц panic болно.`k == self.len()` нь _not_ panic хийдэг бөгөөд энэ нь ямар ч сонголтгүй эргэлт гэдгийг анхаарна уу.
    ///
    /// # Complexity
    ///
    /// Шугаман (`self.len()`) цагт) авдаг.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Хадгаламжийг эргүүлэх:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // АЮУЛГҮЙ БАЙДАЛ: `[p.add(mid) - mid, p.add(mid) + k)` муж нь тийм ч чухал биш юм
        // `ptr_rotate`-ийн шаардлагын дагуу унших, бичихэд хүчинтэй.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `value`-ийг клончлох замаар `self`-ийг элементүүдээр дүүргэнэ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Хаалтыг дахин дахин дуудаж буцааж өгсөн элементүүдээр `self`-ийг дүүргэнэ.
    ///
    /// Энэ арга нь шинэ утгыг бий болгохын тулд хаалтыг ашигладаг.Хэрэв та өгөгдсөн утгыг [`Clone`] болгохыг хүсч байвал [`fill`] ашиглана уу.
    /// Хэрэв та утга үүсгэхийн тулд [`Default`] trait-ийг ашиглахыг хүсвэл [`Default::default`]-ийг аргумент болгон өгч болно.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src`-ээс `self` руу элементүүдийг хуулна.
    ///
    /// `src`-ийн урт нь `self`-тэй ижил байх ёстой.
    ///
    /// Хэрэв `T` нь `Copy`-ийг хэрэгжүүлж байгаа бол [`copy_from_slice`]-ийг ашиглах нь илүү гүйцэтгэлтэй байж болно.
    ///
    /// # Panics
    ///
    /// Хоёр зүсмэлийн урт өөр байвал энэ функц panic болно.
    ///
    /// # Examples
    ///
    /// Хоёр элементийг зүсмэлээс нөгөө рүү клончлох:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Зүсмэлүүд ижил урттай байх ёстой тул бид эх зүсмэлийг дөрвөн элементээс хоёр хэсэг болгон хуваадаг.
    /// // Хэрэв бид үүнийг хийхгүй бол энэ нь panic болно.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust нь тодорхой хүрээнд тодорхой өгөгдөлд хувьсашгүй ишлэл оруулахгүйгээр зөвхөн нэг өөрчлөгдөж болох лавлагаа байж болохыг баталгаажуулдаг.
    /// Үүнээс болоод `clone_from_slice`-ийг нэг зүсмэл дээр ашиглахыг оролдох нь хөрвүүлэлт бүтэлгүйтэхэд хүргэнэ.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Үүнийг тойрон гарахын тулд бид [`split_at_mut`]-ийг ашиглан зүсмэлээс хоёр ялгаатай дэд зүсмэлүүдийг үүсгэж болно.
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Бүх элементүүдийг memcpy ашиглан `src`-ээс `self` руу хуулна.
    ///
    /// `src`-ийн урт нь `self`-тэй ижил байх ёстой.
    ///
    /// Хэрэв `T` нь `Copy`-ийг хэрэгжүүлээгүй бол [`clone_from_slice`]-ийг ашиглаарай.
    ///
    /// # Panics
    ///
    /// Хоёр зүсмэлийн урт өөр байвал энэ функц panic болно.
    ///
    /// # Examples
    ///
    /// Хоёр элементийг зүсмэлээс нөгөө рүү хуулах:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Зүсмэлүүд ижил урттай байх ёстой тул бид эх зүсмэлийг дөрвөн элементээс хоёр хэсэг болгон хуваадаг.
    /// // Хэрэв бид үүнийг хийхгүй бол энэ нь panic болно.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust нь тодорхой хүрээнд тодорхой өгөгдөлд хувьсашгүй ишлэл оруулахгүйгээр зөвхөн нэг өөрчлөгдөж болох лавлагаа байж болохыг баталгаажуулдаг.
    /// Үүнээс болоод `copy_from_slice`-ийг нэг зүсмэл дээр ашиглахыг оролдох нь хөрвүүлэлт бүтэлгүйтэхэд хүргэнэ.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Үүнийг тойрон гарахын тулд бид [`split_at_mut`]-ийг ашиглан зүсмэлээс хоёр ялгаатай дэд зүсмэлүүдийг үүсгэж болно.
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic кодын зам нь дуудлагын сайтыг дүүргэхгүйн тулд хүйтэн функцэд оруулсан болно.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // Аюулгүй байдал: `self` нь `self.len()` элементүүдийн хувьд хүчин төгөлдөр бөгөөд `src` нь хүчин төгөлдөр байсан
        // ижил урттай эсэхийг шалгасан.
        // Хувьсах боломжтой лавлагаа нь онцгой тул зүсмэлүүд давхцах боломжгүй.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Меммов ашиглан элементүүдийг зүсмэлийн нэг хэсгээс нөгөө хэсэг рүү хуулна.
    ///
    /// `src` нь хуулбарлах `self` доторх муж юм.
    /// `dest` нь `src`-тэй ижил урттай хуулж авах `self` доторх мужийн эхлэх индекс юм.
    /// Хоёр муж давхцаж магадгүй юм.
    /// Хоёр мужуудын төгсгөлүүд `self.len()`-ээс бага эсвэл тэнцүү байх ёстой.
    ///
    /// # Panics
    ///
    /// Энэ функц нь зүсэлтийн төгсгөлөөс хэтэрсэн эсвэл `src` төгсгөл эхлэхээс өмнө байвал энэ функц panic болно.
    ///
    ///
    /// # Examples
    ///
    /// Дөрвөн байтыг зүсмэл дотор хуулах:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // АЮУЛГҮЙ БАЙДАЛ: `ptr::copy`-ийн нөхцлийг бүгдийг нь шалгасан,
        // `ptr::add`-тэй адил.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `self` дээрх бүх элементүүдийг `other`-тэй солино.
    ///
    /// `other`-ийн урт нь `self`-тэй ижил байх ёстой.
    ///
    /// # Panics
    ///
    /// Хоёр зүсмэлийн урт өөр байвал энэ функц panic болно.
    ///
    /// # Example
    ///
    /// Хоёр элементийг зүсмэлүүдээр солих.
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust нь тодорхой хүрээний тодорхой өгөгдөлд зөвхөн нэг өөрчлөгдөж болох лавлагаа байж болохыг баталгаажуулдаг.
    ///
    /// Үүнээс болоод `swap_with_slice`-ийг нэг зүсмэл дээр ашиглахыг оролдох нь хөрвүүлэлт бүтэлгүйтэхэд хүргэнэ.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Үүнийг тойрон гарахын тулд бид [`split_at_mut`]-ийг ашиглан зүсмэлээс хоёр ялгаатай өөрчлөгдөж болох дэд зүсмэлүүдийг үүсгэж болно.
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // Аюулгүй байдал: `self` нь `self.len()` элементүүдийн хувьд хүчин төгөлдөр бөгөөд `src` нь хүчин төгөлдөр байсан
        // ижил урттай эсэхийг шалгасан.
        // Хувьсах боломжтой лавлагаа нь онцгой тул зүсмэлүүд давхцах боломжгүй.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}`-ийн дунд болон арын зүсмэлийн уртыг тооцоолох функц.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // `rest`-ийн талаар юу хийх вэ гэвэл бид хамгийн бага тооны "T`"-д хэдэн ширхэг U оруулах боломжтойг олж мэдэх болно.
        //
        // Ийм "multiple" тутамд бидэнд хичнээн T` хэрэгтэй болно.
        //
        // Жишээлбэл T=u8 U=u16-ийг авч үзье.Дараа нь бид 2 U-д 1 U тавьж болно.Энгийн.
        // Одоо, жишээ нь size_of: : тохиолдлыг авч үзье.<T>=16, хэмжээ нь::<U>=24.</u>
        // Бид `rest` зүсмэл дэх 3 Ts-ийн оронд 2 Us-ийг тавьж болно.
        // Бага зэрэг илүү төвөгтэй.
        //
        // Үүнийг тооцоолох томъёо нь:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Өргөтгөсөн, хялбаршуулсан:
        //
        // Бид=хэмжээтэй: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Энэ бүх зүйлийг тогтмол үнэлдэг тул аз болоход энд гүйцэтгэл чухал биш юм!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // давтагдах Stein-ийн алгоритм Бид энэ `const fn`-ийг хийх ёстой (хэрэв үүнийг хийвэл рекурсив алгоритм руу буцах хэрэгтэй), учир нь энэ бүхнийг нягтруулахын тулд llvm-д найдах нь ... сайн байна, энэ нь надад таагүй санагдаж байна.
            //
            //

            // АЮУЛГҮЙ АЖИЛЛАГАА: `a` ба `b` нь тэгээс бусад утгатай эсэхийг шалгана.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // b-ээс 2-ын бүх хүчин зүйлийг хасах
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // АЮУЛГҮЙ БАЙДАЛ: `b`-ийг тэг биш гэж шалгана.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Энэхүү мэдлэгээр зэвсэглэвэл бид хичнээн U` багтааж чадахаа олж чадна!
        let us_len = self.len() / ts * us;
        // Дараачийн зүсмэл дотор хичнээн T` байх болно!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Зүсмэлийг өөр төрлийн зүсмэл рүү шилжүүлж, төрлүүдийн уялдаа холбоог хангана.
    ///
    /// Энэ арга нь зүсмэлийг гурван ялгаатай зүсмэл болгон хуваадаг: угтвар, шинэ төрлийн дунд зүсэлт, залгаасын зүсмэл.
    /// Энэ арга нь дунд зүсэлтийг өгөгдсөн төрөл ба оролтын зүсэлтийн хувьд хамгийн их урттай болгож болох боловч зөвхөн таны алгоритмын гүйцэтгэл нь түүний зөв эсэхээс хамаарна.
    ///
    /// Оруулсан бүх өгөгдлийг угтвар эсвэл дагавар зүсмэл хэлбэрээр буцааж өгөхийг зөвшөөрнө.
    ///
    /// Энэ арга нь оролтын элемент `T` эсвэл гаралтын элемент `U` нь тэг хэмжээтэй байх тул ямар ч зүйлийг хуваахгүйгээр анхны зүсмэлийг буцааж өгөхөд ямар ч зорилгогүй болно.
    ///
    /// # Safety
    ///
    /// Энэ арга нь үндсэндээ буцаж ирсэн дунд зүсмэл дэхь элементүүдийн хувьд `transmute` тул `transmute::<T, U>`-т хамаарах ердийн бүх анхааруулга энд хамаарна.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Энэ функцийн ихэнх хэсгийг тогтмол үнэлэх болно гэдгийг анхаарна уу.
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST-үүдийг тусгайлан зохицуулах, өөрөөр хэлбэл тэдэнтэй харьцах хэрэггүй.
            return (self, &[], &[]);
        }

        // Нэгдүгээрт, бид эхний болон 2-р зүсмэлийг хооронд нь хувааж үзээрэй.
        // ptr.align_offset ашиглан хялбар.
        let ptr = self.as_ptr();
        // АЮУЛГҮЙ БАЙДАЛ: Аюулгүй байдлын дэлгэрэнгүй тайлбарыг `align_to_mut` аргыг үзнэ үү.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // АЮУЛГҮЙ БАЙДАЛ: одоо `rest` нь хоорондоо уялдаатай тул доорхи `from_raw_parts` зүгээр,
            // Учир нь дуудагч бид `T`-ийг `U` руу аюулгүй дамжуулж чадна гэсэн баталгаа өгдөг.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Зүсмэлийг өөр төрлийн зүсмэл рүү шилжүүлж, төрлүүдийн уялдаа холбоог хангана.
    ///
    /// Энэ арга нь зүсмэлийг гурван ялгаатай зүсмэл болгон хуваадаг: угтвар, шинэ төрлийн дунд зүсэлт, залгаасын зүсмэл.
    /// Энэ арга нь дунд зүсэлтийг өгөгдсөн төрөл ба оролтын зүсэлтийн хувьд хамгийн их урттай болгож болох боловч зөвхөн таны алгоритмын гүйцэтгэл нь түүний зөв эсэхээс хамаарна.
    ///
    /// Оруулсан бүх өгөгдлийг угтвар эсвэл дагавар зүсмэл хэлбэрээр буцааж өгөхийг зөвшөөрнө.
    ///
    /// Энэ арга нь оролтын элемент `T` эсвэл гаралтын элемент `U` нь тэг хэмжээтэй байх тул ямар ч зүйлийг хуваахгүйгээр анхны зүсмэлийг буцааж өгөхөд ямар ч зорилгогүй болно.
    ///
    /// # Safety
    ///
    /// Энэ арга нь үндсэндээ буцаж ирсэн дунд зүсмэл дэхь элементүүдийн хувьд `transmute` тул `transmute::<T, U>`-т хамаарах ердийн бүх анхааруулга энд хамаарна.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Энэ функцийн ихэнх хэсгийг тогтмол үнэлэх болно гэдгийг анхаарна уу.
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST-үүдийг тусгайлан зохицуулах, өөрөөр хэлбэл тэдэнтэй харьцах хэрэггүй.
            return (self, &mut [], &mut []);
        }

        // Нэгдүгээрт, бид эхний болон 2-р зүсмэлийг хооронд нь хувааж үзээрэй.
        // ptr.align_offset ашиглан хялбар.
        let ptr = self.as_ptr();
        // АЮУЛГҮЙ БАЙДАЛ: Энд бид U-д тохируулсан заагчийг ашиглах болно
        // үлдсэн арга.Үүнийг заагчийг&[T] руу U руу чиглэсэн тохируулгаар дамжуулж гүйцэтгэнэ.
        // `crate::ptr::align_offset` зөв уялдуулсан, хүчин төгөлдөр `ptr` заагчтай (`self`-ийн лавлагаанаас үүдэлтэй) ба хоёрын хэмжээтэй (U-ийн тохиргооноос гарах тул) аюулгүй байдлын хязгаарлалтыг хангасан хэмжээтэйгээр дуудагдана.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Үүний дараа бид `rest`-ийг дахин ашиглах боломжгүй бөгөөд энэ нь түүний `mut_ptr` гэсэн нэрийг хүчингүй болгох болно!АЮУЛГҮЙ БАЙДАЛ: `align_to`-ийн тайлбарыг үзнэ үү.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Энэ зүсмэлийн элементүүдийг эрэмбэлсэн эсэхийг шалгана.
    ///
    /// Энэ нь `a` элемент ба түүний дараахь `b` элемент бүрийн хувьд `a <= b` байх ёстой.Хэрэв зүсэлт нь яг тэг эсвэл нэг элемент гарвал `true` буцаагдана.
    ///
    /// Хэрэв `Self::Item` нь зөвхөн `PartialOrd` боловч `Ord` биш бол дээрх тодорхойлолт нь дараалсан хоёр зүйлийг харьцуулах боломжгүй тохиолдолд энэ функц `false`-ийг буцааж өгөх болно гэдгийг анхаарна уу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Өгөгдсөн харьцуулагч функцийг ашиглан энэ зүсмэлийн элементүүдийг эрэмбэлсэн эсэхийг шалгана.
    ///
    /// Энэ функц нь `PartialOrd::partial_cmp` ашиглахын оронд өгөгдсөн `compare` функцийг ашиглан хоёр элементийн дарааллыг тодорхойлдог.
    /// Үүнээс гадна энэ нь [`is_sorted`]-тэй тэнцүү юм;дэлгэрэнгүй мэдээллийг түүний баримт бичгээс үзнэ үү.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Энэ зүсэлтийн элементүүдийг өгөгдсөн түлхүүр олборлох функцийг ашиглан эрэмбэлсэн эсэхийг шалгана.
    ///
    /// Зүсмэлийн элементүүдийг шууд харьцуулахын оронд энэ функц нь `f`-ээр тодорхойлогдсон элементүүдийн түлхүүрүүдийг харьцуулдаг.
    /// Үүнээс гадна энэ нь [`is_sorted`]-тэй тэнцүү юм;дэлгэрэнгүй мэдээллийг түүний баримт бичгээс үзнэ үү.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Өгөгдсөн предикатын дагуу хуваалтын цэгийн индексийг буцаана (хоёр дахь хуваалтын эхний элементийн индекс).
    ///
    /// Зүсмэлийг өгөгдсөн прикатын дагуу хуваасан гэж үзнэ.
    /// Энэ нь урьдчилсан утга үнэн эргэж буй бүх элементүүд зүсмэлийн эхэнд байгаа бөгөөд худал өгөгдлөөр буцаж ирдэг бүх элементүүд төгсгөлд байна гэсэн үг юм.
    ///
    /// Жишээлбэл, [7, 15, 3, 5, 4, 12, 6] нь x% 2!=0 гэсэн үндсэн үгийн дор хуваагдана (бүх сондгой тоонууд эхэнд, бүгд төгсгөлдөө).
    ///
    /// Хэрэв энэ зүсмэлийг хуваахгүй бол буцааж өгсөн үр дүн нь тодорхойгүй, утгагүй болно, учир нь энэ арга нь хоёртын төрлийн хайлт хийдэг.
    ///
    /// Мөн [`binary_search`], [`binary_search_by`], [`binary_search_by_key`]-ийг үзнэ үү.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // Аюулгүй байдал: `left < right` үед, `left <= mid < right`.
            // Тиймээс `left` үргэлж нэмэгдэж, `right` үргэлж буурч, тэдгээрийн аль нэгийг нь сонгодог.Хоёр тохиолдолд `left <= right` сэтгэл хангалуун байна.Тиймээс хэрэв `left < right` алхам дээр байвал `left <= right` дараагийн шатанд сэтгэл ханамжтай байна.
            //
            // Тиймээс `left != right` бол `0 <= left < right <= len` сэтгэл хангалуун байх болно, хэрэв энэ тохиолдолд `0 <= mid < len` бас сэтгэл ханамжтай байвал.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Бид тэдгээрийг ижил уртаар нь зүсэх хэрэгтэй
        // оновчлогч хил хязгаарыг арилгах ажлыг хөнгөвчлөх.
        // Гэхдээ үүнд найдах боломжгүй тул бид T: Copy-ийн талаар нарийн мэргэшсэн байдаг.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Хоосон зүсмэл үүсгэдэг.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Өөрчилж болох хоосон зүсмэлийг үүсгэдэг.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Одоогоор зөвхөн `strip_prefix` ба `strip_suffix`-д ашиглагддаг зүсмэл хэлбэртэй хээ.
/// future цэг дээр бид `core::str::Pattern`-ийг (бичих үед `str`-ээр хязгаарлагддаг) зүсмэлүүд дээр нэгтгэж, дараа нь энэ trait-ийг солих эсвэл цуцлах болно гэж найдаж байна.
///
pub trait SlicePattern {
    /// Тохирсон зүсмэлийн элементийн төрөл.
    type Item;

    /// Одоогийн байдлаар `SlicePattern`-ийн хэрэглэгчид зүсмэл хэрэгтэй байна.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}