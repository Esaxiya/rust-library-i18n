//! Зүсмэлийг давтан ашигладаг макро.

// Дотор нь хоосон, хоосон байгаа нь гүйцэтгэлийн асар их өөрчлөлтийг бий болгодог
macro_rules! is_empty {
    // ZST давталтын уртыг кодлох арга нь ZST болон ZST-д тохирохгүй.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Зарим хязгаарлалтын шалгалтаас салахын тулд (`position`-ийг үзнэ үү) бид уртыг зарим талаар гэнэтийн байдлаар тооцоолно.
// (`Codegen/slice-position-bounds-check`-ээр шалгагдсан.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // Бид заримдаа аюултай блок дотор ашиглагддаг

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Энэхүү _cannot_ нь `unchecked_sub`-ийг ашигладаг тул бид урт ZST зүсмэл давталтын уртыг илэрхийлэхээс боохоос хамаарна.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Бид `start <= end` гэдгийг мэддэг тул гарын үсэг зурж тохиролцох шаардлагатай `offset_from`-ээс илүү сайн зүйлийг хийж чадна.
            // Тохиромжтой тугуудыг энд байрлуулснаар LLVM-д хэлж болох бөгөөд энэ нь хязгаарлалтын шалгалтыг арилгахад тусалдаг.
            // АЮУЛГҮЙ БАЙДАЛ: Хувьсах бус хэлбэрээр, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // LLVM-д заагчийг яг ижил хэмжээтэйгээр зааглаж өгснөөр `len() == 0`-ийг `(end - start) < size` биш `start == end` болгож оновчтой болгож чадна.
            //
            // АЮУЛГҮЙ БАЙДАЛ: Төрөл хувьсах хэмжигдэхүүнээр заагчийг дараах байдлаар зэрэгцүүлсэн байна
            //         тэдгээрийн хоорондох зай нь олон тооны цэгийн хэмжээтэй байх ёстой
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` ба `IterMut` давталтын хуваалцсан тодорхойлолт
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Эхний элементийг буцааж, давталтын эхлэлийг 1-ээр урагшлуулна.
        // Шугаман функцтэй харьцуулахад гүйцэтгэлийг ихээхэн сайжруулдаг.
        // Давтагч хоосон биш байх ёстой.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Сүүлийн элементийг буцааж, давталтын төгсгөлийг 1-ээр хойшлуулна.
        // Шугаман функцтэй харьцуулахад гүйцэтгэлийг ихээхэн сайжруулдаг.
        // Давтагч хоосон биш байх ёстой.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // T нь ZST бол давталтын төгсгөлийг `n` арагш хойшлуулснаар давталтыг багасгадаг.
        // `n` `self.len()`-ээс хэтрэхгүй байх ёстой.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Давтлагаас зүсмэл үүсгэх туслах функц.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // АЮУЛГҮЙ БАЙДАЛ: давталтыг заагч бүхий зүсмэлээс бүтээсэн
                // `self.ptr` ба `len!(self)` урт.
                // Энэ нь `from_raw_parts`-ийн бүх урьдчилсан нөхцөл хангагдсан болохыг баталгаажуулдаг.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Хуучин эхлэлийг буцааж, давталтын эхлэлийг `offset` элементээр урагшлуулах туслах функц.
            //
            // Офсет нь `self.len()`-ээс хэтрэхгүй байх ёстой тул аюулгүй биш юм.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `offset` нь `self.len()`-ээс хэтрэхгүй гэдгийг баталгаажуулдаг.
                    // Тиймээс энэ шинэ заагч нь `self` дотор байгаа тул тэг байх баталгаатай болно.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Давталтын төгсгөлийг `offset` элементээр арагш хөдөлгөж, шинэ төгсгөлийг буцаахад туслах туслах функц.
            //
            // Офсет нь `self.len()`-ээс хэтрэхгүй байх ёстой тул аюулгүй биш юм.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `offset` нь `self.len()`-ээс хэтрэхгүй гэдгийг баталгаажуулдаг.
                    // нь `isize`-ээс хэтрэхгүй байх баталгаа юм.
                    // Мөн үүссэн заагч нь `slice`-ийн хязгаарт багтдаг бөгөөд энэ нь `offset`-ийн бусад шаардлагыг хангаж өгдөг.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // зүсмэлүүдээр хэрэгжүүлж болох боловч энэ нь хил хязгаарыг шалгахаас зайлсхийдэг

                // АЮУЛГҮЙ БАЙДАЛ: Зүсмэлийн эхлэх заагчтай тул `assume` дуудлага нь аюулгүй байдаг
                // тэг биш байх ёстой бөгөөд ZST-ээс бусад зүсмэлүүд нь тэг биш төгсгөлийн заагчтай байх ёстой.
                // Эхлээд давталт хоосон эсэхийг шалгаж байгаа тул `next_unchecked!` руу залгах нь аюулгүй юм.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Энэ давталт одоо хоосон байна.
                    if mem::size_of::<T>() == 0 {
                        // `ptr` хэзээ ч 0 байж болохгүй тул `end` нь (боодлын улмаас) байж болох тул бид үүнийг ингэж хийх ёстой.
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // АЮУЛГҮЙ БАЙДАЛ: p нь 0 биш, end>=ptr тул T нь ZST биш бол төгсгөл нь 0 байж болохгүй
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // АЮУЛГҮЙ БАЙДАЛ: Бид хязгаар дотор байна.`post_inc_start` нь ZST-үүдийн хувьд ч зөв зүйл хийдэг.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // `try_fold` ашигладаг анхдагч хэрэгжилтийг хүчингүй болгодог, учир нь энэхүү энгийн хэрэгжүүлэлт нь LLVM IR үүсгэдэггүй бөгөөд хөрвүүлэхэд хурдан байдаг.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // `try_fold` ашигладаг анхдагч хэрэгжилтийг хүчингүй болгодог, учир нь энэхүү энгийн хэрэгжүүлэлт нь LLVM IR үүсгэдэггүй бөгөөд хөрвүүлэхэд хурдан байдаг.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // `try_fold` ашигладаг анхдагч хэрэгжилтийг хүчингүй болгодог, учир нь энэхүү энгийн хэрэгжүүлэлт нь LLVM IR үүсгэдэггүй бөгөөд хөрвүүлэхэд хурдан байдаг.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // `try_fold` ашигладаг анхдагч хэрэгжилтийг хүчингүй болгодог, учир нь энэхүү энгийн хэрэгжүүлэлт нь LLVM IR үүсгэдэггүй бөгөөд хөрвүүлэхэд хурдан байдаг.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // `try_fold` ашигладаг анхдагч хэрэгжилтийг хүчингүй болгодог, учир нь энэхүү энгийн хэрэгжүүлэлт нь LLVM IR үүсгэдэггүй бөгөөд хөрвүүлэхэд хурдан байдаг.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // `try_fold` ашигладаг анхдагч хэрэгжилтийг хүчингүй болгодог, учир нь энэхүү энгийн хэрэгжүүлэлт нь LLVM IR үүсгэдэггүй бөгөөд хөрвүүлэхэд хурдан байдаг.
            // Түүнчлэн, `assume` нь хил хязгаарыг шалгахаас зайлсхийдэг.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // АЮУЛГҮЙ БАЙДАЛ: бид давтагдашгүй хязгаараар хязгаарлагдах болно:
                        // `i >= n`, `self.next()` нь `None`-ийг буцааж өгвөл давталт тасарна.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // `try_fold` ашигладаг анхдагч хэрэгжилтийг хүчингүй болгодог, учир нь энэхүү энгийн хэрэгжүүлэлт нь LLVM IR үүсгэдэггүй бөгөөд хөрвүүлэхэд хурдан байдаг.
            // Түүнчлэн, `assume` нь хил хязгаарыг шалгахаас зайлсхийдэг.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // АЮУЛГҮЙ БАЙДАЛ: `i` нь `n`-ээс эхэлсэн тул `n`-ээс бага байх ёстой
                        // зөвхөн буурч байна.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // АЮУЛГҮЙ БАЙДАЛ: дуудлага хийж байгаа хүн `i` хязгаарлалтад орсныг баталгаажуулах ёстой
                // суурь зүсмэл тул `i` нь `isize`-ийг халих боломжгүй бөгөөд буцаж ирсэн ишлэлүүд нь зүсмэлийн элементэд хамааралтай тул хүчин төгөлдөр байх болно.
                //
                // Дуудлага хийж байгаа хүн биднийг хэзээ ч ижил индексээр дахин залгахгүй байхыг баталгаажуулж байгаа бөгөөд энэ дэд хэсэгт хандах бусад аргыг дуудахгүй тул буцааж өгсөн лавлагаа нь өөрчлөгдөх боломжтой тул хүчин төгөлдөр болохыг анхаарна уу.
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // зүсмэлүүдээр хэрэгжүүлж болох боловч энэ нь хил хязгаарыг шалгахаас зайлсхийдэг

                // АЮУЛГҮЙ БАЙДАЛ: Зүсмэлийн эхлэх заагч нь тэг байх ёстой тул `assume` дуудлага хийх нь аюулгүй,
                // болон ZST-ээс бусад зүсмэлүүд нь хоосон биш заагчтай байх ёстой.
                // Эхлээд давталт хоосон эсэхийг шалгаж байгаа тул `next_back_unchecked!` руу залгах нь аюулгүй юм.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Энэ давталт одоо хоосон байна.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // АЮУЛГҮЙ БАЙДАЛ: Бид хязгаар дотор байна.`pre_dec_end` нь ZST-үүдийн хувьд ч зөв зүйл хийдэг.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}