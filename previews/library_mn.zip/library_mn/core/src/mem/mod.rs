//! Санах ойтой харьцах үндсэн функцууд.
//!
//! Энэ модуль нь төрлүүдийн хэмжээ, тохируулгыг асуух, санах ойг эхлүүлэх, удирдах функцийг агуулдаг.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Хохирогчийг **ажиллуулахгүйгээр** үнэ цэнийн талаар өмчлөл ба "forgets"-ийг авдаг.
///
/// Овоолсон санах ой эсвэл файлын бариул гэх мэт үнэ цэнэтэй удирддаг аливаа эх сурвалжууд хүрч чадахгүй байдалд үүрд хадгалагдах болно.Гэхдээ энэ санах ойд чиглүүлэгч хүчинтэй хэвээр байх баталгаа биш юм.
///
/// * Хэрэв та санах ой алдагдахыг хүсвэл [`Box::leak`]-ийг үзнэ үү.
/// * Хэрэв та санах ойд түүхий заагч авахыг хүсвэл [`Box::into_raw`]-г үзнэ үү.
/// * Хэрэв та устгагчийг ажиллуулж үнэ цэнийг зөв хаяхыг хүсвэл [`mem::drop`]-г үзнэ үү.
///
/// # Safety
///
/// `forget` нь `unsafe` гэж тэмдэглэгдээгүй, учир нь Rust-ийн аюулгүй байдлын баталгаа нь сүйтгэгчид үргэлж ажиллуулах баталгаа ороогүй болно.
/// Жишээлбэл, програм нь [`Rc`][rc] ашиглан лавлагаа цикл үүсгэх, эсвэл [`process::exit`][exit] руу залгаж деструктор ажиллуулахгүйгээр гарах боломжтой.
/// Тиймээс `mem::forget`-ийг аюулгүй кодоос зөвшөөрөх нь Rust-ийн аюулгүй байдлын баталгааг үндсээр нь өөрчлөхгүй.
///
/// Санах ой эсвэл I/O объект гэх мэт нөөцийг задруулах нь ихэвчлэн хүсээгүй зүйл гэж хэлсэн.
/// Энэхүү хэрэгцээ нь FFI эсвэл аюултай код ашиглах зарим төрөлжсөн тохиолдолд гардаг боловч [`ManuallyDrop`] нь ихэвчлэн ашиглагддаг.
///
/// Утга мартахыг зөвшөөрдөг тул таны бичсэн `unsafe` код энэ боломжийг зөвшөөрөх ёстой.Та утга буцааж өгөх боломжгүй бөгөөд дуудлага хийгч тухайн утгыг устгагч ажиллуулах болно гэж найдаж байна.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget`-ийн каноник аюулгүй хэрэглээ нь `Drop` trait-ийн хэрэгжүүлсэн үнэ цэнийг устгагчийг тойрч гарах явдал юм.Жишээлбэл, энэ нь `File` алдагдах болно, өөрөөр хэлбэл
/// хувьсагчийн авсан зайг буцааж авах боловч үндсэн системийн нөөцийг хэзээ ч хаадаггүй:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Энэ нь үндсэн нөөцийн өмчлөлийг өмнө нь Rust-ээс гадуур код руу шилжүүлсэн тохиолдолд ашигтай байдаг, жишээлбэл түүхий файлын тодорхойлогчийг C код руу дамжуулах замаар.
///
/// # `ManuallyDrop`-тай харьцах харилцаа
///
/// `mem::forget`-ийг *санах ой* эзэмших эрхийг шилжүүлэхэд ашиглаж болох боловч үүнийг хийх нь алдаа гаргах эрсдэлтэй байдаг.
/// [`ManuallyDrop`] оронд нь ашиглах хэрэгтэй.Жишээлбэл, энэ кодыг авч үзье.
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v`-ийн агуулгыг ашиглан `String` бүтээх
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // санах ойг одоо `s` удирдаж байгаа тул `v` алдагдсан
/// mem::forget(v);  // ERROR, v хүчингүй тул функцэд дамжуулж болохгүй
/// assert_eq!(s, "Az");
/// // `s` шууд бусаар унагаж, санах ойг нь хуваарилдаг.
/// ```
///
/// Дээрх жишээн дээр хоёр асуудал байна:
///
/// * Хэрэв `String` бүтээх ба `mem::forget()`-ийн хоорондох кодыг нэмж оруулсан бол panic нь ижил санах ойг `v` ба `s` хоёуланг нь зохицуулдаг тул хоёр дахин үнэгүй үүсгэдэг.
/// * `v.as_mut_ptr()` руу залгаж, өгөгдлийн өмчлөлийг `s` руу дамжуулсны дараа `v` утга хүчингүй болно.
/// Утга нь дөнгөж `mem::forget` руу шилжсэн ч (үүнийг шалгахгүй), зарим төрлүүд нь үнэт зүйлдээ хатуу шаардлага тавьдаг тул унжсан эсвэл өмчлөхөө больсон.
/// Хүчин төгөлдөр бус утгыг ямар нэгэн байдлаар ашиглах, үүнд тэдгээрийг шилжүүлэх эсвэл функцээс буцааж өгөх нь тодорхойгүй зан үйлийг бүрдүүлдэг бөгөөд хөрвүүлэгчийн гаргасан таамаглалыг зөрчиж болзошгүй юм.
///
/// `ManuallyDrop` руу шилжих нь дээрх хоёр асуудлаас зайлсхийх болно.
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Бид `v`-ийг түүхий эд болгон задлахаасаа өмнө унахгүй байхыг анхаарна уу!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Одоо `v`-ийг задлах хэрэгтэй.Эдгээр үйлдлүүд panic-ийг хийж чадахгүй тул нэвчилт байж болохгүй.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Эцэст нь `String` бүтээх.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` шууд бусаар унагаж, санах ойг нь хуваарилдаг.
/// ```
///
/// `ManuallyDrop` "v`'s destructor"-ийг өөр зүйл хийхээс өмнө идэвхгүй болгодог тул давхар чөлөөт байдлаас эрс хамгаалдаг.
/// `mem::forget()` үүнийг зөвхөн `v`-оос шаардлагатай бүх зүйлийг гаргаж авсны дараа л бидэн рүү залгахыг тулгаж, аргументаа ашигладаг тул үүнийг зөвшөөрдөггүй.
/// Хэдийгээр `ManuallyDrop`-ийг бүтээх ба мөрийг бүтээх хооронд panic-ийг нэвтрүүлсэн ч гэсэн (энэ нь зурагт заасны дагуу ийм зүйл тохиолдохгүй), энэ нь алдагдалд хүргэж, давхар чөлөөтэй биш болно.
/// Өөрөөр хэлбэл, `ManuallyDrop` нь (давхар) унах тал дээр алдаа гаргахын оронд гоожсон тал дээр алдаатай байдаг.
///
/// Түүнчлэн `ManuallyDrop` нь өмчлөлийг `s`-д шилжүүлсний дараа "touch" `v`-тэй болохоос сэргийлдэг-`v`-тэй харьцаж устгах ажлыг устгах эцсийн алхам нь бүрэн устгагдсан болно.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`]-тэй адил хэмжээгүй утгыг хүлээн зөвшөөрдөг.
///
/// Энэ функц нь `unsized_locals` функц тогтворжсон үед арилгах зориулалттай шил юм.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Төрлийн хэмжээг байтаар буцаана.
///
/// Бүр тодруулбал, энэ нь массив дахь дараалсан элементүүдийн хоорондох байт нөхөлт бөгөөд энэ нь тохируулгын дүүргэлт орно.
///
/// Тиймээс `T` ба урт `n`-ийн хувьд `[T; n]` нь `n * size_of::<T>()` хэмжээтэй байна.
///
/// Ерөнхийдөө нэг төрлийн хэмжээ нь эмхэтгэлд тогтвортой биш боловч команд гэх мэт тодорхой төрлүүд байдаг.
///
/// Дараахь хүснэгтэд команд командуудын хэмжээг өгсөн болно.
///
/// Төрөл |хэмжээтэй: :<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Цаашилбал, `usize` ба `isize` нь ижил хэмжээтэй байна.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>`, `Option<Box<T>>` төрлүүд бүгд ижил хэмжээтэй байна.
/// Хэрэв `T` хэмжээтэй бол эдгээр бүх төрлүүд `usize`-тай ижил хэмжээтэй байна.
///
/// Заагчийн хувирамтгай байдал нь түүний хэмжээг өөрчлөхгүй.Ийм байдлаар `&T` ба `&mut T` ижил хэмжээтэй байна.
/// Үүнтэй адил `*const T` ба `* mut T`.
///
/// # `#[repr(C)]` зүйлийн хэмжээ
///
/// Эд зүйлсийн `C` дүрслэл нь тодорхойлогдсон зохион байгуулалттай байна.
/// Энэхүү схемийн дагуу бүх талбайн хэмжээ тогтвортой байх тохиолдолд эд зүйлсийн хэмжээ тогтвортой байна.
///
/// ## Барилгын хэмжээ
///
/// `structs`-ийн хувьд хэмжээг дараахь алгоритмаар тодорхойлно.
///
/// Тунхаглалын дарааллаар захиалсан бүтцийн талбар бүрийн хувьд:
///
/// 1. Талбайн хэмжээг нэмнэ үү.
/// 2. Одоогийн хэмжээг дараагийн талбайн [alignment]-ийн үржвэрийн нарийвчлалтай ойртуулна.
///
/// Эцэст нь бүтцийн хэмжээг түүний [alignment]-ийн хамгийн ойрын үржвэрт хүргэнэ.
/// Бүтцийн тохируулга нь ихэвчлэн түүний бүх талбаруудын хамгийн том тохируулга юм;үүнийг `repr(align(N))` ашиглан өөрчилж болно.
///
/// `C`-ээс ялгаатай нь тэг хэмжээтэй бүтэц нь нэг байт хүртэл хэмжээтэй биш юм.
///
/// ## Enums хэмжээ
///
/// Ялгаварлан гадуурхахаас бусад өгөгдөл агуулаагүй enums нь хөрвүүлсэн платформ дээрх C enum-тэй ижил хэмжээтэй байна.
///
/// ## Холбооны хэмжээ
///
/// Эвслийн хэмжээ нь түүний хамгийн том талбайн хэмжээ юм.
///
/// `C`-ээс ялгаатай нь тэг хэмжээтэй үйлдвэрчний эвлэл нь нэг байт хүртэл хэмжээтэй биш юм.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Зарим командууд
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Зарим массивууд
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Заагчийн хэмжээ тэгш байдал
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` ашиглах.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Эхний талбайн хэмжээ 1 тул хэмжээг 1 дээр нэмнэ.Хэмжээ 1.
/// // Хоёрдахь талбайн тохируулга нь 2 тул дүүргэхийн тулд 1-ийг нэмнэ.Хэмжээ 2.
/// // Хоёрдахь талбайн хэмжээ нь 2 тул хэмжээг 2 дээр нэмнэ.Хэмжээ 4.
/// // Гурав дахь талбайн тохируулга нь 1 тул дүүргэх хэмжээ дээр 0-ийг нэмнэ.Хэмжээ 4.
/// // Гурав дахь талбайн хэмжээ 1 тул хэмжээ дээр 1-ийг нэмнэ.Хэмжээ 5.
/// // Эцэст нь бүтцийн тохируулга нь 2 байна (учир нь талбаруудын хамгийн том тохируулга нь 2 байна) тул дүүргэхийн тулд 1-ийг нэмнэ.
/// // Хэмжээ 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Барилгын хийц нь ижил дүрмийг баримталдаг.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Талбарыг эрэмбэлэх нь хэмжээг багасгаж болохыг анхаарна уу.
/// // Бид `second`-ээс өмнө `third` тавьснаар хоёр байтыг арилгаж болно.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Холбооны хэмжээ нь хамгийн том талбайн хэмжээ юм.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Байт дахь зааж өгсөн утгын хэмжээг буцаана.
///
/// Энэ нь ихэвчлэн `size_of::<T>()`-тэй ижил байдаг.
/// Гэсэн хэдий ч, `T`*нь* статик мэдэгдэж байгаа хэмжээгүй, жишээлбэл, [`[T]`][slice] зүсмэл эсвэл [trait object] байхгүй тохиолдолд `size_of_val`-ийг динамикаар мэддэг хэмжээг авахад ашиглаж болно.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // АЮУЛГҮЙ БАЙДАЛ: `val` бол лавлагаа тул хүчинтэй түүхий заагч юм
    unsafe { intrinsics::size_of_val(val) }
}

/// Байт дахь зааж өгсөн утгын хэмжээг буцаана.
///
/// Энэ нь ихэвчлэн `size_of::<T>()`-тэй ижил байдаг.Гэсэн хэдий ч, `T`*нь* статик мэдэгдэж байгаа хэмжээгүй, жишээлбэл, [`[T]`][slice] зүсмэл эсвэл [trait object] байхгүй тохиолдолд `size_of_val_raw`-ийг динамикаар мэддэг хэмжээг авахад ашиглаж болно.
///
/// # Safety
///
/// Дараахь нөхцлүүд байвал энэ функцийг дуудахад л аюулгүй байдаг.
///
/// - Хэрэв `T` нь `Sized` бол энэ функцийг дуудахад үргэлж аюулгүй байдаг.
/// - Хэрэв `T`-ийн хэмжээгүй сүүл нь:
///     - [slice], дараа нь зүсмэл сүүлний урт нь эхлүүлсэн бүхэл тоо байх ёстой бөгөөд *бүх утга*(динамик сүүлний урт + статик хэмжээтэй угтвар)-ийн хэмжээ `isize`-т багтах ёстой.
///     - [trait object] бол заагчийн vtable хэсэг нь хэмжээгүй албадлагаар олж авсан хүчин төгөлдөр vtable руу зааж өгөх бөгөөд *бүх утга*(динамик сүүлний урт + статик хэмжээтэй угтвар)-ын хэмжээ `isize`-т багтах ёстой.
///
///     - (unstable) [extern type] бол энэ функцийг дуудахад үргэлж аюулгүй байдаг, гэхдээ extern төрлийн зохион байгуулалт нь тодорхойгүй тул panic эсвэл өөр утгыг буруу утгатай болгож магадгүй юм.
///     Энэ нь [`size_of_val`]-тэй адил extern төрлийн сүүлтэй төрлийг дурдсантай ижил үйлдэл юм.
///     - өөр тохиолдолд энэ функцийг дуудахыг консерватив байдлаар зөвшөөрөхгүй.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // АЮУЛГҮЙ БАЙДАЛ: дуудагч хүчинтэй түүхий заагчийг өгөх ёстой
    unsafe { intrinsics::size_of_val(val) }
}

/// [ABI]-шаардагдах хамгийн бага зэрэгцүүлэлтийн төрлийг буцаана.
///
/// `T` төрлийн утгын лавлагаа бүр энэ тооны үржвэр байх ёстой.
///
/// Энэ бол бүтцийн талбарт ашигласан тохируулга юм.Энэ нь тохируулсан тохируулгаас бага байж болно.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val`-ийн зааж өгсөн утгын төрлийг шаардсан хамгийн бага зэрэгцүүлэлтийг буцаана.
///
/// `T` төрлийн утгын лавлагаа бүр энэ тооны үржвэр байх ёстой.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // АЮУЛГҮЙ БАЙДАЛ: val нь лавлагаа тул хүчинтэй түүхий заагч юм
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI]-шаардагдах хамгийн бага зэрэгцүүлэлтийн төрлийг буцаана.
///
/// `T` төрлийн утгын лавлагаа бүр энэ тооны үржвэр байх ёстой.
///
/// Энэ бол бүтцийн талбарт ашигласан тохируулга юм.Энэ нь тохируулсан тохируулгаас бага байж болно.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val`-ийн зааж өгсөн утгын төрлийг шаардсан хамгийн бага зэрэгцүүлэлтийг буцаана.
///
/// `T` төрлийн утгын лавлагаа бүр энэ тооны үржвэр байх ёстой.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // АЮУЛГҮЙ БАЙДАЛ: val нь лавлагаа тул хүчинтэй түүхий заагч юм
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val`-ийн зааж өгсөн утгын төрлийг шаардсан хамгийн бага зэрэгцүүлэлтийг буцаана.
///
/// `T` төрлийн утгын лавлагаа бүр энэ тооны үржвэр байх ёстой.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Дараахь нөхцлүүд байвал энэ функцийг дуудахад л аюулгүй байдаг.
///
/// - Хэрэв `T` нь `Sized` бол энэ функцийг дуудахад үргэлж аюулгүй байдаг.
/// - Хэрэв `T`-ийн хэмжээгүй сүүл нь:
///     - [slice], дараа нь зүсмэл сүүлний урт нь эхлүүлсэн бүхэл тоо байх ёстой бөгөөд *бүх утга*(динамик сүүлний урт + статик хэмжээтэй угтвар)-ийн хэмжээ `isize`-т багтах ёстой.
///     - [trait object] бол заагчийн vtable хэсэг нь хэмжээгүй албадлагаар олж авсан хүчин төгөлдөр vtable руу зааж өгөх бөгөөд *бүх утга*(динамик сүүлний урт + статик хэмжээтэй угтвар)-ын хэмжээ `isize`-т багтах ёстой.
///
///     - (unstable) [extern type] бол энэ функцийг дуудахад үргэлж аюулгүй байдаг, гэхдээ extern төрлийн зохион байгуулалт нь тодорхойгүй тул panic эсвэл өөр утгыг буруу утгатай болгож магадгүй юм.
///     Энэ нь [`align_of_val`]-тэй адил extern төрлийн сүүлтэй төрлийг дурдсантай ижил үйлдэл юм.
///     - өөр тохиолдолд энэ функцийг дуудахыг консерватив байдлаар зөвшөөрөхгүй.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // АЮУЛГҮЙ БАЙДАЛ: дуудагч хүчинтэй түүхий заагчийг өгөх ёстой
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Хэрэв `T` төрлийн утгыг хасах нь хамаатай бол `true` буцаана.
///
/// Энэ бол цэвэр оновчлолын зөвлөмж бөгөөд үүнийг консерватив байдлаар хэрэгжүүлж магадгүй юм.
/// Энэ нь үнэхээр хаях шаардлагагүй төрлийн хувьд `true`-ийг буцааж өгч магадгүй юм.
/// `true`-ийг үргэлж буцааж өгөх нь энэ функцийг зөв хэрэгжүүлэх болно.Гэсэн хэдий ч хэрэв энэ функц нь `false`-ийг буцааж өгдөг бол `T`-ийг унагавал ямар ч гаж нөлөө үзүүлэхгүй гэдэгт эргэлзэхгүй байна.
///
/// Өөрийн өгөгдлийг гараар унагаах шаардлагатай цуглуулга гэх мэт зүйлсийн доод түвшний хэрэгжилт нь эдгээр агуулгыг устгах үед бүх агуулгыг нь унагаахаас зайлсхийхийн тулд энэ функцийг ашиглах ёстой.
///
/// Энэ нь хувилбарын бүтцэд өөрчлөлт оруулахгүй байж магадгүй (гаж нөлөө байхгүй гогцоог амархан илрүүлж арилгадаг), гэхдээ ихэвчлэн дибаг хийх бүтцэд том ялалт болдог.
///
/// [`drop_in_place`] нь энэ шалгалтыг аль хэдийн хийсэн тул таны ажлын ачааллыг зарим цөөн тооны [`drop_in_place`] дуудлагад хүргэх боломжтой бол үүнийг ашиглах шаардлагагүй болохыг анхаарна уу.
/// Ялангуяа та зүсмэлийг [`drop_in_place`] болгож болох бөгөөд ингэснээр бүх утгыг ганц need_drop шалгах болно.
///
/// Vec гэх мэт төрлүүд нь `needs_drop`-ийг шууд ашиглахгүйгээр зөвхөн `drop_in_place(&mut self[..])` юм.
/// Нөгөө талаар [`HashMap`] гэх мэт төрлүүд нь утгыг нэг нэгээр нь хасах ёстой бөгөөд энэ API-г ашиглах ёстой.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Цуглуулга `needs_drop`-ийг хэрхэн ашиглаж болохыг харуулсан жишээ энд байна.
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // өгөгдлийг хаях
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Бүх тэгийн байтын хэв маягаар илэрхийлсэн `T` төрлийн утгыг буцаана.
///
/// Энэ нь, жишээлбэл, `(u8, u16)` дахь байт байт заавал тэглэх албагүй гэсэн үг юм.
///
/// Бүх тэг тэг байтын загвар нь зарим төрлийн `T`-ийн хүчин төгөлдөр утгыг илэрхийлдэг гэсэн баталгаа байхгүй.
/// Жишээлбэл, бүхэл тэг байтын загвар нь лавлагааны төрлүүд ("&T`, `&mut T`) ба функцын заагчдад тохирох утга биш юм.
/// Ийм төрлийн `zeroed`-ийг ашиглах нь нэн даруй [undefined behavior][ub]-ийг үүсгэдэг, учир нь [the Rust compiler assumes][inv] нь эхлүүлсэн гэж тооцдог хувьсагчийн хүчин төгөлдөр утга үргэлж байдаг.
///
///
/// Энэ нь [`MaybeUninit::zeroed().assume_init()`][zeroed]-тэй ижил нөлөөтэй байдаг.
/// Энэ нь FFI-д заримдаа хэрэгтэй байдаг боловч ерөнхийдөө үүнээс зайлсхийх хэрэгтэй.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Энэ функцийг зөв ашиглах: бүхэл тоог тэгээр эхлүүлэх.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Буруу* энэ функцын ашиглалт: лавлагааг тэгээр эхлүүлэх.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Тодорхойгүй зан байдал!
/// let _y: fn() = unsafe { mem::zeroed() }; // Дахин хэлэхэд!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // АЮУЛГҮЙ БАЙДАЛ: дуудлага хийж байгаа хүн `T`-ийн хувьд бүхэл тэг утга хүчинтэй болохыг баталгаажуулах ёстой.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Rust-ийн ердийн санах ойг эхлүүлэх шалгалтыг тойрч гарахдаа `T` төрлийн утгыг гаргаж байгаа дүр үзүүлэн огт юу ч хийхгүй.
///
/// **Энэ функц хуучирсан.** Үүний оронд [`MaybeUninit<T>`] ашиглана уу.
///
/// Хуучирсан шалтгаан нь функцийг үндсэндээ зөв ашиглаж чадахгүй байгаа явдал юм: энэ нь [`MaybeUninit::uninit().assume_init()`][uninit]-тэй ижил нөлөөтэй байдаг.
///
/// [`assume_init` documentation][assume_init]-ийн тайлбарласнаар утгуудыг зөв эхлүүлсэн [the Rust compiler assumes][inv].
/// Үүний үр дүнд, жишээ нь
/// `mem::uninitialized::<bool>()` нь `bool` эсвэл `false`-ийн аль нь ч биш `bool`-ийг буцааж өгөхөд нэн даруй тодорхойлогдохгүй зан үйлийг үүсгэдэг.
/// Хамгийн муу нь, энд буцаж ирдэг зүйл шиг жинхэнэ эхлээгүй санах ой нь хөрвүүлэгч нь тогтмол утгагүй гэдгийг мэддэгээрээ онцгой юм.
/// Энэ нь хувьсагч нь бүхэл тоон төрөлтэй байсан ч гэсэн эхлүүлээгүй өгөгдлийг хувьсагч дотор байх нь тодорхойгүй зан төлөвийг бий болгодог.
/// (Эхлээгүй бүхэл тоонуудын дүрмийг хараахан эцэслээгүй байгааг анхаарна уу, гэхдээ тэдгээр нь дуусах хүртэл эдгээрээс зайлсхийхийг зөвлөж байна.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `T`-ийн хувьд нэгжлэгдсэн утга хүчинтэй болохыг баталгаажуулах ёстой.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Хоёрыг өөрчлөх боломжтой байрлал дахь утгыг сольж, аль нэгийг нь анхны утгагүйгээр солино.
///
/// * Хэрэв та анхдагч эсвэл хуурамч утгаар солихыг хүсвэл [`take`]-г үзнэ үү.
/// * Хэрэв та хуучин утгыг буцааж дамжуулсан утгыг солихыг хүсвэл [`replace`]-г үзнэ үү.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // АЮУЛГҮЙ БАЙДАЛ: түүхий заагчдыг аюулгүй, өөрчлөгдөж болохуйц лавлагаагаар хийсэн болно
    // `ptr::swap_nonoverlapping_one` дээрх хязгаарлалтууд
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest`-ийг `T`-ийн анхдагч утгаар сольж өмнөх `dest` утгыг буцаана.
///
/// * Хэрэв та хоёр хувьсагчийн утгыг орлуулахыг хүсвэл [`swap`]-г үзнэ үү.
/// * Хэрэв та анхдагч утгын оронд дамжуулсан утгыг орлуулахыг хүсвэл [`replace`]-г үзнэ үү.
///
/// # Examples
///
/// Энгийн жишээ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` нь бүтцийн талбарыг "empty" утгаар сольж өмчлөх боломжийг олгодог.
/// `take` гүйгээр та дараахь асуудлуудтай тулгарч болно:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// `T` нь [`Clone`]-ийг заавал хэрэгжүүлэх албагүй тул `self.buf`-ийг хувилж, дахин тохируулах боломжгүй гэдгийг анхаарна уу.
/// Гэхдээ `take` нь `self.buf`-ийн анхны утгыг `self`-ээс салгаж, буцааж өгөх боломжийг олгодог.
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src`-ийг иш татсан `dest` руу шилжүүлж, өмнөх `dest` утгыг буцаана.
///
/// Аль ч үнэ цэнэ буурахгүй.
///
/// * Хэрэв та хоёр хувьсагчийн утгыг орлуулахыг хүсвэл [`swap`]-г үзнэ үү.
/// * Хэрэв та анхдагч утгыг орлуулахыг хүсвэл [`take`]-г үзнэ үү.
///
/// # Examples
///
/// Энгийн жишээ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` өөр талбараар сольж бүтцийн талбайн хэрэглээг зөвшөөрдөг.
/// `replace` гүйгээр та дараахь асуудлуудтай тулгарч болно:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// `T` нь [`Clone`]-ийг заавал хэрэгжүүлэх албагүй тул шилжихээс зайлсхийхийн тулд `self.buf[i]`-ийг клончлох боломжгүй гэдгийг анхаарна уу.
/// Гэхдээ `replace`-ийг тухайн индекс дэх анхны утгыг `self`-ээс салгаж, буцааж өгөхөд ашиглаж болно.
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // АЮУЛГҮЙ БАЙДАЛ: Бид `dest`-ээс уншдаг, гэхдээ дараа нь шууд `src` гэж бичдэг,
    // хуучин утгыг хуулбарлахгүй байхаар.
    // Юу ч унагаагүй, энд юу ч panic чадахгүй.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Үнэ цэнийг устгана.
///
/// Үүнийг [`Drop`][drop] аргументын хэрэгжилтийг дуудах замаар хийдэг.
///
/// Энэ нь `Copy`-ийг хэрэгжүүлдэг төрлүүдийн хувьд үр дүнтэй зүйл биш юм
/// integers.
/// Ийм утгуудыг хуулж, _then_ функц руу шилжүүлсэн тул энэ функцын дуудлага хийсний дараа утга хэвээр үлдэнэ.
///
///
/// Энэ функц нь ид шид биш юм.үүнийг шууд утгаар нь тодорхойлсон болно
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` функцэд шилжсэн тул функц буцаж ирэхээс өмнө автоматаар унадаг.
///
/// [drop]: Drop
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // vector-ийг шууд хаях
/// ```
///
/// [`RefCell`] нь зээлийн дүрмийг ажиллуулах хугацаандаа хэрэгжүүлдэг тул `drop` нь [`RefCell`] зээлийг гаргаж болно:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // энэ завсар дээрх өөрчлөгдөж болох зээлээс татгалзах
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Бүхэл тоо болон [`Copy`]-ийг хэрэгжүүлж буй бусад төрлүүд нь `drop`-т нөлөөлдөггүй.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x`-ийн хуулбарыг зөөж хаясан
/// drop(y); // `y`-ийн хуулбарыг зөөж хаясан
///
/// println!("x: {}, y: {}", x, y.0); // Одоо ч боломжтой
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src`-ийг `&U` төрөлтэй гэж тайлбарлаж, дараа нь агуулагдсан утгыг хөдөлгөхгүйгээр `src`-г уншина.
///
/// Энэ функц нь `src` заагчийг [`size_of::<U>`][size_of] байтад `&T`-ийг `&U` болгон дамжуулж, дараа нь `&U`-ийг унших замаар хүчин төгөлдөр гэж үзэх болно (энэ нь `&U` нь `&T`-ээс илүү хатуу тохируулгын шаардлага тавьдаг байсан ч гэсэн зөв байдлаар хийгддэг).
/// Энэ нь `src`-ээс гарахын оронд агуулагдах утгын хуулбарыг аюулгүй байдлаар үүсгэх болно.
///
/// Хэрэв `T` ба `U` нь өөр өөр хэмжээтэй байвал энэ нь хөрвүүлэх үеийн алдаа биш боловч зөвхөн `T` ба `U` ижил хэмжээтэй тохиолдолд энэ функцийг ажиллуулахыг зөвлөж байна.Энэ функц нь `U` нь `T`-ээс их бол [undefined behavior][ub]-ийг ажиллуулдаг.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array'-ээс өгөгдлийг хуулж, 'Foo' гэж үзээрэй
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Хуулж авсан өгөгдлийг өөрчлөх
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array'-ийн агуулга өөрчлөгдөөгүй байх ёстой
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Хэрэв U нь тохируулгын шаардлага өндөр байвал src нь тохирохгүй байх магадлалтай.
    if align_of::<U>() > align_of::<T>() {
        // АЮУЛГҮЙ БАЙДАЛ: `src` нь уншихад хүчинтэй байх баталгаатай лавлагаа юм.
        // Дуудлага хийж буй хүн бодит дамжуулалт аюулгүй гэдгийг баталгаажуулах ёстой.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // АЮУЛГҮЙ БАЙДАЛ: `src` нь уншихад хүчинтэй байх баталгаатай лавлагаа юм.
        // Бид `src as *const U`-ийг зөв тааруулсан эсэхийг шалгасан.
        // Дуудлага хийж буй хүн бодит дамжуулалт аюулгүй гэдгийг баталгаажуулах ёстой.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Enum-ийн ялгаварлагч шинж чанарыг илтгэдэг тунгалаг бус төрөл.
///
/// Дэлгэрэнгүй мэдээллийг энэ модуль дахь [`discriminant`] функцийг үзнэ үү.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Эдгээр trait-ийн хэрэгжилтийг олж авах боломжгүй, учир нь бид T-т хязгаар тавихыг хүсэхгүй байна.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` дахь enum хувилбарыг өвөрмөц байдлаар тодорхойлсон утгыг буцаана.
///
/// Хэрэв `T` нь enum биш бол энэ функцийг дуудах нь тодорхойгүй байдалд хүргэхгүй, гэхдээ буцах утга нь тодорхойгүй байна.
///
///
/// # Stability
///
/// Enum-ийн тодорхойлолт өөрчлөгдсөн тохиолдолд enum хувилбарын ялгаварлагч өөрчлөгдөж болно.
/// Зарим хувилбарын ялгаварлагч нь ижил хөрвүүлэгчтэй эмхэтгэлийн хооронд өөрчлөгдөхгүй.
///
/// # Examples
///
/// Үүнийг бодит өгөгдлийг үл тоомсорлож, өгөгдөл дамжуулдаг enums-ийг харьцуулахад ашиглаж болно.
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// `T` enum төрлийн хувилбаруудын тоог буцаана.
///
/// Хэрэв `T` нь enum биш бол энэ функцийг дуудах нь тодорхойгүй байдалд хүргэхгүй, гэхдээ буцах утга нь тодорхойгүй байна.
/// Үүнтэй адил, хэрэв `T` бол `usize::MAX`-ээс их хувилбартай enum бол буцаах утга нь тодорхойгүй байна.
/// Хүн амьдардаггүй хувилбаруудыг тоолно.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}