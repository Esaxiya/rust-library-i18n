use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Автоматаар T`-ийн устгалыг дуудахаас хөрвүүлэгчийг хориглох боодол.
/// Энэхүү боодол нь 0 үнэтэй.
///
/// `ManuallyDrop<T>` нь `T`-тэй адил байршлын оновчлолд хамрагдана.
/// Үүний үр дүнд энэ нь хөрвүүлэгчийн агуулгын талаархи таамаглалд * ямар ч нөлөө үзүүлэхгүй.
/// Жишээлбэл, `ManuallyDrop<&mut T>`-ийг [`mem::zeroed`]-ээр эхлүүлэх нь тодорхойгүй зан байдал юм.
/// Хэрэв танд эхлээгүй өгөгдөлтэй харьцах шаардлагатай бол оронд нь [`MaybeUninit<T>`] ашиглана уу.
///
/// `ManuallyDrop<T>` доторх утгад нэвтрэх нь аюулгүй гэдгийг анхаарна уу.
/// Энэ нь агуулга нь унасан `ManuallyDrop<T>`-ийг олон нийтийн аюулгүй API-ээр дамжуулж болохгүй гэсэн үг юм.
/// Үүний дагуу `ManuallyDrop::drop` нь аюулгүй биш юм.
///
/// # `ManuallyDrop` захиалга унах.
///
/// Rust нь [drop order] утгыг сайн тодорхойлсон байдаг.
/// Талбарууд эсвэл орон нутгийн оршин суугчид тодорхой дарааллаар хасагдсан байгаа эсэхийг баталгаажуулахын тулд далд хэлбэрээр буулгах захиалга зөв байх тул мэдүүлгийг дахин эрэмбэл.
///
/// Буулгах захиалгыг хянахын тулд `ManuallyDrop`-ийг ашиглах боломжтой боловч энэ нь аюулгүй код шаарддаг тул задлах тохиолдолд зөв хийхэд хэцүү байдаг.
///
///
/// Жишээлбэл, хэрэв та тодорхой талбарыг бусдаас хойш хаяж байгаа эсэхийг шалгахыг хүсвэл бүтцийн сүүлчийн талбар болгоно уу:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children`-ээс хойш хаях болно.
///     // Rust нь мэдүүлгийн дарааллаар талбаруудыг хасах баталгаа өгдөг.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Гараар унах утгыг боож боох.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Та үнэ цэнэ дээр аюулгүй ажиллах боломжтой хэвээр байна
    /// assert_eq!(*x, "Hello");
    /// // Гэхдээ `Drop`-ийг энд ажиллуулахгүй
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` савнаас утгыг гаргаж авдаг.
    ///
    /// Энэ нь утгыг дахин унагаах боломжийг олгодог.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Энэ нь `Box`-ийг унагах болно.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` савны утгыг гаргаж авна.
    ///
    /// Энэ арга нь голчлон уналтын утгыг шилжүүлэхэд зориулагдсан болно.
    /// [`ManuallyDrop::drop`]-ийг ашиглан гар аргаар утгыг унагахын оронд та энэ аргыг ашиглан утгыг авч хүссэн хэмжээгээр нь ашиглаж болно.
    ///
    /// Боломжтой бол оронд нь [`into_inner`][`ManuallyDrop::into_inner`]-ийг ашиглах нь зүйтэй бөгөөд энэ нь `ManuallyDrop<T>`-ийн агуулгыг давхардуулахаас сэргийлдэг.
    ///
    ///
    /// # Safety
    ///
    /// Энэ функц нь агуулгын утгыг цаашид ашиглахаас урьдчилан сэргийлэхгүйгээр утгыг нь шилжүүлж, энэ савны төлөвийг хэвээр үлдээнэ.
    /// Энэхүү `ManuallyDrop`-ийг дахин ашиглахгүй байх нь таны үүрэг юм.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // АЮУЛГҮЙ БАЙДАЛ: бид баталгаатай лавлагаанаас уншиж байна
        // уншихад хүчинтэй байх.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Агуулагдсан утгыг гараар унагах.Энэ нь агуулагдах утгын заагчтай [`ptr::drop_in_place`] руу залгахтай яг ижил юм.
    /// Ийм байдлаар агуулагдсан утга нь багцлагдсан бүтэц биш бол устгагчийг утгыг хөдөлгөхгүйгээр байранд нь дуудах бөгөөд ингэснээр [pinned] өгөгдлийг аюулгүй унагаахад ашиглаж болно.
    ///
    /// Хэрэв та үнэ цэнийг эзэмшиж байгаа бол оронд нь [`ManuallyDrop::into_inner`] ашиглаж болно.
    ///
    /// # Safety
    ///
    /// Энэ функц нь агуулагдах утгын устгалыг ажиллуулдаг.
    /// Устгагч өөрөө хийсэн өөрчлөлтөөс бусад тохиолдолд санах ой өөрчлөгдөөгүй бөгөөд хөрвүүлэгчийн хувьд `T` төрлийн хувьд хүчин төгөлдөр болох битийн хэв маягийг хадгалсаар байдаг.
    ///
    ///
    /// Гэхдээ энэ "zombie" утга аюулгүй кодонд өртөх ёсгүй бөгөөд энэ функцийг нэгээс илүү удаа дуудаж болохгүй.
    /// Унасны дараа утгыг ашиглах эсвэл олон удаа унагаах нь Тодорхой бус зан үйлийг үүсгэж болзошгүй (`drop`-ээс хамаарч).
    /// Энэ нь ихэвчлэн системийн системээс урьдчилан сэргийлдэг боловч `ManuallyDrop`-ийн хэрэглэгчид хөрвүүлэгчийн туслалцаагүйгээр эдгээр баталгааг дагаж мөрдөх ёстой.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // АЮУЛГҮЙ БАЙДАЛ: бид өөрчлөгдөх боломжтой лавлагаагаар заасан утгыг унагаж байна
        // бичихэд хүчинтэй байх баталгаатай.
        // `slot`-ийг дахин унагахгүй байх нь дуудлага хийх хүнээс хамаарна.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}