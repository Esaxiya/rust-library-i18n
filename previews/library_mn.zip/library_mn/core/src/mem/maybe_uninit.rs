use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T`-ийн эхлээгүй тохиолдлыг бүтээх зориулалттай боодлын төрөл.
///
/// # Эхлэл өөрчлөгдөхгүй
///
/// Хөрвүүлэгч нь ерөнхийдөө хувьсагчийг тухайн төрлийн шаардлагын дагуу зохих ёсоор эхлүүлсэн гэж үздэг.Жишээлбэл, лавлагааны төрлийн хувьсагч нь NULL-тэй нийцсэн байх ёстой.
/// Энэ нь аюулгүй кодонд ч гэсэн *үргэлж* байх ёстой инвариант юм.
/// Үүний үр дүнд, лавлагаа хэлбэрийн хувьсагчийг тэгээс эхлүүлэх нь агшин зуурын [undefined behavior][ub]-ийг үүсгэдэг бөгөөд тухайн лавлагаа санах ойд нэвтрэхэд ашиглаж байсан эсэхээс үл хамаарна.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // тодорхойгүй зан байдал!⚠️
/// // `MaybeUninit<&i32>`-тэй тэнцэх код:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // тодорхойгүй зан байдал!⚠️
/// ```
///
/// Үүнийг хөрвүүлэгч ажиллуулах хугацааг шалгах, `enum` байршлыг оновчтой болгох гэх мэт янз бүрийн оновчлолд ашигладаг.
///
/// Үүний нэгэн адил, бүхэлдээ эхлээгүй санах ой нь ямар ч агуулгатай байж болох бөгөөд `bool` нь үргэлж `true` эсвэл `false` байх ёстой.Тиймээс эхлээгүй `bool` үүсгэх нь тодорхойгүй зан байдал юм.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // тодорхойгүй зан байдал!⚠️
/// // `MaybeUninit<bool>`-тэй тэнцэх код:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // тодорхойгүй зан байдал!⚠️
/// ```
///
/// Түүнчлэн, эхлүүлээгүй санах ой нь тогтмол утгагүй ("fixed" гэсэн утгатай "it won't change without being written to") гэдгээрээ онцлог юм.Ижил эхлэлгүй байтыг олон удаа унших нь өөр өөр үр дүнд хүргэх болно.
/// Энэ нь хувьсагч нь бүхэл тоон төрөлтэй байсан ч гэсэн эхлэлгүй өгөгдлийг хувьсагч дотор байлгах нь тодорхойгүй зан авирыг бий болгодог.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // тодорхойгүй зан байдал!⚠️
/// // `MaybeUninit<i32>`-тэй тэнцэх код:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // тодорхойгүй зан байдал!⚠️
/// ```
/// (Эхлээгүй бүхэл тоонуудын дүрмийг хараахан эцэслээгүй байгааг анхаарна уу, гэхдээ тэдгээр нь дуусах хүртэл эдгээрээс зайлсхийхийг зөвлөж байна.)
///
/// Дээрээс нь ихэнх төрлүүд нь зөвхөн анхны түвшинд тохируулагдсан гэж тооцогдохоос гадна нэмэлт инвариантуудтай байдаг гэдгийг санаарай.
/// Жишээлбэл, `1`-эхлүүлсэн [`Vec<T>`]-ийг эхлүүлсэн гэж үзнэ (одоогийн хэрэгжүүлэлтийн дагуу; энэ нь тогтвортой баталгааг бүрдүүлэхгүй) тул хөрвүүлэгчийн мэддэг цорын ганц шаардлага бол өгөгдлийн заагч нь тэг байх ёстой.
/// Ийм `Vec<T>` үүсгэх нь *шууд* тодорхойлогдоогүй зан авирыг үүсгэдэггүй, гэхдээ ихэнх аюулгүй ажиллагаа (оруулаад оруулаад) тодорхойлогдоогүй зан үйлийг үүсгэдэг.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` нь эхлүүлээгүй өгөгдөлтэй ажиллахад тохиромжгүй кодыг идэвхжүүлдэг.
/// Энэ нь хөрвүүлэгчийн өгөгдлийг эхлүүлэхгүй байж болохыг харуулсан дохио юм:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Тодорхой эхлээгүй лавлагаа үүсгэх.
/// // Хөрвүүлэгч нь `MaybeUninit<T>` доторх өгөгдөл хүчингүй байж болохыг мэддэг тул энэ нь UB биш юм.
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Үүнийг зөв утгад тохируулна уу.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Анхны өгөгдлийг задлах-энэ нь `x`-ийг зөв эхлүүлсний дараа л зөвшөөрөгдөх болно!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Дараа нь хөрвүүлэгч энэ код дээр буруу таамаглал, оновчлол хийхгүй байхыг мэддэг.
///
/// Та `MaybeUninit<T>`-ийг `Option<T>`-тэй жаахан адилхан гэж бодож болно, гэхдээ ямар ч ажиллуулах цаг хугацаа, аюулгүй байдлын хяналтгүйгээр.
///
/// ## out-pointers
///
/// Та "out-pointers"-ийг хэрэгжүүлэхийн тулд `MaybeUninit<T>`-ийг ашиглаж болно: функцээс өгөгдөл буцаахын оронд үр дүнг оруулахын тулд (uninitialized) санах ойд заагчийг дамжуулна уу.
/// Энэ нь дуудлага хийж буй хүн үр дүнгийн санах ойг хэрхэн яаж хуваарилж байгааг хянах нь чухал бөгөөд хэрэгцээгүй алхам хийхээс зайлсхийхийг хүсч байвал ашигтай байж болох юм.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` хуучин агуулгыг хаяхгүй бөгөөд энэ нь чухал юм.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Одоо бид `v`-ийг эхлүүлсэн болохыг мэдэж байна!Энэ нь vector-ийг зөв унах эсэхийг баталгаажуулдаг.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Массивын элемент бүрийг эхлүүлж байна
///
/// `MaybeUninit<T>` массивын элемент тус бүрийг эхлүүлэхэд ашиглаж болно:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit`-ийн эхлүүлээгүй массив үүсгэх.
///     // `assume_init` нь аюулгүй байдаг, учир нь бидний эхлүүлсэн гэж мэдэгдэж байгаа төрөл нь эхлүүлэх шаардлагагүй, магадгүй "Магадгүй" гэсэн багц юм.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit`-ийг унагах нь юу ч хийхгүй.
///     // Тиймээс `ptr::write`-ийн оронд түүхий заагчийн хуваарилалтыг ашиглах нь хуучин эхлүүлээгүй утгыг унагахад хүргэдэггүй.
/////
///     // Хэрэв энэ давталтын үед panic байвал санах ойн алдагдал гарсан ч санах ойн аюулгүй байдалд асуудалгүй болно.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Бүх зүйлийг эхлүүлсэн.
///     // Массивыг анхны хэлбэрт шилжүүлэх.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Та мөн бага түвшний өгөгдлийн бүтцээс олж болох хэсэгчилсэн эхлүүлсэн массивтай ажиллах боломжтой.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit`-ийн эхлүүлээгүй массив үүсгэх.
/// // `assume_init` нь аюулгүй байдаг, учир нь бидний эхлүүлсэн гэж мэдэгдэж байгаа төрөл нь эхлүүлэх шаардлагагүй, магадгүй "Магадгүй" гэсэн багц юм.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Бидний хуваарилсан элементүүдийн тоог тоол.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Массив дахь зүйл бүрийн хувьд хэрэв бид хуваарилсан бол хаяна уу.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Талбараар бүтцийг эхлүүлэх
///
/// Та бүтцийг талбараар эхлүүлэхийн тулд `MaybeUninit<T>` болон [`std::ptr::addr_of_mut`] макро ашиглаж болно:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` талбарыг эхлүүлж байна
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` талбарыг эхлүүлэх Хэрэв энд panic байгаа бол `name` талбайн `String` алдагдсан байна.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Бүх талбарууд нь анхны үсгээр бичигдсэн тул бид `assume_init` руу залгаж анхны Foo-г авах болно.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` нь `T`-тэй ижил хэмжээ, тохируулга, ABI байх баталгаатай болно:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Гэхдээ `MaybeUninit<T>` агуулсан * төрөл нь заавал ижил байршил биш гэдгийг санаарай.Rust нь `T` ба `U` нь ижил хэмжээтэй, зэрэгцүүлэлттэй байсан ч гэсэн `Foo<T>`-ийн талбарууд `Foo<U>`-тэй ижил дараалалтай байхыг ерөнхийдөө баталгаажуулдаггүй.
///
/// Цаашилбал `MaybeUninit<T>`-ийн хувьд битийн утга хүчин төгөлдөр тул хөрвүүлэгч non-zero/niche-filling-ийн оновчлолыг ашиглаж чадахгүй тул илүү том хэмжээтэй болох магадлалтай:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Хэрэв `T` нь FFI-д аюулгүй бол `MaybeUninit<T>` нь мөн адил юм.
///
/// `MaybeUninit` бол `#[repr(transparent)]` (`T`-тэй ижил хэмжээ, уялдаа холбоо, ABI-ийг баталгаажуулж байгааг харуулж байна), энэ нь өмнөх анхааруулгуудын аль нэгийг *өөрчлөхгүй*.
/// `Option<T>` ба `Option<MaybeUninit<T>>` нь өөр өөр хэмжээтэй байж магадгүй бөгөөд `T` төрлийн талбарыг агуулсан төрлүүд нь `MaybeUninit<T>` хэмжээнээс ялгаатай байж болно.
/// `MaybeUninit` нь нэгдлийн төрөл бөгөөд үйлдвэрчний эвлэлийн хувьд `#[repr(transparent)]` нь тогтворгүй байдаг ([the tracking issue](https://github.com/rust-lang/rust/issues/60405))-г үзнэ үү).
/// Цаг хугацаа өнгөрөх тусам үйлдвэрчний эвлэлийн `#[repr(transparent)]`-ийн баталгаа нь өөрчлөгдөж, `MaybeUninit` нь `#[repr(transparent)]` хэвээр үлдэх эсвэл үлдэхгүй байж болно.
/// Энэ нь `MaybeUninit<T>` нь `T`-тэй ижил хэмжээтэй, зэрэгцүүлэлт, ABI-тэй байхыг *үргэлж* баталгаажуулах болно;`MaybeUninit`-ийн баталгааг хэрэгжүүлэх арга зам өөрчлөгдөж магадгүй юм.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Бусад төрлийг дотор нь боож болохын тулд зүйлээ түрээслээрэй.Энэ нь генераторуудад ашигтай байдаг.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` руу залгахгүй байхын тулд бид үүнийг хангалттай хэмжээгээр эхлүүлсэн эсэхээ мэдэхгүй байна.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Өгөгдсөн утгаар эхлүүлсэн шинэ `MaybeUninit<T>` үүсгэдэг.
    /// Энэ функцын буцах утга дээр [`assume_init`] руу залгах нь аюулгүй юм.
    ///
    /// `MaybeUninit<T>`-ийг унагавал "T"-ийн уналтын кодыг хэзээ ч дуудахгүй гэдгийг анхаарна уу.
    /// `T`-ийг эхлүүлсэн тохиолдолд унах эсэхийг шалгах нь таны үүрэг юм.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Эхлээгүй төлөвт шинэ `MaybeUninit<T>` үүсгэдэг.
    ///
    /// `MaybeUninit<T>`-ийг унагавал "T"-ийн уналтын кодыг хэзээ ч дуудахгүй гэдгийг анхаарна уу.
    /// `T`-ийг эхлүүлсэн тохиолдолд унах эсэхийг шалгах нь таны үүрэг юм.
    ///
    /// Зарим жишээг [type-level documentation][MaybeUninit]-ээс үзнэ үү.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// `MaybeUninit<T>` зүйлсийн шинэ массивыг эхлүүлээгүй төлөвт оруулна уу.
    ///
    /// Note: future Rust хувилбарт массивын шууд синтакс нь [repeating const expressions](https://github.com/rust-lang/rust/issues/49147)-ийг зөвшөөрөх үед энэ арга нь шаардлагагүй болж магадгүй юм.
    ///
    /// Доорх жишээг `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` ашиглаж болно.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Бодит уншсан (магадгүй бага) зүсмэл өгөгдлийг буцаана
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // АЮУЛГҮЙ БАЙДАЛ: Эхлээгүй `[MaybeUninit<_>; LEN]` хүчинтэй.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Санах ойг `0` байтаар дүүргэж, эхлүүлээгүй төлөвт шинэ `MaybeUninit<T>` үүсгэдэг.Энэ нь зөв эхлүүлэх шаардлагатай байгаа эсэх нь `T`-ээс хамаарна.
    ///
    /// Жишээлбэл, `MaybeUninit<usize>::zeroed()`-ийг эхлүүлсэн боловч `MaybeUninit<&'static i32>::zeroed()` нь лавлагаа нь хоосон байж болохгүй.
    ///
    /// `MaybeUninit<T>`-ийг унагавал "T"-ийн уналтын кодыг хэзээ ч дуудахгүй гэдгийг анхаарна уу.
    /// `T`-ийг эхлүүлсэн тохиолдолд унах эсэхийг шалгах нь таны үүрэг юм.
    ///
    /// # Example
    ///
    /// Энэ функцийг зөв ашиглах: бүтцийн бүх талбарууд битийн хэв маягийг 0 хүчин төгөлдөр утга болгон барьж чаддаг тэгээр бүтцийг эхлүүлэх.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Буруу* энэ функцын ашиглалт: `0` нь тухайн төрлийн хувьд хүчин төгөлдөр бит загвар биш тохиолдолд `x.zeroed().assume_init()` руу залгах:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Хос дотор бид хүчин төгөлдөр ялгаварлалгүй `NotZero` үүсгэдэг.
    /// // Энэ бол тодорхойгүй зан байдал юм.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // Аюулгүй байдал: `u.as_mut_ptr()` нь хуваарилагдсан санах ойг заана.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>`-ийн утгыг тохируулна.
    /// Энэ нь өмнөх утгыг унагаалгүйгээр дарж бичих тул устгагчийг алгасахыг хүсэхгүй бол үүнийг хоёр удаа ашиглахаас болгоомжил.
    ///
    /// Таны тав тухтай байдлыг хангахын тулд энэ нь `self`-ийн агуулгыг (одоо аюулгүй эхлүүлсэн) өөрчлөгдөж болох лавлагааг буцаана.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // АЮУЛГҮЙ БАЙДАЛ: Бид энэ утгыг дөнгөж эхлүүлсэн.
        unsafe { self.assume_init_mut() }
    }

    /// Оруулсан утгад заагчийг авна.
    /// Энэ заагчаас унших эсвэл лавлагаа болгон хувиргах нь `MaybeUninit<T>`-ийг эхлүүлээгүй тохиолдолд тодорхой бус үйлдэл юм.
    /// Энэ заагч (non-transitively)-ийн зааж өгсөн санах ойд бичих нь тодорхойгүй үйлдэл юм (`UnsafeCell<T>`-ээс бусад тохиолдолд).
    ///
    /// # Examples
    ///
    /// Энэ аргын зөв хэрэглээ:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` руу лавлагаа үүсгэх.Бид үүнийг эхлүүлсэн тул энэ нь зүгээр юм.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Энэ аргыг буруу * ашиглах:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Бид эхлээгүй vector-ийн лавлагааг бүтээсэн!Энэ бол тодорхойгүй зан байдал юм.⚠️
    /// ```
    ///
    /// (Эхлээгүй өгөгдөлд хамаарах дүрмийг хараахан эцэслээгүй байгааг анхаарна уу, гэхдээ үүнийг дуустал эдгээрээс зайлсхийхийг зөвлөж байна.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` болон `ManuallyDrop` нь хоёулаа `repr(transparent)` тул бид заагчийг дамжуулж болно.
        self as *const _ as *const T
    }

    /// Оруулсан утгыг өөрчлөх боломжтой заагчийг авдаг.
    /// Энэ заагчаас унших эсвэл лавлагаа болгон хувиргах нь `MaybeUninit<T>`-ийг эхлүүлээгүй тохиолдолд тодорхой бус үйлдэл юм.
    ///
    /// # Examples
    ///
    /// Энэ аргын зөв хэрэглээ:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` руу лавлагаа үүсгэх.
    /// // Бид үүнийг эхлүүлсэн тул энэ нь зүгээр юм.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Энэ аргыг буруу * ашиглах:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Бид эхлээгүй vector-ийн лавлагааг бүтээсэн!Энэ бол тодорхойгүй зан байдал юм.⚠️
    /// ```
    ///
    /// (Эхлээгүй өгөгдөлд хамаарах дүрмийг хараахан эцэслээгүй байгааг анхаарна уу, гэхдээ үүнийг дуустал эдгээрээс зайлсхийхийг зөвлөж байна.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` болон `ManuallyDrop` нь хоёулаа `repr(transparent)` тул бид заагчийг дамжуулж болно.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` савнаас утгыг гаргаж авдаг.Энэ нь өгөгдөл унахыг баталгаажуулах маш сайн арга юм, учир нь үүссэн `T` нь ердийн дусал харьцах чадвартай байдаг.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` нь анхны байдалд байгаа эсэхийг баталгаажуулах нь дуудлага хийгчээс хамаарна.Агуулга бүрэн эхлээгүй байхад үүнийг дуудах нь шууд тодорхойлогдохгүй зан үйлийг үүсгэдэг.
    /// [type-level documentation][inv] нь энэхүү эхлүүлэх инварианттай холбоотой нэмэлт мэдээллийг агуулдаг.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Дээрээс нь ихэнх төрлүүд нь зөвхөн анхны түвшинд тохируулагдсан гэж тооцогдохоос гадна нэмэлт инвариантуудтай байдаг гэдгийг санаарай.
    /// Жишээлбэл, `1`-эхлүүлсэн [`Vec<T>`]-ийг эхлүүлсэн гэж үзнэ (одоогийн хэрэгжүүлэлтийн дагуу; энэ нь тогтвортой баталгааг бүрдүүлэхгүй) тул хөрвүүлэгчийн мэддэг цорын ганц шаардлага бол өгөгдлийн заагч нь тэг байх ёстой.
    ///
    /// Ийм `Vec<T>` үүсгэх нь *шууд* тодорхойлогдоогүй зан авирыг үүсгэдэггүй, гэхдээ ихэнх аюулгүй ажиллагаа (оруулаад оруулаад) тодорхойлогдоогүй зан үйлийг үүсгэдэг.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Энэ аргын зөв хэрэглээ:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Энэ аргыг буруу * ашиглах:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` хараахан эхлээгүй байсан тул энэ сүүлчийн мөр нь тодорхойгүй зан авирыг үүсгэсэн.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `self`-ийг эхлүүлсэн болохыг баталгаажуулах ёстой.
        // Энэ нь `self` нь `value` хувилбар байх ёстой гэсэн үг юм.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` савнаас утгыг уншина.Үүний үр дүнд үүссэн `T` нь ердийн дуслын харьцалтад хамаарна.
    ///
    /// Боломжтой бол оронд нь [`assume_init`]-ийг ашиглах нь зүйтэй бөгөөд энэ нь `MaybeUninit<T>`-ийн агуулгыг давхардуулахаас сэргийлдэг.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` нь анхны байдалд байгаа эсэхийг баталгаажуулах нь дуудлага хийгчээс хамаарна.Агуулга бүрэн эхлээгүй байхад үүнийг дуудах нь тодорхойгүй зан авирыг үүсгэдэг.
    /// [type-level documentation][inv] нь энэхүү эхлүүлэх инварианттай холбоотой нэмэлт мэдээллийг агуулдаг.
    ///
    /// Үүнээс гадна, энэ нь `MaybeUninit<T>`-т ижил өгөгдлийн хуулбарыг үлдээдэг.
    /// Мэдээллийн олон хуулбарыг ашиглахдаа (`assume_init_read` руу олон удаа залгах, эсвэл эхлээд `assume_init_read`, дараа нь [`assume_init`] руу залгах замаар) өгөгдөл үнэхээр давхардсан байх ёстой.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Энэ аргын зөв хэрэглээ:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` нь `Copy` тул бид олон удаа уншиж магадгүй юм.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` утгыг хуулбарлах нь зүгээр тул бид олон удаа уншиж магадгүй юм.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Энэ аргыг буруу * ашиглах:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Бид одоо ижил vector-ийн хоёр хувийг бүтээсэн бөгөөд хоёулаа унах үед давхар үнэ төлбөргүй ⚠️ гаргах боломжтой боллоо!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `self`-ийг эхлүүлсэн болохыг баталгаажуулах ёстой.
        // `self.as_ptr()`-г эхлүүлэх шаардлагатай тул `self.as_ptr()`-ээс унших нь аюулгүй юм.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Агуулагдсан утгыг унагав.
    ///
    /// Хэрэв та `MaybeUninit` өмчлөгчтэй бол оронд нь [`assume_init`] ашиглаж болно.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` нь анхны байдалд байгаа эсэхийг баталгаажуулах нь дуудлага хийгчээс хамаарна.Агуулга бүрэн эхлээгүй байхад үүнийг дуудах нь тодорхойгүй зан авирыг үүсгэдэг.
    ///
    /// Дээрээс нь `T` (эсвэл түүний гишүүд)-ийн `Drop` хэрэгжилт үүнд найдаж болох тул `T` төрлийн бүх нэмэлт хувьсагчдыг хангасан байх ёстой.
    /// Жишээлбэл, `1`-эхлүүлсэн [`Vec<T>`]-ийг эхлүүлсэн гэж үзнэ (одоогийн хэрэгжүүлэлтийн дагуу; энэ нь тогтвортой баталгааг бүрдүүлэхгүй) тул хөрвүүлэгчийн мэддэг цорын ганц шаардлага бол өгөгдлийн заагч нь тэг байх ёстой.
    ///
    /// Ийм `Vec<T>`-ийг унагаах нь тодорхойгүй зан авирыг үүсгэдэг.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `self`-ийг эхлүүлсэн болохыг баталгаажуулах ёстой
        // `T`-ийн бүх хувьсагчдыг хангаж өгдөг.
        // Хэрэв ийм тохиолдол байвал үнэ цэнийг нь унагаах нь аюулгүй юм.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Оруулсан утгын талаар хуваалцсан лавлагаа авна.
    ///
    /// Бид эхлүүлсэн боловч `MaybeUninit` өмчлөөгүй (`.assume_init()`)-ийг ашиглахаас сэргийлж) `MaybeUninit`-т хандахыг хүсч байгаа үед энэ нь ашигтай байж болох юм.
    ///
    /// # Safety
    ///
    /// Агуулга бүрэн эхлээгүй байхад үүнийг дуудах нь тодорхойгүй зан авирыг үүсгэдэг: энэ нь `MaybeUninit<T>` үнэхээр эхлүүлсэн төлөвт байгаа эсэхийг баталгаажуулах нь дуудлага хийгчээс хамаарна.
    ///
    ///
    /// # Examples
    ///
    /// ### Энэ аргын зөв хэрэглээ:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x`-ийг эхлүүлэх:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Одоо манай `MaybeUninit<_>`-ийг эхлүүлэх нь мэдэгдэж байгаа тул энэ талаар хуваалцсан лавлагаа үүсгэх нь зөв юм.
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // АЮУЛГҮЙ БАЙДАЛ: `x`-ийг эхлүүлсэн.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Энэ аргын буруу * хэрэглээ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Бид эхлээгүй vector-ийн лавлагааг бүтээсэн!Энэ бол тодорхойгүй зан байдал юм.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` ашиглан `MaybeUninit`-ийг эхлүүлэх:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Эхлээгүй `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `self`-ийг эхлүүлсэн болохыг баталгаажуулах ёстой.
        // Энэ нь `self` нь `value` хувилбар байх ёстой гэсэн үг юм.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Оруулсан утгын талаар өөрчлөгдөж болох (unique) лавлагааг авна.
    ///
    /// Бид эхлүүлсэн боловч `MaybeUninit` өмчлөөгүй (`.assume_init()`)-ийг ашиглахаас сэргийлж) `MaybeUninit`-т хандахыг хүсч байгаа үед энэ нь ашигтай байж болох юм.
    ///
    /// # Safety
    ///
    /// Агуулга бүрэн эхлээгүй байхад үүнийг дуудах нь тодорхойгүй зан авирыг үүсгэдэг: энэ нь `MaybeUninit<T>` үнэхээр эхлүүлсэн төлөвт байгаа эсэхийг баталгаажуулах нь дуудлага хийгчээс хамаарна.
    /// Жишээлбэл, `.assume_init_mut()`-ийг `MaybeUninit`-ийг эхлүүлэхэд ашиглах боломжгүй.
    ///
    /// # Examples
    ///
    /// ### Энэ аргын зөв хэрэглээ:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Оруулах буферын *бүх* байтыг эхлүүлнэ.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf`-ийг эхлүүлэх:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Одоо бид `buf`-ийг эхлүүлсэн гэдгийг мэдэж байгаа тул `.assume_init()` хийж болно.
    /// // Гэхдээ `.assume_init()` ашиглах нь 2048 байтын `memcpy`-ийг өдөөж магадгүй юм.
    /// // Бидний буферийг хуулбарлахгүйгээр эхлүүлсэн гэдгийг батлахын тулд бид `&mut MaybeUninit<[u8; 2048]>`-ийг `&mut [u8; 2048]` болгож сайжруулсан болно.
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // АЮУЛГҮЙ БАЙДАЛ: `buf`-ийг эхлүүлсэн.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Одоо бид `buf`-ийг ердийн зүсмэл болгон ашиглаж болно.
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Энэ аргын буруу * хэрэглээ:
    ///
    /// Та утгыг эхлүүлэхийн тулд `.assume_init_mut()` ашиглаж болохгүй:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Бид эхлээгүй `bool`-ийн талаархи (mutable) лавлагаа бий болгосон!
    ///     // Энэ бол тодорхойгүй зан байдал юм.⚠️
    /// }
    /// ```
    ///
    /// Жишээлбэл, та [`Read`]-г эхлүүлээгүй буферт оруулах боломжгүй:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) эхлээгүй санах ойн лавлагаа!
    ///                             // Энэ бол тодорхойгүй зан байдал юм.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Талбайгаар аажмаар эхлүүлэхийн тулд та шууд талбайн хандалтыг ашиглаж чадахгүй:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) эхлээгүй санах ойн лавлагаа!
    ///                  // Энэ бол тодорхойгүй зан байдал юм.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) эхлээгүй санах ойн лавлагаа!
    ///                  // Энэ бол тодорхойгүй зан байдал юм.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Одоогоор бид дээрх алдаатай гэдэгт найдаж байна, өөрөөр хэлбэл, эхлээгүй өгөгдөлд иш татсан болно (жишээлбэл, `libcore/fmt/float.rs` дээр).
    // Тогтворжуулахаас өмнө дүрмийн талаар эцсийн шийдвэр гаргах ёстой.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // АЮУЛГҮЙ БАЙДАЛ: дуудагч нь `self`-ийг эхлүүлсэн болохыг баталгаажуулах ёстой.
        // Энэ нь `self` нь `value` хувилбар байх ёстой гэсэн үг юм.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` савны массиваас утгыг гаргаж авдаг.
    ///
    /// # Safety
    ///
    /// Массивын бүх элементүүд анхны төлөвт байгаа эсэхийг баталгаажуулах нь дуудлага хийгчээс хамаарна.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // АЮУЛГҮЙ БАЙДАЛ: Бүх элементүүдийг эхлүүлснээр аюулгүй
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Залгагч нь массивын бүх элементүүдийг эхлүүлэх баталгаа өгдөг
        // * `MaybeUninit<T>` ба T нь ижил загвартай байх баталгаатай болно
        // * Магадгүй Unnint унахгүй тул давхар үнэ төлбөргүй байдаг тул хөрвүүлэлт аюулгүй болно
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Бүх элементүүдийг эхлүүлсэн гэж үзвэл тэдгээрийн зүсмэлийг аваарай.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` элементүүд үнэхээр анхны байдалд байгаа эсэхийг баталгаажуулах нь дуудлага хийгчээс хамаарна.
    ///
    /// Агуулга бүрэн эхлээгүй байхад үүнийг дуудах нь тодорхойгүй зан авирыг үүсгэдэг.
    ///
    /// Илүү дэлгэрэнгүй, жишээг [`assume_init_ref`]-с үзнэ үү.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // АЮУЛГҮЙ БАЙДАЛ: зүсмэлийг `*const [T]` руу цутгах нь аюулгүй тул дуудлага хийж буй хүн баталгаажуулдаг
        // `slice` эхлүүлсэн бөгөөд "MaybeUninit" нь `T`-тэй ижил загвартай байх баталгаатай болно.
        // Авсан заагч нь `slice`-ийн санах ойд хамаарах бөгөөд энэ нь уншихад хүчин төгөлдөр болох баталгаатай санах ойг хэлнэ.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Бүх элементүүдийг эхлүүлсэн гэж үзвэл тэдгээрт өөрчлөгдөж болох зүсмэлийг аваарай.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` элементүүд үнэхээр анхны байдалд байгаа эсэхийг баталгаажуулах нь дуудлага хийгчээс хамаарна.
    ///
    /// Агуулга бүрэн эхлээгүй байхад үүнийг дуудах нь тодорхойгүй зан авирыг үүсгэдэг.
    ///
    /// Илүү дэлгэрэнгүй, жишээг [`assume_init_mut`]-с үзнэ үү.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // Аюулгүй байдал: `slice_get_ref`-ийн аюулгүй байдлын тэмдэглэлтэй төстэй боловч бидэнд
        // бичихэд хүчинтэй байх баталгаатай, өөрчлөгдөж болох лавлагаа.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Массивын эхний элементэд заагчийг авна.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Массивын эхний элементэд өөрчлөгдөж болох заагчийг авдаг.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src`-ээс `this` хүртэлх элементүүдийг хуулбарлаж, `this`-ийн одоо шинэчилсэн агуулгатай холбоотой өөрчлөгдөж болох лавлагааг буцаана.
    ///
    /// Хэрэв `T` нь `Copy`-ийг хэрэгжүүлээгүй бол [`write_slice_cloned`]-ийг ашиглаарай
    ///
    /// Энэ нь [`slice::copy_from_slice`]-тэй төстэй юм.
    ///
    /// # Panics
    ///
    /// Хоёр зүсмэлийн урт өөр байвал энэ функц panic болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // АЮУЛГҮЙ БАЙДАЛ: бид len-ийн бүх элементүүдийг нөөц хүчин чадлаар нь дөнгөж сая хуулбарлалаа
    /// // vec-ийн эхний src.len() элементүүд хүчин төгөлдөр болсон.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // АЮУЛГҮЙ БАЙДАЛ: &[T] ба&[Магадгүй Uninit<T>] ижил зохион байгуулалттай байна
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // АЮУЛГҮЙ АЖИЛЛАГАА: Хүчин төгөлдөр элементүүдийг `this` руу дөнгөж хуулсан тул үүнийг идэвхжүүлсэн болно
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src`-ээс `this` хүртэлх элементүүдийг клончлох бөгөөд одоо өөрчлөгдөж буй `this` агуулгад өөрчлөлт оруулах боломжтой.
    /// Урьдчилан боловсруулсан элементүүдийг хаяхгүй.
    ///
    /// Хэрэв `T` нь `Copy`-ийг хэрэгжүүлж байгаа бол [`write_slice`]-ийг ашиглаарай
    ///
    /// Энэ нь [`slice::clone_from_slice`]-тэй төстэй боловч одоо байгаа элементүүдийг унагахгүй.
    ///
    /// # Panics
    ///
    /// Хэрэв хоёр зүсмэлийн урт өөр байвал эсвэл `Clone` panics хэрэгжвэл энэ функц panic болно.
    ///
    /// Хэрэв panic байгаа бол аль хэдийн клончлогдсон элементүүдийг хаях болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // АЮУЛГҮЙ БАЙДАЛ: бид len-ийн бүх элементүүдийг нөөц хүчин чадлаар нь клончлов
    /// // vec-ийн эхний src.len() элементүүд хүчин төгөлдөр болсон.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice-ээс ялгаатай нь энэ нь зүсмэл дээрх clone_from_slice гэж нэрлэхгүй тул `MaybeUninit<T: Clone>` нь Clone програмыг хэрэгжүүлдэггүйтэй холбоотой юм.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // АЮУЛГҮЙ БАЙДАЛ: энэ түүхий зүсэмд зөвхөн эхлүүлсэн объект агуулагдах болно
                // Тиймээс үүнийг хаяхыг зөвшөөрдөг.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Бид тэдгээрийг ижил уртаар нь зүсэх хэрэгтэй
        // хязгаарыг шалгахын тулд оновчлогч энгийн тохиолдлуудад memcpy үүсгэх болно (жишээлбэл T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // хамгаалагч шаардлагатай байна b/c panic нь клоны үед тохиолдож болзошгүй
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // АЮУЛГҮЙ АЖИЛЛАГАА: Хүчин төгөлдөр элементүүдийг `this` дээр дөнгөж сая бичсэн тул үүнийг идэвхжүүлсэн болно
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}