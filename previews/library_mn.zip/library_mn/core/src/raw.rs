#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Хөрвүүлэгчийн суулгасан төрлүүдийн зохион байгуулалтын тодорхойлолтыг агуулдаг.
//!
//! Тэдгээрийг түүхий дүрслэлийг шууд удирдахад ашиггүй кодонд дамжуулагчийн зорилт болгон ашиглаж болно.
//!
//!
//! Тэдний тодорхойлолт нь `rustc_middle::ty::layout`-д тодорхойлогдсон ABI-тэй үргэлж тохирч байх ёстой.
//!

/// `&dyn SomeTrait` шиг trait объектын дүрслэл.
///
/// Энэ бүтэц нь `&dyn SomeTrait` ба `Box<dyn AnotherTrait>` зэрэг төрлүүдтэй ижил байршилтай байдаг.
///
/// `TraitObject` нь байршлыг тааруулах баталгаатай боловч энэ нь trait объектын төрөл биш (жишээлбэл, талбарууд нь `&dyn SomeTrait` дээр шууд нэвтрэх боломжгүй) эсвэл байршлыг хянах боломжгүй (тодорхойлолтыг өөрчлөх нь `&dyn SomeTrait`-ийн байрлалыг өөрчлөхгүй).
///
/// Энэ нь зөвхөн доод түвшний нарийн ширийн зүйлийг зохицуулах шаардлагатай аюултай код ашиглахад зориулагдсан болно.
///
/// Бүх trait обьектыг ерөнхийд нь авч үзэх арга байхгүй тул энэ төрлийн утгыг бий болгох цорын ганц арга бол [`std::mem::transmute`][transmute] гэх мэт функцууд юм.
/// Үүнтэй адил `TraitObject` утгаас жинхэнэ trait объектыг бүтээх цорын ганц арга бол `transmute` юм.
///
/// [transmute]: crate::intrinsics::transmute
///
/// trait объектыг тохиромжгүй төрлүүдтэй нэгтгэх-vtable нь өгөгдлийн заагчийн зааж өгсөн утгын төрөлд тохирохгүй байх нь тодорхойгүй байдалд хүргэх магадлал өндөр юм.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // жишээ trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // хөрвүүлэгч trait объектыг хийцгээе
/// let object: &dyn Foo = &value;
///
/// // түүхий төлөөллийг харах
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // өгөгдлийн заагч нь `value` хаяг юм
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `object`-ээс `i32` vtable-ийг ашиглахдаа болгоомжтой байж, өөр `i32`-ийг зааж шинэ объект барих.
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // Энэ нь яг `other_value`-ээс trait объектыг шууд барьсан юм шиг ажиллах ёстой
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}