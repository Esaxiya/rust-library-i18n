//! `Clone` trait нь 'далд хэлбэрээр хуулж' чадахгүй байгаа төрлүүдэд зориулагдсан.
//!
//! Rust-д зарим энгийн төрлүүд нь "implicitly copyable" байдаг бөгөөд тэдгээрийг хуваарилах эсвэл нэмэлт өгөгдлөөр дамжуулахад хүлээн авагч нь анхны утгыг хэвээр үлдээж хуулбарыг авах болно.
//! Эдгээр төрлүүд нь хуулбарлахад хуваарилалт шаарддаггүй бөгөөд эцсийн тохируулагчгүй байдаг (өөрөөр хэлбэл тэдгээр нь өмчлөгдсөн хайрцгуудыг агуулдаггүй эсвэл [`Drop`] програмыг ашигладаггүй) тул хөрвүүлэгч тэдгээрийг хуулбарлахад хямд, аюулгүй гэж үздэг.
//!
//! Бусад төрлүүдийн хувьд хуулбарыг [`Clone`] trait-ийг хэрэгжүүлж [`clone`] аргыг дуудах замаар тодорхой хуулбарласан байх ёстой.
//!
//! [`clone`]: Clone::clone
//!
//! Хэрэглээний үндсэн жишээ:
//!
//! ```
//! let s = String::new(); // String type нь Clone-ийг хэрэгжүүлдэг
//! let copy = s.clone(); // Тиймээс бид үүнийг хувилж болно
//! ```
//!
//! Clone trait-ийг хялбархан хэрэгжүүлэхийн тулд та `#[derive(Clone)]` ашиглаж болно.Жишээ:
//!
//! ```
//! #[derive(Clone)] // бид Clone trait-ийг Morpheus struct дээр нэмнэ
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // одоо бид үүнийг хувилж болно!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Объектыг тодорхой хуулбарлах чадвартай нийтлэг trait.
///
/// [`Copy`]-ээс ялгаатай нь [`Copy`] нь далд бөгөөд маш хямд байдаг бол `Clone` нь үргэлж тодорхой бөгөөд үнэтэй эсвэл үнэтэй байдаггүй.
/// Эдгээр шинж чанаруудыг хэрэгжүүлэхийн тулд Rust нь [`Copy`]-ийг дахин хэрэгжүүлэхийг зөвшөөрдөггүй боловч та `Clone`-ийг дахин хэрэгжүүлж дурын код ажиллуулж болно.
///
/// `Clone` нь [`Copy`]-ээс илүү ерөнхий тул [`Copy`]-ийг `Clone` болгож автоматаар хийж болно.
///
/// ## Derivable
///
/// Хэрэв бүх талбарууд `Clone` бол энэ trait-ийг `#[derive]`-тэй ашиглаж болно.[`Clone`]-ийн "derive`d" хэрэгжилт нь талбар бүрт [`clone`]-ийг дууддаг.
///
/// [`clone`]: Clone::clone
///
/// Ерөнхий бүтцийн хувьд `#[derive]` нь ерөнхий параметрүүд дээр холбосон `Clone` нэмж, `Clone`-ийг нөхцөлт байдлаар хэрэгжүүлдэг.
///
/// ```
/// // `derive` Уншихад зориулсан Clone програмыг хэрэгжүүлдэг<T>T нь Clone бол.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Би `Clone`-ийг хэрхэн хэрэгжүүлэх вэ?
///
/// [`Copy`] хэлбэрүүд нь `Clone`-ийн өчүүхэн хэрэгжилттэй байх ёстой.Илүү албан ёсоор:
/// хэрэв `T: Copy`, `x: T`, `y: &T` бол `let x = y.clone();` нь `let x = *y;`-тэй тэнцэнэ.
/// Гарын авлагын хэрэгжилт нь энэхүү өөрчлөгдөхгүй байдлыг хадгалахын тулд болгоомжтой байх ёстой;гэхдээ аюулгүй код нь санах ойн аюулгүй байдлыг хангахын тулд үүнд найдах ёсгүй.
///
/// Жишээ нь функцийн заагчийг барьж буй ерөнхий бүтэц юм.Энэ тохиолдолд `Clone`-ийн хэрэгжилтийг `авч 'чадахгүй, гэхдээ дараахь байдлаар хэрэгжүүлж болно.
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Нэмэлт хэрэгжүүлэгчид
///
/// [implementors listed below][impls]-ээс гадна дараахь төрлүүд `Clone`-ийг хэрэгжүүлдэг.
///
/// * Чиг үүргийн төрлүүд (өөрөөр хэлбэл функц тус бүрт тодорхойлсон ялгаатай төрлүүд)
/// * Функцийн заагчийн төрлүүд (жишээлбэл, `fn() -> i32`)
/// * Массивын төрлүүд, бүх төрлийн хувьд `Clone` (жишээлбэл, `[i32; 123456]`)
/// * Tuple төрөл, хэрэв бүрэлдэхүүн хэсэг бүр `Clone` (жишээлбэл, `()`, `(i32, bool)`)-ийг хэрэгжүүлдэг бол
/// * Хэрэв тэдгээр нь хүрээлэн буй орчноос ямар ч үнэ цэнэ авдаггүй эсвэл эдгээр бүх авсан утгууд нь `Clone`-ийг өөрсдөө хэрэгжүүлдэг бол хаалтын төрөл.
///   Хуваалцсан лавлагаагаар авсан хувьсагчид үргэлж `Clone`-ийг хэрэгжүүлдэг (лавлагаа өгдөггүй ч гэсэн), харин өөрчлөгдөж болох лавлагаагаар авсан хувьсагчид хэзээ ч `Clone`-ийг хэрэгжүүлдэггүйг анхаарна уу.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Утга хэмжээний хуулбарыг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str Clone-ийг хэрэгжүүлдэг
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source`-ээс хуулбарлах даалгаврыг гүйцэтгэдэг.
    ///
    /// `a.clone_from(&b)` нь функциональ байдлаараа `a = b.clone()`-тэй тэнцэх боловч шаардлагагүй хуваарилалтаас зайлсхийхийн тулд `a`-ийн нөөцийг дахин ашиглахын тулд хүчингүй болгож болно.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone`-ийн импл үүсгэх макро гаргаж авах.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): эдгээр бүтцийг зөвхөн#[derive] ашигладаг бөгөөд бүх төрлийн бүрэлдэхүүн хэсгүүд нь Clone эсвэл Copy програмыг хэрэгжүүлдэг болохыг батлах болно.
//
//
// Эдгээр бүтэц нь хэрэглэгчийн кодод хэзээ ч харагдахгүй байх ёстой.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Балар эртний төрлүүдэд зориулсан `Clone` хэрэгжилт.
///
/// Rust дээр тайлбарлах боломжгүй хэрэгжилтийг `traits::SelectionContext::copy_clone_conditions()` дээр `rustc_trait_selection` дээр хэрэгжүүлдэг.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Хуваалцсан лавлагааг клончлох боломжтой боловч өөрчлөх боломжтой лавлагаа *чадахгүй*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Хуваалцсан лавлагааг клончлох боломжтой боловч өөрчлөх боломжтой лавлагаа *чадахгүй*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}