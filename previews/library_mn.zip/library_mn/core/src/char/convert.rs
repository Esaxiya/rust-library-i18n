//! Тэмдэгт хөрвүүлэх.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32`-ийг `char` болгон хөрвүүлдэг.
///
/// Бүх [`char`] хүчин төгөлдөр [`u32`]-тэй тэнцэх бөгөөд үүнийг нэг рүү шилжүүлэх боломжтой гэдгийг анхаарна уу
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Гэсэн хэдий ч, урвуу нь үнэн биш юм: бүх хүчинтэй [`u32`] хүчинтэй [[char`] s биш юм.
/// `from_u32()` оролт нь [`char`]-ийн хувьд зөв утга биш бол `None`-ийг буцаана.
///
/// Эдгээр шалгалтыг үл тоомсорлож буй энэ функцын аюултай хувилбарыг [`from_u32_unchecked`]-ээс үзнэ үү.
///
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Оролт нь хүчин төгөлдөр бус [`char`] биш үед `None`-ийг буцааж өгөх:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Хүчин төгөлдөр байдлыг үл тоомсорлож, `u32`-ийг `char` болгон хөрвүүлдэг.
///
/// Бүх [`char`] хүчин төгөлдөр [`u32`]-тэй тэнцэх бөгөөд үүнийг нэг рүү шилжүүлэх боломжтой гэдгийг анхаарна уу
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Гэсэн хэдий ч, урвуу нь үнэн биш юм: бүх хүчинтэй [`u32`] хүчинтэй [[char`] s биш юм.
/// `from_u32_unchecked()` үүнийг үл тоомсорлож, [`char`] руу сохроор шидэж магадгүй хүчингүйг үүсгэх болно.
///
///
/// # Safety
///
/// Хүчингүй `char` утгыг үүсгэж болзошгүй тул энэ функц нь аюултай юм.
///
/// Энэ функцын аюулгүй хувилбарыг [`from_u32`] функцийг үзнэ үү.
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // АЮУЛГҮЙ БАЙДАЛ: дуудлага хийгч нь `i`-ийг хүчин төгөлдөр байх ёстой гэдгийг баталгаажуулах ёстой.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`]-ийг [`u32`] болгон хөрвүүлдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`]-ийг [`u64`] болгон хөрвүүлдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Чар кодыг кодын утга руу шилжүүлж дараа нь тэг хүртэл сунгаж 64 бит болгоно.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]-г үзнэ үү
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`]-ийг [`u128`] болгон хөрвүүлдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Чар кодыг кодын утга руу шилжүүлж, тэг болгож 128 бит болгон өргөтгөв.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]-г үзнэ үү
        c as u128
    }
}

/// Кодын цэг нь ижил утгатай `char`-т 0x00 ..=0xFF-ээр байтыг зурж, U + 0000 ..=U + 00FF.
///
/// Юникод нь IANA-ийн ISO-8859-1 гэж нэрлэдэг тэмдэгт кодчилол бүхий байтыг үр дүнтэй декодлох байдлаар хийгдсэн болно.
/// Энэ кодчилол нь ASCII-тэй нийцдэг.
///
/// Энэ нь ISO/IEC 8859-1 aka-ээс ялгаатай болохыг анхаарна уу
/// ISO 8859-1 (нэг доогуур зураастай) бөгөөд энэ нь зарим тэмдэгтэд оноогүй байтын утгыг "blanks" үлдээдэг.
/// ISO-8859-1 (IANA нь) тэдгээрийг C0 ба C1 хяналтын кодуудад хуваарилдаг.
///
/// Энэ нь Windows-1252 акагаас *бас* өөр гэдгийг анхаарна уу
/// кодын хуудас 1252, энэ нь ISO/IEC 8859-1 дээд тохиргоо бөгөөд зарим (бүгд биш!) хоосон зайг цэг таслал, латин тэмдэгтэд өгдөг.
///
/// Аливаа зүйлийг цааш нь будлиантуулахын тулд [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, `windows-1252` нь Windows-1252-ийн дээд багцад зориулсан хоосон нэр бөгөөд үлдсэн хоосон зайг харгалзах C0 ба C1 хяналтын кодоор дүүргэдэг.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`]-ийг [`char`] болгон хөрвүүлдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Char-г задлахад буцааж болох алдаа.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // АЮУЛГҮЙ БАЙДАЛ: энэ нь хууль ёсны юникодын үнэ цэнэ мөн эсэхийг шалгасан
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32-ээс char руу хөрвүүлэлт амжилтгүй болоход алдааны төрөл буцаж ирэв.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Өгөгдсөн радиус дахь цифрийг `char` болгож хөрвүүлнэ.
///
/// Энд байгаа 'radix'-ийг заримдаа 'base' гэж нэрлэдэг.
/// Хоёр радиус нь хоёртын тоо, аравтын аравтын бутархай, арван зургаатын арван зургаа дахь радиусыг заана.
///
/// Дур мэдэн радикалууд дэмжигддэг.
///
/// `from_digit()` оролт нь тухайн радиус дахь цифр биш бол `None`-ийг буцаана.
///
/// # Panics
///
/// 36-аас дээш радиус өгвөл Panics.
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Аравтын бутархай 11 нь 16-р суурийн нэг оронтой тоо юм
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Оролт нь цифр биш байхад `None`-ийг буцааж өгөх:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// panic үүсгэдэг том радиусыг дамжуулж:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}