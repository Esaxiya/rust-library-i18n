//! импл char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char`-ийн хамгийн өндөр хүчин төгөлдөр кодын цэг.
    ///
    /// `char` бол [Unicode Scalar Value] бөгөөд энэ нь [Code Point] гэсэн үг, гэхдээ зөвхөн тодорхой хязгаарт багтдаг гэсэн үг юм.
    /// `MAX` нь [Unicode Scalar Value] хүчинтэй хамгийн өндөр хүчинтэй кодын цэг юм.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () нь код тайлах алдааг илэрхийлэх зорилгоор Unicode-д ашиглагддаг.
    ///
    /// Жишээлбэл, буруу хэлбэртэй UTF-8 байтыг [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy)-д өгөх үед тохиолдож болно.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// `char` ба `str` аргуудын Unicode хэсгүүдэд суурилсан [Unicode](http://www.unicode.org/) хувилбар.
    ///
    /// Юникодын шинэ хувилбарууд тогтмол гардаг бөгөөд дараа нь Юникод хамаарч стандарт номын сангийн бүх аргууд шинэчлэгддэг.
    /// Тиймээс зарим `char` ба `str` аргуудын зан байдал, энэ тогтмол утга нь цаг хугацааны явцад өөрчлөгдөж байдаг.
    /// Үүнийг * өөрчлөлт хийхгүй гэж үзэж байна.
    ///
    /// Хувилбарыг дугаарлах схемийг [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) дээр тайлбарласан болно.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` дахь кодчилогдсон UTF-16 кодын цэгүүд дээр давталт үүсгэж, хосгүй орлуулагчдыг "Err`s" болгож буцаана.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Алдагдалтай декодерыг `Err` үр дүнг орлуулах тэмдэгтээр сольж авах боломжтой.
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32`-ийг `char` болгон хөрвүүлдэг.
    ///
    /// Бүх `char` хүчинтэй [`u32`]-г тэмдэглэж, үүнийг нэг рүү шилжүүлэх боломжтой гэдгийг анхаарна уу
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Гэсэн хэдий ч урвуу нь үнэн биш юм: хүчинтэй бүх ['u32`] хүчинтэй`char`s биш юм.
    /// `from_u32()` оролт нь `char`-ийн хувьд зөв утга биш бол `None`-ийг буцаана.
    ///
    /// Эдгээр шалгалтыг үл тоомсорлож буй энэ функцын аюултай хувилбарыг [`from_u32_unchecked`]-ээс үзнэ үү.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Оролт нь хүчин төгөлдөр бус `char` биш үед `None`-ийг буцааж өгөх:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Хүчин төгөлдөр байдлыг үл тоомсорлож, `u32`-ийг `char` болгон хөрвүүлдэг.
    ///
    /// Бүх `char` хүчинтэй [`u32`]-г тэмдэглэж, үүнийг нэг рүү шилжүүлэх боломжтой гэдгийг анхаарна уу
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Гэсэн хэдий ч урвуу нь үнэн биш юм: хүчинтэй бүх ['u32`] хүчинтэй`char`s биш юм.
    /// `from_u32_unchecked()` үүнийг үл тоомсорлож, `char` руу сохроор шидэж магадгүй хүчингүйг үүсгэх болно.
    ///
    ///
    /// # Safety
    ///
    /// Хүчингүй `char` утгыг үүсгэж болзошгүй тул энэ функц нь аюултай юм.
    ///
    /// Энэ функцын аюулгүй хувилбарыг [`from_u32`] функцийг үзнэ үү.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // АЮУЛГҮЙ БАЙДАЛ: аюулгүй байдлын гэрээг дуудлага өгсөн хүн дагаж мөрдөх ёстой.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Өгөгдсөн радиус дахь цифрийг `char` болгож хөрвүүлнэ.
    ///
    /// Энд байгаа 'radix'-ийг заримдаа 'base' гэж нэрлэдэг.
    /// Хоёр радиус нь хоёртын тоо, аравтын аравтын бутархай, арван зургаатын арван зургаа дахь радиусыг заана.
    ///
    /// Дур мэдэн радикалууд дэмжигддэг.
    ///
    /// `from_digit()` оролт нь тухайн радиус дахь цифр биш бол `None`-ийг буцаана.
    ///
    /// # Panics
    ///
    /// 36-аас дээш радиус өгвөл Panics.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Аравтын бутархай 11 нь 16-р суурийн нэг оронтой тоо юм
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Оролт нь цифр биш байхад `None`-ийг буцааж өгөх:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// panic үүсгэдэг том радиусыг дамжуулж:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// `char` нь өгөгдсөн радиус дахь цифр эсэхийг шалгана.
    ///
    /// Энд байгаа 'radix'-ийг заримдаа 'base' гэж нэрлэдэг.
    /// Хоёр радиус нь хоёртын тоо, аравтын аравтын бутархай, арван зургаатын арван зургаа дахь радиусыг заана.
    ///
    /// Дур мэдэн радикалууд дэмжигддэг.
    ///
    /// [`is_numeric()`]-тэй харьцуулахад энэ функц нь зөвхөн `0-9`, `a-z` ба `A-Z` тэмдэгтүүдийг таньдаг.
    ///
    /// 'Digit' нь зөвхөн дараах тэмдэгтүүд байхаар тодорхойлогдсон байна.
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit'-ийн талаархи дэлгэрэнгүй ойлголтыг [`is_numeric()`]-ээс үзнэ үү.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// 36-аас дээш радиус өгвөл Panics.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// panic үүсгэдэг том радиусыг дамжуулж:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char`-ийг өгөгдсөн радиус дахь орон руу хөрвүүлнэ.
    ///
    /// Энд байгаа 'radix'-ийг заримдаа 'base' гэж нэрлэдэг.
    /// Хоёр радиус нь хоёртын тоо, аравтын аравтын бутархай, арван зургаатын арван зургаа дахь радиусыг заана.
    ///
    /// Дур мэдэн радикалууд дэмжигддэг.
    ///
    /// 'Digit' нь зөвхөн дараах тэмдэгтүүд байхаар тодорхойлогдсон байна.
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Хэрэв `char` нь тухайн радиус дахь цифрийг заагаагүй бол `None` буцаана.
    ///
    /// # Panics
    ///
    /// 36-аас дээш радиус өгвөл Panics.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Цифрээс бусад үр дүнг дамжуулснаар бүтэлгүйтэх болно:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// panic үүсгэдэг том радиусыг дамжуулж:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` тогтмол бөгөөд 10 ба түүнээс бага тохиолдолд гүйцэтгэлийн хурдыг сайжруулахын тулд кодыг энд хуваана
        //
        let val = if likely(radix <= 10) {
            // Хэрэв цифр биш бол radix-ээс их тоо үүсгэх болно.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// "Char`s" гэсэн тэмдэгтээс арван зургаат Unicode-ийн зугтаж буй давталтыг буцаана.
    ///
    /// Энэ нь `\u{NNNNNN}` хэлбэрийн Rust синтакс бүхий тэмдэгтээс зугтах бөгөөд `NNNNNN` бол арван зургаатын дүрслэл юм.
    ///
    ///
    /// # Examples
    ///
    /// Давталтын хувьд:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ийг шууд ашиглах:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Хоёулаа тэнцүү байна:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` ашиглах:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 нь c==0-ийн хувьд кодыг нэг цифр хэвлэх ёстойг тооцоолж, (ижил хэмжээтэй)(31, 32) хэмжээнээс зайлсхийх боломжийг олгодог
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // хамгийн чухал зургаан өнцөгт орны индекс
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Өргөтгөсөн график кодын цэгээс зугтахыг зөвшөөрсөн `escape_debug`-ийн өргөтгөсөн хувилбар.
    /// Энэ нь мөрний эхэнд байх үед зайны тэмдэггүй тэмдэгтүүдийг илүү сайн форматлах боломжийг бидэнд олгодог.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Тэмдэгтийн зугтах кодыг `char`s гэж өгдөг давталтыг буцаана.
    ///
    /// Энэ нь `str` эсвэл `char`-ийн `Debug` хэрэгжүүлэлттэй төстэй тэмдэгтээс зугтах болно.
    ///
    ///
    /// # Examples
    ///
    /// Давталтын хувьд:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ийг шууд ашиглах:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Хоёулаа тэнцүү байна:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` ашиглах:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Тэмдэгтийн зугтах кодыг `char`s гэж өгдөг давталтыг буцаана.
    ///
    /// Анхдагч тохиргоог C++ 11 болон бусад ижил төстэй хэл дээрх бусад хэл дээр хууль ёсны дагуу бичигдсэн үсгийг хэвийх байдлаар сонгов.
    /// Яг дүрмүүд нь:
    ///
    /// * `\t` гэж табаас зугтав.
    /// * Сүйх тэрэг буцаж ирэхэд `\r` гэж оргон зайлдаг.
    /// * Шугам тэжээл `\n` гэж зугтаж байна.
    /// * Нэг үнийн саналыг `\'` гэж орхижээ.
    /// * Давхар үнийн саналыг `\"` гэж оргон зайлсан.
    /// * Нурууны налууг `\\` болгож зугтаасан.
    /// * `0x20` .. `0x7e` багтаасан 'хэвлэгдэх ASCII' муж дахь аливаа тэмдэгтээс мултардаггүй.
    /// * Бусад бүх тэмдэгтэд арван зургаатын Unicode орголт өгсөн;[`escape_unicode`]-г үзнэ үү.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Давталтын хувьд:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ийг шууд ашиглах:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Хоёулаа тэнцүү байна:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` ашиглах:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 кодлогдсон тохиолдолд энэ `char`-д шаардагдах байтын тоог буцаана.
    ///
    /// Энэ байтын тоо үргэлж 1-4 хооронд байх ёстой.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` төрөл нь түүний агуулга нь UTF-8 болохыг баталгаажуулдаг тул кодын цэг бүр `char` ба `&str`-т өөрөөр илэрхийлэгдвэл түүний үргэлжлэх хугацааг харьцуулж болно.
    ///
    ///
    /// ```
    /// // тэмдэгт байдлаар
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // хоёуланг нь гурван байт хэлбэрээр илэрхийлж болно
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str-ийн хувьд эдгээр хоёрыг UTF-8-д кодчилсон болно
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // Тэд нийт зургаан байт авдаг болохыг бид харж байна ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... яг &str шиг
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 кодлогдсон тохиолдолд энэ `char`-д шаардагдах 16 битийн кодын тоог буцаана.
    ///
    ///
    /// Энэхүү үзэл баримтлалын талаар илүү дэлгэрэнгүй тайлбар авахын тулд [`len_utf8()`]-ийн баримт бичгийг үзнэ үү.
    /// Энэ функц нь толин тусгал боловч UTF-8-ийн оронд UTF-16-т зориулагдсан болно.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Энэ тэмдэгтийг өгөгдсөн байт буферт UTF-8 гэж кодлоод дараа нь кодчилогдсон тэмдэгт агуулсан буферын дэд хэсгийг буцаана.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв буфер нь хангалттай том биш бол Panics.
    /// Дөрвөн урттай буфер нь ямар ч `char`-ийг кодлоход хангалттай.
    ///
    /// # Examples
    ///
    /// Эдгээр хоёр жишээнд 'ß' нь хоёр байтыг кодчилдог.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Хэт жижиг буфер:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // АЮУЛГҮЙ БАЙДАЛ: `char` нь орлуулагч биш тул энэ нь хүчинтэй UTF-8 юм.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Энэ тэмдэгтийг өгөгдсөн `u16` буферт UTF-16 гэж кодлоод дараа нь кодчилогдсон тэмдэгт агуулсан буферын дэд хэсгийг буцаана.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв буфер нь хангалттай том биш бол Panics.
    /// 2-р урттай буфер нь ямар ч `char`-ийг кодлоход хангалттай.
    ///
    /// # Examples
    ///
    /// Эдгээр хоёр жишээнд '𝕊' нь кодлохын тулд хоёр u16-ийг авдаг.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Хэт жижиг буфер:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Хэрэв энэ `char` нь `Alphabetic` шинж чанартай бол `true` буцаана.
    ///
    /// `Alphabetic` [Unicode Standard]-ийн 4-р бүлэгт (Тэмдэгтийн шинж чанарууд) тайлбарласан бөгөөд [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-д заасан болно.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // хайр бол олон зүйл боловч цагаан толгой биш юм
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Хэрэв энэ `char` нь `Lowercase` шинж чанартай бол `true` буцаана.
    ///
    /// `Lowercase` [Unicode Standard]-ийн 4-р бүлэгт (Тэмдэгтийн шинж чанарууд) тайлбарласан бөгөөд [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-д заасан болно.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Хятад хэлний янз бүрийн бичиг, цэг таслалд үсэг байдаггүй тул дараахь зүйлийг оруулав.
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Хэрэв энэ `char` нь `Uppercase` шинж чанартай бол `true` буцаана.
    ///
    /// `Uppercase` [Unicode Standard]-ийн 4-р бүлэгт (Тэмдэгтийн шинж чанарууд) тайлбарласан бөгөөд [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-д заасан болно.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Хятад хэлний янз бүрийн бичиг, цэг таслалд үсэг байдаггүй тул дараахь зүйлийг оруулав.
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Хэрэв энэ `char` нь `White_Space` шинж чанартай бол `true` буцаана.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`]-д заасан болно.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // тасрахгүй орон зай
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Хэрэв энэ `char` нь [`is_alphabetic()`] эсвэл [`is_numeric()`]-ийн аль нэгийг хангаж байвал `true` буцаана.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Хэрэв энэ `char` нь хяналтын кодын ерөнхий ангилалтай бол `true` буцаана.
    ///
    /// Хяналтын кодууд (`Cc`-ийн ерөнхий ангилалтай кодын цэгүүд)-ийг [Unicode Standard]-ийн 4-р бүлэгт (Тэмдэгтийн шинж чанарууд) тайлбарласан бөгөөд [Unicode Character Database][ucd] [`UnicodeData.txt`]-д заасан болно.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// // U + 009C, STRING terminator
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Хэрэв энэ `char` нь `Grapheme_Extend` шинж чанартай бол `true` буцаана.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29]-т тайлбарласан ба [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-д заасан болно.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Хэрэв энэ `char` нь тоонуудын ерөнхий ангиллын аль нэгтэй бол `true`-ийг буцаана.
    ///
    /// Тооны ерөнхий ангиллууд (аравтын оронтой тоогоор `Nd`, үсэг шиг тоон тэмдэгтүүдээс `Nl`, бусад тоон тэмдэгтүүдээс `No`) [Unicode Character Database][ucd] [`UnicodeData.txt`]-д заасан болно.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Энэ `char`-ийн жижиг үсгийн зургийг нэг эсвэл хэд хэдэн хэлбэрээр гаргаж өгдөг давталтыг буцаана
    /// `char`s.
    ///
    /// Хэрэв энэ `char` нь жижиг үсгийн зураглалгүй бол давталт нь ижил `char` гаргадаг.
    ///
    /// Хэрэв энэ `char` нь [Unicode Character Database][ucd] [`UnicodeData.txt`]-ийн өгсөн нэг нэгээр нь жижиг үсгийн зураглалтай бол давталт нь `char`-ийг өгдөг.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Хэрэв энэ `char` нь онцгой анхаарал хандуулах шаардлагатай бол (жишээ нь олон ``char`s) давталт нь [`SpecialCasing.txt`]-ийн өгсөн `char` (ууд)-ийг гаргадаг.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Энэ ажиллагаа нь тохируулгагүйгээр болзолгүй зураглалыг гүйцэтгэдэг.Энэ нь хөрвүүлэлт нь контекст ба хэлнээс хамааралгүй юм.
    ///
    /// [Unicode Standard] бүлэгт 4-р бүлэгт (Тэмдэгтийн шинж чанарууд) тохиолдлын зураглалыг ерөнхийд нь авч, 3-р бүлэгт (Conformance)-д кейсийг хөрвүүлэх анхдагч алгоритмыг авч үзсэн болно.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Давталтын хувьд:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ийг шууд ашиглах:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Хоёулаа тэнцүү байна:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` ашиглах:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Заримдаа үр дүн нь нэгээс олон тэмдэгттэй байдаг:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Том, жижиг хоёр тэмдэгтгүй тэмдэгтүүд өөрсдөө хувирдаг.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Энэ `char`-ийн том үсгийн зургийг нэг эсвэл хэд хэдэн хэлбэрээр гаргаж өгдөг давталтыг буцаана
    /// `char`s.
    ///
    /// Хэрэв энэ `char` нь том үсгийн зураглалгүй бол давталт нь ижил `char` гаргадаг.
    ///
    /// Хэрэв энэ `char` нь [Unicode Character Database][ucd] [`UnicodeData.txt`]-ийн өгсөн том үсгийн зураглалтай бол давталт нь `char`-ийг өгдөг.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Хэрэв энэ `char` нь онцгой анхаарал хандуулах шаардлагатай бол (жишээ нь олон ``char`s) давталт нь [`SpecialCasing.txt`]-ийн өгсөн `char` (ууд)-ийг гаргадаг.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Энэ ажиллагаа нь тохируулгагүйгээр болзолгүй зураглалыг гүйцэтгэдэг.Энэ нь хөрвүүлэлт нь контекст ба хэлнээс хамааралгүй юм.
    ///
    /// [Unicode Standard] бүлэгт 4-р бүлэгт (Тэмдэгтийн шинж чанарууд) тохиолдлын зураглалыг ерөнхийд нь авч, 3-р бүлэгт (Conformance)-д кейсийг хөрвүүлэх анхдагч алгоритмыг авч үзсэн болно.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Давталтын хувьд:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ийг шууд ашиглах:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Хоёулаа тэнцүү байна:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` ашиглах:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Заримдаа үр дүн нь нэгээс олон тэмдэгттэй байдаг:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Том, жижиг хоёр тэмдэгтгүй тэмдэгтүүд өөрсдөө хувирдаг.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Орон нутгийн тэмдэглэл
    ///
    /// Латин хэлээр 'i'-тэй дүйцэхүйц утгыг Турк хэл дээр хоёр хэлбэрийн оронд таван хэлбэртэй байна.
    ///
    /// * 'Dotless': I/ı, заримдаа ï гэж бичдэг
    /// * 'Dotted': I/i
    ///
    /// Жижиг цэгтэй 'i' нь Латинтай адилхан болохыг анхаарна уу.Тиймээс:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Энд `upper_i`-ийн утга нь текстийн хэл дээр тулгуурладаг: хэрэв бид `en-US`-т байгаа бол `"I"`, харин `tr_TR`-т байгаа бол `"İ"` байх ёстой.
    /// `to_uppercase()` үүнийг тооцдоггүй тул дараахь зүйлийг хийх болно.
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// хэлээр ярьдаг.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Энэ утга нь ASCII хязгаарт байгаа эсэхийг шалгана.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Утга хэмжээг ASCII том үсэгтэй дүйцүүлэн хуулбарлана.
    ///
    /// 'a'-ээс 'z' хүртэлх ASCII үсгийг 'A'-'Z' гэж буулгасан боловч ASCII бус үсэг өөрчлөгдөөгүй болно.
    ///
    /// Байршлын утгыг томоор харуулахын тулд [`make_ascii_uppercase()`] ашиглана уу.
    ///
    /// ASCII бус тэмдэгтүүдээс гадна ASCII тэмдэгтүүдийг томоор бичихийн тулд [`to_uppercase()`] ашиглана уу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Утга хэмжээг ASCII жижиг үсэгтэй дүйцүүлэн хуулбарлана.
    ///
    /// 'A'-ээс 'Z' хүртэлх ASCII үсгийг 'a'-'z' гэж буулгасан боловч ASCII бус үсэг өөрчлөгдөөгүй болно.
    ///
    /// Орон дахь утгыг багасгахын тулд [`make_ascii_lowercase()`] ашиглана уу.
    ///
    /// ASCII бус тэмдэгтүүдээс гадна ASCII тэмдэгтүүдийг багасгахын тулд [`to_lowercase()`] ашиглана уу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Хоёр утга нь ASCII-ийн тохиолдол-мэдрэмжгүй таарч байгаа эсэхийг шалгана.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)`-тэй тэнцүү.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Энэ төрлийг оронд нь том хэмжээтэй ASCII том үсэг болгон хөрвүүлдэг.
    ///
    /// 'a'-ээс 'z' хүртэлх ASCII үсгийг 'A'-'Z' гэж буулгасан боловч ASCII бус үсэг өөрчлөгдөөгүй болно.
    ///
    /// Одоо байгаа утгыг өөрчлөхгүйгээр шинэ дээд үсгийг буцаахын тулд [`to_ascii_uppercase()`] ашиглана уу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Энэ төрлийг оронд нь том хэмжээтэй ASCII жижиг үсгээр хөрвүүлдэг.
    ///
    /// 'A'-ээс 'Z' хүртэлх ASCII үсгийг 'a'-'z' гэж буулгасан боловч ASCII бус үсэг өөрчлөгдөөгүй болно.
    ///
    /// Одоо байгаа утгыг өөрчлөхгүйгээр шинэ жижиг утгыг буцаахын тулд [`to_ascii_lowercase()`] ашиглана уу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Энэ утга нь ASCII цагаан толгойн тэмдэгт эсэхийг шалгана:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', эсвэл
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Энэ утга нь ASCII том үсгийн тэмдэгт мөн эсэхийг шалгана:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Энэ утга нь ASCII жижиг үсгийн тэмдэгт мөн эсэхийг шалгана:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Энэ утга нь ASCII үсэг, тоон тэмдэгт эсэхийг шалгана:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', эсвэл
    /// - U + 0061 'a' ..=U + 007A 'z', эсвэл
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Энэ утга нь ASCII аравтын оронтой эсэхийг шалгана:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Энэ утга нь ASCII арван зургаатын оронтой эсэхийг шалгана:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', эсвэл
    /// - U + 0041 'A' ..=U + 0046 'F', эсвэл
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Энэ утга нь ASCII цэг таслалын тэмдэгт эсэхийг шалгана:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, эсвэл
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, эсвэл
    /// - U + 005B ..=U + 0060 `"[\] ^ _``, эсвэл
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Энэ утга нь ASCII график тэмдэгт эсэхийг шалгана:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Энэ утга нь ASCII хоосон зайн тэмдэгт эсэхийг шалгана:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED буюу U + 000D ТЭЭВЭР БУЦАХ.
    ///
    /// Rust нь WhatWG Infra Standard-ийн [definition of ASCII whitespace][infra-aw]-ийг ашигладаг.Өргөн хэрэглээний өөр хэд хэдэн тодорхойлолт байдаг.
    /// Жишээлбэл, [the POSIX locale][pct] нь U + 000B VERTICAL TAB болон дээр дурдсан бүх тэмдэгтүүдийг агуулдаг боловч яг ижил үзүүлэлтээс-[Bourne shell дахь "field splitting"-ийн анхдагч дүрэм][bfs] нь *зөвхөн* SPACE, HORIZONTAL TAB ба LINE FEED нь хоосон орон зай.
    ///
    ///
    /// Хэрэв та одоо байгаа файлын форматыг боловсруулах програм бичиж байгаа бол энэ функцийг ашиглахаасаа өмнө тухайн орон зайн хоосон зайг тодорхойлсон тодорхойлолтыг шалгаарай.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Утга нь ASCII хяналтын тэмдэгт мөн эсэхийг шалгана:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, эсвэл U + 007F DELETE.
    /// Ихэнх ASCII хоосон зайны тэмдэгтүүд нь хяналтын тэмдэгтүүд байдаг бол SPACE тийм биш гэдгийг анхаарна уу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Түүхий u32 утгыг өгөгдсөн байт буферт UTF-8 гэж кодлоод дараа нь кодчилогдсон тэмдэгт агуулсан буферын дэд хэсгийг буцаана.
///
///
/// `char::encode_utf8`-ээс ялгаатай нь энэ арга нь орлуулагч муж дахь код цэгүүдийг зохицуулдаг.
/// (Орлуулагч мужид `char` үүсгэх нь UB.) Үр дүн нь [generalized UTF-8] хүчинтэй боловч UTF-8 хүчин төгөлдөр бус байна.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Хэрэв буфер нь хангалттай том биш бол Panics.
/// Дөрвөн урттай буфер нь ямар ч `char`-ийг кодлоход хангалттай.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Түүхий u32 утгыг UTF-16 гэж заасан `u16` буферт кодлоод дараа нь кодчилогдсон тэмдэгт агуулсан буферын дэд хэсгийг буцаана.
///
///
/// `char::encode_utf16`-ээс ялгаатай нь энэ арга нь орлуулагч муж дахь код цэгүүдийг зохицуулдаг.
/// (Орлуулагч мужид `char` үүсгэх нь UB юм.)
///
/// # Panics
///
/// Хэрэв буфер нь хангалттай том биш бол Panics.
/// 2-р урттай буфер нь ямар ч `char`-ийг кодлоход хангалттай.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // АЮУЛГҮЙ БАЙДАЛ: гар тус бүр нь бичихэд хангалттай байгаа эсэхийг шалгана
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP унаж байна
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Нэмэлт онгоцууд орлон тоглогч болгон хуваадаг.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}