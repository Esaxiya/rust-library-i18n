#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Залгагчийн хувилбараас хамааран `$crate::panic::panic_2015` эсвэл `$crate::panic::panic_2021` болж өргөждөг.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Хоёр илэрхийлэл нь хоорондоо тэнцүү гэдгийг баталж байна ([`PartialEq`] ашиглан).
///
/// panic дээр энэ макро нь илэрхийлэлүүдийн утгыг дибаг хийх дүрсээр хэвлэх болно.
///
///
/// [`assert!`]-ийн нэгэн адил энэхүү макро нь хоёр дахь хэлбэртэй бөгөөд захиалгат panic мессежийг өгөх боломжтой.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Доорх reborrows нь санаатайгаар хийгдсэн байдаг.
                    // Тэдгээргүйгээр, зээлийн хувьд стекийн үүрийг утгыг харьцуулахаас өмнө эхлүүлж, улмаар мэдэгдэхүйц удааширахад хүргэдэг.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Доорх reborrows нь санаатайгаар хийгдсэн байдаг.
                    // Тэдгээргүйгээр, зээлийн хувьд стекийн үүрийг утгыг харьцуулахаас өмнө эхлүүлж, улмаар мэдэгдэхүйц удааширахад хүргэдэг.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Хоёр илэрхийлэл хоорондоо тэнцүү биш гэдгийг баталж байна ([`PartialEq`] ашиглан).
///
/// panic дээр энэ макро нь илэрхийлэлүүдийн утгыг дибаг хийх дүрсээр хэвлэх болно.
///
///
/// [`assert!`]-ийн нэгэн адил энэхүү макро нь хоёр дахь хэлбэртэй бөгөөд захиалгат panic мессежийг өгөх боломжтой.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Доорх reborrows нь санаатайгаар хийгдсэн байдаг.
                    // Тэдгээргүйгээр, зээлийн хувьд стекийн үүрийг утгыг харьцуулахаас өмнө эхлүүлж, улмаар мэдэгдэхүйц удааширахад хүргэдэг.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Доорх reborrows нь санаатайгаар хийгдсэн байдаг.
                    // Тэдгээргүйгээр, зээлийн хувьд стекийн үүрийг утгыг харьцуулахаас өмнө эхлүүлж, улмаар мэдэгдэхүйц удааширахад хүргэдэг.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Булийн илэрхийлэл нь ажиллаж байх үед `true` болохыг баталж байна.
///
/// Хэрэв өгөгдсөн илэрхийлэлийг ажиллуулах явцад `true` болгож үнэлэх боломжгүй бол энэ нь [`panic!`] макроыг ажиллуулах болно.
///
/// [`assert!`]-ийн нэгэн адил энэхүү макро нь хоёр дахь хувилбартай бөгөөд захиалгат panic мессежийг өгөх боломжтой.
///
/// # Uses
///
/// [`assert!`]-ээс ялгаатай нь `debug_assert!` мэдэгдэл нь анхдагчаар зөвхөн оновчтой бус бүтцэд идэвхждэг.
/// Оновчтой бүтэц нь `-C debug-assertions`-ийг хөрвүүлэгч рүү дамжуулахаас бусад тохиолдолд `debug_assert!` мэдэгдлийг гүйцэтгэхгүй.
/// Энэ нь `debug_assert!`-ийг хувилбарын бүтцэд оруулахад хэтэрхий үнэтэй байдаг боловч боловсруулалтын явцад ашиг тустай чекүүдэд ашиг тустай болгодог.
/// `debug_assert!`-ийн өргөтгөлийн үр дүнг үргэлж шалгаж байдаг.
///
/// Хяналтгүй нотолгоо нь нийцгүй төлөвт байгаа програмыг үргэлжлүүлэн ажиллуулах боломжийг олгодог бөгөөд энэ нь гэнэтийн үр дагаварт хүргэж болзошгүй боловч энэ нь зөвхөн аюулгүй кодонд л тохиолддог бол аюулгүй байдлыг хангаж чадахгүй.
///
/// Баталгаажуулалтын гүйцэтгэлийн өртөг нь ерөнхийдөө хэмжигдэхүйц биш юм.
/// Тиймээс [`assert!`]-ийг `debug_assert!`-ээр солих нь зөвхөн нарийн профайл хийсний дараа, хамгийн чухал нь зөвхөн аюулгүй кодоор дэмжигдэнэ!
///
/// # Examples
///
/// ```
/// // эдгээр баталгааны panic мессеж нь өгөгдсөн илэрхийллийн мөрийн утга юм.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // маш энгийн функц
/// debug_assert!(some_expensive_computation());
///
/// // захиалгат мессежээр баталгаажуулах
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Хоёр илэрхийлэл хоорондоо тэнцүү гэдгийг баталж байна.
///
/// panic дээр энэ макро нь илэрхийлэлүүдийн утгыг дибаг хийх дүрсээр хэвлэх болно.
///
/// [`assert_eq!`]-ээс ялгаатай нь `debug_assert_eq!` мэдэгдэл нь анхдагчаар зөвхөн оновчтой бус бүтцэд идэвхждэг.
/// Оновчтой бүтэц нь `-C debug-assertions`-ийг хөрвүүлэгч рүү дамжуулахаас бусад тохиолдолд `debug_assert_eq!` мэдэгдлийг гүйцэтгэхгүй.
/// Энэ нь `debug_assert_eq!`-ийг хувилбарын бүтцэд оруулахад хэтэрхий үнэтэй байдаг боловч боловсруулалтын явцад ашиг тустай чекүүдэд ашиг тустай болгодог.
///
/// `debug_assert_eq!`-ийн өргөтгөлийн үр дүнг үргэлж шалгаж байдаг.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Хоёр илэрхийлэл нь хоорондоо тэнцүү биш гэдгийг баталж байна.
///
/// panic дээр энэ макро нь илэрхийлэлүүдийн утгыг дибаг хийх дүрсээр хэвлэх болно.
///
/// [`assert_ne!`]-ээс ялгаатай нь `debug_assert_ne!` мэдэгдэл нь анхдагчаар зөвхөн оновчтой бус бүтцэд идэвхждэг.
/// Оновчтой бүтэц нь `-C debug-assertions`-ийг хөрвүүлэгч рүү дамжуулахаас бусад тохиолдолд `debug_assert_ne!` мэдэгдлийг гүйцэтгэхгүй.
/// Энэ нь `debug_assert_ne!`-ийг хувилбарын бүтцэд оруулахад хэтэрхий үнэтэй байдаг боловч боловсруулалтын явцад ашиг тустай чекүүдэд ашиг тустай болгодог.
///
/// `debug_assert_ne!`-ийн өргөтгөлийн үр дүнг үргэлж шалгаж байдаг.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Өгөгдсөн илэрхийлэл нь өгөгдсөн хэв маягтай тохирч байгаа эсэхийг буцаана.
///
/// `match` илэрхийлэлтэй адилаар загварыг `if` ба хэв маягт холбогдсон нэрсэд хандах хамгаалалтын илэрхийлэлээр дагаж мөрдөж болно.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Үр дүнг задлах эсвэл түүний алдааг дэлгэрүүлэх.
///
/// `try!`-ийг орлуулахын тулд `?` операторыг нэмж оруулсан бөгөөд оронд нь ашиглах хэрэгтэй.
/// Цаашилбал, `try` нь Rust 2018-д хадгалагдсан үг тул хэрэв та үүнийг ашиглах шаардлагатай бол [raw-identifier syntax][ris]-г ашиглах шаардлагатай болно. `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` өгөгдсөн [`Result`]-тэй таарч байна.`Ok` хувилбарын хувьд илэрхийлэл нь боосон утгын утгатай байна.
///
/// `Err` хувилбарын хувьд дотоод алдааг олж авдаг.Дараа нь `try!` нь `From` ашиглан хөрвүүлэлтийг хийдэг.
/// Энэ нь төрөлжсөн алдаа ба ерөнхий алдааны хооронд автоматаар хөрвүүлэх боломжийг олгодог.
/// Үүний дараа гарсан алдааг нэн даруй буцааж өгдөг.
///
/// Эрт буцаж ирдэг тул `try!`-ийг зөвхөн [`Result`] буцаах функцэд ашиглаж болно.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Алдааг хурдан буцааж өгөх арга
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Алдааг хурдан буцаах өмнөх арга
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Энэ нь:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Форматласан өгөгдлийг буфер дотор бичдэг.
///
/// Энэ макро нь 'writer', форматын мөр, нэмэлт өгөгдлүүдийн жагсаалтыг хүлээн авдаг.
/// Аргументуудыг заасан форматын мөрийн дагуу форматлаж, үр дүнг зохиогчид дамжуулна.
/// Зохиолч нь `write_fmt` аргаар ямар ч үнэ цэнэтэй байж болно;ерөнхийдөө энэ нь [`fmt::Write`] эсвэл [`io::Write`] trait-ийн аль нэгийг хэрэгжүүлснээс үүдэлтэй юм.
/// Макро нь `write_fmt` аргын буцаах бүх зүйлийг буцаадаг;ихэвчлэн [`fmt::Result`] эсвэл [`io::Result`].
///
/// Форматын мөр синтаксийн талаархи нэмэлт мэдээллийг [`std::fmt`]-ээс үзнэ үү.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Модуль нь `std::fmt::Write` ба `std::io::Write` хоёуланг нь импортлож, обьектууд хоёулаа хоёуланг нь хэрэгжүүлдэггүй тул аль алиныг нь хэрэгжүүлж буй объектууд дээр `write!` руу залгах боломжтой.
///
/// Гэсэн хэдий ч модуль нь traits шаардлага хангасан импортлох ёстой тул тэдний нэр зөрчилдөхгүй:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt ашигладаг
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt ашигладаг
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Энэхүү макро нь `no_std` тохиргоонд ашиглаж болно.
/// `no_std` тохиргоонд та бүрэлдэхүүн хэсгүүдийн хэрэгжилтийн дэлгэрэнгүй мэдээллийг хариуцна.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Форматлагдсан өгөгдлийг буфер дотор шинэ мөр хавсаргаж бичнэ үү.
///
/// Бүх платформ дээр шинэ мөр нь зөвхөн LINE FEED тэмдэгт (`\n`/`U+000A`) (нэмэлт CARRIAGE RETURN (`\r`/`U+000D`) байхгүй).
///
/// Дэлгэрэнгүй мэдээллийг [`write!`]-с үзнэ үү.Форматын мөрийн синтаксийн талаархи мэдээллийг [`std::fmt`]-ээс үзнэ үү.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Модуль нь `std::fmt::Write` ба `std::io::Write` хоёуланг нь импортлож, обьектууд хоёулаа хоёуланг нь хэрэгжүүлдэггүй тул аль алиныг нь хэрэгжүүлж буй объектууд дээр `write!` руу залгах боломжтой.
/// Гэсэн хэдий ч модуль нь traits шаардлага хангасан импортлох ёстой тул тэдний нэр зөрчилдөхгүй:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt ашигладаг
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt ашигладаг
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Хандалтгүй кодыг заана.
///
/// Энэ нь хөрвүүлэгч зарим кодыг ашиглах боломжгүй байгааг тогтоож чадахгүй байгаа үед энэ нь ашигтай байдаг.Жишээлбэл:
///
/// * Гараа хамгаалалтын нөхцлөөр тааруул.
/// * Динамикаар цуцалдаг гогцоо.
/// * Динамикаар цуцалдаг давталтууд.
///
/// Хэрэв кодыг олж авах боломжгүй гэсэн шийдвэр буруу болохыг нотолж байвал [`panic!`] програмаар шууд дуусгавар болно.
///
/// Энэ макрогийн аюулгүй түнш бол [`unreachable_unchecked`] функц бөгөөд кодонд хүрсэн тохиолдолд тодорхойгүй үйлдэл гаргах болно.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Энэ нь үргэлж [`panic!`] байх болно.
///
/// # Examples
///
/// Гараа тааруулах:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // тайлбар өгсөн бол эмхэтгэх алдаа
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3-ийн хамгийн ядуу хэрэгжүүлэлтүүдийн нэг
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" мессежээр сандрах замаар хэрэгжээгүй кодыг заана.
///
/// Энэ нь таны кодыг бичих боломжийг олгоно, хэрэв та trait загварыг бүтээж эсвэл хэрэгжүүлж байгаа бол ашиглахгүй байх хэрэгтэй.
///
/// `unimplemented!` ба [`todo!`]-ийн ялгаа нь `todo!` нь хожим нь функцийг хэрэгжүүлэх санааг илэрхийлж, мессеж нь "not yet implemented" бол `unimplemented!` нь ийм нэхэмжлэл гаргахгүй байх явдал юм.
/// Түүний зурвас нь "not implemented" юм.
/// Мөн зарим IDE нь "todo!"-г тэмдэглэнэ.
///
/// # Panics
///
/// Энэ нь үргэлж [`panic!`] байх болно, учир нь `unimplemented!` нь тогтмол, тодорхой мессеж бүхий `panic!`-ийн товчлол юм.
///
/// `panic!`-ийн нэгэн адил энэхүү макро нь өөрчлөн тохируулсан утгуудыг харуулах хоёрдахь хэлбэртэй байдаг.
///
/// # Examples
///
/// Бидэнд trait `Foo` байна гэж хэлье:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Бид 'MyStruct'-т зориулж `Foo`-ийг хэрэгжүүлэхийг хүсч байгаа боловч яагаад ч юм `bar()` функцийг хэрэгжүүлэх нь утга учиртай юм.
/// `baz()` `Foo`-ийг хэрэгжүүлэхэд `qux()`-ийг тодорхойлох шаардлагатай хэвээр байгаа боловч `unimplemented!`-ийг тэдгээрийн тодорхойлолтод ашиглаж кодыг хөрвүүлэх боломжийг олгоно.
///
/// Хэрэв хэрэгжүүлээгүй аргуудад хүрвэл бид хөтөлбөрөө зогсоохыг хүсч байна.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` нь `MyStruct` байх нь утгагүй тул энд бидэнд ямар ч логик байхгүй.
/////
///         // Энэ нь "thread 'main' panicked at 'not implemented'"-ийг харуулах болно.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Бид энд зарим нэг логик байна, Бид хэрэгжүүлээгүй мессеж нэмж болно!бидний орхигдуулсан байдлыг харуулах.
///         // Үүнийг харуулах болно: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Дуусгаагүй кодыг заана.
///
/// Хэрэв та эх загвар зохиож байгаа бөгөөд кодыг typecheck хийхийг хүсч байгаа бол энэ нь ашигтай байж болох юм.
///
/// [`unimplemented!`] ба `todo!`-ийн ялгаа нь `todo!` нь хожим нь функцийг хэрэгжүүлэх санааг илэрхийлж, мессеж нь "not yet implemented" бол `unimplemented!` нь ийм нэхэмжлэл гаргахгүй байх явдал юм.
/// Түүний зурвас нь "not implemented" юм.
/// Мөн зарим IDE нь "todo!"-г тэмдэглэнэ.
///
/// # Panics
///
/// Энэ нь үргэлж [`panic!`] байх болно.
///
/// # Examples
///
/// Зарим боловсруулагдаж байгаа кодын жишээг энд оруулав.Бидэнд trait `Foo` байна:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Бид `Foo`-ийг аль нэг төрлөөрөө хэрэгжүүлэхийг хүсч байгаа боловч зөвхөн `bar()` дээр ажиллахыг хүсч байна.Манай кодыг хөрвүүлэхийн тулд `baz()`-ийг хэрэгжүүлэх шаардлагатай тул `todo!`-г ашиглаж болно.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // хэрэгжилт энд явагдана
///     }
///
///     fn baz(&self) {
///         // baz()-ийг хэрэгжүүлэх талаар одоохондоо санаа зовох хэрэггүй
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // бид baz() ч ашиглахгүй байгаа тул зүгээр байна.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Суурилуулсан макросуудын тодорхойлолт.
///
/// Ихэнх макро шинж чанарууд (тогтвортой байдал, харагдах байдал гэх мэт)-ийг энд байгаа эх кодоос авсан бөгөөд өргөтгөлийн функцуудаас бусад нь макро оролтуудыг гаралт болгон хувиргадаг бөгөөд эдгээр функцуудыг хөрвүүлэгч өгдөг.
///
///
pub(crate) mod builtin {

    /// Таарах үед эмхэтгэл нь өгөгдсөн алдааны мэдэгдлийг бүтэлгүйтэхэд хүргэдэг.
    ///
    /// crate нь алдаатай нөхцөл байдлын талаар илүү сайн алдааны мэдэгдлийг хангахын тулд нөхцөлт эмхэтгэлийн стратеги ашигладаг тохиолдолд энэ макро ашиглах хэрэгтэй.
    ///
    /// Энэ бол [`panic!`]-ийн хөрвүүлэгчийн түвшний хэлбэр боловч *ажиллуулах* үед биш харин * хөрвүүлэх явцад алдаа гаргадаг.
    ///
    /// # Examples
    ///
    /// Ийм хоёр жишээ бол макро болон `#[cfg]` орчин юм.
    ///
    /// Хэрэв макро хүчингүй утгыг дамжуулсан бол илүү сайн хөрвүүлэгчийн алдааг гаргах.
    /// Эцсийн branch байхгүй бол хөрвүүлэгч алдаа гаргасаар байсан боловч алдааны мэдэгдэлд хүчин төгөлдөр хоёр утгын талаар дурдаагүй болно.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Хэрэв хэд хэдэн функцын аль нэг нь байхгүй бол хөрвүүлэгчийн алдааг гаргах.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Бусад мөр хэлбэржүүлэх макросуудын параметрүүдийг байгуулдаг.
    ///
    /// Энэхүү макро нь нэмэлт өгөгдсөн нэмэлт өгөгдөл тус бүрт `{}` агуулсан хэлбэржүүлэх мөрийг ашиглана.
    /// `format_args!` гаралтыг мөр болгон тайлбарлаж болох тул нэмэлт параметрүүдийг бэлтгэж аргументуудыг нэг төрөлд каноникжуулна.
    /// [`Display`] trait-ийг хэрэгжүүлж буй аливаа утгыг `format_args!` руу дамжуулж болох бөгөөд [`Debug`] хэрэгжилтийг форматлах мөр доторх `{:?}` руу дамжуулж болно.
    ///
    ///
    /// Энэхүү макро нь [`fmt::Arguments`] төрлийн утга үүсгэдэг.Энэ утгыг ашигтай дахин чиглүүлэлт хийхийн тулд [`std::fmt`] доторх макро руу дамжуулж болно.
    /// Бусад бүх форматлах макро (["формат!"], [`write!`], [`println!`], гэх мэт) энэ замаар дамжуулагдана.
    /// `format_args!`, түүний гаралтай макроос ялгаатай нь овоо хуваарилахаас зайлсхийдэг.
    ///
    /// `format_args!`-ийн буцааж өгдөг [`fmt::Arguments`] утгыг `Debug` ба `Display` контекстэд доор харуулсны дагуу ашиглаж болно.
    /// Жишээ нь `Debug` ба `Display` форматыг `format_args!` дахь интерполяцийн форматтай ижил форматтай болохыг харуулж байна.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Дэлгэрэнгүй мэдээллийг [`std::fmt`] дээрх баримт бичгээс үзнэ үү.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args`-тэй адил боловч эцэст нь шинэ мөр нэмж оруулав.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Хөрвүүлэх үед орчны хувьсагчийг шалгана.
    ///
    /// Энэхүү макро нь хөрвүүлэх үед нэрлэгдсэн орчны хувьсагчийн утга хүртэл өргөжиж, `&'static str` төрлийн илэрхийлэлийг гаргах болно.
    ///
    ///
    /// Хэрэв орчны хувьсагчийг тодорхойлоогүй бол хөрвүүлэлтийн алдаа гарах болно.
    /// Хөрвүүлэлтийн алдаа гаргахгүйн тулд оронд нь [`option_env!`] макро ашиглана уу.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Та мөрийг хоёр дахь параметр болгон дамжуулж алдааны мэдэгдлийг өөрчилж болно:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Хэрэв `documentation` орчны хувьсагчийг тодорхойлоогүй бол та дараах алдааг олох болно.
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Сонголтоор хөрвүүлэх үед орчны хувьсагчийг шалгана.
    ///
    /// Хэрэв нэрлэгдсэн орчны хувьсагч хөрвүүлэх үед байгаа бол энэ нь хүрээлэн буй орчны хувьсагчийн `Some` утга болох `Option<&'static str>` төрлийн илэрхийлэл болж өргөжинө.
    /// Хэрэв орчны хувьсагч байхгүй бол энэ нь `None` болж өргөжинө.
    /// Энэ төрлийн талаархи дэлгэрэнгүй мэдээллийг [`Option<T>`][Option]-ээс үзнэ үү.
    ///
    /// Энэхүү макро ашиглах үед орчны хувьсагч байгаа эсэхээс үл хамааран хөрвүүлэх хугацааны алдаа хэзээ ч гарахгүй.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Тодорхойлогчдыг нэг танигч болгон нэгтгэдэг.
    ///
    /// Энэ макро нь таслалаар тусгаарлагдсан хэдэн ч тодорхойлогчийг авч, бүгдийг нь нэгтгэж, шинэ танигч болох илэрхийлэлийг гаргана.
    /// Эрүүл ахуй нь энэхүү макро нь орон нутгийн хувьсагчдыг багтааж чадахгүй байх нөхцлийг бүрдүүлж байгааг анхаарна уу.
    /// Түүнчлэн, ерөнхий дүрмээр макро нь зөвхөн зүйл, мэдэгдэл эсвэл илэрхийллийн байрлалд л зөвшөөрөгддөг.
    /// Энэ нь одоо байгаа хувьсагч, функц эсвэл модулиудыг дурдахдаа энэ макрог ашиглаж болох боловч та түүнтэй хамт шинээр тодорхойлох боломжгүй гэсэн үг юм.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (шинэ, хөгжилтэй, нэр) { }//ийм байдлаар ашиглах боломжгүй юм!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Бичиг үсгийг статик мөрний зүсмэл болгон нэгтгэдэг.
    ///
    /// Энэ макро нь бүхэл бүтэн үсгийг зүүнээс баруун тийш холбосон илэрхийлсэн `&'static str` төрлийн илэрхийлэлийг таслалаар тусгаарласан хэдэн тооны үсгийг авах болно.
    ///
    ///
    /// Бүхэл ба хөвөгч цэгийн үсгийг нэгтгэх зорилгоор чангална.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Дуудсан мөрийн дугаар руу өргөжүүлнэ.
    ///
    /// [`column!`] ба [`file!`]-ийн тусламжтайгаар эдгээр макро нь хөгжүүлэгчдэд эх үүсвэр доторх байршлын талаар дибаг хийх мэдээллийг өгдөг.
    ///
    /// Өргөтгөсөн илэрхийлэл нь `u32` төрөлтэй бөгөөд 1-д суурилсан тул файл бүрийн эхний мөр 1, хоёр дахь утга 2 болж үнэлэгдэнэ.
    /// Энэ нь нийтлэг хөрвүүлэгч эсвэл алдартай редакторуудын алдааны мэдэгдлүүдтэй нийцдэг.
    /// Буцаж ирсэн мөр нь *заавал*`line!` дуудлагын мөр биш харин `line!` макроны дуудлагад хүргэх анхны макро дуудлага юм.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Дуудсан баганы дугаар руу өргөжүүлнэ.
    ///
    /// [`line!`] ба [`file!`]-ийн тусламжтайгаар эдгээр макро нь хөгжүүлэгчдэд эх үүсвэр доторх байршлын талаар дибаг хийх мэдээллийг өгдөг.
    ///
    /// Өргөтгөсөн илэрхийлэл нь `u32` хэлбэртэй бөгөөд 1-д суурилсан тул мөр бүрийн эхний багана нь 1, хоёр дахь нь 2 гэх мэтээр үнэлэгддэг.
    /// Энэ нь нийтлэг хөрвүүлэгч эсвэл алдартай редакторуудын алдааны мэдэгдлүүдтэй нийцдэг.
    /// Буцаасан багана нь *заавал*`column!` дуудлагын мөр биш, харин `column!` макроны дуудлагад хүргэх эхний макро дуудлага юм.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Дуудсан файлын нэрийг өргөжүүлнэ.
    ///
    /// [`line!`] ба [`column!`]-ийн тусламжтайгаар эдгээр макро нь хөгжүүлэгчдэд эх үүсвэр доторх байршлын талаар дибаг хийх мэдээллийг өгдөг.
    ///
    /// Өргөтгөсөн илэрхийлэл нь `&'static str` хэлбэртэй бөгөөд буцаагдсан файл нь `file!` макро өөрөө дуудлага биш харин `file!` макроны дуудлагад хүргэх анхны макро дуудлага юм.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Түүний аргументыг мөрдөнө.
    ///
    /// Энэ макро нь `&'static str` төрлийн илэрхийлэлийг гаргах бөгөөд энэ нь макро руу дамжуулсан бүх tokens-ийн мөр юм.
    /// Макро дуудлагын синтакс дээр хязгаарлалт тавьдаггүй.
    ///
    /// tokens оролтын өргөтгөсөн үр дүн future дээр өөрчлөгдөж болохыг анхаарна уу.Хэрэв та гаралтад найдаж байгаа бол болгоомжтой байх хэрэгтэй.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// UTF-8 кодчилогдсон файлыг мөр болгон оруулсан болно.
    ///
    /// Файл нь одоогийн файлтай харьцуулахад байрладаг (модулиуд хэрхэн олддогтой адил).
    /// Өгөгдсөн замыг хөрвүүлэх үед платформд зориулагдсан байдлаар тайлбарладаг.
    /// Жишээлбэл, `\` арын налууг агуулсан Windows зам бүхий дуудлага нь Unix дээр зөв хөрвүүлэгдэхгүй байх болно.
    ///
    ///
    /// Энэ макро нь файлын агуулга болох `&'static str` төрлийн илэрхийлэлийг өгөх болно.
    ///
    /// # Examples
    ///
    /// Нэг директор дотор дараахь агуулгатай хоёр файл байгаа гэж үзье.
    ///
    /// 'spanish.in' файл:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' файл:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs'-ийг эмхэтгээд үр дүнд гарсан хоёртын хувилбарыг ажиллуулснаар "adiós" хэвлэгдэх болно.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Файлыг байтын массивын лавлагаа болгон оруулсан болно.
    ///
    /// Файл нь одоогийн файлтай харьцуулахад байрладаг (модулиуд хэрхэн олддогтой адил).
    /// Өгөгдсөн замыг хөрвүүлэх үед платформд зориулагдсан байдлаар тайлбарладаг.
    /// Жишээлбэл, `\` арын налууг агуулсан Windows зам бүхий дуудлага нь Unix дээр зөв хөрвүүлэгдэхгүй байх болно.
    ///
    ///
    /// Энэ макро нь файлын агуулга болох `&'static [u8; N]` төрлийн илэрхийлэлийг өгөх болно.
    ///
    /// # Examples
    ///
    /// Нэг директор дотор дараахь агуулгатай хоёр файл байгаа гэж үзье.
    ///
    /// 'spanish.in' файл:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' файл:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs'-ийг эмхэтгээд үр дүнд гарсан хоёртын хувилбарыг ажиллуулснаар "adiós" хэвлэгдэх болно.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Одоогийн модулийн замыг харуулсан мөрөнд өргөжүүлнэ.
    ///
    /// Одоогийн модулийн замыг crate root руу буцах модулиудын шатлал гэж ойлгож болно.
    /// Буцаж ирсэн замын эхний бүрэлдэхүүн хэсэг нь одоо эмхэтгэгдэж байгаа crate-ийн нэр юм.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Энэ тохиргооны тугуудын логик хослолыг хөрвүүлэх үед үнэлдэг.
    ///
    /// `#[cfg]` шинж чанараас гадна энэ макро нь тохиргооны тугуудын логик илэрхийлэлийг үнэлэх боломжийг олгодог.
    /// Энэ нь цөөн тооны хуулбарлахад хүргэдэг.
    ///
    /// Энэ макро өгөгдсөн синтакс нь [`cfg`] атрибуттай ижил синтакс юм.
    ///
    /// `cfg!`, `#[cfg]`-ээс ялгаатай нь ямар ч кодыг устгахгүй бөгөөд зөвхөн үнэн эсвэл худал гэж үнэлдэг.
    /// Жишээлбэл, `cfg!`-ийг нөхцөл байдалд ашиглахад if/else илэрхийлэл дэх бүх блок хүчинтэй байх ёстой.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Файлыг агуулгын дагуу илэрхийлэл эсвэл зүйл болгон задалдаг.
    ///
    /// Файл нь одоогийн файлтай харьцуулахад байрладаг (модулиуд хэрхэн олддогтой адил).Өгөгдсөн замыг хөрвүүлэх үед платформд зориулагдсан байдлаар тайлбарладаг.
    /// Жишээлбэл, `\` арын налууг агуулсан Windows зам бүхий дуудлага нь Unix дээр зөв хөрвүүлэгдэхгүй байх болно.
    ///
    /// Энэ макрог ашиглах нь ихэвчлэн буруу санаа байдаг, учир нь хэрэв файлыг илэрхийлэл болгон задалж үзвэл орчны кодонд эрүүл ахуйн шаардлага хангахгүй байдлаар байрлуулах болно.
    /// Энэ нь хувьсагч эсвэл функц нь одоогийн файлд ижил нэртэй хувьсагч эсвэл функц байгаа тохиолдолд файлын хүлээгдэж байснаас өөр байж болзошгүй юм.
    ///
    ///
    /// # Examples
    ///
    /// Нэг директор дотор дараахь агуулгатай хоёр файл байгаа гэж үзье.
    ///
    /// 'monkeys.in' файл:
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 'main.rs' файл:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs'-ийг эмхэтгээд үр дүнд гарсан хоёртын хувилбарыг ажиллуулснаар "🙈🙊🙉🙈🙊🙉" хэвлэгдэх болно.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Булийн илэрхийлэл нь ажиллаж байх үед `true` болохыг баталж байна.
    ///
    /// Хэрэв өгөгдсөн илэрхийлэлийг ажиллуулах явцад `true` болгож үнэлэх боломжгүй бол энэ нь [`panic!`] макроыг ажиллуулах болно.
    ///
    /// # Uses
    ///
    /// Баталгаажуулалтыг дибаг болон хувилбарын аль алинд нь үргэлж шалгаж байдаг тул идэвхгүй болгох боломжгүй.
    /// Анхдагчаар хувилбар бүтээхэд идэвхжүүлээгүй баталгааг [`debug_assert!`]-с үзнэ үү.
    ///
    /// Аюулгүй код нь `assert!`-т итгэж болох бөгөөд хэрэв зөрчсөн бол аюулгүй байдалд хүргэж болзошгүй өөр хувилбаруудыг хэрэгжүүлдэг.
    ///
    /// `assert!`-ийн бусад хэрэглээний тохиолдлууд нь аюулгүй байдлын кодод ажиллах хугацааг өөрчлөхгүй байхыг туршиж, мөрдөх явдал юм (зөрчил нь аюулгүй байдалд хүргэж чадахгүй).
    ///
    ///
    /// # Захиалгат мессеж
    ///
    /// Энэхүү макро нь хоёрдахь хэлбэртэй бөгөөд өөрчлөн тохируулсан panic мессежийг форматлах аргументгүйгээр эсвэл нэмэлт өгөгдлөөр хангах боломжтой.
    /// Энэ маягтын синтаксыг [`std::fmt`]-с харна уу.
    /// Форматын аргумент болгон ашигласан илэрхийллийг батлах нь бүтэлгүйтсэн тохиолдолд л үнэлнэ.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // эдгээр баталгааны panic мессеж нь өгөгдсөн илэрхийллийн мөрийн утга юм.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // маш энгийн функц
    ///
    /// assert!(some_computation());
    ///
    /// // захиалгат мессежээр баталгаажуулах
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Шугаман угсралт.
    ///
    /// Ашиглалтын талаар [unstable book]-ийг уншина уу.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM загварын дотуур угсралт.
    ///
    /// Ашиглалтын талаар [unstable book]-ийг уншина уу.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Модулийн түвшний шугаман угсралт.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Хэвлэмэл нь tokens-ийг стандарт гаралтад дамжуулсан.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Бусад макро дибаг хийхэд ашигладаг мөрдөх ажиллагааг идэвхжүүлдэг эсвэл идэвхгүй болгодог.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Үүсмэл макро хэрэглэхэд ашигладаг шинж чанарын макро.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Функцэд ашигласан атрибутын макро нь нэгжийн тест болж хувирдаг.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Функцэд ашигласан атрибутын макро нь жишиг тест болж хувирсан.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` ба `#[bench]` макроны хэрэгжилтийн нарийвчилсан мэдээлэл.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Аттрибут макро нь статик дээр дэлхийн хуваарилагчаар бүртгүүлэх зорилгоор ашиглагдав.
    ///
    /// Мөн [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html)-г үзнэ үү.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Хэрэв дамжуулсан замд нэвтрэх боломжтой бол хэрэглэсэн зүйлийг хадгалж, өөрөөр устгана.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Хэрэглэсэн кодын хэсэг дэх бүх `#[cfg]` ба `#[cfg_attr]` шинж чанаруудыг өргөжүүлнэ.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` хөрвүүлэгчийн тогтворгүй хэрэгжилтийн дэлгэрэнгүй мэдээллийг бүү ашиглаарай.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` хөрвүүлэгчийн тогтворгүй хэрэгжилтийн дэлгэрэнгүй мэдээллийг бүү ашиглаарай.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}