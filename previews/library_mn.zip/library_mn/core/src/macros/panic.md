Одоогийн утсыг Panics.

Энэ нь програмыг нэн даруй цуцалж, програмыг дуудсан хүнд хариу өгөх боломжийг олгоно.
`panic!` програм нь сэргээгдэх боломжгүй байдалд хүрэхэд ашиглагдах ёстой.

Энэхүү макро нь жишээ код болон туршилтанд нөхцөлийг баталгаажуулах төгс арга юм.
`panic!` нь [`Option`][ounwrap] ба [`Result`][runwrap] enums хоёулангийнх нь `unwrap` аргатай нягт уялдаатай байдаг.
Хоёр хэрэгжүүлэлт нь [`None`] эсвэл [`Err`] хувилбаруудад тохируулагдсан үед `panic!` гэж нэрлэдэг.

`panic!()`-ийг ашиглахдаа [`format!`] синтакс ашиглан бүтээсэн мөрийн ачааллыг зааж өгч болно.
Энэхүү ачааллыг panic-ийг дуудлага хийж буй Rust утас руу оруулахад ашигладаг бөгөөд ингэснээр утсыг бүхэлд нь panic болгоно.

Анхдагч `std` hook-ийн зан байдал, өөрөөр хэлбэл
panic дуудагдсаны дараа шууд ажилладаг код бол `stderr` руу мессежийн ачааллыг `panic!()` дуудлагын file/line/column мэдээллийн хамт хэвлэх явдал юм.

Та [`std::panic::set_hook()`] ашиглан panic hook-ийг хүчингүй болгож болно.
hook дотор panic-ийг ердийн `panic!()` дуудлагад зориулж `&str` эсвэл `String` агуулсан `&dyn Any + Send` хэлбэрээр хандаж болно.
Өөр төрлийн утга бүхий panic-д [`panic_any`] ашиглаж болно.

[`Result`] enum нь `panic!` макро ашиглахаас илүүтэй алдааг арилгах хамгийн сайн шийдэл юм.
Энэ макро нь гадны эх үүсвэр гэх мэт буруу утгыг ашиглахаас зайлсхийхийн тулд ашиглагдах ёстой.
Алдаатай харьцах талаархи дэлгэрэнгүй мэдээллийг [book] дээрээс олж болно.

Хөрвүүлэх явцад гарсан алдаануудыг макро [`compile_error!`]-ээс үзнэ үү.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Одоогийн хэрэгжилт

Хэрэв гол утас panics бол энэ нь таны бүх холболтыг зогсоох бөгөөд `101` кодоор програмаа дуусгах болно.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





