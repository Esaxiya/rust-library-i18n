use crate::future::Future;

/// `Future` руу хөрвүүлэх.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future нь дуусах үед үйлдвэрлэх гарц.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Үүнийг бид ямар future болгож байна вэ?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Утгаас future үүсгэдэг.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}