#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` нь даалгаврын гүйцэтгэгчийн хэрэгжүүлэгчид [`Waker`] үүсгэх боломжийг олгоно.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Энэ нь өгөгдлийн заагч ба `RawWaker`-ийн үйлдлийг өөрчилдөг [virtual function pointer table (vtable)][vtable]-ээс бүрдэнэ.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Гүйцэтгэгчийн шаардсаны дагуу дурын өгөгдлийг хадгалахад ашиглаж болох өгөгдлийн заагч.
    /// Энэ нь жишээ нь байж болно
    /// даалгавартай холбоотой `Arc` руу төрөл арилгасан заагч.
    /// Энэ талбарын утга нь vtable-ийн хэсэг болох бүх функцуудад эхний параметр болж дамждаг.
    ///
    data: *const (),
    /// Энэ сэрүүн хүний үйлдлийг өөрчилдөг виртуал функцын заагч хүснэгт.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Өгөгдсөн `data` заагч болон `vtable`-ээс шинэ `RawWaker` үүсгэдэг.
    ///
    /// `data` заагчийг гүйцэтгэгчийн шаардсаны дагуу дурын өгөгдлийг хадгалахад ашиглаж болно.Энэ нь жишээ нь байж болно
    /// даалгавартай холбоотой `Arc` руу төрөл арилгасан заагч.
    /// Энэ заагчийн утга нь `vtable`-ийн хэсэг болох бүх функцуудад эхний параметр болж дамждаг.
    ///
    /// `vtable` нь `RawWaker`-ээс бүтсэн `Waker`-ийн үйлдлийг өөрчилдөг.
    /// `Waker` дээрх үйлдэл бүрийн хувьд үндсэн `RawWaker`-ийн `vtable` дахь холбогдох функц дуудагдах болно.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// [`RawWaker`]-ийн үйлдлийг тодорхойлдог (vtable) виртуал функцийн заагч хүснэгт.
///
/// Vtable доторх бүх функцэд дамжуулсан заагч нь [`RawWaker`] объектын `data` заагч юм.
///
/// Энэхүү бүтцийн доторх функцууд нь [`RawWaker`] програмын дотор зөв баригдсан [`RawWaker`] объектын `data` заагч дээр дуудагдах зориулалттай юм.
/// Хадгалагдсан функцуудын аль нэгийг бусад `data` заагч ашиглан дуудах нь тодорхойгүй зан үйлийг үүсгэдэг.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Энэ функцийг [`RawWaker`]-ийг клончлох үед, жишээлбэл, [`RawWaker`]-ийг хадгалдаг [`Waker`]-ийг клончлох үед дуудах болно.
    ///
    /// Энэхүү функцийг хэрэгжүүлэх нь [`RawWaker`] болон холбогдох даалгаврын нэмэлт жишээнд шаардагдах бүх нөөцийг хадгалах ёстой.
    /// Үүссэн [`RawWaker`] дээр `wake` руу залгах нь анхны [`RawWaker`]-ээр сэрсэн байсан даалгаврыг сэрээх болно.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Энэ функцийг [`Waker`] дээр `wake` дуудагдах үед дуудах болно.
    /// Энэ [`RawWaker`]-тэй холбоотой даалгаврыг сэрээх ёстой.
    ///
    /// Энэ функцийг хэрэгжүүлэх нь [`RawWaker`]-ийн жишээ болон холбогдох даалгавартай холбоотой аливаа нөөцийг суллах ёстой.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Энэ функцийг [`Waker`] дээр `wake_by_ref` дуудагдах үед дуудах болно.
    /// Энэ [`RawWaker`]-тэй холбоотой даалгаврыг сэрээх ёстой.
    ///
    /// Энэ функц нь `wake`-тэй төстэй боловч өгөгдсөн заагчийг ашиглах ёсгүй.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Энэ функц нь [`RawWaker`] унах үед дуудагдана.
    ///
    /// Энэ функцийг хэрэгжүүлэх нь [`RawWaker`]-ийн жишээ болон холбогдох даалгавартай холбоотой аливаа нөөцийг суллах ёстой.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Өгөгдсөн `clone`, `wake`, `wake_by_ref`, `drop` функцуудаас шинэ `RawWakerVTable` үүсгэдэг.
    ///
    /// # `clone`
    ///
    /// Энэ функцийг [`RawWaker`]-ийг клончлох үед, жишээлбэл, [`RawWaker`]-ийг хадгалдаг [`Waker`]-ийг клончлох үед дуудах болно.
    ///
    /// Энэхүү функцийг хэрэгжүүлэх нь [`RawWaker`] болон холбогдох даалгаврын нэмэлт жишээнд шаардагдах бүх нөөцийг хадгалах ёстой.
    /// Үүссэн [`RawWaker`] дээр `wake` руу залгах нь анхны [`RawWaker`]-ээр сэрсэн байсан даалгаврыг сэрээх болно.
    ///
    /// # `wake`
    ///
    /// Энэ функцийг [`Waker`] дээр `wake` дуудагдах үед дуудах болно.
    /// Энэ [`RawWaker`]-тэй холбоотой даалгаврыг сэрээх ёстой.
    ///
    /// Энэ функцийг хэрэгжүүлэх нь [`RawWaker`]-ийн жишээ болон холбогдох даалгавартай холбоотой аливаа нөөцийг суллах ёстой.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Энэ функцийг [`Waker`] дээр `wake_by_ref` дуудагдах үед дуудах болно.
    /// Энэ [`RawWaker`]-тэй холбоотой даалгаврыг сэрээх ёстой.
    ///
    /// Энэ функц нь `wake`-тэй төстэй боловч өгөгдсөн заагчийг ашиглах ёсгүй.
    ///
    /// # `drop`
    ///
    /// Энэ функц нь [`RawWaker`] унах үед дуудагдана.
    ///
    /// Энэ функцийг хэрэгжүүлэх нь [`RawWaker`]-ийн жишээ болон холбогдох даалгавартай холбоотой аливаа нөөцийг суллах ёстой.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Асинхрон даалгаврын `Context`.
///
/// Одоогийн байдлаар `Context` нь зөвхөн одоогийн даалгаврыг сэрээхэд ашиглаж болох `&Waker`-т хандах боломжийг олгодог.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Амьдралын хугацааг өөрчлөгдөхгүй байхыг шаардсанаар дисперсийн өөрчлөлтийн эсрэг future баталгаажуулалтыг баталгаажуул (аргумент байр суурийн ашиглалтын хугацаа харилцан зөрүүтэй байхад буцах байрлалын ашиглалтын хугацаа ковариант).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker`-ээс шинэ `Context` үүсгэх.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Одоогийн даалгаврын талаархи `Waker`-ийн лавлагааг буцаана.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` нь гүйцэтгэгчийг ажиллуулахад бэлэн байгааг мэдэгдэж сэрээх зориулалттай бариул юм.
///
/// Энэ бариул нь [`RawWaker`] жишээг багтаасан бөгөөд энэ нь гүйцэтгэгчид зориулагдсан сэрэх зан үйлийг тодорхойлдог.
///
///
/// [`Clone`], [`Send`], [`Sync`]-ийг хэрэгжүүлдэг.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Энэ `Waker`-тэй холбоотой даалгаврыг сэрээ.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Бодит сэрэх дуудлагыг виртуал функцын дуудлагаар гүйцэтгэгчийн тодорхойлсон хэрэгжилтэд шилжүүлдэг.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` руу залгах хэрэггүй-сэрээг `wake` ашиглах болно.
        crate::mem::forget(self);

        // АЮУЛГҮЙ БАЙДАЛ: `Waker::from_raw` бол цорын ганц арга зам учраас аюулгүй юм
        // `wake` ба `data`-ийг эхлүүлэхийн тулд хэрэглэгчид `RawWaker`-ийн гэрээг дагаж мөрдөж байгааг хүлээн зөвшөөрөх шаардлагатай болно.
        //
        unsafe { (wake)(data) };
    }

    /// Энэ `Waker`-тэй холбоотой даалгаврыг `Waker` ашиглахгүйгээр сэрээ.
    ///
    /// Энэ нь `wake`-тэй төстэй боловч эзэмшдэг `Waker` боломжтой тохиолдолд арай бага үр ашигтай байж магадгүй юм.
    /// Энэ аргыг `waker.clone().wake()` руу залгахаас илүүтэй сонгох хэрэгтэй.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Бодит сэрэх дуудлагыг виртуал функцын дуудлагаар гүйцэтгэгчийн тодорхойлсон хэрэгжилтэд шилжүүлдэг.
        //

        // Аюулгүй байдал: `wake`-г үзнэ үү
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Хэрэв энэ `Waker` болон өөр `Waker` ижил ажлыг сэрээсэн бол `true` буцаана.
    ///
    /// Энэ функц нь хамгийн сайн хүчин чармайлт дээр ажилладаг бөгөөд Waker`s ижил ажлыг сэрээх үед ч гэсэн буцааж өгдөг.
    /// Гэсэн хэдий ч, хэрэв энэ функц `true`-ийг буцааж өгвөл Waker нь ижил ажлыг сэрээх болно.
    ///
    /// Энэ функцийг үндсэндээ оновчлолын зорилгоор ашигладаг.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`]-ээс шинэ `Waker` үүсгэдэг.
    ///
    /// [RawWaker`] болон [`RawWakerVTable`]-ийн баримт бичигт тодорхойлсон гэрээг дагаж мөрдөөгүй тохиолдолд буцаж ирсэн `Waker`-ийн үйлдлийг тодорхойлоогүй болно.
    ///
    /// Тиймээс энэ арга нь аюултай юм.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // АЮУЛГҮЙ БАЙДАЛ: `Waker::from_raw` бол цорын ганц арга зам учраас аюулгүй юм
            // `clone` ба `data`-ийг эхлүүлэхийн тулд хэрэглэгчид [`RawWaker`]-ийн гэрээг дагаж мөрдөж байгааг хүлээн зөвшөөрөх шаардлагатай болно.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // АЮУЛГҮЙ БАЙДАЛ: `Waker::from_raw` бол цорын ганц арга зам учраас аюулгүй юм
        // `drop` ба `data`-ийг эхлүүлэхийн тулд хэрэглэгчид `RawWaker`-ийн гэрээг дагаж мөрдөж байгааг хүлээн зөвшөөрөх шаардлагатай болно.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}