use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// Дараагийн элементийн нэмэлт лавлагааг буцааж өгдөг `peek()` бүхий давталт.
///
///
/// Энэхүү `struct` нь [`Iterator`] дээр [`peekable`] аргаар бүтээгдсэн болно.
/// Дэлгэрэнгүй мэдээллийг түүний баримт бичгээс үзнэ үү.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Байхгүй байсан ч гэсэн үнэ цэнэтэй зүйлийг санаарай.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable нь `.peek()` аргаар None харагдаагүйг санаж байх ёстой.
// Энэ нь `.peek() гэдгийг баталгаажуулдаг;.peek();` эсвэл `.peek();.next();` нь зөвхөн үндсэн давталтыг нэг удаа сайжруулдаг.
// Энэ нь өөрөө давтагчийг хайлуулж чадахгүй.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Давталтыг ахиулахгүйгээр next() утгын лавлагааг буцаана.
    ///
    /// [`next`]-тэй адил утга байвал `Some(T)`-ээр ороосон байна.
    /// Гэхдээ давталт дууссан бол `None` буцаагдах болно.
    ///
    /// [`next`]: Iterator::next
    ///
    /// `peek()` нь лавлагаа буцаадаг тул олон давталтууд нь лавлагааны дагуу давтагддаг тул буцаах утга нь давхар лавлагаа болох төөрөлдсөн нөхцөл байдал үүсч болзошгүй юм.
    /// Энэ нөлөөг та доорх жишээнээс харж болно.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() бидэнд future-ийг харах боломжийг олгоно
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Бид `peek` удаа давтаж байсан ч давталт нь урагшлахгүй
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Давталж дуусгасны дараа `peek()` дуусна
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Давталтыг ахиулахгүйгээр next() утгын өөрчлөгдөж болох лавлагааг буцаана.
    ///
    /// [`next`]-тэй адил утга байвал `Some(T)`-ээр ороосон байна.
    /// Гэхдээ давталт дууссан бол `None` буцаагдах болно.
    ///
    /// `peek_mut()` нь лавлагаа буцаадаг тул олон давталтууд нь лавлагааны дагуу давтагддаг тул буцаах утга нь давхар лавлагаа болох төөрөлдсөн нөхцөл байдал үүсч болзошгүй юм.
    /// Энэ нөлөөг та доорх жишээнээс харж болно.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // `peek()`-тэй адил бид давталтыг ахиулахгүйгээр future руу харах боломжтой.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Давтагч руу харж, өөрчлөгдөж болох лавлагааны ард утгыг тохируулна уу.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Давталжуулагч үргэлжлэхэд бидний оруулсан үнэ цэнэ дахин гарч ирнэ.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Нөхцөл үнэн бол энэ давталтын дараагийн утгыг хэрэглээд буцаана уу.
    /// Хэрэв `func` нь `true`-ийг энэ давталтын дараагийн утгад буцааж өгвөл түүнийг хэрэглээд буцаана.
    /// Үгүй бол `None` буцаана уу.
    /// # Examples
    /// Хэрэв 0-тэй тэнцүү бол тоо хэрэглэнэ.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Давталтын эхний зүйл 0 байна;үүнийг хэрэглэ.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Дараагийн буцаж ирсэн зүйл одоо 1 тул `consume` нь `false`-ийг буцаана.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` `expected`-тэй тэнцэхгүй байсан бол дараагийн зүйлийн утгыг хадгална.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// 10-аас цөөн тоогоор хэрэглэнэ.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Бүх тоог 10-аас бага тоогоор хэрэглэнэ
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Дараагийн буцаах утга нь 10 байх болно
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Бид `self.next()` руу залгасан тул бид `self.peeked` хэрэглэсэн.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Дараагийн зүйлийг `expected`-тэй тэнцүү бол хэрэглэж, буцааж өгнө.
    /// # Example
    /// Хэрэв 0-тэй тэнцүү бол тоо хэрэглэнэ.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Давталтын эхний зүйл 0 байна;үүнийг хэрэглэ.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Дараагийн буцаж ирсэн зүйл одоо 1 тул `consume` нь `false`-ийг буцаана.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` `expected`-тэй тэнцэхгүй байсан бол дараагийн зүйлийн утгыг хадгална.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // АЮУЛГҮЙ БАЙДАЛ: Аюулгүй ажиллагааг ижил шаардлагад нийцүүлэн, аюултай функц руу шилжүүлэх
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}