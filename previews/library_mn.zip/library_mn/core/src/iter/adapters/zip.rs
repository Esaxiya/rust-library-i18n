use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// Өөр хоёр давталтыг нэгэн зэрэг давтдаг давталт.
///
/// Энэхүү `struct`-ийг [`Iterator::zip`] бүтээсэн болно.
/// Дэлгэрэнгүй мэдээллийг түүний баримт бичгээс үзнэ үү.
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // index, len ба a_len-ийг зөвхөн zip-ийн төрөлжсөн хувилбар ашигладаг
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // АЮУЛГҮЙ БАЙДАЛ: `ZipImpl::__iterator_get_unchecked` нь ижил аюулгүй ажиллагаатай байдаг
        // `Iterator::__iterator_get_unchecked` зэрэг шаардлага.
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// Zip мэргэшсэн trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // Энэ нь `Iterator::__iterator_get_unchecked`-тэй ижил аюулгүй байдлын шаардлага тавьдаг
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// Ерөнхий Zip импл
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // A, b-ийг ижил урттай тохируулна уу
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // Аюулгүй байдал: `i` нь `self.len`-ээс бага тул `self.a.len()` ба `self.b.len()`-ээс бага байна
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // Суурь хэрэгжилтийн болзошгүй гаж нөлөөг АЮУЛГҮЙ АЖИЛЛАХ: бид `i` <`self.a.len()` гэдгийг шалгасан
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // АЮУЛГҮЙ БАЙДАЛ: `delta`-ийг тооцоолохдоо `cmp::min`-ийг ашиглах
                // `end` нь `self.len`-ээс бага эсвэл тэнцүү байх тул `i` нь `self.len`-ээс бага байна.
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // Аюулгүй байдал: дээрхтэй ижил.
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // A, b-ийг ижил урттай болгож, зөвхөн `next_back`-ийн анхны дуудлага үүнийг хийдэг эсэхийг шалгаарай, эс тэгвэл бид `get_unchecked()` руу залгасны дараа `self.next_back()` руу залгах хязгаарлалтыг зөрчих болно.
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // Аюулгүй байдал: `i` нь `self.len`-ийн өмнөх утгаас бага,
            // Энэ нь `self.a.len()` ба `self.b.len()`-ээс бага эсвэл тэнцүү байна
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // АЮУЛГҮЙ БАЙДАЛ: дуудлага хийж байгаа хүн `Iterator::__iterator_get_unchecked`-тэй байгуулсан гэрээг дагаж мөрдөх ёстой.
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// Цип давталтын зүүн талыг олборлодог "source" гэж дур мэдэн сонгосон тохиолдолд сөрөг trait bounds хоёуланг нь туршиж үзэх шаардлагатай болно.
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // АЮУЛГҮЙ БАЙДАЛ: Аюулгүй ажиллагааг ижил шаардлагад нийцүүлэн, аюултай функц руу шилжүүлэх
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// Зүйлийн хувьд хязгаарлагдмал: Zip-ийн TrustedRandomAccess ба Drop-ийн эх сурвалжийг хэрэгжүүлэх харилцан үйлчлэл тодорхойгүй тул хуулбарлах.
//
// Эх сурвалжийг логикоор сайжруулсан тоог буцааж өгөх нэмэлт арга (эх үүсвэрийн үлдэгдлийг зөв хаяхын тулд next()) дуудлага хийхгүйгээр шаардлагатай болно.
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Агуулагдсан давталтууд дээр fmt руу залгах нь * аюулгүй биш юм, учир нь бид тэдгээрийг давтаж эхэлмэгц хачин, аюултай байж болзошгүй мужуудад давтана.
        //
        f.debug_struct("Zip").finish()
    }
}

/// Зүйлүүд нь үр дүнтэй, санамсаргүй байдлаар нэвтрэх боломжтой давталт
///
/// # Safety
///
/// Давталтын `size_hint` нь дуудлага хийхэд яг тохирсон, хямд байх ёстой.
///
/// `size` хүчингүй болгож болохгүй.
///
/// `<Self as Iterator>::__iterator_get_unchecked` дараахь нөхцлийг хангасан тохиолдолд дуудлага хийхэд аюулгүй байх ёстой.
///
/// 1. `0 <= idx` болон `idx < self.size()`.
/// 2. Хэрэв `self: !Clone` бол `get_unchecked`-ийг ижил индексээр хэзээ ч `self` дээр нэгээс олон удаа дууддаггүй.
/// 3. `self.get_unchecked(idx)` дуудагдсаны дараа `next_back` нь зөвхөн хамгийн ихдээ `self.size() - idx - 1` удаа залгах болно.
/// 4. `get_unchecked` дуудагдсаны дараа `self` дээр зөвхөн дараахь аргуудыг дуудах болно.
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// Цаашилбал эдгээр нөхцлийг хангасан тул дараахь зүйлийг баталгаажуулах ёстой.
///
/// * Энэ нь `size_hint`-ээс буцаж ирсэн утгыг өөрчлөхгүй
/// * Шаардлагатай traits хэрэгжиж байна гэж үзээд `get_unchecked` руу залгасны дараа дээр дурдсан аргуудыг `self` дээр дуудах нь аюулгүй байх ёстой.
///
/// * `get_unchecked` руу залгасны дараа `self`-ийг унах нь аюулгүй байх ёстой.
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // Тохиромжтой арга.
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` Хэрэв давталтын элемент авах нь гаж нөлөөтэй байж болзошгүй юм.
    /// Дотоод давталтыг анхааралдаа авахаа бүү мартаарай.
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// `Iterator::__iterator_get_unchecked` шиг боловч хөрвүүлэгчээс `U: TrustedRandomAccess` гэдгийг мэдэхийг шаарддаггүй.
///
///
/// ## Safety
///
/// `get_unchecked` руу шууд залгах ижил шаардлага.
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // АЮУЛГҮЙ БАЙДАЛ: дуудлага хийж байгаа хүн `Iterator::__iterator_get_unchecked`-тэй байгуулсан гэрээг дагаж мөрдөх ёстой.
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// Хэрэв `Self: TrustedRandomAccess` бол `Iterator::__iterator_get_unchecked(self, index)` руу залгахад аюулгүй байх ёстой.
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // АЮУЛГҮЙ БАЙДАЛ: дуудлага хийж байгаа хүн `Iterator::__iterator_get_unchecked`-тэй байгуулсан гэрээг дагаж мөрдөх ёстой.
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}