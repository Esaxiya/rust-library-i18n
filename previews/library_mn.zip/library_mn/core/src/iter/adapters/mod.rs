use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Энэхүү trait нь интератор-адаптерийн дамжуулах хоолойн эх үүсвэр шатанд дамжин өнгөрөх боломжийг олгодог
/// * давталтын эх үүсвэр `S` өөрөө `SourceIter<Source = S>`-ийг хэрэгжүүлдэг
/// * эх үүсвэр ба дамжуулах хоолойн хэрэглэгчийн хоорондох дамжуулах хоолой дахь адаптер бүрийн хувьд энэхүү trait-ийг төлөөлөх хэрэгжилт байдаг.
///
/// Эх сурвалж нь давталтын бүтэц эзэмшдэг (ихэвчлэн `IntoIter` гэж нэрлэдэг) бол энэ нь [`FromIterator`]-ийн хэрэгжилтийг мэргэшүүлэх эсвэл давталтыг хэсэгчлэн дуусгасны дараа үлдсэн элементүүдийг сэргээхэд ашигтай байж болох юм.
///
///
/// Хэрэгжилт нь дамжуулах хоолойн хамгийн дотоод эх үүсвэрт нэвтрэх боломжийг бүрдүүлэх шаардлагагүй гэдгийг анхаарна уу.Тогтсон завсрын адаптер нь дамжуулах хоолойн хэсгийг үнэлэхийг хүсэж, дотоод санах ойг эх үүсвэр болгон харуулах болно.
///
/// Хэрэглэгчид нэмэлт аюулгүй байдлын шинж чанарыг хадгалах ёстой тул trait нь аюултай байдаг.
/// Дэлгэрэнгүйг [`as_inner`]-с үзнэ үү.
///
/// # Examples
///
/// Хэсэгчлэн ашигласан эх үүсвэрийг татаж авах:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Давталтын дамжуулах хоолойн эх үүсвэрийн үе шат.
    type Source: Iterator;

    /// Давталтын дамжуулах хоолойн эх үүсвэрийг авах.
    ///
    /// # Safety
    ///
    /// Хэрэгжүүлэлт нь дуудагчаар солигдоогүй тохиолдолд насан туршдаа ижил өөрчлөгдөж болох лавлагааг буцааж өгөх ёстой.
    /// Дуудлага хийж буй хүмүүс давталтаа зогсоож, эх үүсвэрийг гаргаж авсны дараа давталтын дамжуулах хоолойг унагаахад л лавлагааг сольж болно.
    ///
    /// Энэ нь давталтын адаптерууд давталтын явцад өөрчлөгдөхгүй эх үүсвэрт найдаж болох боловч Drop хэрэгжүүлэхдээ түүнд найдах боломжгүй гэсэн үг юм.
    ///
    /// Энэхүү аргыг хэрэгжүүлснээр адаптерууд зөвхөн хувийн эх үүсвэрээс хандах хандалтаас татгалзах бөгөөд зөвхөн арга хүлээн авагчийн төрлүүд дээр үндэслэсэн баталгаанд найдаж болно гэсэн үг юм.
    /// Хязгаарлагдмал хандалтын дутагдал нь адаптерууд дотооддоо нэвтрэх боломжтой байсан ч эх үүсвэрийн нийтийн API-г дагаж мөрдөхийг шаарддаг.
    ///
    /// Залгагчид нь эх сурвалж нь нийтийн API-тэй нийцсэн ямар ч төлөвт байх ёстой гэж найдаж байх ёстой, учир нь түүнтэй холбогдсон адаптерууд болон эх сурвалж хоорондоо ижил хандалттай байдаг.
    /// Ялангуяа адаптер нь шаардагдах хэмжээнээс илүү их элемент хэрэглэсэн байж магадгүй юм.
    ///
    /// Эдгээр шаардлагын ерөнхий зорилго нь дамжуулах хоолойн хэрэглэгчийг ашиглах боломжийг олгох явдал юм
    /// * давталт зогссоны дараа эх сурвалжид үлдсэн бүх зүйл
    /// * хэрэглээний давталтыг сайжруулах замаар ашиглагдаагүй болсон санах ой
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Суурь давталт нь `Result::Ok` утгыг гаргадаг бол гаралт үүсгэдэг давталтын адаптер.
///
///
/// Хэрэв алдаа гарсан бол давталт зогсч, алдаа хадгалагдана.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Өгөгдсөн давталтыг `Result<T, _>`-ийн оронд `T` гарган авсан мэт боловсруулна.
/// Аливаа алдаа нь дотоод давталтыг зогсоох бөгөөд нийт үр дүн нь алдаа байх болно.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}