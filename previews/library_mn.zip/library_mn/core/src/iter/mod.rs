//! Нийлмэл гадаад давталт.
//!
//! Хэрэв та ямар нэгэн төрлийн цуглуулгатай болсныг олж мэдсэн бөгөөд уг цуглуулгын элементүүд дээр ямар нэгэн үйлдэл хийх шаардлагатай бол та 'iterators' руу хурдан орох болно.
//! Итераторууд нь хэл ярианы Rust кодонд их ашиглагддаг тул тэдэнтэй танилцах нь зүйтэй болов уу.
//!
//! Илүү дэлгэрэнгүй тайлбарлахаасаа өмнө энэ модуль хэрхэн бүтэцлэгдсэн талаар ярилцъя.
//!
//! # Organization
//!
//! Энэ модулийг төрлөөр нь ихэвчлэн зохион байгуулдаг.
//!
//! * [Traits] үндсэн хэсэг юм: эдгээр traits нь ямар төрлийн давталтууд байдаг, тэдэнтэй юу хийж чадахаа тодорхойлдог.Эдгээр traits-ийн аргууд нь нэмэлт сургалтын цагийг зарцуулах нь зүйтэй юм.
//! * [Functions] зарим үндсэн давталтыг бий болгоход тустай аргуудыг өгөх.
//! * [Structs] нь ихэвчлэн энэхүү модулийн traits дээрх янз бүрийн аргуудын өгөөжийн төрлүүд юм.Та ихэвчлэн `struct`-ийг биш харин `struct`-ийг үүсгэдэг аргыг харахыг хүсэх болно.
//! Үүний шалтгааны талаар илүү дэлгэрэнгүйг '[Хэрэгжүүлэх давталт](#хэрэгжүүлэгч-давталт)' хэсгээс үзнэ үү.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Тиймээ!Давталтыг судалж үзье.
//!
//! # Iterator
//!
//! Энэхүү модулийн зүрх ба сүнс нь [`Iterator`] trait юм.[`Iterator`]-ийн цөм дараах байдалтай байна.
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Давтагч нь [`next`] гэсэн аргатай бөгөөд түүнийг дуудахад [`Сонголт`]`буцаадаг<Item>".
//! [`next`] элемент байгаа тохиолдолд [`Some(Item)`]-ийг буцааж өгөх бөгөөд бүгд дууссаны дараа давталт дууссан болохыг харуулахын тулд `None`-ийг буцаана.
//! Бие даасан давталтууд давталтаа үргэлжлүүлэхээр сонгож болох тул дахин [`next`] руу залгах нь хэзээ нэгэн цагт [`Some(Item)`]-ийг буцааж буцааж өгч магадгүй юм (жишээ нь, [`TryIter`]-г үзнэ үү).
//!
//!
//! ["Итератор"]-ын бүрэн тодорхойлолтонд бусад хэд хэдэн аргыг багтаасан байдаг боловч эдгээр нь [`next`] дээр суурилагдсан анхдагч аргууд тул та тэдгээрийг үнэгүй авах боломжтой болно.
//!
//! Итераторууд нь хоорондоо уялдаа холбоотой байдаг бөгөөд боловсруулалтын илүү төвөгтэй хэлбэрүүдийг хийхийн тулд тэдгээрийг гинжлэх нь түгээмэл байдаг.Дэлгэрэнгүй мэдээллийг доорх [Adapters](#adapters) хэсгээс үзнэ үү.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Давталтын гурван хэлбэр
//!
//! Цуглуулгаас давталтыг үүсгэж болох гурван нийтлэг арга байдаг.
//!
//! * `iter()`, энэ нь `&T`-ээс давтагдана.
//! * `iter_mut()`, Энэ нь `&mut T`-ээс давтагдана.
//! * `into_iter()`, энэ нь `T`-ээс давтагдана.
//!
//! Стандарт номын сан дахь янз бүрийн зүйлүүд шаардлагатай бол эдгээрийн аль нэгийг нь эсвэл хэдийг нь хэрэгжүүлж болно.
//!
//! # Итераторыг хэрэгжүүлж байна
//!
//! Өөрийнхөө давталтыг бий болгох нь хоёр үе шаттай: давталтын төлөвийг хадгалахын тулд `struct` үүсгэх, дараа нь тэр `struct`-д зориулж [`Iterator`]-ийг хэрэгжүүлэх.
//! Ийм учраас энэ модуль дотор маш олон бүтцийн элементүүд байдаг: давталт болон давталтын адаптер тус бүрт нэг байдаг.
//!
//! `1`-ээс `5` хүртэл тоолох `Counter` нэртэй давталтыг хийцгээе.
//!
//! ```
//! // Нэгдүгээрт, бүтэц:
//!
//! /// Нэгээс таван хүртэл тоолох давталт
//! struct Counter {
//!     count: usize,
//! }
//!
//! // Бидний тооллыг нэгээс эхлэхийг хүсч байгаа тул туслах new() аргыг нэмье.
//! // Энэ нь тийм ч чухал биш боловч тохиромжтой.
//! // Бид `count`-ийг тэгээс эхлүүлж байгааг анхаарна уу, яагаад `next()`'s-ийн хэрэгжилтийг доор харуулах болно.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Дараа нь бид `Counter`-д зориулж `Iterator`-ийг хэрэгжүүлдэг.
//!
//! impl Iterator for Counter {
//!     // бид usize-тай хамт тоолох болно
//!     type Item = usize;
//!
//!     // next() шаардлагатай цорын ганц арга юм
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Бидний тоог нэмэгдүүлэх.Тиймээс бид тэгээс эхэлсэн.
//!         self.count += 1;
//!
//!         // Бид тоолж дууссан эсэхийг шалгаарай.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Одоо бид үүнийг ашиглаж болно!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`] руу залгах нь давтагдах болно.Rust нь `None` хүрэх хүртэл таны давталт дээр [`next`] руу залгах боломжтой бүтэцтэй.Дараа нь үүнийг давъя.
//!
//! `Iterator` нь `nth`, `fold` зэрэг аргын анхдагч хэрэгжилтийг хангаж өгдөг бөгөөд `next`-ийг дотооддоо дууддаг.
//! Гэхдээ `nth`, `fold` гэх мэт аргуудыг захиалагч нь `next` руу залгахгүйгээр илүү үр дүнтэй тооцоолж чаддаг бол гаалийн хэрэгжилтийг бичих боломжтой.
//!
//! # `for` гогцоонууд ба `IntoIterator`
//!
//! Rust-ийн `for` давталтын синтакс нь үнэндээ давталтанд зориулсан чихэр юм.`for`-ийн үндсэн жишээ энд байна.
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Энэ нь тус бүрийг өөрийн мөрөнд нэгээс тав хүртэлх тоог хэвлэнэ.Гэхдээ та эндээс ямар нэгэн зүйлийг анзаарах болно: бид vector дээрээ давталт гаргахын тулд хэзээ ч юу ч дуудаагүй.Юу өгдөг вэ?
//!
//! Стандарт номын санд ямар нэг зүйлийг давталт болгон хөрвүүлэх trait байдаг: [`IntoIterator`].
//! Энэхүү trait нь [`into_iter`] гэсэн нэг аргатай бөгөөд [`IntoIterator`]-ийг хэрэгжүүлж буй зүйлийг давталт болгон хувиргадаг.
//! Тэр `for` давталтыг дахин авч үзье, хөрвүүлэгч үүнийг юу болгон хөрвүүлдэг вэ?
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust үүнийг дараахь байдлаар бууруулдаг:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Нэгдүгээрт, бид утга дээр `into_iter()` гэж нэрлэдэг.Дараа нь бид буцаж ирсэн давталт дээр таарч, `None` харах хүртэл [`next`] руу дахин дахин залгана.
//! Тэр үед бид `break` гогцооноос гарч, давталт хийж дууслаа.
//!
//! Энд бас нэг нарийн зүйл бий: стандарт номын сан нь [`IntoIterator`]-ийн сонирхолтой програмыг агуулдаг.
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Өөрөөр хэлбэл, өөрсдийгөө буцааж өгөх замаар бүх [`Iterator`] [`IntoIterator`]-ийг хэрэгжүүлдэг.Энэ нь хоёр зүйлийг хэлнэ:
//!
//! 1. Хэрэв та [`Iterator`] бичиж байгаа бол `for` давталтаар ашиглаж болно.
//! 2. Хэрэв та цуглуулга үүсгэж байгаа бол [`IntoIterator`]-ийг хэрэгжүүлснээр таны цуглуулгыг `for` давталтад ашиглах боломжтой болно.
//!
//! # Лавлагаагаар давтаж байна
//!
//! [`into_iter()`] нь `self`-ийг утгаар нь авдаг тул `for` давталтыг ашиглан цуглуулга дээр давталт хийх нь тухайн цуглуулгыг зарцуулдаг.Ихэнх тохиолдолд та цуглуулгыг ашиглахгүйгээр давтахыг хүсч магадгүй юм.
//! Олон цуглуулгуудад уламжлалт байдлаар `iter()` ба `iter_mut()` гэж нэрлэгддэг лавлагааны дагуу давталт өгдөг аргуудыг санал болгодог.
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` одоо ч гэсэн энэ функцэд эзэмшдэг.
//! ```
//!
//! Хэрэв `C` цуглуулгын төрөл нь `iter()`-ийг хангаж байвал `&C`-ийг `&C`-тэй хэрэгжүүлдэг бөгөөд зөвхөн `iter()` руу залгах програмтай байдаг.
//! Үүнтэй адил `iter_mut()` цуглуулдаг `C` цуглуулга нь `IntoIterator`-ийг `iter_mut()`-д шилжүүлснээр `IntoIterator`-ийг ерөнхийдөө хэрэгжүүлдэг.Энэ нь тохиромжтой товчлолыг идэвхжүүлдэг:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()`-тэй адил
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()`-тэй адил
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Олон цуглуулга `iter()`-ийг санал болгодог боловч бүгд `iter_mut()`-ийг санал болгодоггүй.
//! Жишээлбэл, [`HashSet<T>`] эсвэл [`HashMap<K, V>`]-ийн түлхүүрүүдийг мутацлах нь түлхүүрийн хэш өөрчлөгдсөн тохиолдолд цуглуулгыг тохиромжгүй байдалд оруулж болзошгүй тул эдгээр цуглуулгууд зөвхөн `iter()`-ийг санал болгодог.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! [`Iterator`]-ийг аваад өөр [`Iterator`]-ийг буцааж өгдөг функцуудыг "адаптерийн хэлбэр" гэж нэрлэдэг тул үүнийг ихэвчлэн "давталтын адаптерууд" гэж нэрлэдэг.
//! pattern'.
//!
//! Нийтлэг давталтын адаптеруудад [`map`], [`take`], [`filter`] орно.
//! Дэлгэрэнгүй мэдээллийг тэдний баримт бичгээс үзнэ үү.
//!
//! Хэрэв давталтын адаптер panics бол давталт нь тодорхойлогдоогүй (гэхдээ санах ойд аюулгүй) байдалд байх болно.
//! Энэ байдал нь Rust-ийн хувилбарууд дээр ижил хэвээр байх баталгаа биш тул та сандарсан давталтын буцааж өгсөн утгуудад найдахаас зайлсхийх хэрэгтэй.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Итераторууд (мөн [adapters](#adapters)) давтагч нь *залхуу* юм. Энэ нь зөвхөн давталтыг бий болгосноор _do_-ийг бүхэлд нь хамардаггүй гэсэн үг юм. [`next`] руу залгахаас нааш юу ч болохгүй.
//! Энэ нь зөвхөн гаж нөлөөгөөр давталт үүсгэх үед заримдаа төөрөлдөх эх үүсвэр болдог.
//! Жишээлбэл, [`map`] арга нь давтагдсан элемент тус бүр дээр хаалтыг дууддаг.
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Үүнийг ашиглахаас илүүтэйгээр бид зөвхөн давталтыг бүтээсэн тул энэ нь ямар ч утгыг хэвлэхгүй.Энэ төрлийн зан үйлийн талаар хөрвүүлэгч бидэнд анхааруулах болно.
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! [`map`]-ийг гаж нөлөөгөөр бичих өвөрмөц арга бол `for` давталтыг ашиглах эсвэл [`for_each`] аргыг дуудах явдал юм.
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Давталтыг үнэлэх өөр нэг түгээмэл арга бол [`collect`] аргыг ашиглан шинэ цуглуулга гаргах явдал юм.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Итераторууд хязгаартай байх албагүй.Жишээлбэл, нээлттэй хязгаар нь хязгааргүй давталт юм.
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Хязгааргүй давталтыг хязгаарлагдмал болгохын тулд [`take`] давталтын адаптерийг ашиглах нь түгээмэл байдаг.
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Энэ нь `0`-ээс `4` хүртэлх тоог тус тусад нь мөрөнд хэвлэх болно.
//!
//! Хязгааргүй давталтууд, тэр ч байтугай үр дүнг математикийн аргаар эцэс төгсгөлгүй хугацаанд тодорхойлж болох аргууд ч дуусахгүй байж болно гэдгийг санаарай.
//! Тодруулбал, ерөнхийдөө давталтын элемент бүрийг туулах шаардлагатай байдаг [`min`] гэх мэт аргууд нь ямар ч хязгааргүй давталтын хувьд амжилттай эргэж ирэхгүй байх магадлалтай юм.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Өө үгүй ээ!Хязгааргүй гогцоо!
//! // `ones.min()` хязгааргүй гогцоог үүсгэдэг тул бид энэ цэгт хүрэхгүй!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;