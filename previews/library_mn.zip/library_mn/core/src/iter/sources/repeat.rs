use crate::iter::{FusedIterator, TrustedLen};

/// Нэг элементийг төгсгөлгүй давтах шинэ давталтыг бий болгодог.
///
/// `repeat()` функц нь нэг утгыг дахин дахин давтана.
///
/// `repeat()` гэх мэт хязгааргүй давталтыг ихэвчлэн хязгаартай болгохын тулд [`Iterator::take()`] шиг адаптеруудтай хамт ашигладаг.
///
/// Хэрэв танд хэрэгтэй давталтын элементийн төрөл нь `Clone`-ийг хэрэгжүүлээгүй эсвэл давтагдсан элементийг санах ойд хадгалахыг хүсэхгүй байвал [`repeat_with()`] функцийг ашиглаж болно.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// use std::iter;
///
/// // 4-р тоо 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // тиймээ, одоо ч гэсэн дөрөв
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`]-тэй хязгаартай байх:
///
/// ```
/// use std::iter;
///
/// // хамгийн сүүлийн жишээ нь хэтэрхий олон дөрөв байсан.Дөрвөн дөрөвтэй л байцгаая.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... одоо бид дууслаа
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Элементийг төгсгөлгүй давтдаг давталт.
///
/// Энэхүү `struct` нь [`repeat()`] функцээр бүтээгдсэн байдаг.Дэлгэрэнгүй мэдээллийг түүний баримт бичгээс үзнэ үү.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}