use crate::fmt;

/// Давталт бүр нь өгөгдсөн хаалттай `F: FnMut() -> Option<T>` гэж нэрлэдэг шинэ давталтыг бий болгодог.
///
/// Энэ нь зориулалтын төрлийг бий болгож, [`Iterator`] trait-ийг хэрэгжүүлэхэд илүү дэлгэрэнгүй синтакс ашиглахгүйгээр дурын зан төлөв бүхий өөрчлөн давталтыг бий болгох боломжийг олгодог.
///
/// `FromFn` давталт нь хаалтын ажиллагааны талаар таамаглал дэвшүүлдэггүй тул [`FusedIterator`]-ийг хэрэгжүүлдэггүй, эсвэл [`Iterator::size_hint()`]-ийг анхдагч `(0, None)`-ээс нь хүчингүй болгодог болохыг анхаарна уу.
///
///
/// Хаалт нь дүрс болон түүний орчныг ашиглан давталтын төлөвийг хянах боломжтой.Давтагчийг хэрхэн ашиглаж байгаагаас хамааран хаагдахад [`move`] түлхүүр үгийг зааж өгөх шаардлагатай болно.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// [module-level documentation]-ээс эсрэг давталтыг дахин хэрэгжүүлцгээе:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Бидний тоог нэмэгдүүлэх.Тиймээс бид тэгээс эхэлсэн.
///     count += 1;
///
///     // Бид тоолж дууссан эсэхийг шалгаарай.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Давталт бүр нь өгөгдсөн хаалтыг `F: FnMut() -> Option<T>` гэж нэрлэдэг давталт.
///
/// Энэхүү `struct` нь [`iter::from_fn()`] функцээр бүтээгдсэн байдаг.
/// Дэлгэрэнгүй мэдээллийг түүний баримт бичгээс үзнэ үү.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}