use crate::iter::{FusedIterator, TrustedLen};

/// Өгөгдсөн хаалтыг дуудаж залхуутайгаар яг нэг удаа үнэ цэнэ үүсгэдэг давталтыг бий болгодог.
///
/// Энэ нь ихэвчлэн нэг утга үүсгэгчийг [`chain()`] бусад төрлийн давталтад дасан зохицуулахад ашиглагддаг.
/// Магадгүй танд бараг бүх зүйлийг хамарсан давтагч байгаа байх, гэхдээ танд нэмэлт онцгой тохиолдол хэрэгтэй.
/// Магадгүй танд давталт дээр ажилладаг функц байгаа байх, гэхдээ та зөвхөн нэг утгыг боловсруулах хэрэгтэй.
///
/// [`once()`]-ээс ялгаатай нь энэ функц нь хүсэлтийн дагуу үнэ цэнийг бий болгодог.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// use std::iter;
///
/// // нэг бол хамгийн ганцаардсан тоо юм
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // Зөвхөн нэг л зүйл бол бид үүнийг л олж авдаг
/// assert_eq!(None, one.next());
/// ```
///
/// Өөр нэг давталттай хамт гинжлэх.
/// Бид `.foo` директорын файл бүр дээр давтахыг хүсч байгаа, гэхдээ бас тохиргооны файл гэж хэлье,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // бид DirEntry-ийн давталтаас PathBufs-ийн давталт руу хөрвүүлэх хэрэгтэй тул газрын зургийг ашигладаг.
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // одоо зөвхөн манай тохиргооны файлд зориулсан давталт
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // хоёр давталтыг нэг том давталтад гинжлээрэй
/// let files = dirs.chain(config);
///
/// // Энэ нь бидэнд .foo болон .foorc файлуудыг бүгдийг нь өгөх болно
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Өгөгдсөн хаалттай `F: FnOnce() -> A`-ийг хэрэглэснээр `A` төрлийн нэг элементийг гаргадаг давталт.
///
///
/// Энэхүү `struct` нь [`once_with()`] функцээр бүтээгдсэн байдаг.
/// Дэлгэрэнгүй мэдээллийг түүний баримт бичгээс үзнэ үү.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}