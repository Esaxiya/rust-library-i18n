use crate::iter::{FusedIterator, TrustedLen};

/// Элементийг яг нэг удаа гаргадаг давталтыг бий болгодог.
///
/// Энэ нь нэг утгыг бусад төрлийн давталтын [`chain()`] болгон өөрчлөхөд түгээмэл хэрэглэгддэг.
/// Магадгүй танд бараг бүх зүйлийг хамарсан давтагч байгаа байх, гэхдээ танд нэмэлт онцгой тохиолдол хэрэгтэй.
/// Магадгүй танд давталт дээр ажилладаг функц байгаа байх, гэхдээ та зөвхөн нэг утгыг боловсруулах хэрэгтэй.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// use std::iter;
///
/// // нэг бол хамгийн ганцаардсан тоо юм
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // Зөвхөн нэг л зүйл бол бид үүнийг л олж авдаг
/// assert_eq!(None, one.next());
/// ```
///
/// Өөр нэг давталттай хамт гинжлэх.
/// Бид `.foo` директорын файл бүр дээр давтахыг хүсч байгаа, гэхдээ бас тохиргооны файл гэж хэлье,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // бид DirEntry-ийн давталтаас PathBufs-ийн давталт руу хөрвүүлэх хэрэгтэй тул газрын зургийг ашигладаг.
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // одоо зөвхөн манай тохиргооны файлд зориулсан давталт
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // хоёр давталтыг нэг том давталтад гинжлээрэй
/// let files = dirs.chain(config);
///
/// // Энэ нь бидэнд .foo болон .foorc файлуудыг бүгдийг нь өгөх болно
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Элементийг яг нэг удаа гаргадаг давталт.
///
/// Энэхүү `struct` нь [`once()`] функцээр бүтээгдсэн байдаг.Дэлгэрэнгүй мэдээллийг түүний баримт бичгээс үзнэ үү
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}