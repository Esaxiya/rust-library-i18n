use crate::iter::{FusedIterator, TrustedLen};

/// Өгөгдсөн хаалт, давталт, `A` төрлийн элементүүдийг төгсгөлгүй давтах шинэ давталтыг бий болгодог. `F: FnMut() -> A`.
///
/// `repeat_with()` функц нь давталтыг дахин дахин дууддаг.
///
/// `repeat_with()` гэх мэт хязгааргүй давталтыг ихэвчлэн хязгаартай болгохын тулд [`Iterator::take()`] шиг адаптеруудтай хамт ашигладаг.
///
/// Хэрэв танд хэрэгтэй давталтын элементийн төрөл нь [`Clone`]-ийг хэрэгжүүлж байгаа бол эх элементийг санах ойд хадгалах нь зөв бол та оронд нь [`repeat()`] функцийг ашиглах хэрэгтэй.
///
///
/// `repeat_with()`-ийн үйлдвэрлэсэн давталт нь [`DoubleEndedIterator`] биш юм.
/// Хэрэв танд [`DoubleEndedIterator`] буцааж өгөхөд `repeat_with()` хэрэгтэй бол GitHub-ийн асуудлыг нээж ашиглалтынхаа тохиолдлыг тайлбарлана уу.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// use std::iter;
///
/// // Бид `Clone` биш эсвэл үнэтэй тул санах ойд хараахан багтаахыг хүсээгүй зарим төрлийн үнэ цэнэтэй гэж үзье.
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // үүрд тодорхой үнэ цэнэ:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Мутацийг ашиглан хязгаартай болно.
///
/// ```rust
/// use std::iter;
///
/// // Тэгээс хоёрын гуравдахь хүч хүртэл:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... одоо бид дууслаа
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Өгөгдсөн хаалт `F: FnMut() -> A`-ийг ашигласнаар `A` төрлийн элементүүдийг төгсгөлгүй давтдаг давталт.
///
///
/// Энэхүү `struct` нь [`repeat_with()`] функцээр бүтээгдсэн байдаг.
/// Дэлгэрэнгүй мэдээллийг түүний баримт бичгээс үзнэ үү.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}