use crate::ops::{ControlFlow, Try};

/// Хоёр үзүүрээс элемент гаргаж чаддаг давталт.
///
/// `DoubleEndedIterator`-ийг хэрэгжүүлдэг зүйл нь [`Iterator`]-ийг хэрэгжүүлж байгаа зүйл дээр нэг нэмэлт чадвартай байдаг: "Item`s"-ийг урд, урд талаас нь авах чадвартай байдаг.
///
///
/// Хоёулаа хоёулаа ижил хүрээн дээр ажилладаг бөгөөд огтлолцохгүй байхыг анхаарах нь чухал юм: давталт нь дунд нь уулзахад дуусна.
///
/// [`Iterator`] протоколтой ижил төстэй байдлаар `DoubleEndedIterator` нь [`next_back()`]-ээс [`None`]-ийг буцааж дахин дуудвал [`Some`]-ийг буцааж өгч магадгүй юм.
/// [`next()`] болон [`next_back()`] нь энэ зорилгоор солигддог.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Давталтын төгсгөлөөс элементийг арилгаж буцаана.
    ///
    /// Элемент байхгүй үед `None` буцаана.
    ///
    /// [trait-level] документууд илүү дэлгэрэнгүй мэдээллийг агуулдаг.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `DoubleEndedIterator`-ийн аргаар гаргаж авсан элементүүд [[Iterator`]-ын гаргасан аргуудаас ялгаатай байж болно:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Ар талаас давтагчийг `n` элементээр урагшлуулна.
    ///
    /// `advance_back_by` нь [`advance_by`]-ийн урвуу хувилбар юм.Энэ арга нь `n` элементүүдийг ар талаас нь эхлэн [`next_back`]-ийг `n` хүртэл `n` удаа дуудаж алгасах болно.
    ///
    /// `advance_back_by(n)` давталт нь `n` элементүүдээр амжилттай урагшилвал [`Ok(())`]-ийг буцаана, эсвэл [`None`] тулгарвал [`Err(k)`] болно, энд `k` нь элемент дуусахаас өмнө давталтын ахисан элементүүдийн тоо юм.
    /// давталтын урт).
    /// `k` нь үргэлж `n`-ээс бага болохыг анхаарна уу.
    ///
    /// `advance_back_by(0)` руу залгах нь ямар ч элемент хэрэглэдэггүй бөгөөд үргэлж [`Ok(())`]-ийг буцаадаг.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // зөвхөн `&3`-ийг алгассан
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Давталтын төгсгөлөөс `n`th элементийг буцаана.
    ///
    /// Энэ бол үндсэндээ [`Iterator::nth()`]-ийн урвуу хувилбар юм.
    /// Ихэнх индексжүүлэх үйлдлүүдийн адил тоолол нь тэгээс эхэлдэг тул `nth_back(0)` нь эхний утгыг төгсгөлөөс, `nth_back(1)` хоёр дахь хэсгийг буцааж өгдөг.
    ///
    ///
    /// Төгсгөл ба буцаасан элементийн хоорондох бүх элементүүд, үүнд буцаж ирсэн элементийг зарцуулах болно гэдгийг анхаарна уу.
    /// Энэ нь `nth_back(0)`-ийг нэг давталтад олон удаа залгах нь өөр өөр элементүүдийг буцааж өгөх болно гэсэн үг юм.
    ///
    /// `nth_back()` хэрэв `n` нь давталтын уртаас их эсвэл тэнцүү байвал [`None`] буцаана.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` руу олон удаа залгах нь давталтыг буцааж өгөхгүй:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1`-ээс бага элемент байвал `None`-ийг буцааж өгөх:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Энэ бол [`Iterator::try_fold()`]-ийн урвуу хувилбар юм: давталтын арын хэсгээс эхлэн элементүүдийг авдаг.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Энэ нь богино холболттой тул үлдсэн элементүүд нь давталтаар дамжуулан авах боломжтой хэвээр байна.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Давтагчийн элементүүдийг арын хэсгээс эхлэн нэг, эцсийн утга болгон бууруулдаг давталтын арга.
    ///
    /// Энэ бол [`Iterator::fold()`]-ийн урвуу хувилбар юм: давталтын арын хэсгээс эхлэн элементүүдийг авдаг.
    ///
    /// `rfold()` гэсэн хоёр аргумент шаардагдана: эхний утга ба 'accumulator' ба элемент гэсэн хоёр аргумент бүхий хаалт.
    /// Хаах нь аккумляторын дараагийн давталтад байх ёстой утгыг буцааж өгдөг.
    ///
    /// Эхний утга нь аккумляторын анхны дуудлага дээр гарах утга юм.
    ///
    /// Энэхүү хаалтыг давталтын элемент бүрт хэрэглэсний дараа `rfold()` нь аккумляторыг буцааж өгдөг.
    ///
    /// Энэ үйлдлийг заримдаа 'reduce' эсвэл 'inject' гэж нэрлэдэг.
    ///
    /// Эвхэх нь танд ямар нэгэн зүйлийн цуглуулга байхад хэрэгтэй байдаг бөгөөд үүнээс ганц үнэ цэнэ бий болгохыг хүсдэг.
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // а-ийн бүх элементүүдийн нийлбэр
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Энэ жишээнд эхний утгаас эхлээд элемент тус бүрийг ар талаас урд тал хүртэл үргэлжлүүлэн мөрийг бүтээнэ.
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Урьдчилгааг хангасан давталтын элементийг ар талаас нь хайж олох.
    ///
    /// `rfind()` `true` эсвэл `false` буцаах хаалтыг авдаг.
    /// Энэ хаалтыг давталтын элемент бүрт төгсгөлөөс нь эхлэн хэрэгжүүлдэг бөгөөд хэрэв тэдгээрийн аль нэг нь `true`-ийг буцаадаг бол `rfind()` нь [`Some(element)`]-ийг буцаана.
    /// Хэрэв тэд бүгд `false`-ийг буцаадаг бол [`None`]-ийг буцаадаг.
    ///
    /// `rfind()` богино холболт;өөрөөр хэлбэл, хаалт `true`-ийг буцааж авмагц боловсруулалтыг зогсооно.
    ///
    /// `rfind()` нь лавлагаа авдаг тул олон давталтууд нь лавлагаагаар давтагддаг тул энэ нь нэмэлт маргаан болох маргаантай нөхцөл байдалд хүргэдэг.
    ///
    /// Та энэ нөлөөг `&&x` ашиглан доорх жишээнүүдээс харж болно.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Эхний `true` дээр зогсох:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // Илүү олон элемент байгаа тул бид `iter`-ийг ашиглаж болно.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}