/// Түүний уртыг яг нарийн мэддэг давталт.
///
/// Олон ["Итератор"] хэдэн удаа давтахаа мэдэхгүй байгаа ч зарим нь үүнийг хийдэг.
/// Хэрэв давталт нь хэдэн удаа давтаж болохыг мэддэг бол тухайн мэдээлэлд нэвтрэх боломжийг олгох нь ашигтай байж болох юм.
/// Жишээлбэл, хэрэв та арагшаа давтахыг хүсч байвал төгсгөл хаана байгааг мэдэх нь сайн эхлэл юм.
///
/// `ExactSizeIterator`-ийг хэрэгжүүлэхдээ та [`Iterator`]-ийг хэрэгжүүлэх ёстой.
/// Үүнийг хийхдээ [`Iterator::size_hint`] * хэрэгжүүлэлт нь давталтын яг хэмжээг буцааж өгөх ёстой.
///
/// [`len`] арга нь анхдагч хэрэгжүүлэлттэй байдаг тул та үүнийг хэрэгжүүлэх ёсгүй.
/// Гэсэн хэдий ч, та анхдагчаас илүү гүйцэтгэлтэй гүйцэтгэлийг хангаж чадах тул энэ тохиолдолд үүнийг хүчингүй болгох нь утга учиртай болно.
///
///
/// Энэхүү trait нь аюулгүй trait тул буцаасан урт нь зөв болохыг баталгаажуулахгүй *бөгөөд* чадахгүй гэдгийг анхаарна уу.
/// Энэ нь `unsafe` код ** нь [`Iterator::size_hint`]-ийн зөв байдалд найдах ёсгүй гэсэн үг юм.
/// Тогтворгүй, аюултай [`TrustedLen`](super::marker::TrustedLen) trait нь энэхүү нэмэлт баталгааг өгдөг.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Үндсэн хэрэглээ:
///
/// ```
/// // хязгаарлагдмал муж хэдэн удаа давтахыг яг таг мэддэг
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] дээр бид [`Iterator`]-ийг хэрэгжүүлсэн, `Counter`.
/// Үүний тулд `ExactSizeIterator`-ийг хэрэгжүүлцгээе:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Бид үлдсэн давталтын тоог хялбархан тооцоолох боломжтой.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Одоо бид үүнийг ашиглаж болно!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Давтагчийн яг уртыг буцаана.
    ///
    /// Хэрэгжилт нь давталт нь [`None`]-ийг буцааж өгөхөөс өмнө [`Some(T)`]-ийн утгаас яг `len()` дахин эргэж ирэхийг баталгаажуулдаг.
    ///
    /// Энэ арга нь анхдагч хэрэгжүүлэлттэй байдаг тул та үүнийг шууд хэрэгжүүлэх ёсгүй.
    /// Гэсэн хэдий ч, хэрэв та илүү үр дүнтэй хэрэгжүүлэлтийг хангаж чадвал үүнийг хийж чадна.
    /// Жишээ авахын тулд [trait-level] документыг үзнэ үү.
    ///
    /// Энэ функц нь [`Iterator::size_hint`] функцтэй ижил аюулгүй байдлын баталгаатай байдаг.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// // хязгаарлагдмал муж хэдэн удаа давтахыг яг таг мэддэг
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Энэ нотолгоо нь хэтэрхий хамгаалалттай боловч өөрчлөгдөөгүй байдлыг шалгадаг
        // trait баталгаатай.
        // Хэрэв энэ trait нь rust-дотоод байсан бол бид debug_assert ашиглаж болно !;assert_eq!бүх Rust хэрэглэгчийн хэрэгжилтийг шалгах болно.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Давталжуулагч хоосон байвал `true`-ийг буцаана.
    ///
    /// Энэ арга нь [`ExactSizeIterator::len()`] ашиглан анхдагч хэрэгжүүлэлттэй тул та өөрөө хэрэгжүүлэх шаардлагагүй болно.
    ///
    ///
    /// # Examples
    ///
    /// Үндсэн хэрэглээ:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}