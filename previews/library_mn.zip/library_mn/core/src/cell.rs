//! Хуваалцах боломжтой хуванцар сав.
//!
//! Rust санах ойн аюулгүй байдал нь дараахь дүрмийг үндэслэнэ: `T` объектын хувьд зөвхөн дараахь зүйлсийн аль нэгийг ашиглах боломжтой.
//!
//! - (`&T`) объектод хэд хэдэн өөрчлөгдөхгүй лавлагаа өгөх (үүнийг **aliasing** гэж нэрлэдэг).
//! - Тухайн объектын талаар нэг өөрчлөгдөж болохуйц лавлагаа ("&mut T`") байх (үүнийг **хувирамтгай байдал** гэж нэрлэдэг).
//!
//! Үүнийг Rust хөрвүүлэгч хэрэгжүүлдэг.Гэсэн хэдий ч, энэ дүрэм хангалттай уян хатан биш байх тохиолдол байдаг.Заримдаа обьектын талаар олон удаа иш татсан байхад түүнийг өөрчлөх шаардлагатай байдаг.
//!
//! Хуваалцдаг өөрчлөгдөх боломжтой савнууд нь өөрчлөгдөх боломжтой байсан ч өөрчлөгдөж өөрчлөгдөх боломжтой байдаг.[`Cell<T>`] ба [`RefCell<T>`] хоёулаа үүнийг нэг урсгалтай аргаар хийх боломжийг олгодог.
//! Гэсэн хэдий ч `Cell<T>` эсвэл `RefCell<T>` хоёулаа утас аюулгүй байдаг (тэд [`Sync`]-ийг хэрэгжүүлдэггүй).
//! Хэрэв та олон тооны урсгалуудын хооронд хувиргах, мутаци хийх шаардлагатай бол [`Mutex<T>`], [`RwLock<T>`] эсвэл [`atomic`] төрлийг ашиглах боломжтой.
//!
//! `Cell<T>` ба `RefCell<T>` төрлийн утгыг хуваалцсан лавлагаагаар мутацид оруулж болно (өөрөөр хэлбэл
//! нийтлэг `&T` төрөл), харин ихэнх Rust төрлийг зөвхөн өвөрмөц (`&mut T`) лавлагаагаар мутацлах боломжтой.
//! `Cell<T>` ба `RefCell<T>` нь "удамшлын хувирамтгай байдал"-ыг харуулдаг ердийн Rust төрлүүдээс ялгаатай нь "дотоод хувирал" өгдөг.
//!
//! Эсийн төрлүүд нь `Cell<T>` ба `RefCell<T>` гэсэн хоёр амттай байдаг.`Cell<T>` нь `Cell<T>`-ээс дотогшоо шилжих замаар дотоод өөрчлөлтийг хэрэгжүүлдэг.
//! Үнэлгээний оронд лавлагаа ашиглахын тулд мутаци хийхээс өмнө бичих түгжээг олж авахын тулд `RefCell<T>` төрлийг ашиглах хэрэгтэй.`Cell<T>` нь одоогийн дотоод утгыг олж авах, өөрчлөх аргуудыг өгдөг.
//!
//!  - [`Copy`]-ийг хэрэгжүүлдэг төрлүүдийн хувьд [`get`](Cell::get) арга нь одоогийн дотоод утгыг гаргаж авдаг.
//!  - [`Default`]-ийг хэрэгжүүлж буй төрлүүдийн хувьд [`take`](Cell::take) арга нь одоогийн дотоод утгыг [`Default::default()`]-ээр сольж, сольсон утгыг буцаана.
//!  - Бүх төрлүүдийн хувьд [`replace`](Cell::replace) арга нь одоо байгаа дотоод утгыг орлож, сольсон утгыг буцааж өгөх ба [`into_inner`](Cell::into_inner) арга нь `Cell<T>`-ийг зарцуулж, дотоод утгыг буцаана.
//!  Нэмж дурдахад [`set`](Cell::set) арга нь дотоод утгыг орлож, солигдсон утгыг бууруулдаг.
//!
//! `RefCell<T>` "динамик зээл"-ийг хэрэгжүүлэхийн тулд Rust-ийн амьдралын хугацааг ашигладаг бөгөөд энэ нь дотоод үнэ цэнэд түр, онцгой, өөрчлөгдөх хандалтыг шаардах үйл явц юм.
//! RefCell-т зээлдэг<T>Rust-ийн төрөлхийн лавлагааны төрлүүдээс ялгаатай нь хөрвүүлэх үед статик байдлаар хянагддаг тул "ажиллуулах үед" хянагддаг.
//! `RefCell<T>` зээл нь динамик тул аль хэдийн харилцан уялдаатайгаар зээлсэн үнэ цэнийг авахыг оролдох боломжтой;Энэ нь panic утас үүсгэдэг.
//!
//! # Дотоод хувирамтгай чанарыг хэзээ сонгох вэ
//!
//! Утга өөрчлөгдөх өвөрмөц хандалттай байх ёстой илүү түгээмэл удамшлын хувирал нь Rust-ийг заагчийг солих талаар хүчтэй эргэцүүлж, ослын алдаанаас урьдчилан сэргийлэх боломжийг олгодог хэлний гол элементүүдийн нэг юм.
//! Ийм учраас удамшлын өөрчлөлтийг илүүд үздэг бөгөөд дотоод хувирал нь хамгийн эцсийн арга зам юм.
//! Нүдний төрлүүд нь мутацийг өөрөөр зөвшөөрөхгүй байх нөхцлийг бүрдүүлдэг тул дотоод хувирал тохирох эсвэл бүр *ашиглах* шаардлагатай тохиолдол байдаг.
//!
//! * 'inside'-ийн өөрчлөгдөх чадварыг танилцуулж байна
//! * Логик-өөрчлөгдөхгүй аргуудын хэрэгжилтийн нарийвчилсан мэдээлэл.
//! * [`Clone`]-ийн өөрчлөлтүүд.
//!
//! ## 'inside'-ийн өөрчлөгдөх чадварыг танилцуулж байна
//!
//! [`Rc<T>`], [`Arc<T>`] зэрэг олон хуваалцсан ухаалаг заагчийн төрлүүд нь олон талуудад хувааж, хувааж ашиглах боломжтой савыг өгдөг.
//! Оруулсан утгууд нь олон янзын байж болох тул тэдгээрийг `&mut` биш харин зөвхөн `&`-ээр зээлж авах боломжтой.
//! Нүдгүйгээр эдгээр ухаалаг заагч доторх өгөгдлийг мутацлах боломжгүй юм.
//!
//! Хувьсах чадварыг сэргээхийн тулд `RefCell<T>`-ийг хуваалцсан заагчийн төрлүүдэд оруулах нь түгээмэл байдаг.
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Динамик зээлийн хамрах хүрээг хязгаарлах шинэ блок үүсгэх
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Хэрэв бид кэшийн өмнөх зээлийг үйлчлэх хүрээнээс гадуур байлгахыг зөвшөөрөөгүй бол дараагийн зээл нь panic динамик урсгал үүсгэх болно гэдгийг анхаарна уу.
//!     //
//!     // Энэ бол `RefCell`-ийг ашиглах гол аюул юм.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Энэ жишээнд `Arc<T>` биш `Rc<T>` ашигладаг болохыг анхаарна уу.RefCell<T>нь ганц урсгалтай хувилбаруудад зориулагдсан болно.Хэрэв танд олон урсгалтай нөхцөлд хувьсах өөрчлөлт шаардлагатай бол [`RwLock<T>`] эсвэл [`Mutex<T>`] ашиглах талаар бодож үзээрэй.
//!
//! ## Логик-өөрчлөгдөхгүй аргуудын хэрэгжилтийн нарийвчилсан мэдээлэл
//!
//! Заримдаа API дээр "under the hood" мутаци болж байгааг ил гаргахгүй байх нь зүйтэй болов уу.
//! Энэ нь логикийн хувьд үйл ажиллагаа нь өөрчлөгддөггүй байж болох юм, гэхдээ жишээ нь кэш хийх нь мутацийг хэрэгжүүлэхийг албаддаг;эсвэл `&self` авахаар анх тодорхойлсон trait аргыг хэрэгжүүлэхийн тулд та мутацийг ашиглах ёстой.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Үнэтэй тооцоолол энд ордог
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone`-ийн өөрчлөлтүүд
//!
//! Энэ бол ердөө л урьд өмнө тохиолдсон онцгой, гэхдээ нийтлэг тохиолдол бөгөөд өөрчлөгдөхгүй мэт санагдах үйлдлүүдийн хувирамтгай байдлыг нуух явдал юм.
//! [`clone`](Clone::clone) арга нь эх утгыг өөрчлөхгүй гэж тооцож байгаа бөгөөд `&mut self` биш харин `&self`-ийг авахаар тунхаглаж байна.
//! Тиймээс `clone` аргад тохиолддог аливаа мутаци нь эсийн төрлийг ашиглах ёстой.
//! Жишээлбэл, [`Rc<T>`] нь `Cell<T>` дотор лавлагаа тооллогоо хадгалдаг.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Санах ойг өөрчлөх боломжтой байршил.
///
/// # Examples
///
/// Энэ жишээн дээр `Cell<T>` нь өөрчлөгдөхгүй бүтцийн доторх мутацийг идэвхжүүлж байгааг харж болно.
/// Өөрөөр хэлбэл, энэ нь "interior mutability"-ийг идэвхжүүлдэг.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // АЛДАА: `my_struct` нь өөрчлөгдөхгүй
/// // my_struct.regular_field =шинэ_ утга;
///
/// // АЖИЛЛАХ: хэдийгээр `my_struct` нь өөрчлөгддөггүй боловч `special_field` нь `Cell`,
/// // үргэлж өөрчлөгдөж болох юм
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Дэлгэрэнгүйг [module-level documentation](self)-с үзнэ үү.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T-ийн хувьд `Default` утгатай `Cell<T>` үүсгэдэг.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Өгөгдсөн утгыг агуулсан шинэ `Cell` үүсгэдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Оруулсан утгыг тохируулна.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Хоёр нүдний утгыг солино.
    /// `std::mem::swap`-ийн ялгаа нь энэ функцэд `&mut` лавлагаа шаарддаггүй явдал юм.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // АЮУЛГҮЙ БАЙДАЛ: Хэрэв тусдаа утаснаас дуудвал эрсдэлтэй байж болох ч `Cell`
        // нь `!Sync` тул ийм зүйл болохгүй.
        // Энэ нь мөн ямар ч заагчийг хүчингүй болгохгүй тул `Cell` нь эдгээр "Cell`s"-ийн аль нэгэнд нь өөр зүйл зааж өгөхгүй байхыг баталгаажуулдаг.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Агуулагдсан утгыг `val`-ээр сольж, хуучин агуулгыг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // АЮУЛГҮЙ БАЙДАЛ: Энэ нь тусдаа утаснаас дуудвал өгөгдлийн уралдаан үүсгэж болзошгүй,
        // гэхдээ `Cell` бол `!Sync` тул ийм зүйл болохгүй.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Утгыг задална.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Агуулагдсан утгын хуулбарыг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // АЮУЛГҮЙ БАЙДАЛ: Энэ нь тусдаа утаснаас дуудвал өгөгдлийн уралдаан үүсгэж болзошгүй,
        // гэхдээ `Cell` бол `!Sync` тул ийм зүйл болохгүй.
        unsafe { *self.value.get() }
    }

    /// Агуулагдсан утгыг функц ашиглан шинэчилж, шинэ утгыг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Энэ нүдэнд байгаа өгөгдөл рүү түүхий заагчийг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Суурь өгөгдлийн өөрчлөгдөж болох лавлагааг буцаана.
    ///
    /// Энэ дуудлага нь `Cell`-ийг харилцан тохиролцон зээлж авах боломжтой (нэгтгэх үед) бөгөөд энэ нь цорын ганц лавлагаа бидэнд байгаа гэдгийг баталгаажуулна.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T`-ээс `&Cell<T>` буцаана
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // Аюулгүй байдал: `&mut` нь өвөрмөц хандалтыг баталгаажуулдаг.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Нүдний утгыг авч `Default::default()`-ийг оронд нь үлдээнэ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>`-ээс `&[Cell<T>]` буцаана
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // АЮУЛГҮЙ БАЙДАЛ: `Cell<T>` нь `T`-тэй ижил санах ойн зохион байгуулалттай байдаг.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Зээлийн дүрмийг динамикаар шалгасан, өөрчлөгдөх боломжтой санах ойн байршил
///
/// Дэлгэрэнгүйг [module-level documentation](self)-с үзнэ үү.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] буцааж өгсөн алдаа.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] буцааж өгсөн алдаа.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Эерэг утга нь идэвхтэй `Ref` тоог илэрхийлнэ.Сөрөг утга нь `RefMut` идэвхтэй тоог илэрхийлнэ.
// Олон тооны RefMut нь `RefCell`-ийн ялгаатай, хоорондоо давхцалгүй бүрэлдэхүүн хэсгүүдийг (жишээлбэл, зүсмэлийн янз бүрийн муж) дурдсан тохиолдолд л идэвхтэй байх боломжтой.
//
// `Ref` болон `RefMut` нь хоёулаа хоёр үгний хэмжээтэй тул `usize` мужийн тэн хагасыг давах хангалттай `Ref`s эсвэл`RefMut` байхгүй байх болно.
// Тиймээс `BorrowFlag` нь хэзээ ч халихгүй эсвэл халихгүй байх магадлалтай.
// Гэхдээ энэ нь баталгаа биш, учир нь эмгэг судлалын програм нь mem::forget `Ref`s эсвэл`RefMut`s-ийг дахин дахин үүсгэж болзошгүй юм.
// Тиймээс аюулгүй байдал алдагдахаас зайлсхийх, эсвэл халих эсвэл халих тохиолдол гарсан тохиолдолд ядаж зөв ажиллахын тулд бүх кодууд халих, халих эсэхийг тодорхой шалгаж байх ёстой (жишээлбэл, BorrowRef::new-г үзнэ үү).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` агуулсан шинэ `RefCell` үүсгэдэг.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell`-ийг зарцуулж, боосон утгыг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Энэ функц нь `self` (`RefCell`)-ийг утгаар нь авдаг тул хөрвүүлэгч нь одоогоор зээллэгдээгүй гэдгийг статикаар баталгаажуулдаг.
        //
        self.value.into_inner()
    }

    /// Боодолтой утгыг шинэ утгаар сольж, хуучин утгыг буцааж, аль нэгийг нь буцаахгүйгээр солино.
    ///
    ///
    /// Энэ функц нь [`std::mem::replace`](../mem/fn.replace.html)-тэй тохирч байна.
    ///
    /// # Panics
    ///
    /// Хэрэв үнэ цэнийг одоо зээлж авсан бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Ороосон утгыг `f`-ээс тооцоолсон шинэ утгаар сольж, хуучин утгыг буцааж өгөхгүй.
    ///
    ///
    /// # Panics
    ///
    /// Хэрэв үнэ цэнийг одоо зээлж авсан бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `self`-ийн боосон утгыг `other`-ийн оролтын утгыг хоёуланг нь солихгүйгээр солино.
    ///
    ///
    /// Энэ функц нь [`std::mem::swap`](../mem/fn.swap.html)-тэй тохирч байна.
    ///
    /// # Panics
    ///
    /// Хэрэв `RefCell`-ийн аль нэгнийх нь утгыг одоо зээлж авсан бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Боодолтой үнэ цэнийг үл хөдлөх байдлаар зээлдэг.
    ///
    /// Зээл нь буцаж ирсэн `Ref` хүрээнээс гарах хүртэл үргэлжилнэ.
    /// Олон өөрчлөгдөхгүй зээлийг нэгэн зэрэг гаргаж болно.
    ///
    /// # Panics
    ///
    /// Хэрэв утга нь одоогоор харилцан зээллэгдэж байгаа бол Panics.
    /// Сандардаггүй хувилбарын хувьд [`try_borrow`](#method.try_borrow)-ийг ашиглаарай.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic-ийн жишээ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Боодолтой утгыг үл хөдлөх байдлаар зээлж авдаг бөгөөд хэрэв үнэ цэнийг одоо зээлж авах боломжтой бол алдаа буцаана.
    ///
    ///
    /// Зээл нь буцаж ирсэн `Ref` хүрээнээс гарах хүртэл үргэлжилнэ.
    /// Олон өөрчлөгдөхгүй зээлийг нэгэн зэрэг гаргаж болно.
    ///
    /// Энэ бол [`borrow`](#method.borrow)-ийн сандардаггүй хувилбар юм.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // АЮУЛГҮЙ БАЙДАЛ: `BorrowRef` нь зөвхөн өөрчлөгдөөгүй хандалтыг хангаж өгдөг
            // зээл авч байх үеийн үнэ цэнэ хүртэл.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Боодолтой үнэ цэнийг харилцан уялдаатай зээлдэг.
    ///
    /// Зээл нь буцаж ирсэн `RefMut` буюу түүнээс гарсан бүх `RefMut`-ийг авах хүртэл үргэлжилнэ.
    ///
    /// Энэхүү зээл идэвхтэй байх үед үнэ цэнийг зээлэх боломжгүй юм.
    ///
    /// # Panics
    ///
    /// Хэрэв үнэ цэнийг одоо зээлж авсан бол Panics.
    /// Сандардаггүй хувилбарын хувьд [`try_borrow_mut`](#method.try_borrow_mut)-ийг ашиглаарай.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic-ийн жишээ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Боодолтой утгыг харилцан уялдаатайгаар зээлж, хэрэв тухайн зээлийг зээлж авсан бол алдаа буцаана.
    ///
    ///
    /// Зээл нь буцаж ирсэн `RefMut` буюу түүнээс гарсан бүх `RefMut`-ийг авах хүртэл үргэлжилнэ.
    /// Энэхүү зээл идэвхтэй байх үед үнэ цэнийг зээлэх боломжгүй юм.
    ///
    /// Энэ бол [`borrow_mut`](#method.borrow_mut)-ийн сандралгүй хувилбар юм.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // Аюулгүй байдал: `BorrowRef` нь өвөрмөц хандалтыг баталгаажуулдаг.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Энэ нүдэнд байгаа өгөгдөл рүү түүхий заагчийг буцаана.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Суурь өгөгдлийн өөрчлөгдөж болох лавлагааг буцаана.
    ///
    /// Энэ дуудлага нь `RefCell`-ийг харилцан хөрвүүлэх замаар (хөрвүүлэх үед) зээлдэг тул динамик шалгалт хийх шаардлагагүй болно.
    ///
    /// Гэсэн хэдий ч болгоомжтой байх хэрэгтэй: энэ арга нь `self`-ийг өөрчлөгдөх боломжтой гэж үздэг бөгөөд энэ нь `RefCell`-ийг ашиглахад ерөнхийдөө тийм байдаггүй.
    ///
    /// Хэрэв `self` нь өөрчлөгдөх боломжгүй бол оронд нь [`borrow_mut`] аргыг үзээрэй.
    ///
    /// Түүнчлэн, энэхүү арга нь зөвхөн онцгой нөхцөл байдалд зориулагдсан бөгөөд ихэнхдээ таны хүссэн зүйл биш гэдгийг анхаарна уу.
    /// Хэрэв эргэлзэж байгаа бол оронд нь [`borrow_mut`] ашиглана уу.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Алдагдсан хамгаалагчдын `RefCell`-ийн зээлийн төлөв байдалд үзүүлэх нөлөөг арилгах.
    ///
    /// Энэ дуудлага нь [`get_mut`]-тэй төстэй боловч илүү мэргэшсэн байна.
    /// Энэ нь `RefCell`-ийг харилцан уялдаатайгаар зээлж, зээл авахгүй байх нөхцлийг бүрдүүлдэг бөгөөд дараа нь улсын хяналтыг хуваалцах зээлийг дахин тохируулдаг.
    /// Хэрэв зарим `Ref` эсвэл `RefMut` зээлүүд алдагдсан бол энэ нь хамааралтай болно.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Боодолтой утгыг үл хөдлөх байдлаар зээлж авдаг бөгөөд хэрэв үнэ цэнийг одоо зээлж авах боломжтой бол алдаа буцаана.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow`-ээс ялгаатай нь энэ арга нь `Ref`-ийг буцаадаггүй тул зээлийн тугийг хөндөөгүй үлдээх тул аюултай байдаг.
    /// Энэ аргаар буцааж өгсөн лавлагаа амьд байхад `RefCell`-ийг харилцан зээлж авах нь тодорхойгүй зан байдал юм.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // АЮУЛГҮЙ АЖИЛЛАГАА: Одоо хэн ч идэвхтэй бичихгүй байгаа эсэхийг шалгаж байна, гэхдээ тийм байна
            // буцааж өгсөн лавлагаа ашиглахаа болих хүртэл хэн ч бичихгүй байхыг баталгаажуулах үүрэгтэй дуудлага хийгчийн үүрэг.
            // Түүнчлэн, `self.value.get()` нь `self`-ийн эзэмшдэг утгыг хэлдэг бөгөөд `self`-ийн ашиглалтын хугацаанд хүчинтэй байх баталгаа юм.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// `Default::default()`-ийг оронд нь үлдээж ороосон утгыг авна.
    ///
    /// # Panics
    ///
    /// Хэрэв үнэ цэнийг одоо зээлж авсан бол Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Хэрэв утга нь одоогоор харилцан зээллэгдэж байгаа бол Panics.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// T-ийн хувьд `Default` утгатай `RefCell<T>` үүсгэдэг.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Хэрэв `RefCell`-ийн аль нэгнийх нь утгыг одоо зээлж авсан бол Panics.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Хэрэв `RefCell`-ийн аль нэгнийх нь утгыг одоо зээлж авсан бол Panics.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Хэрэв `RefCell`-ийн аль нэгнийх нь утгыг одоо зээлж авсан бол Panics.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Хэрэв `RefCell`-ийн аль нэгнийх нь утгыг одоо зээлж авсан бол Panics.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Хэрэв `RefCell`-ийн аль нэгнийх нь утгыг одоо зээлж авсан бол Panics.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Хэрэв `RefCell`-ийн аль нэгнийх нь утгыг одоо зээлж авсан бол Panics.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Хэрэв `RefCell`-ийн аль нэгнийх нь утгыг одоо зээлж авсан бол Panics.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Зээлийг нэмэгдүүлэх нь дараах тохиолдолд унших боломжгүй утгад (<=0) хүргэж болзошгүй юм.
            // 1. Энэ нь <0 байсан, өөрөөр хэлбэл бичих зээлүүд байгаа тул Rust-ийн лавлагаа хаях дүрмийн улмаас унших зээлийг зөвшөөрөх боломжгүй.
            // 2.
            // Энэ нь isize::MAX (унших зээлийн хамгийн их хэмжээ) байсан бөгөөд isize::MIN (бичгийн зээлийн хамгийн их хэмжээ) болж хальсан тул isize нь маш олон уншсан зээлийг төлөөлж чадахгүй тул бид нэмэлт унших зээл авахыг зөвшөөрөхгүй (энэ нь зөвхөн ийм тохиолдолд л тохиолдож болно) та mem::forget бага хэмжээний тогтмол хэмжээнээс илүү, энэ нь тийм ч сайн туршлага биш юм)
            //
            //
            //
            //
            None
        } else {
            // Зээлийг нэмэгдүүлэх нь дараах тохиолдолд унших утгыг (> 0) нэмэгдүүлэх боломжтой:
            // 1. Энэ нь=0 байсан, өөрөөр хэлбэл зээл аваагүй бөгөөд бид эхний уншсан зээлийг авч байна
            // 2. Энэ нь> 0 ба <isize::MAX байсан, өөрөөр хэлбэл
            // Уншсан зээлүүд байсан бөгөөд дахин нэг унших зээл авах боломжтойг илэрхийлэх хангалттай хэмжээтэй байна
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Энэ Ref байдаг тул бид зээлийн туг нь унших зээл гэдгийг мэддэг.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Зээлийн тоолуурыг бичгээр авсан зээл рүү халихаас урьдчилан сэргийлэх.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// `RefCell` хайрцагт байгаа утгын талаар зээлсэн лавлагааг боож өгнө.
/// `RefCell<T>`-ээс үл өөрчлөгдөхийн тулд зээлсэн үнэ цэнэтэй боодлын төрөл.
///
/// Дэлгэрэнгүйг [module-level documentation](self)-с үзнэ үү.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// `Ref` хуулбарлана.
    ///
    /// `RefCell` нь аль хэдийн өөрчлөгдөөгүй зээл авсан тул бүтэлгүйтэх боломжгүй юм.
    ///
    /// Энэ нь `Ref::clone(...)` хэлбэрээр ашиглах шаардлагатай холбогдох функц юм.
    /// `Clone`-ийн хэрэгжилт эсвэл арга нь `RefCell`-ийн агуулгыг хуулбарлахын тулд `r.borrow().clone()`-ийг өргөн ашиглахад саад болно.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Зээл авсан мэдээллийн бүрэлдэхүүн хэсэгт зориулж шинэ `Ref` гаргадаг.
    ///
    /// `RefCell` нь аль хэдийн өөрчлөгдөөгүй зээл авсан тул бүтэлгүйтэх боломжгүй юм.
    ///
    /// Энэ нь `Ref::map(...)` хэлбэрээр ашиглах шаардлагатай холбогдох функц юм.
    /// Арга нь `Deref`-ээр дамжуулан ашигладаг `RefCell`-ийн агуулга дээрх ижил нэртэй аргуудад саад болох болно.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Зээл авсан өгөгдлийн нэмэлт бүрэлдэхүүн хэсэгт зориулж шинэ `Ref` гаргадаг.
    /// Анхны хамгаалалтыг `None` болгож хаах тохиолдолд `Err(..)` болгон буцаана.
    ///
    /// `RefCell` нь аль хэдийн өөрчлөгдөөгүй зээл авсан тул бүтэлгүйтэх боломжгүй юм.
    ///
    /// Энэ нь `Ref::filter_map(...)` хэлбэрээр ашиглах шаардлагатай холбогдох функц юм.
    /// Арга нь `Deref`-ээр дамжуулан ашигладаг `RefCell`-ийн агуулга дээрх ижил нэртэй аргуудад саад болох болно.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Зээл авсан өгөгдлийн өөр бүрэлдэхүүн хэсгүүдийн хувьд `Ref`-ийг олон `Ref`-д хуваана.
    ///
    /// `RefCell` нь аль хэдийн өөрчлөгдөөгүй зээл авсан тул бүтэлгүйтэх боломжгүй юм.
    ///
    /// Энэ нь `Ref::map_split(...)` хэлбэрээр ашиглах шаардлагатай холбогдох функц юм.
    /// Арга нь `Deref`-ээр дамжуулан ашигладаг `RefCell`-ийн агуулга дээрх ижил нэртэй аргуудад саад болох болно.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Суурь өгөгдлийн лавлагаа болгон хөрвүүлэх.
    ///
    /// Суурь `RefCell`-ийг хэзээ ч харилцан солилцоотойгоор зээлж авах боломжгүй бөгөөд үргэлж өөрчлөгдөөгүй зээлсэн мэт харагдах болно.
    ///
    /// Тогтмол тооны лавлагаанаас илүү мэдээлэл цацах нь тийм ч сайн санаа биш юм.
    /// Нийт цөөн тооны алдагдал гарсан тохиолдолд `RefCell`-ийг дахин зээлж авах боломжтой.
    ///
    /// Энэ нь `Ref::leak(...)` хэлбэрээр ашиглах шаардлагатай холбогдох функц юм.
    /// Арга нь `Deref`-ээр дамжуулан ашигладаг `RefCell`-ийн агуулга дээрх ижил нэртэй аргуудад саад болох болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Энэхүү Ref-г мартсанаар бид RefCell дахь зээлийн тоолуурыг ашиглалтын хугацаандаа `'b` хугацаанд АШИГЛАСАН руу буцах боломжгүй болно.
        // Лавлагаа хянах төлөвийг дахин тохируулахын тулд зээлсэн RefCell-ийн талаархи өвөрмөц лавлагаа шаардагдана.
        // Анхны нүднээс өөр өөрчлөгдөх боломжтой лавлагаа үүсгэх боломжгүй.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Зээл авсан өгөгдлийн бүрэлдэхүүн хэсэг, жишээлбэл, enum хувилбарын хувьд шинэ `RefMut` хийдэг.
    ///
    /// `RefCell` загварыг аль хэдийн харилцан зээлж авсан тул бүтэлгүйтэх боломжгүй юм.
    ///
    /// Энэ нь `RefMut::map(...)` хэлбэрээр ашиглах шаардлагатай холбогдох функц юм.
    /// Арга нь `Deref`-ээр дамжуулан ашигладаг `RefCell`-ийн агуулга дээрх ижил нэртэй аргуудад саад болох болно.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): зээлийн чекийг засах
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Зээл авсан өгөгдлийн нэмэлт бүрэлдэхүүн хэсэгт зориулж шинэ `RefMut` гаргадаг.
    /// Анхны хамгаалалтыг `None` болгож хаах тохиолдолд `Err(..)` болгон буцаана.
    ///
    /// `RefCell` загварыг аль хэдийн харилцан зээлж авсан тул бүтэлгүйтэх боломжгүй юм.
    ///
    /// Энэ нь `RefMut::filter_map(...)` хэлбэрээр ашиглах шаардлагатай холбогдох функц юм.
    /// Арга нь `Deref`-ээр дамжуулан ашигладаг `RefCell`-ийн агуулга дээрх ижил нэртэй аргуудад саад болох болно.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): зээлийн чекийг засах
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // АЮУЛГҮЙ АЖИЛЛАГАА: функц нь тухайн хугацааны туршид онцгой лавлагаа агуулдаг
        // түүний дуудлага нь `orig`-ээр дамждаг бөгөөд заагч нь зөвхөн функцын дуудлагын дотор хамааралгүй байдаг бөгөөд онцгой лавлагааг гадагшлуулахыг хэзээ ч зөвшөөрдөггүй.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // Аюулгүй байдал: дээрхтэй ижил.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Зээл авсан өгөгдлийн өөр бүрэлдэхүүн хэсгүүдийн хувьд `RefMut`-ийг олон `RefMut`-д хуваана.
    ///
    /// Үүний суурь `RefCell` нь буцаж ирсэн RefMut-ийн аль аль нь үйлчлэх хүрээнээс гарах хүртэл харилцан зээллэг хэвээр үлдэнэ.
    ///
    /// `RefCell` загварыг аль хэдийн харилцан зээлж авсан тул бүтэлгүйтэх боломжгүй юм.
    ///
    /// Энэ нь `RefMut::map_split(...)` хэлбэрээр ашиглах шаардлагатай холбогдох функц юм.
    /// Арга нь `Deref`-ээр дамжуулан ашигладаг `RefCell`-ийн агуулга дээрх ижил нэртэй аргуудад саад болох болно.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Суурь өгөгдлийг өөрчлөх боломжтой лавлагаа болгон хөрвүүлэх.
    ///
    /// Суурь `RefCell`-ийг дахин зээлэх боломжгүй бөгөөд харилцан уялдаатай зээлсэн хэлбэрээр үргэлж гарч ирэх тул буцааж өгсөн лавлагаа нь зөвхөн дотоод засал чимэглэл болно.
    ///
    ///
    /// Энэ нь `RefMut::leak(...)` хэлбэрээр ашиглах шаардлагатай холбогдох функц юм.
    /// Арга нь `Deref`-ээр дамжуулан ашигладаг `RefCell`-ийн агуулга дээрх ижил нэртэй аргуудад саад болох болно.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Энэхүү BorrowRefMut-ийг мартсанаар бид RefCell дахь зээлийн тоолуур нь `'b` ашиглалтын хугацаанд АШИГЛАГДАХ горимд буцаж очих боломжгүй болно.
        // Лавлагаа хянах төлөвийг дахин тохируулахын тулд зээлсэн RefCell-ийн талаархи өвөрмөц лавлагаа шаардагдана.
        // Тухайн хугацааны туршид анхны нүднээс өөр лавлагаа үүсгэх боломжгүй тул одоогийн зээлийг үлдсэн амьдралын цорын ганц лавлагаа болгоно.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone-ээс ялгаатай нь анхны үсгийг үүсгэхийн тулд шинээр дууддаг
        // өөрчлөгдөж болох лавлагаа, тиймээс одоогоор лавлагаа байхгүй байх ёстой.
        // Тиймээс клон нь өөрчлөгдөж болох тооллогыг нэмэгдүүлж байгаа боловч бид зөвхөн UNUSED-ээс UNUSED, 1 рүү шилжихийг зөвшөөрнө.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut`-ийг хуулдаг.
    //
    // Энэ нь зөвхөн `BorrowRefMut` бүрийг анхны объектын давхцалгүй, ялгаатай муж руу шилжих өөрчлөлтийг хянахад ашигласан тохиолдолд л хүчинтэй болно.
    //
    // Энэ нь Clone имплд байхгүй тул код нь үүнийг шууд утгаар дуудахгүй байх болно.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Зээлийн тоолуурыг халихаас урьдчилан сэргийлэх.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>`-ээс харилцан зээлж авсан үнийн хувьд боодлын төрөл.
///
/// Дэлгэрэнгүйг [module-level documentation](self)-с үзнэ үү.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust доторх дотоод хувирамтгай байдлын үндсэн команд.
///
/// Хэрэв танд лавлагаа `&T` байгаа бол Rust дээр хөрвүүлэгч нь `&T` нь өөрчлөгдөхгүй өгөгдлийг зааж өгдөг гэсэн мэдлэг дээр үндэслэн оновчлолыг хийдэг.Энэ өгөгдлийг өөрчлөх, жишээлбэл, өөр нэрээр эсвэл `&T`-ийг `&mut T` болгон хувиргах нь тодорхойлогдоогүй үйлдэл гэж тооцогддог.
/// `UnsafeCell<T>` `&T`-ийн хувиршгүй байдлын баталгаанаас татгалзах: хуваалцсан `&UnsafeCell<T>` лавлагаа нь мутацид орж буй өгөгдлийг зааж өгч болно.Үүнийг "interior mutability" гэж нэрлэдэг.
///
/// `Cell<T>`, `RefCell<T>` гэх мэт дотоод хувирамтгай байдлыг зөвшөөрдөг бусад бүх төрлүүд өөрсдийн өгөгдлийг боохдоо `UnsafeCell`-ийг ашигладаг.
///
/// `UnsafeCell` нь зөвхөн хуваалцсан лавлагааны өөрчлөгдөхгүй байдлын баталгаанд нөлөөлдөг болохыг анхаарна уу.Өөрчлөгдөж болохуйц лавлагааны өвөрмөц байдлын баталгаа нөлөөлөхгүй.`UnsafeCell<T>`-тэй ч хамаагүй `&mut`-ийг ашиглах хууль ёсны арга байхгүй *.
///
/// `UnsafeCell` API нь өөрөө техникийн хувьд маш энгийн: [`.get()`] нь агуулгад нь `*mut T` түүхий заагчийг өгдөг.Тэр түүхий заагчийг зөв ашиглах нь хийсвэрлэлийн дизайнерын хувьд _you_ хүртэл байна.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Нарийвчилсан Rust дүрмүүд нь зарим талаар чөлөөтэй байдаг боловч гол санаа нь маргаантай биш юм.
///
/// - Хэрэв та ашиглалтын хугацааны туршид `'a` (`&T` эсвэл `&mut T` лавлагаа) аюулгүй кодоор нэвтрэх боломжтой аюулгүй лавлагааг бүтээсэн бол (жишээ нь, буцааж өгсөн тул) өгөгдөлд үлдэх хэсэг рүү харшлахгүй байх ёстой. `'a`-ийн.
/// Жишээлбэл, хэрэв та `*mut T`-ийг `UnsafeCell<T>`-ээс аваад `&T` руу шидвэл `T` дээрх өгөгдөл нь өөрчлөгдөхгүй байх ёстой (мэдээж `T`-ээс олдсон `UnsafeCell`-ийн өгөгдлийг модуль болгоно) тухайн лавлагааны ашиглалтын хугацаа дуусах хүртэл.
/// Үүнтэй адилаар, хэрэв та аюулгүй код руу гаргасан `&mut T` лавлагаа үүсгэсэн бол тухайн лавлагааны хугацаа дуустал `UnsafeCell` доторх өгөгдөлд нэвтрэх ёсгүй.
///
/// - Бүх цаг үед та мэдээллийн уралдаанаас зайлсхийх хэрэгтэй.Хэрэв олон урсгал ижил `UnsafeCell` руу нэвтрэх эрхтэй бол бусад бүх хандалттай харьцахаас өмнө (эсвэл атомыг ашиглах) өмнө зохих бичиглэл байх ёстой.
///
/// Зөв зохистой дизайн хийхэд туслахын тулд дараахь хувилбаруудыг нэг урсгалтай кодын хувьд хууль ёсны гэж тунхагласан болно.
///
/// 1. `&T` лавлагааг аюулгүй код руу гаргаж болох бөгөөд энэ нь бусад `&T` лавлагаатай зэрэгцэн орших боломжтой боловч `&mut T`-тэй хамт байхгүй болно.
///
/// 2. `&mut T` лавлагаа бусад `&mut T` ба `&T` хоёулаа хамт байхгүй тохиолдолд аюулгүй код руу гаргаж болно.`&mut T` нь үргэлж өвөрмөц байх ёстой.
///
/// `&UnsafeCell<T>`-ийн агуулгыг мутацлах (хэдийгээр бусад `&UnsafeCell<T>` нүдэнд хуурамч нэр зааж өгсөн ч гэсэн) зүгээр байх болно (хэрэв та дээрх инвариантуудыг өөр аргаар хэрэгжүүлсэн бол), хэд хэдэн `&mut UnsafeCell<T>`-ийн хуурамч нэртэй байх нь тодорхойгүй үйлдэл хэвээр байгааг анхаарна уу.
/// Өөрөөр хэлбэл, `UnsafeCell` бол X0 `&UnsafeCell<_>` лавлагаагаар дамжуулан _shared_ accesses (_i.e._-тэй харилцан үйлчлэлцэх зориулалттай боодол юм);_exclusive_ accesses (_e.g._-тэй харьцахдаа `&mut UnsafeCell<_>`-ээр дамжуулан ямар ч ид шид байдаггүй): эсийн эсвэл ороосон утгыг `&mut` зээл авах хугацаанд өөрчилж болохгүй.
///
/// Үүнийг `&mut T` гаргадаг _safe_ getter болох [`.get_mut()`] accessor харуулдаг.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// `UnsafeCell<_>`-ийн агуулгыг нүдийг нь өөрчилсөн олон лавлагаа байгаа хэдий ч хэрхэн яаж мутацийг өөрчлөхийг харуулсан жишээ энд байна.
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Ижил `x`-д олон/зэрэгцээ/хуваалцсан лавлагаа авах.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // АЮУЛГҮЙ БАЙДАЛ: энэ хүрээнд "x`-ийн агуулгын талаар өөр лавлагаа байхгүй болно,
///     // Тиймээс манайх үр дүнтэй өвөрмөц юм.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- зээл авах-+
///     *p1_exclusive += 27; // |
/// } // <---------- энэ цэгээс хэтэрч чадахгүй -------------------+
///
/// unsafe {
///     // АЮУЛГҮЙ БАЙДАЛ: энэ хүрээнд "x"-ийн агуулгад онцгой хандалт хийхийг хэн ч хүлээхгүй,
///     // Тиймээс бид олон тооны хуваалцсан хандалтыг зэрэг авах боломжтой.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Дараах жишээ нь `UnsafeCell<T>`-т онцгой хандалт нь `T`-т хандах хандалтыг илэрхийлдэг болохыг харуулж байна.
///
/// ```rust
/// #![forbid(unsafe_code)] // онцгой хандалттай,
///                         // `UnsafeCell` нь ил тод сонгодог боодол тул `unsafe` шаардлагагүй болно.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x`-ийн талаархи эмхэтгэлийн цагийг шалгасан өвөрмөц лавлагаа авах.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Онцгой лавлагаагаар бид агуулгыг үнэгүй мутацлах боломжтой.
/// *p_unique.get_mut() = 0;
/// // Эсвэл ижил төстэй байдлаар:
/// x = UnsafeCell::new(0);
///
/// // Бид үнэ цэнийг эзэмшсэн тохиолдолд агуулгыг үнэгүй гаргаж авах боломжтой.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Тодорхойлсон утгыг боох `UnsafeCell`-ийн шинэ жишээг байгуулна.
    ///
    ///
    /// Аргын тусламжтайгаар дотоод үнэ цэнэ рүү нэвтрэх бүх боломж бол `unsafe` юм.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Утгыг задална.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Багцлагдсан утгыг өөрчлөх боломжтой заагчийг авна.
    ///
    /// Үүнийг ямар ч төрлийн заагч руу дамжуулж болно.
    /// `&mut T` руу дамжуулахдаа хандалтын давтагдашгүй байдал (идэвхтэй лавлагаа байхгүй, өөрчлөгдөх боломжтой, өөрчлөгдөөгүй) байх ёстой бөгөөд `&T` руу дамжуулахад мутаци эсвэл хувирамтгай хуурамч зүйл байхгүй байхыг баталгаажуулна уу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] тул бид заагчийг `UnsafeCell<T>`-ээс `T` руу шилжүүлж болно.
        // Энэ нь libstd-ийн тусгай статусыг ашигладаг тул хэрэглэгчийн кодын хувьд хөрвүүлэгчийн future хувилбаруудад ажиллах баталгаа байхгүй болно!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Суурь өгөгдлийн өөрчлөгдөж болох лавлагааг буцаана.
    ///
    /// Энэхүү дуудлага нь `UnsafeCell`-ийг харилцан тохиролцож зээлж авахад зориулагдсан болно.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Багцлагдсан утгыг өөрчлөх боломжтой заагчийг авна.
    /// [`get`]-ийн ялгаа нь энэ функц нь түүхий заагчийг хүлээн авах бөгөөд түр зуурын лавлагаа үүсгэхээс зайлсхийхэд тустай юм.
    ///
    /// Үр дүнг бүх төрлийн заагч руу дамжуулж болно.
    /// `&mut T` руу дамжуулахдаа хандалтын давтагдашгүй байдал (идэвхтэй лавлагаа байхгүй, өөрчлөгдөх боломжтой, өөрчлөгдөөгүй) байх ёстой бөгөөд `&T` руу дамжуулахад мутаци эсвэл өөрчлөгдөж болох хуурамч зүйл байхгүй байхыг баталгаажуулна уу.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell`-ийг аажмаар эхлүүлэх нь `raw_get`-ийг шаарддаг тул `get`-г дуудах нь эхлээгүй өгөгдөлд лавлагаа үүсгэх шаардлагатай болно.
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] тул бид заагчийг `UnsafeCell<T>`-ээс `T` руу шилжүүлж болно.
        // Энэ нь libstd-ийн тусгай статусыг ашигладаг тул хэрэглэгчийн кодын хувьд хөрвүүлэгчийн future хувилбаруудад ажиллах баталгаа байхгүй болно!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T-ийн хувьд `Default` утгатай `UnsafeCell` үүсгэдэг.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}