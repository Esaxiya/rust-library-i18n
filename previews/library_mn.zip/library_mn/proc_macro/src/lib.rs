//! Шинэ макро тодорхойлоход макро зохиогчдод туслах номын сан.
//!
//! Стандарт түгээлтээр хангагдсан энэхүү номын сан нь функцтэй төстэй макро `#[proc_macro]` макро атрибутууд, `#[proc_macro_attribute]` макро атрибутууд ба customive derive attributes`#[proc_macro_derive]"гэх мэт процедурын дагуу тодорхойлогдсон макро тодорхойлолтуудын интерфэйсүүдэд хэрэглэгддэг төрлийг өгдөг.
//!
//!
//! Дэлгэрэнгүйг [the book]-с үзнэ үү.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Proc_macro-г одоо ажиллаж байгаа програмд нэвтрэх боломжтой болгосон эсэхийг тодорхойлно.
///
/// Proc_macro crate нь зөвхөн процедурын макро хэрэгжүүлэхэд зориулагдсан болно.Энэхүү crate panic доторх бүх функцууд нь процедурын макроос гадна, жишээ нь build скрипт эсвэл нэгжийн тест эсвэл ердийн Rust хоёртын файлуудаас дуудагддаг.
///
/// Макро болон макро бус ашиглалтын тохиолдлуудыг дэмжихэд зориулагдсан Rust сангуудын талаар авч үзвэл `proc_macro::is_available()` нь proc_macro API ашиглахад шаардлагатай дэд бүтэц одоо байгаа эсэхийг илрүүлэх паник бус аргыг санал болгодог.
/// Процедурын макро дотроос дуудагдсан тохиолдолд үнэн, бусад хоёртын файлаас дуудах тохиолдолд буцаана.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Энэхүү crate-ийн өгсөн үндсэн төрөл, tokens-ийн хийсвэр урсгал, эсвэл бүр тодруулбал token модны дарааллыг илэрхийлдэг.
/// Энэ төрөл нь тэдгээр token моднуудыг давтах интерфейсүүдийг хангаж, эсрэгээр хэд хэдэн token модыг нэг урсгалд цуглуулдаг.
///
///
/// Энэ бол `#[proc_macro]`, `#[proc_macro_attribute]` ба `#[proc_macro_derive]` тодорхойлолтуудын оролт, гаралтын аль аль нь юм.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str`-с алдаа буцаж ирэв.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token модгүй хоосон `TokenStream` буцаана.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Энэ `TokenStream` хоосон эсэхийг шалгана.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Мөрийг tokens болгон салгаж, tokens-ийг token урсгал руу задлах оролдлогууд.
/// Жишээлбэл, мөрөнд тэнцвэргүй зааглагч эсвэл тухайн хэлэнд байхгүй тэмдэгт агуулсан бол хэд хэдэн шалтгааны улмаас бүтэлгүйтэх магадлалтай.
///
/// Шинжилсэн урсгал дахь бүх tokens нь `Span::call_site()` хугацааг авдаг.
///
/// NOTE: зарим алдаа нь `LexError`-ийг буцаахын оронд panics үүсгэж болзошгүй юм.Эдгээр алдааг бид дараа нь `LexError` болгож өөрчлөх эрхтэй.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, гүүр нь зөвхөн `to_string`-ийг хангаж, `fmt::Display`-ийг хэрэгжүүлдэг (хоёрын ердийн харилцааны урвуу тал).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token урсгалыг алдагдалгүй хөрвөх чадвартай мөр болгон буцааж ижил token урсгалд (модулийн хугацаатай) хэвлэнэ, гэхдээ `Delimiter::None` хязгаарлагч ба сөрөг тоон үсэгтэй "TokenTree: : Group`s-ээс бусад.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// token-ийг дибаг хийхэд тохиромжтой хэлбэрээр хэвлэнэ.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Ганц token модыг агуулсан token урсгалыг үүсгэдэг.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Олон тооны token модыг нэг горхи болгон цуглуулдаг.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token горхи дээрх "flattening" ажиллагаа нь олон тооны token горхиудаас token модыг нэг урсгалд цуглуулдаг.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Боломжтой оновчтой хэрэгжүүлэлтийг if/when ашиглах.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Давталт гэх мэт `TokenStream` төрлийн олон нийтийн хэрэгжилтийн дэлгэрэнгүй мэдээлэл.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `TokenStream`-ийн TokenTree`s-ээр дамжуулагч.
    /// Давталт нь "shallow", жишээлбэл, давталт нь зааглагдсан бүлгүүдэд шилжихгүй бөгөөд бүхэл бүтэн бүлгүүдийг token мод болгон буцаана.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` дурын tokens-ийг хүлээн авч оролтыг дүрсэлсэн `TokenStream` болж өргөждөг.
/// Жишээлбэл, `quote!(a + b)` нь үнэлэхэд `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Үнийн санал авах ажиллагааг `$`-ээр хийдэг бөгөөд дараагийн идентыг үнийн санал ирүүлээгүй нэр томъёогоор авна.
/// `$`-ээс иш татахын тулд `$$` ашиглана уу.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Макро өргөтгөлийн мэдээллийн хамт эх кодын бүс.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Өгөгдсөн `message` бүхий `self` давтамжтайгаар шинэ `Diagnostic` үүсгэдэг.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Макро тодорхойлолтын сайт дээр шийдэгдэх хугацаа.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Одоогийн процедурын макроыг ашиглах хугацаа.
    /// Энэ хугацаанд бүтээгдсэн танигчдыг макро дуудлагын байршил (дуудлагын талбайн эрүүл ахуй) дээр шууд бичсэн мэт шийдэж, макро дуудлагын сайт дээрх бусад кодыг мөн ашиглах боломжтой болно.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` эрүүл ахуйг илэрхийлдэг, заримдаа макро тодорхойлолтын сайт (орон нутгийн хувьсагч, шошго, `$crate`), заримдаа макро дуудлагын сайт (бусад бүх зүйл) дээр шийдэгддэг хугацаа.
    ///
    /// Хугацааны байршлыг дуудлагын сайтаас авсан болно.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Үүнийг зааж өгсөн анхны эх файл.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Хэрэв байгаа бол `self`-ийг үүсгэсэн өмнөх макро өргөтгөлийн tokens-д зориулсан `Span`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self`-ийн үүсгэсэн эх кодын хугацаа.
    /// Хэрэв энэ `Span` нь бусад макро өргөтгөлөөс үүсгээгүй бол буцах утга нь `*self`-тэй ижил байна.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Энэ хугацааны эх файл дахь эхлэл line/column-ийг авдаг.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Энэ хугацааны эх файл дахь төгсгөл line/column-г авна.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` ба `other`-ийг багтаасан шинэ хүрээ үүсгэдэг.
    ///
    /// Хэрэв `self` ба `other` нь өөр өөр файлынх бол `None`-ийг буцаана.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self`-тэй ижил line/column мэдээлэл бүхий шинэ хүрээ үүсгэдэг боловч `other` дээр байгаа мэт тэмдгүүдийг шийддэг.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self`-тэй ижил нэртэй нарийвчлалтай ажиллах чадвартай боловч `other`-ийн line/column мэдээлэлтэй шинэ үеийг бий болгодог.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Тэд тэнцүү байгаа эсэхийг шалгахын тулд харьцуулалт хийдэг.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Хугацааны ард эх бичвэрийг буцаана.
    /// Энэ нь зай, сэтгэгдэл зэрэг анхны эх кодыг хадгална.
    /// Энэ хугацаа нь жинхэнэ эх кодтой тохирч байвал л үр дүнгээ өгдөг.
    ///
    /// Note: Макрогийн ажиглагдах үр дүн нь зөвхөн tokens дээр тулгуурлах ёстой бөгөөд энэ эх текст дээр тулгуурлах ёсгүй.
    ///
    /// Энэ функцын үр дүн нь зөвхөн оношлогоонд ашиглах хамгийн сайн хүчин чармайлт юм.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Хугацааг дибаг хийхэд тохиромжтой хэлбэрээр хэвлэнэ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// `Span`-ийн эхлэл эсвэл төгсгөлийг илэрхийлсэн мөр баганын хос.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// (inclusive) эхлэх ба дуусах эх файлын 1 индексжүүлсэн мөр.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// (inclusive) эхлэх ба дуусах эх файл дахь 0 индексжүүлсэн багана (UTF-8 тэмдэгтээр).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Өгөгдсөн `Span`-ийн эх файл.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Энэ эх файлд хүрэх замыг олж авна.
    ///
    /// ### Note
    /// Хэрэв энэ `SourceFile`-тэй холбоотой кодын хугацааг гадны макро, энэ макро үүсгэсэн бол энэ нь файлын систем дээрх бодит зам биш байж болох юм.
    /// [`is_real`] ашиглан шалгах хэрэгтэй.
    ///
    /// Хэдийгээр `is_real` нь `true`-ийг буцааж өгсөн ч гэсэн `--remap-path-prefix` командын мөрөнд дамжуулсан бол өгсөн зам нь үнэндээ хүчин төгөлдөр бус байж болохыг анхаарна уу.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Хэрэв энэ эх файл нь гадны макро өргөтгөлөөр үүсгээгүй жинхэнэ эх файл бол `true`-ийг буцаана.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Энэ нь завсрын завсарлага хэрэгжих хүртэл хакердсан бөгөөд бид гадны макро дээр үүсгэсэн зайны жинхэнэ эх файлтай байж болно.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Ганц token эсвэл token модны зааглагдсан дараалал (жишээлбэл, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Хаалт заагчаар хүрээлэгдсэн token урсгал.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Тодорхойлогч.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Нэг цэг таслал ("+", `,`, `$` гэх мэт).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Үг үсэг (`'a'`), мөр (`"hello"`), (`2.3`) тоо гэх мэт.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Агуулагдсан token эсвэл хязгаарлагдсан урсгалын `span` аргад шилжүүлэн энэ модны уртыг буцаана.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *Зөвхөн энэ token*-д тохируулах боломжтой.
    ///
    /// Хэрэв энэ token нь `Group` бол энэ арга нь дотоод tokens бүрийн үргэлжлэх хугацааг тохируулахгүй тул энэ нь хувилбар бүрийн `set_span` аргад шилжих болно гэдгийг анхаарна уу.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// token модыг дибаг хийхэд тохиромжтой хэлбэрээр хэвлэнэ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Эдгээр нь тус бүрдээ үүсгэсэн дибаг хийхдээ struct төрлийн нэртэй байдаг тул нэмэлт шууд бус давхаргад санаа зовох хэрэггүй
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, гүүр нь зөвхөн `to_string`-ийг хангаж, `fmt::Display`-ийг хэрэгжүүлдэг (хоёрын ердийн харилцааны урвуу тал).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token модыг алдагдалгүйгээр хөрвөх чадвартай мөр болгон буцааж ижил token модонд (модулийн зайтай) буцааж хэвлэнэ, магадгүй `Delimiter::None` заагчтай, сөрөг тоон үсэг бүхий "TokenTree: : Group`s"-ийг эс тооцвол.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Тусгаарлагдсан token урсгал.
///
/// `Group` нь дотроо X хязгаарлагчаар хүрээлэгдсэн `TokenStream` агуулдаг.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token модны дарааллыг хэрхэн яаж хязгаарлаж байгааг тайлбарлана уу.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Жишээлбэл, "macro variable" `$var`-ээс гарах tokens-ийн эргэн тойронд гарч болох далд хязгаарлагч.
    /// `$var * 3` гэх мэт тохиолдолд операторын тэргүүлэх чиглэлийг хадгалах нь чухал юм.
    /// Тодорхой бус зааглагчид token урсгалаар утас дамжин өнгөрөх үед амьд үлдэхгүй байж магадгүй юм.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Өгөгдсөн зааглагч ба token урсгалаар шинэ `Group` үүсгэдэг.
    ///
    /// Энэхүү байгуулагч нь энэ бүлгийн үргэлжлэх хугацааг `Span::call_site()` болгож тохируулна.
    /// Хугацааг өөрчлөхийн тулд доорх `set_span` аргыг ашиглаж болно.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Энэ `Group`-ийн зааглагчийг буцаана
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Энэ `Group`-д зааглагдсан tokens-ийн `TokenStream`-ийг буцаана.
    ///
    /// Буцаж ирсэн token урсгал дээр дээр буцаан оруулсан заагч ороогүй болохыг анхаарна уу.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Энэ token урсгалын зааглагчийг бүхэлд нь `Group`-т багтаан буцааж өгдөг.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Энэ бүлгийн нээлтийн зааглагчийг зааж өгнө.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Энэ бүлгийн хаалтын заагч руу зааж өгсөн хугацааг буцаана.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Энэ `Group`-ийн зааглагчийн хязгаарыг тохируулах боловч түүний дотоод tokens биш юм.
    ///
    /// Энэ арга нь энэ бүлэгт багтсан бүх дотоод tokens-ийн үргэлжлэх хугацааг ** тогтоох биш харин зөвхөн tokens-ийн хязгаарыг `Group` түвшинд тохируулах болно.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, гүүр нь зөвхөн `to_string`-ийг хангаж, `fmt::Display`-ийг хэрэгжүүлдэг (хоёрын ердийн харилцааны урвуу тал).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Бүлгийг алдагдалгүйгээр хөрвүүлэх боломжтой мөр болгон ижил бүлэгт (модулийн хугацаатай) буцааж хэвлэнэ, гэхдээ `Delimiter::None` хязгаарлагчтай "TokenTree: : Group`s-ээс бусад.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` бол `+`, `-` эсвэл `#` гэх мэт таслал бүхий ганц тэмдэгт юм.
///
/// `+=` гэх мэт олон тэмдэгт операторууд нь `Punct`-ийн хоёр янзын хэлбэрийг буцааж өгсөн `Punct`-ийн хоёр тохиолдол хэлбэрээр төлөөлдөг.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// `Punct`-ийг дараа нь өөр `Punct` эсвэл дараа нь өөр token эсвэл хоосон зайг дагаж мөрдөх эсэх.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// жишээлбэл, `+` бол `+ =`, `+ident` эсвэл `+()` дахь `Alone` юм.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// жишээлбэл, `+` нь `+=` эсвэл `'#` дахь `Joint` юм.
    /// Нэмж дурдахад `'` ганц ишлэл нь танигчтай нэгдэж, `'ident` амьдралын хугацааг бүрдүүлдэг.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Өгөгдсөн тэмдэгт ба зайнаас шинэ `Punct` үүсгэдэг.
    /// `ch` аргумент нь тухайн хэлний зөвшөөрсөн зөв цэг таслал байх ёстой, эс тэгвээс функц panic болно.
    ///
    /// Буцаж ирсэн `Punct` нь анхдагч `Span::call_site()` хугацаатай байх бөгөөд үүнийг доорх `set_span` аргаар тохируулж болно.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Энэ таслал тэмдэгтийн утгыг `char` болгож буцаана.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Энэ таслал тэмдэгтийн зайг буцааж token урсгалд өөр `Punct` дагалдаж байгаа эсэхийг харуулах тул тэдгээрийг олон тэмдэгттэй (`Joint`) операторт нэгтгэх боломжтой, эсвэл дараа нь өөр token эсвэл хоосон орон зайд (`Alone`) оруулах тул оператор нь мэдээжийн хэрэг болно. дууссан.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Энэ таслал тэмдэгтийн хугацааг буцаана.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Энэ цэг таслалыг тохируулна уу.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, гүүр нь зөвхөн `to_string`-ийг хангаж, `fmt::Display`-ийг хэрэгжүүлдэг (хоёрын ердийн харилцааны урвуу тал).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Таслал тэмдэгтийг алдагдалгүйгээр хөрвүүлэх боломжтой мөр болгон хэвлэ.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// (`ident`) танигч.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Өгөгдсөн `string` болон заасан `span`-тэй шинэ `Ident` үүсгэдэг.
    /// `string` аргумент нь тухайн хэлний зөвшөөрсөн хүчинтэй танигч байх ёстой (үүнд түлхүүр үгс орно, жишээлбэл `self` эсвэл `fn`).Үгүй бол функц panic болно.
    ///
    /// `span` нь одоогоор rustc дээр байгаа бөгөөд энэ танигчийн эрүүл ахуйн мэдээллийг тохируулж байгааг анхаарна уу.
    ///
    /// Энэ үеэс эхлэн `Span::call_site()` нь "call-site"-ийн эрүүл ахуйг ил тодоор сонгож байгаа бөгөөд энэ хугацааг үүсгэсэн танигчдыг макро дуудлагын байршилд шууд бичсэн мэт шийдвэрлэж, макро дуудлагын сайт дээрх бусад кодыг ашиглах боломжтой болно. тэднийг бас.
    ///
    ///
    /// Хожим нь `Span::def_site()` нь "definition-site"-ийн эрүүл ахуйд хамрагдах боломжийг олгоно.Ингэснээр энэ хугацаанд үүссэн танигчдыг макро тодорхойлолтын байршил дээр шийдвэрлэж, макро дуудлагын сайт дээрх бусад кодыг ашиглах боломжгүй болно.
    ///
    /// Ариун цэврийн өнөөгийн чухал ач холбогдолтой тул энэхүү барилга байгууламж нь бусад tokens-ээс ялгаатай нь барилгын ажилд `Span`-ийг зааж өгөхийг шаарддаг.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new`-тэй ижил боловч (`r#ident`) түүхий танигчийг үүсгэдэг.
    /// `string` аргумент нь тухайн хэлний зөвшөөрсөн хүчинтэй танигч байх ёстой (үүнд түлхүүр үгс орно, жишээлбэл `fn`).
    /// Замын хэсгүүдэд ашиглах боломжтой түлхүүр үгс (ж.нь.
    /// `self`, `super`)-ийг дэмждэггүй бөгөөд panic үүсгэдэг.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// [`to_string`](Self::to_string)-ээр буцаж ирсэн бүх мөрийг багтаасан энэхүү `Ident`-ийн хугацааг буцаана.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Энэхүү `Ident`-ийн үргэлжлэх хугацааг тохируулж, эрүүл ахуйн нөхцлийг нь өөрчлөх боломжтой.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, гүүр нь зөвхөн `to_string`-ийг хангаж, `fmt::Display`-ийг хэрэгжүүлдэг (хоёрын ердийн харилцааны урвуу тал).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Тодорхойлогчийг алдагдалгүйгээр хөрвүүлэх боломжтой мөр болгон хэвлэж, ижил танигч болгоно.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Үг үсэг (`"hello"`), байт мөр (`b"hello"`), тэмдэгт (`'a'`), байт тэмдэгт (`b'a'`), бүхэл тоо эсвэл залгаасгүй ("1`, `1u8`, `2.3`, `2.3f32`) тэмдэгт.
///
/// `true`, `false` гэх мэт логик үсгүүд энд хамаарахгүй, тэдгээр нь "Ident`s" юм.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Заасан утгатай шинэ дагавар бүхэл тоон утгыг бий болгоно.
        ///
        /// Энэ функц нь `1u32` шиг бүхэл тоог үүсгэх бөгөөд хэрэв заасан бүхэл утга нь token-ийн эхний хэсэг бөгөөд интеграл нь мөн төгсгөлд нь залгана.
        /// Сөрөг тооноос үүссэн тоонууд нь `TokenStream` эсвэл мөрөөр дамжин өнгөрөхдөө амьд үлдэхгүй бөгөөд хоёр tokens (`-` ба эерэг үсэг) болгон хувааж болно.
        ///
        ///
        /// Энэ аргаар бий болгосон тоон утга нь анхдагчаар `Span::call_site()` хугацаатай байдаг бөгөөд үүнийг доорх `set_span` аргаар тохируулж болно.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Тодорхойлогдсон утгатай шинэ хавсаргаагүй бүхэл тоон утгыг үүсгэдэг.
        ///
        /// Энэ функц нь `1` шиг бүхэл тоог үүсгэх бөгөөд энд заасан бүхэл утга нь token-ийн эхний хэсэг болно.
        /// Энэ token дээр дагавар заагаагүй тул `Literal::i8_unsuffixed(1)` гэх мэт дуудлага нь `Literal::u32_unsuffixed(1)`-тэй дүйнэ гэсэн үг юм.
        /// Сөрөг тоонуудаас үүссэн тоонууд нь `TokenStream` эсвэл мөрөөр дамжин өнгөрөх чадваргүй байж болох ба хоёр tokens (`-` ба эерэг үсэг) болгон хувааж болно.
        ///
        ///
        /// Энэ аргаар бий болгосон тоон утга нь анхдагчаар `Span::call_site()` хугацаатай байдаг бөгөөд үүнийг доорх `set_span` аргаар тохируулж болно.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Шинэ хавсаргаагүй хөвөгч цэгийн шууд үсгийг үүсгэдэг.
    ///
    /// Энэ байгуулагч нь `Literal::i8_unsuffixed` шиг хөвөгч утгыг шууд token-д ялгаруулдаг боловч ямар ч дагавар ашиглаагүй тул хөрвүүлэгчийн дараа `f64` байх магадлалтай байж болно.
    ///
    /// Сөрөг тоонуудаас үүссэн тоонууд нь `TokenStream` эсвэл мөрөөр дамжин өнгөрөх чадваргүй байж болох ба хоёр tokens (`-` ба эерэг үсэг) болгон хувааж болно.
    ///
    /// # Panics
    ///
    /// Энэ функц нь заасан хөвөгч хязгаартай байхыг шаарддаг, жишээлбэл хязгааргүй эсвэл NaN бол энэ функц panic болно.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Шинэ дагавар хөвөгч цэгийн шууд үсгийг бий болгодог.
    ///
    /// Энэ байгуулагч нь `1.0f32` шиг шууд утгыг үүсгэх бөгөөд энд заасан утга нь token-ийн өмнөх хэсэг бөгөөд `f32` нь token-ийн дагавар болно.
    /// Энэхүү token нь хөрвүүлэгчийн үргэлж `f32` байх тухай дүгнэлт байх болно.
    /// Сөрөг тоонуудаас үүссэн тоонууд нь `TokenStream` эсвэл мөрөөр дамжин өнгөрөх чадваргүй байж болох ба хоёр tokens (`-` ба эерэг үсэг) болгон хувааж болно.
    ///
    ///
    /// # Panics
    ///
    /// Энэ функц нь заасан хөвөгч хязгаартай байхыг шаарддаг, жишээлбэл хязгааргүй эсвэл NaN бол энэ функц panic болно.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Шинэ хавсаргаагүй хөвөгч цэгийн шууд үсгийг үүсгэдэг.
    ///
    /// Энэ байгуулагч нь `Literal::i8_unsuffixed` шиг хөвөгч утгыг шууд token-д ялгаруулдаг боловч ямар ч дагавар ашиглаагүй тул хөрвүүлэгчийн дараа `f64` байх магадлалтай байж болно.
    ///
    /// Сөрөг тоонуудаас үүссэн тоонууд нь `TokenStream` эсвэл мөрөөр дамжин өнгөрөх чадваргүй байж болох ба хоёр tokens (`-` ба эерэг үсэг) болгон хувааж болно.
    ///
    /// # Panics
    ///
    /// Энэ функц нь заасан хөвөгч хязгаартай байхыг шаарддаг, жишээлбэл хязгааргүй эсвэл NaN бол энэ функц panic болно.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Шинэ дагавар хөвөгч цэгийн шууд үсгийг бий болгодог.
    ///
    /// Энэхүү байгуулагч нь `1.0f64` шиг шууд утгыг үүсгэх бөгөөд заасан утга нь token-ийн өмнөх хэсэг бөгөөд `f64` нь token-ийн дагавар болно.
    /// Энэхүү token нь хөрвүүлэгчийн үргэлж `f64` байх тухай дүгнэлт байх болно.
    /// Сөрөг тоонуудаас үүссэн тоонууд нь `TokenStream` эсвэл мөрөөр дамжин өнгөрөх чадваргүй байж болох ба хоёр tokens (`-` ба эерэг үсэг) болгон хувааж болно.
    ///
    ///
    /// # Panics
    ///
    /// Энэ функц нь заасан хөвөгч хязгаартай байхыг шаарддаг, жишээлбэл хязгааргүй эсвэл NaN бол энэ функц panic болно.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Үг шууд утгаараа.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Тэмдэгт шууд утгаараа.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Байт мөр.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Энэ шууд утгаар багтаасан хугацааг буцаана.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Энэ шууд утгаар холбосон хугацааг тохируулна.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `range` муж дахь зөвхөн эх байтыг агуулсан `self.span()` дэд хэсэг болох `Span`-ийг буцаана.
    /// Хэрэв засах хугацаа `self`-ийн хязгаараас гадуур байвал `None`-ийг буцаана.
    ///
    // FIXME(SergioBenitez): байтын муж эх үүсвэрийн UTF-8 хил хязгаараас эхэлж дуусах эсэхийг шалгана уу.
    // өөр тохиолдолд эх текстийг хэвлэх үед panic нь өөр газар тохиолдох магадлалтай.
    // FIXME(SergioBenitez): Хэрэглэгчид `self.span()` нь яг юу зураглаж байгааг мэдэх ямар ч боломжгүй тул энэ аргыг одоогоор зөвхөн сохроор дуудаж болно.
    // Жишээлбэл, 'c' тэмдэгтэд зориулсан `to_string()` нь "'\u{63}'"-ийг буцаадаг;хэрэглэгчийн хувьд эх текст нь 'c' байсан уу эсвэл '\u{63}' байсан уу гэдгийг мэдэх арга байхгүй.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned`-тэй төстэй, гэхдээ `Bound<&T>`-тэй төстэй.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, гүүр нь зөвхөн `to_string`-ийг хангаж, `fmt::Display`-ийг хэрэгжүүлдэг (хоёрын ердийн харилцааны урвуу тал).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Үг үсгийг алдагдалгүйгээр хөрвүүлэгдэх мөр болгон ижил утгаар хэвлэнэ (хөвөгч цэгийн үсгийн хувьд дугуйруулахаас бусад тохиолдолд).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Хүрээлэн буй орчны хувьсагчдыг хянах.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Хүрээлэн буй орчны хувьсагчийг татаж, хараат байдлын мэдээллийг бий болгохын тулд нэмнэ үү.
    /// Хөрвүүлэгчийг ажиллуулж буй бүтээх систем нь хөрвүүлэх явцад хувьсагч руу нэвтэрсэн болохыг мэдэж, тухайн хувьсагчийн утга өөрчлөгдөхөд бүтцийг дахин ажиллуулах боломжтой болно.
    ///
    /// Хараат байдлыг хянахаас гадна энэ функц нь стандарт номын сангаас `env::var`-тэй тэнцүү байх ёстой, гэхдээ аргумент нь UTF-8 байх ёстой.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}