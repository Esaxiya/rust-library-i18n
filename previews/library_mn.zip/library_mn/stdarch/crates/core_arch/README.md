`core::arch` - Rust-ийн үндсэн номын сангийн архитектурын онцлог шинж чанарууд
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` модуль нь архитектураас хамааралтай дотоод шинж чанарыг (жишээлбэл, SIMD) хэрэгжүүлдэг.

# Usage 

`core::arch` нь `libcore`-ийн нэг хэсэг бөгөөд `libstd`-ээр дахин экспортлогдож байна.Энэ crate-ээс илүү `core::arch` эсвэл `std::arch`-ээр ашиглахыг илүүд үзээрэй.
Тогтворгүй шинж чанаруудыг ихэвчлэн шөнийн Rust дээр `feature(stdsimd)`-ээр дамжуулан авах боломжтой байдаг.

`core::arch`-ийг энэхүү crate-ээр дамжуулан ашиглахын тулд шөнийн Rust шаардагддаг бөгөөд энэ нь ихэвчлэн эвдэрч (болдог).Энэ crate-ээр дамжуулан ашиглах талаар бодож үзэх цорын ганц тохиолдлууд нь:

* хэрэв та `core::arch`-ийг өөрөө дахин хөрвүүлэх шаардлагатай бол, жишээлбэл, `libcore`/`libstd`-д идэвхжүүлээгүй зорилтот шинж чанаруудыг идэвхжүүлсэн.
Note: Хэрэв та стандарт бус зорилтот бүлэгт зориулж дахин хөрвүүлэх шаардлагатай бол энэ crate-ийг ашиглахын оронд `xargo`-ийг ашиглах, `libcore`/`libstd`-ийг зохих ёсоор нь дахин хөрвүүлэхийг илүүд үзнэ үү.
  
* Тогтворгүй Rust шинж чанаруудын ард ч байхгүй байж болох зарим шинж чанаруудыг ашиглах.Эдгээрийг аль болох бага байлгахыг хичээдэг.
Хэрэв та эдгээр функцуудын заримыг ашиглах шаардлагатай бол асуудлыг шөнийн Rust дээр ил гаргахын тулд асуудлыг нээж өгөөч.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` нь MIT лиценз ба Apache лицензийн (2.0 хувилбар) хоёулангийнх нь дагуу BSD-тэй төстэй янз бүрийн лицензээр бүрхэгдсэн хэсгүүдээр тархдаг.

LICENSE-APACHE, LICENSE-MIT-ээс дэлгэрэнгүй үзнэ үү.

# Contribution

Хэрэв та өөрөөр тодорхой заагаагүй бол Apache-2.0 лицензэд тодорхойлсон `core_arch`-д оруулахаар зориудаар оруулсан аливаа хувь нэмрийг дээр дурдсанчлан нэмэлт нөхцөл, болзолгүйгээр давхар лицензтэй байх ёстой.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












