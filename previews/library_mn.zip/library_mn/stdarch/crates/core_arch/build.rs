use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Манай `#[assert_instr]` аннотацид бүх симд интриниксүүд коджуулагчаа шалгах боломжтой байдаг тул зарим нь яг одоо `#[target_feature]`-тэй дүйцэх нэмэлт `-Ctarget-feature=+unimplemented-simd128`-ийн ард зогсож байгаа тул үүнийг ашиглахад ашигладаг.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}