# Stdarch-д хувь нэмэр оруулж байна

`stdarch` crate нь хувь нэмрийг хүлээн авахад бэлэн байна!Эхлээд та агуулахтай танилцаж, туршилтууд танд тохирсон эсэхийг шалгаарай.

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Хэрэв `<your-target-arch>` бол `rustup`-ийн ашигладаг зорилтот гурвалсан байдал юм, жишээлбэл `x86_x64-unknown-linux-gnu` (өмнөх `nightly-` ба үүнтэй төстэй зүйлгүйгээр).
Энэ сан нь Rust-ийн шөнийн сувгийг шаарддаг гэдгийг санаарай!
Дээрх тестүүд нь `rustup default nightly` (болон буцаахдаа `rustup default stable`) ашигладаг тохиргоог хийхийн тулд шөнийн rust-ийг таны системд анхдагчаар тохируулахыг шаарддаг.

Хэрэв дээрх алхамуудын аль нэг нь ажиллахгүй бол, [please let us know][new]!

Дараа нь [find an issue][issues] дээр туслахын тулд бид [`help wanted`][help] ба [`impl-period`][impl] шошготой цөөн хэдэн зүйлийг сонгосон бөгөөд энэ нь зарим тусламжийг ашиглаж болно. 
Та [#40][vendor] дээр бүх үйлдвэрлэгчийн дотоод шинж чанарыг нэвтрүүлж, [#40][vendor]-ийг хамгийн их сонирхож магадгүй юм.Энэ асуудал хаанаас эхлэх талаар сайн зааж өгсөн болно!

Хэрэв танд ерөнхий асуулт байгаа бол [join us on gitter][gitter]-ээс чөлөөтэй асууж лавлаж асуугаарай!@BurntSushi эсвэл@alexcrichton гэсэн хоёрын аль нэгийг нь асууж лавлахаас бүү эргэлз.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Stdarch intrinsics-т жишээг хэрхэн бичих вэ

Өгөгдсөн дотоод чанарыг хэвийн ажиллуулахын тулд хэд хэдэн функцийг идэвхжүүлсэн байх ёстой бөгөөд тухайн функцийг CPU дэмжсэн тохиолдолд л `cargo test --doc` жишээг ажиллуулах ёстой.

Үүний үр дүнд `rustdoc`-ийн үүсгэсэн анхдагч `fn main` ажиллахгүй болно (ихэнх тохиолдолд).
Таны үлгэр жишээ хүлээгдэж буй үр дүнд хүрэхийн тулд дараахь зүйлийг гарын авлага болгон ашиглах талаар бодож үзээрэй.

```rust
/// # // Жишээ нь зөвхөн байхын тулд бидэнд cfg_target_feature хэрэгтэй
/// # // CPU нь функцийг дэмжих үед `cargo test --doc`-ээр ажиллуулна
/// # #![feature(cfg_target_feature)]
/// # // Дотоод хүний ажиллахын тулд бидэнд target_feature хэрэгтэй
/// # #![feature(target_feature)]
/// #
/// # // rustdoc нь анхдагчаар `extern crate stdarch` ашигладаг боловч бидэнд хэрэгтэй
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Бодит үндсэн функц
/// # fn main() {
/// #     // Зөвхөн `<target feature>` дэмжигдсэн тохиолдолд л ажиллуулна уу
/// #     хэрэв cfg_feature_enabled! ("<target feature>"){
/// #         // Зорилтот функц л ажиллуулах боломжтой `worker` функцийг үүсгээрэй
/// #         // дэмжигдсэн бөгөөд таны ажилтанд зориулж `target_feature`-ийг идэвхжүүлсэн эсэхийг шалгаарай
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         аюултай fn worker() {
/// // Жишээг энд бичээрэй.Онцлог шинж чанарууд энд ажиллах болно!Зэрлэг яв!
///
/// #         }
///
/// #         аюултай { worker(); }
/// #     }
/// # }
```

Хэрэв дээр дурдсан зарим синтакс танил биш юм бол [Rust Book]-ийн [Documentation as tests] хэсэгт `rustdoc` синтаксийг маш сайн дүрсэлсэн байдаг.
Үргэлж лугаа адил [join us on gitter][gitter]-тэй чөлөөтэй холбогдоорой, та ямар нэгэн хулгай хийсэн эсэхийг биднээс асуугаарай, `stdarch`-ийн баримт бичгийг сайжруулахад тусалсанд баярлалаа!

# Өөр туршилтын заавар

Туршилтыг явуулахын тулд `ci/run.sh` ашиглахыг ерөнхийдөө зөвлөж байна.
Гэхдээ энэ нь танд тохирохгүй байж магадгүй, жишээлбэл, хэрэв та Windows дээр байгаа бол.

Энэ тохиолдолд та код үүсгэх туршилтанд хамрагдахын тулд `cargo +nightly test` ба `cargo +nightly test --release -p core_arch`-ийг ажиллуулах боломжтой болно.
Эдгээр нь шөнийн хэрэгслийн сүлжээг суулгаж, `rustc` нь таны зорилтот гурав дахин, түүний CPU-ийн талаар мэдэх шаардлагатайг анхаарна уу.
Ялангуяа та `TARGET` орчны хувьсагчийг `ci/run.sh`-тай адил тохируулах хэрэгтэй.
Нэмж дурдахад зорилтот шинж чанаруудыг харуулахын тулд `RUSTCFLAGS` (`C` хэрэгтэй) тохируулах хэрэгтэй `RUSTCFLAGS="-C -target-features=+avx2"`.
Хэрэв та "just"-ийг одоогийн CPU-ийн эсрэг хөгжүүлж байгаа бол `-C -target-cpu=native`-ийг тохируулж болно.

Эдгээр өөр зааврыг ашиглахдаа [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], жишээлбэл
заавар үүсгэх туршилт нь бүтэлгүйтэж магадгүй, учир нь дизассемблер өөрөөр нэрлэсэн, жишээлбэл
Энэ нь `aesenc`-ийн заавруудын оронд `vaesenc`-ийг үүсгэж магадгүй юм.
Эдгээр зааврууд нь ердийнхөөс бага тест хийдэг тул эцэст нь хүсэлт гаргаснаар энд дурдаагүй тестүүдэд зарим алдаа гарч болзошгүйг гайхах хэрэггүй.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






