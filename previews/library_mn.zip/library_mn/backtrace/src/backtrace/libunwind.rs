//! libunwind/gcc_s/etc API ашиглан backtrace дэмжлэг үзүүлэх.
//!
//! Энэ модуль нь libunwind загварын API ашиглан стекийг тайлах чадварыг агуулдаг.
//! Libunwind-тэй төстэй API-ийн бүхэл бүтэн багц програмууд байдаг бөгөөд энэ нь зөвхөн сонгомтгой байхын оронд ихэнхдээ нэг дор нийцүүлэхийг хичээдэг болохыг анхаарна уу.
//!
//!
//! Libunwind API нь `_Unwind_Backtrace`-ээр ажилладаг бөгөөд бодит байдал дээр арын мөрийг үүсгэхэд маш найдвартай байдаг.
//! Үүнийг яаж хийдэг нь бүрэн тодорхойгүй байна (фрэймийн заагч? Eh_frame info? Хоёулаа?) Гэхдээ энэ нь ажиллах шиг байна!
//!
//! Энэ модулийн ихэнх нарийн төвөгтэй байдал нь libunwind хэрэгжүүлэлтүүдийн хоорондох янз бүрийн платформын ялгааг зохицуулах явдал юм.
//! Үгүй бол энэ нь libunwind API-уудтай шууд холбогдсон Rust юм.
//!
//! Энэ нь одоогоор Windows-аас бусад бүх платформуудын анхдагч задлах API юм.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// Түүхий libunwind заагчтай бол зөвхөн унших боломжтой threadsafe хэлбэрээр хандах боломжтой тул `Sync` юм.
// `Clone`-ээр дамжуулан бусад урсгал руу илгээхдээ бид интерьер заагчийг хадгалахгүй хувилбар руу шилждэг тул бид бас `Send` байх ёстой.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // OSX дээр `_Unwind_FindEnclosingFunction` заагчийг ... ойлгомжгүй зүйл рүү буцаадаг бололтой.
        // Энэ нь үргэлж ямар ч шалтгаанаар хаагдах функц биш юм.
        // Энд юу болж байгаа нь надад бүрэн ойлгомжгүй байгаа тул одоохондоо үүнийг гутарч, ip-г үргэлж буцааж өгөх хэрэгтэй.
        //
        // Энэ заалтыг харгалзан `skip_inner_frames.rs` тестийг OSX дээр алгассан болохыг анхаарна уу. Хэрэв энэ нь тогтмол болсон бол онолын хувьд тестийг OSX дээр ажиллуулж болно!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Backtraces хийхэд ашигладаг номын сангийн интерфэйсийг тайлах
///
/// Энд үхсэн кодыг ашиглахыг зөвшөөрсөн тул iOS-ийг бүгдийг нь холбодог тул платформд илүү тохиргоог нэмэх нь кодыг хэт их бохирдуулж байгааг анхаарна уу.
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // зөвхөн ARM EABI ашигладаг
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // IOS дээр уугуул _Unwind_Backtrace байхгүй
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0-ээс хойш ашиглах боломжтой тул бидний зорилгод нийцсэн байх ёстой
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Энэ функц нь буруу утгатай: энэ фрэймийн Canonical Frame хаяг (дуудагч фрэймийн SP гэх мэт)-ийг авахын оронд энэ фрэймийн SP-г буцааж өгдөг.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x нь CFA утгыг ашигладаг тул бид _Unwind_GetCFA-д найдахын оронд стек заагч (%r15) бүртгэлийг авахын тулд _Unwind_GetGR-ийг ашиглах хэрэгтэй.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android ба arm дээр `_Unwind_GetIP` функц ба бусад олон зүйл макро байдаг тул макро өргөтгөл агуулсан функцийг тодорхойлдог.
    //
    //
    // TODO: Хэрэв та олж чадвал эдгээр макродыг тодорхойлдог толгой файлын холбоос.
    // (Би, фицген, эдгээр макро өргөтгөлийн заримыг анх зээлж авсан толгой файлыг олж чадахгүй байна.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 нь гар дээрх стек заагч юм.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // Энэ функц нь Android эсвэл ARM/Linux дээр байдаггүй тул үүнийг идэвхгүй болго.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}