use core::ffi::c_void;
use core::fmt;

/// Одоогийн дуудлагын стекийг шалгаж, бүх идэвхтэй хүрээг стек ул мөрийг тооцоолохын тулд өгсөн хаалтанд оруулна.
///
/// Энэ функц нь програмын стек ул мөрийг тооцоолоход энэхүү номын сангийн ажлын морь юм.Өгөгдсөн хаалтын `cb` нь стек дээрх дуудлагын хүрээний тухай мэдээллийг илэрхийлсэн `Frame`-ийн жишээг авч үзнэ.
/// Хаалтыг дээрээс доош чигээр нь гаргаж өгдөг (хамгийн сүүлд эхлээд функц гэж нэрлэдэг).
///
/// Хаалтын буцах утга нь арын мөрийг үргэлжлүүлэх ёстой эсэхийг харуулж байна.`false`-ийн буцах утга нь арын мөрийг цуцалж, даруй буцаж ирнэ.
///
/// `Frame`-ийг олж авсны дараа `backtrace::resolve` руу залгаж `ip` (зааврын заагч) эсвэл тэмдгийн хаягийг нэр ба/эсвэл файлын нэр/мөрийн дугаарыг сурах боломжтой `Symbol` болгон хөрвүүлэхийг хүсч магадгүй юм.
///
///
/// Энэ нь харьцангуй бага түвшний функц бөгөөд хэрэв та жишээ нь дараа нь шалгаж үзэхийн тулд арын мөрийг авахыг хүсч байвал `Backtrace` төрөл илүү тохиромжтой байж болохыг анхаарна уу.
///
/// # Шаардлагатай шинж чанарууд
///
/// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
///
/// # Panics
///
/// Энэ функц нь хэзээ ч panic-тэй байхыг хичээдэг боловч хэрэв `cb` panics-ийг хангаж өгдөг бол зарим платформууд нь panic-ийг давхар цуцлах болно.
/// Зарим платформууд нь эргээд буцааж буцааж өгөх боломжгүй дуудлагыг ашигладаг C номын санг ашигладаг тул `cb`-ээс сандрах нь процессыг зогсооход хүргэж болзошгүй юм.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // мөрөө үргэлжлүүлээрэй
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace`-тэй адилхан, синхрончлогдоогүй тул зөвхөн аюулгүй байдаг.
///
/// Энэ функц нь синхрончлолын гарын авлагагүй боловч энэ crate-ийн `std` функцийг хөрвүүлээгүй үед ашиглах боломжтой.
/// Илүү олон баримт бичиг, жишээ авахын тулд `trace` функцийг үзнэ үү.
///
/// # Panics
///
/// `cb`-ийг сандаргахад анхааруулах зүйлсийн талаар `trace` дээрх мэдээллийг үзнэ үү.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Буцаах мөрний нэг хүрээг илэрхийлсэн trait нь энэ crate-ийн `trace` функцэд хүргэсэн.
///
/// Мөшгих функцийг хааснаас фрэймүүд гарах бөгөөд хүрээ нь үндсэндээ хэрэгжих хүртэл үргэлж мэдэгддэггүй тул хүрээ нь бараг илгээгддэг.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Энэ фрэймийн одоогийн зааврын заагчийг буцаана.
    ///
    /// Энэ нь ихэвчлэн фрэйм дээр гүйцэтгэх дараагийн заавар байдаг боловч бүх хэрэгжүүлэлтүүд үүнийг 100% нарийвчлалтай жагсадаггүй (гэхдээ энэ нь ерөнхийдөө ойролцоо байдаг).
    ///
    ///
    /// Энэ утгыг бэлгэдлийн нэр болгохын тулд `backtrace::resolve` руу дамжуулахыг зөвлөж байна.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Энэ хүрээний одоогийн стек заагчийг буцаана.
    ///
    /// Арын арын хэсэг нь энэ хүрээний стек заагчийг сэргээж чадахгүй тохиолдолд тэг заагчийг буцаана.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Энэ функцын хүрээний эхлэх тэмдгийн хаягийг буцаана.
    ///
    /// Энэ нь `ip`-ээр буцааж өгсөн зааврын заагчийг функцийн эхэнд буцааж буцааж буцааж өгөхийг оролдох болно.
    ///
    /// Гэхдээ зарим тохиолдолд арын холболтууд энэ функцээс `ip`-ийг буцааж өгдөг.
    ///
    /// Дээр өгөгдсөн `ip` дээр `backtrace::resolve` бүтэлгүйтсэн тохиолдолд буцаж ирсэн утгыг заримдаа ашиглаж болно.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Хүрээ хамаарах модулийн үндсэн хаягийг буцаана.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Мири хост хост платформоос давуу эрх олгохыг баталгаажуулахын тулд үүнийг хамгийн түрүүнд хийх шаардлагатай байна
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // зөвхөн dbghelp-д ашиглагддаг
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}