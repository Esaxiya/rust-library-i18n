use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Өмчлөгдсөн болон өөртөө хамааралтай арын мөрийг төлөөлөх.
///
/// Энэ бүтцийг програмын янз бүрийн цэгүүдээс арын мөрийг олж авахад ашиглаж болох ба дараа нь тухайн үеийн арын мөрийг шалгаж үзэхэд ашиглаж болно.
///
///
/// `Backtrace` `Debug` хэрэгжүүлснээр backtraces-ийг нэлээд сайн хэвлэхийг дэмждэг.
///
/// # Шаардлагатай шинж чанарууд
///
/// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Энд жаазыг стекийн дээрээс доороос жагсаасан болно
    frames: Vec<BacktraceFrame>,
    // Бидний үзэж байгаа индекс бол `Backtrace::new`, `backtrace::trace` гэх мэт фрэймүүдийг орхигдуулж, арын замын бодит эхлэл юм.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Ар араасаа чиглэсэн хүрээний хувилбарыг авсан.
///
/// Энэ төрлийг `Backtrace::frames`-ийн жагсаалт болгон буцааж өгсөн ба авсан арын мөрөнд нэг стекийн хүрээг илэрхийлнэ.
///
/// # Шаардлагатай шинж чанарууд
///
/// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Арын мөрөнд тэмдэгийн хувилбарыг барьж авав.
///
/// Энэ төрлийг `BacktraceFrame::symbols`-ийн жагсаалт болгон буцааж өгсөн бөгөөд арын мөрөнд байгаа тэмдэгт мета өгөгдлийг илэрхийлнэ.
///
/// # Шаардлагатай шинж чанарууд
///
/// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Энэ функцын дуудлага хийх газар дээрхи арын зургийг барьж, эзэмшсэн төлөөллийг буцаана.
    ///
    /// Энэ функц нь арын мөрийг Rust дахь объект болгон илэрхийлэхэд хэрэгтэй.Энэ буцааж өгсөн утгыг утаснуудаар дамжуулж өөр газар хэвлэх боломжтой бөгөөд энэ утга нь бүхэлдээ өөртөө агуулагдах болно.
    ///
    /// Зарим платформ дээр бүрэн ухрах замыг олж авах нь үүнийг шийдвэрлэхэд маш их өртөгтэй болохыг анхаарна уу.
    /// Хэрэв таны програмын өртөг хэтэрхий их байвал `Backtrace::new_unresolved()`-ийг ашиглахыг зөвлөж байна, энэ нь тэмдгийн нягтралын алхамаас зайлсхийх бөгөөд (энэ нь ихэвчлэн хамгийн урт хугацаа шаардагддаг) бөгөөд үүнийг хойшлуулах боломжийг олгодог.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // устгах хүрээ байгаа эсэхийг шалгахыг хүсч байна
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Энэ нь `new`-тэй адил бөгөөд энэ нь ямар ч тэмдгийг шийддэггүй тул буцах мөрийг хаягийн жагсаалт болгон авдаг.
    ///
    /// Дараа нь `resolve` функцийг дуудаж энэ арын тэмдгийг унших боломжтой нэр болгоно.
    /// Шийдвэрлэх явцад заримдаа нэлээд их цаг хугацаа шаардагддаг бол буцааж мөрдөх нь ховор хэвлэгддэг тул энэ функц байдаг.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // тэмдгийн нэр байхгүй
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // одоо байгаа бэлгэдлийн нэрс
    /// ```
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    ///
    ///
    #[inline(never)] // устгах хүрээ байгаа эсэхийг шалгахыг хүсч байна
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Энэ арын мөрийг авсан үеийн жаазыг буцаана.
    ///
    /// Энэ зүсмэлийн эхний оруулга нь `Backtrace::new` функц байж магадгүй бөгөөд сүүлчийн хүрээ нь энэ утас эсвэл үндсэн функц хэрхэн яаж эхэлсэн тухай юм.
    ///
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Хэрэв энэ арын мөрийг `new_unresolved`-ээс үүсгэсэн бол энэ функц нь арын мөрөнд байгаа бүх хаягийг бэлгэдлийн нэрээр нь шийдвэрлэх болно.
    ///
    ///
    /// Хэрэв энэ арын мөрийг өмнө нь шийдсэн эсвэл `new`-ээр бүтээсэн бол энэ функц юу ч хийхгүй.
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip`-тэй ижил
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address`-тэй ижил
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address`-тэй ижил
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Энэ хүрээний харгалзах тэмдгийн жагсаалтыг буцаана.
    ///
    /// Ер нь нэг фрэймд нэг л тэмдэг байдаг, гэхдээ заримдаа хэд хэдэн функцийг нэг фрэйм дотор оруулбал олон тооны тэмдэг буцаагдах болно.
    /// Жагсаалтанд орсон эхний тэмдэг нь "innermost function", харин сүүлчийн тэмдэг нь хамгийн гадна талын (сүүлчийн дуудагч) тэмдэг юм.
    ///
    /// Хэрэв энэ хүрээ шийдэгдээгүй буцаж ирсэн мөрөөс гарсан бол хоосон жагсаалтыг буцааж өгөх болно гэдгийг анхаарна уу.
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name`-тэй ижил
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr`-тэй ижил
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename`-тэй ижил
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno`-тэй ижил
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno`-тэй ижил
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Замуудыг хэвлэхдээ cwd-г байгаа тохиолдолд нь хуулж авахыг хичээдэг, эс тэгвээс замыг нь байгаагаар нь хэвлэчихдэг.
        // Бид үүнийг зөвхөн богино форматаар хийдэг гэдгийг анхаарна уу, учир нь дүүрсэн бол бид бүх зүйлийг хэвлэхийг хүсч байна.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}