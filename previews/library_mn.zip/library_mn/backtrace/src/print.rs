#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Арын замд зориулсан форматлагч.
///
/// Энэ төрлийг буцаах мөр нь өөрөө хаанаас ирснээс үл хамааран арын мөрийг хэвлэхэд ашиглаж болно.
/// Хэрэв танд `Backtrace` төрөл байгаа бол түүний `Debug` хэрэгжүүлэлт нь энэ хэвлэх форматыг аль хэдийн ашигласан болно.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Бидний хэвлэж чадах хэвлэх хэв маяг
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Зөвхөн холбогдох мэдээллийг агуулсан илүү нарийвчлалтай арын мөрийг хэвлэнэ
    Short,
    /// Боломжтой бүх мэдээллийг агуулсан арын мөрийг хэвлэнэ
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Өгөгдсөн `fmt` дээр гаралтыг бичих шинэ `BacktraceFmt` үүсгээрэй.
    ///
    /// `format` аргумент нь арын мөрийг хэвлэх хэв маягийг хянах бөгөөд `print_path` аргумент нь `BytesOrWideString` файлын нэрийг хэвлэхэд ашиглагдах болно.
    /// Энэ төрөл нь файлын нэрийг хэвлэх ямар ч ажил хийдэггүй тул үүнийг буцааж дуудах шаардлагатай болно.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Хэвлэх гэж байгаа арын мөрийн оршил хэсгийг хэвлэнэ.
    ///
    /// Арын трассыг дараа нь бүрэн бэлгэдэл болгохын тулд зарим платформ дээр үүнийг хийх шаардлагатай байдаг бөгөөд өөрөөр хэлбэл энэ нь `BacktraceFmt` үүсгэсний дараа дуудах анхны арга байх болно.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Backtrace гаралтад хүрээ нэмнэ.
    ///
    /// Энэхүү амлалт нь хүрээ хэвлэхэд ашиглаж болох `BacktraceFrameFmt`-ийн RAII жишээг буцаадаг бөгөөд устгалд хүрээний тоолуур нэмэгдэх болно.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Буцах мөрний гаралтыг гүйцээнэ.
    ///
    /// Энэ нь одоогоор ажиллахгүй байгаа боловч буцах мөрний форматтай future нийцтэй байх үүднээс нэмж оруулсан болно.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Одоогийн байдлаар future-ийг нэмэх боломжийг олгохын тулд энэ hook-ийг оруулаагүй болно.
        Ok(())
    }
}

/// Буцах мөрийн зөвхөн нэг хүрээний форматлагч.
///
/// Энэ төрлийг `BacktraceFmt::frame` функцээр үүсгэдэг.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Энэ хүрээ форматлагчаар `BacktraceFrame` хэвлэнэ.
    ///
    /// Энэ нь `BacktraceFrame` доторх бүх `BacktraceSymbol` тохиолдлуудыг рекурсив хэлбэрээр хэвлэх болно.
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceSymbol`-ийг `BacktraceFrame` дотор хэвлэнэ.
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: Энэ нь бид юу ч хэвлэж дуусгахгүй байх нь тийм ч сайхан биш юм
            // utf8 бус файлын нэрээр.
            // Аз болоход бараг бүх зүйл utf8 тул тийм ч муу биш байх ёстой.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Түүхий ул мөр бүхий `Frame` ба `Symbol`-ийг ихэвчлэн энэ crate-ийн түүхий дуудлага дотроос хэвлэдэг.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Буцах мөрний гаралтад түүхий хүрээг нэмнэ.
    ///
    /// Энэ арга нь өмнөхөөсөө ялгаатай нь янз бүрийн байршлаас эх үүсвэр болж байгаа тохиолдолд түүхий аргументуудыг авдаг.
    /// Үүнийг нэг фрэймийн хувьд олон удаа дуудаж болохыг анхаарна уу.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Баганын мэдээллийг багтаасан backtrace гаралтад түүхий хүрээг нэмж оруулна.
    ///
    /// Энэ арга нь өмнөхтэй адил түүхий аргументуудыг өөр өөр газраас олж авах тохиолдолд авдаг.
    /// Үүнийг нэг фрэймийн хувьд олон удаа дуудаж болохыг анхаарна уу.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Фучиа нь үйл явцын дотор бэлгэдэх боломжгүй тул дараа нь бэлгэдэхэд ашиглаж болох тусгай форматтай байдаг.
        // Энд хаягуудыг өөрийн форматаар хэвлэхийн оронд үүнийг хэвлэ.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" фрэймийг хэвлэх шаардлагагүй бөгөөд энэ нь үндсэндээ системийн ухралт нь хэт хол мөрдөхийг маш их хүсч байсан гэсэн үг юм.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx анклав дахь TCB хэмжээг багасгахын тулд бид тэмдгийн нягтралын функцийг хэрэгжүүлэхийг хүсэхгүй байна.
        // Үүний оронд бид хаягийн офсетыг энд хэвлэх боломжтой бөгөөд дараа нь функцийг засахын тулд зураглал хийж болно.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Хүрээний индексийг хэвлэх, фрэймийн нэмэлт зааварчилгааг хэвлэх.
        // Хэрэв бид энэ фрэймийн эхний тэмдгээс гадуур байвал зохих хоосон зайг хэвлэх болно.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Дараа нь, хэрэв бид бүрэн ухарсан бол нэмэлт мэдээлэл авахын тулд өөр форматыг ашиглан тэмдгийн нэрийг бичнэ үү.
        // Энд бид нэргүй тэмдгүүдийг бас зохицуулдаг,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Эцэст нь filename/line дугаарыг боломжтой бол хэвлэ.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line тэмдгийн нэрэн дор мөрөнд хэвлэсэн тул тохирох хоосон зайг хэвлээд өөрсдийгөө зөв зэрэгцүүлээрэй.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Файлын нэрийг хэвлэх, дараа нь мөрийн дугаарыг хэвлэхийн тулд манай дотоод дуудлагад төлөөлөгчөөр оролцуул.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Хэрэв боломжтой бол баганын дугаарыг нэмнэ үү.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Бид зөвхөн хүрээний анхны тэмдгийг л анхаарч үздэг
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}