//! crates.io дээр `gimli` crate-ийг ашиглан бэлгэдлийг дэмжих
//!
//! Энэ бол Rust-ийн анхдагч бэлгэдлийн хэрэгжилт юм.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'статик насан туршийн хугацаа нь өөрөө лавлагаа өгөх загварыг дэмжихэд дутагдалтай байгаа нь худлаа юм.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Статик ашиглалтын хугацааг хөрвүүлээрэй, учир нь тэмдэг нь зөвхөн `map` ба `stash`-ийг зээлэх ёстой бөгөөд бид тэдгээрийг доор хадгалж байна.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows дээр уугуул номын сангуудыг ачаалахын тулд rust-lang/rust#71060 дээрх янз бүрийн стратегиудын талаархи зарим хэлэлцүүлгийг үзнэ үү.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW сангууд одоогоор ASLR (rust-lang/rust#16514)-ийг дэмждэггүй боловч DLL файлуудыг хаягийн зайд шилжүүлэх боломжтой хэвээр байна.
            // Дебаг хийх мэдээллийн хаягууд бүгд энэ номын сан нь COFF файлын толгой хэсгийн талбар болох "image base" дээр ачаалагдсан мэт санагдаж байна.
            // Энэ нь debuginfo-ийн жагсаалт юм шиг байгаа тул бид тэмдэглэгээний хүснэгтийг задалж, номын санг "image base" дээр ачаалагдсан мэт хадгална.
            //
            // Гэхдээ номын санг "image base" дээр ачаалахгүй байж магадгүй юм.
            // (тэнд өөр ямар нэг зүйл дуудаж магадгүй гэж үү?) Энд л `bias` талбар эхэлж байгаа бөгөөд энд `bias`-ийн утгыг олох хэрэгтэй.Харамсалтай нь ачаалагдсан модулиас үүнийг хэрхэн олж авах нь тодорхойгүй байна.
            // Гэхдээ бидэнд байгаа зүйл бол (`modBaseAddr`) ачааллын хаяг юм.
            //
            // Одоохондоо бага зэрэг цөөвтөр байдлаар бид файлаа мммап файлын толгойн мэдээллийг уншаад mmap хаяна.Энэ нь дэмий зүйл юм, учир нь дараа нь mmap-ийг дахин нээх болно, гэхдээ энэ нь одоогоор хангалттай ажиллах ёстой.
            //
            // Бид `image_base` (хүссэн ачааллын байршил) ба `base_addr` (ачааллын бодит байршил)-ыг авсны дараа `bias` (бодит ба хүссэний хоорондох ялгаа)-г бөглөж болох бөгөөд дараа нь сегмент бүрийн заасан хаяг нь `image_base` болно, учир нь файл яг ингэж хэлдэг.
            //
            //
            // Одоогийн байдлаар бид ELF/MachO-ээс ялгаатай нь `modBaseSize`-ийг бүхэлд нь хэмжээгээр ашиглаж нэг номын санд нэг сегмент хийх боломжтой юм.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS Mach-O файлын форматыг ашигладаг бөгөөд програмын хэсэг болох уугуул номын сангуудын жагсаалтыг ачаалахад DYLD-тэй холбоотой API-уудыг ашигладаг.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Энэ номын сангийн нэрийг хаана татаж авах замтай тохирч байгаа нэрийг авчирна уу.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Энэ номын сангийн зургийн толгойг ачаалж, бүх ачаалах тушаалуудыг задлан шинжлэхийн тулд `object`-д шилжүүлээрэй.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Сегментүүд дээр давталт хийж, олсон сегментүүдийн хувьд мэдэгдэж буй бүс нутгуудыг бүртгэнэ.
            // Нэмэлт мэдээллийг дараа нь боловсруулахад зориулж текстийн сегментийг тэмдэглэж аваарай.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Энэ номын сангийн "slide"-ийг тодорхойлж, санах ойн объектууд хаана ачаалагдаж байгааг тодорхойлоход ашигладаг хэвийсэн утгатай болно.
            // Энэ бол жаахан хачин тооцоолол боловч байгальд цөөн зүйлийг туршиж үзээд юу нь наалдаж байгааг олж харсны үр дүн юм.
            //
            // Ерөнхий санаа бол `bias` ба сегментийн `stated_virtual_memory_address` нь бодит хаягийн орон зайд сегмент байрлаж байх болно.
            // Бидний найддаг өөр нэг зүйл бол `bias`-ийг хассан жинхэнэ хаяг бол тэмдэглэгээний хүснэгт болон debuginfo дээрээс хайж олох индекс юм.
            //
            // Гэсэн хэдий ч систем ачаалагдсан номын сангуудын хувьд эдгээр тооцоо буруу байсан нь харагдаж байна.Эх програмын хувьд энэ нь зөв харагдаж байна.
            // LLDB-ийн эх сурвалжаас зарим логикийг авч үзэхэд 0-ийн офсет-ээс тэг хэмжээтэй ачаалагдсан эхний `__TEXT` хэсэгт зориулагдсан тусгай бүрхүүлтэй болно.
            // Энэ нь ямар ч шалтгаанаар тэмдэглэгээний хүснэгтийг зөвхөн номын сангийн vmaddr слайдтай харьцуулсан гэсэн үг юм.
            // Хэрэв энэ нь *байхгүй* бол тэмдэглэгээний хүснэгт нь vmaddr слайдтай харьцуулж сегментийн заасан хаягтай харьцуулсан болно.
            //
            // Энэ нөхцөл байдлыг зохицуулахын тулд тэг файлыг хасах текст хэсгийг олохгүй бол эхний текст хэсгүүдийн заасан хаягаар хэвийх утгыг нэмэгдүүлж, заасан хаягийг мөн тэр хэмжээгээр бууруулна.
            //
            // Ийм байдлаар номын сангийн хэвийсэн хэмжээтэй харьцуулахад тэмдэглэгээний хүснэгт үргэлж гарч ирдэг.
            // Энэ нь бэлгэдлийн хүснэгтээр бэлгэдэхэд тохирсон зөв үр дүнтэй харагдаж байна.
            //
            // Үнэнийг хэлэхэд энэ нь зөв үү эсвэл үүнийг хэрхэн яаж хийхийг зааж өгөх ёстой өөр зүйл байгаа гэдэгт би бүрэн эргэлзэж байна.
            // Одоогийн байдлаар энэ нь (?) хангалттай сайн ажиллаж байгаа юм шиг санагдаж байгаа бөгөөд хэрэв шаардлагатай бол бид үүнийг цаг хугацааны явцад өөрчлөх хэрэгтэй.
            //
            // Дэлгэрэнгүй мэдээллийг #318-с авна уу
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Бусад Unix (жишээ нь
        // Linux) платформууд нь ELF-ийг объектын файлын формат болгон ашигладаг бөгөөд ихэвчлэн уугуул сангуудыг ачаалахын тулд `dl_iterate_phdr` нэртэй API хэрэгжүүлдэг.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` хүчинтэй заагч байх ёстой.
        // `vec` нь `std::Vec`-ийн зөв заагч байх ёстой.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 нь дибаг хийх мэдээллийг төрөлх хэлбэрээр нь дэмждэггүй боловч бүтээх систем нь дибаг хийх мэдээллийг `romfs:/debug_info.elf` зам дээр байрлуулах болно.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Бусад бүх зүйл ELF-ийг ашиглах ёстой боловч уугуул номын санг хэрхэн яаж ачаалахаа мэдэхгүй байна.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Ачаалагдсан бүх мэдэгдэж буй хуваалцсан номын сангууд.
    libraries: Vec<Library>,

    /// Бид задлан шинжилсэн одой мэдээллийг хадгалдаг газрын зураг.
    ///
    /// Энэхүү жагсаалт нь бүхэл бүтэн өргөх цаг хугацааны хувьд тогтмол хүчин чадалтай бөгөөд хэзээ ч нэмэгддэггүй.
    /// Хос бүрийн `usize` элемент нь `usize::max_value()` нь одоогийн гүйцэтгэгдэж байгаа хэсгийг харуулсан дээрх `libraries` индекс юм.
    ///
    /// `Mapping` нь дүн шинжилгээ хийсэн одой мэдээллийг харгалзана.
    ///
    /// Энэ нь үндсэндээ LRU-ийн кэш гэдгийг бид анхаарч хаягийг бэлгэдэхдээ энд байгаа зүйлсийг өөрчлөх болно.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Энэ номын сангийн хэсгүүдийг санах ойд ачаалж, хаана ачаалж байгааг.
    segments: Vec<LibrarySegment>,
    /// Энэ номын сангийн "bias", ихэвчлэн санах ойд хадгалагддаг.
    /// Энэ утга нь сегмент тус бүр дээр заасан виртуал санах ойн хаягийг авахын тулд сегмент бүрийн заасан хаяг дээр нэмэгддэг.
    /// Нэмж дурдахад бодит виртуал санах ойн хаягаас хасах нь debuginfo болон тэмдэглэгээний хүснэгтэд индексжүүлэх болно.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Объект файл дахь энэ сегментийн заасан хаяг.
    /// Энэ нь үнэндээ сегментийг ачаалж байгаа газар биш, харин энэ хаягийг нэмээд номын сангийн `bias`-ийг багтаасан болно.
    ///
    stated_virtual_memory_address: usize,
    /// Санах ойн сегментийн хэмжээ.
    len: usize,
}

// аюултай, учир нь үүнийг гаднаас синхрончлох шаардлагатай байдаг
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // аюултай, учир нь үүнийг гаднаас синхрончлох шаардлагатай байдаг
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Дибаг хийх мэдээллийн зураглал хийхэд зориулсан маш жижиг, маш энгийн LRU кэш.
        //
        // Ердийн стек нь олон хуваалцсан номын сангуудын хооронд дамждаггүй тул цохилт маш өндөр байх ёстой.
        //
        // `addr2line::Context` бүтцийг бүтээхэд нэлээд үнэтэй байдаг.
        // Дараагийн `locate` асуулгад түүний өртөгийг хорогдуулах төлөвтэй байгаа бөгөөд энэ нь addr2line: : Context`s-ийг барьж байгуулахад ашигласан хурдыг сайжруулж өгдөг.
        //
        // Хэрэв бидэнд энэ кэш байхгүй байсан бол ийм хорогдол хэзээ ч гарахгүй бөгөөд арын замыг тэмдэглэх нь ssssllllooooowwww болно.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Эхлээд энэ `lib`-т `addr` агуулсан сегмент байгаа эсэхийг шалгана уу (шилжүүлэлтийг зохицуулах).Хэрэв энэ шалгалт өнгөрвөл бид доор үргэлжлүүлж хаягийг орчуулж болно.
                //
                // Халих шалгалтаас зайлсхийхийн тулд бид энд `wrapping_add` ашиглаж байгааг анхаарна уу.SVMA + хэвийсэн тооцоолол халих нь зэрлэг ан амьтдад харагдсан.
                // Энэ нь арай л сонин байх шиг санагдаж байна, гэхдээ сансар огторгуй руу чиглүүлж байгаа тул эдгээр сегментийг үл тоомсорлохоос өөр бидний хийж чадах зүйл тийм ч их биш юм.
                //
                // Энэ нь анх rust-lang/backtrace-rs#329 дээр гарч ирсэн.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // `lib` нь `addr` агуулдаг болохыг мэдэж байгаа тул тогтоосон виртуал санах ойн хаягийг олохын тулд хэвийх утгыг нөхөж чадна.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Хувьсашгүй: Үүний дараа болзолт нь эрт буцаж ирэхгүйгээр дуусна
        // алдаанаас болж энэ замын кэш оруулах нь 0 индекс дээр байна.

        if let Some(idx) = idx {
            // Байршлыг аль хэдийн кэш дээр байрлуулсан бол урд тал руу шилжүүлнэ үү.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Байршлыг кэш дотор оруулаагүй тохиолдолд шинэ зураглал үүсгээд кэшийн урд хэсэгт оруулаад шаардлагатай бол хамгийн эртний кэш оруулгыг хуулж ав.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static`-ийн ашиглалтын хугацааг битгий алдаарай, үүнийг зөвхөн өөрсдөдөө багтаасан эсэхийг шалгаарай
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Харамсалтай нь бид энд шаардагдах тул `sym`-ийн ашиглалтын хугацааг `'static` болгож уртасгах хэрэгтэй, гэхдээ энэ нь лавлагаа хэлбэрээр ашиглагдах болно, тиймээс энэ хүрээнээс цааш дурьдаагүй байх ёстой.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Эцэст нь, энэ файлд зориулж кэш хийсэн зураглал авах эсвэл шинэ зураглал үүсгэх, DWARF мэдээллийг үнэлж энэ хаягийн file/line/name-ийг олох.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Бид энэхүү тэмдгийн хүрээний мэдээллийг олж чадсан бөгөөд "addr2line"-ын хүрээ нь дотроо бүх нарийн ширийн зүйлийг агуулсан болно.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Дибаг хийх мэдээллийг олж чадсангүй, гэхдээ бид үүнийг elf програмын тэмдэглэгээний хүснэгтээс оллоо.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}