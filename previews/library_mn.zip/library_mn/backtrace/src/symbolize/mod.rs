use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Тэмдэгт заасан хаягийг дамжуулж, тэмдгийг зааж өгнө.
///
/// Энэ функц нь өгөгдсөн хаягийг локал тэмдэглэгээний хүснэгт, динамик тэмдэглэгээний хүснэгт, эсвэл DWARF дибаг хийх мэдээлэл (идэвхжүүлсэн хэрэгжүүлэлтээс хамаарч) гэх мэт газруудад хайж олох бөгөөд үр өгөөж өгөх тэмдгүүдийг олох болно.
///
///
/// Тогтоолыг гүйцэтгэх боломжгүй бол хаалтыг дуудаж болохгүй, мөн шугаман функцүүдийн хувьд үүнийг нэгээс илүү удаа дуудаж болно.
///
/// Гаргасан тэмдгүүд нь заасан `addr` дээр гүйцэтгэлийг илэрхийлдэг бөгөөд тухайн хаягийн file/line хосыг буцааж өгдөг (хэрэв байгаа бол).
///
/// Хэрэв танд `Frame` байгаа бол энэ функцын оронд `resolve_frame` функцийг ашиглахыг зөвлөж байна.
///
/// # Шаардлагатай шинж чанарууд
///
/// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
///
/// # Panics
///
/// Энэ функц нь хэзээ ч panic-тэй байхыг хичээдэг боловч хэрэв `cb` panics-ийг хангаж өгдөг бол зарим платформууд нь panic-ийг давхар цуцлах болно.
/// Зарим платформууд нь эргээд буцааж буцааж өгөх боломжгүй дуудлагыг ашигладаг C номын санг ашигладаг тул `cb`-ээс сандрах нь процессыг зогсооход хүргэж болзошгүй юм.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // зөвхөн дээд хүрээг хар
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Өмнө нь авсан жаазыг тэмдэг болгон тодорхойлж, тэмдгийг заасан хаалттай хэсэгт шилжүүлнэ.
///
/// Энэ функц нь `resolve`-тэй ижил функцийг гүйцэтгэдэг бөгөөд зөвхөн хаягийн оронд `Frame`-ийг аргумент болгон авдаг.
/// Энэ нь арын трасс хийх зарим платформ хэрэгжилтийг илүү нарийвчлалтай тэмдэглэгээний мэдээлэл эсвэл жишээлбэл дотор шугамуудын талаархи мэдээллийг өгөх боломжийг олгодог.
///
/// Хэрэв та боломжтой бол үүнийг ашиглахыг зөвлөж байна.
///
/// # Шаардлагатай шинж чанарууд
///
/// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
///
/// # Panics
///
/// Энэ функц нь хэзээ ч panic-тэй байхыг хичээдэг боловч хэрэв `cb` panics-ийг хангаж өгдөг бол зарим платформууд нь panic-ийг давхар цуцлах болно.
/// Зарим платформууд нь эргээд буцааж буцааж өгөх боломжгүй дуудлагыг ашигладаг C номын санг ашигладаг тул `cb`-ээс сандрах нь процессыг зогсооход хүргэж болзошгүй юм.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // зөвхөн дээд хүрээг хар
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Стекийн фрэймүүдийн IP утга нь ихэвчлэн стекийн ул мөр болох дуудлагын дараах (always?) заавар юм.
// Үүнийг бэлгэдэх нь filename/line дугаарыг нэгээр тэргүүлж, функцын төгсгөлд ойрхон байвал хүчингүй болгоход хүргэдэг.
//
// Энэ нь үндсэндээ бүх платформ дээр үргэлж тохиолддог тул бид шийдсэн ip-ээс нэгийг нь буцааж өгөх зааврын оронд өмнөх дуудлагын заавраар шийддэг.
//
//
// Бид үүнийг хийхгүй байх нь дээр.
// `resolve` API-г дуудаж байгаа хүмүүс -1-ийг гараар хийхийг шаардаж, байршлын мэдээллийг одоогийн биш харин *өмнөх* зааврын дагуу хийхийг хүсч байна.
// Хэрэв бид үнэхээр дараагийн зааварчилгаа эсвэл одоогийн хаяг бол бид `Frame` дээр гарах болно.
//
// Одоогийн байдлаар энэ нь нэлээд анхаарал татсан асуудал тул бид дотооддоо үргэлж нэгийг хасдаг.
// Хэрэглэгчид үргэлжлүүлэн ажиллаж, маш сайн үр дүнд хүрч байх ёстой тул бид хангалттай сайн байх ёстой.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve`-тэй адилхан, синхрончлогдоогүй тул зөвхөн аюулгүй байдаг.
///
/// Энэ функц нь синхрончлолын гарын авлагагүй боловч энэ crate-ийн `std` функцийг хөрвүүлээгүй үед ашиглах боломжтой.
/// Илүү олон баримт бичиг, жишээ авахын тулд `resolve` функцийг үзнэ үү.
///
/// # Panics
///
/// `cb`-ийг сандаргахад анхааруулах зүйлсийн талаар `resolve` дээрх мэдээллийг үзнэ үү.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame`-тэй адилхан, синхрончлогдоогүй тул зөвхөн аюулгүй байдаг.
///
/// Энэ функц нь синхрончлолын гарын авлагагүй боловч энэ crate-ийн `std` функцийг хөрвүүлээгүй үед ашиглах боломжтой.
/// Илүү олон баримт бичиг, жишээ авахын тулд `resolve_frame` функцийг үзнэ үү.
///
/// # Panics
///
/// `cb`-ийг сандаргахад анхааруулах зүйлсийн талаар `resolve_frame` дээрх мэдээллийг үзнэ үү.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Файл дахь тэмдэгийн нарийвчлалыг илэрхийлсэн trait.
///
/// Энэ trait нь `backtrace::resolve` функцэд хаагдахад trait объект болж өгдөг бөгөөд энэ нь цаана нь хэрэгжиж байгаа нь тодорхойгүй тул бараг илгээгддэг.
///
///
/// Тэмдэгт нь функцын талаархи контекст мэдээллийг өгөх боломжтой, жишээлбэл нэр, файлын нэр, мөрийн дугаар, нарийн хаяг гэх мэт.
/// Бүх мэдээллийг үргэлж бэлгэдэл хэлбэрээр авах боломжгүй байдаг тул бүх аргууд нь `Option`-ийг буцаадаг.
///
///
pub struct Symbol {
    // TODO: энэ насан туршийн холболтыг эцэст нь `Symbol` хүртэл хадгалах хэрэгтэй,
    // гэхдээ одоогоор энэ бол маш том өөрчлөлт юм.
    // `Symbol` нь зөвхөн лавлагаагаар тараагддаг тул хуулбарлах боломжгүй тул одоогоор энэ нь аюулгүй юм.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Энэ функцын нэрийг буцаана.
    ///
    /// Буцаж ирсэн бүтцийг тэмдгийн нэрний талаар янз бүрийн шинж чанараас асуухад ашиглаж болно:
    ///
    ///
    /// * `Display` програм нь буулгасан тэмдгийг хэвлэх болно.
    /// * Тэмдгийн түүхий `str` утгад хандах боломжтой (хэрэв utf-8 хүчинтэй бол).
    /// * Тэмдгийн нэрний түүхий байт руу нэвтрэх боломжтой.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Энэ функцийн эхлэх хаягийг буцаана.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Түүхий файлын нэрийг зүсмэл болгон буцаана.
    /// Энэ нь `no_std` орчинд голчлон хэрэгтэй байдаг.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Энэ тэмдэг одоо хэрэгжиж байгаа баганын дугаарыг буцаана.
    ///
    /// Зөвхөн gimli нь одоогоор зөвхөн `filename` нь `Some`-ийг буцааж өгсөн тохиолдолд л ийм утгыг өгдөг бөгөөд ингэснээр ижил төстэй анхааруулгад хамаарна.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Энэ тэмдэг одоо хэрэгжиж байгаа мөрийн дугаарыг буцаана.
    ///
    /// Хэрэв `filename` нь `Some`-ийг буцааж өгвөл энэ өгөөжийн утга нь ихэвчлэн `Some` байх ба үүнтэй ижил төстэй анхааруулгад хамаарна.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Энэ функцийг тодорхойлсон файлын нэрийг буцаана.
    ///
    /// Энэ нь одоогоор libbacktrace эсвэл gimli-г ашиглаж байх үед л боломжтой (ж.нь.
    /// unix бусад платформууд) болон хоёртын файлыг debuginfo-той хөрвүүлэх үед.
    /// Хэрэв эдгээр нөхцлүүдийн аль нь ч хангагдаагүй бол энэ нь `None`-ийг буцааж өгөх болно.
    ///
    /// # Шаардлагатай шинж чанарууд
    ///
    /// Энэ функц нь `backtrace` crate-ийн `std` функцийг идэвхжүүлсэн байхыг шаарддаг бөгөөд `std` функц нь анхдагчаар идэвхждэг.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Магадгүй задалсан тэмдгийг Rust гэж задлах нь бүтэлгүйтвэл C++ тэмдэгтийг задалж магадгүй юм.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // `cpp_demangle` функцийг идэвхгүй болгоход үнэ төлбөргүй байхын тулд үүнийг тэг хэмжээтэй байлгах хэрэгтэй.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Бэлгэдсэн нэр, түүхий байт, түүхий мөр гэх мэт эргономик хандалтыг хангах тэмдгийн нэрийг тойрсон боодол.
///
// `cpp_demangle` функцийг идэвхжүүлээгүй үед үхсэн кодыг зөвшөөрөх.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Түүхий байтаас шинэ тэмдгийн нэрийг үүсгэдэг.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Тэмдэгт utf-8 хүчин төгөлдөр байвал түүхий (mangled) тэмдгийн нэрийг `str` болгож буцаана.
    ///
    /// Хэрэв та буулгасан хувилбарыг хүсч байвал `Display` програмыг ашигла.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Түүхий тэмдгийн нэрийг байтын жагсаалт болгон буцаана
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Хэрэв буулгасан тэмдэг нь үнэндээ хүчин төгөлдөр бус байвал үүнийг хэвлэж магадгүй тул алдааг гадагш нь тараахгүйгээр сайн зохицуулна уу.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Хаягуудыг бэлгэдэхэд ашигладаг кэш санах ойг буцааж авах оролдлого.
///
/// Энэ арга нь глобал хэлбэрээр хадгалагдсан, эсвэл DWARF-ийн задалсан мэдээллийг төлөөлдөг урсгалд агуулагдсан глобал өгөгдлийн бүтцийг суллахыг оролдох болно.
///
///
/// # Caveats
///
/// Энэ функцийг үргэлж ашиглах боломжтой байдаг ч ихэнх хэрэгжүүлэлт дээр юу ч хийдэггүй.
/// Dbghelp эсвэл libbacktrace гэх мэт сангууд нь төлөвийг хуваарилах, хуваарилагдсан санах ойг удирдах байгууламжаар хангадаггүй.
/// Одоогийн байдлаар энэ crate-ийн `gimli-symbolize` онцлог нь энэ функцэд ямар нэгэн нөлөө үзүүлэх цорын ганц онцлог юм.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}