//! Libbacktrace дээр DWARF-ийг задлах кодыг ашиглан бэлгэдлийн стратеги.
//!
//! Ихэвчлэн gcc-т тараагддаг libbacktrace C номын сан нь зөвхөн буцах мөрийг үүсгэхийг (бид үүнийг ашигладаггүй) дэмждэг төдийгүй мөрийг бэлгэдэж, доторлогоотой жааз, юу ч биш гэх мэт одой дибаг хийх мэдээллийг дэмждэг.
//!
//!
//! Энд янз бүрийн асуудлуудаас болж харьцангуй төвөгтэй байгаа боловч үндсэн санаа нь:
//!
//! * Эхлээд бид `backtrace_syminfo` руу залгана.Энэ нь динамик тэмдэглэгээний хүснэгтээс хэрэв боломжтой бол тэмдгийн мэдээллийг авдаг.
//! * Дараа нь бид `backtrace_pcinfo` руу залгана.Энэ нь debuginfo хүснэгтүүд байгаа бол тэдгээрийг задлан шинжилж, дотогшоо хүрээ, файлын нэр, мөрийн дугаар гэх мэт мэдээллийг сэргээх боломжийг бидэнд олгоно.
//!
//! Одой ширээнүүдийг libbacktrace-т оруулах талаар олон заль мэх байдаг, гэхдээ энэ нь дэлхийн төгсгөл биш бөгөөд доор уншихад хангалттай тодорхой байна гэж найдаж байна.
//!
//! Энэ бол MSVC болон OSX бус платформуудын анхдагч бэлгэдлийн стратеги юм.Энэ нь OSX-ийн анхдагч стратеги юм.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Хэрэв боломжтой бол debuginfo-оос ирдэг `function` нэрийг илүүд үздэг бөгөөд жишээлбэл дотор шугамд илүү нарийвчлалтай байж болно.
                // Хэрэв энэ нь байхгүй бол `symname`-д заасан хүснэгтийн нэр рүү буцаж орно уу.
                //
                // Заримдаа `function` нь арай бага нарийвчлалтай санагддаг, жишээлбэл, `std::panicking::try::do_call`-ийн `try<i32,closure>` биш гэж жагсдаг болохыг анхаарна уу.
                //
                // Яагаад үнэхээр тодорхойгүй байгаа ч `function` нэр нь илүү нарийвчлалтай санагдаж байна.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // одоохондоо юу ч хийхгүй
}

/// `syminfo_cb`-д дамжуулсан `data` заагчийн төрөл
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Энэ дуудлага `backtrace_syminfo`-ээс дуудагдаж эхэлмэгц бид `backtrace_pcinfo` руу залгахаар цааш явна.
    // `backtrace_pcinfo` функц нь дибаг хийх мэдээлэлтэй зөвлөлдөх ба file/line мэдээллийг сэргээх, доторлогоотой жааз хийх гэх мэт зүйлийг хийхийг оролдох болно.
    // Хэрэв дибаг хийх мэдээлэл байхгүй бол `backtrace_pcinfo` бүтэлгүйтэх эсвэл их зүйл хийхгүй гэдгийг анхаарна уу, тиймээс ийм тохиолдолд бид буцааж дуудлага хийхдээ `syminfo_cb`-ээс дор хаяж нэг тэмдэг бүхий дуудлага хийх болно.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `pcinfo_cb`-д дамжуулсан `data` заагчийн төрөл
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API нь төлөв үүсгэхийг дэмждэг боловч төлөвийг устгахыг дэмждэггүй.
// Би хувьдаа төрийг бүтээж, дараа нь мөнхөд оршин тогтнох ёстой гэсэн утгаар ойлгож байгаа.
//
// Би энэ байдлыг цэвэрлэдэг at_exit() боловсруулагчийг бүртгүүлэхийг хүсч байна, гэхдээ libbacktrace нь үүнийг хийх ямар ч боломжгүй юм.
//
// Эдгээр хязгаарлалтын дагуу энэ функц нь үүнийг анх удаа шаардахад тооцоотой статик кэш төлөвтэй байдаг.
//
// Арын бичлэг хийх нь бүгд цуврал байдлаар явагддаг гэдгийг санаарай (нэг дэлхийн түгжээ).
//
// Синхрончлол байхгүй байгаа нь `resolve`-ийг гаднаас синхрончлох шаардлагаас үүдэлтэй болохыг анхаарна уу.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Libbacktrace-ийн threadsafe чадварыг бүү ашиглаарай.
        //
        0,
        error_cb,
        ptr::null_mut(), // нэмэлт өгөгдөл байхгүй
    );

    return STATE;

    // Libbacktrace-ийг ажиллуулахын тулд DWARF-ийн одоогийн гүйцэтгэх програмын дибаг хийх мэдээллийг хайж олох хэрэгтэй.Энэ нь ихэвчлэн хэд хэдэн механизмаар хийгддэг боловч үүгээр хязгаарлагдахгүй.
    //
    // * /proc/self/exe дэмжигдсэн платформууд дээр
    // * Төлөв үүсгэх үед файлын нэр шууд дамжуулагдав
    //
    // Libbacktrace номын сан нь том хэмжээний C код юм.Энэ нь санах ойн аюулгүй байдлын эмзэг байдлыг олж авах болно гэсэн үг юм, ялангуяа буруу боловсруулсан debuginfo-тэй харьцах үед.
    // Либстд эдгээрийн ихэнхийг түүхэн байдлаар туршиж үзсэн.
    //
    // Хэрэв /proc/self/exe ашиглаж байгаа бол libbacktrace нь "mostly correct" гэж үздэг тул "attempted to be correct" одой дибаг хийх мэдээлэлтэй хачин зүйл хийдэггүй гэж үзвэл бид эдгээрийг үл тоомсорлож болно.
    //
    //
    // Хэрэв бид файлын нэрээр дамжуулсан бол хорлонтой жүжигчид тухайн байршилд дурын файл байрлуулахад хүргэж болзошгүй зарим платформууд (BSD гэх мэт) дээр боломжтой байдаг.
    // Хэрэв бид libbacktrace файлын нэрний талаар дурдах юм бол дурын файл ашиглаж болзошгүй тул segfaults-ийг үүсгэж болзошгүй юм.
    // Хэрэв бид libbacktrace-д юу ч хэлэхгүй бол /proc/self/exe шиг замыг дэмждэггүй платформ дээр юу ч хийхгүй болно!
    //
    // Бид файлын нэрийг оруулахгүй байхын тулд аль болох их хичээдэг боловч /proc/self/exe-ийг огт дэмждэггүй платформ дээр ажиллах ёстой.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Бид `std::env::current_exe`-ийг ашиглах нь зүйтэй боловч энд `std` шаардах боломжгүй гэдгийг анхаарна уу.
            //
            // `_NSGetExecutablePath`-ийг ашиглан одоогийн гүйцэтгэгдэх замыг статик хэсэгт ачаална уу (хэрэв энэ нь хэтэрхий жижиг бол зүгээр л бууж өг).
            //
            //
            // Бид libbacktrace-д авлигад автагдсан гүйцэтгэгч програмууд дээр үхэхгүй гэдэгт маш их итгэж байгаа боловч энэ нь үнэхээр ... гэдгийг анхаарна уу.
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows файл нээх горимтой бөгөөд нээсний дараа устгах боломжгүй байдаг.
            // Энэ нь ерөнхийдөө бидний хүсч байгаа зүйл юм, учир нь дурын өгөгдлийг libbacktrace руу шилжүүлэх чадварыг бууруулж (үүнийг буруу ашигласан байж магадгүй) libbacktrace-д шилжүүлсний дараа бидний гүйцэтгэх боломжтой зүйл бидний дороос өөрчлөгдөхгүй байхыг баталгаажуулахыг хүсч байгаа юм.
            //
            //
            // Бид өөрсдийнхөө дүр төрхийг түгжихийг оролдохын тулд энд жаахан бүжиг хийдэг болохыг харгалзан үзвэл:
            //
            // * Одоогийн үйл явцтай танилцах, түүний файлын нэрийг ачаалах.
            // * Файлын нэр дээр файлыг зөв тугуудаар нээнэ үү.
            // * Одоогийн процессын файлын нэрийг дахин ачаалж, ижил байгаа эсэхийг шалгаарай
            //
            // Хэрэв энэ бүхэн биелвэл бид онолын хувьд бидний процессын файлыг нээсэн бөгөөд энэ нь өөрчлөгдөхгүй гэсэн баталгаа юм.FWIW-ийн нэг хэсэг нь libstd-ээс түүхэн хуулбарлагдсан тул энэ нь юу болж байгааг миний хамгийн сайн тайлбарлаж байна.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Энэ нь статик санах ойд амьдардаг тул бид үүнийг буцааж өгч чадна.
                static mut BUF: [i8; N] = [0; N];
                // ... энэ нь түр зуурынх тул стек дээр амьдардаг
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // `handle`-ийг зориудаар энд алдагдуулж байгаа тул энэ файлын нэр дээрх түгжээг хадгалах хэрэгтэй.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Бид цуцлагдсан зүсмэлийг буцааж өгөхийг хүсч байгаа тул хэрэв бүх зүйлийг бөглөсөн бөгөөд энэ нь нийт урттай тэнцвэл дараа нь үүнийг бүтэлгүйтэлтэй тэнцүүлнэ.
                //
                //
                // Үгүй бол амжилтыг буцааж өгөхдөө nul байтыг зүсмэл дотор оруулсан эсэхийг шалгаарай.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // буцах мөрний алдаанууд одоогоор хивсний доор арчигдаж байна
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API руу залгах хэрэгтэй (код уншсанаас хойш) `syminfo_cb`-ийг яг нэг удаа дуудах ёстой (эсвэл алдаа гарахгүй байж магадгүй юм).
    // Дараа нь бид `syminfo_cb` хүрээнд илүү их зүйлийг зохицуулдаг.
    //
    // `syminfo` нь хоёртын файлд дибаг хийх мэдээлэл байхгүй байсан ч гэсэн тэмдгийн нэрийг хайж олох тул тэмдгийн хүснэгттэй зөвлөлдөх болно.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}