// яг одоо Linux дээр ашиглагдаж байгаа тул үхсэн кодыг өөр газар олгоно уу
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Байт буферт зориулсан энгийн талбайн хуваарилагч.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Тодорхой хэмжээний буферийг хуваарилж, өөрчлөгдөж болох лавлагааг буцаана.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // АЮУЛГҮЙ БАЙДАЛ: энэ бол хэзээ ч өөрчлөгдөж болдог цорын ганц функц юм
        // `self.buffers`-ийн лавлагаа.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // АЮУЛГҮЙ БАЙДАЛ: бид `self.buffers`-ээс элементүүдийг хэзээ ч устгадаггүй тул лавлагаа болно
        // ямар ч буфер доторх өгөгдөлд `self` ашиглагдах хүртэл амьдрах болно.
        &mut buffers[i]
    }
}