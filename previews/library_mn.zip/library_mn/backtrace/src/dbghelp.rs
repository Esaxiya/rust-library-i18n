//! Windows дээр dbghelp холболтыг удирдахад туслах модуль
//!
//! Windows дээрх backtraces (дор хаяж MSVC-ийн хувьд) нь `dbghelp.dll` ба түүний агуулсан янз бүрийн функцээр ихээхэн тэжээгддэг.
//! Эдгээр функцууд нь `dbghelp.dll`-ийг статикаар холбохоос илүү *динамикаар* ачаалагдаж байна.
//! Энэ нь одоогоор стандарт номын сангаар хийгддэг (гэхдээ онолын хувьд тэнд шаардагддаг) боловч номын сангийн статик dll хамаарлыг багасгахад туслах хүчин чармайлт юм.
//!
//! Үүнийг хэлэхэд `dbghelp.dll` нь Windows дээр бараг үргэлж амжилттай ачаалагддаг.
//!
//! Бид энэ бүх дэмжлэгийг динамикаар ачаалах тул `winapi`-д түүхий тодорхойлолтыг ашиглах боломжгүй, харин функцын заагчийн төрлийг өөрсдөө тодорхойлж, ашиглах хэрэгтэй гэдгийг анхаарна уу.
//! Бид winapi-г хуулбарлах бизнес эрхлэхийг үнэхээр хүсэхгүй байгаа тул бүх холболтууд winapi-тэй тохирч байгаа бөгөөд энэ функцийг CI дээр идэвхжүүлсэн болохыг баталж байгаа Cargo `verify-winapi` онцлогтой.
//!
//! Эцэст нь хэлэхэд, `dbghelp.dll`-д зориулсан DLL файлыг хэзээ ч буулгахгүй гэдгийг энд тэмдэглэх болно.
//! Бид үүнийг дэлхийн хэмжээнд кэш хийж, API руу дуудлага хийх хооронд ашиглах боломжтой бөгөөд үнэтэй loads/unloads-ээс зайлсхийх боломжтой гэж бодож байна.
//! Хэрэв энэ нь гоожих мэдрэгч эсвэл үүнтэй төстэй асуудал байвал бид тэнд очоод гүүрээр гарах боломжтой.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Winapi-д байхгүй `SymGetOptions` ба `SymSetOptions`-ийг ажиллуул.
// Үгүй бол энэ нь зөвхөн winapi-тэй холбоотой төрлийг давхар шалгаж байх үед л ашиглагдана.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Winapi дээр хараахан тодорхойлогдоогүй байна
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Үүнийг winapi-д тодорхойлсон боловч буруу байна (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Winapi дээр хараахан тодорхойлогдоогүй байна
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Энэ макро нь `Dbghelp` бүтцийг тодорхойлоход хэрэглэгддэг бөгөөд бидний ачаалж болох бүх функциональ заагчийг дотооддоо агуулдаг.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll`-д зориулж ачаалагдсан DLL
            dll: HMODULE,

            // Бидний ашиглаж болох функц бүрийн функцын заагч
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Эхлээд бид DLL-ийг ачаалаагүй байна
            dll: 0 as *mut _,
            // Эхний үед бүх функцийг динамикаар ачаалах шаардлагатай гэж тэг гэж тохируулсан болно.
            //
            $($name: 0,)*
        };

        // Функцийн төрөл тус бүрт тав тухтай typedef.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll`-ийг нээх оролдлогууд.
            /// Хэрэв ажиллавал амжилтыг эсвэл `LoadLibraryW` бүтэлгүйтсэн тохиолдолд алдаа буцаана.
            ///
            /// Хэрэв номын сан аль хэдийн ачаалагдсан бол Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Бидний ашиглахыг хүссэн арга бүрийн функц.
            // Үүнийг дуудахад кэш функцийн заагчийг унших эсвэл ачаалах ба ачаалагдсан утгыг буцаана.
            // Ачаалал амжилтанд хүрнэ гэж баталж байна.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp функцийг лавлахын тулд цэвэрлэх түгжээг ашиглахад тохиромжтой прокси.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Энэ crate-ээс `dbghelp` API функцуудад нэвтрэхэд шаардлагатай бүх дэмжлэгийг эхлүүлнэ.
///
///
/// Энэ функц нь **аюулгүй** бөгөөд дотооддоо өөрийн синхрончлолтой болохыг анхаарна уу.
/// Энэ функцийг олон удаа давтаж дуудах нь аюулгүй гэдгийг анхаарна уу.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Бидний хийх ёстой хамгийн эхний зүйл бол энэ функцийг синхрончлох явдал юм.Үүнийг бусад утаснаас зэрэгцээ эсвэл нэг утас дотор рекурсив байдлаар дуудаж болно.
        // Үүнээс илүү зальтай гэдгийг анхаарна уу, гэхдээ `dbghelp`,*мөн* энэ процесст бусад бүх дуудлага хийгчдийг `dbghelp` руу синхрончлох шаардлагатай байдаг.
        //
        // Ихэвчлэн `dbghelp` руу ижил процессын хүрээнд тийм ч олон дуудлага байдаггүй бөгөөд бид зөвхөн үүнд нэвтэрч байгаа гэж аюулгүйгээр бодож магадгүй юм.
        // Гэсэн хэдий ч бидний санаа зовох ёстой нэг гол хэрэглэгчид байдаг бөгөөд энэ нь хачирхалтай нь өөрсдөө, гэхдээ стандарт номын санд байдаг.
        // Rust стандарт номын сан нь буцах мөрний дэмжлэгийн энэ crate-ээс хамаардаг бөгөөд энэ crate нь crates.io дээр бас байдаг.
        // Энэ нь стандарт номын сан panic-ийн арын мөрийг хэвлэж байгаа бол энэ нь crates.io-ээс гарах crate-тэй уралдаж, хагарал үүсгэж болзошгүй гэсэн үг юм.
        //
        // Энэ синхрончлолын асуудлыг шийдвэрлэхэд туслахын тулд бид Windows-тэй холбоотой тусгай арга хэрэглэдэг (энэ нь синхрончлолын талаархи Windows-ийн хязгаарлалт юм).
        // Бид энэ дуудлагыг хамгаалахын тулд мутекс *нэртэй* session-local * үүсгэнэ.
        // Энд стандарт номын сан болон энэ crate нь энд синхрончлохын тулд Rust түвшний API-г хуваалцах шаардлагагүй харин хөшигний ард ажиллаж, бие биетэйгээ синхрончилж байгаа эсэхийг шалгаарай.
        //
        // Энэ функцийг стандарт номын сан эсвэл crates.io-ээр дамжуулан дуудахад ижил мутексийг олж авч байгаа гэдэгт бид итгэж болно.
        //
        // Энэ бүхэн бол бидний хамгийн түрүүнд хийдэг зүйл бол X001 дээр нэрлэсэн мутекс болох `HANDLE`-ийг атомаар үүсгэдэг гэсэн үг юм.
        // Бид энэ функцийг тусгайлан хуваалцаж буй бусад thread-уудтай синхрончлох бөгөөд энэ функцын жишээнд зөвхөн нэг бариул үүсгэхийг баталгаажуулдаг.
        // Дэлхий дахинд хадгалагдсаны дараа бариул хэзээ ч хаагддаггүйг анхаарна уу.
        //
        // Бид цоожоо ажиллуулсны дараа үүнийг олж авдаг бөгөөд бидний тарааж өгдөг `Init` бариул нь эцэст нь унах үүрэгтэй болно.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // За, хүү!Бүгдээрээ аюулгүй синхрончлогдсон тул бүх зүйлийг боловсруулж эхэлье.
        // Нэгдүгээрт, бид энэ процесст `dbghelp.dll`-ийг үнэхээр ачааллаж байгаа эсэхийг баталгаажуулах хэрэгтэй.
        // Статик хараат байдлаас зайлсхийхийн тулд бид үүнийг динамикаар хийдэг.
        // Энэ нь хачин холболттой асуудлуудыг тойрон гарахын тулд түүхэн байдлаар хийгдсэн бөгөөд хоёртын файлыг арай зөөврийн болгох зорилготой бөгөөд энэ нь ихэвчлэн дибаг хийх хэрэгсэл юм.
        //
        //
        // `dbghelp.dll`-ийг нээсний дараа зарим эхлүүлэх функцуудыг дуудах шаардлагатай бөгөөд доор дэлгэрэнгүй тайлбарлавал.
        // Гэхдээ бид үүнийг ганц л удаа хийдэг тул бид одоо болтол хийгээгүйгээ харуулсан дэлхийн хэмжээний boolean-ийг авсан болно.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` тугийг тохируулсан эсэхийг шалгаарай, учир нь MSVC-ийн өөрийн баримт бичигт заасны дагуу: "This is the fastest, most efficient way to use the symbol handler.", тэгвэл тэгье!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // MSVC ашиглан тэмдэгтүүдийг эхлүүлэх.Энэ нь бүтэлгүйтэж болохыг анхаарна уу, гэхдээ бид үл тоомсорлож байна.
        // Урьдчилсан байдлаар нэг ч тонн урлаг байдаггүй, гэхдээ LLVM нь дотооддоо буцаах утгыг үл тоомсорлож байгаа бөгөөд LLVM дахь ариутгагч номын сангуудын нэг нь бүтэлгүйтсэн тохиолдолд аймшигтай анхааруулга хэвлүүлж өгдөг боловч урт хугацаанд үүнийг үл тоомсорлодог.
        //
        //
        // Энэ нь Rust-д маш их тохиолддог нэг тохиолдол бол стандарт номын сан болон crates.io дээрх crate хоёулаа `SymInitializeW`-ийн төлөө өрсөлдөхийг хүсч байгаа явдал юм.
        // Стандарт номын сан нь түүхэндээ ихэнхдээ дараа нь цэвэрлэх ажлыг эхлүүлэхийг хүсдэг байсан бол одоо энэ crate-ийг ашиглаж байгаа тул хэн нэгэн нь эхлүүлэх ажлыг эхлүүлж, нөгөө нь уг эхлүүлэлтийг авах болно гэсэн үг юм.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}