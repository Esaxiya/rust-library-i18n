# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust-т ажиллах цагаар backtraces авах номын сан.
Энэхүү номын сан нь програмын интерфэйсээр хангаж стандарт номын сангийн дэмжлэгийг сайжруулахыг зорьж байгаа боловч libstd-ийн panics шиг одоогийн арын мөрийг хялбархан хэвлэхийг дэмждэг.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Зөвхөн арын мөрийг барьж, үүнтэй харьцахаа хойшлуулахын тулд та дээд түвшний `Backtrace` төрлийг ашиглаж болно.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Хэрэв та бодит мөрдөх функцэд илүү их түүхий хандалт хийхийг хүсч байвал `trace` ба `resolve` функцуудыг шууд ашиглаж болно.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Энэ зааврын заагчийг тэмдгийн нэр дээр шийдвэрлэ
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // дараагийн хүрээ рүү үргэлжлүүлээрэй
    });
}
```

# License

Энэ төсөл нь лицензийн аль нэгнийх нь дагуу хийгддэг

 * Apache лиценз, хувилбар 2.0, ([LICENSE-APACHE](LICENSE-APACHE) эсвэл http://www.apache.org/licenses/LICENSE-2.0)
 * MIT лиценз ([LICENSE-MIT](LICENSE-MIT) эсвэл http://opensource.org/licenses/MIT)

таны сонголтоор.

### Contribution

Хэрэв та өөрөөр тодорхой заагаагүй бол Apache-2.0 лицензэд тодорхойлсон backtrace-rs-д оруулахаар санаатайгаар оруулсан аливаа хувь нэмрийг дээр дурдсанчлан нэмэлт нөхцөл, болзолгүйгээр давхар лицензтэй байх ёстой.







