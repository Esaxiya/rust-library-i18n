use backtrace::Backtrace;

// Энэхүү тест нь зөвхөн тэмдгийн эхлэх хаягийг мэдээлэх хүрээний хувьд `symbol_address` функцтэй платформ дээр ажилладаг.
// Үүний үр дүнд энэ нь зөвхөн цөөн хэдэн платформ дээр идэвхжсэн болно.
//
const ENABLED: bool = cfg!(all(
    // Windows үнэхээр туршиж үзээгүй байгаа бөгөөд OSX нь хаалтын хүрээ олохыг дэмжихгүй тул үүнийг идэвхгүй болго
    //
    target_os = "linux",
    // ARM дээр хаах функцийг олох нь ip-ийг өөрөө буцааж өгөх явдал юм.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}