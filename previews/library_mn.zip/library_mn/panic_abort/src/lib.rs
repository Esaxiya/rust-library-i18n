//! Үйл явцыг зогсоох замаар Rust panics-ийг хэрэгжүүлэх
//!
//! Энэхүү crate програмыг задлах замаар харьцуулж үзэхэд *хамаагүй* хялбар юм!Үүнийг хэлэхэд энэ нь тийм ч уян хатан биш боловч энд байна!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" ашигласан ачаалал ба тавцан дээрх холбогдох тасалдал.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal руу залгах
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows дээр процессорт зориулсан __fastfail механизмыг ашиглана уу.Windows 8 ба түүнээс хойшхи хувилбаруудад энэ нь процессын доторх үл хамаарах зохицуулагчийг ажиллуулахгүйгээр шууд процессыг зогсоох болно.
            // Windows-ийн өмнөх хувилбаруудад энэхүү дарааллын зааврыг хандалтыг зөрчсөн гэж үзэх бөгөөд процессыг зогсоох боловч бүх онцгой тохиолдлуудыг зохицуулахгүйгээр зайлшгүй оруулах болно.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: Энэ нь libstd-ийн `abort_internal`-тэй ижил хэрэгжүүлэлт юм
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Энэ ... жаахан сонин байна.Tl; dr;Энэ нь зөв холбоход шаардагдах бөгөөд урт тайлбарыг доор харуулав.
//
// Яг одоо бидний илгээж буй libcore/libstd-ийн хоёртын файлыг бүгдийг нь `-C panic=unwind`-той нэгтгэсэн болно.Хоёртын файлыг аль болох олон нөхцөл байдалд хамгийн их нийцүүлэхийн тулд үүнийг хийдэг.
// Гэхдээ хөрвүүлэгч нь `-C panic=unwind`-той хөрвүүлсэн бүх функцэд "personality function" шаарддаг.Энэхүү хувийн функцийг `rust_eh_personality` тэмдэгт хатуу кодчилдог бөгөөд `eh_personality` lang зүйлээр тодорхойлно.
//
// So...
// яагаад зөвхөн энэ lang зүйлийг энд тодорхойлж болохгүй гэж?Сайн асуулт!panic ажиллах цаг хугацааг хооронд нь холбох арга нь хөрвүүлэгчийн crate дэлгүүрт байгаа "sort of" гэдгээрээ ялимгүй нарийн байдаг, гэхдээ өөр холболт хийгдээгүй тохиолдолд л холбогддог.
//
// Энэ нь crate болон panic_unwind crate хоёулаа хөрвүүлэгчийн crate дэлгүүрт гарч болох бөгөөд хэрэв хоёулаа `eh_personality` lang зүйлийг тодорхойлвол алдаа гарна гэсэн үг юм.
//
// Үүнийг хөрвүүлэхийн тулд зөвхөн panic-ийн ажиллуулах цаг нь завсарлагааны цаг байх тохиолдолд `eh_personality`-ийг тодорхойлсон байх ёстой, өөрөөр хэлбэл үүнийг тодорхойлох шаардлагагүй (зөв зүйтэй).
// Гэхдээ энэ тохиолдолд энэ номын сан нь энэ тэмдгийг тодорхойлдог тул хаа нэг газар дор хаяж хувь хүн байдаг.
//
// Үндсэндээ энэ тэмдэг нь libcore/libstd хоёртын файлтай холболт хийхийн тулд л тодорхойлогдсон байдаг, гэхдээ бид хэзээ ч завсарлагааны цагийг холбодоггүй тул үүнийг хэзээ ч дуудах ёсгүй.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // X86_64-pc-windows-gnu дээр бид бүх фрэймүүдээ дамжуулж байх явцад `ExceptionContinueSearch`-ийг буцааж өгөх шаардлагатай өөрийн хувийн функцийг ашигладаг.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Дээрхтэй адил энэ нь зөвхөн одоо Emscripten дээр ашиглагддаг `eh_catch_typeinfo` lang зүйлтэй тохирч байна.
    //
    // panics нь үл хамаарах зүйл үүсгэдэггүй тул гадны онцгой тохиолдлууд нь -C panic=цуцлах UB (одоогоор өөрчлөгдөж магадгүй) тул ямар ч catch_unwind дуудлага хэзээ ч энэ type-г ашиглахгүй.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Эдгээр хо iрыг i686-pc-windows-gnu дээрх эхлүүлэх объектууд дууддаг боловч тэдгээр нь ямар ч зүйл хийх шаардлагагүй тул бие нь нойр юм.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}