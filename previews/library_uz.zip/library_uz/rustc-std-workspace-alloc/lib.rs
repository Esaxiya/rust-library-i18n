#![feature(no_core)]
#![no_core]

// Ushbu crate nima uchun kerakligini rustc-std-ish joyi-yadrosiga qarang.

// Liballoc-da ajratish moduli bilan ziddiyatni oldini olish uchun crate nomini o'zgartiring.
extern crate alloc as foo;

pub use foo::*;