use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Bizning `#[assert_instr]` izohlarimizga barcha simd ichki qurilmalar o'zlarining kodgenlarini sinab ko'rish uchun foydalanishlari mumkinligini aytish uchun ishlatiladi, chunki ba'zilari hozirda `#[target_feature]`-da hech qanday ekvivalenti bo'lmagan qo'shimcha `-Ctarget-feature=+unimplemented-simd128` orqasida joylashgan.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}