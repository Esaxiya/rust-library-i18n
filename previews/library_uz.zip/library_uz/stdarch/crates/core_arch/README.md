`core::arch` - Rust ning asosiy kutubxonasi me'morchiligiga xos ichki narsalar
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` moduli me'morchilikka bog'liq ichki xususiyatlarni (masalan, SIMD) amalga oshiradi.

# Usage 

`core::arch` `libcore` ning bir qismi sifatida mavjud va u `libstd` tomonidan qayta eksport qilinadi.Ushbu crate dan ko'ra `core::arch` yoki `std::arch` orqali foydalanishni afzal biling.
`feature(stdsimd)` orqali ko'pincha Rust-da beqaror xususiyatlar mavjud.

`core::arch`-ni ushbu crate orqali ishlatish uchun tungi Rust kerak va u tez-tez sinishi mumkin (va).Ushbu crate orqali foydalanishni o'ylashingiz kerak bo'lgan yagona holatlar:

* agar siz `core::arch`-ni o'zingiz qayta kompilyatsiya qilishingiz kerak bo'lsa, masalan, `libcore`/`libstd` uchun yoqilmagan maqsadli xususiyatlar yoqilgan bo'lsa.
Note: agar siz uni nostandart maqsad uchun qayta kompilyatsiya qilishingiz kerak bo'lsa, iltimos, ushbu crate o'rniga `xargo` dan foydalanishni va `libcore`/`libstd` ni kerakli tarzda qayta kompilyatsiya qilishni afzal ko'ring.
  
* beqaror Rust funktsiyalari ortida ham mavjud bo'lmasligi mumkin bo'lgan ba'zi xususiyatlardan foydalanish.Biz bularni minimal darajaga tushirishga harakat qilamiz.
Agar sizga ushbu funktsiyalarning bir qismini ishlatishingiz kerak bo'lsa, iltimos, biz ularni tungi Rust-da ochib berishimiz uchun siz shu erdan foydalanishingiz uchun muammoni oching.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` asosan MIT litsenziyasi va Apache litsenziyasi (2.0 versiyasi) shartlari asosida tarqatiladi, uning qismlari turli BSD-ga o'xshash litsenziyalar bilan qoplanadi.

Tafsilotlar uchun LICENSE-APACHE va LICENCE-MIT-ga qarang.

# Contribution

Agar siz boshqacha tarzda aniq ko'rsatmasangiz, siz 0Apache-2.0 litsenziyasida belgilangan `core_arch`-ga qo'shilish uchun ataylab topshirilgan har qanday hissa, qo'shimcha shartlar va shartlarsiz yuqoridagi kabi ikki tomonlama litsenziyaga ega bo'lishi kerak.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












