# Stdarch-ga hissa qo'shish

`stdarch` crate hissalarni qabul qilishga tayyor!Birinchidan, ehtimol siz omborni tekshirib ko'rishingiz va siz uchun testlar o'tganligiga ishonch hosil qilishingiz mumkin:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Bu erda `<your-target-arch>` `rustup` tomonidan ishlatilgan maqsad uchligi, masalan `x86_x64-unknown-linux-gnu` (oldingi `nightly-` yoki shunga o'xshashlarsiz).
Shuni ham yodda tutingki, ushbu omborga Rust tungi kanali kerak!
Yuqorida keltirilgan testlar, aslida `rustup default nightly` (va qaytarish uchun `rustup default stable`) dan foydalanishni sozlash uchun tungi rust-ni tizimingizda standart holatga keltirishni talab qiladi.

Agar yuqoridagi qadamlardan birortasi ishlamasa, [please let us know][new]!

Keyinchalik [find an issue][issues]-ga yordam berish uchun biz [`help wanted`][help] va [`impl-period`][impl] teglari bilan tanladik, ular ba'zi yordamlardan foydalanishlari mumkin. 
Sizni [#40][vendor] eng ko'p qiziqtirishi mumkin, bu x86-da barcha sotuvchilarning ichki xususiyatlarini amalga oshiradi.Ushbu masala qaerdan boshlash kerakligi haqida yaxshi ko'rsatmalarga ega!

Agar sizda umumiy savollar bo'lsa, [join us on gitter][gitter]-ga murojaat qiling va so'rang!@BurntSushi yoki@alexcrichton-ni savollar bilan ping qilishdan qo'rqmang.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Stdarch intrinsics uchun misollar qanday yoziladi

Berilgan ichki funktsiyani to'g'ri ishlashi uchun bir nechta xususiyatlarni yoqish kerak va bu xususiyat faqat protsessor tomonidan qo'llab-quvvatlanganda `cargo test --doc` tomonidan bajarilishi kerak.

Natijada, `rustdoc` tomonidan ishlab chiqarilgan standart `fn main` ishlamaydi (ko'p hollarda).
Sizning namunangiz kutilganidek ishlashini ta'minlash uchun quyidagilarni qo'llanma sifatida ko'rib chiqing.

```rust
/// # // Misol faqat bo'lishi uchun bizga cfg_target_feature kerak
/// # // CPU funktsiyani qo'llab-quvvatlaganida `cargo test --doc` tomonidan ishlaydi
/// # #![feature(cfg_target_feature)]
/// # // Intrinsic ishlashi uchun bizga target_feature kerak
/// # #![feature(target_feature)]
/// #
/// # // rustdoc sukut bo'yicha `extern crate stdarch`-dan foydalanadi, lekin bizga kerak
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Haqiqiy asosiy funktsiya
/// # fn main() {
/// #     // Buni faqat `<target feature>` qo'llab-quvvatlanadigan bo'lsa ishlating
/// #     agar cfg_feature_enabled! ("<target feature>"){
/// #         // `worker` funktsiyasini yarating, u faqat maqsad funktsiyasida ishlaydi
/// #         // qo'llab-quvvatlanadi va sizning ishchingiz uchun `target_feature` yoqilganligini ta'minlaydi
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         xavfli fn worker() {
/// // O'zingizning namunangizni bu erda yozing.Bu erda o'ziga xos xususiyatlar ishlaydi!Yirtqichga boring!
///
/// #         }
///
/// #         xavfli { worker(); }
/// #     }
/// # }
```

Agar yuqoridagi sintaksisning bir qismi tanish ko'rinmasa, [Rust Book] ning [Documentation as tests] qismida `rustdoc` sintaksisini juda yaxshi tavsiflaydi.
Har doimgidek, [join us on gitter][gitter]-dan bexabar bo'ling va bizdan biron bir zarbani urganligingizni so'rang va `stdarch` hujjatlarini yaxshilashga yordam berganingiz uchun tashakkur!

# Muqobil test sinovlari bo'yicha ko'rsatmalar

Sinovlarni o'tkazish uchun odatda `ci/run.sh` dan foydalanish tavsiya etiladi.
Ammo bu siz uchun ishlamasligi mumkin, masalan, agar siz Windows da bo'lsangiz.

Bunday holda siz kod ishlab chiqarishni sinash uchun `cargo +nightly test` va `cargo +nightly test --release -p core_arch`-ga qaytishingiz mumkin.
Shuni esda tutingki, ular uchun tungi asboblar zanjiri o'rnatilishi kerak va `rustc` sizning maqsadingiz uchligi va uning protsessori haqida bilishi kerak.
Xususan, X001 uchun bo'lgani kabi, siz `TARGET` muhit o'zgaruvchisini o'rnatishingiz kerak.
Bundan tashqari, maqsad xususiyatlarini ko'rsatish uchun `RUSTCFLAGS` (`C` kerak) ni o'rnatishingiz kerak, masalan `RUSTCFLAGS="-C -target-features=+avx2"`.
Agar siz "just" sizning hozirgi protsessoringizga qarshi rivojlanayotgan bo'lsa, siz `-C -target-cpu=native`-ni o'rnatishingiz mumkin.

Ushbu muqobil ko'rsatmalardan foydalanganda, masalan, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], ogohlantirilsin
yo'riqnomani yaratish sinovlari muvaffaqiyatsiz bo'lishi mumkin, chunki disassembler ularni boshqacha nomlagan, masalan
`aesenc` yo'riqnomalari o'rniga `vaesenc` ishlab chiqarishi mumkin, ular bir xil harakat qilishlariga qaramay.
Bundan tashqari, ushbu ko'rsatmalar odatdagidan kamroq testlarni bajaradi, shuning uchun siz oxir-oqibat so'ralganda ba'zi xatolar bu erda ko'rsatilmagan testlarda paydo bo'lishi mumkinligiga hayron bo'lmang.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






