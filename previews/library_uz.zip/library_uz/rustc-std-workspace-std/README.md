# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate uchun hujjatlarni ko'ring.