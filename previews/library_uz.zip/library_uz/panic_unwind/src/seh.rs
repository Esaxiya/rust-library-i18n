//! Windows SEH
//!
//! Windows-da (hozirda faqat MSVC-da) standart istisnolarni boshqarish mexanizmi Structured Exception Handling (SEH).
//! Bu mitti asosidagi istisnolardan foydalanishdan (masalan, boshqa unix platformalaridan foydalanadigan) kompilyator ichki qismidan ancha farq qiladi, shuning uchun LLVM SEH uchun yaxshi qo'shimcha yordamga ega bo'lishi kerak.
//!
//! Qisqacha aytganda, bu erda nima sodir bo'ladi:
//!
//! 1. `panic` funktsiyasi standart Windows funktsiyasini chaqiradi `_CxxThrowException`, C++ -ni istisno qilish uchun bo'shatish jarayonini keltirib chiqaradi.
//! 2.
//! Tuzuvchi tomonidan ishlab chiqarilgan barcha qo'nish maydonchalari XTX funktsiyasidan, CRT funktsiyasidan foydalaniladi va Windows dagi echish kodi ushbu shaxsiy funktsiyadan stekdagi barcha tozalash kodlarini bajarish uchun foydalanadi.
//!
//! 3. `invoke`-ga kompilyator tomonidan ishlab chiqarilgan barcha qo'ng'iroqlar `cleanuppad` LLVM ko'rsatmasi sifatida o'rnatilgan maydonchaga ega, bu tozalash tartibining boshlanishini bildiradi.
//! Shaxs (CRT-da belgilangan 2-bosqichda) tozalash tartib-qoidalarini bajarish uchun javobgardir.
//! 4. Oxir-oqibat ichki (kompilyator tomonidan yaratilgan) "catch" kodi bajariladi va boshqaruv Rust-ga qaytishi kerakligini ko'rsatadi.
//! Bu `catchswitch` va LLVM IR shartlarida `catchpad` buyrug'i orqali amalga oshiriladi va nihoyat `catchret` buyrug'i bilan dasturga normal boshqaruvni qaytaradi.
//!
//! gcc-ga asoslangan istisno ishlovidan ba'zi o'ziga xos farqlar quyidagilardir:
//!
//! * Rust shaxsiy xususiyatiga ega emas, uning o'rniga *har doim*`__CxxFrameHandler3` bo'ladi.Bundan tashqari, qo'shimcha filtrlash amalga oshirilmaydi, shuning uchun biz tashlagan turga o'xshash C++ istisnolarini qo'lga kiritamiz.
//! Istisnolarni Rust-ga tashlash baribir aniqlanmagan xatti-harakatlar ekanligini unutmang, shuning uchun bu yaxshi bo'lishi kerak.
//! * Bizda chegara bo'ylab, xususan `Box<dyn Any + Send>` orqali uzatiladigan ba'zi ma'lumotlar mavjud.Mittigina istisnolar singari, bu ikkita ko'rsatgich istisno o'zi uchun foydali yuk sifatida saqlanadi.
//! Ammo MSVC-da qo'shimcha yig'indilarni ajratishning hojati yo'q, chunki filtr funktsiyalari bajarilayotganda qo'ng'iroqlar to'plami saqlanib qoladi.
//! Bu shuni anglatadiki, ko'rsatgichlar to'g'ridan-to'g'ri `_CxxThrowException`-ga uzatiladi va ular filtr funktsiyasida tiklanib, ichki `try` stek ramkasiga yoziladi.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Bu Variant bo'lishi kerak, chunki biz istisnoni mos yozuvlar yordamida ushlaymiz va uning destruktori C++ ish vaqti bilan bajariladi.
    // Biz qutini istisno holatidan olib tashlaganimizda, uning halokati uchun qutini ikki marta tashlamasdan ishlashi uchun istisno holatini to'g'ri holatda qoldirishimiz kerak.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Birinchidan, butun turdagi ta'riflar.Bu erda platformaga xos g'alati holatlar mavjud va juda ko'p narsa LLVM-dan ochiqchasiga ko'chirilgan.Bularning barchasi maqsadi `_CxxThrowException` raqamiga qo'ng'iroq orqali quyidagi `panic` funktsiyasini amalga oshirishdir.
//
// Ushbu funktsiya ikkita dalilni oladi.Birinchisi, biz uzatadigan ma'lumotlarning ko'rsatgichi, bu holda bizning trait ob'ekti.Topish juda oson!Keyingi, ammo murakkabroq.
// Bu `_ThrowInfo` tuzilmasining ko'rsatgichi va odatda faqat tashlangan istisnolarni tasvirlash uchun mo'ljallangan.
//
// Hozirgi vaqtda ushbu turdagi [1] ta'rifi biroz tukli va asosiy g'alati narsa (va onlayn maqoladan farqi) shundaki, 32-bitda ko'rsatkichlar ko'rsatkichlar, 64-bitda ko'rsatkichlar 32-bitli ofset sifatida ko'rsatilgan `__ImageBase` belgisi.
//
// Buni ifodalash uchun quyidagi modullarda joylashgan `ptr_t` va `ptr!` so'llari ishlatiladi.
//
// Ushbu turdagi ta'riflar labirinti ham LLVM ushbu operatsiya uchun nimalar chiqarishini diqqat bilan kuzatib boradi.Masalan, agar siz ushbu C++ kodini MSVC-da kompilyatsiya qilsangiz va LLVM IR-ni chiqarsangiz:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      bo'sh joy foo() { rust_panic a = {0, 1};
//          uloqtirish;}
//
// Bu biz taqlid qilmoqchi bo'lgan narsadir.Quyidagi doimiy qiymatlarning aksariyati LLVM-dan ko'chirilgan,
//
// Qanday bo'lmasin, ushbu inshootlar barchasi o'xshash tarzda qurilgan va bu biz uchun shunchaki aniq.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Shuni esda tutingki, biz bu erda nomlarni o'zgartirish qoidalarini ataylab e'tiborsiz qoldiramiz: biz C++ ning `struct rust_panic`-ni e'lon qilish orqali Rust panics-ni qo'lga olishini istamaymiz.
//
//
// O'zgartirish paytida, tur nomi nomi qatori `compiler/rustc_codegen_llvm/src/intrinsic.rs`-da ishlatilgan bilan to'liq mos kelishiga ishonch hosil qiling.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Bu erda etakchi `\x01` bayti aslida LLVM uchun sehrli signal bo'lib, `_` belgisi bilan prefiks kabi boshqa biron bir manglingni qo'llamaydi *.
    //
    //
    // Ushbu belgi C++ ning `std::type_info` tomonidan ishlatiladigan vtable.
    // `std::type_info` tipidagi ob'ektlar, tip deskriptorlari ushbu jadvalga ko'rsatgichga ega.
    // Turlarning tavsiflovchilariga yuqorida tavsiflangan va biz quyida tuzilgan C++ EH tuzilmalari murojaat qiladi.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Ushbu turdagi tavsiflovchi faqat istisno chiqarilganda qo'llaniladi.
// Qo'lga olish qismi o'zlarining TypeDescriptor-larini yaratadigan try intrinsic tomonidan boshqariladi.
//
// Bu juda yaxshi, chunki MSVC ish vaqti ko'rsatgich tengligiga emas, balki TypeDescriptors-ga mos keladigan turdagi nomdagi satrlarni taqqoslashdan foydalanadi.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Agar C++ kodi istisnoni qo'lga kiritishga va uni tarqatmasdan tashlab qo'yishga qaror qilsa, foydalanuvchi destruktor
// Ichki sinashning ushlash qismi istisno ob'ektining birinchi so'zini 0 ga o'rnatadi, shunda u destruktor tomonidan o'tkazib yuboriladi.
//
// Shuni esda tutingki, x86 Windows standart "C" chaqiruv o'rniga C++ a'zo funktsiyalari uchun "thiscall" chaqiruv konventsiyasidan foydalanadi.
//
// Exception_copy funktsiyasi bu erda biroz o'ziga xos: u MSVC ish vaqti tomonidan try/catch bloki ostida chaqiriladi va biz bu erda ishlab chiqaradigan panic istisno nusxasi natijasida ishlatiladi.
//
// Bu C++ ish vaqti tomonidan std::exception_ptr bilan istisnolarni saqlashni qo'llab-quvvatlash uchun ishlatiladi, biz uni qo'llab-quvvatlay olmaymiz, chunki Box<dyn Any>klonlash mumkin emas.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException bu stack ramkasida to'liq bajariladi, shuning uchun `data` ni uyumga o'tkazishga hojat yo'q.
    // Biz bu funktsiyaga faqat stack ko'rsatkichini uzatamiz.
    //
    // ManualDrop bu erda kerak, chunki biz ochilayotganda istisno tushishini xohlamaymiz.
    // Buning o'rniga C++ ish vaqti tomonidan chaqiriladigan exception_cleanup tomonidan o'chiriladi.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Bu ... hayratlanarli tuyulishi mumkin va bu haqli ravishda.32-bitli MSVC-da ushbu tuzilish orasidagi ko'rsatgichlar shunchaki ko'rsatgichlardir.
    // 64-bitli MSVC-da esa tuzilmalar orasidagi ko'rsatgichlar `__ImageBase`-dan 32-bitli ofset sifatida ifodalanadi.
    //
    // Natijada, 32-bitli MSVC-da biz ushbu ko'rsatkichlarning barchasini yuqoridagi "statik" da e'lon qilishimiz mumkin.
    // 64-bitli MSVC-da biz Rust hozircha ruxsat bermaydigan statikada ko'rsatgichlarni olib tashlashni ifodalashimiz kerak edi, shuning uchun biz buni bajara olmaymiz.
    //
    // Keyingi eng yaxshi narsa, ushbu tuzilmalarni ish vaqtida to'ldirishdir (vahima "slow path" baribir).
    // Shunday qilib, biz ushbu ko'rsatkich maydonlarining barchasini 32-bitli tamsayılar sifatida qayta sharhlaymiz va keyin tegishli qiymatni saqlaymiz (atomik ravishda, panics bir vaqtda sodir bo'lishi mumkin).
    //
    // Texnik jihatdan ish vaqti bu sohalarni atomik bo'lmagan o'qishni amalga oshirishi mumkin, ammo nazariy jihatdan ular hech qachon *noto'g'ri* qiymatini o'qimaydilar, shuning uchun u yomon bo'lmasligi kerak ...
    //
    // Qanday bo'lmasin, biz statikada ko'proq operatsiyalarni ifoda etgunga qadar (va biz hech qachon qila olmasligimiz kerak), asosan, shunga o'xshash narsa qilishimiz kerak.
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Bu erda NULL foydali yuk, biz __rust_try ning (...) ushlashidan kelib chiqqanimizni anglatadi.
    // Bu Rust bo'lmagan xorijiy istisno ushlanganda sodir bo'ladi.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Bu kompilyator tomonidan mavjud bo'lishi kerak (masalan, bu lang elementi), lekin uni hech qachon kompilyator chaqirmaydi, chunki __C_specific_handler yoki_except_handler3 har doim ishlatiladigan shaxsiy funktsiya.
//
// Shuning uchun bu faqat abort qiladigan stub.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}