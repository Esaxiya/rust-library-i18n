//! Miri uchun panics-ni echish.
use alloc::boxed::Box;
use core::any::Any;

// Miri dvigateli biz uchun bo'shashish orqali tarqaladigan foydali yuk turi.
// Ko'rsatkich o'lchamida bo'lishi kerak.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri tomonidan taqdim etilgan extern funktsiyasi bo'shashishni boshlash uchun.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // `miri_start_panic`-ga o'tadigan foydali yuk, biz quyida keltirilgan `cleanup`-da aniq dalil bo'ladi.
    // Shunday qilib, biz ko'rsatgichga o'xshash narsalarni olish uchun uni faqat bir marta qutiga joylashtiramiz.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Asosiy `Box`-ni qayta tiklang.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}