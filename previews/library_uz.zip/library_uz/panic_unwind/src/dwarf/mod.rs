//! DWARF bilan kodlangan ma'lumotlar oqimlarini ajratish uchun yordamchi dasturlar.
//! <http://www.dwarfstd.org>, DWARF-4 standarti, 7-bo'lim, "Data Representation" ga qarang
//!

// Ushbu moduldan hozircha faqat x86_64-pc-windows-gnu foydalanadi, ammo biz regresslardan qochish uchun uni hamma joyda to'playmiz.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF oqimlari qadoqlangan, shuning uchun masalan, u32 4 baytli chegarada tekislanishi shart emas.
    // Bu qat'iy hizalama talablari bilan platformalarda muammolarni keltirib chiqarishi mumkin.
    // Ma'lumotlarni "packed" tizimiga o'rash orqali biz orqa tomonga "misalignment-safe" kodini ishlab chiqarishni aytamiz.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 va SLEB128 kodlashlari 7.6, "Variable Length Data" bo'limida aniqlangan.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}