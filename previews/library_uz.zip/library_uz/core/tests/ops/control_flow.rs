use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Bu barqaror sirt maydoni emas, lekin LLVM hozirda har doim ham bu imkoniyatdan foydalana olmasa ham, ular orasida `?`-ni arzonlashtirishga yordam beradi.
    //
    // (Afsuski, Natija va Variant mos kelmaydi, shuning uchun ControlFlow ikkalasiga ham mos kelmaydi.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}