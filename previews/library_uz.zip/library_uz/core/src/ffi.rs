#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! (FFI) chet el funktsiyalari interfeysi bilan bog'liq dasturlar.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// [pointer] sifatida ishlatilganda C ning `void` turiga teng.
///
/// Aslida `*const c_void` C ning `const void*` ga, `*mut c_void` esa C ning `void*` ga teng.
/// Ya'ni, bu C ning `void` qaytish turi bilan bir xil emas *, bu Rust ning `()` turi.
///
/// FFI-da shaffof bo'lmagan turlarga ko'rsatgichlarni modellashtirish uchun `extern type` stabillashguncha bo'sh baytlar qatori atrofida newtype o'ramidan foydalanish tavsiya etiladi.
///
/// Tafsilotlar uchun [Nomicon]-ga qarang.
///
/// Agar eski Rust kompilyatorini 1.1.0 gacha qo'llab-quvvatlamoqchi bo'lsa, `std::os::raw::c_void` dan foydalanish mumkin.
/// Rust 1.30.0 dan keyin u ushbu ta'rif bilan qayta eksport qilindi.
/// Qo'shimcha ma'lumot uchun [RFC 2521]-ni o'qing.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, LLVM bo'sh ko'rsatgich turini tanishi va malloc() kabi kengaytma funktsiyalari bo'yicha biz uni LLVM bit kodida i8 * sifatida ifodalashimiz kerak.
// Bu erda ishlatiladigan enum buni ta'minlaydi va "raw" turini noto'g'ri ishlatilishini oldini oladi, faqat xususiy variantlarga ega.
// Bizga ikkita variant kerak, chunki kompilyator aks holda repr atributidan shikoyat qiladi va biz kamida bitta variantga muhtojmiz, chunki aks holda enum yashamaydi va hech bo'lmaganda bunday ko'rsatgichlarni ajratish UB bo'ladi.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list` ning asosiy qo'llanilishi.
// Ism hozircha `VaListImpl`-dan foydalangan holda WIP.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` dan o'zgarmas, shuning uchun har bir `VaListImpl<'f>` ob'ekti u belgilangan funktsiya mintaqasiga bog'langan
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ABI-ni `va_list`-ni amalga oshirish.
/// Qo'shimcha ma'lumot uchun [AArch64 Procedure Call Standard]-ga qarang.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ABI-ni `va_list`-ni amalga oshirish.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ABI-ni `va_list`-ni amalga oshirish.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` uchun paket
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl`-ni C ning `va_list`-ga mos keladigan ikkilik mos keladigan `VaList`-ga o'zgartiring.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl`-ni C ning `va_list`-ga mos keladigan ikkilik mos keladigan `VaList`-ga o'zgartiring.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait umumiy interfeyslarda ishlatilishi kerak, ammo trait ning o'zi ushbu moduldan tashqarida foydalanishga yo'l qo'yilmasligi kerak.
// Foydalanuvchilarga trait-ni yangi turga tatbiq etishlariga ruxsat berish (shu bilan ichki va_arg-ning yangi turida ishlatilishiga imkon berish) aniqlanmagan xatti-harakatlarni keltirib chiqarishi mumkin.
//
// FIXME(dlrobertson): VaArgSafe trait-ni umumiy interfeysda ishlatish, shuningdek uni boshqa joylarda ishlatib bo'lmaydiganligini ta'minlash uchun trait xususiy modulda ochiq bo'lishi kerak.
// RFC 2145 tatbiq etilgandan so'ng uni yaxshilashga e'tibor bering.
//
//
//
//
mod sealed_trait {
    /// 0Trait, bu [super::VaListImpl::arg] bilan ruxsat etilgan turlardan foydalanishga imkon beradi.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Keyingi argga o'tish.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `va_arg` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { va_arg(self) }
    }

    /// `va_list`-ni hozirgi joyda nusxa ko'chiradi.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `va_end` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // XAVFSIZLIK: biz `MaybeUninit`-ga yozamiz, shuning uchun u ishga tushiriladi va `assume_init` qonuniy hisoblanadi
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: bu `va_end`-ga qo'ng'iroq qilishi kerak, ammo buning toza usuli yo'q
        // `drop` har doim qo'ng'iroq qiluvchiga kirishini kafolatlaydi, shuning uchun `va_end` to'g'ridan-to'g'ri mos keladigan `va_copy` bilan bir xil funktsiyadan chaqiriladi.
        // `man va_end` C buni talab qiladi va LLVM asosan C semantikasiga amal qiladi, shuning uchun biz `va_end` har doim `va_copy` bilan bir xil funktsiyadan chaqirilishini ta'minlashimiz kerak.
        //
        // Qo'shimcha ma'lumot uchun, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Bu hozircha ishlaydi, chunki `va_end` barcha LLVM maqsadlarida no-op hisoblanadi.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` yoki `va_copy` bilan ishga tushirilgandan so'ng `ap` argumentlarini yo'q qiling.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// `src` arglist ro'yxatining joriy joylashuvini `dst` arglistiga ko'chiradi.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `T` turidagi argumentni `va_list` `ap` dan yuklaydi va argumentni `ap` ga oshiradi.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}