#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future asenkron hisoblashni anglatadi.
///
/// future-bu hisoblashni hali tugatmagan bo'lishi mumkin bo'lgan qiymat.
/// Ushbu turdagi "asynchronous value" ipning foydali ishlashini davom ettirishga imkon beradi, chunki u qiymat paydo bo'lishini kutadi.
///
///
/// # `poll` usuli
///
/// future, `poll` ning asosiy usuli, future-ni yakuniy qiymatga aylantirish uchun *urinishlar*.
/// Agar qiymat tayyor bo'lmasa, bu usul blokirovka qilmaydi.
/// Buning o'rniga, hozirgi vazifani yana "so'rovnoma" orqali ilgarilash mumkin bo'lganda uyg'otish rejalashtirilgan.
/// `poll` usuliga o'tgan `context` hozirgi vazifani uyg'otish uchun dastak bo'lgan [`Waker`] ni taqdim etishi mumkin.
///
/// future-dan foydalanishda siz odatda `poll`-ga to'g'ridan-to'g'ri qo'ng'iroq qilmaysiz, aksincha uning qiymati `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Yakunlashda ishlab chiqarilgan qiymat turi.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// future-ni yakuniy qiymatga qo'yishga urinib ko'ring, agar qiymat hali mavjud bo'lmasa, uyg'onish uchun joriy vazifani ro'yxatdan o'tkazing.
    ///
    /// # Qaytish qiymati
    ///
    /// Ushbu funktsiya quyidagicha qaytadi:
    ///
    /// - [`Poll::Pending`] agar future hali tayyor bo'lmasa
    /// - [`Poll::Ready(val)`] muvaffaqiyatli bajarilgan bo'lsa, ushbu future ning `val` natijasi bilan.
    ///
    /// future tugagandan so'ng, mijozlar uni qayta `poll` qilmasligi kerak.
    ///
    /// future hali tayyor bo'lmaganda, `poll` `Poll::Pending`-ni qaytaradi va [`Waker`]-ning hozirgi [`Context`]-dan nusxalangan klonini saqlaydi.
    /// Keyin future rivojlanishi mumkin bo'lganidan keyin ushbu [`Waker`] uyg'onadi.
    /// Masalan, rozetkaning o'qilishini kutayotgan future, [`Waker`]-da `.clone()`-ga qo'ng'iroq qiladi va uni saqlaydi.
    /// Soketning o'qilishi mumkinligini ko'rsatadigan boshqa joyga signal kelganda, [`Waker::wake`] chaqiriladi va future rozetkasi uyg'onadi.
    /// Vazifa uyg'otilgandan so'ng, u future-ni qayta `poll`-ga o'tkazishga urinishi kerak, bu yakuniy qiymatni keltirib chiqarishi mumkin yoki bo'lmasligi mumkin.
    ///
    /// Shuni esda tutingki, `poll`-ga bir nechta qo'ng'iroqlarda faqat [`Context`]-dan so'nggi qo'ng'iroqqa uzatilgan [`Waker`] uyg'onishi kerak.
    ///
    /// # Ish vaqti xususiyatlari
    ///
    /// Faqat Futures *inert*;taraqqiyotga erishish uchun ularni *faol* so'roq qilish kerak, ya'ni har safar joriy vazifa uyg'onganida, u hali ham qiziqish bildirayotgan futures ni faol ravishda qayta "poll" ga qaytarishi kerak.
    ///
    /// `poll` funktsiyasi qattiq tsiklda qayta-qayta chaqirilmaydi-buning o'rniga uni faqat future rivojlanishga tayyorligini ko'rsatganda chaqirish kerak (`wake()`) ni chaqirish orqali).
    /// Agar siz Unix-dagi `poll(2)` yoki `select(2)` tizimlari bilan tanish bo'lsangiz, shuni ta'kidlash kerakki, futures odatda "all wakeups must poll all events" bilan bir xil muammolarga duch kelmaydi;ular ko'proq `epoll(4)` ga o'xshaydi.
    ///
    /// `poll` dasturini tezda qaytarishga intilish kerak va blokirovka qilmaslik kerak.Tezda qaytish keraksiz ravishda iplarni yoki hodisalar ko'chalarini to'sib qo'yishning oldini oladi.
    /// Agar `poll`-ga qo'ng'iroq biroz vaqt o'tishi mumkinligi oldindan ma'lum bo'lsa, ishni `poll`-ning tezda qaytishini ta'minlash uchun iplar havzasiga (yoki shunga o'xshash narsalarga) yuklash kerak.
    ///
    /// # Panics
    ///
    /// future tugagandan so'ng (`Ready` dan `poll` qaytarildi), uning yana `poll` usulini chaqirish panic, abadiy bloklanishi yoki boshqa muammolarni keltirib chiqarishi mumkin;`Future` trait bunday qo'ng'iroq ta'siriga hech qanday talab qo'ymaydi.
    /// Biroq, `poll` usuli `unsafe` bilan belgilanmaganligi sababli, Rust odatdagi qoidalari amal qiladi: future holatidan qat'i nazar, qo'ng'iroqlar hech qachon aniqlanmagan xatti-harakatlarga (xotira buzilishi, `unsafe` funktsiyalaridan noto'g'ri foydalanish yoki shunga o'xshashlar) sabab bo'lmasligi kerak.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}