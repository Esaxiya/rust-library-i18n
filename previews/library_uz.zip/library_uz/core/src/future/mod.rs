#![stable(feature = "futures_api", since = "1.36.0")]

//! Asenkron qiymatlar.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Ushbu turga kerak, chunki:
///
/// a) Jeneratörler `for<'a, 'b> Generator<&'a mut Context<'b>>`-ni amalga oshira olmaydi, shuning uchun biz xom ko'rsatgichdan o'tishimiz kerak (<https://github.com/rust-lang/rust/issues/68923>-ga qarang).
///
/// b) Xom ko'rsatgichlar va `NonNull` `Send` yoki `Sync` emas, shuning uchun har bir future non-Send/Sync ham ishlaydi va biz buni xohlamaymiz.
///
/// Bundan tashqari, `.await` ning HIR tushirilishini osonlashtiradi.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Jeneratörni future-ga o'rab qo'ying.
///
/// Ushbu funktsiya ostidagi `GenFuture`-ni qaytaradi, lekin uni yaxshiroq xato xabarlari berish uchun `impl Trait`-da yashiradi (`GenFuture<[closure.....]>` o'rniga `impl Future`).
///
// `const async fn`-ni tiklaganimizdan keyin qo'shimcha xatolarga yo'l qo'ymaslik uchun bu `const`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Asosiy generatorda o'z-o'zidan ma'lumot olish uchun qarzlarni yaratish uchun biz async/await futures ning ko'chmas ekanligiga ishonamiz.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // XAVFSIZLIK: !Unpin + !Drop ekanligimiz uchun xavfsiz, va bu shunchaki maydon proektsiyasi.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // `&mut Context` ni `NonNull` xom ko'rsatgichiga aylantirib, generatorni davom ettiring.
            // `.await` tushirilishi xavfsiz tarzda `&mut Context`-ga qaytadi.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `cx.0` haqiqiy ko'rsatgich ekanligiga kafolat berishi kerak
    // o'zgaruvchan ma'lumot uchun barcha talablarni bajaradigan.
    unsafe { &mut *cx.0.as_ptr().cast() }
}