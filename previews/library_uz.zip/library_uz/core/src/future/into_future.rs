use crate::future::Future;

/// `Future`-ga o'tish.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future tugagandan so'ng ishlab chiqaradigan mahsulot.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Buni future ning qaysi turiga aylantirmoqdamiz?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Qiymatdan future hosil qiladi.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}