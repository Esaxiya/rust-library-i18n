//! Ibtidoiy traits va turlarning asosiy xususiyatlarini ifodalovchi turlari.
//!
//! Rust turlari ichki xususiyatlariga ko'ra turli xil foydali usullar bilan tasniflanishi mumkin.
//! Ushbu tasniflar traits sifatida ifodalanadi.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Ip chegaralari orqali o'tkazilishi mumkin bo'lgan turlari.
///
/// Ushbu trait avtomatik ravishda kompilyator mosligini aniqlaganda amalga oshiriladi.
///
/// "Yubormaslik" turiga misol qilib [`rc::Rc`][`Rc`] mos yozuvlarni hisoblash ko'rsatkichi keltirilgan.
/// Agar ikkita ip bir xil mos yozuvlar hisoblangan qiymatga ishora qiluvchi [`Rc`] ni klonlashga harakat qilsa, ular bir vaqtning o'zida mos yozuvlar sonini yangilashga urinishlari mumkin, bu [undefined behavior][ub], chunki [`Rc`] atom operatsiyalaridan foydalanmaydi.
///
/// Uning amakivachchasi [`sync::Arc`][arc] atom operatsiyalaridan foydalanadi (qo'shimcha xarajatlarga olib keladi) va shuning uchun `Send`.
///
/// Qo'shimcha ma'lumot uchun [the Nomicon](../../nomicon/send-and-sync.html)-ga qarang.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Kompilyatsiya vaqtida ma'lum bo'lgan doimiy o'lchamdagi turlari.
///
/// Barcha turdagi parametrlarning `Sized` chegarasi mavjud.Agar mos kelmasa, ushbu chegarani olib tashlash uchun maxsus `?Sized` sintaksisidan foydalanish mumkin.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//xato: [i32] uchun o'lchov amalga oshirilmagan
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Istisnolardan biri trait ning yashirin `Self` turi.
/// trait aniq bo'lmagan `Sized` bog'lanishiga ega emas, chunki bu [trait ob'ekti] lar bilan mos kelmaydi, bu erda trait barcha mumkin bo'lgan bajaruvchilar bilan ishlashi kerak va shuning uchun har qanday hajmda bo'lishi mumkin.
///
///
/// Garchi Rust sizga `Sized` ni trait bilan bog'lashga imkon bersa ham, undan keyin trait ob'ektini yaratish uchun foydalana olmaysiz:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y: &dyn Bar= &Impl;//xato: trait `Bar` ob'ektga aylantirilmaydi
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // masalan, `[T]: !Default`-ni baholashni talab qiladigan Default uchun
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Dinamik o'lchamdagi turga "unsized" bo'lishi mumkin bo'lgan turlari.
///
/// Masalan, o'lchamdagi `[i8; 2]` massivi `Unsize<[i8]>` va `Unsize<dyn fmt::Debug>` ni amalga oshiradi.
///
/// `Unsize`-ning barcha ilovalari kompilyator tomonidan avtomatik ravishda ta'minlanadi.
///
/// `Unsize` uchun amalga oshiriladi:
///
/// - `[T; N]` bu `Unsize<[T]>`
/// - `T` `T: Trait` bo'lganda `Unsize<dyn Trait>` bo'ladi
/// - `Foo<..., T, ...>` agar `Unsize<Foo<..., U, ...>>` bo'lsa, agar:
///   - `T: Unsize<U>`
///   - Foo-bu struktura
///   - Faqat `Foo` ning so'nggi sohasi `T` ni o'z ichiga olgan turga ega
///   - `T` boshqa maydonlarning turiga kirmaydi
///   - `Bar<T>: Unsize<Bar<U>>`, agar `Foo` ning so'nggi maydoni `Bar<T>` turiga ega bo'lsa
///
/// `Unsize` [`ops::CoerceUnsized`] bilan birga [`Rc`] kabi "user-defined" konteynerlarini dinamik o'lchamdagi turlarini o'z ichiga olishi uchun ishlatiladi.
/// Qo'shimcha ma'lumot uchun [DST coercion RFC][RFC982] va [the nomicon entry on coercion][nomicon-coerce]-ga qarang.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Naqshli o'yinlarda ishlatiladigan doimiylar uchun trait talab qilinadi.
///
/// `PartialEq` ni chiqaradigan har qanday turdagi avtomatik ravishda ushbu trait amalga oshiriladi,*uning tur parametrlari `Eq` ni amalga oshiradimi-yo'qligidan qat'iy nazar*.
///
/// Agar `const` elementida ushbu trait-ni amalga oshirmaydigan biron bir tur mavjud bo'lsa, u holda (1.) turi `PartialEq`-ni qo'llamaydi (ya'ni doimiy kod taqqoslash usulini ta'minlamaydi, ya'ni kod ishlab chiqarilishi mumkin) yoki (2.) o'zi bajaradi * *`PartialEq` versiyasi (biz strukturaviy tenglikni taqqoslashga mos kelmaydi).
///
///
/// Yuqoridagi ikkita stsenariyning har ikkalasida ham biz ushbu doimiylikni naqshli o'yinda ishlatishni rad etamiz.
///
/// Atributlarga asoslangan dizayndan ushbu trait ga o'tishni rag'batlantirgan [structural match RFC][RFC1445] va [issue 63438]-ga qarang.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Naqshli o'yinlarda ishlatiladigan doimiylar uchun trait talab qilinadi.
///
/// `Eq` ni chiqaradigan har qanday turdagi avtomatik ravishda ushbu trait amalga oshiriladi,*uning parametrlari `Eq` ni amalga oshiradimi-yo'qligidan qat'iy nazar*.
///
/// Bu bizning turdagi tizimimizdagi cheklovlarni hal qilish uchun buzilgan.
///
/// # Background
///
/// Biz naqshli o'yinlarda ishlatiladigan konstlarning `#[derive(PartialEq, Eq)]` atributiga ega bo'lishini talab qilmoqchimiz.
///
/// Keyinchalik ideal dunyoda biz ushbu talabni `StructuralPartialEq` trait *va*`Eq` trait ikkalasini ham bajarishini tekshirish orqali tekshirishimiz mumkin.
/// Ammo, siz *bajaradigan*`derive(PartialEq, Eq)` ADT-larga ega bo'lishingiz mumkin va biz kompilyatorni qabul qilishini istaymiz, ammo doimiyning turi `Eq`-ni amalga oshira olmaydi.
///
/// Masalan, shunga o'xshash ish:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Yuqoridagi koddagi muammo shundaki, `Wrap<fn(&())>` `PartialEq` ni ham, `Eq` ni ham amalga oshirmaydi, chunki "uchun" uchun fn(&'a _)` does not implement those traits.)
///
/// Shuning uchun biz `StructuralPartialEq` va shunchaki `Eq` uchun sodda tekshiruvga ishonishimiz mumkin emas.
///
/// Buning atrofida ishlash uchun biz ikkala (`#[derive(PartialEq)]` va `#[derive(Eq)]`) lotinlari tomonidan AOK qilingan ikkita alohida traits dan foydalanamiz va ularning ikkalasi ham tarkibiy-o'yinlarni tekshirish doirasida mavjudligini tekshiramiz.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Bitlarni nusxalash orqali ularning qiymatlarini takrorlash mumkin bo'lgan turlar.
///
/// Odatiy bo'lib, o'zgaruvchan birikmalar "harakat semantikasiga" ega.Boshqa so'zlar bilan aytganda:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y`-ga o'tdi va shuning uchun uni ishlatish mumkin emas
///
/// // println! ("{: ?}", x);//xato: ko'chirilgan qiymatdan foydalanish
/// ```
///
/// Ammo, agar biron bir turi `Copy` ni amalga oshirsa, uning o'rniga "nusxa ko'chirish semantikasi" mavjud:
///
/// ```
/// // Biz `Copy` dasturini olishimiz mumkin.
/// // `Clone` ham talab qilinadi, chunki bu `Copy` supertraitidir.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` bu `x` nusxasi
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Shuni ta'kidlash kerakki, ushbu ikkita misolda faqat bitta farq-bu sizga topshiriqdan keyin `x`-ga kirishga ruxsat beriladimi-yo'qmi.
/// Kaput ostida ham nusxa ko'chirish, ham ko'chirish bitlarga xotirada ko'chirilishiga olib kelishi mumkin, garchi bu ba'zan optimallashtirilsa.
///
/// ## `Copy` ni qanday amalga oshirishim mumkin?
///
/// Sizning turingizda `Copy` ni amalga oshirishning ikkita usuli mavjud.Eng sodda narsa `derive` dan foydalanish:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Siz shuningdek `Copy` va `Clone`-ni qo'lda amalga oshirishingiz mumkin:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Ikkalasi o'rtasida ozgina farq bor: `derive` strategiyasi, shuningdek, har doim ham istalmagan turdagi parametrlarga bog'liq bo'lgan `Copy` ni joylashtiradi.
///
/// ## `Copy` va `Clone` o'rtasidagi farq nima?
///
/// Nusxalari bevosita, masalan, `y = x` topshirig'ining bir qismi sifatida sodir bo'ladi.`Copy` xatti-harakatlari haddan tashqari yuklanmaydi;bu har doim oddiy dono nusxa.
///
/// Klonlash-bu aniq harakat, `x.clone()`.[`Clone`]-ni amalga oshirish qiymatlarni xavfsiz ravishda ko'paytirish uchun zarur bo'lgan har qanday turdagi harakatlarni ta'minlay oladi.
/// Masalan, [`String`] uchun [`Clone`] ni amalga oshirish, uyumga yo'naltirilgan simli buferni nusxalashi kerak.
/// [`String`] qiymatlarining oddiy bitli nusxasi shunchaki ko'rsatgichni nusxalashi mumkin, bu esa chiziq bo'ylab ikki baravar bo'shashishga olib keladi.
/// Shu sababli [`String`] [`Clone`], lekin `Copy` emas.
///
/// [`Clone`] `Copy` supertraitidir, shuning uchun `Copy` bo'lgan hamma narsa [`Clone`]-ni ham bajarishi kerak.
/// Agar tur `Copy` bo'lsa, uning [`Clone`] bajarilishi faqat `*self` ni qaytarishi kerak (yuqoridagi misolga qarang).
///
/// ## Mening turim qachon `Copy` bo'lishi mumkin?
///
/// Agar uning barcha komponentlari `Copy` ni qo'llasa, `Copy` ni amalga oshirishi mumkin.Masalan, bu struktura `Copy` bo'lishi mumkin:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Struktura `Copy` bo'lishi mumkin va [`i32`] `Copy`, shuning uchun `Point` `Copy` bo'lish huquqiga ega.
/// Aksincha, o'ylab ko'ring
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` strukturasi `Copy` ni amalga oshira olmaydi, chunki [`Vec<T>`] `Copy` emas.Agar biz `Copy` dasturini olishga urinib ko'rsak, xato bo'ladi:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Umumiy havolalar (`&T`) ham `Copy` hisoblanadi, shuning uchun hatto `T` turlarining *bo'lmagan*`Copy` ma'lumotlariga ega bo'lsa ham, bunday turdagi `Copy` bo'lishi mumkin.
/// `Copy`-ni amalga oshirishi mumkin bo'lgan quyidagi tuzilmani ko'rib chiqing, chunki u faqat yuqoridan bizning "Copy" bo'lmagan `PointList` turiga *umumiy ma'lumot* beradi:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Qachon *mening turim `Copy` bo'lishi mumkin emas*?
///
/// Ba'zi turlarini xavfsiz nusxa ko'chirib bo'lmaydi.Masalan, `&mut T`-ni nusxalash, o'zgaruvchan o'zgaruvchan ma'lumotnomani yaratishi mumkin.
/// [`String`] nusxasi ['String`] ning buferini boshqarish uchun mas'uliyatni takrorlashi mumkin, bu esa ikki baravar bepul bo'lishiga olib keladi.
///
/// Ikkinchi holatni umumlashtirish, [`Drop`]-ni amalga oshiradigan har qanday turdagi `Copy` bo'lishi mumkin emas, chunki u o'z [`size_of::<T>`] baytlaridan tashqari ba'zi manbalarni boshqaradi.
///
/// Agar siz `Copy`-ni "Copy" bo'lmagan ma'lumotlarni o'z ichiga olgan struct yoki enum-da amalga oshirishga harakat qilsangiz, [E0204] xatosi paydo bo'ladi.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Mening turim qachon `Copy` bo'lishi kerak *?
///
/// Umuman aytganda, agar sizning _can_ turingiz `Copy` ni amalga oshirsa, kerak.
/// Shuni yodda tutingki, `Copy` ni amalga oshirish sizning turdagi ochiq API qismidir.
/// Agar tur future-da "Copy" bo'lmasligi mumkin bo'lsa, API o'zgarishini buzmaslik uchun hozirda `Copy` dasturini tashlab qo'yish oqilona bo'lishi mumkin.
///
/// ## Qo'shimcha dasturchilar
///
/// [implementors listed below][impls]-ga qo'shimcha ravishda quyidagi turlari ham `Copy`-ni amalga oshiradi:
///
/// * Funktsiya elementlari turlari (ya'ni har bir funktsiya uchun aniqlangan turlar)
/// * Funktsiya ko'rsatkichlari turlari (masalan, `fn() -> i32`)
/// * Array turlari, har qanday o'lcham uchun, agar element turi ham `Copy` ni qo'llasa (masalan, `[i32; 123456]`)
/// * Tuple turlari, agar har bir komponent `Copy` ni amalga oshirsa (masalan, `()`, `(i32, bool)`)
/// * Yopish turlari, agar ular atrof-muhitdan hech qanday ahamiyatga ega bo'lmasa yoki olingan barcha qiymatlar `Copy`-ni o'zlashtirsa.
///   Shuni esda tutingki, umumiy ma'lumot bilan olingan o'zgaruvchilar har doim `Copy`-ni qo'llaydi (hatto referent bo'lmasa ham), o'zgaruvchan mos yozuvlar bilan olingan o'zgaruvchilar hech qachon `Copy`-ni qo'llamaydi.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Bu umr bo'yi qoniqmaganligi sababli `Copy` ni amalga oshirmaydigan turini nusxalashga imkon beradi (faqat `A<'static>: Copy` va `A<'_>: Clone` bo'lganda `A<'_>` nusxasi).
// Bizda bu atribut hozircha mavjud, chunki `Copy`-da standart kutubxonada mavjud bo'lgan bir nechta ixtisosliklar mavjud va hozirda ushbu xatti-harakatni xavfsiz bajarishning imkoni yo'q.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` implini yaratadigan so'lni oling.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Mavzular orasida havolalarni almashish xavfsiz bo'lgan turlari.
///
/// Ushbu trait avtomatik ravishda kompilyator mosligini aniqlaganda amalga oshiriladi.
///
/// Aniq ta'rifi: `T` turi [`Sync`], agar `&T` [`Send`] bo'lsa.
/// Boshqacha qilib aytganda, agar `&T` havolalarini iplar orasidan o'tkazishda [undefined behavior][ub] (ma'lumotlar poygalarini o'z ichiga olgan) imkoniyati bo'lmasa.
///
/// Kutilganidek, [`u8`] va [`f64`] kabi ibtidoiy turlar hammasi [`Sync`], shuningdek, ularni o'z ichiga olgan oddiy agregatlar turlari, masalan, strelka va enumlar.
/// Asosiy [`Sync`] turlarining ko'proq misollari orasida `&T` kabi "immutable" turlari va oddiy meros qilib olinadigan o'zgaruvchanligi, masalan, [`Box<T>`][box], [`Vec<T>`][vec] va boshqa ko'plab to'plam turlari mavjud.
///
/// (Konteynerlari ["Sinxronizatsiya"] bo'lishi uchun umumiy parametrlar [`Sync`] bo'lishi kerak.)
///
/// Ta'rifning hayratlanarli natijasi shundaki, `&mut T` `Sync` (agar `T` `Sync` bo'lsa), garchi bu sinxronizatsiya qilinmagan mutatsiyani ta'minlashi mumkin bo'lsa.
/// Hiyla shundaki, umumiy ma'lumotnomaning (ya'ni `& &mut T`) orqasidagi o'zgaruvchan mos yozuvlar xuddi `& &T` kabi o'qish uchun aylanadi.
/// Shuning uchun ma'lumotlar poygasi xavfi yo'q.
///
/// `Sync` bo'lmagan turlar, bu [`Cell`][cell] va [`RefCell`][refcell] kabi xavfsiz bo'lmagan shaklda "interior mutability" bo'lganlardir.
/// Ushbu turlar o'zgarmas, umumiy ma'lumot orqali ham ularning tarkibini mutatsiyalashga imkon beradi.
/// Masalan, [`Cell<T>`][cell]-da `set` usuli `&self`-ni oladi, shuning uchun u faqat [`&Cell<T>`][cell]-ga umumiy ma'lumotni talab qiladi.
/// Usul hech qanday sinxronlashni amalga oshirmaydi, shuning uchun [`Cell`][cell] `Sync` bo'lishi mumkin emas.
///
/// "Sync" bo'lmagan turdagi yana bir misol-bu [`Rc`][rc] mos yozuvlar hisoblash ko'rsatkichi.
/// Har qanday mos yozuvlar [`&Rc<T>`][rc]-ni hisobga olgan holda, siz yangi [`Rc<T>`][rc]-ni klonlashingiz mumkin, mos yozuvlar sonini atom bo'lmagan tarzda o'zgartirishingiz mumkin.
///
/// Ichki o'zgaruvchan ichki o'zgaruvchanlikni talab qiladigan holatlarda, Rust [atomic data types], shuningdek [`sync::Mutex`][mutex] va [`sync::RwLock`][rwlock] orqali aniq qulflashni ta'minlaydi.
/// Ushbu turlar har qanday mutatsiya ma'lumotlar poygalarini keltirib chiqara olmasligini ta'minlaydi, shuning uchun turlari `Sync`.
/// Xuddi shu tarzda, [`sync::Arc`][arc] simsiz [`Rc`][rc] analogini taqdim etadi.
///
/// Ichki o'zgaruvchanlikka ega bo'lgan har qanday turdagi X001 o'ramini value(s) atrofida ishlatishi kerak, u umumiy ma'lumotnoma orqali mutatsiyaga uchraydi.
/// Buni amalga oshirmaslik [undefined behavior][ub].
/// Masalan, [`transmute`][transmute]-ing `&T` dan `&mut T` gacha emas.
///
/// `Sync` haqida ko'proq ma'lumot olish uchun [the Nomicon][nomicon-send-and-sync]-ga qarang.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): bir marta `rustc_on_unimplemented`-ga notalarni beta-versiyada qo'shishni qo'llab-quvvatlasa va yopilish talab zanjirining biron bir joyida ekanligini tekshirish uchun kengaytirilsa, uni (#48534) sifatida kengaytiring:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nolinchi o'lchamdagi "act like"-ga tegishli bo'lgan narsalarni belgilash uchun ishlatiladigan `T`.
///
/// Sizning turingizga `PhantomData<T>` maydonini qo'shish kompilyatorga sizning turingiz `T` turidagi qiymatni saqlaganidek harakat qilishini aytadi, garchi u aslida bo'lmasa ham.
/// Ushbu ma'lumotlar ma'lum xavfsizlik xususiyatlarini hisoblashda ishlatiladi.
///
/// `PhantomData<T>`-dan qanday foydalanish haqida batafsilroq ma'lumot olish uchun [the Nomicon](../../nomicon/phantom-data.html)-ga qarang.
///
/// # Dahshatli eslatma 👻👻👻
///
/// Garchi ularning ikkalasi ham qo'rqinchli ismlarga ega bo'lsa-da, `PhantomData` va "xayolot turlari" bir-biriga bog'liq, ammo bir xil emas.Fantom turi parametri shunchaki hech qachon ishlatilmaydigan turdagi parametrdir.
/// Rust-da, bu ko'pincha kompilyatorning shikoyat qilishiga olib keladi va echim X001 yordamida "dummy" foydalanishni qo'shishdir.
///
/// # Examples
///
/// ## Foydalanilmagan umr bo'yi parametrlari
///
/// Ehtimol, `PhantomData` uchun eng keng tarqalgan foydalanish holati, odatda ba'zi xavfli kodlarning bir qismi sifatida foydalanilmaydigan umr bo'yi parametrga ega bo'lgan tuzilishdir.
/// Masalan, bu erda biron bir qatorga ishora qiladigan `*const T` tipidagi ikkita ko'rsatgichga ega bo'lgan `Slice` strukturasi keltirilgan:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Niyat shundaki, asosiy ma'lumotlar faqat `'a` umri uchun amal qiladi, shuning uchun `Slice` `'a` dan oshmasligi kerak.
/// Biroq, bu niyat kodda ifodalanmagan, chunki `'a` umr bo'yi ishlatilish holatlari mavjud emas va shuning uchun u qaysi ma'lumotlarga tegishli ekanligi aniq emas.
/// Biz buni tuzuvchiga *`Slice` tuzilmasi `&'a T` ma'lumotnomasini o'z ichiga olgandek* bajarishini aytish orqali tuzatishimiz mumkin:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Bu, o'z navbatida, `T: 'a` izohini talab qiladi, ya'ni `T`-dagi har qanday havolalar `'a` umri davomida amal qiladi.
///
/// `Slice`-ni ishga tushirishda siz `phantom` maydoni uchun `PhantomData` qiymatini berasiz:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Foydalanilmaydigan turdagi parametrlar
///
/// Ba'zan sizda foydalanilmaydigan turdagi parametrlar mavjud bo'lib, ular strukturaning qaysi "tied" ma'lumotlariga tegishli ekanligini ko'rsatadi, garchi bu ma'lumotlar strukturaning o'zida topilmasa ham.
/// Bu [FFI] bilan yuzaga keladigan misol.
/// Chet el interfeysi har xil turdagi Rust qiymatlariga murojaat qilish uchun `*mut ()` tipidagi tutqichlardan foydalanadi.
/// Biz tutqichni o'raydigan `ExternalResource` structdagi fantom turi parametri yordamida Rust turini kuzatamiz.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Mulk huquqi va tushishni tekshirish
///
/// `PhantomData<T>` turidagi maydonni qo'shsangiz, sizning turingiz `T` tipidagi ma'lumotlarga egalik qiladi.Bu o'z navbatida sizning turingiz tushirilganda, u `T` turidagi bir yoki bir nechta nusxalarni tushirishi mumkinligini anglatadi.
/// Bu Rust kompilyatorining [drop check] tahliliga ta'sir qiladi.
///
/// Agar sizning tizimingiz aslida `T` tipidagi ma'lumotlarga *egalik qilmasa, egalik huquqini ko'rsatmaslik uchun, masalan, `PhantomData<&'a T>` (ideally) yoki `PhantomData<* const T>` (agar umr bo'yi tegishli bo'lmasa) kabi mos yozuvlar turidan foydalanish yaxshiroqdir.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Enum diskriminantlari turini ko'rsatish uchun ishlatiladigan kompilyator-ichki trait.
///
/// Ushbu trait har bir turi uchun avtomatik ravishda amalga oshiriladi va [`mem::Discriminant`] ga hech qanday kafolat bermaydi.
/// `DiscriminantKind::Discriminant` va `mem::Discriminant` o'rtasida transmute qilish **aniqlanmagan xatti-harakatlar**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// `mem::Discriminant` tomonidan talab qilingan trait bounds ni qondirishi kerak bo'lgan diskriminant turi.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Kompilyator-ichki trait turga biron bir `UnsafeCell` o'z ichiga olganligini aniqlash uchun ishlatiladi, lekin bilvosita emas.
///
/// Bu, masalan, ushbu turdagi `static` faqat o'qiladigan statik xotiraga yoki yoziladigan statik xotiraga joylashtirilishiga ta'sir qiladi.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Pimlanganidan keyin xavfsiz ko'chirilishi mumkin bo'lgan turlari.
///
/// Rust-ning o'zi ko'chmas turlar haqida tushunchaga ega emas va harakatlarni (masalan, topshiriq yoki [`mem::replace`] orqali) har doim xavfsiz deb hisoblaydi.
///
/// [`Pin`][Pin] turi uning o'rniga tip tizimida harakatlanishni oldini olish uchun ishlatiladi.[`Pin<P<T>>`][Pin] plyonkasiga o'ralgan `P<T>` ko'rsatkichlarini tashqariga chiqarib bo'lmaydi.
/// PIN-kod haqida qo'shimcha ma'lumot olish uchun [`pin` module] hujjatlariga qarang.
///
/// `Unpin` trait-ni `T` uchun amalga oshirish, turni mahkamlash cheklovlarini bekor qiladi, keyinchalik `T`-ni [`Pin<P<T>>`][Pin]-dan [`mem::replace`] kabi funktsiyalar bilan ko'chirishga imkon beradi.
///
///
/// `Unpin` biriktirilmagan ma'lumotlar uchun hech qanday natija yo'q.
/// Xususan, [`mem::replace`] quvonch bilan `!Unpin` ma'lumotlarini harakatga keltiradi (u faqat `T: Unpin` paytida emas, balki har qanday `&mut T` uchun ishlaydi).
/// Biroq, siz [`mem::replace`]-ni [`Pin<P<T>>`][Pin] ichiga o'ralgan ma'lumotlarda ishlata olmaysiz, chunki buning uchun kerakli `&mut T`-ni ololmaysiz va *aynan shu* tizimning ishlashiga sabab bo'ladi.
///
/// Masalan, bu faqat `Unpin` dasturini amalga oshirishda amalga oshirilishi mumkin:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` raqamiga qo'ng'iroq qilish uchun bizga o'zgaruvchan ma'lumot kerak.
/// // Biz (implicitly)-ni chaqirgan holda (implicitly)-ga murojaat qilishimiz mumkin, ammo bu faqat `String` `Unpin`-ni amalga oshirganligi sababli mumkin.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Ushbu trait deyarli barcha turlari uchun avtomatik ravishda amalga oshiriladi.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin`-ni qo'llamaydigan marker turi.
///
/// Agar turida `PhantomPinned` bo'lsa, u sukut bo'yicha `Unpin` ni amalga oshirmaydi.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Ibtidoiy turlar uchun `Copy` dasturlari.
///
/// Rust-da tasvirlab bo'lmaydigan dasturlar `traits::SelectionContext::copy_clone_conditions()`-da `rustc_trait_selection`-da amalga oshiriladi.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Umumiy ma'lumotnomalarni nusxalash mumkin, ammo o'zgarishi mumkin bo'lgan ma'lumotnomalar *mumkin emas*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}