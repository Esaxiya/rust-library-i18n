//! Dangasa qiymatlar va statik ma'lumotlarning bir martalik boshlanishi.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Faqat bir marta yozilishi mumkin bo'lgan katak.
///
/// `RefCell`-dan farqli o'laroq, `OnceCell` faqat uning qiymati haqida umumiy `&T` ma'lumotlarini taqdim etadi.
/// `Cell`-dan farqli o'laroq, `OnceCell` unga kirish uchun qiymatni nusxalashni yoki almashtirishni talab qilmaydi.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // O'zgarmas: ko'pi bilan bir marta yoziladi.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Yangi bo'sh katak hosil qiladi.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Asosiy qiymatga havolani oladi.
    ///
    /// Agar katak bo'sh bo'lsa, `None`-ni qaytaradi.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // XAVFSIZLIK: "ichki" ning o'zgarmasligi sababli xavfsiz
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// O'zgaruvchan mos yozuvlarni asosiy qiymatga oladi.
    ///
    /// Agar katak bo'sh bo'lsa, `None`-ni qaytaradi.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // XAVFSIZLIK: Xavfsiz, chunki bizda noyob kirish imkoniyati mavjud
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Yacheykaning tarkibini `value` ga o'rnatadi.
    ///
    /// # Errors
    ///
    /// Ushbu usul, agar hujayra bo'sh bo'lsa, `Ok(())` va agar u to'la bo'lsa, `Err(value)` ni qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // XAVFSIZLIK: Xavfsiz, chunki biz o'zgarishi mumkin bo'lgan qarzlarga ega bo'lolmaymiz
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // XAVFSIZLIK: Bu biz uyani o'rnatadigan yagona joy, poyga yo'q
        // reentrancy/concurrency tufayli mumkin va biz hozirda slot `None` ekanligini tekshirdik, shuning uchun bu yozuv "ichki" ning o'zgarmasligini saqlaydi.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Hujayra tarkibini oladi, agar u bo'sh bo'lsa, uni `f` bilan boshlang.
    ///
    /// # Panics
    ///
    /// Agar `f` panics bo'lsa, panic qo'ng'iroq qiluvchiga tarqaladi va hujayra initsializatsiya qilinmaydi.
    ///
    ///
    /// `f`-dan katakchani qayta ishga tushirish xato.Buning natijasida panic paydo bo'ladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Hujayra tarkibini oladi, agar u bo'sh bo'lsa, uni `f` bilan boshlang.
    /// Agar katak bo'sh bo'lsa va `f` ishlamay qolsa, xato qaytariladi.
    ///
    /// # Panics
    ///
    /// Agar `f` panics bo'lsa, panic qo'ng'iroq qiluvchiga tarqaladi va hujayra initsializatsiya qilinmaydi.
    ///
    ///
    /// `f`-dan katakchani qayta ishga tushirish xato.Buning natijasida panic paydo bo'ladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Qayta kirishni boshlashning *ba'zi* shakllari UB ga olib kelishi mumkinligini unutmang (`reentrant_init` testiga qarang).
        // O'ylaymanki, `set/get`-ni ushlab turganda, ushbu `assert`-ni olib tashlash juda yaxshi bo'lar edi, lekin panic-ga eski qiymatdan jimgina foydalanish o'rniga yaxshiroq ko'rinadi.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// O'ralgan qiymatni qaytarib, katakchani iste'mol qiladi.
    ///
    /// Agar katak bo'sh bo'lsa, `None`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // `into_inner` qiymati bo'yicha `self` ni qabul qilganligi sababli, kompilyator statik ravishda hozirda qarz olinmaganligini tasdiqlaydi.
        // Shunday qilib, `Option<T>`-dan chiqib ketish xavfsizdir.
        self.inner.into_inner()
    }

    /// Ushbu `OnceCell` qiymatini olib, uni boshlanmagan holatga qaytaradi.
    ///
    /// H01X ishga tushirilmagan bo'lsa, ta'sir qilmaydi va `None` ni qaytaradi.
    ///
    /// O'zgaruvchan ma'lumotni talab qilish orqali xavfsizlik kafolatlanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Birinchi kirishda boshlangan qiymat.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   ishga tushirishga tayyor
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Berilgan boshlang'ich funktsiyasi bilan yangi dangasa qiymat hosil qiladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Ushbu dangasa qiymatni baholashga majbur qiladi va natijaga havolani qaytaradi.
    ///
    ///
    /// Bu `Deref` impl-ga teng, ammo aniq.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Boshlovchi funktsiya sifatida `Default` dan foydalangan holda yangi dangasa qiymatni yaratadi.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}