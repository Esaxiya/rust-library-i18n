//! ASCII satrlari va belgilaridagi operatsiyalar.
//!
//! Rust-dagi ko'pgina operatsiyalar UTF-8 satrlarida ishlaydi.
//! Biroq, ba'zida faqat ma'lum bir operatsiya uchun ASCII belgilar to'plamini ko'rib chiqish mantiqan to'g'ri keladi.
//!
//! [`escape_default`] funktsiyasi berilgan belgining qochib ketgan versiyasi baytlari bo'ylab iteratorni ta'minlaydi.
//!
//!

#![stable(feature = "core_ascii", since = "1.26.0")]

use crate::fmt;
use crate::iter::FusedIterator;
use crate::ops::Range;
use crate::str::from_utf8_unchecked;

/// Baytning qochib ketgan versiyasi ustida iterator.
///
/// Ushbu `struct` [`escape_default`] funktsiyasi tomonidan yaratilgan.
/// Qo'shimcha ma'lumot uchun uning hujjatlariga qarang.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct EscapeDefault {
    range: Range<usize>,
    data: [u8; 4],
}

/// `u8` ning qochib ketgan versiyasini ishlab chiqaruvchi iteratorni qaytaradi.
///
/// Odatiy bo'lib, turli xil tillarda, shu jumladan C++ 11 va shunga o'xshash C oilaviy tillarida qonuniy bo'lgan adabiyotlarni ishlab chiqarish tarafdorligi tanlanadi.
/// To'liq qoidalar:
///
/// * Tab `\t` sifatida qochib ketdi.
/// * Vagonni qaytarish `\r` sifatida qochib ketadi.
/// * `\n` sifatida chiziqli ozuqa qochib ketdi.
/// * Bitta kotirovka `\'` sifatida qochib ketgan.
/// * Ikki tirnoq `\"` sifatida qochib ketgan.
/// * Orqaga burilish `\\` sifatida qochib qutuldi.
/// * "Bosib chiqariladigan ASCII" `0x20` .. `0x7e` inklyuzividagi har qanday belgidan qochib bo'lmaydi.
/// * Boshqa har qanday belgilarga '\xNN' shaklidagi olti burchakli qochqinlar berilgan.
/// * Unicode qochqinlari bu funktsiya yordamida hech qachon yaratilmaydi.
///
/// # Examples
///
/// ```
/// use std::ascii;
///
/// let escaped = ascii::escape_default(b'0').next().unwrap();
/// assert_eq!(b'0', escaped);
///
/// let mut escaped = ascii::escape_default(b'\t');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b't', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\r');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'r', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\n');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'n', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\'');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\'', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'"');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'"', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\\');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\\', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\x9d');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'x', escaped.next().unwrap());
/// assert_eq!(b'9', escaped.next().unwrap());
/// assert_eq!(b'd', escaped.next().unwrap());
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn escape_default(c: u8) -> EscapeDefault {
    let (data, len) = match c {
        b'\t' => ([b'\\', b't', 0, 0], 2),
        b'\r' => ([b'\\', b'r', 0, 0], 2),
        b'\n' => ([b'\\', b'n', 0, 0], 2),
        b'\\' => ([b'\\', b'\\', 0, 0], 2),
        b'\'' => ([b'\\', b'\'', 0, 0], 2),
        b'"' => ([b'\\', b'"', 0, 0], 2),
        b'\x20'..=b'\x7e' => ([c, 0, 0, 0], 1),
        _ => ([b'\\', b'x', hexify(c >> 4), hexify(c & 0xf)], 4),
    };

    return EscapeDefault { range: 0..len, data };

    fn hexify(b: u8) -> u8 {
        match b {
            0..=9 => b'0' + b,
            _ => b'a' + b - 10,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Iterator for EscapeDefault {
    type Item = u8;
    fn next(&mut self) -> Option<u8> {
        self.range.next().map(|i| self.data[i])
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.range.size_hint()
    }
    fn last(mut self) -> Option<u8> {
        self.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl DoubleEndedIterator for EscapeDefault {
    fn next_back(&mut self) -> Option<u8> {
        self.range.next_back().map(|i| self.data[i])
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ExactSizeIterator for EscapeDefault {}
#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for EscapeDefault {}

#[stable(feature = "ascii_escape_display", since = "1.39.0")]
impl fmt::Display for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // XAVFSIZLIK: yaxshi, chunki `escape_default` faqat haqiqiy utf-8 ma'lumotlarini yaratdi
        f.write_str(unsafe { from_utf8_unchecked(&self.data[self.range.clone()]) })
    }
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("EscapeDefault { .. }")
    }
}