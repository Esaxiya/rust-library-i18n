#![stable(feature = "core_hint", since = "1.27.0")]

//! Kodni qanday chiqarish yoki optimallashtirishga ta'sir qiladigan kompilyatorga ko'rsatmalar.
//! Maslahatlar kompilyatsiya vaqti yoki ish vaqti bo'lishi mumkin.

use crate::intrinsics;

/// Kodni ushbu nuqtasiga erishish mumkin emasligi haqida kompilyatorga xabar beradi va bu yanada optimallashtirishga imkon beradi.
///
/// # Safety
///
/// Ushbu funktsiyaga erishish butunlay *aniqlanmagan xatti-harakatlar*(UB).Xususan, kompilyator barcha UB hech qachon bo'lmasligi kerak, shuning uchun `unreachable_unchecked()` ga qo'ng'iroq qiladigan barcha filiallarni yo'q qiladi deb taxmin qiladi.
///
/// Barcha UB misollari singari, agar bu taxmin noto'g'ri bo'lib chiqsa, ya'ni `unreachable_unchecked()` chaqiruvi barcha mumkin bo'lgan boshqaruv oqimlari orasida mavjud bo'lsa, kompilyator noto'g'ri optimallashtirish strategiyasini qo'llaydi va ba'zida bir-biriga bog'liq bo'lmagan ko'rinadigan kodni buzishi mumkin, disk raskadrovka muammolari.
///
///
/// Ushbu funktsiyadan faqat kod uni hech qachon chaqirmasligini isbotlay olsangizgina foydalaning.
/// Aks holda, optimallashtirishga imkon bermaydigan, lekin bajarilganda panic bo'lgan [`unreachable!`] so'lidan foydalanishni o'ylab ko'ring.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` har doim ijobiy (nol emas), shuning uchun `checked_div` hech qachon `None` qaytmaydi.
/////
///     // Shuning uchun, boshqa branch bilan bog'lanib bo'lmaydi.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // XAVFSIZLIK: `intrinsics::unreachable` uchun xavfsizlik shartnomasi shart
    // chaqiruvchi tomonidan qo'llab-quvvatlansin.
    unsafe { intrinsics::unreachable() }
}

/// Protsessorni band-wait spin-loop ("spin lock") da ishlayotganligi to'g'risida signal berish uchun mashina buyrug'ini chiqaradi.
///
/// Spin-loop signalini olgandan so'ng, protsessor o'z ishini optimallashtirishi mumkin, masalan, quvvatni tejash yoki hyper-iplarini almashtirish.
///
/// Ushbu funktsiya to'g'ridan-to'g'ri tizimni rejalashtiruvchiga olib keladigan [`thread::yield_now`] dan farq qiladi, `spin_loop` esa operatsion tizim bilan o'zaro ta'sir qilmaydi.
///
/// `spin_loop` uchun odatiy holat sinxronizatsiya primitivlarida CAS tsiklida cheklangan optimistik yigiruvni amalga oshiradi.
/// Birinchi darajali inversiya kabi muammolardan qochish uchun cheklangan miqdordagi takrorlashdan so'ng tegishli aylanish blokirovkasi tugagach, aylanma tsiklni tugatish tavsiya etiladi.
///
///
/// **Izoh**: Spin-loop maslahatlarini qabul qilishni qo'llab-quvvatlamaydigan platformalarda bu funktsiya umuman hech narsa qilmaydi.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Mavzular muvofiqlashtirish uchun foydalanadigan umumiy atom qiymati
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Orqa fonda biz oxir-oqibat qiymatni o'rnatamiz
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Biroz ishlang, so'ngra qiymatni jonli qiling
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Joriy ipimizga qaytib, biz qiymat o'rnatilishini kutamiz
/// while !live.load(Ordering::Acquire) {
///     // Spin loop-bu biz kutayotgan protsessorga ishora, lekin ehtimol bu juda uzoq emas
/////
///     hint::spin_loop();
/// }
///
/// // Endi qiymat o'rnatildi
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // XAVFSIZLIK: `cfg` attr biz buni faqat x86 maqsadlarida bajarishni kafolatlaydi.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // XAVFSIZLIK: `cfg` attr biz buni faqat x86_64 maqsadlarida bajarishni kafolatlaydi.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // XAVFSIZLIK: `cfg` attr biz buni faqat aarch64 maqsadlarida bajarishni kafolatlaydi.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // XAVFSIZLIK: `cfg` attr biz buni faqat qo'l nishonlarida bajarishni ta'minlaydi
            // v6 xususiyati uchun qo'llab-quvvatlash bilan.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// *__ `black_box` nima qilishi mumkinligi haqida maksimal darajada pessimistik bo'lishi uchun kompilyatorga*__ ishora qiluvchi identifikatsiya funktsiyasi.
///
/// [`std::convert::identity`]-dan farqli o'laroq, Rust kompilyatori `black_box` `dummy`-ni Rust kodiga qo'ng'iroq kodida aniqlanmagan xatti-harakatlarsiz ruxsat berilishi mumkin bo'lgan har qanday usulda ishlatishi mumkin deb taxmin qilishni tavsiya qiladi.
///
/// Ushbu xususiyat `black_box`-ni kodni yozish uchun foydali qiladi, unda ba'zi optimallashtirishlar istalmagan, masalan, mezon.
///
/// Shunga qaramay, `black_box` faqat "best-effort" asosida taqdim etiladi (va faqat bo'lishi mumkin).Optimallashtirishni bloklash darajasi ishlatilgan platforma va code-gen backend-ga qarab farq qilishi mumkin.
/// Dasturlar hech qanday tarzda *to'g'riligi* uchun `black_box`-ga ishonishlari mumkin emas.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Biz argumentni LLVM qandaydir tarzda ko'rib chiqa olmaydigan tarzda "use" qilishimiz kerak va uni qo'llab-quvvatlovchi maqsadlarda biz odatda buni amalga oshirish uchun ichki montajdan foydalanishimiz mumkin.
    // Ichki montajning LLVM talqini-bu qora quti.
    // Bu eng zo'r dastur emas, chunki u biz xohlaganimizdan ham ko'proq narsani optimallashtiradi, ammo hozircha bu juda yaxshi.
    //
    //

    #[cfg(not(miri))] // Bu shunchaki ishora, shuning uchun Mirida o'tish yaxshi.
    // XAVFSIZLIK: ichkaridagi yig'ilish no-op.
    unsafe {
        // FIXME: `asm!`-dan foydalanib bo'lmaydi, chunki u MIPS va boshqa arxitekturalarni qo'llab-quvvatlamaydi.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}