//! String manipulyatsiyasi.
//!
//! Qo'shimcha ma'lumot uchun [`std::str`] moduliga qarang.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. chegaradan
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. begin <=end
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. belgilar chegarasi
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // xarakterini toping
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` len va char chegarasidan kichik bo'lishi kerak
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` uzunligini qaytaradi.
    ///
    /// Ushbu uzunlik [`char`] s yoki grafemlarda emas, baytlarda.
    /// Boshqacha qilib aytganda, odam ipning uzunligini hisobga oladigan narsa bo'lmasligi mumkin.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // chiroyli f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Agar `self` nol bayt uzunligiga ega bo'lsa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// `Indeks`-bayt UTF-8 kod punktlari ketma-ketligi yoki satr oxiridagi birinchi bayt ekanligini tekshiradi.
    ///
    ///
    /// Ipning boshi va oxiri (qachon `indeks== self.len()`) chegara deb hisoblanadi.
    ///
    /// `index` `self.len()` dan katta bo'lsa, `false`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` boshlanishi
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` ning ikkinchi bayti
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` ning uchinchi bayti
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 va len har doim yaxshi.
        // Chekni osongina optimallashtirishi va ushbu holat uchun o'qish satr ma'lumotlarini o'tkazib yuborishi uchun 0 ni aniq sinab ko'ring.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Bu bit sehrli ekvivalenti: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Ip kesimini bayt tilimiga aylantiradi.
    /// Bayt tilimini yana mag'lubiyatga aylantirish uchun [`from_utf8`] funktsiyasidan foydalaning.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // XAVFSIZLIK: konst ovozi, chunki biz bir xil tartibda ikkita turni uzatamiz
        unsafe { mem::transmute(self) }
    }

    /// O'zgaruvchan satr kesimini o'zgaruvchan bayt bo'lagiga o'zgartiradi.
    ///
    /// # Safety
    ///
    /// Qo'ng'iroq qiluvchi qarz tugashidan va asosiy `str` ishlatilishidan oldin tilimning mazmuni UTF-8 haqiqiyligini ta'minlashi kerak.
    ///
    ///
    /// Tarkibi yaroqsiz UTF-8 bo'lgan `str`-dan foydalanish aniqlanmagan xatti-harakatlardir.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // XAVFSIZLIK: `&str` dan `&[u8]` gacha bo'lgan aktyorlar `str` dan beri xavfsizdir
        // `&[u8]` bilan bir xil tartibga ega (faqat libstd ushbu kafolatni berishi mumkin).
        // Ko'rsatkichni ajratib olish xavfsizdir, chunki u o'zgarishi mumkin bo'lgan ma'lumotnomadan kelib chiqadi va bu yozuvlar uchun amal qiladi.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Ipli bo'lakni xom ko'rsatkichga o'zgartiradi.
    ///
    /// Tarmoqli bo'laklar bayt bo'lagi bo'lgani uchun, xom ko'rsatkich [`u8`]-ga ishora qiladi.
    /// Ushbu ko'rsatgich simli bo'lakning birinchi baytiga ishora qiladi.
    ///
    /// Qo'ng'iroq qiluvchi qaytarilgan ko'rsatgich hech qachon yozilmasligini ta'minlashi kerak.
    /// Agar siz mag'lubiyatga bo'lak tarkibini mutatsiyalashingiz kerak bo'lsa, [`as_mut_ptr`] dan foydalaning.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// O'zgaruvchan satr tilimini xom ko'rsatkichga o'zgartiradi.
    ///
    /// Tarmoqli bo'laklar bayt bo'lagi bo'lgani uchun, xom ko'rsatkich [`u8`]-ga ishora qiladi.
    /// Ushbu ko'rsatgich simli bo'lakning birinchi baytiga ishora qiladi.
    ///
    /// Ip bo'lagi faqat UTF-8 kuchini saqlab qoladigan tarzda o'zgartirilishini ta'minlash sizning javobgarligingizdir.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` sublitsiyasini qaytaradi.
    ///
    /// Bu `str` indeksatsiyasining vahima qo'zg'atmaydigan alternativasi.
    /// Ekvivalent indekslash jarayoni panic bo'lganida, [`None`]-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indekslar UTF-8 ketma-ketligi chegaralarida emas
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // chegaradan
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` o'zgaruvchan sublitsiyasini qaytaradi.
    ///
    /// Bu `str` indeksatsiyasining vahima qo'zg'atmaydigan alternativasi.
    /// Ekvivalent indekslash jarayoni panic bo'lganida, [`None`]-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // to'g'ri uzunlik
    /// assert!(v.get_mut(0..5).is_some());
    /// // chegaradan
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` tekshirilmagan sublitsiyasini qaytaradi.
    ///
    /// Bu `str` indeksatsiyasining tekshirilmagan alternativasi.
    ///
    /// # Safety
    ///
    /// Ushbu funktsiyani chaqiruvchilar ushbu shartlar bajarilishi uchun javobgardir:
    ///
    /// * Boshlang'ich indeks yakuniy indeksdan oshmasligi kerak;
    /// * Indekslar asl tilim chegaralarida bo'lishi kerak;
    /// * Indekslar UTF-8 ketma-ketligi chegaralarida yotishi kerak.
    ///
    /// Amalga oshirilmaganda, qaytarilgan mag'lubiyat yaroqsiz xotiraga murojaat qilishi yoki `str` turi bilan bog'langan invariantlarni buzishi mumkin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `get_unchecked` uchun xavfsizlik shartnomasini bajarishi kerak;
        // tilim ajratilishi mumkin, chunki `self` xavfsiz ma'lumotdir.
        // Qaytgan ko'rsatgich xavfsizdir, chunki `SliceIndex` impllari buning kafolatiga ega bo'lishi kerak.
        unsafe { &*i.get_unchecked(self) }
    }

    /// O'zgaruvchan, tekshirilmagan `str` sublitsiyasini qaytaradi.
    ///
    /// Bu `str` indeksatsiyasining tekshirilmagan alternativasi.
    ///
    /// # Safety
    ///
    /// Ushbu funktsiyani chaqiruvchilar ushbu shartlar bajarilishi uchun javobgardir:
    ///
    /// * Boshlang'ich indeks yakuniy indeksdan oshmasligi kerak;
    /// * Indekslar asl tilim chegaralarida bo'lishi kerak;
    /// * Indekslar UTF-8 ketma-ketligi chegaralarida yotishi kerak.
    ///
    /// Amalga oshirilmaganda, qaytarilgan mag'lubiyat yaroqsiz xotiraga murojaat qilishi yoki `str` turi bilan bog'langan invariantlarni buzishi mumkin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `get_unchecked_mut` uchun xavfsizlik shartnomasini bajarishi kerak;
        // tilim ajratilishi mumkin, chunki `self` xavfsiz ma'lumotdir.
        // Qaytgan ko'rsatgich xavfsizdir, chunki `SliceIndex` impllari buning kafolatiga ega bo'lishi kerak.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Xavfsizlik tekshiruvlarini chetlab o'tib, boshqa chiziqli bo'lakdan ipli bo'lak hosil qiladi.
    ///
    /// Odatda bu tavsiya etilmaydi, ehtiyotkorlik bilan foydalaning!Xavfsiz alternativa uchun [`str`] va [`Index`]-ga qarang.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Ushbu yangi tilim `begin` dan `end` gacha, shu jumladan `begin` ga, lekin `end` bundan mustasno.
    ///
    /// O'zgaruvchan satr tilimini olish uchun [`slice_mut_unchecked`] usulini ko'ring.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Ushbu funktsiyani chaqiruvchilar uchta shart bajarilishi uchun javobgardir:
    ///
    /// * `begin` `end` dan oshmasligi kerak.
    /// * `begin` va `end` mag'lubiyat bo'lagi ichida bayt pozitsiyalari bo'lishi kerak.
    /// * `begin` va `end` UTF-8 ketma-ketlik chegaralarida yotishi kerak.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `get_unchecked` uchun xavfsizlik shartnomasini bajarishi kerak;
        // tilim ajratilishi mumkin, chunki `self` xavfsiz ma'lumotdir.
        // Qaytgan ko'rsatgich xavfsizdir, chunki `SliceIndex` impllari buning kafolatiga ega bo'lishi kerak.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Xavfsizlik tekshiruvlarini chetlab o'tib, boshqa chiziqli bo'lakdan ipli bo'lak hosil qiladi.
    /// Odatda bu tavsiya etilmaydi, ehtiyotkorlik bilan foydalaning!Xavfsiz alternativa uchun [`str`] va [`IndexMut`]-ga qarang.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Ushbu yangi tilim `begin` dan `end` gacha, shu jumladan `begin` ga, lekin `end` bundan mustasno.
    ///
    /// O'zgarmas mag'lubiyatga tilim olish uchun [`slice_unchecked`] usulini ko'ring.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Ushbu funktsiyani chaqiruvchilar uchta shart bajarilishi uchun javobgardir:
    ///
    /// * `begin` `end` dan oshmasligi kerak.
    /// * `begin` va `end` mag'lubiyat bo'lagi ichida bayt pozitsiyalari bo'lishi kerak.
    /// * `begin` va `end` UTF-8 ketma-ketlik chegaralarida yotishi kerak.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `get_unchecked_mut` uchun xavfsizlik shartnomasini bajarishi kerak;
        // tilim ajratilishi mumkin, chunki `self` xavfsiz ma'lumotdir.
        // Qaytgan ko'rsatgich xavfsizdir, chunki `SliceIndex` impllari buning kafolatiga ega bo'lishi kerak.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Bir qatorli bo'lakni indeks bo'yicha ikkiga bo'ling.
    ///
    /// Argument, `mid`, mag'lubiyat boshidan baytga ofset bo'lishi kerak.
    /// Bundan tashqari, u UTF-8 kod nuqtasi chegarasida bo'lishi kerak.
    ///
    /// Qaytgan ikkita tilim mag'lubiyat bo'lagining boshidan `mid` gacha, `mid` dan esa tilim tilimining oxirigacha boradi.
    ///
    /// O'zgaruvchan satr tilimlarini olish uchun [`split_at_mut`] usulini ko'ring.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Agar 0Panics, agar `mid` UTF-8 kod nuqtasi chegarasida bo'lmasa yoki u satr kesimining so'nggi kod nuqtasi tugagan bo'lsa.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary indeksning [0, .len()]
        if self.is_char_boundary(mid) {
            // XAVFSIZLIK: faqat `mid` ning char chegarasida ekanligini tekshiring.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Bir o'zgaruvchan mag'lubiyatga bo'lakni indeks bo'yicha ikkiga bo'ling.
    ///
    /// Argument, `mid`, mag'lubiyat boshidan baytga ofset bo'lishi kerak.
    /// Bundan tashqari, u UTF-8 kod nuqtasi chegarasida bo'lishi kerak.
    ///
    /// Qaytgan ikkita tilim mag'lubiyat bo'lagining boshidan `mid` gacha, `mid` dan esa tilim tilimining oxirigacha boradi.
    ///
    /// O'zgarmas mag'lubiyatli tilimlarni olish uchun [`split_at`] uslubiga qarang.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Agar 0Panics, agar `mid` UTF-8 kod nuqtasi chegarasida bo'lmasa yoki u satr kesimining so'nggi kod nuqtasi tugagan bo'lsa.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary indeksning [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // XAVFSIZLIK: faqat `mid` ning char chegarasida ekanligini tekshiring.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Satr kesimining [`char`] s ustiga iteratorni qaytaradi.
    ///
    /// Tarmoqli bo'lak yaroqli UTF-8 dan iborat bo'lganligi sababli, biz [`char`] tomonidan chiziqli tilim orqali takrorlashimiz mumkin.
    /// Ushbu usul bunday iteratorni qaytaradi.
    ///
    /// Shuni esda tutish kerakki, [`char`] Unicode skaler qiymatini anglatadi va 'character' nima ekanligi haqidagi fikringizga mos kelmasligi mumkin.
    ///
    /// Grafem klasterlari bo'yicha takrorlash siz xohlagan narsa bo'lishi mumkin.
    /// Ushbu funktsiya Rust standart kutubxonasi tomonidan ta'minlanmagan, buning o'rniga crates.io-ni tekshiring.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Esingizda bo'lsin, [`char`] belgilar sizning sezgiingizga mos kelmasligi mumkin:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' emas
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Satr kesimining [`char`] s ustiga iteratorni va ularning joylashishini qaytaradi.
    ///
    /// Tarmoqli bo'lak yaroqli UTF-8 dan iborat bo'lganligi sababli, biz [`char`] tomonidan chiziqli tilim orqali takrorlashimiz mumkin.
    /// Ushbu usul ikkala [`char`] ning va shuningdek ularning bayt pozitsiyalarining iteratorini qaytaradi.
    ///
    /// Takrorlash moslamasi natija beradi.Lavozim birinchi, [`char`] ikkinchi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Esingizda bo'lsin, [`char`] belgilar sizning sezgiingizga mos kelmasligi mumkin:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // emas (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // bu erda 3 ga e'tibor bering, oxirgi belgi ikki baytni egalladi
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Ipli tilim baytlari ustida takrorlovchi.
    ///
    /// Ipli tilim baytlar ketma-ketligidan iborat bo'lgani uchun, biz baytlar qatori orqali takrorlashimiz mumkin.
    /// Ushbu usul bunday iteratorni qaytaradi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Ipli bo'lakni bo'sh joy bilan ajratadi.
    ///
    /// Qaytgan iterator, bo'shliqning istalgan miqdori bilan ajratilgan, dastlabki satr tilimining pastki bo'laklari bo'lgan satr tilimlarini qaytaradi.
    ///
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` shartlariga muvofiq belgilanadi.
    /// Agar siz faqat ASCII bo'sh joyida bo'lishni xohlasangiz, [`split_ascii_whitespace`] dan foydalaning.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Bo'shliqning barcha turlari quyidagilar hisoblanadi:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Ipli bo'lakni ASCII bo'sh joyiga ajratadi.
    ///
    /// Qaytgan iterator, asl satr tilimining pastki bo'laklari bo'lgan, har qanday miqdordagi ASCII bo'sh joy bilan ajratilgan satr tilimlarini qaytaradi.
    ///
    ///
    /// Unicode `Whitespace` tomonidan ajratish uchun [`split_whitespace`] foydalaning.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ASCII bo'shliqlarining barcha turlari quyidagilar hisoblanadi:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Ip chiziqlari bo'ylab, chiziqli tilim kabi iterator.
    ///
    /// Chiziqlar (`\n`) yangi qatori yoki (`\r\n`) chiziqli beslemeli vagon qaytishi bilan tugaydi.
    ///
    /// Oxirgi chiziq tugashi ixtiyoriy.
    /// Oxirgi satr tugashi bilan tugagan satr, xuddi shu satrlarni oxirgi satrsiz, aks holda bir xil satrlarni qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Oxirgi satr tugashi shart emas:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Ip chiziqlari bo'ylab iterator.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 sifatida kodlangan mag'lubiyatga `u16` iteratorini qaytaradi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Agar berilgan naqsh ushbu satr tilimining pastki qismiga to'g'ri keladigan bo'lsa, `true`-ni qaytaradi.
    ///
    /// Agar yo'q bo'lsa, `false`-ni qaytaradi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Agar berilgan naqsh ushbu satr kesimining prefiksiga to'g'ri keladigan bo'lsa, `true`-ni qaytaradi.
    ///
    /// Agar yo'q bo'lsa, `false`-ni qaytaradi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Agar berilgan naqsh ushbu satr kesimining qo'shimchasiga to'g'ri keladigan bo'lsa, `true`-ni qaytaradi.
    ///
    /// Agar yo'q bo'lsa, `false`-ni qaytaradi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Ushbu satr kesimining naqshga mos keladigan birinchi belgisining bayt indeksini qaytaradi.
    ///
    /// Agar naqsh mos kelmasa, [`None`]-ni qaytaradi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Oddiy naqshlar:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Nuqsonsiz uslub va yopilishlardan foydalangan holda yanada murakkab naqshlar:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Naqsh topilmayapti:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Ushbu satr kesimidagi naqshning o'ng tomonidagi eng mos keladigan birinchi belgi uchun bayt indeksini qaytaradi.
    ///
    /// Agar naqsh mos kelmasa, [`None`]-ni qaytaradi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Oddiy naqshlar:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Yopish bilan yanada murakkab naqshlar:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Naqsh topilmayapti:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Ushbu chiziqli tilimning pastki satrlari bo'ylab takrorlovchi, naqsh bilan mos belgilar bilan ajratilgan.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorning harakati
    ///
    /// Qaytgan iterator [`DoubleEndedIterator`] bo'ladi, agar naqsh teskari qidiruvga imkon bersa va forward/reverse qidiruvi bir xil elementlarga ega bo'lsa.
    /// Bu, masalan, [`char`] uchun to'g'ri, lekin `&str` uchun emas.
    ///
    /// Agar naqsh teskari qidiruvga imkon bersa, lekin uning natijalari oldinga qarab qidirishdan farq qilishi mumkin bo'lsa, [`rsplit`] usulidan foydalanish mumkin.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Oddiy naqshlar:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Agar naqsh chiziq belgilar bo'lsa, har qanday belgi paydo bo'lishiga bo'ling:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Yopish yordamida yanada murakkab naqsh:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Agar satrda bir nechta qo'shni ajratgichlar mavjud bo'lsa, siz natijada bo'sh satrlar bilan yakunlanasiz:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Qo'shni ajratgichlar bo'sh satr bilan ajralib turadi.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Ipning boshida yoki oxirida ajratgichlar bo'sh satrlar bilan qo'shni.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Bo'sh satr ajratuvchi sifatida ishlatilsa, u satrning har bir belgisini, qatorning boshi va oxiri bilan birga ajratadi.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Bo'shliq ajratuvchi sifatida ishlatilganda tutashgan ajratgichlar hayratlanarli xatti-harakatlarga olib kelishi mumkin.Ushbu kod to'g'ri:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ sizga quyidagilarni beradi:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Ushbu xatti-harakatlar uchun [`split_whitespace`]-dan foydalaning.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Ushbu chiziqli tilimning pastki satrlari bo'ylab takrorlovchi, naqsh bilan mos belgilar bilan ajratilgan.
    /// `split` tomonidan ishlab chiqarilgan iteratordan farq qiladi, chunki `split_inclusive` mos keladigan qismni substring terminatori sifatida qoldiradi.
    ///
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Agar mag'lubiyatning so'nggi elementi mos keladigan bo'lsa, u element oldingi pastki satrning terminatori hisoblanadi.
    /// Ushbu substring iterator tomonidan qaytarilgan so'nggi element bo'ladi.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Naqsh bilan mos keladigan va teskari tartibda berilgan belgilar bilan ajratilgan berilgan satr tilimining pastki satrlari ustidagi iterator.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorning harakati
    ///
    /// Qaytgan iterator naqshning teskari qidirishni qo'llab-quvvatlashini talab qiladi va agar forward/reverse qidiruvi bir xil elementlarni keltirsa, u [`DoubleEndedIterator`] bo'ladi.
    ///
    ///
    /// Old tomondan takrorlash uchun [`split`] usulidan foydalanish mumkin.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Oddiy naqshlar:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Yopish yordamida yanada murakkab naqsh:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Naqsh bilan mos belgilar bilan ajratilgan, berilgan torli tilimning pastki satrlari bo'ylab iterator.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] ga teng, faqat bo'sh satr bo'sh bo'lsa, o'tkazib yuboriladi.
    ///
    /// [`split`]: str::split
    ///
    /// Ushbu usul naqshli _separated_ o'rniga, _terminated_ bo'lgan mag'lubiyatga oid ma'lumotlar uchun ishlatilishi mumkin.
    ///
    /// # Iteratorning harakati
    ///
    /// Qaytgan iterator [`DoubleEndedIterator`] bo'ladi, agar naqsh teskari qidiruvga imkon bersa va forward/reverse qidiruvi bir xil elementlarga ega bo'lsa.
    /// Bu, masalan, [`char`] uchun to'g'ri, lekin `&str` uchun emas.
    ///
    /// Agar naqsh teskari qidiruvga imkon bersa, lekin uning natijalari oldinga qarab qidirishdan farq qilishi mumkin bo'lsa, [`rsplit_terminator`] usulidan foydalanish mumkin.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Naqsh bilan mos keladigan va teskari tartibda hosil bo'lgan belgilar bilan ajratilgan `self` satrlari ustidagi iterator.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] ga teng, faqat bo'sh satr bo'sh bo'lsa, o'tkazib yuboriladi.
    ///
    /// [`split`]: str::split
    ///
    /// Ushbu usul naqshli _separated_ o'rniga, _terminated_ bo'lgan mag'lubiyatga oid ma'lumotlar uchun ishlatilishi mumkin.
    ///
    /// # Iteratorning harakati
    ///
    /// Qaytgan iterator naqshning teskari qidiruvni qo'llab-quvvatlashini talab qiladi va agar forward/reverse qidiruvi bir xil elementlarga ega bo'lsa, u ikki baravar bo'ladi.
    ///
    ///
    /// Old tomondan takrorlash uchun [`split_terminator`] usulidan foydalanish mumkin.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Berilgan mag'lubiyat qismining pastki satrlari bo'ylab, naqsh bilan ajratilgan, ko'pi bilan `n` elementlarini qaytarish bilan cheklangan iterator.
    ///
    /// Agar `n` pastki satrlari qaytarilsa, oxirgi satr ("n`-pastki satr") qatorning qolgan qismini o'z ichiga oladi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorning harakati
    ///
    /// Qaytgan iterator ikki marta tugamaydi, chunki uni qo'llab-quvvatlash samarasiz.
    ///
    /// Agar naqsh teskari izlashga imkon bersa, [`rsplitn`] usulidan foydalanish mumkin.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Oddiy naqshlar:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Yopish yordamida yanada murakkab naqsh:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Ushbu mag'lubiyat tilimining pastki satrlari ustidagi takrorlovchi, naqsh bilan ajratilgan, mag'lubiyatning oxiridan boshlab, ko'pi bilan `n` elementni qaytarish bilan cheklangan.
    ///
    ///
    /// Agar `n` pastki satrlari qaytarilsa, oxirgi satr ("n`-pastki satr") qatorning qolgan qismini o'z ichiga oladi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorning harakati
    ///
    /// Qaytgan iterator ikki marta tugamaydi, chunki uni qo'llab-quvvatlash samarasiz.
    ///
    /// Old tomondan bo'linish uchun [`splitn`] usulidan foydalanish mumkin.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Oddiy naqshlar:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Yopish yordamida yanada murakkab naqsh:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Belgilangan ajratuvchining birinchi paydo bo'lishida satrni ajratadi va ajratuvchidan oldin prefiksni va ajratuvchidan keyin qo'shimchani qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Satrni ko'rsatilgan ajratuvchining oxirgi paydo bo'lishiga ajratadi va prefiksni ajratuvchidan oldin, ajratuvchidan keyin qo'shimchasini qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Berilgan mag'lubiyat bo'lagi ichidagi naqshning mos kelmaydigan o'yinlari ustidan iterator.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorning harakati
    ///
    /// Qaytgan iterator [`DoubleEndedIterator`] bo'ladi, agar naqsh teskari qidiruvga imkon bersa va forward/reverse qidiruvi bir xil elementlarga ega bo'lsa.
    /// Bu, masalan, [`char`] uchun to'g'ri, lekin `&str` uchun emas.
    ///
    /// Agar naqsh teskari qidiruvga imkon bersa, lekin uning natijalari oldinga qarab qidirishdan farq qilishi mumkin bo'lsa, [`rmatches`] usulidan foydalanish mumkin.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Ushbu qator bo'lagi ichidagi naqshning ajratilgan gugurtlari ustidan takrorlovchi teskari tartibda chiqdi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorning harakati
    ///
    /// Qaytgan iterator naqshning teskari qidirishni qo'llab-quvvatlashini talab qiladi va agar forward/reverse qidiruvi bir xil elementlarni keltirsa, u [`DoubleEndedIterator`] bo'ladi.
    ///
    ///
    /// Old tomondan takrorlash uchun [`matches`] usulidan foydalanish mumkin.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Ushbu qatorli bo'lak ichidagi naqshning mos kelmagan o'yinlari ustidan takrorlovchi, shuningdek, o'yin boshlanadigan indeks.
    ///
    /// `self` doirasidagi `pat` o'yinlari uchun bir-biriga to'g'ri keladigan o'yinlar uchun faqat birinchi o'yinga to'g'ri keladigan indekslar qaytariladi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorning harakati
    ///
    /// Qaytgan iterator [`DoubleEndedIterator`] bo'ladi, agar naqsh teskari qidiruvga imkon bersa va forward/reverse qidiruvi bir xil elementlarga ega bo'lsa.
    /// Bu, masalan, [`char`] uchun to'g'ri, lekin `&str` uchun emas.
    ///
    /// Agar naqsh teskari qidiruvga imkon bersa, lekin uning natijalari oldinga qarab qidirishdan farq qilishi mumkin bo'lsa, [`rmatch_indices`] usulidan foydalanish mumkin.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // faqat birinchi `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` ichidagi naqshning mos kelmagan o'yinlari ustidan iterator, mos keladigan ko'rsatkich bilan birga teskari tartibda chiqdi.
    ///
    /// `self` doirasidagi `pat` o'yinlari uchun bir-biriga to'g'ri keladigan o'yinlar uchun faqat oxirgi o'yinga to'g'ri keladigan indekslar qaytariladi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratorning harakati
    ///
    /// Qaytgan iterator naqshning teskari qidirishni qo'llab-quvvatlashini talab qiladi va agar forward/reverse qidiruvi bir xil elementlarni keltirsa, u [`DoubleEndedIterator`] bo'ladi.
    ///
    ///
    /// Old tomondan takrorlash uchun [`match_indices`] usulidan foydalanish mumkin.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // faqat oxirgi `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Bo'shliqning etakchi va so'nggi bo'shliqlari olib tashlangan qatorli tilimni qaytaradi.
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` shartlariga muvofiq belgilanadi.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Bo'sh joyni olib tashlagan qatorli bo'lakni qaytaradi.
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` shartlariga muvofiq belgilanadi.
    ///
    /// # Matn yo'nalishi
    ///
    /// Satr-bu baytlar ketma-ketligi.
    /// `start` ushbu kontekstda ushbu bayt satrining birinchi pozitsiyasi;ingliz yoki rus kabi chapdan o'ngga til uchun bu chap tomonda, arab yoki ibroniy kabi o'ngdan chapga esa bu o'ng tomon bo'ladi.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// So'nggi bo'sh joy olib tashlangan qatorli tilimni qaytaradi.
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` shartlariga muvofiq belgilanadi.
    ///
    /// # Matn yo'nalishi
    ///
    /// Satr-bu baytlar ketma-ketligi.
    /// `end` bu kontekstda ushbu bayt satrining oxirgi holati;ingliz yoki rus kabi chapdan o'ngga til uchun bu o'ng tomon, arab yoki ibroniy kabi o'ngdan chapga esa chap tomon bo'ladi.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Bo'sh joyni olib tashlagan qatorli bo'lakni qaytaradi.
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` shartlariga muvofiq belgilanadi.
    ///
    /// # Matn yo'nalishi
    ///
    /// Satr-bu baytlar ketma-ketligi.
    /// 'Left' ushbu kontekstda ushbu bayt satrining birinchi pozitsiyasi;arab yoki ibroniy kabi "chapdan o'ngga" emas, "o'ngdan chapga" bo'lgan til uchun bu _right_ tomoni bo'ladi, chap emas.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// So'nggi bo'sh joy olib tashlangan qatorli tilimni qaytaradi.
    ///
    /// 'Whitespace' Unicode Derived Core Property `White_Space` shartlariga muvofiq belgilanadi.
    ///
    /// # Matn yo'nalishi
    ///
    /// Satr-bu baytlar ketma-ketligi.
    /// 'Right' bu kontekstda ushbu bayt satrining oxirgi holati;arab yoki ibroniy kabi "chapdan o'ngga" emas, "o'ngdan chapga" bo'lgan til uchun bu _left_ tomoni bo'ladi, o'ng emas.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Bir qatorni olib tashlangan naqshga mos keladigan barcha prefiks va qo'shimchalar bilan mag'lubiyatni qaytaradi.
    ///
    /// [pattern] [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Oddiy naqshlar:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Yopish yordamida yanada murakkab naqsh:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Avvalgi o'yinni eslang, agar quyida tuzatsangiz
            // oxirgi o'yin boshqacha
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // XAVFSIZLIK: `Searcher` haqiqiy indekslarni qaytarishi ma'lum.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Bir necha marta olib tashlangan naqshga mos keladigan barcha prefikslar bilan mag'lubiyat tilimini qaytaradi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Matn yo'nalishi
    ///
    /// Satr-bu baytlar ketma-ketligi.
    /// `start` ushbu kontekstda ushbu bayt satrining birinchi pozitsiyasi;ingliz yoki rus kabi chapdan o'ngga til uchun bu chap tomonda, arab yoki ibroniy kabi o'ngdan chapga esa bu o'ng tomon bo'ladi.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // XAVFSIZLIK: `Searcher` haqiqiy indekslarni qaytarishi ma'lum.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Prefiks olib tashlangan qatorli tilimni qaytaradi.
    ///
    /// Agar mag'lubiyat `prefix` naqshidan boshlangan bo'lsa, `Some` ga o'ralgan holda prefiksdan keyin pastki qatorni qaytaradi.
    /// `trim_start_matches`-dan farqli o'laroq, ushbu usul prefiksni to'liq bir marta olib tashlaydi.
    ///
    /// Agar mag'lubiyat `prefix` bilan boshlanmasa, `None` ni qaytaradi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Qo'shimchani olib tashlagan holda chiziqli tilimni qaytaradi.
    ///
    /// Agar mag'lubiyat `suffix` naqsh bilan tugasa, substringni `Some` ga o'ralgan qo'shimchadan oldin qaytaradi.
    /// `trim_end_matches`-dan farqli o'laroq, bu usul qo'shimchani to'liq bir marta olib tashlaydi.
    ///
    /// Agar mag'lubiyat `suffix` bilan tugamasa, `None` ni qaytaradi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Bir necha marta olib tashlangan naqshga mos keladigan barcha qo'shimchalar bilan mag'lubiyatni qaytaradi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Matn yo'nalishi
    ///
    /// Satr-bu baytlar ketma-ketligi.
    /// `end` bu kontekstda ushbu bayt satrining oxirgi holati;ingliz yoki rus kabi chapdan o'ngga til uchun bu o'ng tomon, arab yoki ibroniy kabi o'ngdan chapga esa chap tomon bo'ladi.
    ///
    ///
    /// # Examples
    ///
    /// Oddiy naqshlar:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Yopish yordamida yanada murakkab naqsh:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // XAVFSIZLIK: `Searcher` haqiqiy indekslarni qaytarishi ma'lum.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Bir necha marta olib tashlangan naqshga mos keladigan barcha prefikslar bilan mag'lubiyat tilimini qaytaradi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Matn yo'nalishi
    ///
    /// Satr-bu baytlar ketma-ketligi.
    /// 'Left' ushbu kontekstda ushbu bayt satrining birinchi pozitsiyasi;arab yoki ibroniy kabi "chapdan o'ngga" emas, "o'ngdan chapga" bo'lgan til uchun bu _right_ tomoni bo'ladi, chap emas.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Bir necha marta olib tashlangan naqshga mos keladigan barcha qo'shimchalar bilan mag'lubiyatni qaytaradi.
    ///
    /// [pattern] `&str`, [`char`], [`char`] lar bo'lagi yoki belgining mos kelishini belgilaydigan funktsiya yoki yopilish bo'lishi mumkin.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Matn yo'nalishi
    ///
    /// Satr-bu baytlar ketma-ketligi.
    /// 'Right' bu kontekstda ushbu bayt satrining oxirgi holati;arab yoki ibroniy kabi "chapdan o'ngga" emas, "o'ngdan chapga" bo'lgan til uchun bu _left_ tomoni bo'ladi, o'ng emas.
    ///
    ///
    /// # Examples
    ///
    /// Oddiy naqshlar:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Yopish yordamida yanada murakkab naqsh:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Ushbu satrni boshqa turga ajratadi.
    ///
    /// `parse` juda umumiy bo'lganligi sababli, u turdagi xulosalar bilan bog'liq muammolarni keltirib chiqarishi mumkin.
    /// Shunday qilib, `parse` siz 'turbofish' deb nomlanadigan sintaksisni ko'radigan bir necha marta biridir: `::<>`.
    ///
    /// Bu xulosa algoritmiga qaysi turni tahlil qilmoqchi ekaningizni aniq tushunishga yordam beradi.
    ///
    /// `parse` [`FromStr`] trait-ni amalga oshiradigan har qanday turga ajralishi mumkin.
    ///

    /// # Errors
    ///
    /// Agar ushbu mag'lubiyatni kerakli turga ajratish imkoni bo'lmasa, [`Err`] qaytadi.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` izohlash o'rniga 'turbofish' dan foydalanish:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Ajratib bo'lmadi:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Ushbu satrdagi barcha belgilar ASCII oralig'ida ekanligini tekshiradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Biz bu erda har bir baytni belgi sifatida ko'rib chiqishimiz mumkin: barcha ko'p baytli belgilar ascii diapazonida bo'lmagan bayt bilan boshlanadi, shuning uchun biz shu erda to'xtab qolamiz.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Ikki satr ASCII holatiga sezgir bo'lmagan o'yin ekanligini tekshiradi.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` bilan bir xil, ammo vaqtinchaliklarni ajratmasdan va nusxalashsiz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Ushbu mag'lubiyatni o'z o'rniga ASCII katta bosh harfiga o'zgartiradi.
    ///
    /// 'a' dan 'z' gacha bo'lgan ASCII harflari 'A' dan 'Z' gacha xaritalanadi, ammo ASCII bo'lmagan harflar o'zgarmaydi.
    ///
    /// Mavjud qiymatni o'zgartirmasdan yangi bosh harfni qaytarish uchun [`to_ascii_uppercase()`] dan foydalaning.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // XAVFSIZLIK: xavfsiz, chunki biz bir xil tartibda ikkita turni o'zgartiramiz.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Ushbu mag'lubiyatni o'z o'rniga ASCII kichik harfiga aylantiradi.
    ///
    /// 'A' dan 'Z' gacha bo'lgan ASCII harflari 'a' dan 'z' gacha xaritalanadi, ammo ASCII bo'lmagan harflar o'zgarmaydi.
    ///
    /// Mavjud qiymatni o'zgartirmasdan yangi kichik harfli qiymatni qaytarish uchun [`to_ascii_lowercase()`] dan foydalaning.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // XAVFSIZLIK: xavfsiz, chunki biz bir xil tartibda ikkita turni o'zgartiramiz.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// `self`-da [`char::escape_debug`] bilan har bir char dan qochib ketadigan iteratorni qaytaring.
    ///
    ///
    /// Note: faqat mag'lubiyatni boshlaydigan kengaytirilgan grafem kod nuqtalari qochib ketadi.
    ///
    /// # Examples
    ///
    /// Takrorlovchi sifatida:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// To'g'ridan-to'g'ri `println!`-dan foydalanish:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Ikkalasi ham quyidagilarga teng:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` dan foydalanish:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// `self`-da [`char::escape_default`] bilan har bir char dan qochib ketadigan iteratorni qaytaring.
    ///
    ///
    /// # Examples
    ///
    /// Takrorlovchi sifatida:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// To'g'ridan-to'g'ri `println!`-dan foydalanish:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Ikkalasi ham quyidagilarga teng:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` dan foydalanish:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// `self`-da [`char::escape_unicode`] bilan har bir chardan qochib ketadigan iteratorni qaytaring.
    ///
    ///
    /// # Examples
    ///
    /// Takrorlovchi sifatida:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// To'g'ridan-to'g'ri `println!`-dan foydalanish:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Ikkalasi ham quyidagilarga teng:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` dan foydalanish:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Bo'sh str hosil qiladi
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Bo'sh o'zgaruvchan str yaratadi
    #[inline]
    fn default() -> Self {
        // XAVFSIZLIK: bo'sh satr UTF-8 uchun amal qiladi.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Taniqli, klonlanadigan fn turi
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // XAVFSIZLIK: xavfsiz emas
        unsafe { from_utf8_unchecked(bytes) }
    };
}