//! `str` uchun Trait dasturlari.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Iplarga buyurtma berishni amalga oshiradi.
///
/// Satrlar bayt qiymatlari bo'yicha [lexicographically](Ord#lexicographical-comparison)-ga tartiblangan.
/// Bu kodlar jadvalidagi pozitsiyalariga qarab Unicode kod punktlarini buyurtma qiladi.
/// Bu "alphabetical" buyurtmasi bilan bir xil bo'lishi shart emas, bu til va til jihatidan farq qiladi.
/// Iplarni madaniy qabul qilingan standartlarga muvofiq saralash uchun `str` turi doirasidan tashqarida bo'lgan mahalliy ma'lumotlarga ehtiyoj bor.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Iplarga taqqoslash operatsiyalarini amalga oshiradi.
///
/// Satrlar bayt qiymatlari bo'yicha [lexicographically](Ord#lexicographical-comparison) bilan taqqoslanadi.
/// Bu kod jadvallaridagi pozitsiyalariga qarab Unicode kod punktlarini taqqoslaydi.
/// Bu "alphabetical" buyurtmasi bilan bir xil bo'lishi shart emas, bu til va til jihatidan farq qiladi.
/// Iplarni madaniy qabul qilingan standartlarga muvofiq taqqoslash uchun `str` turi doirasidan tashqarida bo'lgan mahalliy ma'lumotlarga ehtiyoj bor.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Sintaksis `&self[..]` yoki `&mut self[..]` bilan substring tilimlashni amalga oshiradi.
///
/// Barcha mag'lubiyatning bir qismini qaytaradi, ya'ni `&self` yoki `&mut self` ni qaytaradi."&Self" ga teng [0 ..
/// len] `yoki`&mut mut [0 ..
/// len]`.
/// Boshqa indekslash operatsiyalaridan farqli o'laroq, bu hech qachon panic qila olmaydi.
///
/// Ushbu operatsiya *O*(1).
///
/// 1.20.0 dan oldin ushbu indekslash operatsiyalari to'g'ridan-to'g'ri `Index` va `IndexMut` dasturlari tomonidan qo'llab-quvvatlangan.
///
/// `&self[0 .. len]` yoki `&mut self[0 .. len]` ga teng.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Sintaksis `&self[begin .. end]` yoki `&mut self[begin .. end]` bilan substring tilimlashni amalga oshiradi.
///
/// Bayt oralig'idan berilgan qatorning bir qismini qaytaradi [`begin`, `end`).
///
/// Ushbu operatsiya *O*(1).
///
/// 1.20.0 dan oldin ushbu indekslash operatsiyalari to'g'ridan-to'g'ri `Index` va `IndexMut` dasturlari tomonidan qo'llab-quvvatlangan.
///
/// # Panics
///
/// Agar Panics, agar `begin` yoki `end` belgilarning boshlang'ich bayt ofsetiga ishora qilmasa (`is_char_boundary` tomonidan belgilanadigan bo'lsa), agar `begin > end` bo'lsa yoki `end > len` bo'lsa.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // bular panic bo'ladi:
/// // bayt 2 `ö` ichida joylashgan:
/// // &s [2 ..3];
///
/// // bayt 8 `老`&s ichida yotadi [1 ..
/// // 8];
///
/// // bayt 100 satrdan tashqarida&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // XAVFSIZLIK: `start` va `end` char chegarasida ekanligini tekshiring,
            // va biz xavfsiz ma'lumotnomaga o'tmoqdamiz, shuning uchun qaytish qiymati ham bitta bo'ladi.
            // Biz char chegaralarini ham tekshirdik, shuning uchun bu UTF-8 amal qiladi.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // XAVFSIZLIK: faqat `start` va `end` lar chegarasida ekanligini tekshiring.
            // Biz ko'rsatkichni noyob ekanligini bilamiz, chunki biz uni `slice` dan oldik.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` ning `slice` chegaralarida bo'lishiga kafolat beradi
        // bu `add` uchun barcha shartlarni qondiradi.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // XAVFSIZLIK: `get_unchecked` uchun sharhlarga qarang.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary, indeks [0, .len()] da yuqoridagi kabi `get` dan foydalana olmasligini tekshiradi, chunki NLL muammosi
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // XAVFSIZLIK: `start` va `end` char chegarasida ekanligini tekshiring,
            // va biz xavfsiz ma'lumotnomaga o'tmoqdamiz, shuning uchun qaytish qiymati ham bitta bo'ladi.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Sintaksis `&self[.. end]` yoki `&mut self[.. end]` bilan substring tilimlashni amalga oshiradi.
///
/// [`0`, `end`) bayt oralig'idan berilgan satrning bir bo'lagini qaytaradi.
/// `&self[0 .. end]` yoki `&mut self[0 .. end]` ga teng.
///
/// Ushbu operatsiya *O*(1).
///
/// 1.20.0 dan oldin ushbu indekslash operatsiyalari to'g'ridan-to'g'ri `Index` va `IndexMut` dasturlari tomonidan qo'llab-quvvatlangan.
///
/// # Panics
///
/// Agar Panics, agar `end` belgining boshlang'ich bayt ofsetiga ishora qilmasa (`is_char_boundary` tomonidan belgilangan) yoki `end > len` bo'lsa.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // XAVFSIZLIK: `end` ning char chegarasida ekanligini tekshiring,
            // va biz xavfsiz ma'lumotnomaga o'tmoqdamiz, shuning uchun qaytish qiymati ham bitta bo'ladi.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // XAVFSIZLIK: `end` ning char chegarasida ekanligini tekshiring,
            // va biz xavfsiz ma'lumotnomaga o'tmoqdamiz, shuning uchun qaytish qiymati ham bitta bo'ladi.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // XAVFSIZLIK: `end` ning char chegarasida ekanligini tekshiring,
            // va biz xavfsiz ma'lumotnomaga o'tmoqdamiz, shuning uchun qaytish qiymati ham bitta bo'ladi.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Sintaksis `&self[begin ..]` yoki `&mut self[begin ..]` bilan substring tilimlashni amalga oshiradi.
///
/// Bayt oralig'idan berilgan qatorning bir qismini qaytaradi [`begin`, `len`)."&Self" bilan teng [start ..
/// len] `yoki`&mut mut [boshlash ..
/// len]`.
///
/// Ushbu operatsiya *O*(1).
///
/// 1.20.0 dan oldin ushbu indekslash operatsiyalari to'g'ridan-to'g'ri `Index` va `IndexMut` dasturlari tomonidan qo'llab-quvvatlangan.
///
/// # Panics
///
/// Agar Panics, agar `begin` belgining boshlang'ich bayt ofsetiga ishora qilmasa (`is_char_boundary` tomonidan belgilangan) yoki `begin > len` bo'lsa.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // XAVFSIZLIK: `start` ning char chegarasida ekanligini tekshiring,
            // va biz xavfsiz ma'lumotnomaga o'tmoqdamiz, shuning uchun qaytish qiymati ham bitta bo'ladi.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // XAVFSIZLIK: `start` ning char chegarasida ekanligini tekshiring,
            // va biz xavfsiz ma'lumotnomaga o'tmoqdamiz, shuning uchun qaytish qiymati ham bitta bo'ladi.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` ning `slice` chegaralarida bo'lishiga kafolat beradi
        // bu `add` uchun barcha shartlarni qondiradi.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // XAVFSIZLIK: `get_unchecked` bilan bir xil.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // XAVFSIZLIK: `start` ning char chegarasida ekanligini tekshiring,
            // va biz xavfsiz ma'lumotnomaga o'tmoqdamiz, shuning uchun qaytish qiymati ham bitta bo'ladi.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Sintaksis `&self[begin ..= end]` yoki `&mut self[begin ..= end]` bilan substring tilimlashni amalga oshiradi.
///
/// [`begin`, `end`] bayt oralig'idan berilgan satrning bir bo'lagini qaytaradi.`&self [begin .. end + 1]` yoki `&mut self[begin .. end + 1]` ga teng, faqat `end` `usize` uchun maksimal qiymatga ega bo'lsa.
///
/// Ushbu operatsiya *O*(1).
///
/// # Panics
///
/// Panics, agar `begin` belgining boshlang'ich bayt ofsetiga ishora qilmasa (`is_char_boundary` tomonidan belgilanadigan bo'lsa), agar `end` belgining oxiri baytini almashtirishga ishora qilmasa (`end + 1` boshlang'ich bayt ofset yoki `len` ga teng bo'lsa), agar `begin > end` yoki agar `end >= len` bo'lsa.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `get_unchecked` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `get_unchecked_mut` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Sintaksis `&self[..= end]` yoki `&mut self[..= end]` bilan substring tilimlashni amalga oshiradi.
///
/// [0, `end`] bayt oralig'idan berilgan satrning bir qismini qaytaradi.
/// `&self [0 .. end + 1]` ga teng, faqat `end` `usize` uchun maksimal qiymatga ega bo'lsa.
///
/// Ushbu operatsiya *O*(1).
///
/// # Panics
///
/// Agar Panics, agar `end` belgining oxiri baytni almashtirishga ishora qilmasa (`end + 1` yoki `is_char_boundary` tomonidan belgilangan boshlang'ich bayt ofsetidir yoki `len` ga teng) yoki `end >= len` bo'lsa.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `get_unchecked` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `get_unchecked_mut` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Ipdagi qiymatni tahlil qiling
///
/// "FromStr" ning [`from_str`] usuli ko'pincha ['str`] ning [`parse`] usuli orqali bevosita ishlatiladi.
/// Misollar uchun ["tahlil qilish"] ning hujjatlariga qarang.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` umr bo'yi parametrga ega emas va shuning uchun siz faqat o'zlari uchun umr bo'yi parametrlarni o'z ichiga olmagan turlarni ajratishingiz mumkin.
///
/// Boshqacha qilib aytganda, siz `i32` ni `FromStr` bilan ajratishingiz mumkin, lekin `&i32` emas.
/// Siz tarkibida `i32` bo'lgan tuzilmani ajrata olasiz, lekin `&i32` tarkibiga kirmaydi.
///
/// # Examples
///
/// `FromStr` ning `Point` turiga misol sifatida asoslanishi:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Bunga bog'liq xato, uni tahlil qilishdan qaytarish mumkin.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Ushbu turdagi qiymatni qaytarish uchun `s` qatorini ajratadi.
    ///
    /// Agar ajralish muvaffaqiyatli bo'lsa, [`Ok`] ichidagi qiymatni qaytaring, aks holda satr noto'g'ri formatlangan bo'lsa, ichki [`Err`] uchun xos bo'lgan xatoni qaytaradi.
    /// Xato turi trait dasturiga xosdir.
    ///
    /// # Examples
    ///
    /// `FromStr` ni amalga oshiradigan [`i32`] bilan asosiy foydalanish:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// `bool` ni mag'lubiyatdan ajrating.
    ///
    /// `Result<bool, ParseBoolError>` hosil qiladi, chunki `s` aslida ajratib bo'lmaydigan yoki bo'lmasligi mumkin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// E'tibor bering, ko'p hollarda `str` da `.parse()` usuli to'g'ri keladi.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}