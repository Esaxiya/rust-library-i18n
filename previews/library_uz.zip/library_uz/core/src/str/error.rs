//! utf8 xato turini belgilaydi.

use crate::fmt;

/// [`u8`] ketma-ketligini mag'lubiyat sifatida izohlashga urinishda yuzaga kelishi mumkin bo'lgan xatolar.
///
/// Shunday qilib, `from_utf8` funktsiyalari oilasi va [`String`] va [`&str`] ning funktsiyalari, masalan, ushbu xatodan foydalanadi.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Ushbu xato turidagi usullardan, uyali xotirani ajratmasdan, `String::from_utf8_lossy` ga o'xshash funktsiyalarni yaratish uchun foydalanish mumkin:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Yaroqli UTF-8 tekshirilgan berilgan qatordagi indeksni qaytaradi.
    ///
    /// Bu `from_utf8(&input[..index])` `Ok(_)` ni qaytaradigan maksimal indeks.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// use std::str;
    ///
    /// // ba'zi bir noto'g'ri baytlar, vector da
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Utf8Error-ni qaytaradi
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // ikkinchi bayt bu erda yaroqsiz
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Xato haqida ko'proq ma'lumot beradi:
    ///
    /// * `None`: kirishning oxiri kutilmaganda erishildi.
    ///   `self.valid_up_to()` kirish oxiridan 1 dan 3 baytgacha.
    ///   Agar bayt oqimi (masalan, fayl yoki tarmoq rozetkasi) bosqichma-bosqich dekodlanayotgan bo'lsa, bu UTF-8 bayt ketma-ketligi bir nechta qismni qamrab oladigan haqiqiy `char` bo'lishi mumkin.
    ///
    ///
    /// * `Some(len)`: kutilmagan baytga duch keldi.
    ///   Taqdim etilgan uzunlik, `valid_up_to()` tomonidan berilgan indeksdan boshlanadigan yaroqsiz baytlar ketma-ketligi.
    ///   Dekodlash ushbu ketma-ketlikdan keyin ([`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] qo'shilgandan keyin) yo'qotilgan dekodlashda davom etishi kerak.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// `bool`-ni [`from_str`] yordamida tahlil qilishda xatolik yuz berdi
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}