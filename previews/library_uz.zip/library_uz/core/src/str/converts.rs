//! Bayt tilimidan `str` yaratish usullari.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Bir qism baytni mag'lubiyatga aylantiradi.
///
/// ([`&str`]) qatorli bo'lagi ([`u8`]) baytlardan va ([`&[u8]`][byteslice]) bayt bo'laklari baytlardan qilingan, shuning uchun bu funktsiya ikkalasini o'zgartiradi.
/// Hamma bayt bo'laklari ham mag'lubiyatga to'g'ri kelmaydi, ammo: [`&str`] uning haqiqiyligini talab qiladi UTF-8.
/// `from_utf8()` baytlarning UTF-8 haqiqiyligini tekshirish uchun tekshiradi va keyin konvertatsiya qiladi.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Agar siz bayt bo'limi UTF-8 haqiqiyligiga ishonchingiz komil bo'lsa va siz haqiqiylikni tekshirish uchun ortiqcha xarajatlarni talab qilmoqchi bo'lmasangiz, ushbu funktsiyaning [`from_utf8_unchecked`] xavfli versiyasi mavjud, u xuddi shunday xatti-harakatga ega, ammo chekni o'tkazib yuboradi.
///
///
/// Agar sizga `&str` o'rniga `String` kerak bo'lsa, [`String::from_utf8`][string] ni ko'rib chiqing.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Agar siz `[u8; N]` ni stack-ajratishingiz va undan [`&[u8]`][byteslice] olishingiz mumkinligi sababli, bu funktsiya stack-stringga ega bo'lishning bir usuli hisoblanadi.Quyidagi misollar bo'limida bunga misol keltirilgan.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Agar tilim UTF-8 bo'lmasa, taqdim etilgan tilim nima uchun UTF-8 emasligi haqidagi tavsif bilan `Err`-ni qaytaradi.
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::str;
///
/// // ba'zi baytlar, vector da
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Biz ushbu baytlarning haqiqiyligini bilamiz, shuning uchun faqat `unwrap()` dan foydalaning.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Noto'g'ri baytlar:
///
/// ```
/// use std::str;
///
/// // ba'zi bir noto'g'ri baytlar, vector da
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Qaytish mumkin bo'lgan xato turlari haqida ko'proq ma'lumot olish uchun [`Utf8Error`] uchun hujjatlarni ko'rib chiqing.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // bir necha bayt, stekka ajratilgan qatorda
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Biz ushbu baytlarning haqiqiyligini bilamiz, shuning uchun faqat `unwrap()` dan foydalaning.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // XAVFSIZLIK: Shunchaki tekshiruv o'tkazildi.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// O'zgaruvchan bayt bo'linmasini o'zgaruvchan mag'lubiyatga aylantiradi.
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" o'zgaruvchan vector sifatida
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Ushbu baytlar haqiqiyligini bilganimiz uchun biz `unwrap()` dan foydalanishimiz mumkin
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Noto'g'ri baytlar:
///
/// ```
/// use std::str;
///
/// // O'zgaruvchan vector-dagi ba'zi noto'g'ri baytlar
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Qaytish mumkin bo'lgan xato turlari haqida ko'proq ma'lumot olish uchun [`Utf8Error`] uchun hujjatlarni ko'rib chiqing.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // XAVFSIZLIK: Shunchaki tekshiruv o'tkazildi.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Satrning yaroqli UTF-8 mavjudligini tekshirmasdan bayt tilimini satr tilimiga o'zgartiradi.
///
/// Qo'shimcha ma'lumot uchun [`from_utf8`] xavfsiz versiyasini ko'ring.
///
/// # Safety
///
/// Ushbu funktsiya xavfli emas, chunki unga uzatilgan baytlarning UTF-8 haqiqiyligini tekshirmaydi.
/// Agar ushbu cheklov buzilgan bo'lsa, aniqlanmagan xatti-harakatlar paydo bo'ladi, chunki qolgan Rust ['&str`]' lar UTF-8 haqiqiyligini taxmin qiladi.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::str;
///
/// // ba'zi baytlar, vector da
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `v` baytlari UTF-8 haqiqiyligiga kafolat berishi kerak.
    // Xuddi shu tartibga ega bo'lgan `&str` va `&[u8]`-larga tayanadi.
    unsafe { mem::transmute(v) }
}

/// Satrning yaroqli UTF-8 mavjudligini tekshirmasdan bayt tilimini mag'lubiyatga aylantiradi;o'zgaruvchan versiya.
///
///
/// Qo'shimcha ma'lumot uchun [`from_utf8_unchecked()`] o'zgarmas versiyasini ko'ring.
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `v` baytlariga kafolat berishi kerak
    // haqiqiy UTF-8, shuning uchun `*mut str`-ga o'tish xavfsizdir.
    // Bundan tashqari, ko'rsatgichni ajratish xavfsizdir, chunki bu ko'rsatgich yozuvlar uchun yaroqliligi kafolatlangan ma'lumotnomadan kelib chiqadi.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}