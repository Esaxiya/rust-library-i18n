//! Turlar orasidagi konversiyalar uchun Traits.
//!
//! Ushbu moduldagi traits bir turdan ikkinchi turga o'tish usulini taqdim etadi.
//! Har bir trait boshqa maqsadga xizmat qiladi:
//!
//! - [`AsRef`] trait-ni mos yozuvlar-ma'lumotlarga arzon konvertatsiya qilish uchun amalga oshiring
//! - O'zgaruvchan o'zgaruvchan va o'zgaruvchan konversiyalar uchun [`AsMut`] trait-ni amalga oshiring
//! - [`From`] trait-ni qiymatdan qiymatga o'tkazishni iste'mol qilish uchun amalga oshiring
//! - [`Into`] trait-ni joriy crate dan tashqaridagi turlarga qiymatdan qiymatga o'tkazishni iste'mol qilish uchun qo'llang.
//! - [`TryFrom`] va [`TryInto`] traits o'zlarini [`From`] va [`Into`] kabi tutishadi, lekin konvertatsiya amalga oshmay qolganda amalga oshirilishi kerak.
//!
//! Ushbu moduldagi traits odatda umumiy funktsiyalar uchun trait bounds sifatida ishlatiladi, chunki bir nechta turdagi argumentlarni qo'llab-quvvatlaydi.Misollar uchun har bir trait hujjatiga qarang.
//!
//! Kutubxona muallifi sifatida siz har doim [`Into<U>`][`Into`] yoki [`TryInto<U>`][`TryInto`] o'rniga [`From<T>`][`From`] yoki [`TryFrom<T>`][`TryFrom`] dasturini afzal ko'rishingiz kerak, chunki [`From`] va [`TryFrom`] ko'proq moslashuvchanlikni ta'minlaydi va standart kutubxonada adyol tatbiq etilishi tufayli teng ravishda [`Into`] yoki [`TryInto`] dasturlarini taklif qiladi.
//! Rust 1.41 dan oldingi versiyani nishonga olayotganda, [`Into`] yoki [`TryInto`] ni joriy crate tashqarisidagi turga o'tkazishda to'g'ridan-to'g'ri amalga oshirish kerak bo'lishi mumkin.
//!
//! # Umumiy dasturlar
//!
//! - [`AsRef`] va ichki turi mos yozuvlar bo'lsa, [`AsMut`] avtomatik o'chirib qo'yish
//! - [`From`]`<U>T uchun</u> [`Into`] ' <U>ni anglatadi</u><T><U>U` uchun</u>
//! - T`<U>uchun [`TryFrom`]" ["TryInto`]"ni nazarda tutadi</u><T><U>U` uchun</u>
//! - [`From`] va [`Into`] reflektivdir, demak, barcha turdagi `into` o'zlari va `from` o'zlari mumkin
//!
//! Foydalanish misollari uchun har bir trait-ga qarang.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Identifikatsiya funktsiyasi.
///
/// Ushbu funktsiya haqida ikkita narsani ta'kidlash muhim:
///
/// - Bu har doim ham `|x| x` kabi yopilishga teng kelmaydi, chunki yopilish `x` ni boshqa turga majbur qilishi mumkin.
///
/// - Bu funktsiyaga o'tgan `x` kiritishni harakatga keltiradi.
///
/// Kirishni qaytaradigan funktsiyaga ega bo'lish g'alati tuyulishi mumkin bo'lsa-da, ba'zi qiziqarli narsalar mavjud.
///
///
/// # Examples
///
/// Boshqa, qiziqarli funktsiyalar ketma-ketligida hech narsa qilmaslik uchun `identity`-dan foydalanish:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Keling, birini qo'shish qiziqarli funktsiya ekanligi haqida tasavvur qilaylik.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity`-ni shartli ravishda "do nothing" asosiy ishi sifatida ishlatish:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Ko'proq qiziqarli narsalar qiling ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` iteratorining `Some` variantlarini saqlab qolish uchun `identity` dan foydalanish:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Malumotdan ma'lumotga arzon konvertatsiya qilish uchun foydalaniladi.
///
/// Ushbu trait o'zgaruvchan havolalar o'rtasida konvertatsiya qilish uchun ishlatiladigan [`AsMut`] ga o'xshaydi.
/// Agar sizga qimmat konvertatsiya qilish kerak bo'lsa, [`From`] ni `&T` turi bilan amalga oshirish yoki maxsus funktsiyani yozish yaxshiroqdir.
///
/// `AsRef` [`Borrow`] bilan bir xil imzoga ega, ammo [`Borrow`] bir nechta jihatlari bilan farq qiladi:
///
/// - `AsRef`-dan farqli o'laroq, [`Borrow`] har qanday `T` uchun adyol impl-ga ega va mos yozuvlar yoki qiymatlarni qabul qilish uchun ishlatilishi mumkin.
/// - [`Borrow`] shuningdek, qarz qiymati uchun [`Hash`], [`Eq`] va [`Ord`] tegishli qiymatga teng bo'lishini talab qiladi.
/// Shu sababli, agar siz faqat bitta strukturaning maydonini qarz olishni istasangiz, siz `AsRef` ni amalga oshirishingiz mumkin, ammo [`Borrow`] emas.
///
/// **Note: Ushbu trait ishlamay qolmasligi kerak **.Agar konversiya bajarilmasa, [`Option<T>`] yoki [`Result<T, E>`] ni qaytaradigan maxsus usuldan foydalaning.
///
/// # Umumiy dasturlar
///
/// - `AsRef` agar ichki turi mos yozuvlar yoki o'zgarishi mumkin bo'lgan ma'lumot bo'lsa (masalan:) `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds-dan foydalanib, biz belgilangan `T` turiga o'tkazilishi mumkin bo'lgan har xil turdagi argumentlarni qabul qilishimiz mumkin.
///
/// Masalan: `AsRef<str>`-ni qabul qiladigan umumiy funktsiyani yaratish orqali biz [`&str`]-ga aylantirilishi mumkin bo'lgan barcha murojaatlarni argument sifatida qabul qilmoqchimiz.
/// [`String`] va [`&str`] ikkalasi ham `AsRef<str>`-ni qo'llaganligi sababli, biz ikkalasini ham kirish argumenti sifatida qabul qilishimiz mumkin.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Konversiyani amalga oshiradi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// O'zgaruvchan va o'zgaruvchan mos yozuvlarni konvertatsiya qilish uchun foydalaniladi.
///
/// Ushbu trait [`AsRef`] ga o'xshaydi, lekin o'zgaruvchan havolalar o'rtasida konvertatsiya qilish uchun ishlatiladi.
/// Agar sizga qimmat konvertatsiya qilish kerak bo'lsa, [`From`] ni `&mut T` turi bilan amalga oshirish yoki maxsus funktsiyani yozish yaxshiroqdir.
///
/// **Note: Ushbu trait ishlamay qolmasligi kerak **.Agar konversiya bajarilmasa, [`Option<T>`] yoki [`Result<T, E>`] ni qaytaradigan maxsus usuldan foydalaning.
///
/// # Umumiy dasturlar
///
/// - `AsMut` agar ichki turi o'zgarishi mumkin bo'lgan ma'lumot bo'lsa (masalan:) `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Umumiy funktsiya uchun trait bound sifatida `AsMut` dan foydalanib, biz `&mut T` turiga o'tkazilishi mumkin bo'lgan barcha o'zgaruvchan havolalarni qabul qilishimiz mumkin.
/// [`Box<T>`] `AsMut<T>`-ni amalga oshirganligi sababli, biz `&mut u64`-ga o'tkazilishi mumkin bo'lgan barcha argumentlarni qabul qiladigan `add_one` funktsiyasini yozishimiz mumkin.
/// [`Box<T>`] `AsMut<T>` ni qo'llaganligi sababli, `add_one` `&mut Box<u64>` tipidagi argumentlarni ham qabul qiladi:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Konversiyani amalga oshiradi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Kirish qiymatini iste'mol qiladigan qiymatdan qiymatga o'tkazish.[`From`] ning teskarisi.
///
/// [`Into`] ni amalga oshirishdan qochish va uning o'rniga [`From`] ni qo'llash kerak.
/// [`From`] dasturini avtomatik ravishda standart kutubxonada adyolga tatbiq etish tufayli [`Into`] dasturini taqdim etadi.
///
/// Umumiy funktsiyada trait bounds-ni belgilashda [`Into`]-dan [`From`]-dan foydalanishni afzal ko'ring, faqat [`Into`]-ni amalga oshiradigan turlardan ham foydalanish mumkin.
///
/// **Note: Ushbu trait ishlamay qolmasligi kerak **.Agar konversiya bajarilmasa, [`TryInto`]-dan foydalaning.
///
/// # Umumiy dasturlar
///
/// - ["Kimdan"]<T>chunki U` `Into<U> for T` ni nazarda tutadi
/// - [`Into`] refleksli, ya'ni `Into<T> for T` amalga oshirilishini anglatadi
///
/// # Rust ning eski versiyalarida tashqi turlarga o'tish uchun [`Into`]-ni amalga oshirish
///
/// Rust 1.41-dan oldin, agar maqsad turi hozirgi crate tarkibiga kirmasa, siz [`From`]-ni to'g'ridan-to'g'ri amalga oshira olmaysiz.
/// Masalan, ushbu kodni oling:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Bu tilning eski versiyalarida tuzilmaydi, chunki Rust ning etim qoidalari biroz qattiqroq edi.
/// Buni chetlab o'tish uchun siz [`Into`]-ni to'g'ridan-to'g'ri amalga oshirishingiz mumkin:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Shuni anglash kerakki, [`Into`] [`From`] dasturini ta'minlamaydi ([`From`] [`Into`] bilan bo'lgani kabi).
/// Shuning uchun, har doim [`From`]-ni amalga oshirishga urinib ko'rishingiz kerak, keyin [`From`] amalga oshirilmasa, [`Into`]-ga qaytishingiz kerak.
///
/// # Examples
///
/// [`String`] amalga oshiradi [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Umumiy funktsiyani belgilangan `T` turiga o'tkazilishi mumkin bo'lgan barcha argumentlarni qabul qilishini xohlashimizni bildirish uchun biz [`Into`]"ning trait bound dan foydalanishimiz mumkin.<T>".
///
/// Masalan: `is_hello` funktsiyasi [`Vec`]`<`[`u8`] `>` ga aylantirilishi mumkin bo'lgan barcha argumentlarni oladi.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Konversiyani amalga oshiradi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Kirish qiymatini iste'mol qilishda qiymatdan qiymatga o'tkazishni amalga oshirish uchun foydalaniladi.Bu [`Into`] ning o'zaro bog'liqligi.
///
/// X0Xni [`Into`] o'rniga har doim amalga oshirishni afzal ko'rish kerak, chunki `From` dasturini avtomatik ravishda standart kutubxonada adyolni tatbiq etish tufayli [`Into`] bajarilishini ta'minlaydi.
///
///
/// [`Into`]-ni faqat Rust 1.41-dan oldingi versiyaga yo'naltirish va joriy crate tashqarisidagi turga aylantirish paytida amalga oshiring.
/// `From` Rust-ning etim qoidalari tufayli ushbu turdagi konversiyalarni avvalgi versiyalarida qila olmadi.
/// Qo'shimcha ma'lumot uchun [`Into`]-ga qarang.
///
/// Umumiy funktsiyada trait bounds-ni ko'rsatishda [`Into`]-dan `From`-dan foydalanishni afzal biling.
/// Shunday qilib, to'g'ridan-to'g'ri [`Into`]-ni amalga oshiradigan turlardan argument sifatida ham foydalanish mumkin.
///
/// `From` xatolarni ko'rib chiqishda ham juda foydali.Qobiliyatsiz funktsiyani qurishda, qaytish turi odatda `Result<T, E>` shaklida bo'ladi.
/// `From` trait funktsiyasi bir nechta xato turlarini qamrab oladigan bitta xato turini qaytarishiga imkon berish orqali xatolarni ko'rib chiqishni soddalashtiradi.Qo'shimcha ma'lumot uchun "Examples" bo'limiga va [the book][book] ga qarang.
///
/// **Note: Ushbu trait ishlamay qolmasligi kerak **.Agar konversiya bajarilmasa, [`TryFrom`]-dan foydalaning.
///
/// # Umumiy dasturlar
///
/// - `From<T> for U` T`<U>uchun</u> ["Into`]" ni nazarda tutadi
/// - `From` refleksli, ya'ni `From<T> for T` amalga oshirilishini anglatadi
///
/// # Examples
///
/// [`String`] `From<&str>`-ni amalga oshiradi:
///
/// `&str`-dan String-ga aniq konvertatsiya qilish quyidagicha amalga oshiriladi:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Xato bilan ishlashni amalga oshirayotganda, `From`-ni o'zingizning xato turingizga moslashtirish foydalidir.
/// Asosiy xato turlarini asosiy xato turini o'z ichiga olgan odatiy xato turiga aylantirish orqali biz asosiy sabab haqida ma'lumot yo'qotmasdan bitta xato turini qaytarishimiz mumkin.
/// '?' operatori `From` ni amalga oshirishda avtomatik ravishda ta'minlanadigan `Into<CliError>::into`-ga qo'ng'iroq qilib, asosiy xato turini avtomatik ravishda bizning odatiy xato turimizga o'zgartiradi.
/// Keyin kompilyator `Into` dasturining qaysi dasturidan foydalanish kerakligini belgilaydi.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Konversiyani amalga oshiradi.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// `self` ni iste'mol qiladigan, qimmat bo'lishi yoki bo'lmasligi mumkin bo'lgan konvertatsiya qilishga urinish.
///
/// Kutubxona mualliflari odatda ushbu trait-ni to'g'ridan-to'g'ri amalga oshirmasliklari kerak, lekin [`TryFrom`] trait-ni amalga oshirishni afzal ko'rishlari kerak, bu esa ko'proq moslashuvchanlikni taklif qiladi va standart kutubxonada adyol yordamida `TryInto` dasturini bepul taqdim etadi.
/// Bu haqda ko'proq ma'lumot olish uchun [`Into`] hujjatiga qarang.
///
/// # `TryInto`-ni amalga oshirish
///
/// Bu [`Into`]-ni amalga oshirish bilan bir xil cheklovlar va mulohazalarga duch keladi, batafsil ma'lumot uchun u erga qarang.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Konvertatsiya qilishda xatolik yuz berganda qaytarilgan tur.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Konversiyani amalga oshiradi.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Ba'zi hollarda nazorat ostida ishlamay qolishi mumkin bo'lgan oddiy va xavfsiz turdagi konversiyalar.Bu [`TryInto`] ning o'zaro bog'liqligi.
///
/// Bu juda ozgina muvaffaqiyatga erishish mumkin bo'lgan, lekin maxsus ishlov berishga muhtoj bo'lishi mumkin bo'lgan turdagi konversiyani amalga oshirayotganda foydalidir.
/// Masalan, [`i64`] ni [`From`] trait yordamida [`i32`] ga aylantirishning imkoni yo'q, chunki [`i64`] tarkibida [`i32`] ifodalay olmaydigan qiymat bo'lishi mumkin va shuning uchun konvertatsiya ma'lumotlarni yo'qotadi.
///
/// Buni [`i64`]-ni [`i32`]-ga qisqartirish (asosan [[i64`] ning qiymati [`i32::MAX`] modulini berish) yoki [`i32::MAX`]-ni qaytarish yoki boshqa usul bilan hal qilish mumkin.
/// [`From`] trait mukammal konvertatsiya qilish uchun mo'ljallangan, shuning uchun `TryFrom` trait dasturchiga tip konvertatsiyasi qachon yomonlashishi mumkinligi haqida xabar beradi va ularga qanday ishlov berish to'g'risida qaror qabul qilishga imkon beradi.
///
/// # Umumiy dasturlar
///
/// - `TryFrom<T> for U` T`<U>uchun</u> [`TryInto`] 'ni nazarda tutadi
/// - [`try_from`] refleksli, ya'ni `TryFrom<T> for T` amalga oshiriladi va ishlamay qolmaydi degan ma'noni anglatadi-`T` tipidagi qiymatga `T::try_from()` ni chaqirish uchun tegishli `Error` turi [`Infallible`].
/// [`!`] turi barqarorlashtirilganda [`Infallible`] va [`!`] teng bo'ladi.
///
/// `TryFrom<T>` quyidagicha amalga oshirilishi mumkin:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Ta'riflanganidek, [`i32`] "TryFrom <` [`i64`]">`ni amalga oshiradi:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // `big_number`-ni jimgina qisqartiradi, aniqlangandan keyin kesilgan joyni aniqlash va unga ishlov berishni talab qiladi.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // `big_number` `i32` ga sig`maydigan darajada katta bo`lganligi sababli xatolikni qaytaradi.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` qaytaradi.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Konvertatsiya qilishda xatolik yuz berganda qaytarilgan tur.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Konversiyani amalga oshiradi.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// UMUMIY IMPLS
////////////////////////////////////////////////////////////////////////////////

// Asansörler kabi
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut dan yuqori ko'targichlar sifatida
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): yuqoridagi fikrlarni&/&mut uchun quyidagi umumiy bilan almashtiring:
// // Deref ustidan ko'tarilganidek
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut orqali ko'tariladi
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut uchun yuqoridagi so'zni quyidagi umumiy bilan almashtiring:
// // AsMut DerefMut-ni ko'taradi
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Into ma'nosini anglatadi
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (va shunday qilib Into) refleksivdir
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Barqarorlik haqida eslatma:** Ushbu tushuncha hali mavjud emas, lekin biz uni future-ga qo'shish uchun "reserving space" miz.
/// Tafsilotlar uchun [rust-lang/rust#64715][#64715]-ga qarang.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): o'rniga printsipial tuzatishni amalga oshiring.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom TryInto-ni nazarda tutadi
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Noto'g'ri konvertatsiya qilish semantik jihatdan odam yashamaydigan xato turiga ega bo'lgan noto'g'ri konversiyaga tengdir.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETON IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// XATOSIZ XATO TURI
////////////////////////////////////////////////////////////////////////////////

/// Hech qachon bo'lishi mumkin bo'lmagan xatolar uchun xato turi.
///
/// Ushbu enumning varianti bo'lmaganligi sababli, ushbu turdagi qiymat hech qachon mavjud bo'lmaydi.
/// Bu [`Result`] dan foydalanadigan va xato turini parametrlashtiradigan umumiy API uchun foydali bo'lishi mumkin, natijada har doim [`Ok`] bo'ladi.
///
/// Masalan, [`TryFrom`] trait ([`Result`] ni qaytaradigan konvertatsiya) teskari [`Into`] bajarilishi mavjud bo'lgan barcha turlari uchun adyol dasturiga ega.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future mosligi
///
/// Ushbu enum [the `!`“never”type][never] bilan bir xil rol o'ynaydi, bu Rust versiyasida beqaror.
/// `!` stabillashganida, biz unga `Infallible` turini taxallus qilishni rejalashtirmoqdamiz:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Va oxir-oqibat `Infallible` eskirgan.
///
/// Ammo `!` sintaksisini `!` to'laqonli tur sifatida barqarorlashtirishdan oldin foydalanish mumkin bo'lgan bitta holat mavjud: funktsiya qaytish turi holatida.
/// Xususan, ikki xil funktsiyani ko'rsatgich turlari uchun amalga oshirish mumkin:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` enum bo'lsa, ushbu kod amal qiladi.
/// Ammo `Infallible` never type uchun taxallusga aylanganda, ikkita "impl`" bir-birining ustiga chiqa boshlaydi va shu sababli tilning trait muvofiqligi qoidalari bilan taqiqlanadi.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}