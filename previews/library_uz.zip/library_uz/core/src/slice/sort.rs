//! Dilimlarni saralash
//!
//! Ushbu modulda Orson Pitersning namunalarini mag'lubiyatga uchratgan tezkor kontserti asosida saralash algoritmi mavjud: <https://github.com/orlp/pdqsort>
//!
//!
//! Barqaror saralash libcore bilan mos keladi, chunki u bizning barqaror saralash dasturimizdan farqli o'laroq, xotirani ajratmaydi.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Yiqilganda, `src` dan `dest` ga nusxa olinadi.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // XAVFSIZLIK: Bu yordamchi sinf.
        //          Iltimos, to'g'riligi uchun uning ishlatilishiga murojaat qiling.
        //          `src` va `dst` `ptr::copy_nonoverlapping` talablariga binoan bir-birining ustiga chiqmasligiga ishonch hosil qilish kerak.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Katta yoki teng elementga duch kelguncha birinchi elementni o'ngga siljitadi.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // XAVFSIZLIK: Quyidagi xavfli operatsiyalar majburiy tekshiruvsiz indekslashni o'z ichiga oladi (`get_unchecked` va `get_unchecked_mut`)
    // va (`ptr::copy_nonoverlapping`) xotirasini nusxalash.
    //
    // a.Indekslash:
    //  1. Biz massivning hajmini>=2 ga tekshirdik.
    //  2. Biz bajaradigan barcha indekslar har doim eng ko'p {0 <= index < len} orasida bo'ladi.
    //
    // b.Xotirani nusxalash
    //  1. Biz haqiqiyligi kafolatlangan ma'lumotnomalarga ko'rsatgichlar olamiz.
    //  2. Ular bir-birining ustiga chiqa olmaydi, chunki biz tilimning indekslari bo'yicha ko'rsatkichlarni olamiz.
    //     `i` va `i-1`.
    //  3. Agar tilim to'g'ri tekislangan bo'lsa, elementlar to'g'ri hizalanadi.
    //     Tilning to'g'ri tekislanganligini tekshirish qo'ng'iroq qiluvchining vazifasi.
    //
    // Batafsil ma'lumot uchun quyidagi izohlarga qarang.
    unsafe {
        // Agar dastlabki ikkita element tartibsiz bo'lsa ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Birinchi elementni stekka ajratilgan o'zgaruvchiga o'qing.
            // Agar quyidagi taqqoslash operatsiyasi panics bo'lsa, `hole` tushadi va avtomatik ravishda elementni tilimga yozadi.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // "I`-chi" elementni chapga bir joyga siljiting, shu bilan teshikni o'ng tomonga siljiting.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` tushadi va shu tariqa `tmp` ni `v` dagi qolgan teshikka ko'chiradi.
        }
    }
}

/// Oxirgi elementni kichikroq yoki teng elementga duch kelguncha chapga siljitadi.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // XAVFSIZLIK: Quyidagi xavfli operatsiyalar majburiy tekshiruvsiz indekslashni o'z ichiga oladi (`get_unchecked` va `get_unchecked_mut`)
    // va (`ptr::copy_nonoverlapping`) xotirasini nusxalash.
    //
    // a.Indekslash:
    //  1. Biz massivning hajmini>=2 ga tekshirdik.
    //  2. Biz bajaradigan barcha indekslar har doim eng ko'p `0 <= index < len-1` orasida bo'ladi.
    //
    // b.Xotirani nusxalash
    //  1. Biz haqiqiyligi kafolatlangan ma'lumotnomalarga ko'rsatgichlar olamiz.
    //  2. Ular bir-birining ustiga chiqa olmaydi, chunki biz tilimning indekslari bo'yicha ko'rsatkichlarni olamiz.
    //     `i` va `i+1`.
    //  3. Agar tilim to'g'ri tekislangan bo'lsa, elementlar to'g'ri hizalanadi.
    //     Tilning to'g'ri tekislanganligini tekshirish qo'ng'iroq qiluvchining vazifasi.
    //
    // Batafsil ma'lumot uchun quyidagi izohlarga qarang.
    unsafe {
        // Agar oxirgi ikkita element tartibsiz bo'lsa ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Oxirgi elementni stekka ajratilgan o'zgaruvchiga o'qing.
            // Agar quyidagi taqqoslash operatsiyasi panics bo'lsa, `hole` tushadi va avtomatik ravishda elementni tilimga yozadi.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // "I`-" elementni bir joyga o'ngga siljiting, shu bilan teshikni chapga siljiting.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` tushadi va shu tariqa `tmp` ni `v` dagi qolgan teshikka ko'chiradi.
        }
    }
}

/// Tilni qisman tartibsiz bo'lgan bir nechta elementlarni almashtirish orqali saralash.
///
/// Agar tilim oxirida saralangan bo'lsa, `true`-ni qaytaradi.Ushbu funktsiya *O*(*n*) eng yomon holat.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Ko'chib o'tadigan qo'shni tartibsiz juftlarning maksimal soni.
    const MAX_STEPS: usize = 5;
    // Agar tilim bundan qisqa bo'lsa, hech qanday elementni almashtirmang.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // XAVFSIZLIK: Biz allaqachon `i < len` bilan bog'langan tekshiruvni aniq amalga oshirdik.
        // Bizning keyingi indekslashimiz faqat `0 <= index < len` oralig'ida
        unsafe {
            // Tartibsiz elementlarning navbatdagi juftligini toping.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Biz tugadikmi?
        if i == len {
            return true;
        }

        // Elementlarni qisqa massivlarga o'tkazmang, bu ishlash narxiga ega.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Topilgan juft elementni almashtiring.Bu ularni to'g'ri tartibda joylashtiradi.
        v.swap(i - 1, i);

        // Kichikroq elementni chapga siljiting.
        shift_tail(&mut v[..i], is_less);
        // Katta elementni o'ngga siljiting.
        shift_head(&mut v[i..], is_less);
    }

    // Tilni cheklangan miqdordagi qadamlar bo'yicha saralashga muvaffaq bo'lmadi.
    false
}

/// Qo'shimchani tartiblash yordamida bo'lakni saralaydi, bu *O*(*n*^ 2) eng yomon holat.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// `v`-ni *O*(*n*\*log(* n*))-ning eng yomon holatini kafolatlaydigan "heapsort" yordamida saralash.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ushbu ikkilik uyma o'zgarmas `parent >= child` ni hurmat qiladi.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` bolalari:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Katta bolani tanlang.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Agar invariant `node` darajasida bo'lsa, to'xtating.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // `node`-ni kattaroq bola bilan almashtiring, bir qadam pastga o'ting va elakdan o'tkazishda davom eting.
            v.swap(node, greater);
            node = greater;
        }
    };

    // To'pni chiziqli vaqt ichida yarating.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Uyumdan maksimal elementlarni oching.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` ni `pivot` dan kichik elementlarga ajratadi, so'ngra `pivot` dan katta yoki unga teng elementlar.
///
///
/// `pivot` dan kichik elementlar sonini qaytaradi.
///
/// Bo'linish operatsiyalari narxini minimallashtirish maqsadida blokirovka qilish yo'li bilan amalga oshiriladi.
/// Ushbu g'oya [BlockQuicksort][pdf] qog'ozida keltirilgan.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Odatda blokdagi elementlar soni.
    const BLOCK: usize = 128;

    // Bo'linish algoritmi quyidagi amallarni bajarilguncha takrorlaydi:
    //
    // 1. Burilishdan kattaroq yoki teng bo'lgan elementlarni aniqlash uchun chap tomondan blokni kuzatib boring.
    // 2. Burilishdan kichikroq elementlarni aniqlash uchun blokni o'ng tomondan kuzatib boring.
    // 3. Belgilangan elementlarni chap va o'ng tomon bilan almashtiring.
    //
    // Biz elementlar bloki uchun quyidagi o'zgaruvchilarni saqlaymiz:
    //
    // 1. `block` - Blokdagi elementlar soni.
    // 2. `start` - `offsets` qatoriga ko'rsatgichni boshlang.
    // 3. `end` - `offsets` qatoriga ko'rsatkichni tugatish.
    // 4. `ofsetlar, blok ichidagi tartibsiz elementlarning ko'rsatkichlari.

    // Chap tarafdagi joriy blok (`l` dan `l.add(block_l)`) gacha.
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // O'ng tarafdagi joriy blok (`r.sub(block_r)` to `r`) dan.
    // XAVFSIZLIK: .add() uchun hujjatlarda `vec.as_ptr().add(vec.len())` har doim xavfsiz ekanligi alohida ta'kidlangan
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Biz VLA-larni olganimizda, aksincha, bitta uzunlikdagi `min(v.len(), 2 * BLOCK) massivini yaratishga harakat qiling
    // `BLOCK` uzunlikdagi ikkita aniq o'lchamdagi massivlardan.VLA'lar kesh tejamkor bo'lishi mumkin.

    // `l` (inclusive) va `r` (exclusive) ko'rsatkichlari orasidagi elementlar sonini qaytaradi.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` va `r` juda yaqinlashganda biz bloklarni bloklarga ajratish bilan ish olib boramiz.
        // Keyin qolgan elementlarni o'rtada bo'lish uchun bir nechta tuzatish ishlarini qilamiz.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Qolgan elementlarning soni (hali ham burilish bilan taqqoslanmagan).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Blok o'lchamlarini chap va o'ng blok bir-birining ustiga chiqmasligi uchun sozlang, ammo qolgan bo'shliqni qoplash uchun to'liq tekislang.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // `block_l` elementlarini chap tomondan kuzatib boring.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // XAVFSIZLIK: Quyidagi xavfsizlik operatsiyalari `offset`-dan foydalanishni o'z ichiga oladi.
                //         Funktsiya talab qiladigan shartlarga muvofiq biz ularni qondiramiz, chunki:
                //         1. `offsets_l` stek-ajratilgan va shu bilan alohida ajratilgan ob'ekt hisoblanadi.
                //         2. `is_less` funktsiyasi `bool` ni qaytaradi.
                //            `bool`-ni quyish hech qachon `isize` ni to'ldirmaydi.
                //         3. Biz `block_l` ning `<= BLOCK` bo'lishiga kafolat berdik.
                //            Bundan tashqari, dastlab `end_l` to'plamda e'lon qilingan `offsets_` boshlang'ich ko'rsatkichiga o'rnatildi.
                //            Shunday qilib, biz bilamizki, hatto eng yomon holatda ham (`is_less` ning barcha chaqiruvlari noto'g'ri bo'ladi), biz faqat eng ko'pi bilan 1 bayt oxiridan o'tamiz.
                //        Bu erda yana bir xavfli operatsiya-bu `elem`-ni ajratish.
                //        Biroq, `elem` dastlab har doim amal qiladigan bo'lakning boshlanish ko'rsatkichi bo'lgan.
                unsafe {
                    // Tarmoqsiz taqqoslash.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // `block_r` elementlarini o'ng tomondan kuzatib boring.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // XAVFSIZLIK: Quyidagi xavfsizlik operatsiyalari `offset`-dan foydalanishni o'z ichiga oladi.
                //         Funktsiya talab qiladigan shartlarga muvofiq biz ularni qondiramiz, chunki:
                //         1. `offsets_r` stek-ajratilgan va shu bilan alohida ajratilgan ob'ekt hisoblanadi.
                //         2. `is_less` funktsiyasi `bool` ni qaytaradi.
                //            `bool`-ni quyish hech qachon `isize` ni to'ldirmaydi.
                //         3. Biz `block_r` ning `<= BLOCK` bo'lishiga kafolat berdik.
                //            Bundan tashqari, dastlab `end_r` to'plamda e'lon qilingan `offsets_` boshlang'ich ko'rsatkichiga o'rnatildi.
                //            Shunday qilib, biz bilamizki, hatto eng yomon holatda ham (`is_less` ning barcha chaqiruvlari to'g'ri keladi) biz faqat eng ko'pi bilan 1 bayt oxiridan o'tamiz.
                //        Bu erda yana bir xavfli operatsiya-bu `elem`-ni ajratish.
                //        Biroq, `elem` dastlab `1 *sizeof(T)` ni oxiriga etkazdi va biz unga kirishdan oldin uni `1* sizeof(T)` ga kamaytirdik.
                //        Bundan tashqari, `block_r` `BLOCK` dan kam deb tasdiqlangan va `elem` shuning uchun tilim boshiga ishora qiladi.
                unsafe {
                    // Tarmoqsiz taqqoslash.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Chap va o'ng tomonni almashtirish uchun buyurtma berilmagan elementlarning soni.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Bir vaqtning o'zida bitta juftlikni almashtirish o'rniga, tsiklli almashtirishni amalga oshirish samaraliroq.
            // Bu almashtirishga mutlaqo teng emas, lekin kamroq xotira operatsiyalari yordamida shunga o'xshash natijani keltirib chiqaradi.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Chap blokdagi barcha ishdan chiqqan elementlar ko'chirildi.Keyingi blokka o'ting.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // O'ng blokdagi barcha ishdan chiqqan elementlar ko'chirildi.Oldingi blokka o'tish.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Hozir ko'pi bitta blokda (chapda ham, o'ngda ham) tartibsiz elementlar bilan ko'chirilishi kerak.
    // Bunday qolgan elementlarni o'zlarining bloklari ichida oxirigacha siljitish mumkin.
    //

    if start_l < end_l {
        // Chap blok qoladi.
        // Qolgan tartibsiz elementlarini o'ta o'ng tomonga o'tkazing.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // To'g'ri blok qoladi.
        // Qolgan tartibsiz elementlarini o'ta chap tomonga o'tkazing.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Boshqa qiladigan ishimiz yo'q, ishimiz tugadi.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` ni `v[pivot]` dan kichik elementlarga ajratadi, so'ngra `v[pivot]` dan katta yoki unga teng elementlar.
///
///
/// Qatorni qaytaradi:
///
/// 1. `v[pivot]` dan kichik elementlar soni.
/// 2. To'g'ri, agar `v` allaqachon ajratilgan bo'lsa.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Pivotni tilim boshiga joylashtiring.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Effektivlik uchun stivni ajratilgan o'zgaruvchiga o'qing.
        // Agar quyidagi taqqoslash operatsiyasi panics bo'lsa, pivot avtomatik ravishda tilimga qaytarib yoziladi.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Tartibsiz elementlarning birinchi juftligini toping.
        let mut l = 0;
        let mut r = v.len();

        // XAVFSIZLIK: Quyidagi xavfsizlik, qatorni indekslashni o'z ichiga oladi.
        // Birinchisi uchun: biz allaqachon bu erda `l < r` yordamida chegaralarni tekshiramiz.
        // Ikkinchisi uchun: Dastlab bizda `l == 0` va `r == v.len()` mavjud va biz har bir indekslash jarayonida `l < r` ni tekshirdik.
        //                     Bu erdan biz bilamizki, `r` kamida `r == l` bo'lishi kerak, bu birinchisidan boshlab haqiqiyligini ko'rsatdi.
        unsafe {
            // Pivotdan katta yoki teng bo'lgan birinchi elementni toping.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Burilishdan kichikroq so'nggi elementni toping.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` doiradan chiqib ketadi va pivotni (bu stekka ajratilgan o'zgaruvchini) yana avval joylashgan bo'lakka yozadi.
        // Ushbu qadam xavfsizlikni ta'minlashda juda muhimdir!
        //
    };

    // Ikkala qism orasidagi burilishni joylashtiring.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` ni `v[pivot]` ga teng elementlarga ajratib, so'ngra `v[pivot]` dan katta elementlar.
///
/// Pivotga teng elementlar sonini qaytaradi.
/// `v`-da burilishdan kichikroq elementlar mavjud emas deb taxmin qilinadi.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Pivotni tilim boshiga joylashtiring.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Effektivlik uchun stivni ajratilgan o'zgaruvchiga o'qing.
    // Agar quyidagi taqqoslash operatsiyasi panics bo'lsa, pivot avtomatik ravishda tilimga qaytarib yoziladi.
    // XAVFSIZLIK: Bu erda ko'rsatgich to'g'ri, chunki u tilimga havola orqali olinadi.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Endi tilimni qismlarga bo'ling.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // XAVFSIZLIK: Quyidagi xavfsizlik, qatorni indekslashni o'z ichiga oladi.
        // Birinchisi uchun: biz allaqachon bu erda `l < r` yordamida chegaralarni tekshiramiz.
        // Ikkinchisi uchun: Dastlab bizda `l == 0` va `r == v.len()` mavjud va biz har bir indekslash jarayonida `l < r` ni tekshirdik.
        //                     Bu erdan biz bilamizki, `r` kamida `r == l` bo'lishi kerak, bu birinchisidan boshlab haqiqiyligini ko'rsatdi.
        unsafe {
            // Burilishdan kattaroq birinchi elementni toping.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Pivotga teng bo'lgan oxirgi elementni toping.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Biz tugadikmi?
            if l >= r {
                break;
            }

            // Topilgan buyurtma qilinmagan juftlikni almashtiring.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Biz burilishga teng `l` elementlarini topdik.Pivotning o'zi hisobiga 1 ni qo'shing.
    l + 1

    // `_pivot_guard` doiradan chiqib ketadi va pivotni (bu stekka ajratilgan o'zgaruvchini) yana avval joylashgan bo'lakka yozadi.
    // Ushbu qadam xavfsizlikni ta'minlashda juda muhimdir!
}

/// Quicksortda muvozanatsiz bo'linishlarga olib kelishi mumkin bo'lgan naqshlarni buzish uchun ba'zi elementlarni atrofga tarqatadi.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Jorj Marsagliyaning "Xorshift RNGs" qog'ozidan pseudorandom tasodifiy generator.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Ushbu raqamni modul qilib tasodifiy sonlarni oling.
        // Raqam `usize` ga to'g'ri keladi, chunki `len` `isize::MAX` dan katta emas.
        let modulus = len.next_power_of_two();

        // Ba'zi asosiy nomzodlar ushbu ko'rsatkichga yaqin joyda bo'ladi.Keling, ularni tasodifiy qilaylik.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // `len` modulini tasodifiy sonini yarating.
            // Biroq, qimmat operatsiyalarni oldini olish uchun biz avval uni modulning ikkitasini olamiz, so'ngra `[0, len - 1]` diapazoniga mos kelguncha `len` ga kamaytiramiz.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` dan past bo'lishi kafolatlanadi.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v`-da burilishni tanlaydi va agar tilim allaqachon tartiblangan bo'lsa, indeksni va `true`-ni qaytaradi.
///
/// Jarayon davomida `v`-dagi elementlar qayta tartiblangan bo'lishi mumkin.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Median-median usulini tanlash uchun minimal uzunlik.
    // Qisqa tilimlarda uchta o'rtacha median usuli qo'llaniladi.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Ushbu funksiyada bajarilishi mumkin bo'lgan maksimal svoplar soni.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Uchta indeks, biz ularga yaqinlashadigan joyni tanlaymiz.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Indekslarni saralash paytida biz bajaradigan svoplarning umumiy sonini hisoblaydi.
    let mut swaps = 0;

    if len >= 8 {
        // `v[a] <= v[b]` ko'rsatkichlarini almashtiradi.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // `v[a] <= v[b] <= v[c]` ko'rsatkichlarini almashtiradi.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` medianini topadi va indeksni `a` ga saqlaydi.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b` va `c` mahallalarida medianlarni toping.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b` va `c` orasida mediani toping.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Maksimal svoplar soni amalga oshirildi.
        // Ehtimol, tilim kamayib bormoqda yoki asosan kamaymoqda, shuning uchun teskari yo'naltirish uni tezroq saralashga yordam beradi.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v`-ni rekursiv ravishda saralaydi.
///
/// Agar tilim asl qatorda avvalgisiga ega bo'lsa, u `pred` sifatida ko'rsatilgan.
///
/// `limit` - `heapsort` ga o'tishdan oldin ruxsat berilgan muvozanatsiz bo'limlarning soni.
/// Agar nol bo'lsa, bu funktsiya zudlik bilan omborga o'tadi.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ushbu uzunlikgacha bo'lgan bo'laklar qo'shish tartibida saralanadi.
    const MAX_INSERTION: usize = 20;

    // To'g'ri, agar oxirgi qism oqilona muvozanatli bo'lsa.
    let mut was_balanced = true;
    // To'g'ri, agar oxirgi qism elementlarni aralashtirmasa (tilim allaqachon bo'linib ketgan bo'lsa).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Qo'shish tartibida juda qisqa bo'laklar saralanadi.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Agar juda ko'p noto'g'ri tanlov variantlari qilingan bo'lsa, `O(n * log(n))`-ning eng yomon holatiga kafolat berish uchun shunchaki uyaga qaytib boring.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Agar oxirgi qism muvozanatsiz bo'lsa, atrofdagi ba'zi elementlarni aralashtirib, tilimdagi naqshlarni buzishga harakat qiling.
        // Umid qilamizki, biz bu safar yaxshiroq yo'nalishni tanlaymiz.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Pivotni tanlang va tilim allaqachon saralanganligini taxmin qilib ko'ring.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Agar oxirgi qism yaxshi muvozanatlangan bo'lsa va elementlarni aralashtirmasa va agar pivot tanlovi taxmin qilsa, tilim allaqachon tartiblangan bo'lishi mumkin ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Bir nechta tartibsiz elementlarni aniqlab, ularni to'g'ri holatga o'tkazishga harakat qiling.
            // Agar tilim to'liq saralansa, biz tugatdik.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Agar tanlangan burilish avvalgisiga teng bo'lsa, u holda bu tilimdagi eng kichik element.
        // Tilni pivotga teng bo'lgan elementlarga bo'ling.
        // Ushbu holat, odatda, tilimda ko'plab takrorlanadigan elementlar mavjud bo'lganda uriladi.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Pivotdan kattaroq elementlarni saralashda davom eting.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Tilni bo'laklarga bo'ling.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Dilimni `left`, `pivot` va `right`-ga bo'ling.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Rekursiv qo'ng'iroqlarning umumiy sonini minimallashtirish va kamroq bo'sh joyni sarflash uchun faqat qisqa tomonga o'ting.
        // Keyin shunchaki uzunroq tomon bilan davom eting (bu quyruq rekursiyasiga o'xshaydi).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// *O*(*n*\*log(* n*)) eng yomon holati) bo'lgan `v` ni naqshlarni engib chiqadigan tezkor kort yordamida saralaydi.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tartiblash nol o'lchovli turlari bo'yicha mazmunli harakatlarga ega emas.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Balanssiz bo'linmalar sonini `floor(log2(len)) + 1` bilan cheklang.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Ushbu uzunlikdagi bo'laklarga ularni saralash tezroq bo'lishi mumkin.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Pivotni tanlang
        let (pivot, _) = choose_pivot(v, is_less);

        // Agar tanlangan burilish avvalgisiga teng bo'lsa, u holda bu tilimdagi eng kichik element.
        // Tilni pivotga teng bo'lgan elementlarga bo'ling.
        // Ushbu holat, odatda, tilimda ko'plab takrorlanadigan elementlar mavjud bo'lganda uriladi.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Agar biz indeksimizdan o'tgan bo'lsak, demak biz yaxshimiz.
                if mid > index {
                    return;
                }

                // Aks holda, pivotdan kattaroq elementlarni saralashda davom eting.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Dilimni `left`, `pivot` va `right`-ga bo'ling.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Agar mid==indeks bo'lsa, demak biz bajaramiz, chunki partition() o'rtadan keyingi barcha elementlar o'rtadan katta yoki teng bo'lishiga kafolat beradi.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Tartiblash nol o'lchovli turlari bo'yicha mazmunli harakatlarga ega emas.Hech narsa qilmang.
    } else if index == v.len() - 1 {
        // Maks elementni toping va uni massivning oxirgi holatiga qo'ying.
        // Biz bu erda `unwrap()`-dan foydalanishimiz mumkin, chunki v bo'sh bo'lmasligi kerakligini bilamiz.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Min elementini toping va uni massivning birinchi holatiga qo'ying.
        // Biz bu erda `unwrap()`-dan foydalanishimiz mumkin, chunki v bo'sh bo'lmasligi kerakligini bilamiz.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}