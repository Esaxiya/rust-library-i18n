//! Tilning iteratorlari foydalanadigan makrolar.

// In_mpty va len juda katta farq qiladi
macro_rules! is_empty {
    // ZST iteratorining uzunligini kodlash usuli, bu ZST uchun ham, ZST uchun ham ishlaydi.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Ba'zi chegara tekshiruvlaridan xalos bo'lish uchun (`position`-ga qarang), biz kutilmagan tarzda uzunlikni hisoblaymiz.
// ("Codegen/slice-position-bounds-check" tomonidan sinov qilingan.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // biz ba'zan xavfli blok ichida foydalanamiz

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ushbu _cannot_ `unchecked_sub` dan foydalanadi, chunki biz uzun ZST tilim iteratorlari uzunligini ko'rsatish uchun o'rashga bog'liqmiz.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Biz `start <= end` ni bilamiz, shuning uchun imzolangan shartnoma bilan shug'ullanish kerak bo'lgan `offset_from` dan yaxshiroq narsani qilishimiz mumkin.
            // Bu erda tegishli bayroqlarni o'rnatib, LLVM ga buni aytishimiz mumkin, bu esa chegara tekshiruvlarini olib tashlashga yordam beradi.
            // XAVFSIZLIK: o'zgarmas turiga ko'ra, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Shuningdek, LLVM-ga ko'rsatgichlar bir xil turdagi kattalikka ajratilganligini aytib, `(end - start) < size` o'rniga `len() == 0`-ni `start == end`-ga optimallashtiradi.
            //
            // XAVFSIZLIK: Turi o'zgarmas, ko'rsatkichlar shunday qilib tekislanadi
            //         ularning orasidagi masofa pointee kattaligi bo'lishi kerak
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` va `IterMut` iteratorlarining umumiy ta'rifi
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Birinchi elementni qaytaradi va iteratorning boshlanishini oldinga 1 ga o'tkazadi.
        // Chiziqli funktsiyaga nisbatan ishlashni sezilarli darajada yaxshilaydi.
        // Takrorlovchi bo'sh bo'lmasligi kerak.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Oxirgi elementni qaytaradi va iterator uchini 1 ga orqaga qaytaradi.
        // Chiziqli funktsiyaga nisbatan ishlashni sezilarli darajada yaxshilaydi.
        // Takrorlovchi bo'sh bo'lmasligi kerak.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // T ZST bo'lganda, iteratorning uchini `n` orqaga qarab siljitib, iteratorni kichraytiradi.
        // `n` `self.len()` dan oshmasligi kerak.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Yineleyiciden tilim yaratish uchun yordamchi funktsiya.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // XAVFSIZLIK: iterator ko'rsatgichli tilimdan yaratilgan
                // `self.ptr` va uzunligi `len!(self)`.
                // Bu `from_raw_parts` uchun barcha shartlar bajarilishini kafolatlaydi.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Eslatmani qaytarib, `offset` elementlari bo'yicha iteratorning boshlanishini oldinga siljitish uchun yordamchi funktsiya.
            //
            // Xavfsiz, chunki ofset `self.len()` dan oshmasligi kerak.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // XAVFSIZLIK: qo'ng'iroq qiluvchi `offset` `self.len()` dan oshmasligini kafolatlaydi,
                    // shuning uchun ushbu yangi ko'rsatkich `self` ichida va shuning uchun bo'sh bo'lishi kafolatlangan.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Yineleyicinin uchini `offset` elementlari orqaga qaytarish uchun yordamchi funktsiyasi, yangi uchini qaytaradi.
            //
            // Xavfsiz, chunki ofset `self.len()` dan oshmasligi kerak.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // XAVFSIZLIK: qo'ng'iroq qiluvchi `offset` `self.len()` dan oshmasligini kafolatlaydi,
                    // bu `isize` ni to'ldirmasligi kafolatlanadi.
                    // Bundan tashqari, natijada ko'rsatgich `slice` chegaralarida bo'lib, `offset` uchun boshqa talablarni bajaradi.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // tilim bilan amalga oshirilishi mumkin, ammo bu chegara tekshiruvidan qochadi

                // XAVFSIZLIK: `assume` qo'ng'iroqlari tilim boshlanishidan beri xavfsizdir
                // null bo'lmagan bo'lishi kerak va ZST bo'lmagan tilimlar null bo'lmagan ko'rsatkichga ega bo'lishi kerak.
                // `next_unchecked!`-ga qo'ng'iroq xavfsizdir, chunki avval iterator bo'sh ekanligini tekshiramiz.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ushbu iterator endi bo'sh.
                    if mem::size_of::<T>() == 0 {
                        // Biz buni shunday qilishimiz kerak, chunki `ptr` hech qachon 0 bo'lmasligi mumkin, lekin `end` bo'lishi mumkin (o'rash tufayli).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // XAVFSIZLIK: agar T ZST bo'lmasa, end 0 bo'lishi mumkin emas, chunki ptr 0 va end>=ptr emas
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // XAVFSIZLIK: Biz chegaradamiz.`post_inc_start` hatto ZSTlar uchun ham to'g'ri ish qiladi.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Biz `try_fold`-dan foydalanadigan standart dasturni bekor qilamiz, chunki bu oddiy dastur kamroq LLVM IR hosil qiladi va tezroq kompilyatsiya qilinadi.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Biz `try_fold`-dan foydalanadigan standart dasturni bekor qilamiz, chunki bu oddiy dastur kamroq LLVM IR hosil qiladi va tezroq kompilyatsiya qilinadi.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Biz `try_fold`-dan foydalanadigan standart dasturni bekor qilamiz, chunki bu oddiy dastur kamroq LLVM IR hosil qiladi va tezroq kompilyatsiya qilinadi.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Biz `try_fold`-dan foydalanadigan standart dasturni bekor qilamiz, chunki bu oddiy dastur kamroq LLVM IR hosil qiladi va tezroq kompilyatsiya qilinadi.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Biz `try_fold`-dan foydalanadigan standart dasturni bekor qilamiz, chunki bu oddiy dastur kamroq LLVM IR hosil qiladi va tezroq kompilyatsiya qilinadi.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Biz `try_fold`-dan foydalanadigan standart dasturni bekor qilamiz, chunki bu oddiy dastur kamroq LLVM IR hosil qiladi va tezroq kompilyatsiya qilinadi.
            // Shuningdek, `assume` chegara tekshiruvidan qochadi.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // XAVFSIZLIK: biz o'zgarmas chegaralar chegarasida bo'lishimizga kafolat beramiz:
                        // qachon `i >= n`, `self.next()` `None` qaytaradi va tsikl uziladi.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Biz `try_fold`-dan foydalanadigan standart dasturni bekor qilamiz, chunki bu oddiy dastur kamroq LLVM IR hosil qiladi va tezroq kompilyatsiya qilinadi.
            // Shuningdek, `assume` chegara tekshiruvidan qochadi.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // XAVFSIZLIK: `i` `n` dan past bo'lishi kerak, chunki u `n` da boshlanadi
                        // va faqat kamayib bormoqda.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // XAVFSIZLIK: qo'ng'iroq qiluvchi `i` chegarasida ekanligiga kafolat berishi kerak
                // asosiy tilim, shuning uchun `i` `isize` ni to'ldira olmaydi va qaytarilgan havolalar tilim elementiga murojaat qilishiga kafolat beradi va shu bilan haqiqiyligini kafolatlaydi.
                //
                // Shuni ham yodda tutingki, qo'ng'iroq qiluvchi bizni hech qachon bir xil indeks bilan chaqirmasligimizga kafolat beradi va ushbu sublitga kiradigan boshqa usullar chaqirilmasligini kafolatlaydi, shuning uchun qaytarilgan ma'lumot uchun o'zgaruvchan bo'lishi mumkin.
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // tilim bilan amalga oshirilishi mumkin, ammo bu chegara tekshiruvidan qochadi

                // XAVFSIZLIK: `assume` qo'ng'iroqlari xavfsizdir, chunki tilimning boshlash ko'rsatkichi bo'sh bo'lishi kerak,
                // va ZST-larga tegishli bo'lmagan tilimlarda nol bo'lmagan ko'rsatgich bo'lishi kerak.
                // `next_back_unchecked!`-ga qo'ng'iroq xavfsizdir, chunki avval iterator bo'sh ekanligini tekshiramiz.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ushbu iterator endi bo'sh.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // XAVFSIZLIK: Biz chegaradamiz.`pre_dec_end` hatto ZSTlar uchun ham to'g'ri ish qiladi.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}