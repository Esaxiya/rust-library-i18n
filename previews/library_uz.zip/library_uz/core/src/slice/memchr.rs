// Asl dastur rust-memchr-dan olingan.
// Mualliflik huquqi 2015 Endryu Gallant, bluss va Nikolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Qisqartirish usulidan foydalaning.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Agar `x` tarkibida nol bayt bo'lsa, `true`-ni qaytaradi.
///
/// *Matters Computational* dan, J. Arndt:
///
/// "Maqsad har bir baytdan bittasini olib tashlash, so'ngra qarz eng ahamiyatli tomonga ko'paygan baytlarni izlashdir.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` baytiga mos keladigan birinchi indeksni qaytaradi.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Kichik bo'laklar uchun tezkor yo'l
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Bir vaqtning o'zida ikkita `usize` so'zni o'qib, bitta bayt qiymatini qidiring.
    //
    // Split `text` uch qismga bo'lingan
    // - hizalanmagan boshlang'ich qism, birinchi so'zdan oldin matndagi manzil hizalanadi
    // - tanasi, bir vaqtning o'zida 2 ta so'z bilan skanerlang
    // - oxirgi 2 qism, <2 so'z hajmi

    // tekislangan chegaraga qadar qidirish
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // matnning asosiy qismini qidirish
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // XAVFSIZLIK: vaqt predikati kamida 2 * usize_bytes masofani kafolatlaydi
        // tilimning oxiri va oxiri o'rtasida.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // mos keladigan bayt bo'lsa sindirish
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Tana tsikli to'xtagan nuqtadan keyin baytni toping.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `x` baytiga mos keladigan so'nggi indeksni `text`-ga qaytaradi.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Bir vaqtning o'zida ikkita `usize` so'zni o'qib, bitta bayt qiymatini qidiring.
    //
    // Split `text` uch qismga bo'linadi:
    // - unvaligned quyruq, oxirgi so'zdan keyin manzildagi matnda,
    // - bir vaqtning o'zida 2 ta so'z bilan skanerlangan tanasi,
    // - birinchi qolgan bayt, <2 so'z hajmi.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Biz buni faqat prefiks va qo'shimchaning uzunligini olish uchun chaqiramiz.
        // O'rtada biz har doim bir vaqtning o'zida ikkita bo'lakni qayta ishlaymiz.
        // XAVFSIZLIK: `[u8]`-ni `[usize]`-ga o'tkazish, `align_to` tomonidan ko'rib chiqiladigan o'lchamdagi farqlar bundan mustasno.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Matnning asosiy qismini qidiring, min_aligned_offset-dan o'tmasligimizga ishonch hosil qiling.
    // ofset har doim hizalanadi, shuning uchun faqat `>`-ni sinab ko'rish etarli va ortiqcha toshib ketishning oldini oladi.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // XAVFSIZLIK: ofset len, suffix.len() dan boshlanadi, agar u kattaroq bo'lsa
        // min_aligned_offset (prefix.len()) qolgan masofa kamida 2 * chunk_bayt.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Agar mos keladigan bayt bo'lsa, sindirib tashlang.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Tana halqasi to'xtagan nuqtadan oldin baytni toping.
    text[..offset].iter().rposition(|elt| *elt == x)
}