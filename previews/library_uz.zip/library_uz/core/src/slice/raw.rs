//! `&[T]` va `&mut [T]` yaratish uchun bepul funktsiyalar.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Ko'rsatkich va uzunlikdan bo'lak hosil qiladi.
///
/// `len` argumenti **element** soni, baytlar soni emas.
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `data` `len * mem::size_of::<T>()` ko'p bayt uchun o'qish uchun [valid] bo'lishi kerak va u to'g'ri hizalanmalıdır.Bu, xususan:
///
///     * Ushbu tilimning butun xotira diapazoni bitta ajratilgan ob'ekt ichida bo'lishi kerak!
///       Bo'limlar hech qachon bir nechta ajratilgan ob'ektlar bo'ylab tarqalib keta olmaydi.Buni hisobga olmaslik uchun noto'g'ri misol uchun [below](#incorrect-usage)-ga murojaat qiling.
///     * `data` nol uzunlikdagi bo'laklar uchun ham nolga tenglashtirilishi kerak.
///     Buning bir sababi shundaki, enum tartibini optimallashtirish mos yozuvlar (har qanday uzunlikdagi tilimlarni o'z ichiga olgan holda) hizalanmış va boshqa ma'lumotlardan ajratib turishi mumkin.
///     [`NonNull::dangling()`] yordamida nol uzunlikdagi bo'laklar uchun `data` sifatida ishlatilishi mumkin bo'lgan ko'rsatkichni olishingiz mumkin.
///
/// * `data` `T` tipidagi ketma-ket to'g'ri boshlangan qiymatlarni `len` ga ko'rsatishi kerak.
///
/// * Qaytgan tilimga havola qilingan xotira, `UnsafeCell` ichidan tashqari, `'a` umri davomida mutatsiyaga olib kelmasligi kerak.
///
/// * Dilimning umumiy hajmi `len * mem::size_of::<T>()` `isize::MAX` dan katta bo'lmasligi kerak.
///   [`pointer::offset`] xavfsizlik hujjatlariga qarang.
///
/// # Caveat
///
/// Qaytgan tilimning ishlash muddati uning ishlatilishidan kelib chiqadi.
/// Tasodifiy noto'g'ri ishlatilishining oldini olish uchun, kontekstda, masalan, tilim uchun xost qiymatining ishlash muddatini oladigan yordamchi funktsiyani taqdim etish yoki aniq izoh berish orqali hayotning qaysi manbasini xavfsiz bo'lishiga bog'liqligini tavsiya etamiz.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // bitta element uchun bo'lakni namoyish qilish
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Noto'g'ri foydalanish
///
/// Quyidagi `join_slices` funktsiyasi **asossiz** is️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Yuqoridagi tasdiq `fst` va `snd` ning tutashganligini ta'minlaydi, ammo ular hali ham _different allocated objects_ ichida bo'lishi mumkin, bu holda ushbu bo'lakni yaratish aniqlanmagan xatti-harakatlardir.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` va `b` har xil ajratilgan ob'ektlar ...
///     let a = 42;
///     let b = 27;
///     // ... shunga qaramay, ular xotirada doimiy ravishda joylashtirilishi mumkin: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `from_raw_parts` uchun xavfsizlik shartnomasini bajarishi kerak.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// [`from_raw_parts`] bilan bir xil funktsiyalarni bajaradi, faqat o'zgaruvchan tilim qaytariladi.
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `data` `len * mem::size_of::<T>()` ko'p baytlarni o'qish va yozish uchun [valid] bo'lishi kerak va u to'g'ri hizalanmalıdır.Bu, xususan:
///
///     * Ushbu tilimning butun xotira diapazoni bitta ajratilgan ob'ekt ichida bo'lishi kerak!
///       Bo'limlar hech qachon bir nechta ajratilgan ob'ektlar bo'ylab tarqalib keta olmaydi.
///     * `data` nol uzunlikdagi bo'laklar uchun ham nolga tenglashtirilishi kerak.
///     Buning bir sababi shundaki, enum tartibini optimallashtirish mos yozuvlar (har qanday uzunlikdagi tilimlarni o'z ichiga olgan holda) hizalanmış va boshqa ma'lumotlardan ajratib turishi mumkin.
///
///     [`NonNull::dangling()`] yordamida nol uzunlikdagi bo'laklar uchun `data` sifatida ishlatilishi mumkin bo'lgan ko'rsatkichni olishingiz mumkin.
///
/// * `data` `T` tipidagi ketma-ket to'g'ri boshlangan qiymatlarni `len` ga ko'rsatishi kerak.
///
/// * Qaytgan tilim bilan havola qilingan xotiraga `'a` umri davomida boshqa ko'rsatgich orqali (qaytarish qiymatidan kelib chiqmagan) kirish mumkin emas.
///   Ham o'qish, ham yozish taqiqlanadi.
///
/// * Dilimning umumiy hajmi `len * mem::size_of::<T>()` `isize::MAX` dan katta bo'lmasligi kerak.
///   [`pointer::offset`] xavfsizlik hujjatlariga qarang.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `from_raw_parts_mut` uchun xavfsizlik shartnomasini bajarishi kerak.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// T ga havolani uzunlik 1 bo'lagiga o'zgartiradi (nusxa olmasdan).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// T ga havolani uzunlik 1 bo'lagiga o'zgartiradi (nusxa olmasdan).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}