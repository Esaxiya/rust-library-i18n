//! ASCII `[u8]` operatsiyalari.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Ushbu qismdagi barcha baytlar ASCII oralig'ida ekanligini tekshiradi.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Ikki bo'lak ASCII holatiga sezgir bo'lmagan o'yin ekanligini tekshiradi.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` bilan bir xil, ammo vaqtinchaliklarni ajratmasdan va nusxalashsiz.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Ushbu bo'lakni o'rniga ASCII bosh harfiga tenglashtiradigan joyga o'zgartiradi.
    ///
    /// 'a' dan 'z' gacha bo'lgan ASCII harflari 'A' dan 'Z' gacha xaritalanadi, ammo ASCII bo'lmagan harflar o'zgarmaydi.
    ///
    /// Mavjud qiymatni o'zgartirmasdan yangi bosh harfni qaytarish uchun [`to_ascii_uppercase`] dan foydalaning.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Ushbu bo'lakni o'z o'rniga ASCII kichik harfiga aylantirmoqda.
    ///
    /// 'A' dan 'Z' gacha bo'lgan ASCII harflari 'a' dan 'z' gacha xaritalanadi, ammo ASCII bo'lmagan harflar o'zgarmaydi.
    ///
    /// Mavjud qiymatni o'zgartirmasdan yangi kichik harfli qiymatni qaytarish uchun [`to_ascii_lowercase`] dan foydalaning.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` so'zidagi bayt nonascii (>=128) bo'lsa, `true`-ni qaytaradi.
/// `../str/mod.rs`-dan Snarfed, bu utf8-ni tasdiqlash uchun shunga o'xshash narsani qiladi.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Vaqtinchalik operatsiyalar o'rniga (agar iloji bo'lsa) bir vaqtning o'zida foydalanadigan operatsiyalardan foydalanadigan optimallashtirilgan ASCII testi.
///
/// Bu erda biz foydalanadigan algoritm juda oddiy.Agar `s` juda qisqa bo'lsa, biz faqat har bir baytni tekshiramiz va shu bilan bajaramiz.Aks holda:
///
/// - To'g'ri bo'lmagan yuk bilan birinchi so'zni o'qing.
/// - Ko'rsatkichni tekislang, keyingi so'zlarni tekislangan yuklar bilan oxirigacha o'qing.
/// - `s`-dan so'nggi `usize`-ni tekislanmagan yuk bilan o'qing.
///
/// Agar ushbu yuklarning birortasi `contains_nonascii` (above) haqiqiyligini qaytaradigan narsa ishlab chiqaradigan bo'lsa, unda biz javobning yolg'on ekanligini bilamiz.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Agar biz bir vaqtning o'zida amalga oshirilgan so'zlardan hech qanday foyda ko'rmasak, yana skaler ko'chaga o'ting.
    //
    // Biz buni `size_of::<usize>()` `usize` uchun etarli darajada moslashtirilmagan arxitektura uchun qilamiz, chunki bu g'alati edge ishi.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Biz har doim birinchi so'zni satrsiz o'qiymiz, ya'ni `align_offset` degan ma'noni anglatadi
    // 0, biz hizalangan o'qish uchun yana bir xil qiymatni o'qiymiz.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // XAVFSIZLIK: Biz yuqoridagi `len < USIZE_SIZE`-ni tasdiqlaymiz.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Biz buni yuqorida, bilvosita, tekshirdik.
    // `offset_to_aligned` `align_offset` yoki `USIZE_SIZE` ekanligini unutmang, ikkalasi ham yuqorida aniq tekshirilgan.
    //
    debug_assert!(offset_to_aligned <= len);

    // XAVFSIZLIK: word_ptr-biz o'qish uchun foydalanadigan (to'g'ri hizalangan) usize ptr
    // tilimning o'rta qismi.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` bu `word_ptr` bayt ko'rsatkichi bo'lib, pastadir tekshiruvi uchun ishlatiladi.
    let mut byte_pos = offset_to_aligned;

    // Paranoya tekislanishni tekshiradi, chunki biz bir qator yuklanmagan yuklarni amalga oshirmoqchimiz.
    // Amalda bu `align_offset`-da xatolikka yo'l qo'ymaslik mumkin emas.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Keyingi so'zlarni oxirgi hizalanadigan so'zga qadar o'qing, so'ngra dumini tekshirishda bajarilishi kerak bo'lgan oxirgi hizalanadigan so'zni o'zi bundan mustasno, dumining har doim bir branch `byte_pos == len` ga qadar har doim bitta `usize` bo'lishini ta'minlash uchun.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // O'qish chegaralanganligini aql-idrok bilan tekshiring
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Va `byte_pos` haqidagi taxminlarimiz amal qiladi.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // XAVFSIZLIK: Biz `word_ptr` to'g'ri moslashtirilganligini bilamiz (tufayli
        // "align_offset`), va biz bilamizki, `word_ptr` va oxirigacha etarli baytlarimiz bor
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // XAVFSIZLIK: Biz `byte_pos <= len - USIZE_SIZE` ekanligini bilamiz, demak
        // ushbu `add` dan so'ng, `word_ptr` ko'pi bilan oxirigacha bo'ladi.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Haqiqatan ham bitta `usize` qolganligini ta'minlash uchun sog'lig'ini tekshirish.
    // Bunga bizning halqaviy holatimiz kafolat berishi kerak.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // XAVFSIZLIK: Bu biz boshida tekshiradigan `len >= USIZE_SIZE`-ga bog'liq.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}