// ignore-tidy-filelength

//! Dilimlarni boshqarish va manipulyatsiya.
//!
//! Qo'shimcha ma'lumot uchun [`std::slice`]-ga qarang.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// rust-memchr-dan olingan sof rust memchrni amalga oshirish
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Ushbu funktsiya hammaga ma'lum, chunki sinovli hepsortni birlashtirishning boshqa usuli yo'q.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Tilimdagi elementlar sonini qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // XAVFSIZLIK: konst ovozi, chunki biz uzunlik maydonini usize sifatida o'zgartiramiz (bo'lishi kerak)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // XAVFSIZLIK: bu xavfsizdir, chunki `&[T]` va `FatPtr<T>` bir xil tartibga ega.
            // Ushbu kafolatni faqat `std` taqdim etishi mumkin.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Bu barqaror bo'lsa, `crate::ptr::metadata(self)` bilan almashtiring.
            // Ushbu yozuvdan boshlab, bu "Const-stable functions can only call other const-stable functions" xatosiga sabab bo'ladi.
            //

            // XAVFSIZLIK: `PtrRepr` birlashmasidan qiymatga kirish * const T dan beri xavfsizdir
            // va PtrComponentlar<T>bir xil xotira tartibiga ega.
            // Ushbu kafolatni faqat std berishi mumkin.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Agar tilimning uzunligi 0 bo'lsa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Dilimning birinchi elementini yoki bo'sh bo'lsa `None`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// O'zgaruvchan ko'rsatkichni tilimning birinchi elementiga qaytaradi yoki bo'sh bo'lsa, `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Dilimning birinchi va qolgan barcha elementlarini qaytaradi, yoki bo'sh bo'lsa, `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Dilimning birinchi va qolgan barcha elementlarini qaytaradi, yoki bo'sh bo'lsa, `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Dilimning oxirgi va qolgan barcha elementlarini qaytaradi, yoki bo'sh bo'lsa, `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Dilimning oxirgi va qolgan barcha elementlarini qaytaradi, yoki bo'sh bo'lsa, `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Bo'limning oxirgi elementini yoki bo'sh bo'lsa `None`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// O'zgaruvchan ko'rsatkichni tilimdagi oxirgi elementga qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Indeks turiga qarab elementga yoki sublitsiyaga havolani qaytaradi.
    ///
    /// - Agar pozitsiya berilgan bo'lsa, elementni ushbu pozitsiyadagi yoki chegaradan tashqarida bo'lsa, `None` qaytaradi.
    ///
    /// - Agar diapazon berilgan bo'lsa, ushbu diapazonga mos keladigan sublitsiyani yoki chegaradan tashqarida bo'lsa, `None`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Indeks turiga qarab ([`get`]-ga qarang) yoki indeks chegaradan tashqarida bo'lsa, `None` ga qarab element yoki sublitsiyaga tegishli o'zgaruvchan havolani qaytaradi.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Chegaralarni tekshirmasdan elementga yoki pastki qismga havolani qaytaradi.
    ///
    /// Xavfsiz alternativa uchun [`get`]-ga qarang.
    ///
    /// # Safety
    ///
    /// Ushbu usulni chegaradan tashqaridagi indeks bilan chaqirish *[aniqlanmagan xatti-harakatlar]*, natijada havola ishlatilmasa ham.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `get_unchecked` uchun xavfsizlik talablarining ko'pini bajarishi kerak;
        // tilim ajratilishi mumkin, chunki `self` xavfsiz ma'lumotdir.
        // Qaytgan ko'rsatgich xavfsizdir, chunki `SliceIndex` impllari buning kafolatiga ega bo'lishi kerak.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Chegaralarni tekshirmasdan, elementga yoki pastki qismga o'zgarishi mumkin bo'lgan ma'lumotni qaytaradi.
    ///
    /// Xavfsiz alternativa uchun [`get_mut`]-ga qarang.
    ///
    /// # Safety
    ///
    /// Ushbu usulni chegaradan tashqaridagi indeks bilan chaqirish *[aniqlanmagan xatti-harakatlar]*, natijada havola ishlatilmasa ham.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `get_unchecked_mut` uchun xavfsizlik talablarini bajarishi kerak;
        // tilim ajratilishi mumkin, chunki `self` xavfsiz ma'lumotdir.
        // Qaytgan ko'rsatgich xavfsizdir, chunki `SliceIndex` impllari buning kafolatiga ega bo'lishi kerak.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Xom ko'rsatkichni tilimning buferiga qaytaradi.
    ///
    /// Qo'ng'iroq qiluvchi bu funktsiya qaytadan ko'rsatgichdan uzoqroq bo'lishini ta'minlashi kerak, aks holda u axlatga ishora qiladi.
    ///
    /// Qo'ng'iroq qiluvchi shuningdek, (non-transitively) ko'rsatgichi ko'rsatgan xotiraning ushbu ko'rsatgich yoki undan olingan har qanday ko'rsatgich yordamida hech qachon (`UnsafeCell` ichkarisida) yozilmasligini ta'minlashi kerak.
    /// Agar tilim tarkibini mutatsiyalash kerak bo'lsa, [`as_mut_ptr`] dan foydalaning.
    ///
    /// Ushbu tilimga havola qilingan konteynerni o'zgartirish uning buferini qayta taqsimlanishiga olib kelishi mumkin, bu esa unga ko'rsatgichlarni bekor qiladi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Xavfsiz o'zgaruvchan ko'rsatkichni tilimning buferiga qaytaradi.
    ///
    /// Qo'ng'iroq qiluvchi bu funktsiya qaytadan ko'rsatgichdan uzoqroq bo'lishini ta'minlashi kerak, aks holda u axlatga ishora qiladi.
    ///
    /// Ushbu tilimga havola qilingan konteynerni o'zgartirish uning buferini qayta taqsimlanishiga olib kelishi mumkin, bu esa unga ko'rsatgichlarni bekor qiladi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Tilni qamrab olgan ikkita xom ko'rsatkichni qaytaradi.
    ///
    /// Qaytgan diapazon yarim ochiq, ya'ni tugmachaning ko'rsatgichi tilimning oxirgi elementini *bir o'tganligini* ko'rsatadi.
    /// Shunday qilib, bo'sh bo'lak ikkita teng ko'rsatkich bilan, ikkala ko'rsatkich orasidagi farq esa tilimning hajmini bildiradi.
    ///
    /// Ushbu ko'rsatgichlardan foydalanish to'g'risida ogohlantirishlar uchun [`as_ptr`]-ga qarang.Yakuniy ko'rsatgich qo'shimcha ehtiyotkorlikni talab qiladi, chunki u tilimdagi yaroqli elementga ishora qilmaydi.
    ///
    /// Ushbu funktsiya C++ da keng tarqalganidek, xotiradagi bir qator elementlarga murojaat qilish uchun ikkita ko'rsatgichdan foydalanadigan chet el interfeyslari bilan ishlash uchun foydalidir.
    ///
    ///
    /// Shuningdek, elementga ko'rsatgich ushbu tilim elementiga tegishli ekanligini tekshirish foydali bo'lishi mumkin:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // XAVFSIZLIK: Bu erda `add` xavfsizdir, chunki:
        //
        //   - Ikkala ko'rsatgich ham bitta ob'ektning bir qismidir, chunki to'g'ridan-to'g'ri ob'ekt yonidan o'tib ketish ham hisobga olinadi.
        //
        //   - Bu erda ta'kidlanganidek, tilimning hajmi hech qachon isize::MAX baytdan kattaroq emas:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Bu erda hech qanday o'rash yo'q, chunki tilimlar manzil maydonining oxiridan o'tmaydi.
        //
        // pointer::add hujjatiga qarang.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Tilni qamrab olgan ikkita xavfli o'zgaruvchan ko'rsatkichni qaytaradi.
    ///
    /// Qaytgan diapazon yarim ochiq, ya'ni tugmachaning ko'rsatgichi tilimning oxirgi elementini *bir o'tganligini* ko'rsatadi.
    /// Shunday qilib, bo'sh bo'lak ikkita teng ko'rsatkich bilan, ikkala ko'rsatkich orasidagi farq esa tilimning hajmini bildiradi.
    ///
    /// Ushbu ko'rsatgichlardan foydalanish to'g'risida ogohlantirishlar uchun [`as_mut_ptr`]-ga qarang.
    /// Yakuniy ko'rsatgich qo'shimcha ehtiyotkorlikni talab qiladi, chunki u tilimdagi yaroqli elementga ishora qilmaydi.
    ///
    /// Ushbu funktsiya C++ da keng tarqalganidek, xotiradagi bir qator elementlarga murojaat qilish uchun ikkita ko'rsatgichdan foydalanadigan chet el interfeyslari bilan ishlash uchun foydalidir.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // XAVFSIZLIK: Bu erda `add` nima uchun xavfsiz ekanligini yuqoridagi as_ptr_range()-ga qarang.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Tilimdagi ikkita elementni almashtiradi.
    ///
    /// # Arguments
    ///
    /// * a, birinchi elementning ko'rsatkichi
    /// * b, ikkinchi elementning ko'rsatkichi
    ///
    /// # Panics
    ///
    /// Agar 0Panics, agar `a` yoki `b` chegaradan tashqarida bo'lsa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Bitta vector-dan ikkita o'zgarishi mumkin bo'lgan kreditni ololmaysiz, buning o'rniga xom ko'rsatkichlardan foydalaning.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // XAVFSIZLIK: `pa` va `pb` xavfsiz o'zgaruvchan havolalar asosida yaratilgan va havola qilingan
        // tilimdagi elementlarga va shu sababli haqiqiyligi va hizalanishiga kafolat beriladi.
        // `a` va `b` orqasidagi elementlarga kirish tekshiriladi va chegaradan tashqarida panic bo'ladi.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Tilimdagi elementlarning tartibini joyida o'zgartiradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Juda kichik turlari uchun odatdagi yo'lda o'qigan har bir kishi yomon ishlaydi.
        // Xnumx XNUMX samaradorligini hisobga olgan holda, kattaroq qismni yuklash va reestrni orqaga qaytarish orqali biz yaxshiroq ishlashimiz mumkin.
        //

        // Ideal holda LLVM biz uchun buni amalga oshirishi mumkin edi, chunki u hizalanmagan o'qishlar samaradorligini (masalan, turli xil ARM versiyalari o'rtasida o'zgarishini) va eng yaxshi qism hajmi qanday bo'lishini bizdan ko'ra yaxshiroq biladi.
        // Afsuski, LLVM 4.0 (2017-05)-dan boshlab, u faqat tsiklni ochadi, shuning uchun biz buni o'zimiz qilishimiz kerak.
        // (Gipoteza: teskari muammoli, chunki tomonlar boshqacha tekislanishi mumkin-uzunligi g'alati bo'lganda bo'ladi-shuning uchun o'rtada to'liq hizalanmış SIMD dan foydalanish uchun oldingi va keyingi qo'shimchalar chiqarishning imkoni yo'q.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // U00-ni usize-ga qaytarish uchun ichki llvm.bswap-dan foydalaning
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // XAVFSIZLIK: Bu erda bir nechta narsalarni tekshirish kerak:
                //
                // - Yuqoridagi cfg tekshiruvi tufayli `chunk` 4 yoki 8 ekanligini unutmang.Shunday qilib, `chunk - 1` ijobiydir.
                // - `i` indekslari bilan indeksatsiya qilish yaxshi, chunki loop tekshiruvi kafolatlaydi
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - `ln - i - chunk = ln - (i + chunk)` indeksi bilan indekslash yaxshi:
                //   - `i + chunk > 0` ahamiyatsiz haqiqat.
                //   - Tekshirish kafolati:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, shuning uchun olib tashlash pastga tushmaydi.
                // - `read_unaligned` va `write_unaligned` qo'ng'iroqlari yaxshi:
                //   - `pa` `i` indeksiga ishora qiladi, bu erda `i < ln / 2 - (chunk - 1)` (yuqoriga qarang) va `pb` `ln - i - chunk` indeksiga ishora qiladi, shuning uchun ikkalasi ham `self` oxiridan kamida `chunk` ko'p bayt.
                //
                //   - Har qanday ishga tushirilgan xotira haqiqiy `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // U00-larni u32-da teskari yo'naltirish uchun 16-rotate-dan foydalaning
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // XAVFSIZLIK: `i + 1 < ln` bo'lsa, mos kelmagan u32 ni `i` dan o'qish mumkin
                // (va aniq `i < ln`), chunki har bir element 2 baytdan iborat va biz 4 o'qiymiz.
                //
                // `i + chunk - 1 < ln / 2` # esa holat
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // U uzunlikning 2 ga bo'linishidan kichik bo'lgani uchun u chegarada bo'lishi kerak.
                //
                // Bu, shuningdek, `0 < i + chunk <= ln` sharti doimo hurmat qilinishini anglatadi va `pb` ko'rsatkichidan xavfsiz foydalanilishini ta'minlaydi.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // XAVFSIZLIK: `i` tilim uzunligining yarmidan kam
            // `i` va `ln - i - 1`-ga kirish xavfsiz (`i` 0dan boshlanadi va `ln / 2 - 1` dan oshmaydi).
            // Natijada paydo bo'lgan `pa` va `pb` ko'rsatkichlari haqiqiy va moslashtirilgan bo'lib, ularni o'qish va yozish mumkin.
            //
            //
            unsafe {
                // Xavfsiz almashtirishda chegaralarni tekshirmaslik uchun xavfsiz bo'lmagan almashtirish.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Tilning ustiga iteratorni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Har bir qiymatni o'zgartirishga imkon beruvchi iteratorni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// `size` uzunlikdagi barcha qo'shni windows bo'yicha iteratorni qaytaradi.
    /// windows ustma-ust tushadi.
    /// Agar tilim `size` dan qisqa bo'lsa, iterator hech qanday qiymat qaytarmaydi.
    ///
    /// # Panics
    ///
    /// Agar `size` 0 bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Agar tilim `size` dan qisqa bo'lsa:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Dilimning boshidan boshlab, bir vaqtning o'zida tilimning `chunk_size` elementlari ustidan iteratorni qaytaradi.
    ///
    /// Parchalar tilim bo'lib, ular bir-birining ustiga chiqmaydi.Agar `chunk_size` tilim uzunligini ajratmasa, u holda oxirgi qism `chunk_size` uzunlikka ega bo'lmaydi.
    ///
    /// Ushbu iteratorning har doim to'liq `chunk_size` elementlarining qismlarini qaytaradigan variantini [`chunks_exact`]-ga qarang va xuddi shu iterator uchun [`rchunks`], lekin tilim oxiridan boshlanadi.
    ///
    ///
    /// # Panics
    ///
    /// Agar `chunk_size` 0 bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Dilimning boshidan boshlab, bir vaqtning o'zida tilimning `chunk_size` elementlari ustidan iteratorni qaytaradi.
    ///
    /// Parchalar o'zgaruvchan bo'laklar bo'lib, ular bir-birining ustiga chiqmaydi.Agar `chunk_size` tilim uzunligini ajratmasa, u holda oxirgi qism `chunk_size` uzunlikka ega bo'lmaydi.
    ///
    /// Ushbu iteratorning har doim to'liq `chunk_size` elementlarining qismlarini qaytaradigan variantini [`chunks_exact_mut`]-ga qarang va xuddi shu iterator uchun [`rchunks_mut`], lekin tilim oxiridan boshlanadi.
    ///
    ///
    /// # Panics
    ///
    /// Agar `chunk_size` 0 bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Dilimning boshidan boshlab, bir vaqtning o'zida tilimning `chunk_size` elementlari ustidan iteratorni qaytaradi.
    ///
    /// Parchalar tilim bo'lib, ular bir-birining ustiga chiqmaydi.
    /// Agar `chunk_size` tilim uzunligini taqsimlamasa, u holda `chunk_size-1` gacha bo'lgan oxirgi elementlar chiqarib tashlanadi va ularni iteratorning `remainder` funktsiyasidan olish mumkin.
    ///
    ///
    /// To'liq `chunk_size` elementlariga ega bo'lgan har bir qism tufayli kompilyator ko'pincha olingan kodni [`chunks`] ga qaraganda yaxshiroq optimallashtirishi mumkin.
    ///
    /// Qolgan qismini kichikroq qism sifatida qaytaradigan ushbu iteratorning bir varianti uchun [`chunks`]-ga qarang va xuddi shu iterator uchun [`rchunks_exact`], lekin tilim oxiridan boshlanadi.
    ///
    /// # Panics
    ///
    /// Agar `chunk_size` 0 bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Dilimning boshidan boshlab, bir vaqtning o'zida tilimning `chunk_size` elementlari ustidan iteratorni qaytaradi.
    ///
    /// Parchalar o'zgaruvchan bo'laklar bo'lib, ular bir-birining ustiga chiqmaydi.
    /// Agar `chunk_size` tilim uzunligini taqsimlamasa, u holda `chunk_size-1` gacha bo'lgan oxirgi elementlar chiqarib tashlanadi va ularni iteratorning `into_remainder` funktsiyasidan olish mumkin.
    ///
    ///
    /// To'liq `chunk_size` elementlariga ega bo'lgan har bir qism tufayli kompilyator natijada olingan kodni [`chunks_mut`] ga qaraganda yaxshiroq optimallashtirishi mumkin.
    ///
    /// Qolgan qismini kichikroq qism sifatida qaytaradigan ushbu iteratorning bir varianti uchun [`chunks_mut`]-ga qarang va xuddi shu iterator uchun [`rchunks_exact_mut`], lekin tilim oxiridan boshlanadi.
    ///
    /// # Panics
    ///
    /// Agar `chunk_size` 0 bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Qolgan joy yo'q deb o'ylab, tilimni `N`-elementli massivlar bo'lagiga ajratadi.
    ///
    ///
    /// # Safety
    ///
    /// Buni faqat qachon deb atash mumkin
    /// - Dilim to'liq "N`-element" qismlariga bo'linadi (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // XAVFSIZLIK: 1 elementli qismlar hech qachon qoldiqqa ega bo'lmaydi
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // XAVFSIZLIK: (6) bo'lagi uzunligi 3 ga ko'paytiriladi
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Bu asossiz bo'lar edi:
    /// // bo'laklarga ruxsat bering: &[[_;5]]= slice.as_chunks_unchecked()//Dilim uzunligi 5 ta bo'lakning ko'paytmasi emas:&[[_;0]]= slice.as_chunks_unchecked()//Nol uzunlikdagi bo'laklarga hech qachon yo'l qo'yilmaydi
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // XAVFSIZLIK: Bizning shartimiz bunga qo'ng'iroq qilish uchun kerak bo'lgan narsadir
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // XAVFSIZLIK: Biz ichiga bir bo'lak `new_len * N` elementlarini tashladik
        // ko'plab `N` elementlari bo'laklari bo'lgan `new_len` bo'lagi.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Tilni tilim boshidan boshlab `N`-elementli massivlar bo'lagi va uzunligi `N` dan kam bo'lgan qoldiq bo'laklarga bo'linadi.
    ///
    ///
    /// # Panics
    ///
    /// Panics, agar `N` 0 bo'lsa, bu usul barqarorlashguncha, ehtimol kompilyatsiya vaqtidagi xatolikka o'zgartiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // XAVFSIZLIK: Biz allaqachon noldan vahima oldik va qurilish bilan ta'minladik
        // sublitsiyaning uzunligi N ning ko'paytmasi ekanligi.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Tilni oxiridan boshlab `N`-elementli massivlar bo'lagi va uzunligi `N` dan kam bo'lgan qoldiq bo'laklarga bo'linadi.
    ///
    ///
    /// # Panics
    ///
    /// Panics, agar `N` 0 bo'lsa, bu usul barqarorlashguncha, ehtimol kompilyatsiya vaqtidagi xatolikka o'zgartiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // XAVFSIZLIK: Biz allaqachon noldan vahima oldik va qurilish bilan ta'minladik
        // sublitsiyaning uzunligi N ning ko'paytmasi ekanligi.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Dilimning boshidan boshlab, bir vaqtning o'zida tilimning `N` elementlari ustidan iteratorni qaytaradi.
    ///
    /// Qismlar massiv ma'lumotnomalari bo'lib, bir-birining ustiga chiqmaydi.
    /// Agar `N` tilim uzunligini taqsimlamasa, u holda `N-1` gacha bo'lgan oxirgi elementlar chiqarib tashlanadi va ularni iteratorning `remainder` funktsiyasidan olish mumkin.
    ///
    ///
    /// Ushbu usul [`chunks_exact`] ning umumiy umumiy ekvivalenti.
    ///
    /// # Panics
    ///
    /// Panics, agar `N` 0 bo'lsa, bu usul barqarorlashguncha, ehtimol kompilyatsiya vaqtidagi xatolikka o'zgartiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Qolgan joy yo'q deb o'ylab, tilimni `N`-elementli massivlar bo'lagiga ajratadi.
    ///
    ///
    /// # Safety
    ///
    /// Buni faqat qachon deb atash mumkin
    /// - Dilim to'liq "N`-element" qismlariga bo'linadi (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // XAVFSIZLIK: 1 elementli qismlar hech qachon qoldiqqa ega bo'lmaydi
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // XAVFSIZLIK: (6) bo'lagi uzunligi 3 ga ko'paytiriladi
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Bu asossiz bo'lar edi:
    /// // bo'laklarga ruxsat bering: &[[_;5]]= slice.as_chunks_unchecked_mut()//Dilim uzunligi 5 ta bo'lakning ko'paytmasi emas:&[[_;0]]= slice.as_chunks_unchecked_mut()//Nol uzunlikdagi bo'laklarga hech qachon yo'l qo'yilmaydi
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // XAVFSIZLIK: Bizning shartimiz bunga qo'ng'iroq qilish uchun kerak bo'lgan narsadir
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // XAVFSIZLIK: Biz ichiga bir bo'lak `new_len * N` elementlarini tashladik
        // ko'plab `N` elementlari bo'laklari bo'lgan `new_len` bo'lagi.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Tilni tilim boshidan boshlab `N`-elementli massivlar bo'lagi va uzunligi `N` dan kam bo'lgan qoldiq bo'laklarga bo'linadi.
    ///
    ///
    /// # Panics
    ///
    /// Panics, agar `N` 0 bo'lsa, bu usul barqarorlashguncha, ehtimol kompilyatsiya vaqtidagi xatolikka o'zgartiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // XAVFSIZLIK: Biz allaqachon noldan vahima oldik va qurilish bilan ta'minladik
        // sublitsiyaning uzunligi N ning ko'paytmasi ekanligi.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Tilni oxiridan boshlab `N`-elementli massivlar bo'lagi va uzunligi `N` dan kam bo'lgan qoldiq bo'laklarga bo'linadi.
    ///
    ///
    /// # Panics
    ///
    /// Panics, agar `N` 0 bo'lsa, bu usul barqarorlashguncha, ehtimol kompilyatsiya vaqtidagi xatolikka o'zgartiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // XAVFSIZLIK: Biz allaqachon noldan vahima oldik va qurilish bilan ta'minladik
        // sublitsiyaning uzunligi N ning ko'paytmasi ekanligi.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Dilimning boshidan boshlab, bir vaqtning o'zida tilimning `N` elementlari ustidan iteratorni qaytaradi.
    ///
    /// Qismlar o'zgaruvchan qator ma'lumotlari bo'lib, ular bir-biriga mos kelmaydi.
    /// Agar `N` tilim uzunligini taqsimlamasa, u holda `N-1` gacha bo'lgan oxirgi elementlar chiqarib tashlanadi va ularni iteratorning `into_remainder` funktsiyasidan olish mumkin.
    ///
    ///
    /// Ushbu usul [`chunks_exact_mut`] ning umumiy umumiy ekvivalenti.
    ///
    /// # Panics
    ///
    /// Panics, agar `N` 0 bo'lsa, bu usul barqarorlashguncha, ehtimol kompilyatsiya vaqtidagi xatolikka o'zgartiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Tilimning boshidan boshlab, tilimning windows ning windows elementlari ustiga tushgan iteratorni qaytaradi.
    ///
    ///
    /// Bu [`windows`] ning umumiy umumiy ekvivalenti.
    ///
    /// Agar `N` tilim kattaligidan katta bo'lsa, u holda windows bo'lmaydi.
    ///
    /// # Panics
    ///
    /// Agar `N` 0 bo'lsa, Panics.
    /// Ushbu tekshiruv, ehtimol bu usul barqarorlashguncha kompilyatsiya vaqtidagi xatolikka o'zgartiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Dilimning oxiridan boshlab, bir vaqtning o'zida tilimning `chunk_size` elementlari ustidan iteratorni qaytaradi.
    ///
    /// Parchalar tilim bo'lib, ular bir-birining ustiga chiqmaydi.Agar `chunk_size` tilim uzunligini ajratmasa, u holda oxirgi qism `chunk_size` uzunlikka ega bo'lmaydi.
    ///
    /// Ushbu iteratorning har doim to'liq `chunk_size` elementlarining qismini qaytaradigan variantini [`rchunks_exact`]-ga qarang va xuddi shu iterator uchun [`chunks`]-ni, lekin tilim boshidan boshlab.
    ///
    ///
    /// # Panics
    ///
    /// Agar `chunk_size` 0 bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Dilimning oxiridan boshlab, bir vaqtning o'zida tilimning `chunk_size` elementlari ustidan iteratorni qaytaradi.
    ///
    /// Parchalar o'zgaruvchan bo'laklar bo'lib, ular bir-birining ustiga chiqmaydi.Agar `chunk_size` tilim uzunligini ajratmasa, u holda oxirgi qism `chunk_size` uzunlikka ega bo'lmaydi.
    ///
    /// Ushbu iteratorning har doim to'liq `chunk_size` elementlarining qismini qaytaradigan variantini [`rchunks_exact_mut`]-ga qarang va xuddi shu iterator uchun [`chunks_mut`]-ni, lekin tilim boshidan boshlab.
    ///
    ///
    /// # Panics
    ///
    /// Agar `chunk_size` 0 bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Dilimning oxiridan boshlab, bir vaqtning o'zida tilimning `chunk_size` elementlari ustidan iteratorni qaytaradi.
    ///
    /// Parchalar tilim bo'lib, ular bir-birining ustiga chiqmaydi.
    /// Agar `chunk_size` tilim uzunligini taqsimlamasa, u holda `chunk_size-1` gacha bo'lgan oxirgi elementlar chiqarib tashlanadi va ularni iteratorning `remainder` funktsiyasidan olish mumkin.
    ///
    /// To'liq `chunk_size` elementlariga ega bo'lgan har bir qism tufayli kompilyator ko'pincha olingan kodni [`chunks`] ga qaraganda yaxshiroq optimallashtirishi mumkin.
    ///
    /// Qolgan qismini kichikroq qism sifatida qaytaradigan ushbu iteratorning variantini [`rchunks`]-ga qarang, va xuddi shu iterator uchun [`chunks_exact`], lekin tilim boshidan boshlanadi.
    ///
    ///
    /// # Panics
    ///
    /// Agar `chunk_size` 0 bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Dilimning oxiridan boshlab, bir vaqtning o'zida tilimning `chunk_size` elementlari ustidan iteratorni qaytaradi.
    ///
    /// Parchalar o'zgaruvchan bo'laklar bo'lib, ular bir-birining ustiga chiqmaydi.
    /// Agar `chunk_size` tilim uzunligini taqsimlamasa, u holda `chunk_size-1` gacha bo'lgan oxirgi elementlar chiqarib tashlanadi va ularni iteratorning `into_remainder` funktsiyasidan olish mumkin.
    ///
    /// To'liq `chunk_size` elementlariga ega bo'lgan har bir qism tufayli kompilyator natijada olingan kodni [`chunks_mut`] ga qaraganda yaxshiroq optimallashtirishi mumkin.
    ///
    /// Qolgan qismini kichikroq qism sifatida qaytaradigan ushbu iteratorning bir variantini [`rchunks_mut`]-ga qarang va xuddi shu iterator uchun [`chunks_exact_mut`], lekin tilim boshidan boshlanadi.
    ///
    ///
    /// # Panics
    ///
    /// Agar `chunk_size` 0 bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Elementlarni bir-biridan ajratib olish uchun predikat yordamida elementlarning bir-birining ustiga chiqmaydigan qismlarini hosil qiladigan iteratorni qaytaradi.
    ///
    /// Predikat o'z-o'zidan ergashgan ikkita elementga, ya'ni `slice[0]` va `slice[1]`-ga, keyin `slice[1]` va `slice[2]`-ga va boshqalarga chaqirilishini anglatadi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ushbu usul saralangan pastki qismlarni ajratib olish uchun ishlatilishi mumkin:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Elementlarni bir-biridan ajratib turadigan predikat yordamida bir-birining ustiga chiqadigan o'zgaruvchan o'zgaruvchan elementlarini hosil qiladigan iteratorni qaytaradi.
    ///
    /// Predikat o'z-o'zidan ergashgan ikkita elementga, ya'ni `slice[0]` va `slice[1]`-ga, keyin `slice[1]` va `slice[2]`-ga va boshqalarga chaqirilishini anglatadi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ushbu usul saralangan pastki qismlarni ajratib olish uchun ishlatilishi mumkin:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Bir bo'lakni indeks bo'yicha ikkiga ajratadi.
    ///
    /// Birinchisida `[0, mid)` (`mid` indeksining o'zi bundan mustasno), ikkinchisida `[mid, len)` (`len` indeksining o'zi bundan mustasno) barcha indekslari bo'ladi.
    ///
    ///
    /// # Panics
    ///
    /// Agar `mid > len` bo'lsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // XAVFSIZLIK: `[ptr; mid]` va `[mid; len]` `self` ichida, ular
        // `from_raw_parts_mut` talablarini bajaradi.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Bir o'zgaruvchan bo'lakni indeks bo'yicha ikkiga ajratadi.
    ///
    /// Birinchisida `[0, mid)` (`mid` indeksining o'zi bundan mustasno), ikkinchisida `[mid, len)` (`len` indeksining o'zi bundan mustasno) barcha indekslari bo'ladi.
    ///
    ///
    /// # Panics
    ///
    /// Agar `mid > len` bo'lsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // XAVFSIZLIK: `[ptr; mid]` va `[mid; len]` `self` ichida, ular
        // `from_raw_parts_mut` talablarini bajaradi.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Chegaralarni tekshirmasdan, bitta bo'lakni indeks bo'yicha ikkiga ajratadi.
    ///
    /// Birinchisida `[0, mid)` (`mid` indeksining o'zi bundan mustasno), ikkinchisida `[mid, len)` (`len` indeksining o'zi bundan mustasno) barcha indekslari bo'ladi.
    ///
    ///
    /// Xavfsiz alternativa uchun [`split_at`]-ga qarang.
    ///
    /// # Safety
    ///
    /// Ushbu usulni chegaradan tashqaridagi indeks bilan chaqirish *[noefined behavior]** natijada havola ishlatilmasa ham.Chaqiruvchi `0 <= mid <= self.len()` ekanligini ta'minlashi kerak.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // XAVFSIZLIK: Qo'ng'iroq qiluvchi `0 <= mid <= self.len()`-ni tekshirishi kerak
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Bir o'zgaruvchan bo'lakni indeks bo'yicha ikkiga ajratadi, chegaralarni tekshirmasdan.
    ///
    /// Birinchisida `[0, mid)` (`mid` indeksining o'zi bundan mustasno), ikkinchisida `[mid, len)` (`len` indeksining o'zi bundan mustasno) barcha indekslari bo'ladi.
    ///
    ///
    /// Xavfsiz alternativa uchun [`split_at_mut`]-ga qarang.
    ///
    /// # Safety
    ///
    /// Ushbu usulni chegaradan tashqaridagi indeks bilan chaqirish *[noefined behavior]** natijada havola ishlatilmasa ham.Chaqiruvchi `0 <= mid <= self.len()` ekanligini ta'minlashi kerak.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // XAVFSIZLIK: Qo'ng'iroq qiluvchi `0 <= mid <= self.len()`-ni tekshirishi kerak.
        //
        // `[ptr; mid]` va `[mid; len]` bir-biriga mos kelmaydi, shuning uchun o'zgaruvchan ma'lumotni qaytarish yaxshi.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred`-ga mos keladigan elementlar bilan ajratilgan pastki qismlarga iteratorni qaytaradi.
    /// Mos keladigan element pastki qismlarda mavjud emas.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Agar birinchi element mos keladigan bo'lsa, bo'sh bo'lak iterator tomonidan qaytarilgan birinchi element bo'ladi.
    /// Xuddi shunday, agar tilimdagi oxirgi element mos keladigan bo'lsa, bo'sh bo'lak iterator tomonidan qaytarilgan oxirgi element bo'ladi:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Agar ikkita mos keladigan element to'g'ridan-to'g'ri qo'shni bo'lsa, ular orasida bo'sh bo'lak bo'ladi:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred` ga mos keladigan elementlar bilan ajratilgan o'zgaruvchan pastki qismlar ustiga iteratorni qaytaradi.
    /// Mos keladigan element pastki qismlarda mavjud emas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred`-ga mos keladigan elementlar bilan ajratilgan pastki qismlarga iteratorni qaytaradi.
    /// Mos keladigan element oldingi sublitsiyaning oxirida terminator sifatida mavjud.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Agar tilimning oxirgi elementi mos kelsa, u element oldingi tilimning terminatori hisoblanadi.
    ///
    /// Ushbu tilim iterator tomonidan qaytarilgan so'nggi element bo'ladi.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred` ga mos keladigan elementlar bilan ajratilgan o'zgaruvchan pastki qismlar ustiga iteratorni qaytaradi.
    /// Tegishli element oldingi sublitsiyada terminator sifatida mavjud.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// `pred` ga mos keladigan elementlar bilan ajratilgan, tilimning oxiridan boshlab va orqaga qarab ishlaydigan bo'laklarga iteratorni qaytaradi.
    /// Mos keladigan element pastki qismlarda mavjud emas.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()`-da bo'lgani kabi, agar birinchi yoki oxirgi element mos keladigan bo'lsa, bo'sh bo'lak iterator tomonidan qaytarilgan birinchi (yoki oxirgi) element bo'ladi.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// `pred` ga mos keladigan elementlar bilan ajratilgan o'zgaruvchan pastki qismlarga takrorlovchi qaytaradi, tilim oxiridan boshlab va orqaga qarab ishlaydi.
    /// Mos keladigan element pastki qismlarda mavjud emas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Ko'pgina `n` elementlarini qaytarish bilan cheklangan, `pred` ga mos keladigan elementlar bilan ajratilgan pastki qismlarga iteratorni qaytaradi.
    /// Mos keladigan element pastki qismlarda mavjud emas.
    ///
    /// Qaytgan oxirgi element, agar mavjud bo'lsa, tilimning qolgan qismini o'z ichiga oladi.
    ///
    /// # Examples
    ///
    /// Bo'limni 3 ga bo'linadigan raqamlarga bir marta chop eting (ya'ni, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Ko'pgina `n` elementlarini qaytarish bilan cheklangan, `pred` ga mos keladigan elementlar bilan ajratilgan pastki qismlarga iteratorni qaytaradi.
    /// Mos keladigan element pastki qismlarda mavjud emas.
    ///
    /// Qaytgan oxirgi element, agar mavjud bo'lsa, tilimning qolgan qismini o'z ichiga oladi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Ko'p `n` elementlarini qaytarish bilan cheklangan `pred` bilan mos keladigan elementlar bilan ajratilgan pastki qismlarga iteratorni qaytaradi.
    /// Bu tilim oxiridan boshlanadi va orqaga qarab ishlaydi.
    /// Mos keladigan element pastki qismlarda mavjud emas.
    ///
    /// Qaytgan oxirgi element, agar mavjud bo'lsa, tilimning qolgan qismini o'z ichiga oladi.
    ///
    /// # Examples
    ///
    /// Bo'limni oxiridan boshlab 3 ga bo'linadigan raqamlarga bir marta chop eting (ya'ni, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Ko'p `n` elementlarini qaytarish bilan cheklangan `pred` bilan mos keladigan elementlar bilan ajratilgan pastki qismlarga iteratorni qaytaradi.
    /// Bu tilim oxiridan boshlanadi va orqaga qarab ishlaydi.
    /// Mos keladigan element pastki qismlarda mavjud emas.
    ///
    /// Qaytgan oxirgi element, agar mavjud bo'lsa, tilimning qolgan qismini o'z ichiga oladi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Agar tilimda berilgan qiymatga ega element bo'lsa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Agar sizda `&T` bo'lmasa, faqat `T: Borrow<U>` (masalan, `T: Borrow<U>`) bo'lsa
    /// String: qarz oling<str>`), siz `iter().any` dan foydalanishingiz mumkin:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // tilim `String`
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` bilan qidirish
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Agar `needle` tilimning prefiksi bo'lsa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Har doim `true` qaytaradi, agar `needle` bo'sh bo'lak bo'lsa:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Agar `needle` tilim qo'shimchasi bo'lsa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Har doim `true` qaytaradi, agar `needle` bo'sh bo'lak bo'lsa:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Prefiksi olib tashlangan sublitsiyani qaytaradi.
    ///
    /// Agar tilim `prefix` bilan boshlangan bo'lsa, subfitsiyani prefiksdan keyin `Some` ga o'ralgan holda qaytaradi.
    /// Agar `prefix` bo'sh bo'lsa, shunchaki asl tilimni qaytaring.
    ///
    /// Agar tilim `prefix` bilan boshlanmasa, `None` qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ushbu funktsiya SlicePattern yanada takomillashgan bo'lsa va qachon yozilishini talab qiladi.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Qo'shimchasi olib tashlangan sublitsiyani qaytaradi.
    ///
    /// Agar tilim `suffix` bilan tugasa, subfitsiyani `Some` ga o'ralgan holda qo'shimchadan oldin qaytaradi.
    /// Agar `suffix` bo'sh bo'lsa, shunchaki asl tilimni qaytaring.
    ///
    /// Agar tilim `suffix` bilan tugamasa, `None` ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ushbu funktsiya SlicePattern yanada takomillashgan bo'lsa va qachon yozilishini talab qiladi.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Ikkilik ushbu saralangan bo'lakni ma'lum bir elementni qidiradi.
    ///
    /// Agar qiymat topilsa, unda mos element indeksini o'z ichiga olgan [`Result::Ok`] qaytariladi.
    /// Agar bir nechta o'yin bo'lsa, unda har qanday o'yin qaytarilishi mumkin.
    /// Agar qiymat topilmasa, [`Result::Err`] qaytariladi, unda tartiblangan tartibni saqlagan holda mos keladigan element kiritilishi mumkin bo'lgan indeks mavjud.
    ///
    ///
    /// Shuningdek qarang [`binary_search_by`], [`binary_search_by_key`] va [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// To'rt elementdan iborat qatorni ko'rib chiqadi.
    /// Birinchisi topilgan, o'ziga xos tarzda aniqlangan pozitsiyaga ega;ikkinchisi va uchinchisi topilmadi;to'rtinchisi `[1, 4]`-dagi har qanday pozitsiyaga mos kelishi mumkin.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Agar siz tartiblangan vector-ga element qo'shmoqchi bo'lsangiz, tartiblash tartibini saqlang:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Ikkilik ushbu saralangan bo'lakni taqqoslash funktsiyasi yordamida qidiradi.
    ///
    /// Komparator funktsiyasi, uning tilimi `Less`, `Equal` yoki `Greater` kerakli maqsad ekanligini ko'rsatadigan buyurtma kodini qaytarib, asosiy tilimning tartib tartibiga mos keladigan tartibni amalga oshirishi kerak.
    ///
    ///
    /// Agar qiymat topilsa, unda mos element indeksini o'z ichiga olgan [`Result::Ok`] qaytariladi.Agar bir nechta o'yin bo'lsa, unda har qanday o'yin qaytarilishi mumkin.
    /// Agar qiymat topilmasa, [`Result::Err`] qaytariladi, unda tartiblangan tartibni saqlagan holda mos keladigan element kiritilishi mumkin bo'lgan indeks mavjud.
    ///
    /// Shuningdek qarang [`binary_search`], [`binary_search_by_key`] va [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// To'rt elementdan iborat qatorni ko'rib chiqadi.Birinchisi topilgan, o'ziga xos tarzda aniqlangan pozitsiyaga ega;ikkinchisi va uchinchisi topilmadi;to'rtinchisi `[1, 4]`-dagi har qanday pozitsiyaga mos kelishi mumkin.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // XAVFSIZLIK: qo'ng'iroq quyidagi invariantlar tomonidan xavfsiz amalga oshiriladi:
            // - `mid >= 0`
            // - `mid < size`: `mid` `[left; right)` bilan cheklangan.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Biz o'yinni emas, balki if/else boshqaruv oqimidan foydalanishimizning sababi, o'yinlarni qayta taqqoslash operatsiyalarini bajarish juda sezgir.
            //
            // Bu u8 uchun x86 asm: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Ikkilik ushbu ajratilgan bo'lakni kalit ajratib olish funktsiyasi bilan qidiradi.
    ///
    /// Til tugmachasi bo'yicha tartiblangan deb taxmin qiladi, masalan, xuddi shu tugmachani chiqarish funktsiyasidan foydalangan holda [`sort_by_key`] bilan.
    ///
    /// Agar qiymat topilsa, unda mos element indeksini o'z ichiga olgan [`Result::Ok`] qaytariladi.
    /// Agar bir nechta o'yin bo'lsa, unda har qanday o'yin qaytarilishi mumkin.
    /// Agar qiymat topilmasa, [`Result::Err`] qaytariladi, unda tartiblangan tartibni saqlagan holda mos keladigan element kiritilishi mumkin bo'lgan indeks mavjud.
    ///
    ///
    /// Shuningdek qarang [`binary_search`], [`binary_search_by`] va [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Ikkinchi elementlari bo'yicha saralangan juft tilimdagi to'rtta elementlar qatorini qidiradi.
    /// Birinchisi topilgan, o'ziga xos tarzda aniqlangan pozitsiyaga ega;ikkinchisi va uchinchisi topilmadi;to'rtinchisi `[1, 4]`-dagi har qanday pozitsiyaga mos kelishi mumkin.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // `slice::sort_by_key` crate `alloc`-da bo'lgani uchun Lint rustdoc::broken_intra_doc_links-ga ruxsat beriladi va `core`-ni qurishda hali mavjud emas.
    //
    // quyi oqim crate: #74481-ga havolalar.Primitivlar faqat libstd (#73423)-da hujjatlashtirilganligi sababli, bu amalda hech qachon buzilgan aloqalarga olib kelmaydi.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Dilimni saralaydi, lekin teng elementlarning tartibini saqlay olmasligi mumkin.
    ///
    /// Bunday tartib beqaror (ya'ni teng elementlarni tartibini o'zgartirishi mumkin), joyida (ya'ni ajratmaydi) va *O*(*n*\*log(* n*)) eng yomon holat).
    ///
    /// # Amaldagi dastur
    ///
    /// Amaldagi algoritm Orson Pitersning [pattern-defeating quicksort][pdqsort]-ga asoslangan bo'lib, u tasodifiy kiktsortning tezkor o'rtacha holatini va eng yomon xayajon holatini birlashtirgan holda, ma'lum bir naqshli bo'laklarda chiziqli vaqtga erishishga imkon beradi.
    /// Degeneratsiya holatlarini oldini olish uchun ba'zi randomizatsiyadan foydalanadi, lekin har doim deterministik xatti-harakatni ta'minlash uchun qat'iy seed bilan.
    ///
    /// Odatda barqaror saralashga qaraganda tezroq bo'ladi, faqat bir nechta maxsus holatlar bundan mustasno, masalan, tilim bir nechta birlashtirilgan tartiblangan ketma-ketliklardan iborat bo'lganda.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Kesimni taqqoslash funktsiyasi bilan saralaydi, lekin teng elementlarning tartibini saqlamasligi mumkin.
    ///
    /// Bunday tartib beqaror (ya'ni teng elementlarni tartibini o'zgartirishi mumkin), joyida (ya'ni ajratmaydi) va *O*(*n*\*log(* n*)) eng yomon holat).
    ///
    /// Komparator funktsiyasi tilimdagi elementlarning umumiy tartibini belgilashi kerak.Agar buyurtma jami bo'lmasa, elementlarning tartibi aniqlanmagan.Buyurtma bu umumiy buyurtma, agar u (barcha `a`, `b` va `c` uchun) bo'lsa:
    ///
    /// * jami va antisimmetrik: aynan `a < b`, `a == b` yoki `a > b` bittasi to'g'ri va
    /// * o'tish, `a < b` va `b < c` `a < c` ni nazarda tutadi.Xuddi shu narsa `==` va `>` uchun ham amal qilishi kerak.
    ///
    /// Masalan, [`f64`] [`Ord`] ni amalga oshirmasa ham, chunki `NaN != NaN`, biz tilimda `NaN` mavjud emasligini bilsak, biz `partial_cmp` ni saralash funktsiyamiz sifatida ishlatishimiz mumkin.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Amaldagi dastur
    ///
    /// Amaldagi algoritm Orson Pitersning [pattern-defeating quicksort][pdqsort]-ga asoslangan bo'lib, u tasodifiy kiktsortning tezkor o'rtacha holatini va eng yomon xayajon holatini birlashtirgan holda, ma'lum bir naqshli bo'laklarda chiziqli vaqtga erishishga imkon beradi.
    /// Degeneratsiya holatlarini oldini olish uchun ba'zi randomizatsiyadan foydalanadi, lekin har doim deterministik xatti-harakatni ta'minlash uchun qat'iy seed bilan.
    ///
    /// Odatda barqaror saralashga qaraganda tezroq bo'ladi, faqat bir nechta maxsus holatlar bundan mustasno, masalan, tilim bir nechta birlashtirilgan tartiblangan ketma-ketliklardan iborat bo'lganda.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // teskari tartiblash
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Tilni kalit ajratib olish funktsiyasi bilan saralaydi, lekin teng elementlarning tartibini saqlamasligi mumkin.
    ///
    /// Bunday tartib beqaror (ya'ni teng elementlarni tartibini o'zgartirishi mumkin), joyida (ya'ni ajratmaydi) va *O*(m\* * n *\* log(*n*)) eng yomon holat, bu erda asosiy funktsiya *O*(*m*).
    ///
    /// # Amaldagi dastur
    ///
    /// Amaldagi algoritm Orson Pitersning [pattern-defeating quicksort][pdqsort]-ga asoslangan bo'lib, u tasodifiy kiktsortning tezkor o'rtacha holatini va eng yomon xayajon holatini birlashtirgan holda, ma'lum bir naqshli bo'laklarda chiziqli vaqtga erishishga imkon beradi.
    /// Degeneratsiya holatlarini oldini olish uchun ba'zi randomizatsiyadan foydalanadi, lekin har doim deterministik xatti-harakatni ta'minlash uchun qat'iy seed bilan.
    ///
    /// Kalit qo'ng'iroq qilish strategiyasidan kelib chiqqan holda, [`sort_unstable_by_key`](#method.sort_unstable_by_key), agar asosiy funktsiya qimmat bo'lgan hollarda, [`sort_by_cached_key`](#method.sort_by_cached_key) dan sekinroq bo'lishi mumkin.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// `index`-dagi element so'nggi saralangan holatida bo'lishi uchun tilimni tartibini o'zgartiring.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// `index`-dagi element so'nggi saralangan holatida bo'lishi uchun kesimni taqqoslash funktsiyasi bilan qayta tartiblang.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// `index`-dagi element so'nggi saralangan holatida bo'lishi uchun bo'lakni ajratib olish tugmachasini funktsiyasini o'zgartiring.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// `index`-dagi element so'nggi saralangan holatida bo'lishi uchun tilimni tartibini o'zgartiring.
    ///
    /// Ushbu qayta tartiblash, `i < index` holatidagi har qanday qiymat `j > index` pozitsiyasidagi har qanday qiymatdan kam yoki teng bo'lishiga qo'shimcha xususiyatga ega.
    /// Bundan tashqari, bu qayta tartiblash beqaror (ya'ni
    /// har qanday teng elementlar `index` holatida tugashi mumkin), joyida (ya'ni.)
    /// ajratmaydi) va *O*(*n*) eng yomon holat.
    /// Ushbu funktsiya boshqa kutubxonalarda "kth element" nomi bilan ham tanilgan.
    /// U quyidagi qiymatlarning uchtasini qaytaradi: barcha elementlar berilgan indeksdagi ko'rsatkichdan kichik, berilgan indeksdagi qiymat va barcha elementlar berilgan indeksdan kattaroq.
    ///
    ///
    /// # Amaldagi dastur
    ///
    /// Amaldagi algoritm [`sort_unstable`] uchun ishlatiladigan xuddi shu tezkor algoritmning tez tanlangan qismiga asoslangan.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` bo'lganda Panics, ya'ni har doim bo'sh bo'laklarda panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Mediani toping
    /// v.select_nth_unstable(2);
    ///
    /// // Belgilangan indeksni saralashimizga asoslanib, tilim quyidagilardan biri bo'lishiga biz faqat kafolat beramiz.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index`-dagi element so'nggi saralangan holatida bo'lishi uchun kesimni taqqoslash funktsiyasi bilan qayta tartiblang.
    ///
    /// Ushbu qayta tartiblash `i < index` pozitsiyasidagi har qanday qiymat `j > index` pozitsiyasidagi har qanday qiymatdan kam yoki unga tenglashtiradigan qo'shimcha xususiyatga ega, bu komparator funktsiyasi yordamida.
    /// Bundan tashqari, bu qayta tartiblashtirish beqaror (ya'ni har qanday teng element soni `index` holatiga tushishi mumkin), joyida (ya'ni ajratilmaydi) va *O*(*n*) eng yomon holatda.
    /// Ushbu funktsiya boshqa kutubxonalarda "kth element" nomi bilan ham tanilgan.
    /// U quyidagi qiymatlarning uchligini qaytaradi: berilgan indeksdagi ko'rsatkichdan kichik bo'lgan barcha elementlar, berilgan indeksdagi qiymat va berilgan indeksdagi kattaroq barcha elementlar, berilgan taqqoslash funktsiyasidan foydalangan holda.
    ///
    ///
    /// # Amaldagi dastur
    ///
    /// Amaldagi algoritm [`sort_unstable`] uchun ishlatiladigan xuddi shu tezkor algoritmning tez tanlangan qismiga asoslangan.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` bo'lganda Panics, ya'ni har doim bo'sh bo'laklarda panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Tilim kamayish tartibida saralanganidek mediani toping.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Belgilangan indeksni saralashimizga asoslanib, tilim quyidagilardan biri bo'lishiga biz faqat kafolat beramiz.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index`-dagi element so'nggi saralangan holatida bo'lishi uchun bo'lakni ajratib olish tugmachasini funktsiyasini o'zgartiring.
    ///
    /// Ushbu qayta tartiblash qo'shimcha xususiyatga ega bo'lib, `i < index` pozitsiyasidagi har qanday qiymat `j > index` pozitsiyasidagi har qanday qiymatdan kichik yoki unga teng bo'ladi, bu kalitni ajratib olish funktsiyasidan foydalangan holda.
    /// Bundan tashqari, bu qayta tartiblashtirish beqaror (ya'ni har qanday teng element soni `index` holatiga tushishi mumkin), joyida (ya'ni ajratilmaydi) va *O*(*n*) eng yomon holatda.
    /// Ushbu funktsiya boshqa kutubxonalarda "kth element" nomi bilan ham tanilgan.
    /// U quyidagi qiymatlarning uchtasini qaytaradi: berilgan indeksdagi qiymatdan kichik bo'lgan barcha elementlar, berilgan indeksdagi qiymat va berilgan indeksdagi kattaroq barcha elementlar, taqdim etilgan kalitlarni chiqarib olish funktsiyasidan foydalangan holda.
    ///
    ///
    /// # Amaldagi dastur
    ///
    /// Amaldagi algoritm [`sort_unstable`] uchun ishlatiladigan xuddi shu tezkor algoritmning tez tanlangan qismiga asoslangan.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` bo'lganda Panics, ya'ni har doim bo'sh bo'laklarda panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Medianni massivni mutloq qiymat bo'yicha saralanganidek qaytaring.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Belgilangan indeksni saralashimizga asoslanib, tilim quyidagilardan biri bo'lishiga biz faqat kafolat beramiz.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Barcha ketma-ket takrorlangan elementlarni tilim oxiriga [`PartialEq`] trait dasturiga muvofiq ko'chiradi.
    ///
    ///
    /// Ikki bo'lakni qaytaradi.Birinchisi ketma-ket takrorlanadigan elementlarni o'z ichiga olmaydi.
    /// Ikkinchisida barcha dublikatlar belgilangan tartibda mavjud emas.
    ///
    /// Agar tilim tartiblangan bo'lsa, birinchi qaytarilgan tilimda dublikatlar bo'lmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Berilgan tenglik munosabatini qondiradigan ketma-ket birinchi elementlardan tashqari barchasini tilim oxiriga ko'chiradi.
    ///
    /// Ikki bo'lakni qaytaradi.Birinchisi ketma-ket takrorlanadigan elementlarni o'z ichiga olmaydi.
    /// Ikkinchisida barcha dublikatlar belgilangan tartibda mavjud emas.
    ///
    /// `same_bucket` funktsiyasi tilimdan ikkita elementga havolalar yuboriladi va elementlarning tengligini taqqoslashni aniqlashi kerak.
    /// Elementlar tilimdagi tartibidan qarama-qarshi tartibda uzatiladi, shuning uchun `same_bucket(a, b)` `true` ni qaytarsa, tilim oxirida `a` siljiydi.
    ///
    ///
    /// Agar tilim tartiblangan bo'lsa, birinchi qaytarilgan tilimda dublikatlar bo'lmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Bizda `self` haqida o'zgaruvchan ma'lumot mavjud bo'lsa ham, biz *o'zboshimchalik bilan* o'zgartirishlarni amalga oshira olmaymiz.`same_bucket` qo'ng'iroqlari panic bo'lishi mumkin, shuning uchun biz tilim har doim yaroqli holatda bo'lishini ta'minlashimiz kerak.
        //
        // Ushbu usulni almashtirish svoplardan foydalanish;Biz barcha elementlar bo'ylab takrorlanamiz va almashtiramiz, shunday qilib oxirida biz saqlamoqchi bo'lgan elementlar old tomonda, biz rad qilishni istaganlar orqada.
        // Keyin tilimni ajratishimiz mumkin.
        // Ushbu operatsiya hali ham `O(n)`.
        //
        // Misol: biz ushbu holatdan boshlaymiz, bu erda `r` "keyingi" ni ifodalaydi
        // o'qing "va `w` next_write` ni ifodalaydi.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // self[r]-ni o'z-o'zini [w-1] bilan taqqoslash, bu dublikat emas, shuning uchun biz self[r] va self[w]-ni almashtiramiz (r==w kabi ta'sir bo'lmaydi) va keyin ikkala r va w-ni oshiramiz va bizni qoldiramiz:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r]-ni self [w-1] bilan taqqoslaganda, bu qiymat ikki nusxada bo'ladi, shuning uchun biz `r`-ni oshiramiz, ammo hamma narsani o'zgarmay qoldiramiz:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r]-ni o'z-o'zini [w-1] bilan taqqoslash, bu dublikat emas, shuning uchun self[r] va self[w]-ni almashtiring va r va w-ga o'ting:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ikki nusxada emas, takrorlang:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Ikki nusxadagi, tilim advance r. End.W da bo'linish.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // XAVFSIZLIK: `while` sharti `next_read` va `next_write` ga kafolat beradi
        // `len` dan kam, shuning uchun `self` ichida.
        // `prev_ptr_write` `ptr_write` oldidan bitta elementga ishora qiladi, lekin `next_write` 1dan boshlanadi, shuning uchun `prev_ptr_write` hech qachon 0 dan kam bo'lmaydi va tilim ichida bo'ladi.
        // Bu `ptr_read`, `prev_ptr_write` va `ptr_write`-ni ajratish va `ptr.add(next_read)`, `ptr.add(next_write - 1)` va `prev_ptr_write.offset(1)`-dan foydalanish talablariga javob beradi.
        //
        //
        // `next_write` shuningdek, har bir tsikl uchun eng ko'pi bilan bir marta oshiriladi, ya'ni almashtirish kerak bo'lganda hech qanday element o'tkazib yuborilmaydi.
        //
        // `ptr_read` va `prev_ptr_write` hech qachon bir xil elementga ishora qilmaydi.Bu `&mut *ptr_read`, `&mut* prev_ptr_write` xavfsiz bo'lishi uchun talab qilinadi.
        // Tushuntirish shunchaki `next_read >= next_write` har doim to'g'ri, shuning uchun `next_read > next_write - 1` ham.
        //
        //
        //
        //
        //
        unsafe {
            // Xom ko'rsatkichlar yordamida chegaralarni tekshirishdan saqlaning.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Ketma-ket ketma-ket elementlardan boshqasini bir xil tugmachani echib bo'lakning oxiriga o'tkazadi.
    ///
    ///
    /// Ikki bo'lakni qaytaradi.Birinchisi ketma-ket takrorlanadigan elementlarni o'z ichiga olmaydi.
    /// Ikkinchisida barcha dublikatlar belgilangan tartibda mavjud emas.
    ///
    /// Agar tilim tartiblangan bo'lsa, birinchi qaytarilgan tilimda dublikatlar bo'lmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Dilimni birinchi `mid` elementlari oxirigacha, oxirgi `self.len() - mid` elementlari old tomonga o'tadigan qilib bo'lakni joyida aylantiradi.
    /// `rotate_left`-ni chaqirgandan so'ng, avval `mid` indeksidagi element tilimdagi birinchi elementga aylanadi.
    ///
    /// # Panics
    ///
    /// Agar `mid` tilim uzunligidan katta bo'lsa, bu funktsiya panic bo'ladi.Shuni esda tutingki, `mid == self.len()` _not_ panic qiladi va no-op aylanishidir.
    ///
    /// # Complexity
    ///
    /// Lineer (`self.len()`) vaqt ichida) oladi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Sublitsiyani aylantirish:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // XAVFSIZLIK: `[p.add(mid) - mid, p.add(mid) + k)` diapazoni ahamiyatsiz
        // `ptr_rotate` talabiga binoan o'qish va yozish uchun amal qiladi.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Dilimni birinchi `self.len() - k` elementlari oxirigacha, oxirgi `k` elementlari old tomonga o'tadigan qilib bo'lakni joyida aylantiradi.
    /// `rotate_right`-ni chaqirgandan so'ng, avval `self.len() - k` indeksidagi element tilimdagi birinchi elementga aylanadi.
    ///
    /// # Panics
    ///
    /// Agar `k` tilim uzunligidan katta bo'lsa, bu funktsiya panic bo'ladi.Shuni esda tutingki, `k == self.len()` _not_ panic qiladi va no-op aylanishidir.
    ///
    /// # Complexity
    ///
    /// Lineer (`self.len()`) vaqt ichida) oladi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Sublitsiyani aylantirish:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // XAVFSIZLIK: `[p.add(mid) - mid, p.add(mid) + k)` diapazoni ahamiyatsiz
        // `ptr_rotate` talabiga binoan o'qish va yozish uchun amal qiladi.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `value` klonlash orqali `self` ni elementlar bilan to'ldiradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// `self`-ni yopilishni qayta-qayta chaqirib qaytarilgan elementlar bilan to'ldiradi.
    ///
    /// Ushbu usul yangi qadriyatlarni yaratish uchun yopilishdan foydalanadi.Agar siz [`Clone`] berilgan qiymatini xohlasangiz, [`fill`] dan foydalaning.
    /// Agar siz qiymatlarni yaratish uchun [`Default`] trait dan foydalanmoqchi bo'lsangiz, argument sifatida [`Default::default`] ni berishingiz mumkin.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src` dan `self` gacha bo'lgan elementlarni nusxa ko'chiradi.
    ///
    /// `src` uzunligi `self` bilan bir xil bo'lishi kerak.
    ///
    /// Agar `T` `Copy`-ni amalga oshirsa, [`copy_from_slice`]-dan foydalanish yanada samaraliroq bo'lishi mumkin.
    ///
    /// # Panics
    ///
    /// Agar ikkala tilim turli uzunliklarga ega bo'lsa, bu funktsiya panic bo'ladi.
    ///
    /// # Examples
    ///
    /// Ikkita elementni tilimdan boshqasiga klonlash:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Tilimlarning uzunligi bir xil bo'lishi kerakligi sababli, biz manba tilimini to'rt elementdan ikkiga bo'lamiz.
    /// // Agar buni qilmasak, u panic bo'ladi.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust, ma'lum bir ma'lumot doirasiga ma'lum doiradagi o'zgarmas havolalarsiz faqat bitta o'zgaruvchan mos yozuvlar bo'lishi mumkinligini talab qiladi.
    /// Shu sababli, `clone_from_slice`-ni bitta bo'lakda ishlatishga urinish kompilyatsiya ishlamay qolishiga olib keladi:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Buning ustida ishlash uchun biz [`split_at_mut`] yordamida tilimdan ikkita alohida pastki bo'lak yaratishimiz mumkin:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Memcpy yordamida `src` dan `self` gacha bo'lgan barcha elementlarni nusxa ko'chiradi.
    ///
    /// `src` uzunligi `self` bilan bir xil bo'lishi kerak.
    ///
    /// Agar `T` `Copy` ni amalga oshirmasa, [`clone_from_slice`] dan foydalaning.
    ///
    /// # Panics
    ///
    /// Agar ikkala tilim turli uzunliklarga ega bo'lsa, bu funktsiya panic bo'ladi.
    ///
    /// # Examples
    ///
    /// Ikkita elementni tilimdan boshqasiga nusxalash:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Tilimlarning uzunligi bir xil bo'lishi kerakligi sababli, biz manba tilimini to'rt elementdan ikkiga bo'lamiz.
    /// // Agar buni qilmasak, u panic bo'ladi.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust, ma'lum bir ma'lumot doirasiga ma'lum doiradagi o'zgarmas havolalarsiz faqat bitta o'zgaruvchan mos yozuvlar bo'lishi mumkinligini talab qiladi.
    /// Shu sababli, `copy_from_slice`-ni bitta bo'lakda ishlatishga urinish kompilyatsiya ishlamay qolishiga olib keladi:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Buning ustida ishlash uchun biz [`split_at_mut`] yordamida tilimdan ikkita alohida pastki bo'lak yaratishimiz mumkin:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Qo'ng'iroq qilish saytini shishirmaslik uchun panic kod yo'li sovuq funktsiyaga kiritildi.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // XAVFSIZLIK: `self` ta'rifi bo'yicha `self.len()` elementlari uchun amal qiladi va `src` shunday edi
        // bir xil uzunlikka ega ekanligi tekshirildi.
        // O'zgaruvchan havolalar eksklyuziv bo'lgani uchun tilimlar bir-birining ustiga chiqa olmaydi.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Memmove yordamida elementlarni tilimning bir qismidan ikkinchi qismiga ko'chiradi.
    ///
    /// `src` nusxa ko'chirish uchun `self` doirasidagi interval.
    /// `dest` ko'chirilishi kerak bo'lgan `self` oralig'idagi boshlang'ich indeksidir, u uzunligi `src` bilan bir xil bo'ladi.
    /// Ikki diapazon bir-biri bilan qoplanishi mumkin.
    /// Ikki diapazonning uchlari `self.len()` dan kam yoki unga teng bo'lishi kerak.
    ///
    /// # Panics
    ///
    /// Ushbu funktsiya panic bo'ladi, agar har qanday diapazon tilim oxiridan oshsa yoki `src` tugashi boshlanishidan oldin bo'lsa.
    ///
    ///
    /// # Examples
    ///
    /// To'rt baytni tilimga nusxalash:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // XAVFSIZLIK: `ptr::copy` uchun shartlar barchasi yuqorida tekshirilgan,
        // `ptr::add` uchun bo'lgani kabi.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `self` dagi barcha elementlarni `other` bilan almashtiradi.
    ///
    /// `other` uzunligi `self` bilan bir xil bo'lishi kerak.
    ///
    /// # Panics
    ///
    /// Agar ikkala tilim turli uzunliklarga ega bo'lsa, bu funktsiya panic bo'ladi.
    ///
    /// # Example
    ///
    /// Ikki elementni bo'laklarga almashtirish:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust, ma'lum doiradagi ma'lum bir ma'lumotga faqat bitta o'zgaruvchan mos yozuvlar bo'lishi mumkinligini talab qiladi.
    ///
    /// Shu sababli, `swap_with_slice`-ni bitta bo'lakda ishlatishga urinish kompilyatsiya etishmovchiligiga olib keladi:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Buning ustida ishlash uchun [`split_at_mut`] yordamida tilimdan ikkita aniq o'zgaruvchan pastki bo'laklarni yaratishimiz mumkin:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // XAVFSIZLIK: `self` ta'rifi bo'yicha `self.len()` elementlari uchun amal qiladi va `src` shunday edi
        // bir xil uzunlikka ega ekanligi tekshirildi.
        // O'zgaruvchan havolalar eksklyuziv bo'lgani uchun tilimlar bir-birining ustiga chiqa olmaydi.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}` uchun o'rta va oxirgi tilim uzunliklarini hisoblash funktsiyasi.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Biz `rest` haqida nima qilsak, u qancha "U" sonini eng past "T" soniga qo'yishimiz mumkinligini aniqlaymiz.
        //
        // Va har bir bunday "multiple" uchun qancha "T" kerak.
        //
        // Masalan T=u8 U=u16 ni ko'rib chiqing.Keyin biz 2 U ga 1 U qo'yishimiz mumkin.Oddiy.
        // Endi, masalan, size_of: : holatini ko'rib chiqing.<T>=16, hajmi_of::<U>=24.</u>
        // `rest` tilimidagi har 3 Ts o'rniga 2 Bizni qo'yishimiz mumkin.
        // Biroz murakkabroq.
        //
        // Buni hisoblash uchun formulalar:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Kengaytirilgan va soddalashtirilgan:
        //
        // Biz=hajmi_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Yaxshiyamki, bularning barchasi doimiy ravishda baholanadi ... bu erda ishlash muhim emas!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterning takrorlanadigan algoritmi Biz hali ham bu `const fn` ni qilishimiz kerak (va agar shunday qilsak, rekursiv algoritmga qaytishimiz kerak), chunki bularning barchasini to'xtatish uchun llvm ga tayanish ... bu menga noqulaylik tug'diradi.
            //
            //

            // XAVFSIZLIK: `a` va `b` nolga teng bo'lmagan qiymatlar sifatida tekshiriladi.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // b ning 2 omillarini olib tashlang
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // XAVFSIZLIK: `b` nolga teng emasligi tekshiriladi.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Ushbu bilimlarga ega bo'lib, biz qancha "U" ga sig'inishimiz mumkinligini bilib olamiz!
        let us_len = self.len() / ts * us;
        // Va keyingi tilimda qancha "T" bo'ladi!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Tilni boshqa turdagi bo'lakka o'tkazing, turlarning hizalanishini ta'minlang.
    ///
    /// Ushbu usul tilimni uchta aniq bo'lakka ajratadi: prefiks, yangi turga to'g'ri tekislangan o'rta bo'lak va qo'shimchalar bo'lagi.
    /// Usul o'rta bo'lakni ma'lum bir turdagi va kiritilgan qism uchun mumkin bo'lgan eng katta uzunlikka aylantirishi mumkin, ammo faqat sizning algoritmingiz ishlashi uning to'g'riligiga emas, balki bog'liq bo'lishi kerak.
    ///
    /// Kiritilgan ma'lumotlarning hammasi prefiks yoki qo'shimchaning bo'lagi sifatida qaytarilishi mumkin.
    ///
    /// `T` kirish elementi yoki `U` chiqish elementi nol o'lchovli bo'lganda va hech qanday bo'linmasdan asl tilimni qaytaradigan bo'lsa, bu usul hech qanday maqsadga ega emas.
    ///
    /// # Safety
    ///
    /// Ushbu usul aslida qaytarilgan o'rta bo'lakdagi elementlarga nisbatan `transmute` hisoblanadi, shuning uchun `transmute::<T, U>`-ga tegishli barcha odatiy ogohlantirishlar ham shu erda qo'llaniladi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Shuni esda tutingki, ushbu funktsiyaning aksariyati doimiy ravishda baholanadi,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // maxsus ZST-lar bilan ishlang, ya'ni ularni umuman ishlatmang.
            return (self, &[], &[]);
        }

        // Birinchidan, birinchi va ikkinchi bo'laklarni qaysi nuqtada ajratishimizni aniqlang.
        // ptr.align_offset bilan oson.
        let ptr = self.as_ptr();
        // XAVFSIZLIK: Xavfsizlik bo'yicha batafsil izoh uchun `align_to_mut` usulini ko'ring.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // XAVFSIZLIK: endi `rest` aniq moslashtirilgan, shuning uchun quyida joylashgan `from_raw_parts` yaxshi,
            // chunki qo'ng'iroq qiluvchi biz `T`-ni `U`-ga xavfsiz uzatishni kafolatlaydi.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Tilni boshqa turdagi bo'lakka o'tkazing, turlarning hizalanishini ta'minlang.
    ///
    /// Ushbu usul tilimni uchta aniq bo'lakka ajratadi: prefiks, yangi turga to'g'ri tekislangan o'rta bo'lak va qo'shimchalar bo'lagi.
    /// Usul o'rta bo'lakni ma'lum bir turdagi va kiritilgan qism uchun mumkin bo'lgan eng katta uzunlikka aylantirishi mumkin, ammo faqat sizning algoritmingiz ishlashi uning to'g'riligiga emas, balki bog'liq bo'lishi kerak.
    ///
    /// Kiritilgan ma'lumotlarning hammasi prefiks yoki qo'shimchaning bo'lagi sifatida qaytarilishi mumkin.
    ///
    /// `T` kirish elementi yoki `U` chiqish elementi nol o'lchovli bo'lganda va hech qanday bo'linmasdan asl tilimni qaytaradigan bo'lsa, bu usul hech qanday maqsadga ega emas.
    ///
    /// # Safety
    ///
    /// Ushbu usul aslida qaytarilgan o'rta bo'lakdagi elementlarga nisbatan `transmute` hisoblanadi, shuning uchun `transmute::<T, U>`-ga tegishli barcha odatiy ogohlantirishlar ham shu erda qo'llaniladi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Shuni esda tutingki, ushbu funktsiyaning aksariyati doimiy ravishda baholanadi,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // maxsus ZST-lar bilan ishlang, ya'ni ularni umuman ishlatmang.
            return (self, &mut [], &mut []);
        }

        // Birinchidan, birinchi va ikkinchi bo'laklarni qaysi nuqtada ajratishimizni aniqlang.
        // ptr.align_offset bilan oson.
        let ptr = self.as_ptr();
        // XAVFSIZLIK: Bu erda biz U uchun hizalangan ko'rsatgichlardan foydalanamiz
        // qolgan usul.Bu ko'rsatgichni&[T] ga U tomon yo'naltirilgan hizalama bilan o'tkazish orqali amalga oshiriladi.
        // `crate::ptr::align_offset` to'g'ri moslashtirilgan va to'g'ri `ptr` ko'rsatkichi bilan chaqiriladi (u `self` ga ishora qiladi) va ikkitaning kuchi (chunki u U uchun hizalamadan kelib chiqadi), uning xavfsizlik cheklovlarini qondiradi.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Shundan so'ng biz `rest`-dan yana foydalana olmaymiz, bu uning `mut_ptr` taxallusini bekor qiladi!XAVFSIZLIK: `align_to` uchun sharhlarni ko'ring.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Ushbu tilim elementlari saralanganligini tekshiradi.
    ///
    /// Ya'ni, har bir `a` elementi va uning quyidagi `b` elementi uchun `a <= b` bo'lishi kerak.Agar tilim to'liq nolga yoki bitta elementga ega bo'lsa, `true` qaytariladi.
    ///
    /// E'tibor bering, agar `Self::Item` faqat `PartialOrd` bo'lsa, lekin `Ord` bo'lmasa, yuqoridagi ta'rif shuni anglatadiki, agar ketma-ket ikkita element taqqoslanmasa, bu funktsiya `false` ni qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Ushbu tilim elementlari berilgan taqqoslash funktsiyasi yordamida saralanganligini tekshiradi.
    ///
    /// `PartialOrd::partial_cmp` o'rniga, bu funktsiya ikkita elementning tartibini aniqlash uchun berilgan `compare` funktsiyasidan foydalanadi.
    /// Bundan tashqari, bu [`is_sorted`] ga teng;qo'shimcha ma'lumot olish uchun uning hujjatlariga qarang.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Ushbu tilim elementlari berilgan tugmachani chiqarish funktsiyasi yordamida saralanganligini tekshiradi.
    ///
    /// To'g'ridan-to'g'ri tilim elementlarini taqqoslash o'rniga, bu funktsiya `f` tomonidan aniqlangan elementlarning kalitlarini taqqoslaydi.
    /// Bundan tashqari, bu [`is_sorted`] ga teng;qo'shimcha ma'lumot olish uchun uning hujjatlariga qarang.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Berilgan predikat bo'yicha (ikkinchi qismning birinchi elementi indeksiga) ko'ra bo'lim nuqtasining indeksini qaytaradi.
    ///
    /// Tilim berilgan predikat bo'yicha bo'lingan deb taxmin qilinadi.
    /// Bu shuni anglatadiki, predikat haqiqiy qaytadigan barcha elementlar tilimning boshida va predikat yolg'on qaytaradigan barcha elementlar oxirida joylashgan.
    ///
    /// Masalan, [7, 15, 3, 5, 4, 12, 6] predmetat ostida bo'linadi x% 2!=0 (barcha g'alati raqamlar boshida, hammasi oxirida ham).
    ///
    /// Agar ushbu tilim bo'linmasa, qaytarilgan natija aniqlanmagan va ma'nosiz bo'ladi, chunki bu usul bir xil ikkilik qidiruvni amalga oshiradi.
    ///
    /// Shuningdek qarang [`binary_search`], [`binary_search_by`] va [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // XAVFSIZLIK: qachon `left < right`, `left <= mid < right`.
            // Shuning uchun `left` har doim ko'payadi va `right` har doim kamayadi va ulardan ikkitasi tanlanadi.Ikkala holatda ham `left <= right` qoniqtiriladi.Shuning uchun bir qadamda `left < right` bo'lsa, keyingi bosqichda `left <= right` qoniqtiriladi.
            //
            // Shuning uchun `left != right` ekan, `0 <= left < right <= len` qoniqtiriladi va agar bu holat `0 <= mid < len` ham qondirilsa.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Biz ularni bir xil uzunlikda aniq kesib olishimiz kerak
        // optimallashtiruvchiga chegaralarni tekshirishni osonlashtirish uchun.
        // Bunga ishonib bo'lmaydiganligi sababli, bizda T: Copy uchun aniq ixtisoslashuv mavjud.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Bo'sh bo'lak hosil qiladi.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// O'zgaruvchan bo'sh bo'lak hosil qiladi.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Hozirda faqat `strip_prefix` va `strip_suffix` tomonidan ishlatiladigan tilimdagi naqshlar.
/// future nuqtasida biz `core::str::Pattern`-ni (yozish paytida `str` bilan cheklangan) tilimlarga umumlashtiramiz degan umiddamiz, keyin bu trait almashtiriladi yoki bekor qilinadi.
///
pub trait SlicePattern {
    /// Mos keladigan tilimning element turi.
    type Item;

    /// Hozirda `SlicePattern` iste'molchilari tilimga muhtoj.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}