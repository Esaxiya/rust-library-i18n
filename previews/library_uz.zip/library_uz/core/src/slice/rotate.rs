// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` diapazonini shunday o'zgartiradiki, `mid` dagi element birinchi elementga aylansin.Teng ravishda, `left` elementlarini chapga yoki `right` elementlarini o'ngga aylantiradi.
///
/// # Safety
///
/// Belgilangan diapazon o'qish va yozish uchun amal qilishi kerak.
///
/// # Algorithm
///
/// Algoritm 1 kichik `left + right` qiymatlari yoki katta `T` uchun ishlatiladi.
/// Elementlar `mid - left` dan boshlanib, `left + right` moduli bo'yicha `right` qadamlari bilan birma-bir so'nggi holatiga o'tkaziladi, faqat bitta vaqtinchalik kerak bo'ladi.
/// Oxir-oqibat, biz `mid - left`-ga qaytib kelamiz.
/// Ammo, agar `gcd(left + right, right)` 1 bo'lmasa, yuqoridagi qadamlar elementlardan o'tkazib yuborildi.
/// Masalan:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Yaxshiyamki, yakunlangan elementlar orasidagi o'tkazib yuborilgan elementlarning soni har doim teng bo'ladi, shuning uchun biz faqat o'zimizning boshlang'ich pozitsiyamizni almashtirib, ko'proq turlarni bajarishimiz mumkin (aylanalarning umumiy soni `gcd(left + right, right)` value)).
///
/// Natijada barcha elementlar bir marta va faqat bir marta yakunlanadi.
///
/// Algoritm 2, agar `left + right` katta bo'lsa, lekin `min(left, right)` stak tamponiga sig'inadigan darajada kichik bo'lsa ishlatiladi.
/// `min(left, right)` elementlari buferga ko'chiriladi, boshqalarga `memmove` qo'llaniladi va buferdagi narsalar ular paydo bo'lgan joyning teskari tomonidagi teshikka qaytariladi.
///
/// Vektorlashtirilishi mumkin bo'lgan algoritmlar `left + right` etarlicha katta bo'lgandan keyin yuqoridagi ko'rsatkichlardan ustun turadi.
/// Algoritm 1 chunking va bir vaqtning o'zida ko'plab turlarni bajarish orqali vektorlashtirilishi mumkin, ammo `left + right` juda katta bo'lmaguncha o'rtacha juda kam turlar mavjud va bitta turning eng yomon holati doimo u erda bo'ladi.
/// Buning o'rniga 3 algoritmi `min(left, right)` elementlarini kichikroq aylantirish muammosi qolguncha takroriy almashtirishdan foydalanadi.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` almashtirish o'rniga chap tomondan sodir bo'lganda.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. agar ushbu holatlar tekshirilmasa, quyida keltirilgan algoritmlar ishlamay qolishi mumkin
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritm 1 Microbenchmarks shuni ko'rsatadiki, tasodifiy siljishlar uchun o'rtacha ko'rsatkich taxminan `left + right == 32` gacha yaxshiroq, ammo eng yomon ko'rsatkich 16 ga yaqinlashadi.
            // 24 o'rta yo'l sifatida tanlandi.
            // Agar `T` hajmi 4 `usize`dan katta bo'lsa, bu algoritm boshqa algoritmlardan ham ustundir.
            //
            //
            let x = unsafe { mid.sub(left) };
            // birinchi davraning boshlanishi
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` qo'lidan oldin `gcd(left + right, right)` ni hisoblash orqali topish mumkin, ammo gcd-ni yon ta'sir sifatida hisoblaydigan bitta tsiklni bajarish, so'ngra qolgan qismini bajarish tezroq
            //
            //
            let mut gcd = right;
            // ko'rsatkichlar shuni ko'rsatadiki, vaqtinchalik vaqtni bir marta o'qish, orqaga nusxalash va keyin oxirigacha yozish o'rniga oxirigacha almashtirish tezroq.
            // Buning sababi, vaqtinchaliklarni almashtirish yoki almashtirish, ikkitasini boshqarish kerak emas, balki ko'chadan faqat bitta xotira manzilidan foydalanishi bilan bog'liq.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` ni oshirib, keyin uning chegaradan tashqarida ekanligini tekshirish o'rniga, `i` keyingi o'sish bo'yicha chegaradan chiqib ketishini tekshiramiz.
                // Bu ko'rsatkichlarni yoki `usize`-ni har qanday o'rashga yo'l qo'ymaydi.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // birinchi davra oxiri
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // `left + right >= 15` bo'lsa, bu shartli bu erda bo'lishi kerak
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // qismni ko'proq dumaloq bilan tugating
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` nol o'lchovli tur emas, shuning uchun uning kattaligiga bo'lish yaxshi.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritm 2 Bu erda `[T; 0]` T ga mos kelishini ta'minlash uchun
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritm 3 almashtirishning muqobil usuli mavjud, bu algoritmning oxirgi almashinuvi qaerda bo'lishini va shu algoritm kabi qo'shni bo'laklarni almashtirish o'rniga ushbu oxirgi qismdan foydalanishni almashtirishni o'z ichiga oladi, ammo bu hali ham tezroq.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}