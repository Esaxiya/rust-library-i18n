//! Bu ifmt tomonidan ishlatiladigan ichki moduldir!ish vaqti.Ushbu tuzilmalar formatlash satrlarini oldindan kompilyatsiya qilish uchun statik massivlarga chiqariladi.
//!
//! Ushbu ta'riflar ularning `ct` ekvivalentlariga o'xshaydi, ammo ularning statik ravishda taqsimlanishi va ish vaqti uchun biroz optimallashtirilganligi bilan farq qiladi.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Formatlashtirish bo'yicha direktivaning bir qismi sifatida so'ralishi mumkin bo'lgan tekislashlar.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Tarkibni chapga tekislash kerakligini ko'rsatuvchi ko'rsatma.
    Left,
    /// Tarkiblar to'g'ri tekislangan bo'lishi kerakligiga ishora.
    Right,
    /// Tarkiblar markazlashtirilgan bo'lishi kerakligiga ishora.
    Center,
    /// Hizalama talab qilinmadi.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) va [precision](https://doc.rust-lang.org/std/fmt/#precision) spetsifikatorlari tomonidan ishlatiladi.
#[derive(Copy, Clone)]
pub enum Count {
    /// Oddiy raqam bilan ko'rsatilgan, qiymatni saqlaydi
    Is(usize),
    /// `$` va `*` sintaksislari yordamida ko'rsatilgan, indeksni `args` formatida saqlaydi
    Param(usize),
    /// Ko'rsatilmagan
    Implied,
}