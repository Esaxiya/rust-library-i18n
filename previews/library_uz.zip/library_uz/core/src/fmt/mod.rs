//! Qatorlarni formatlash va bosib chiqarish uchun yordamchi dasturlar.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` tomonidan qaytarilgan mumkin bo'lgan hizalamalar
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Tarkibni chapga tekislash kerakligini ko'rsatuvchi ko'rsatma.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Tarkiblar to'g'ri tekislangan bo'lishi kerakligiga ishora.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Tarkiblar markazlashtirilgan bo'lishi kerakligiga ishora.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Formatlash usullari bilan qaytarilgan tur.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Xabarni oqimga formatlashda qaytariladigan xato turi.
///
/// Ushbu turdagi xatolik yuz berganidan boshqa xatoni uzatishni qo'llab-quvvatlamaydi.
/// Har qanday qo'shimcha ma'lumot boshqa vositalar orqali uzatilishi uchun tartibga solinishi kerak.
///
/// Shuni esda tutish kerakki, `fmt::Error` turini [`std::io::Error`] yoki [`std::error::Error`] bilan aralashtirib yubormaslik kerak, bu siz ham o'z ichiga olgan bo'lishi mumkin.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// Unicode qabul qiluvchi buferlar yoki oqimlarga yozish yoki formatlash uchun trait.
///
/// Ushbu trait faqat UTF-8 kodlangan ma'lumotlarni qabul qiladi va [flushable] emas.
/// Agar siz faqat Unicode-ni qabul qilmoqchi bo'lsangiz va sizga yuvish kerak bo'lmasa, ushbu trait-ni amalga oshirishingiz kerak;
/// aks holda siz [`std::io::Write`] dasturini amalga oshirishingiz kerak.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Ushbu yozuvchiga mag'lubiyat bo'lagini yozadi va yozish muvaffaqiyatli bo'lganligini qaytaradi.
    ///
    /// Ushbu usul faqat mag'lubiyatning butun qismi muvaffaqiyatli yozilgan taqdirdagina muvaffaqiyatga erishishi mumkin va barcha usullar yozilmaguncha yoki xato yuz bermaguncha bu usul qaytmaydi.
    ///
    ///
    /// # Errors
    ///
    /// Ushbu funktsiya [`Error`] nusxasini xatoga qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// [`char`]-ni ushbu yozuvchiga yozib, yozuv muvaffaqiyatli bo'lganligini qaytaradi.
    ///
    /// Bitta [`char`] bir nechta bayt sifatida kodlanishi mumkin.
    /// Ushbu usul faqat barcha baytlar ketma-ketligi muvaffaqiyatli yozilgan taqdirda muvaffaqiyatga erishishi mumkin va barcha usullar yozilmaguncha yoki xato yuzaga kelguncha bu usul qaytmaydi.
    ///
    ///
    /// # Errors
    ///
    /// Ushbu funktsiya [`Error`] nusxasini xatoga qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Ushbu trait dasturlari bilan [`write!`] makrosidan foydalanish uchun elim.
    ///
    /// Ushbu usul odatda qo'lda emas, balki [`write!`] so'lining o'zi orqali chaqirilishi kerak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Formatlash uchun konfiguratsiya.
///
/// `Formatter` formatlash bilan bog'liq turli xil variantlarni aks ettiradi.
/// Foydalanuvchilar to'g'ridan-to'g'ri "Formatter" ni yaratmaydilar;biriga o'zgartirilishi mumkin bo'lgan havola, [`Debug`] va [`Display`] kabi traits formatlashning `fmt` uslubiga o'tkaziladi.
///
///
/// `Formatter` bilan ishlash uchun siz formatlash bilan bog'liq turli xil variantlarni o'zgartirish uchun turli xil usullarni chaqirasiz.
/// Misollar uchun, iltimos, quyidagi `Formatter`-da belgilangan usullarning hujjatlarini ko'ring.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Argument asosan `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` ga tenglashtirilgan optimallashtirilgan qisman qo'llaniladigan formatlash funktsiyasidir.

extern "C" {
    type Opaque;
}

/// Ushbu struktur Xprintf funktsiyalar oilasi tomonidan qabul qilingan umumiy "argument" ni ifodalaydi.Unda berilgan qiymatni formatlash funktsiyasi mavjud.
/// Kompilyatsiya vaqtida funktsiya va qiymatning to'g'ri turlarga ega bo'lishi ta'minlanadi, so'ngra ushbu struktur bitta turga argumentlarni kanoniklashtirish uchun ishlatiladi.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Bu formatlash infratuzilmasida indices/counts bilan bog'liq funktsiya ko'rsatgichi uchun yagona barqaror qiymatni kafolatlaydi.
//
// Shuni esda tutingki, funktsiyalar har doim unnamed_addr yorlig'i bilan LLVM IR ga tushirish bilan belgilanadi, shuning uchun ularning manzili LLVM uchun muhim deb hisoblanmaydi va shuning uchun as_usize cast noto'g'ri kompilyatsiya qilingan bo'lishi mumkin.
//
// Amalda, biz hech qachon as_usize deb nomlanmaydigan ma'lumotlarni o'z ichiga olmaymiz (formatlash argumentlarini statik hosil qilish masalasi sifatida), shuning uchun bu shunchaki qo'shimcha tekshiruv.
//
// `USIZE_MARKER`-dagi funktsiya ko'rsatgichi `&usize`-ni birinchi argument sifatida qabul qiladigan funktsiyalarga *faqat* mos keladigan manzilga ega bo'lishini ta'minlashni xohlaymiz.
// Read_volatile bu erda biz havolani havoladan xavfsiz tarzda tayyorlab qo'yishni va ushbu manzil usize bo'lmagan qabul qilish funktsiyasini ko'rsatmasligini ta'minlaydi.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // XAVFSIZLIK: ptr ma'lumotnoma
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // XAVFSIZLIK: `mem::transmute(x)` xavfsiz, chunki
        //     1. `&'b T` `'b` bilan ishlab chiqarilgan umrini saqlaydi (umri cheklanmasligi uchun)
        //     2.
        //     `&'b T` va `&'b Opaque` bir xil xotira tartibiga ega (`T` `Sized` bo'lsa, xuddi shu erda) `mem::transmute(f)` xavfsiz, chunki `fn(&T, &mut Formatter<'_>) -> Result` va `fn(&Opaque, &mut Formatter<'_>) -> Result` bir xil ABIga ega (`T` `Sized` ekan)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // XAVFSIZLIK: `formatter` maydoni faqat USIZE_MARKER-ga o'rnatiladi
            // qiymati usize, shuning uchun bu xavfsizdir
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// format_args formatidagi v1 formatida mavjud bo'lgan bayroqlar
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Format_args! () So'lidan foydalanilganda ushbu funktsiya Argumentlar tuzilishini yaratish uchun ishlatiladi.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Ushbu funktsiya nostandart formatlash parametrlarini ko'rsatish uchun ishlatiladi.
    /// To'g'ri Argumentlar tuzilishini qurish uchun `pieces` massivi kamida `fmt` bo'lishi kerak.
    /// Shuningdek, `fmt` ichidagi har qanday `Count`, ya'ni `CountIsParam` yoki `CountIsNextParam`, `argumentusize` bilan yaratilgan argumentga ishora qilishi kerak.
    ///
    /// Biroq, buni qilmaslik xavfsizlikni keltirib chiqarmaydi, ammo bekorga e'tibor bermaydi.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Formatlangan matnning uzunligini taxmin qiladi.
    ///
    /// Bu `format!` dan foydalanganda dastlabki `String` hajmini sozlash uchun foydalanishga mo'ljallangan.
    /// Note: bu na pastki va na yuqori chegara.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Agar formatlash satri argument bilan boshlangan bo'lsa, hech narsa oldindan taqsimlamang, agar uning uzunligi muhim bo'lmasa.
            //
            //
            0
        } else {
            // Ba'zi argumentlar mavjud, shuning uchun har qanday qo'shimcha surish satrni qayta taqsimlaydi.
            //
            // Bunga yo'l qo'ymaslik uchun biz "pre-doubling" imkoniyatiga egamiz.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Ushbu tuzilma format satrining xavfsiz tarzda oldindan tuzilgan versiyasini va uning dalillarini aks ettiradi.
/// Buni ish vaqtida yaratish mumkin emas, chunki uni xavfsiz bajarish mumkin emas, shuning uchun konstruktorlar berilmaydi va o'zgartirishlar oldini olish uchun maydonlar xususiydir.
///
///
/// [`format_args!`] makrosi ushbu tuzilmaning xavfsiz nusxasini yaratadi.
/// Makro formatlash satrini kompilyatsiya vaqtida tasdiqlaydi, shuning uchun [`write()`] va [`format()`] funktsiyalaridan foydalanish xavfsiz bajarilishi mumkin.
///
/// Quyidagi kabi [`format_args!`] `Debug` va `Display` kontekstida qaytaradigan `Arguments<'a>` dan foydalanishingiz mumkin.
/// Masalan, `Debug` va `Display` formatlari xuddi shu narsaga o'xshashligini ko'rsatadi: `format_args!`-da interpolatsiyalangan format qatori.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Bosib chiqarish uchun satr qismlarini formatlash.
    pieces: &'a [&'static str],

    // Joylashtiruvchi xususiyatlar yoki agar barcha xususiyatlar standart bo'lsa ("{}{}" da bo'lgani kabi) `None`.
    fmt: Option<&'a [rt::v1::Argument]>,

    // Interpolatsiya uchun dinamik argumentlar, mag'lubiyatga bo'linadigan qismlar.
    // (Har qanday argumentdan oldin mag'lubiyat bo'lagi).
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Formatlangan qatorni oling, agar formatlash uchun argumentlari bo'lmasa.
    ///
    /// Bu eng ahamiyatsiz holatda ajratmalarga yo'l qo'ymaslik uchun ishlatilishi mumkin.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` dasturni tuzatuvchi kontekstida chiqishni formatlashi kerak.
///
/// Umuman aytganda, siz `derive` `Debug` dasturini bajarishingiz kerak.
///
/// Muqobil format spetsifikatori `#?` bilan foydalanilganda, chiqish juda yaxshi bosilgan.
///
/// Formatterlar haqida ko'proq ma'lumot olish uchun [the module-level documentation][module]-ga qarang.
///
/// [module]: ../../std/fmt/index.html
///
/// Agar barcha maydonlar `Debug` ni qo'llasa, ushbu trait-dan `#[derive]` bilan foydalanish mumkin.
/// Strukturalar uchun "derive`" bo'lsa, u `struct`, keyin `{`, keyin har bir maydon nomining vergul bilan ajratilgan ro'yxati va `Debug` qiymatidan, keyin `}` dan foydalanadi.
/// `Enum`s uchun u variantning nomidan va agar kerak bo'lsa `(` dan keyin maydonlarning `Debug` qiymatlaridan, keyin `)` dan foydalanadi.
///
/// # Stability
///
/// `Debug` formatlari barqaror emas va shuning uchun future Rust versiyalari bilan o'zgarishi mumkin.
/// Bundan tashqari, `Debug` standart kutubxonasi tomonidan taqdim etilgan turlar (`libstd`, `libcore`, `liballoc` va boshqalar) barqaror emas va future Rust versiyalari bilan ham o'zgarishi mumkin.
///
///
/// # Examples
///
/// Amalga oshirish:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Qo'l bilan amalga oshirish:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// X001 kabi qo'lda bajarishda sizga yordam beradigan bir qator yordamchi usullar mavjud.
///
/// `Debug` `derive` yoki disk raskadrovka quruvchi API-ni [`Formatter`]-da ishlatib, muqobil bayroq yordamida chiroyli bosib chiqarishni qo'llab-quvvatlaydi: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` bilan chiroyli bosib chiqarish:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Berilgan formatlashtiruvchi yordamida qiymatni formatlaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// `Debug` so'lini prelude-dan trait `Debug` holda qayta eksport qilish uchun alohida modul.
pub(crate) mod macros {
    /// trait `Debug` implini yaratadigan so'lni oling.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Bo'sh format uchun trait formatini, `{}`.
///
/// `Display` [`Debug`] ga o'xshaydi, lekin `Display` foydalanuvchiga qaragan chiqishi uchundir va shuning uchun uni chiqarib bo'lmaydi.
///
///
/// Formatterlar haqida ko'proq ma'lumot olish uchun [the module-level documentation][module]-ga qarang.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `Display`-ni quyidagi turda amalga oshirish:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Berilgan formatlashtiruvchi yordamida qiymatni formatlaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait o'z chiqishini raqam sifatida base-8 formatida formatlashi kerak.
///
/// Ibtidoiy imzolangan butun sonlar uchun (`i8` dan `i128` va `isize`), manfiy qiymatlar ikkalasining to'ldiruvchisi sifatida formatlanadi.
///
///
/// Muqobil bayroq, `#`, chiqish oldida `0o` qo'shadi.
///
/// Formatterlar haqida ko'proq ma'lumot olish uchun [the module-level documentation][module]-ga qarang.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` bilan asosiy foydalanish:
///
/// ```
/// let x = 42; // 42 sakkizli '52'
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// `Octal`-ni quyidagi turda amalga oshirish:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 dasturining vakili
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Berilgan formatlashtiruvchi yordamida qiymatni formatlaydi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait o'z chiqishini raqam sifatida ikkilik shaklida formatlashi kerak.
///
/// Ibtidoiy imzolangan butun sonlar uchun ([`i8`] dan [`i128`] va [`isize`]), manfiy qiymatlar ikkalasining to'ldiruvchisi sifatida formatlanadi.
///
///
/// Muqobil bayroq, `#`, chiqish oldida `0b` qo'shadi.
///
/// Formatterlar haqida ko'proq ma'lumot olish uchun [the module-level documentation][module]-ga qarang.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] bilan asosiy foydalanish:
///
/// ```
/// let x = 42; // 42 ikkilikda '101010'
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// `Binary`-ni quyidagi turda amalga oshirish:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 dasturining vakili
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Berilgan formatlashtiruvchi yordamida qiymatni formatlaydi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait o'z chiqishini o'n oltinchi raqam sifatida formatlashi kerak, kichik harf bilan `a` dan `f` gacha.
///
/// Ibtidoiy imzolangan butun sonlar uchun (`i8` dan `i128` va `isize`), manfiy qiymatlar ikkalasining to'ldiruvchisi sifatida formatlanadi.
///
///
/// Muqobil bayroq, `#`, chiqish oldida `0x` qo'shadi.
///
/// Formatterlar haqida ko'proq ma'lumot olish uchun [the module-level documentation][module]-ga qarang.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` bilan asosiy foydalanish:
///
/// ```
/// let x = 42; // 42 olti burchakda '2a'
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// `LowerHex`-ni quyidagi turda amalga oshirish:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 dasturining vakili
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Berilgan formatlashtiruvchi yordamida qiymatni formatlaydi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait o'z chiqishini o'n oltinchi raqam sifatida formatlashi kerak, katta harf bilan `A` dan `F` gacha.
///
/// Ibtidoiy imzolangan butun sonlar uchun (`i8` dan `i128` va `isize`), manfiy qiymatlar ikkalasining to'ldiruvchisi sifatida formatlanadi.
///
///
/// Muqobil bayroq, `#`, chiqish oldida `0x` qo'shadi.
///
/// Formatterlar haqida ko'proq ma'lumot olish uchun [the module-level documentation][module]-ga qarang.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` bilan asosiy foydalanish:
///
/// ```
/// let x = 42; // 42 olti burchakda '2A'
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// `UpperHex`-ni quyidagi turda amalga oshirish:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 dasturining vakili
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Berilgan formatlashtiruvchi yordamida qiymatni formatlaydi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait uning chiqishini xotira joyi sifatida formatlashi kerak.
/// Bu odatda o'n oltinchi raqam sifatida taqdim etiladi.
///
/// Formatterlar haqida ko'proq ma'lumot olish uchun [the module-level documentation][module]-ga qarang.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` bilan asosiy foydalanish:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // bu '0x7f06092ac6d0' kabi bir narsa ishlab chiqaradi
/// ```
///
/// `Pointer`-ni quyidagi turda amalga oshirish:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // biz foydalanishingiz mumkin bo'lgan Pointer-ni amalga oshiradigan `*const T`-ga o'tish uchun `as`-dan foydalaning
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Berilgan formatlashtiruvchi yordamida qiymatni formatlaydi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait chiqishi kichik ilmiy `e` bilan ilmiy yozuvlarda formatlanishi kerak.
///
/// Formatterlar haqida ko'proq ma'lumot olish uchun [the module-level documentation][module]-ga qarang.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` bilan asosiy foydalanish:
///
/// ```
/// let x = 42.0; // 42.0 ilmiy notatsiyada '4.2e1' dir
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// `LowerExp`-ni quyidagi turda amalga oshirish:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 dasturining vakili
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Berilgan formatlashtiruvchi yordamida qiymatni formatlaydi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait o'z chiqishini ilmiy yozuvlarda `E` katta harflar bilan formatlashi kerak.
///
/// Formatterlar haqida ko'proq ma'lumot olish uchun [the module-level documentation][module]-ga qarang.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` bilan asosiy foydalanish:
///
/// ```
/// let x = 42.0; // 42.0 ilmiy notatsiyada '4.2E1' hisoblanadi
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// `UpperExp`-ni quyidagi turda amalga oshirish:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 dasturining vakili
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Berilgan formatlashtiruvchi yordamida qiymatni formatlaydi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` funktsiyasi chiqish oqimini va `format_args!` makrosi bilan oldindan kompilyatsiya qilinadigan `Arguments` strukturasini oladi.
///
///
/// Argumentlar belgilangan format qatoriga muvofiq taqdim etilgan chiqish oqimiga formatlanadi.
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Iltimos, [`write!`] dan foydalanish afzalroq bo'lishi mumkinligini unutmang.Misol:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Barcha argumentlar uchun standart formatlash parametrlaridan foydalanishimiz mumkin.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Har bir spektrning mos keladigan argumenti bor, undan oldin mag'lubiyat qismi.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // XAVFSIZLIK: arg va args.args bir xil argumentlardan kelib chiqadi,
                // bu indekslarni har doim chegarada bo'lishini kafolatlaydi.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Faqat bitta orqadagi mag'lubiyat qismi bo'lishi mumkin.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // XAVFSIZLIK: arg va arglar bir xil argumentlardan kelib chiqadi,
    // bu indekslarni har doim chegarada bo'lishini kafolatlaydi.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // To'g'ri dalilni chiqarib oling
    debug_assert!(arg.position < args.len());
    // XAVFSIZLIK: arg va arglar bir xil argumentlardan kelib chiqadi,
    // bu uning indeksini doimo kafolatlaydi.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Keyin aslida bir oz bosib chiqaring
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // XAVFSIZLIK: cnt va arglar bir xil argumentlardan kelib chiqadi,
            // bu indeks har doim chegarada bo'lishini kafolatlaydi.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Biror narsa tugaganidan keyin to'ldirish.`Formatter::padding` tomonidan qaytarilgan.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Ushbu yozuvni to'ldiring.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Biz buni o'zgartirishni xohlaymiz
            buf: wrap(self.buf),

            // Va ularni saqlang
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // traits formatlashidan foydalanishi mumkin bo'lgan formatlash argumentlarini to'ldirish va qayta ishlash uchun yordamchi usullar.
    //

    /// Str ga chiqarilgan tamsayı uchun to'g'ri to'ldirishni amalga oshiradi.
    /// Strda bu usul bilan qo'shiladigan tamsayı belgisi bo'lmasligi kerak *.
    ///
    /// # Arguments
    ///
    /// * asl tamsayı musbat yoki nolga teng bo'ladimi, manfiy emas.
    /// * prefiks, agar '#' belgisi (Alternate) taqdim etilsa, bu raqam oldiga qo'yiladigan prefiks.
    ///
    /// * buf, raqam formatlangan baytlar qatori
    ///
    /// Ushbu funktsiya taqdim etilgan bayroqlarni va minimal kenglikni to'g'ri hisobga oladi.
    /// Bu aniqlikni hisobga olmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // "-" raqamini chiqarilishidan olib tashlashimiz kerak.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Agar mavjud bo'lsa, belgini, keyin so'ralsa, prefiksni yozadi
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // `width` maydoni bu erda ko'proq `min-width` parametridir.
        match self.width {
            // Agar minimal uzunlik talablari bo'lmasa, biz faqat baytlarni yozishimiz mumkin.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Minimal kengligimizdan oshganligimizni tekshiring, agar shunday bo'lsa, biz shunchaki baytlarni yozishimiz mumkin.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // To'ldirish belgisi nol bo'lsa, belgi va prefiks to'ldirishdan oldin ketadi
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Aks holda, belgi va prefiks to'ldirishdan keyin ketadi
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Ushbu funktsiya mag'lubiyatga bo'lakni oladi va belgilangan formatlash bayroqlarini qo'llaganidan keyin ichki buferga chiqaradi.
    /// Umumiy satrlar uchun tanilgan bayroqlar:
    ///
    /// * kengligi, chiqaradigan narsaning minimal kengligi
    /// * fill/align - agar taqdim etilgan satrni to'ldirish kerak bo'lsa, nimani chiqarish kerak va uni qaerdan chiqarish kerak
    /// * aniqlik, chiqariladigan maksimal uzunlik, agar bu uzunlikdan uzun bo'lsa, mag'lubiyat kesiladi
    ///
    /// Ayniqsa, ushbu funktsiya `flag` parametrlarini e'tiborsiz qoldiradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Oldinda tez yo'l borligiga ishonch hosil qiling
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` maydonini formatlanadigan satr uchun `max-width` sifatida talqin qilish mumkin.
        //
        let s = if let Some(max) = self.precision {
            // Agar bizning ipimiz aniqlikdan uzunroq bo'lsa, unda bizda kesish kerak.
            // Ammo `fill`, `width` va `align` kabi boshqa bayroqlar har doimgidek harakat qilishi kerak.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM bu erda `..i` panic `&s[..i]` bo'lmasligini isbotlay olmaydi, ammo biz buni panic qila olmasligini bilamiz.
                // `unsafe` dan qochish uchun `get` + `unwrap_or` dan foydalaning va aks holda bu erda panic bilan bog'liq kod chiqarmang.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // `width` maydoni bu erda ko'proq `min-width` parametridir.
        match self.width {
            // Agar biz maksimal uzunlik ostida bo'lsak va minimal uzunlik bo'yicha talablar bo'lmasa, biz shunchaki ipni chiqaramiz
            //
            None => self.buf.write_str(s),
            // Agar biz maksimal kenglik ostida bo'lsak, minimal kenglikdan oshganligimizni tekshirib ko'ring, agar shunday bo'lsa, shunchaki ipni chiqarish kabi oson.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Agar biz maksimal va minimal kenglik ostida bo'lsak, unda belgilangan kenglik bilan minimal kenglikni to'ldiring + biroz tekislang.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Old to'ldirishni yozing va yozilmagan to'ldirishni qaytaring.
    /// Qo'ng'iroq qiluvchilar to'ldirilgan narsadan keyin yozuvni to'ldirishni ta'minlash uchun javobgardir.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Formatlangan qismlarni oladi va to'ldirishni qo'llaydi.
    /// `self.precision` ni e'tiborsiz qoldirish uchun qo'ng'iroq qiluvchi allaqachon ehtiyot qismlarni kerakli aniqlikda ishlagan deb taxmin qiladi.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // belgini biladigan nolga to'ldirish uchun biz avval belgini beramiz va boshidanoq hech qanday belgimiz bo'lmaganidek harakat qilamiz.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // belgi har doim birinchi o'rinda turadi
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // formatlangan qismlardan belgini olib tashlang
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // qolgan qismlar oddiy to'ldirish jarayonidan o'tadi.
            let len = formatted.len();
            let ret = if width <= len {
                // plomba yo'q
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // bu oddiy holat va biz yorliqni tanlaymiz
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // XAVFSIZLIK: Bu `flt2dec::Part::Num` va `flt2dec::Part::Copy` uchun ishlatiladi.
            // `flt2dec::Part::Num` uchun foydalanish xavfsizdir, chunki `c` har bir char `b'0'` va `b'9'` orasida, ya'ni `s` haqiqiy UTF-8 degan ma'noni anglatadi.
            // Ehtimol, `flt2dec::Part::Copy(buf)` uchun ishlatish amalda xavfsiz bo'lishi mumkin, chunki `buf` oddiy ASCII bo'lishi kerak, ammo kimdir `buf` uchun yomon qiymatda `flt2dec::to_shortest_str` ga o'tishi mumkin, chunki bu umumiy funktsiya.
            //
            // FIXME: Buning natijasi UBga olib kelishi mumkinligini aniqlang.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 nol
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Ushbu formatlashtiruvchi tarkibidagi asosiy buferga ba'zi ma'lumotlarni yozadi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Bu quyidagilarga teng:
    ///         // yozing! (formatlashtiruvchi, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Ushbu nusxada ba'zi formatlangan ma'lumotlarni yozadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Formatlash uchun bayroqlar
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Hizalama mavjud bo'lganda 'fill' sifatida ishlatiladigan belgi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Biz ">" bilan o'ng tomonga tekislashni o'rnatdik.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Tuzatishning qaysi shakli talab qilinganligini ko'rsatuvchi bayroq.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Chiqish bo'lishi kerak bo'lgan ixtiyoriy ravishda belgilangan butun kenglik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Agar biz kenglikni olgan bo'lsak, uni ishlatamiz
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Aks holda biz alohida hech narsa qilmaymiz
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Raqamli turlar uchun ixtiyoriy ravishda aniqlik.
    /// Shu bilan bir qatorda, mag'lubiyat turlari uchun maksimal kenglik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Agar biz aniqlik olgan bo'lsak, uni ishlatamiz.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Aks holda biz 2 ga sukut qilamiz.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// `+` bayrog'i ko'rsatilganligini aniqlaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// `-` bayrog'i ko'rsatilganligini aniqlaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Siz minus belgisini xohlaysizmi?Bir bor!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// `#` bayrog'i ko'rsatilganligini aniqlaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// `0` bayrog'i ko'rsatilganligini aniqlaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Formatlashtiruvchi parametrlarini e'tiborsiz qoldiramiz.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Ushbu ikkita bayroq uchun qaysi umumiy API-ni xohlayotganimizni hal qiling.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Strukturalar uchun [`fmt::Debug`] dasturlarini yaratishda yordam berish uchun mo'ljallangan [`DebugStruct`] quruvchisini yaratadi.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// `DebugTuple` konstruktsiyasini yaratadi, bu esa strelka konstruktsiyalari uchun `fmt::Debug` dasturlarini yaratishda yordam beradi.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Ro'yxatga o'xshash tuzilmalar uchun `fmt::Debug` dasturlarini yaratishda yordam berish uchun mo'ljallangan `DebugList` quruvchisini yaratadi.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// O'rnatilgan o'xshash tuzilmalar uchun `fmt::Debug` dasturlarini yaratishda yordam berish uchun mo'ljallangan `DebugSet` quruvchisini yaratadi.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Ushbu yanada murakkab misolda biz o'yin qurollari ro'yxatini tuzish uchun [`format_args!`] va `.debug_set()` dan foydalanamiz:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Xaritaga o'xshash tuzilmalar uchun `fmt::Debug` dasturlarini yaratishda yordam berish uchun mo'ljallangan `DebugMap` quruvchisini yaratadi.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// traits yadro formatlashni amalga oshirish

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Agar char qochish kerak bo'lsa, hozirgacha ishdan bo'shatib qo'ying va yozing, aks holda o'tkazib yuboring
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Muqobil bayroq allaqachon LowerHex tomonidan maxsus deb qaraladi-bu 0x bilan prefiks qo'yish kerakligini bildiradi.
        // Biz uni nolga cho'zish yoki kengaytirmaslik to'g'risida ishlash uchun foydalanamiz va keyin so'zsiz uni prefiksni olish uchun o'rnatamiz.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Turli xil yadro turlari uchun Display/Debug-ni amalga oshirish

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell-ni mutanosib ravishda sotib olish mumkin, shuning uchun biz uning qiymatini ko'rib chiqa olmaymiz.
                // O'rniga joyni belgilang.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Agar testlar shu erda bo'lishini kutgan bo'lsangiz, uning o'rniga core/tests/fmt.rs faylini ko'rib chiqing, bu erda barcha rt::Piece tuzilmalarini yaratishdan ancha osonroq.
//
// Shuningdek, ajratmalarga muhtoj bo'lganlar uchun crate ajratishida testlar mavjud.