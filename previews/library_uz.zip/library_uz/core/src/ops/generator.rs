use crate::marker::Unpin;
use crate::pin::Pin;

/// Jeneratorni qayta tiklash natijasi.
///
/// Ushbu enum `Generator::resume` usulidan qaytariladi va generatorning mumkin bo'lgan qaytarilish qiymatlarini bildiradi.
/// Hozirda bu (`Yielded`) to'xtatib turish nuqtasiga yoki (`Complete`) to'xtash nuqtasiga to'g'ri keladi.
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Jeneratör qiymati bilan to'xtatildi.
    ///
    /// Ushbu holat generatorning to'xtatilganligini ko'rsatadi va odatda `yield` bayonotiga mos keladi.
    /// Ushbu variantda keltirilgan qiymat `yield`-ga o'tkazilgan ifodaga mos keladi va generatorlarga har safar hosil bo'lganida qiymat berishiga imkon beradi.
    ///
    ///
    Yielded(Y),

    /// Jeneratör qaytish qiymati bilan yakunlandi.
    ///
    /// Ushbu holat generatorning taqdim etilgan qiymat bilan bajarilishini tugatganligini ko'rsatadi.
    /// Jeneratör `Complete` ni qaytargandan so'ng, `resume`-ga qayta qo'ng'iroq qilish dasturchining xatosi hisoblanadi.
    ///
    Complete(R),
}

/// O'rnatilgan generator turlari tomonidan amalga oshirilgan trait.
///
/// Odatda generatorlar deb nomlanuvchi generatorlar Rust-da eksperimental til xususiyatidir.
/// [RFC 2033] generatorlarida qo'shilgan narsa, asosan, async/await sintaksisining qurilish blokini ta'minlashga mo'ljallangan, ammo ehtimol iteratorlar va boshqa ibtidoiylar uchun ergonomik ta'rif berishga ham imkon beradi.
///
///
/// Jeneratorlar uchun sintaksis va semantik barqaror emas va barqarorlashtirish uchun qo'shimcha RFC talab etiladi.Ammo bu vaqtda sintaksis yopilishga o'xshaydi:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Jeneratörlarning qo'shimcha hujjatlari beqaror kitobda joylashgan.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Ushbu generator beradigan qiymat turi.
    ///
    /// Ushbu bog'liq tur `yield` ifodasiga va generator har safar hosil bo'lganida qaytarishga ruxsat berilgan qiymatlarga mos keladi.
    ///
    /// Masalan, generator kabi iterator, ehtimol `T` kabi turga ega bo'lishi mumkin, turi takrorlanadi.
    ///
    type Yield;

    /// Ushbu generator qaytaradigan qiymat turi.
    ///
    /// Bu generatordan `return` iborasi bilan yoki to'g'ridan-to'g'ri generator so'zining oxirgi ifodasi sifatida qaytarilgan turga mos keladi.
    /// Masalan, futures buni `Result<T, E>` sifatida ishlatishi mumkin, chunki u tugallangan future ni anglatadi.
    ///
    ///
    type Return;

    /// Ushbu generatorning ishlashini davom ettiradi.
    ///
    /// Ushbu funktsiya generatorning ishlashini davom ettiradi yoki hali bajarilmagan bo'lsa, uni bajarishni boshlaydi.
    /// Ushbu qo'ng'iroq generatorning so'nggi to'xtatib turish nuqtasiga qaytadi va so'nggi `yield`-dan ishlashni davom ettiradi.
    /// Jeneratör u hosil bo'lguncha yoki qaytguncha bajarishni davom ettiradi va shu vaqtda bu funktsiya qaytadi.
    ///
    /// # Qaytish qiymati
    ///
    /// Ushbu funktsiyadan qaytarilgan `GeneratorState` enum generatorning qaytib kelgandan keyin qanday holatda ekanligini ko'rsatadi.
    /// Agar `Yielded` varianti qaytarilsa, u holda generator to'xtatib turish nuqtasiga etib bordi va qiymat chiqarildi.
    /// Ushbu holatdagi generatorlar keyinroq qayta tiklanishi mumkin.
    ///
    /// Agar `Complete` qaytarilsa, u holda generator taqdim etilgan qiymat bilan to'liq ishlaydi.Jeneratorni qayta tiklash uchun yaroqsiz.
    ///
    /// # Panics
    ///
    /// Agar `Complete` varianti avval qaytarilganidan keyin chaqirilsa, bu funktsiya panic bo'lishi mumkin.
    /// Tilda generator literallari 0panic-ga `Complete` dan keyin qayta tiklanishiga kafolat berilsa-da, bu `Generator` trait-ning barcha ilovalari uchun kafolatlanmaydi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}