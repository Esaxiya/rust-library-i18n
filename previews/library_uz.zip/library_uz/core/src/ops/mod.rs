//! Haddan tashqari yuklanadigan operatorlar.
//!
//! Ushbu traits-ni amalga oshirish ma'lum operatorlarni ortiqcha yuklashga imkon beradi.
//!
//! Ushbu traits-dan ba'zilari prelude tomonidan import qilinadi, shuning uchun ular har Rust dasturida mavjud.Faqat traits tomonidan qo'llab-quvvatlanadigan operatorlar haddan tashqari yuklanishi mumkin.
//! Masalan, (`+`) qo'shish operatori [`Add`] trait orqali haddan tashqari yuklanishi mumkin, ammo (`=`) tayinlash operatorida trait qo'llab-quvvatlovchisiz bo'lgani uchun uning semantikasini ortiqcha yuklashning imkoni yo'q.
//! Bundan tashqari, ushbu modulda yangi operatorlarni yaratish mexanizmlari mavjud emas.
//! Agar nomuvofiq ortiqcha yuk yoki maxsus operatorlar kerak bo'lsa, siz Rust sintaksisini kengaytirish uchun makrolar yoki kompilyator plaginlariga murojaat qilishingiz kerak.
//!
//! traits operatorining tatbiq etilishi, odatdagi ma'nolari va [operator precedence] ni yodda tutgan holda, o'zlarining kontekstlarida ajablantirmasligi kerak.
//! Masalan, [`Mul`]-ni amalga oshirishda operatsiya ko'paytma bilan o'xshashligi bo'lishi kerak (va assotsiativlik kabi kutilgan xususiyatlarni baham ko'ring).
//!
//! E'tibor bering, `&&` va `||` operatorlari qisqa tutashuvga, ya'ni natijaga hissa qo'shgan taqdirdagina ikkinchi operandlarini baholaydilar.Ushbu xatti-harakatlar traits tomonidan bajarilmasligi sababli, `&&` va `||` haddan tashqari yuklanadigan operatorlar sifatida qo'llab-quvvatlanmaydi.
//!
//! Ko'pgina operatorlar o'z operandalarini qiymatiga qarab qabul qilishadi.O'rnatilgan turlarni o'z ichiga olgan umumiy bo'lmagan kontekstlarda bu odatda muammo emas.
//! Biroq, ushbu operatorlardan umumiy kodda foydalanish, operatorlarning ularni iste'mol qilishiga qarshi qiymatlarni qayta ishlatish kerak bo'lsa, ba'zi e'tibor talab qiladi.Bitta variant-vaqti-vaqti bilan [`clone`]-dan foydalanish.
//! Yana bir variant-havolalar uchun qo'shimcha operatorlarni amalga oshirishni ta'minlaydigan turlarga tayanish.
//! Masalan, qo'shilishni qo'llab-quvvatlashi kerak bo'lgan foydalanuvchi tomonidan belgilangan `T` turi uchun, ehtimol `T` va `&T` traits [`Add<T>`][`Add`] va [`Add<&T>`][`Add`]-ni amalga oshirishi kerak, shunda umumiy kod keraksiz klonlashsiz yozilishi mumkin.
//!
//!
//! # Examples
//!
//! Ushbu misol [`Add`] va [`Sub`]-ni amalga oshiradigan `Point` strukturasini yaratadi, so'ngra ikkita "Nuqta" ni qo'shish va chiqarishni namoyish etadi.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Misolni amalga oshirish uchun har bir trait uchun hujjatlarni ko'ring.
//!
//! [`Fn`], [`FnMut`] va [`FnOnce`] traits funktsiyalar kabi chaqirilishi mumkin bo'lgan turlari bo'yicha amalga oshiriladi.[`Fn`] `&self`, [`FnMut`] `&mut self` va [`FnOnce`] `self` oladi.
//! Ular instansiyada chaqirilishi mumkin bo'lgan uchta usulga mos keladi: chaqiruv bo'yicha qo'ng'iroq qilish, mutanosib qo'ng'iroq qilish va qiymat bo'yicha qo'ng'iroq.
//! Ushbu traits-ning eng keng tarqalgan ishlatilishi funktsiyalar yoki yopilishlarni argument sifatida qabul qiladigan yuqori darajadagi funktsiyalar chegarasi sifatida harakat qilishdir.
//!
//! Parametr sifatida [`Fn`]-ni olish:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Parametr sifatida [`FnMut`]-ni olish:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Parametr sifatida [`FnOnce`]-ni olish:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ushlangan o'zgaruvchilarni iste'mol qiladi, shuning uchun uni bir necha marta ishlatish mumkin emas
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()`-ni qayta chaqirishga urinish `func` uchun `use of moved value` xatosini keltirib chiqaradi
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` endi bu erda chaqirish mumkin emas
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;