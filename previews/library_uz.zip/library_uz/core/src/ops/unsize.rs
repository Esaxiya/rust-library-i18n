use crate::marker::Unsize;

/// Trait, bu ko'rsatgich yoki o'ralgan narsa ekanligini, bu erda pointee o'lchamini o'zgartirish mumkin.
///
/// Qo'shimcha ma'lumot uchun [DST coercion RFC][dst-coerce] va [the nomicon entry on coercion][nomicon-coerce]-ga qarang.
///
/// O'rnatilgan ko'rsatgich turlari uchun `T` ko'rsatkichlari, agar `T: Unsize<U>` ingichka ko'rsatkichdan yog 'ko'rsatkichiga o'tish orqali `U` ko'rsatkichlariga majbur bo'ladi.
///
/// Maxsus turlar uchun bu erda majburlash `Foo<T>` dan `Foo<U>` gacha majburlash orqali ishlaydi, agar `CoerceUnsized<Foo<U>> for Foo<T>` ma'nosi mavjud bo'lsa.
/// Bunday tushuntirishni faqat `Foo<T>`-da `T` bilan bog'liq bo'lgan yagona fantomdata maydoni bo'lsa yozish mumkin.
/// Agar ushbu maydon turi `Bar<T>` bo'lsa, `CoerceUnsized<Bar<U>> for Bar<T>` dasturi mavjud bo'lishi kerak.
/// Majburlash `Bar<T>` maydonini `Bar<U>` ga majburlash va `Foo<T>` dan qolgan maydonlarni to'ldirish orqali ishlaydi.
/// Bu ko'rsatgich maydoniga samarali ravishda kirib boradi va buni majbur qiladi.
///
/// Odatda, aqlli ko'rsatgichlar uchun siz `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`-ni amalga oshirasiz, `T`-ning o'zida ixtiyoriy `?Sized`.
/// To'g'ridan-to'g'ri `T`-ni `Cell<T>` va `RefCell<T>`-ga joylashtiradigan o'rash turlari uchun siz to'g'ridan-to'g'ri `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`-ni amalga oshirishingiz mumkin.
///
/// Bu `Cell<Box<T>>` kabi turlarni majburlashni amalga oshirishga imkon beradi.
///
/// [`Unsize`][unsize] ko'rsatkichlardan orqada bo'lsa DST-ga majburlanadigan turlarni belgilash uchun foydalaniladi.U avtomatik ravishda kompilyator tomonidan amalga oshiriladi.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Bu usulning qabul qiluvchisi turini yuborish mumkinligini tekshirish uchun ob'ekt xavfsizligi uchun ishlatiladi.
///
/// trait dasturining misoli:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}