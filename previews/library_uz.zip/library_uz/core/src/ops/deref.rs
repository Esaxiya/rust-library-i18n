/// `*v` kabi o'zgarmas ajratish operatsiyalari uchun ishlatiladi.
///
/// O'zgarmas kontekstda (unary) `*` operatori bilan aniq farqlash operatsiyalari uchun foydalanishga qo'shimcha ravishda, `Deref` ham ko'p hollarda kompilyator tomonidan bevosita ishlatilgan.
/// Ushbu mexanizm ['`Deref` coercion'][more] deb nomlanadi.
/// O'zgaruvchan kontekstlarda [`DerefMut`] ishlatiladi.
///
/// `Deref`-ni aqlli ko'rsatgichlar uchun qo'llash ularning orqasidagi ma'lumotlarga kirishni qulay qiladi, shuning uchun ular `Deref`-ni amalga oshiradilar.
/// Boshqa tomondan, `Deref` va [`DerefMut`] qoidalari aqlli ko'rsatgichlarni joylashtirish uchun maxsus ishlab chiqilgan.
/// Shuning uchun **"Deref" chalkashmaslik uchun faqat aqlli ko'rsatgichlar** uchun qo'llanilishi kerak.
///
/// Shunga o'xshash sabablarga ko'ra **bu trait hech qachon ishlamay qolmasligi kerak**.`Deref` to'g'ridan-to'g'ri chaqirilganda, ajratish paytida xatolik juda chalkash bo'lishi mumkin.
///
/// # `Deref` majburlash haqida ko'proq
///
/// Agar `T` `Deref<Target = U>` ni amalga oshirsa va `x` `T` tipidagi qiymat bo'lsa, unda:
///
/// * O'zgarmas kontekstlarda `*x` (bu erda `T` na ma'lumotnoma, na xom ko'rsatkich) `* Deref::deref(&x)` ga teng.
/// * `&T` tipidagi qiymatlar `&U` tipidagi qiymatlarga majburlanadi
/// * `T` `U` turidagi barcha (immutable) usullarini bilvosita amalga oshiradi.
///
/// Qo'shimcha ma'lumot uchun [the chapter in *The Rust Programming Language*][book]-ga, shuningdek [the dereference operator][ref-deref-op], [method resolution] va [type coercions]-ga mos yozuvlar bo'limlariga tashrif buyuring.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Strukturani ajratib ko'rsatish orqali kirish mumkin bo'lgan bitta maydonga ega bo'lgan struktura.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Hukmdorlikdan keyingi natijalar.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Qiymatni qisqartirish.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;`-dagi kabi o'zgaruvchan farqlash operatsiyalari uchun foydalaniladi.
///
/// O'zgaruvchan kontekstda (unary) `*` operatori bilan aniq farqlash operatsiyalari uchun ishlatishdan tashqari, `DerefMut` ko'p hollarda kompilyator tomonidan bevosita ishlatilgan.
/// Ushbu mexanizm ['`Deref` coercion'][more] deb nomlanadi.
/// O'zgarmas kontekstlarda [`Deref`] ishlatiladi.
///
/// `DerefMut`-ni aqlli ko'rsatgichlar uchun qo'llash ularning orqasidagi ma'lumotlarning mutatsiyasini qulay qiladi, shuning uchun ular `DerefMut`-ni amalga oshiradilar.
/// Boshqa tomondan, [`Deref`] va `DerefMut` qoidalari aqlli ko'rsatgichlarni joylashtirish uchun maxsus ishlab chiqilgan.
/// Shuning uchun **"DerefMut" chalkashmaslik uchun faqat aqlli ko'rsatgichlar** uchun qo'llanilishi kerak.
///
/// Shunga o'xshash sabablarga ko'ra **bu trait hech qachon ishlamay qolmasligi kerak**.`DerefMut` to'g'ridan-to'g'ri chaqirilganda, ajratish paytida xatolik juda chalkash bo'lishi mumkin.
///
/// # `Deref` majburlash haqida ko'proq
///
/// Agar `T` `DerefMut<Target = U>` ni amalga oshirsa va `x` `T` tipidagi qiymat bo'lsa, unda:
///
/// * O'zgaruvchan kontekstlarda `*x` (bu erda `T` na ma'lumotnoma, na xom ko'rsatkich) `* DerefMut::deref_mut(&mut x)` ga teng.
/// * `&mut T` tipidagi qiymatlar `&mut U` tipidagi qiymatlarga majburlanadi
/// * `T` `U` turidagi barcha (mutable) usullarini bilvosita amalga oshiradi.
///
/// Qo'shimcha ma'lumot uchun [the chapter in *The Rust Programming Language*][book]-ga, shuningdek [the dereference operator][ref-deref-op], [method resolution] va [type coercions]-ga mos yozuvlar bo'limlariga tashrif buyuring.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Strukturani ajratib ko'rsatish orqali o'zgartirilishi mumkin bo'lgan bitta maydonga ega bo'lgan struktura.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// O'zgaruvchan qiymatni o'zgartiradi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Strukturani `arbitrary_self_types` xususiyatisiz usul qabul qilish vositasi sifatida ishlatilishini bildiradi.
///
/// Bu `Box<T>`, `Rc<T>`, `&T` va `Pin<P>` kabi stdlib ko'rsatgich turlari tomonidan amalga oshiriladi.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}