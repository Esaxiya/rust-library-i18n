/// Destruktor ichidagi maxsus kod.
///
/// Agar qiymat endi kerak bo'lmasa, Rust ushbu qiymatda "destructor" ishlaydi.
/// Qiymat endi kerak bo'lmaydigan eng keng tarqalgan usul bu uning doiradan chiqib ketishi.Yo'q qiluvchilar hali ham boshqa holatlarda ishlashlari mumkin, ammo biz bu erda keltirilgan misollar doirasiga e'tibor qaratamiz.
/// Ba'zi bir boshqa holatlar haqida bilish uchun, iltimos, [the reference] destruktorlari bo'limiga qarang.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Ushbu destruktor ikkita komponentdan iborat:
/// - Ushbu maxsus `Drop` trait uning turi uchun amalga oshirilsa, ushbu qiymat uchun `Drop::drop` ga qo'ng'iroq.
/// - Avtomatik ravishda ishlab chiqarilgan "drop glue", bu qiymatning barcha maydonlarini buzadiganlarni rekursiv ravishda chaqiradi.
///
/// Rust avtomatik ravishda barcha mavjud maydonlarning destruktorlarini chaqirganligi sababli, siz ko'p hollarda `Drop` dasturini bajarishingiz shart emas.
/// Ammo bu foydali bo'lgan ba'zi holatlar mavjud, masalan, resursni bevosita boshqaradigan turlar uchun.
/// Ushbu resurs xotira bo'lishi mumkin, fayl tavsiflovchisi bo'lishi mumkin, tarmoq rozetkasi bo'lishi mumkin.
/// Ushbu turdagi qiymat endi ishlatilmagandan so'ng, u xotirani bo'shatish yoki fayl yoki rozetkani yopish orqali o'z manbasini "clean up" qilishi kerak.
/// Bu destruktorning ishi, shuning uchun `Drop::drop` ishi.
///
/// ## Examples
///
/// Yo'q qiluvchilarni amalda ko'rish uchun quyidagi dasturni ko'rib chiqamiz:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust birinchi navbatda `_x` uchun `_x`, keyin esa `_x.one` va `_x.two` uchun qo'ng'iroq qiladi, ya'ni uni ishga tushirish
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Agar biz `HasTwoDrop` uchun `Drop` dasturini olib tashlasak ham, uning maydonlarini buzuvchi qurilmalar chaqiriladi.
/// Bu natijaga olib keladi
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Siz `Drop::drop` telefoniga o'zingiz qo'ng'iroq qila olmaysiz
///
/// `Drop::drop` qiymatni tozalash uchun ishlatilganligi sababli, usul chaqirilgandan keyin bu qiymatdan foydalanish xavfli bo'lishi mumkin.
/// `Drop::drop` uning kiritilishiga egalik qilmasligi sababli, Rust to'g'ridan-to'g'ri `Drop::drop` raqamiga qo'ng'iroq qilishga ruxsat bermaslik orqali noto'g'ri foydalanishni oldini oladi.
///
/// Boshqacha qilib aytganda, agar siz yuqoridagi misolda `Drop::drop`-ga aniq qo'ng'iroq qilmoqchi bo'lsangiz, siz kompilyator xatosiga duch kelasiz.
///
/// Agar siz aniq bir qiymatni yo'q qiluvchini chaqirishni xohlasangiz, uning o'rniga [`mem::drop`] ishlatilishi mumkin.
///
/// [`mem::drop`]: drop
///
/// ## Buyurtmani tushirish
///
/// Bizning ikkita `HasDrop`-ning qaysi biri birinchi bo'lib tushadi?Strukturalar uchun ular e'lon qilingan tartibda: avval `one`, keyin `two`.
/// Agar buni o'zingiz sinab ko'rishni istasangiz, yuqoridagi `HasDrop`-ni butun son kabi ba'zi ma'lumotlarni o'z ichiga olishi uchun o'zgartirishingiz va keyin `Drop` ichidagi `println!`-da ishlatishingiz mumkin.
/// Ushbu xatti-harakatlar til tomonidan kafolatlangan.
///
/// Strukturalardan farqli o'laroq, mahalliy o'zgaruvchilar teskari tartibda tashlanadi:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Bu chop etiladi
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Iltimos, to'liq qoidalar uchun [the reference]-ga qarang.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` va `Drop` eksklyuziv hisoblanadi
///
/// Siz ikkala [`Copy`] va `Drop`-ni bir xil turdagi amalga oshira olmaysiz.`Copy` bo'lgan turlar kompilyator tomonidan to'g'ridan-to'g'ri takrorlanadi, shuning uchun destruktorlarning qachon va qanchalik tez-tez bajarilishini taxmin qilish juda qiyin.
///
/// Shunday qilib, ushbu turlarda destruktorlar bo'lishi mumkin emas.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Ushbu turdagi destruktorni bajaradi.
    ///
    /// Qiymat doiradan chiqib ketganda, bu usul aniq ravishda chaqiriladi va uni aniq chaqirish mumkin emas (bu [E0040] kompilyator xatosi).
    /// Biroq, prelude-dagi [`mem::drop`] funktsiyasi argumentning `Drop` dasturini chaqirish uchun ishlatilishi mumkin.
    ///
    /// Ushbu usul chaqirilganda, `self` hali taqsimlanmagan.
    /// Bu faqat usul tugagandan so'ng sodir bo'ladi.
    /// Agar bunday bo'lmasa, `self` osilgan ma'lumotnoma bo'lar edi.
    ///
    /// # Panics
    ///
    /// [`panic!`] `drop` ni bo'shashganda chaqirishini hisobga olsak, `drop` dasturidagi har qanday [`panic!`] bekor qilinishi mumkin.
    ///
    /// E'tibor bering, agar bu panics bo'lsa ham, qiymat tushgan deb hisoblanadi;
    /// `drop`-ni qayta chaqirishga sabab bo'lmasligingiz kerak.
    /// Bu odatda avtomatik ravishda kompilyator tomonidan ko'rib chiqiladi, ammo xavfli kodni ishlatganda, ba'zida bexosdan, ayniqsa [`ptr::drop_in_place`] dan foydalanganda yuz berishi mumkin.
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}