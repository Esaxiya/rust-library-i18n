/// `?` operatorining xatti-harakatlarini sozlash uchun trait.
///
/// `Try`-ni amalga oshiradigan tur, uni success/failure ikkilamchi nuqtai nazaridan ko'rish uchun kanonik usulga ega.
/// Ushbu trait mavjud bo'lgan misoldan o'sha muvaffaqiyatsizlik yoki muvaffaqiyatsizlik qiymatlarini chiqarishga ham, muvaffaqiyat yoki qobiliyatsizlik qiymatidan yangi nusxani yaratishga imkon beradi.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Ushbu qiymatning turi muvaffaqiyatli deb qaralganda.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Ushbu qiymatning turi muvaffaqiyatsiz deb hisoblanganda.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" operatorini qo'llaydi.`Ok(t)`-ning qaytishi shuni anglatadiki, ijro etilish normal davom etishi kerak va `?` natijasi `t` qiymatidir.
    /// `Err(e)` qaytishi shuni anglatadiki, branch `catch` atrofidagi ichki qismga yoki funktsiyadan qaytadi.
    ///
    /// Agar `Err(e)` natijasi qaytarilgan bo'lsa, `e` qiymati "wrapped" bo'ladi, bu doiraning qaytish turida (o'zi `Try` ni amalga oshirishi kerak).
    ///
    /// Xususan, `X::from_error(From::from(e))` qiymati qaytariladi, bu erda `X`-yopuvchi funktsiyani qaytarish turi.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Kompozit natijani yaratish uchun xato qiymatini o'rab qo'ying.
    /// Masalan, `Result::Err(x)` va `Result::from_error(x)` tengdir.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Kompozit natijani yaratish uchun OK qiymatini o'rab qo'ying.
    /// Masalan, `Result::Ok(x)` va `Result::from_ok(x)` tengdir.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}