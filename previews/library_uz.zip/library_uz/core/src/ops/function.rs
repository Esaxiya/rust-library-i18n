/// O'zgarmas qabul qiluvchini qabul qiladigan qo'ng'iroq operatorining versiyasi.
///
/// `Fn` nusxalarini mutatsion holatsiz qayta-qayta chaqirish mumkin.
///
/// *Ushbu trait (`Fn`) ni [function pointers] (`fn`) bilan aralashtirib bo'lmaydi.*
///
/// `Fn` avtomatik ravishda amalga oshiriladi, bu faqat olingan o'zgaruvchilarga o'zgarmas havolalarni oladi yoki umuman hech narsa yozib olinmaydi, shuningdek (safe) [function pointers] (ba'zi ogohlantirishlar bilan, qo'shimcha ma'lumot olish uchun ularning hujjatlariga qarang).
///
/// Bundan tashqari, `Fn` ni amalga oshiradigan har qanday `F` turi uchun `&F` ham `Fn` ni amalga oshiradi.
///
/// [`FnMut`] va [`FnOnce`] ikkalasi ham `Fn` supertraitlari bo'lganligi sababli, `Fn` ning har qanday nusxasi [`FnMut`] yoki [`FnOnce`] kutilgan parametr sifatida ishlatilishi mumkin.
///
/// Agar funktsiyaga o'xshash turdagi parametrlarni qabul qilmoqchi bo'lsangiz va uni mutatsiyasiz holatga qayta-qayta qo'ng'iroq qilishingiz kerak bo'lsa (masalan, bir vaqtning o'zida chaqirganda), `Fn`-ni cheklangan sifatida foydalaning.
/// Agar sizga bunday qattiq talablar kerak bo'lmasa, [`FnMut`] yoki [`FnOnce`]-dan chegara sifatida foydalaning.
///
/// Ushbu mavzu bo'yicha qo'shimcha ma'lumot olish uchun [chapter on closures in *The Rust Programming Language*][book]-ga qarang.
///
/// `Fn` traits uchun maxsus sintaksis ham e'tiborga loyiq (masalan
/// `Fn(usize, bool) -> usize`).Buning texnik tafsilotlariga qiziquvchilar [the relevant section in the *Rustonomicon*][nomicon]-ga murojaat qilishlari mumkin.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Yopilishga chaqirish
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` parametridan foydalanish
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // shunday qilib regex ushbu `&str: !FnMut` ga ishonishi mumkin
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Qo'ng'iroq operatsiyasini bajaradi.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// O'zgaruvchan qabul qiluvchini qabul qiladigan qo'ng'iroq operatorining versiyasi.
///
/// `FnMut` nusxalarini qayta-qayta chaqirish mumkin va holat mutatsiyaga uchrashi mumkin.
///
/// `FnMut` avtomatik ravishda qo'lga kiritilgan o'zgaruvchilarga o'zgaruvchan mos yozuvlar kiritilgan [`Fn`], masalan, (safe) [function pointers] (masalan, `FnMut` [`Fn`] supertraitidir) o'zgarishi mumkin bo'lgan mos yozuvlar yordamida amalga oshiriladi.
/// Bundan tashqari, `FnMut` ni amalga oshiradigan har qanday `F` turi uchun `&mut F` ham `FnMut` ni amalga oshiradi.
///
/// [`FnOnce`] `FnMut` supertrait bo'lgani uchun `FnMut` ning har qanday misoli [`FnOnce`] kutilayotgan joyda ishlatilishi mumkin va [`Fn`] `FnMut` subtraitida bo'lgani uchun `FnMut` ning istalgan nusxasi `FnMut` kutilayotgan joyda ishlatilishi mumkin.
///
/// `FnMut`-ni funktsiyaga o'xshash turdagi parametrni qabul qilmoqchi bo'lganingizda va uni mutatsiyalashga imkon berganda, uni qayta-qayta chaqirishingiz kerak bo'lganda, cheklangan sifatida foydalaning.
/// Agar parametr mutatsiyaga uchraganligini xohlamasangiz, [`Fn`] ni chegaralangan sifatida ishlating;agar sizga qayta-qayta qo'ng'iroq qilishning hojati bo'lmasa, [`FnOnce`]-dan foydalaning.
///
/// Ushbu mavzu bo'yicha qo'shimcha ma'lumot olish uchun [chapter on closures in *The Rust Programming Language*][book]-ga qarang.
///
/// `Fn` traits uchun maxsus sintaksis ham e'tiborga loyiq (masalan
/// `Fn(usize, bool) -> usize`).Buning texnik tafsilotlariga qiziquvchilar [the relevant section in the *Rustonomicon*][nomicon]-ga murojaat qilishlari mumkin.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## O'zgaruvchan tutilishni yopishni chaqirish
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` parametridan foydalanish
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // shunday qilib regex ushbu `&str: !FnMut` ga ishonishi mumkin
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Qo'ng'iroq operatsiyasini bajaradi.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Qabul qiluvchini qabul qiladigan qo'ng'iroq operatorining versiyasi.
///
/// `FnOnce` nusxalarini chaqirish mumkin, lekin ularni bir necha marta chaqirish mumkin emas.Shu sababli, agar `FnOnce`-ni amalga oshiradigan narsa haqida faqat bitta narsa ma'lum bo'lsa, uni faqat bir marta chaqirish mumkin.
///
/// `FnOnce` qo'lga kiritilgan o'zgaruvchilarni iste'mol qilishi mumkin bo'lgan yopilishlar, shuningdek [`FnMut`] ni amalga oshiradigan barcha turlar, masalan, (safe) [function pointers] tomonidan avtomatik ravishda amalga oshiriladi (chunki `FnOnce`-[`FnMut`] ning supertraitidir).
///
///
/// [`Fn`] va [`FnMut`] ikkalasi ham `FnOnce` subtraitlari bo'lganligi sababli, [`Fn`] yoki [`FnMut`] ning har qanday nusxasi `FnOnce` kutilgan joyda ishlatilishi mumkin.
///
/// Agar funktsiyaga o'xshash turdagi parametrni qabul qilmoqchi bo'lsangiz va uni faqat bir marta chaqirishingiz kerak bo'lsa, `FnOnce`-ni cheklangan sifatida foydalaning.
/// Agar parametrni qayta-qayta chaqirishingiz kerak bo'lsa, [`FnMut`]-ni cheklangan sifatida ishlating;agar sizga mutatsiyaga tushmaslik uchun kerak bo'lsa, [`Fn`] dan foydalaning.
///
/// Ushbu mavzu bo'yicha qo'shimcha ma'lumot olish uchun [chapter on closures in *The Rust Programming Language*][book]-ga qarang.
///
/// `Fn` traits uchun maxsus sintaksis ham e'tiborga loyiq (masalan
/// `Fn(usize, bool) -> usize`).Buning texnik tafsilotlariga qiziquvchilar [the relevant section in the *Rustonomicon*][nomicon]-ga murojaat qilishlari mumkin.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` parametridan foydalanish
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ushlangan o'zgaruvchilarni iste'mol qiladi, shuning uchun uni bir necha marta ishlatish mumkin emas.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()`-ni qayta chaqirishga urinish `func` uchun `use of moved value` xatosini keltirib chiqaradi.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` endi bu erda chaqirish mumkin emas
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // shunday qilib regex ushbu `&str: !FnMut` ga ishonishi mumkin
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Qo'ng'iroq operatoridan keyin qaytarilgan tur.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Qo'ng'iroq operatsiyasini bajaradi.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}