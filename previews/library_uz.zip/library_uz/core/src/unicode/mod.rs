#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// Unicode qismlari `char` va `str` usullariga asoslangan [Unicode](http://www.unicode.org/) versiyasi.
///
/// Unicode-ning yangi versiyalari muntazam ravishda chiqariladi va keyinchalik Unicode-ga bog'liq bo'lgan standart kutubxonadagi barcha usullar yangilanadi.
/// Shuning uchun ba'zi `char` va `str` usullarining xatti-harakatlari va bu doimiy qiymat vaqt o'tishi bilan o'zgarib turadi.
/// Bu *keskin o'zgarish deb hisoblanmaydi*.
///
/// Versiya raqamlash sxemasi [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) da tushuntirilgan.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Liballoc-da foydalanish uchun, libstd-da reeksport qilinmaydi.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;