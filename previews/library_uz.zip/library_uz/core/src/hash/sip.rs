//! SipHash dasturini amalga oshirish.

#![allow(deprecated)] // ushbu modulning turlari eskirgan

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// SipHash 1-3 dasturini amalga oshirish.
///
/// Hozirda bu standart kutubxonada ishlatiladigan standart xeshlash funktsiyasi (masalan, `collections::HashMap` uni sukut bo'yicha ishlatadi).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// SipHash 2-4 dasturini amalga oshirish.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// SipHash 2-4 dasturini amalga oshirish.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash-bu umumiy maqsadli xeshlash funktsiyasi: u yaxshi tezlikda ishlaydi (Spooky va City bilan raqobatdosh) va kuchli _keyed_ xeshlash imkoniyatini beradi.
///
/// Bu sizning xash jadvallaringizni kuchli RNG-dan, masalan, [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html)-dan klaviatura qilishingizga imkon beradi.
///
/// SipHash algoritmi umuman kuchli deb hisoblansa ham, u kriptografik maqsadlar uchun mo'ljallanmagan.
/// Shunday qilib, ushbu dasturning barcha kriptografik ishlatilishi _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // qancha baytni qayta ishladik
    state: State,  // xash davlat
    tail: u64,     // qayta ishlanmagan baytlar le
    ntail: usize,  // quyruqdagi qancha bayt to'g'ri
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 va v1, v3 algoritmda juft bo'lib ko'rinadi va SipHash-ning simd dasturlari v02 va v13 ning vectors-dan foydalanadi.
    //
    // Strukturada ularni shu tartibda joylashtirib, kompilyator o'zi tomonidan bir nechta simd optimallashtirishni tanlashi mumkin.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Kerakli turdagi butun sonni bayt oqimidan LE tartibida yuklaydi.
/// `copy_nonoverlapping`-dan foydalanib, kompilyatorga uni ehtimol mos kelmagan manzildan yuklashning eng samarali usulini yaratishi mumkin.
///
///
/// Xavfsiz, chunki: i..i+size_of(int_ty) da tekshirilmagan indekslash
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// 7 baytgacha bo'lgan bayt bo'lagi yordamida u64-ni yuklaydi.
/// Bu beparvoga o'xshaydi, lekin paydo bo'ladigan `copy_nonoverlapping` qo'ng'iroqlari (`load_int_le!` orqali) aniq o'lchamlarga ega va `memcpy` qo'ng'iroqlaridan qochadi, bu tezlik uchun yaxshi
///
///
/// Xavfsiz, chunki: boshlash paytida tekshirilmagan indekslash .. start + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // joriy bayt indeksi (LSB dan) u64 chiqishda
    let mut out = 0;
    if i + 3 < len {
        // XAVFSIZLIK: `i` `len` dan katta bo'lishi mumkin emas va qo'ng'iroq qiluvchining kafolati bo'lishi kerak
        // start start..start + len chegarada.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // XAVFSIZLIK: yuqoridagi kabi.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // XAVFSIZLIK: yuqoridagi kabi.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// 0 ga o'rnatilgan ikkita boshlang'ich tugmachasi bilan yangi `SipHasher` yaratadi.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Taqdim etilgan kalitlardan o'chirilgan `SipHasher` yaratadi.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// 0 ga o'rnatilgan ikkita boshlang'ich tugmachasi bilan yangi `SipHasher13` yaratadi.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Taqdim etilgan kalitlardan o'chirilgan `SipHasher13` yaratadi.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: butun sonli aralashtirish usullari aniqlanmagan (`write_u *`, `write_i*`)
    // ushbu tur uchun.
    // Biz ularni qo'shib, `short_write` dasturini librustc_data_structures/sip128.rs-ga nusxalashimiz va `SipHasher`, `SipHasher13` va `DefaultHasher`-ga `write_u *`/`write_i*` usullarini qo'shishimiz mumkin.
    //
    // Bu ba'zi bir ko'rsatkichlar bo'yicha kompilyatsiya tezligini biroz sekinlatish evaziga ushbu hasherlar tomonidan butun sonli xeshni juda tezlashtiradi.
    // Tafsilotlar uchun #69152-ga qarang.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // XAVFSIZLIK: `cmp::min(length, needed)` `length` dan oshmasligi kafolatlanadi
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Buferlangan quyruq endi yuviladi, yangi kirishni qayta ishlaydi.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // XAVFSIZLIK: chunki `len - left` 8 tagidagi eng katta katak hisoblanadi
            // `len`, va `i` `needed` dan boshlanganligi sababli `len` `length - needed` bo'ladi, chunki `i + 8` `length` dan kam yoki unga teng bo'lishi kafolatlanadi.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // XAVFSIZLIK: `i` endi `needed + len.div_euclid(8) * 8`,
        // shuning uchun `i + left` = `needed + len` = `length`, bu ta'rifi bo'yicha `msg.len()` ga teng.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// 0 ga o'rnatilgan ikkita boshlang'ich tugmachasi bilan `Hasher<S>` yaratadi.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}