#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` vazifa ijrochisining bajaruvchisiga moslashtirilgan uyg'onish xatti-harakatini ta'minlaydigan [`Waker`] yaratishga imkon beradi.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// U ma'lumotlar ko'rsatgichidan va `RawWaker` xatti-harakatlarini moslashtiradigan [virtual function pointer table (vtable)][vtable] dan iborat.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Ijrochining talabiga binoan o'zboshimchalik bilan ma'lumotlarni saqlash uchun ishlatilishi mumkin bo'lgan ma'lumot ko'rsatkichi.
    /// Bu, masalan, bo'lishi mumkin
    /// vazifa bilan bog'liq bo'lgan `Arc`-ga o'chirilgan ko'rsatgich.
    /// Ushbu maydon qiymati vtable tarkibiga kiruvchi barcha funktsiyalarga birinchi parametr sifatida o'tadi.
    ///
    data: *const (),
    /// Ushbu uyg'otuvchining xatti-harakatlarini moslashtiradigan virtual funktsiyalar ko'rsatkichlari jadvali.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Taqdim etilgan `data` ko'rsatgichidan va `vtable` dan yangi `RawWaker` yaratadi.
    ///
    /// `data` ko'rsatgichidan ijrochining talabiga binoan o'zboshimchalik bilan ma'lumotlarni saqlash uchun foydalanish mumkin.Bu, masalan, bo'lishi mumkin
    /// vazifa bilan bog'liq bo'lgan `Arc`-ga o'chirilgan ko'rsatgich.
    /// Ushbu ko'rsatkichning qiymati birinchi parametr sifatida `vtable` tarkibiga kiruvchi barcha funktsiyalarga o'tadi.
    ///
    /// `vtable` `RawWaker` dan yaratilgan `Waker` xatti-harakatlarini moslashtiradi.
    /// `Waker`-dagi har bir operatsiya uchun `RawWaker`-ning asosidagi `vtable`-dagi bog'liq funktsiya chaqiriladi.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// [`RawWaker`] xatti-harakatini belgilaydigan (vtable) virtual funktsiyasi ko'rsatkich jadvali.
///
/// Vtable ichidagi barcha funktsiyalarga uzatilgan ko'rsatgich, [`RawWaker`] ob'ektidan olingan `data` ko'rsatkichidir.
///
/// Ushbu strukturadagi funktsiyalar faqat [`RawWaker`] dasturining ichidan to'g'ri qurilgan [`RawWaker`] ob'ektining `data` ko'rsatkichiga qo'ng'iroq qilish uchun mo'ljallangan.
/// Tarkibidagi funktsiyalardan biriga boshqa har qanday `data` ko'rsatgichidan foydalanib qo'ng'iroq qilish noaniq xatti-harakatga olib keladi.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Ushbu funktsiya [`RawWaker`] klonlanganda, masalan, [`RawWaker`] saqlanadigan [`Waker`] klonlanganda chaqiriladi.
    ///
    /// Ushbu funktsiyani amalga oshirish ushbu qo'shimcha [`RawWaker`] misoli va unga tegishli vazifa uchun zarur bo'lgan barcha manbalarni saqlab qolishi kerak.
    /// Natijada paydo bo'lgan [`RawWaker`]-ga `wake`-ni chaqirish asl [`RawWaker`] tomonidan uyg'ongan vazifani uyg'otishiga olib kelishi kerak.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Ushbu funktsiya [`Waker`] da `wake` chaqirilganda chaqiriladi.
    /// Ushbu [`RawWaker`] bilan bog'liq vazifani uyg'otishi kerak.
    ///
    /// Ushbu funktsiyani amalga oshirish ushbu [`RawWaker`] misoli va tegishli vazifa bilan bog'liq bo'lgan barcha manbalarni chiqarishga ishonch hosil qilishi kerak.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Ushbu funktsiya [`Waker`] da `wake_by_ref` chaqirilganda chaqiriladi.
    /// Ushbu [`RawWaker`] bilan bog'liq vazifani uyg'otishi kerak.
    ///
    /// Ushbu funktsiya `wake` ga o'xshaydi, lekin taqdim etilgan ma'lumot ko'rsatkichini iste'mol qilmasligi kerak.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Ushbu funktsiya [`RawWaker`] tushganda chaqiriladi.
    ///
    /// Ushbu funktsiyani amalga oshirish ushbu [`RawWaker`] misoli va tegishli vazifa bilan bog'liq bo'lgan barcha manbalarni chiqarishga ishonch hosil qilishi kerak.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Taqdim etilgan `clone`, `wake`, `wake_by_ref` va `drop` funktsiyalaridan yangi `RawWakerVTable` yaratadi.
    ///
    /// # `clone`
    ///
    /// Ushbu funktsiya [`RawWaker`] klonlanganda, masalan, [`RawWaker`] saqlanadigan [`Waker`] klonlanganda chaqiriladi.
    ///
    /// Ushbu funktsiyani amalga oshirish ushbu qo'shimcha [`RawWaker`] misoli va unga tegishli vazifa uchun zarur bo'lgan barcha manbalarni saqlab qolishi kerak.
    /// Natijada paydo bo'lgan [`RawWaker`]-ga `wake`-ni chaqirish asl [`RawWaker`] tomonidan uyg'ongan vazifani uyg'otishiga olib kelishi kerak.
    ///
    /// # `wake`
    ///
    /// Ushbu funktsiya [`Waker`] da `wake` chaqirilganda chaqiriladi.
    /// Ushbu [`RawWaker`] bilan bog'liq vazifani uyg'otishi kerak.
    ///
    /// Ushbu funktsiyani amalga oshirish ushbu [`RawWaker`] misoli va tegishli vazifa bilan bog'liq bo'lgan barcha manbalarni chiqarishga ishonch hosil qilishi kerak.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Ushbu funktsiya [`Waker`] da `wake_by_ref` chaqirilganda chaqiriladi.
    /// Ushbu [`RawWaker`] bilan bog'liq vazifani uyg'otishi kerak.
    ///
    /// Ushbu funktsiya `wake` ga o'xshaydi, lekin taqdim etilgan ma'lumot ko'rsatkichini iste'mol qilmasligi kerak.
    ///
    /// # `drop`
    ///
    /// Ushbu funktsiya [`RawWaker`] tushganda chaqiriladi.
    ///
    /// Ushbu funktsiyani amalga oshirish ushbu [`RawWaker`] misoli va tegishli vazifa bilan bog'liq bo'lgan barcha manbalarni chiqarishga ishonch hosil qilishi kerak.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Asenkron vazifaning `Context`-si.
///
/// Hozirgi vaqtda `Context` faqat `&Waker`-ga kirish vazifasini bajaradi, undan hozirgi vazifani uyg'otish uchun foydalanish mumkin.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // future-ning o'zgaruvchanlik o'zgarishiga qarshi ekanligiga ishonch hosil qiling, chunki umrni o'zgarmas bo'lishga majbur qiling (argument-pozitsiya umrlari ziddiyatli, qaytarish pozitsiyasining umrlari esa kovariant).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker`-dan yangi `Context` yarating.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Joriy vazifa uchun `Waker`-ga havolani qaytaradi.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker`-bu vazifani bajarishga tayyorligi to'g'risida ijrochini ogohlantirish orqali uni uyg'otish uchun tutqich.
///
/// Ushbu dastani ijrochiga xos uyg'onish xatti-harakatini belgilaydigan [`RawWaker`] nusxasini qamrab oladi.
///
///
/// [`Clone`], [`Send`] va [`Sync`]-ni amalga oshiradi.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Ushbu `Waker` bilan bog'liq vazifani uyg'oting.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Haqiqiy uyg'onish chaqiruvi ijro etuvchi tomonidan belgilanadigan dasturga virtual funktsiya chaqiruvi orqali beriladi.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` raqamiga qo'ng'iroq qilmang-xaker `wake` tomonidan iste'mol qilinadi.
        crate::mem::forget(self);

        // XAVFSIZLIK: Bu xavfsiz, chunki `Waker::from_raw` yagona yo'ldir
        // `wake` va `data`-ni ishga tushirish uchun foydalanuvchidan `RawWaker` shartnomasi bajarilishini tan olishini talab qiladi.
        //
        unsafe { (wake)(data) };
    }

    /// Ushbu `Waker` bilan bog'liq vazifani `Waker` ni iste'mol qilmasdan uyg'oning.
    ///
    /// Bu `wake` ga o'xshaydi, ammo tegishli `Waker` mavjud bo'lgan taqdirda unchalik samarasiz bo'lishi mumkin.
    /// Ushbu usul `waker.clone().wake()`-ga qo'ng'iroq qilishdan afzal bo'lishi kerak.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Haqiqiy uyg'onish chaqiruvi ijro etuvchi tomonidan belgilanadigan dasturga virtual funktsiya chaqiruvi orqali beriladi.
        //

        // XAVFSIZLIK: `wake` ga qarang
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Agar bu `Waker` va boshqa `Waker` xuddi shu vazifani uyg'otgan bo'lsa, `true`-ni qaytaradi.
    ///
    /// Ushbu funktsiya maksimal darajada ishlaydi va hatto Waker xuddi shu vazifani uyg'otganda ham noto'g'ri bo'lishi mumkin.
    /// Ammo, agar bu funktsiya `true`-ni qaytarsa, Waker-ning xuddi shu vazifani uyg'otishi kafolatlanadi.
    ///
    /// Ushbu funktsiya birinchi navbatda optimallashtirish uchun ishlatiladi.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] dan yangi `Waker` yaratadi.
    ///
    /// Qaytgan `Waker`-ning xatti-harakatlari, agar [RawWaker`] va [`RawWakerVTable`] hujjatlarida belgilangan shartnoma bajarilmasa, aniqlanmagan.
    ///
    /// Shuning uchun bu usul xavfli emas.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // XAVFSIZLIK: Bu xavfsiz, chunki `Waker::from_raw` yagona yo'ldir
            // `clone` va `data`-ni ishga tushirish uchun foydalanuvchidan [`RawWaker`] shartnomasi bajarilishini tan olishini talab qiladi.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // XAVFSIZLIK: Bu xavfsiz, chunki `Waker::from_raw` yagona yo'ldir
        // `drop` va `data`-ni ishga tushirish uchun foydalanuvchidan `RawWaker` shartnomasi bajarilishini tan olishini talab qiladi.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}