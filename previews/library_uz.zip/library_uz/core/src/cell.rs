//! Birgalikda o'zgarishi mumkin bo'lgan idishlar.
//!
//! Rust xotirasi xavfsizligi ushbu qoidaga asoslanadi: `T` ob'ekti hisobga olinsa, quyidagilardan bittasi bo'lishi mumkin:
//!
//! - Ob'ektga bir nechta o'zgarmas havolalarga ega bo'lish (shuningdek,**aliasing** deb nomlanadi).
//! - Ob'ektga bitta o'zgaruvchan ma'lumot ("&mut T`")(shuningdek **o'zgaruvchanlik** deb nomlanadi) ega.
//!
//! Bu Rust kompilyatori tomonidan amalga oshiriladi.Biroq, ushbu qoida etarlicha moslashuvchan bo'lmagan holatlar mavjud.Ba'zan ob'ektga bir nechta murojaat qilish va shu bilan mutatsiyani o'zgartirish talab qilinadi.
//!
//! Birgalikda o'zgarishi mumkin bo'lgan idishlar mutatsiyani boshqariladigan tartibda, hattoki taxallus mavjud bo'lganda ham ruxsat etish uchun mavjud.[`Cell<T>`] va [`RefCell<T>`] ikkalasi ham buni bitta ipli usulda bajarishga imkon beradi.
//! Biroq, `Cell<T>` ham, `RefCell<T>` ham zararli xavfsiz emas (ular [`Sync`] ni amalga oshirmaydilar).
//! Agar siz bir nechta iplar orasidagi taxallus va mutatsiyani bajarishingiz kerak bo'lsa, [`Mutex<T>`], [`RwLock<T>`] yoki [`atomic`] turlaridan foydalanish mumkin.
//!
//! `Cell<T>` va `RefCell<T>` turlarining qiymatlari umumiy ma'lumotnomalar yordamida mutatsiyaga uchragan bo'lishi mumkin (ya'ni
//! umumiy `&T` turi), aksariyat Rust turlari faqat noyob (`&mut T`) havolalar orqali mutatsiyaga uchraydi.
//! Aytishimizcha, `Cell<T>` va `RefCell<T>` "ichki o'zgaruvchanlikni" ta'minlaydi, aksincha "irsiy o'zgaruvchanlik" ni namoyish qiladigan Rust tiplaridan.
//!
//! Hujayra turlari ikki xil: `Cell<T>` va `RefCell<T>`.`Cell<T>` `Cell<T>` ichkarisida va tashqarisida qiymatlarni siljitish orqali ichki o'zgaruvchanlikni amalga oshiradi.
//! Qadriyatlar o'rniga havolalarni ishlatish uchun mutatsiyadan oldin yozishni blokirovka qilib, `RefCell<T>` turini ishlatish kerak.`Cell<T>` joriy ichki qiymatini olish va o'zgartirish usullarini taqdim etadi:
//!
//!  - [`Copy`]-ni amalga oshiradigan turlar uchun [`get`](Cell::get) usuli joriy ichki qiymatni oladi.
//!  - [`Default`] ni amalga oshiradigan turlar uchun [`take`](Cell::take) usuli joriy ichki qiymatni [`Default::default()`] bilan almashtiradi va o'zgartirilgan qiymatni qaytaradi.
//!  - Barcha turlar uchun [`replace`](Cell::replace) usuli joriy ichki qiymatni almashtiradi va o'zgartirilgan qiymatni qaytaradi va [`into_inner`](Cell::into_inner) usuli `Cell<T>` ni iste'mol qiladi va ichki qiymatni qaytaradi.
//!  Bundan tashqari, [`set`](Cell::set) usuli ichki qiymatni almashtiradi, o'zgartirilgan qiymatni tushiradi.
//!
//! `RefCell<T>` "dinamik qarz olish" ni amalga oshirish uchun Rust-ning hayotiy vaqtidan foydalanadi, bu jarayon ichki qiymatga vaqtincha, eksklyuziv va o'zgaruvchan kirishni talab qilishi mumkin.
//! RefCell uchun qarzlar<T>Rust-ning mahalliy mos yozuvlar turlaridan farqli o'laroq, ular "ish vaqtida" kuzatiladi, ular kompilyatsiya vaqtida to'liq statik ravishda kuzatiladi.
//! `RefCell<T>` qarzlari dinamik bo'lganligi sababli, o'zaro almashinib qarzga olingan qiymatni olishga harakat qilish mumkin;Bu sodir bo'lganda, u panic ipiga olib keladi.
//!
//! # Ichki o'zgaruvchanlikni qachon tanlash kerak
//!
//! Qiymatni mutatsiyalash uchun noyob kirish huquqiga ega bo'lishi kerak bo'lgan keng tarqalgan merosxo'rlik o'zgaruvchanligi, bu Rust-ga ko'rsatgichlarni taxallus qilish to'g'risida jiddiy fikr yuritishga imkon beradigan va buzilish xatolarini statik ravishda oldini olishga imkon beradigan asosiy til elementlaridan biridir.
//! Shu sababli, meros qilib olingan mutatsiyaga ustunlik beriladi va ichki o'zgaruvchanlik so'nggi chora hisoblanadi.
//! Hujayra turlari mutatsiyani boshqa yo'l qo'yilmasa ham faollashtirishi sababli, ichki mutatsiyaga mos keladigan holatlar mavjud, hattoki *ishlatilishi kerak*, masalan.
//!
//! * O'zgaruvchan 'inside' o'zgaruvchanligini joriy qilish
//! * Mantiqiy-o'zgarmas usullarni amalga oshirish tafsilotlari.
//! * [`Clone`] dasturlarining mutatsiyaga uchraganligi.
//!
//! ## O'zgaruvchan 'inside' o'zgaruvchanligini joriy qilish
//!
//! [`Rc<T>`] va [`Arc<T>`] kabi ko'plab umumiy aqlli ko'rsatgich turlari, klonlashi va bir nechta tomonlar o'rtasida bo'lishishi mumkin bo'lgan konteynerlarni taqdim etadi.
//! Tarkibidagi qiymatlar ko'p sonli bo'lishi mumkinligi sababli, ularni `&mut` emas, faqat `&` bilan olish mumkin.
//! Hujayralarsiz ushbu aqlli ko'rsatkichlar ichidagi ma'lumotlarni mutatsiyalash umuman mumkin emas.
//!
//! O'zgaruvchanlikni qayta tiklash uchun `RefCell<T>`-ni birgalikda ko'rsatgich turlariga qo'yish juda keng tarqalgan:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Dinamik qarz olish doirasini cheklash uchun yangi blok yarating
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // E'tibor bering, agar biz keshning avvalgi qarzlari doirasidan chiqib ketishiga yo'l qo'ymasak, u holda keyingi qarz dinamik panic oqimiga olib keladi.
//!     //
//!     // Bu `RefCell`-dan foydalanishning asosiy xavfi.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Ushbu misolda `Arc<T>` emas, balki `Rc<T>` ishlatilishini unutmang.RefCell<T>lar bitta yo'nalishli stsenariylarga mo'ljallangan.Ko'p tarmoqli vaziyatda birgalikda o'zgaruvchanlik zarur bo'lsa, [`RwLock<T>`] yoki [`Mutex<T>`] dan foydalanishni o'ylab ko'ring.
//!
//! ## Mantiqiy-o'zgarmas usullarni amalga oshirish tafsilotlari
//!
//! Ba'zan API-da "under the hood" sodir bo'layotgan mutatsiya haqida fosh qilmaslik ma'qul bo'lishi mumkin.
//! Buning sababi mantiqan operatsiya o'zgarmas bo'lishi mumkin, ammo masalan, keshlash dasturni mutatsiyani amalga oshirishga majbur qiladi;yoki dastlab `&self` olish uchun belgilangan trait usulini amalga oshirish uchun mutatsiyadan foydalanishingiz kerak.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Qimmatbaho hisoblash bu erga boradi
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` dasturlarining mutatsiyaga uchraganligi
//!
//! Bu shunchaki avvalgi holatning maxsus, ammo keng tarqalgan hodisasidir: o'zgarmas bo'lib ko'rinadigan operatsiyalar uchun mutatsiyani yashirish.
//! [`clone`](Clone::clone) usuli manba qiymatini o'zgartirmasligi kutilmoqda va `&mut self` emas, `&self` qabul qilinishi e'lon qilindi.
//! Shuning uchun `clone` usulida yuz beradigan har qanday mutatsiya hujayralar turlaridan foydalanishi kerak.
//! Masalan, [`Rc<T>`] mos yozuvlar sonini `Cell<T>` ichida saqlaydi.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// O'zgaruvchan xotira joylashuvi.
///
/// # Examples
///
/// Ushbu misolda siz `Cell<T>` o'zgarmas struktura ichida mutatsiyani yoqishini ko'rishingiz mumkin.
/// Boshqacha qilib aytganda, bu "interior mutability"-ni yoqadi.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // Xato: `my_struct` o'zgarmasdir
/// // my_struct.regular_field =new_value;
///
/// // ISHLAR: garchi `my_struct` o'zgarmas bo'lsa ham, `special_field` bu `Cell`,
/// // har doim mutatsiyaga uchragan bo'lishi mumkin
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Qo'shimcha ma'lumot uchun [module-level documentation](self)-ga qarang.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T uchun `Default` qiymatiga ega bo'lgan `Cell<T>` hosil qiladi.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Berilgan qiymatni o'z ichiga olgan yangi `Cell` yaratadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Ichki qiymatni o'rnatadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Ikki Hujayraning qiymatlarini almashtiradi.
    /// `std::mem::swap` bilan farqi shundaki, bu funktsiya `&mut` ma'lumotnomasini talab qilmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // XAVFSIZLIK: Agar bu alohida iplardan chaqirilsa, bu xavfli bo'lishi mumkin, ammo `Cell`
        // bu `!Sync`, shuning uchun bunday bo'lmaydi.
        // Bundan tashqari, bu biron bir ko'rsatgichni bekor qilmaydi, chunki `Cell` ushbu "Hujayralar" ning hech biriga ishora qilmasligiga ishonch hosil qiladi.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// O'z ichiga olgan qiymatni `val` bilan almashtiradi va eski qadriyatni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // XAVFSIZLIK: Bu alohida mavzudan chaqirilsa, ma'lumotlar poygalariga sabab bo'lishi mumkin,
        // lekin `Cell` bu `!Sync`, shuning uchun bunday bo'lmaydi.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Qiymatni ochadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Tarkibidagi qiymatning nusxasini qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // XAVFSIZLIK: Bu alohida mavzudan chaqirilsa, ma'lumotlar poygalariga sabab bo'lishi mumkin,
        // lekin `Cell` bu `!Sync`, shuning uchun bunday bo'lmaydi.
        unsafe { *self.value.get() }
    }

    /// Mavjud qiymatni funktsiya yordamida yangilaydi va yangi qiymatni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Ushbu katakdagi asosiy ma'lumotlarga xom ko'rsatkichni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Asosiy ma'lumotlarga o'zgaruvchan ma'lumotni qaytaradi.
    ///
    /// Ushbu qo'ng'iroq `Cell`-ni mutanosib ravishda oladi (kompilyatsiya vaqtida), bu bizning yagona ma'lumotnomamizga ega bo'lishiga kafolat beradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T` dan `&Cell<T>` qaytaradi
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // XAVFSIZLIK: `&mut` noyob kirishni ta'minlaydi.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// `Default::default()` o'rnida qoldirib, hujayraning qiymatini oladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>` dan `&[Cell<T>]` qaytaradi
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // XAVFSIZLIK: `Cell<T>` `T` bilan bir xil xotira tartibiga ega.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Dinamik ravishda tekshirilgan qarz olish qoidalariga ega o'zgaruvchan xotira joylashuvi
///
/// Qo'shimcha ma'lumot uchun [module-level documentation](self)-ga qarang.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] tomonidan qaytarilgan xato.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] tomonidan qaytarilgan xato.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Ijobiy qiymatlar faol `Ref` sonini bildiradi.Salbiy qiymatlar faol `RefMut` sonini bildiradi.
// Bir nechta "RefMut" faqat bir vaqtning o'zida faol bo'lishi mumkin, agar ular `RefCell` ning bir-biriga mos kelmaydigan qismlariga murojaat qilsalar (masalan, tilimning turli diapazonlari).
//
// `Ref` va `RefMut` ikkalasi ham ikki so'zdan iborat, shuning uchun `usize` diapazonining yarmini to'ldirish uchun hech qachon "Ref" yoki "RefMut" mavjud bo'lmaydi.
// Shunday qilib, `BorrowFlag` hech qachon toshib ketmaydi yoki to'kilmaydi.
// Ammo bu kafolat emas, chunki patologik dastur qayta-qayta yaratishi mumkin va keyin mem::forget `Ref`s yoki`RefMut`s.
// Shunday qilib, barcha kodlar havfsizlikni oldini olish uchun yoki hech bo'lmaganda toshib ketish yoki tushish sodir bo'lganda o'zini to'g'ri tutishi uchun toshib ketish va to'kilishni tekshirishi kerak (masalan, BorrowRef::new ga qarang).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` o'z ichiga olgan yangi `RefCell` yaratadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// O'ralgan qiymatni qaytarib, `RefCell` iste'mol qiladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Ushbu funktsiya qiymati bo'yicha `self` (`RefCell`) ni qabul qilganligi sababli, kompilyator statik ravishda uning hozirda olinmaganligini tekshiradi.
        //
        self.value.into_inner()
    }

    /// O'ralgan qiymatni eskirgan qiymatini qaytarib, yangisini almashtiradi, ikkinchisini deinisializatsiya qilmasdan.
    ///
    ///
    /// Ushbu funktsiya [`std::mem::replace`](../mem/fn.replace.html) ga mos keladi.
    ///
    /// # Panics
    ///
    /// Agar qiymat hozirda olingan bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// O'ralgan qiymatni `f`-dan hisoblangan yangisi bilan almashtiradi, eskirgan qiymatini qaytarib, ikkinchisini deinisallashtirmasdan.
    ///
    ///
    /// # Panics
    ///
    /// Agar qiymat hozirda olingan bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `self` ning o'ralgan qiymatini `other` qiymatiga almashtiradi, ikkinchisini deinitsializatsiya qilmasdan.
    ///
    ///
    /// Ushbu funktsiya [`std::mem::swap`](../mem/fn.swap.html) ga mos keladi.
    ///
    /// # Panics
    ///
    /// Panics, agar har ikkala `RefCell` qiymatlari hozirda qarzga olingan bo'lsa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// O'ralgan qiymatni o'zgarmas ravishda qarzga oladi.
    ///
    /// Qarz qaytarilgan `Ref` doirasidan chiqib ketguncha davom etadi.
    /// Bir vaqtning o'zida bir nechta o'zgarmas qarzlarni olish mumkin.
    ///
    /// # Panics
    ///
    /// Agar qiymat hozirda mutanosib ravishda qarzga olingan bo'lsa, Panics.
    /// Vahima qo'zg'atmaydigan variant uchun [`try_borrow`](#method.try_borrow)-dan foydalaning.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic misoli:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// O'chirilgan qiymatni o'zgarmas ravishda qarzga oladi va agar qiymat hozirgi vaqtda qarzga olinadigan bo'lsa, xatolikni qaytaradi.
    ///
    ///
    /// Qarz qaytarilgan `Ref` doirasidan chiqib ketguncha davom etadi.
    /// Bir vaqtning o'zida bir nechta o'zgarmas qarzlarni olish mumkin.
    ///
    /// Bu [`borrow`](#method.borrow)-ning vahima qo'zg'atmaydigan variantidir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // XAVFSIZLIK: `BorrowRef` faqat o'zgarmas kirish imkoniyatini beradi
            // qarz olayotganda qiymatiga.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// O'ralgan qiymatni mutanosib ravishda qarzga oladi.
    ///
    /// Qarz qaytarilgan `RefMut` yoki undan kelib chiqadigan barcha "RefMut" lar chiqqunga qadar davom etadi.
    ///
    /// Ushbu qarz faol bo'lganda qiymatni olish mumkin emas.
    ///
    /// # Panics
    ///
    /// Agar qiymat hozirda olingan bo'lsa, Panics.
    /// Vahima qo'zg'atmaydigan variant uchun [`try_borrow_mut`](#method.try_borrow_mut)-dan foydalaning.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic misoli:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// O'chirilgan qiymatni mutanosib ravishda qarzga oladi va agar qiymat hozirda olingan bo'lsa, xatolikni qaytaradi.
    ///
    ///
    /// Qarz qaytarilgan `RefMut` yoki undan kelib chiqadigan barcha "RefMut" lar chiqqunga qadar davom etadi.
    /// Ushbu qarz faol bo'lganda qiymatni olish mumkin emas.
    ///
    /// Bu [`borrow_mut`](#method.borrow_mut)-ning vahima qo'zg'atmaydigan variantidir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // XAVFSIZLIK: `BorrowRef` noyob kirishni kafolatlaydi.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Ushbu katakdagi asosiy ma'lumotlarga xom ko'rsatkichni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Asosiy ma'lumotlarga o'zgaruvchan ma'lumotni qaytaradi.
    ///
    /// Ushbu qo'ng'iroq `RefCell`-ni mutanosib ravishda (kompilyatsiya vaqtida) qarz oladi, shuning uchun dinamik tekshiruvlarga ehtiyoj qolmaydi.
    ///
    /// Ammo ehtiyot bo'ling: bu usul `self` ni o'zgaruvchan bo'lishini kutadi, bu odatda `RefCell` dan foydalanganda bo'lmaydi.
    ///
    /// `self` o'zgarmas bo'lsa, uning o'rniga [`borrow_mut`] usulini ko'rib chiqing.
    ///
    /// Iltimos, iltimos, ushbu usul faqat maxsus holatlarga tegishli ekanligini va odatda siz istagan narsa emasligini bilib qo'ying.
    /// Agar shubha tug'ilsa, uning o'rniga [`borrow_mut`]-dan foydalaning.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Sızdırılan qo'riqchilarning `RefCell` qarz holatiga ta'sirini bekor qiling.
    ///
    /// Ushbu qo'ng'iroq [`get_mut`]-ga o'xshash, ammo ko'proq ixtisoslashgan.
    /// Hech qanday qarz yo'qligini ta'minlash uchun u mutanosib ravishda `RefCell` ssudasini oladi va keyinchalik davlat kuzatuvidagi umumiy qarzlarni tiklaydi.
    /// Agar ba'zi bir `Ref` yoki `RefMut` qarzlari sizib chiqqan bo'lsa, bu dolzarbdir.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// O'chirilgan qiymatni o'zgarmas ravishda qarzga oladi va agar qiymat hozirgi vaqtda qarzga olinadigan bo'lsa, xatolikni qaytaradi.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow`-dan farqli o'laroq, bu usul xavfli emas, chunki u `Ref`-ni qaytarmaydi, shuning uchun qarz bayrog'ini tegmasdan qoldiradi.
    /// Ushbu usul bilan qaytarilgan ma'lumot mavjud bo'lganda, o'zaro bog'liq ravishda `RefCell` ni qarz olish-bu aniqlanmagan xatti-harakatlar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // XAVFSIZLIK: Biz hozir hech kim faol yozmayotganligini tekshiramiz, ammo shunday
            // qo'ng'iroq qiluvchining javobgarligi, qaytarilgan ma'lumotnoma endi ishlatilmaguncha hech kim yozmasligini ta'minlash.
            // Shuningdek, `self.value.get()` `self`-ga tegishli qiymatga ishora qiladi va shuning uchun `self`-ning ishlash muddati davomida kafolatlanadi.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// `Default::default()` o'rnida qoldirib, o'ralgan qiymatni oladi.
    ///
    /// # Panics
    ///
    /// Agar qiymat hozirda olingan bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Agar qiymat hozirda mutanosib ravishda qarzga olingan bo'lsa, Panics.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// T uchun `Default` qiymatiga ega bo'lgan `RefCell<T>` hosil qiladi.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, agar har ikkala `RefCell` qiymatlari hozirda qarzga olingan bo'lsa.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, agar har ikkala `RefCell` qiymatlari hozirda qarzga olingan bo'lsa.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, agar har ikkala `RefCell` qiymatlari hozirda qarzga olingan bo'lsa.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, agar har ikkala `RefCell` qiymatlari hozirda qarzga olingan bo'lsa.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, agar har ikkala `RefCell` qiymatlari hozirda qarzga olingan bo'lsa.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, agar har ikkala `RefCell` qiymatlari hozirda qarzga olingan bo'lsa.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, agar har ikkala `RefCell` qiymatlari hozirda qarzga olingan bo'lsa.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Qarzni ko'paytirish quyidagi hollarda o'qimaydigan qiymatga (<=0) olib kelishi mumkin:
            // 1. Bu <0 edi, ya'ni yozma qarzlar mavjud, shuning uchun Rust-ning mos yozuvlar taxallus qoidalari tufayli o'qishga qarz berishga ruxsat berolmaymiz.
            // 2.
            // Bu isize::MAX (o'qish uchun qarzlarning maksimal miqdori) edi va u isize::MIN ga (yozma qarzlarning maksimal miqdori) tushdi, shuning uchun biz qo'shimcha o'qishga ruxsat berolmaymiz, chunki isize juda ko'p o'qilgan qarzlarni ifodalay olmaydi (bu faqat sodir bo'lishi mumkin siz mem::forget ni oz miqdordagi doimiy miqdordagi Ref'dan ko'proq, bu yaxshi amaliyot emas)
            //
            //
            //
            //
            None
        } else {
            // Qarz miqdorini oshirish quyidagi hollarda o'qish qiymatiga (> 0) olib kelishi mumkin:
            // 1. Bu=0 edi, ya'ni qarz olinmadi va biz birinchi o'qilgan qarzni olamiz
            // 2. Bu> 0 va <isize::MAX edi, ya'ni
            // o'qilgan qarzlar mavjud edi va isize yana bitta o'qilgan qarzni ifodalash uchun etarlicha katta
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Ushbu Ref mavjud bo'lganligi sababli, biz qarz bayrog'i o'qish uchun qarz ekanligini bilamiz.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Qarz hisoblagichining yozma qarzga to'lib ketishini oldini oling.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Qarz qilingan ma'lumotnomani `RefCell` qutisidagi qiymatga o'rab oladi.
/// `RefCell<T>`-dan o'zgarmas qiymatga ega bo'lgan qadoqlash turi.
///
/// Qo'shimcha ma'lumot uchun [module-level documentation](self)-ga qarang.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// `Ref` nusxasini ko'chiradi.
    ///
    /// `RefCell` allaqachon o'zgarmas ravishda qarzga olingan, shuning uchun bu muvaffaqiyatsiz bo'lmaydi.
    ///
    /// Bu `Ref::clone(...)` sifatida ishlatilishi kerak bo'lgan bog'liq funktsiya.
    /// `Clone` dasturi yoki usuli `RefCell` tarkibini klonlash uchun `r.borrow().clone()` ning keng qo'llanilishiga xalaqit beradi.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Qarzga olingan ma'lumotlarning tarkibiy qismi uchun yangi `Ref` ishlab chiqaradi.
    ///
    /// `RefCell` allaqachon o'zgarmas ravishda qarzga olingan, shuning uchun bu muvaffaqiyatsiz bo'lmaydi.
    ///
    /// Bu `Ref::map(...)` sifatida ishlatilishi kerak bo'lgan bog'liq funktsiya.
    /// Usul `Deref` orqali ishlatiladigan `RefCell` tarkibidagi bir xil nomdagi usullarga xalaqit beradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Qarzga olingan ma'lumotlarning ixtiyoriy komponenti uchun yangi `Ref` ishlab chiqaradi.
    /// Dastlabki qo'riqchi `Err(..)` sifatida qaytariladi, agar yopilish `None` ni qaytarsa.
    ///
    /// `RefCell` allaqachon o'zgarmas ravishda qarzga olingan, shuning uchun bu muvaffaqiyatsiz bo'lmaydi.
    ///
    /// Bu `Ref::filter_map(...)` sifatida ishlatilishi kerak bo'lgan bog'liq funktsiya.
    /// Usul `Deref` orqali ishlatiladigan `RefCell` tarkibidagi bir xil nomdagi usullarga xalaqit beradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Qarzga olingan ma'lumotlarning turli tarkibiy qismlari uchun `Ref`-ni bir nechta "Ref" larga ajratadi.
    ///
    /// `RefCell` allaqachon o'zgarmas ravishda qarzga olingan, shuning uchun bu muvaffaqiyatsiz bo'lmaydi.
    ///
    /// Bu `Ref::map_split(...)` sifatida ishlatilishi kerak bo'lgan bog'liq funktsiya.
    /// Usul `Deref` orqali ishlatiladigan `RefCell` tarkibidagi bir xil nomdagi usullarga xalaqit beradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Asosiy ma'lumotlarga havolaga aylantiring.
    ///
    /// Asosiy `RefCell` hech qachon mutanosib ravishda qarzga olinishi mumkin emas va har doim o'zgarmas ravishda qarzga olingan bo'lib ko'rinadi.
    ///
    /// Doimiy ma'lumotnomalardan ko'proq ma'lumot olish yaxshi emas.
    /// Agar jami kamroq miqdordagi qochqinlar sodir bo'lgan bo'lsa, `RefCell`-ni yana qarz olish mumkin.
    ///
    /// Bu `Ref::leak(...)` sifatida ishlatilishi kerak bo'lgan bog'liq funktsiya.
    /// Usul `Deref` orqali ishlatiladigan `RefCell` tarkibidagi bir xil nomdagi usullarga xalaqit beradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Ushbu Refni unutib, biz RefCell-dagi qarz hisoblagichi `'b` umri davomida UNUSED-ga qaytmasligini ta'minlaymiz.
        // Malumotlarni kuzatish holatini tiklash uchun qarz olingan RefCell-ga noyob ma'lumot kerak bo'ladi.
        // Asl katakchadan boshqa o'zgaruvchan havolalar yaratib bo'lmaydi.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Qarzga olingan ma'lumotlarning tarkibiy qismi uchun yangi `RefMut` qiladi, masalan, enum varianti.
    ///
    /// `RefCell` allaqachon mutanosib ravishda qarzga olingan, shuning uchun bu muvaffaqiyatsiz bo'lmaydi.
    ///
    /// Bu `RefMut::map(...)` sifatida ishlatilishi kerak bo'lgan bog'liq funktsiya.
    /// Usul `Deref` orqali ishlatiladigan `RefCell` tarkibidagi bir xil nomdagi usullarga xalaqit beradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): qarz chekini tuzatish
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Qarzga olingan ma'lumotlarning ixtiyoriy komponenti uchun yangi `RefMut` ishlab chiqaradi.
    /// Dastlabki qo'riqchi `Err(..)` sifatida qaytariladi, agar yopilish `None` ni qaytarsa.
    ///
    /// `RefCell` allaqachon mutanosib ravishda qarzga olingan, shuning uchun bu muvaffaqiyatsiz bo'lmaydi.
    ///
    /// Bu `RefMut::filter_map(...)` sifatida ishlatilishi kerak bo'lgan bog'liq funktsiya.
    /// Usul `Deref` orqali ishlatiladigan `RefCell` tarkibidagi bir xil nomdagi usullarga xalaqit beradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): qarz chekini tuzatish
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // XAVFSIZLIK: funktsiya muddati davomida eksklyuziv ma'lumotnomada saqlanadi
        // uning qo'ng'irog'i `orig` orqali va ko'rsatgich faqat funktsiya chaqiruvi ichida havola qilinmaydi, hech qachon eksklyuziv ma'lumotlarning qochib ketishiga yo'l qo'ymaydi.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // XAVFSIZLIK: yuqoridagi kabi.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Qarzga olingan ma'lumotlarning turli xil tarkibiy qismlari uchun `RefMut`-ni bir nechta "RefMut"-larga ajratadi.
    ///
    /// Ikkala qaytarilgan RefMut'lar doirasidan chiqib ketgunga qadar asosiy `RefCell` mutanosib ravishda qarz bo'lib qoladi.
    ///
    /// `RefCell` allaqachon mutanosib ravishda qarzga olingan, shuning uchun bu muvaffaqiyatsiz bo'lmaydi.
    ///
    /// Bu `RefMut::map_split(...)` sifatida ishlatilishi kerak bo'lgan bog'liq funktsiya.
    /// Usul `Deref` orqali ishlatiladigan `RefCell` tarkibidagi bir xil nomdagi usullarga xalaqit beradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Asosiy ma'lumotlarga o'zgaruvchan mos yozuvlarni aylantiring.
    ///
    /// Asosiy `RefCell`-ni yana qarzga olish mumkin emas va har doim mutanosib ravishda qarzga olingan bo'lib ko'rinadi, bu qaytarilgan ma'lumotni ichki qismga yagona qiladi.
    ///
    ///
    /// Bu `RefMut::leak(...)` sifatida ishlatilishi kerak bo'lgan bog'liq funktsiya.
    /// Usul `Deref` orqali ishlatiladigan `RefCell` tarkibidagi bir xil nomdagi usullarga xalaqit beradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Ushbu BorrowRefMut-ni unutib, biz RefCell-dagi qarz hisoblagichi `'b` umri davomida UNUSED-ga qaytmasligini ta'minlaymiz.
        // Malumotlarni kuzatish holatini tiklash uchun qarz olingan RefCell-ga noyob ma'lumot kerak bo'ladi.
        // Ushbu umr davomida asl katakchadan qo'shimcha ma'lumot yaratib bo'lmaydi, shu sababli joriy qarz qolgan umr uchun yagona ma'lumotnoma bo'ladi.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone-dan farqli o'laroq, yangi boshlang'ichni yaratish uchun chaqiriladi
        // o'zgaruvchan mos yozuvlar va shuning uchun hozirda mavjud bo'lgan ma'lumotnomalar bo'lmasligi kerak.
        // Shunday qilib, klon o'zgaruvchan qayta hisoblashni ko'paytirar ekan, biz bu erda faqat UNUSED dan UNUSED, 1 ga o'tishga ruxsat beramiz.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut`-ni klonlaydi.
    //
    // Bu har bir `BorrowRefMut` asl ob'ektning aniq, bir-biriga mos kelmaydigan diapazoniga o'zgaruvchan mos yozuvlarni kuzatish uchun ishlatilgan taqdirdagina amal qiladi.
    //
    // Kod Clone-ni chaqirmasligi uchun bu Clone impl-da emas.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Qarz hisoblagichining to'kilmasligini oldini oling.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>` dan mutanosib ravishda olingan qiymat uchun o'ralgan turi.
///
/// Qo'shimcha ma'lumot uchun [module-level documentation](self)-ga qarang.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust-da ichki o'zgaruvchanlik uchun asosiy ibtidoiy.
///
/// Agar sizda `&T` mos yozuvlar mavjud bo'lsa, unda odatda Rust-da kompilyator `&T` o'zgarmas ma'lumotlarga ishora qilganligi asosida optimallashtirishlarni amalga oshiradi.Ushbu ma'lumotlarning mutatsiyasiga, masalan, taxallus orqali yoki `&T`-ni `&mut T`-ga o'tkazish, aniqlanmagan xatti-harakatlar deb hisoblanadi.
/// `UnsafeCell<T>` `&T` uchun o'zgarmaslik kafolatidan voz kechish: umumiy ma'lumot `&UnsafeCell<T>` mutatsiyaga uchragan ma'lumotlarga ishora qilishi mumkin.Bunga "interior mutability" deyiladi.
///
/// `Cell<T>` va `RefCell<T>` kabi ichki o'zgaruvchanlikka imkon beradigan boshqa barcha turlari o'zlarining ma'lumotlarini o'rash uchun `UnsafeCell` dan foydalanadilar.
///
/// Shuni esda tutingki, `UnsafeCell` faqat umumiy ma'lumotlarning o'zgarmasligini kafolatiga ta'sir qiladi.O'zgaruvchan havolalar uchun o'ziga xoslik kafolati ta'sir qilmaydi.X002 taxallusini olishning * hech qanday qonuniy usuli yo'q, hatto `UnsafeCell<T>` bilan ham.
///
/// `UnsafeCell` API o'zi texnik jihatdan juda sodda: [`.get()`] sizga uning tarkibiga `*mut T` xom ko'rsatgichini beradi.Ushbu xom ko'rsatgichdan to'g'ri foydalanish abstraktsioner sifatida _you_ gacha.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Rust taxallusining aniq qoidalari biroz o'zgaruvchan, ammo asosiy fikrlar munozarali emas:
///
/// - Agar siz `'a` (yoki `&T` yoki `&mut T` ma'lumotnomasi) bilan xavfsiz kodni (masalan, uni qaytarib berganingiz uchun) kirish mumkin bo'lgan xavfsiz ma'lumotnomani yaratsangiz, u holda siz ma'lumotlarga ushbu ma'lumotnomaning qolgan qismiga zid keladigan tarzda kirishingiz kerak emas. `'a`.
/// Masalan, bu shuni anglatadiki, agar siz `*mut T` ni `UnsafeCell<T>` dan olib `&T` ga tashlasangiz, u holda `T` dagi ma'lumotlar o'zgarmas bo'lib qolishi kerak (albatta `T` ichida topilgan har qanday `UnsafeCell` ma'lumotlarini modulyatsiya qilish) shu ma'lumotnomaning ishlash muddati tugamaguncha.
/// Xuddi shunday, agar siz xavfsiz kodga chiqarilgan `&mut T` ma'lumotnomasini yaratadigan bo'lsangiz, u holda ushbu ma'lumotnoma muddati tugamaguncha `UnsafeCell` ichidagi ma'lumotlarga kirishingiz kerak emas.
///
/// - Har doim ma'lumotlar poygalaridan qochishingiz kerak.Agar bir nechta iplar bir xil `UnsafeCell`-ga kirish huquqiga ega bo'lsa, unda har qanday yozuv barcha boshqa kirishlarga (yoki atomikadan foydalanishga) bog'liq holda oldin sodir bo'lishi kerak.
///
/// To'g'ri dizaynga yordam berish uchun quyidagi stsenariylar bitta ipli kod uchun aniq qonuniy deb e'lon qilinadi:
///
/// 1. `&T` ma'lumotnomasi xavfsiz kodga chiqarilishi mumkin va u erda u boshqa `&T` ma'lumotnomalari bilan birga bo'lishi mumkin, ammo `&mut T` bilan emas
///
/// 2. `&mut T` ma'lumotnomasi xavfsiz kodga chiqarilishi mumkin, agar u bilan boshqa `&mut T` ham, `&T` ham mavjud bo'lmasa.`&mut T` har doim noyob bo'lishi kerak.
///
/// Shuni esda tutingki, `&UnsafeCell<T>` tarkibidagi mutatsiyani o'zgartirish (boshqa `&UnsafeCell<T>` xujayrasi taxallusiga ishora qilsa ham) yaxshi (yuqoridagi o'zgarmaslikni boshqa yo'l bilan bajarish sharti bilan), bir nechta `&mut UnsafeCell<T>` taxallusiga ega bo'lish hali ham aniqlanmagan xatti-harakatdir.
/// Ya'ni, `UnsafeCell`-bu X0 `&UnsafeCell<_>` ma'lumotnomasi orqali _shared_ accesses (_i.e._ bilan o'zaro ta'sir o'tkazish uchun mo'ljallangan o'ram);_exclusive_ accesses (_e.g._ bilan ishlashda hech qanday sehr mavjud emas, `&mut UnsafeCell<_>` orqali): na hujayra, na o'ralgan qiymat ushbu `&mut` qarz olish muddati davomida boshqa nomga berilishi mumkin.
///
/// Buni [`.get_mut()`] aksessuari namoyish etadi, ya'ni `&mut T` beradigan _safe_ getter.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// `UnsafeCell<_>` tarkibini qanday qilib mutatsiyalashni ko'rsatadigan misol, bu erda katakchani taxallus qiladigan bir nechta havolalar mavjud:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Xuddi shu `x`-ga bir nechta/bir vaqtda/birgalikda ma'lumotnomalarni oling.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // XAVFSIZLIK: ushbu doirada "x" ning tarkibiga boshqa havolalar mavjud emas,
///     // shuning uchun biznikilar noyobdir.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- qarz olish-+
///     *p1_exclusive += 27; // |
/// } // <---------- ushbu nuqtadan tashqariga chiqa olmaydi -------------------+
///
/// unsafe {
///     // XAVFSIZLIK: ushbu doirada hech kim "x" ning tarkibiga eksklyuziv kirish huquqiga ega bo'lishni kutmaydi,
///     // bir vaqtning o'zida bir nechta umumiy kirish huquqiga ega bo'lishimiz mumkin.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Quyidagi misol `UnsafeCell<T>`-ga eksklyuziv kirish uning `T`-ga eksklyuziv kirishni nazarda tutishini ko'rsatmoqda:
///
/// ```rust
/// #![forbid(unsafe_code)] // eksklyuziv kirish huquqi bilan,
///                         // `UnsafeCell` shaffof operatsion paket emas, shuning uchun bu erda `unsafe` kerak emas.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` uchun kompilyatsiya vaqtida tekshirilgan noyob ma'lumotnomani oling.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Eksklyuziv ma'lumotnoma bilan biz tarkibni bepul mutatsiya qilishimiz mumkin.
/// *p_unique.get_mut() = 0;
/// // Yoki teng ravishda:
/// x = UnsafeCell::new(0);
///
/// // Agar biz qiymatga egalik qilsak, tarkibni bepul olishimiz mumkin.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Belgilangan qiymatni o'rab oladigan yangi `UnsafeCell` nusxasini yaratadi.
    ///
    ///
    /// Ichki qiymatga usullar orqali kirishning barchasi `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Qiymatni ochadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// O'rnatilgan qiymatga o'zgaruvchan ko'rsatkichni oladi.
    ///
    /// Bu har qanday ko'rsatgichga uzatilishi mumkin.
    /// `&mut T`-ga translatsiya qilishda kirishning noyob ekanligiga ishonch hosil qiling (faol havolalar mavjud emas, o'zgarishi mumkin yoki yo'q) va `&T`-ga translatsiya qilinayotganda mutatsiyalar yoki o'zgaruvchan taxalluslar mavjud emasligiga ishonch hosil qiling.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] tufayli biz ko'rsatgichni `UnsafeCell<T>` dan `T` ga tashlashimiz mumkin.
        // Bu libstd-ning maxsus holatidan foydalanadi, foydalanuvchi kodi uchun kompilyatorning future versiyalarida ishlashiga kafolat yo'q!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Asosiy ma'lumotlarga o'zgaruvchan ma'lumotni qaytaradi.
    ///
    /// Ushbu qo'ng'iroq `UnsafeCell`-ni mutanosib ravishda oladi (kompilyatsiya vaqtida), bu bizning yagona ma'lumotnomamizga ega bo'lishiga kafolat beradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// O'rnatilgan qiymatga o'zgaruvchan ko'rsatkichni oladi.
    /// [`get`] dan farqi shundaki, bu funktsiya vaqtinchalik ma'lumotlarning yaratilishining oldini olish uchun foydali bo'lgan xom ko'rsatkichni qabul qiladi.
    ///
    /// Natija har qanday ko'rsatgichga uzatilishi mumkin.
    /// `&mut T`-ga translatsiya qilishda kirishning noyob ekanligiga ishonch hosil qiling (faol havolalar mavjud emas, o'zgarishi mumkin yoki yo'q) va `&T`-ga translatsiya qilinayotganda mutatsiyalar yoki o'zgaruvchan taxalluslar mavjud emasligiga ishonch hosil qiling.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell`-ni bosqichma-bosqich ishga tushirish `raw_get`-ni talab qiladi, chunki `get`-ni chaqirish uchun boshlanmagan ma'lumotlarga mos yozuvlar yaratilishi kerak:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] tufayli biz ko'rsatgichni `UnsafeCell<T>` dan `T` ga tashlashimiz mumkin.
        // Bu libstd-ning maxsus holatidan foydalanadi, foydalanuvchi kodi uchun kompilyatorning future versiyalarida ishlashiga kafolat yo'q!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T uchun `Default` qiymatiga ega bo'lgan `UnsafeCell` hosil qiladi.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}