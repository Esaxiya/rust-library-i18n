//! Belgilar konversiyasi.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32`-ni `char`-ga o'zgartiradi.
///
/// Shuni yodda tutingki, barcha [`char`] lar haqiqiy [`u32`] lardir va ularni biriga qo'shib qo'yish mumkin
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Biroq, buning teskari tomoni to'g'ri emas: barcha yaroqli [`u32`] lar haqiqiy emas [`char`] lar.
/// `from_u32()` agar kirish [`char`] uchun to'g'ri qiymat bo'lmasa, `None` ni qaytaradi.
///
/// Ushbu tekshiruvlarni e'tiborsiz qoldiradigan ushbu funktsiyaning xavfli versiyasi uchun [`from_u32_unchecked`]-ga qarang.
///
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Kirish haqiqiy [`char`] bo'lmaganida `None`-ni qaytarish:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// `u32`-ni `char`-ga o'zgartiradi, haqiqiyligini hisobga olmaydi.
///
/// Shuni yodda tutingki, barcha [`char`] lar haqiqiy [`u32`] lardir va ularni biriga qo'shib qo'yish mumkin
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Biroq, buning teskari tomoni to'g'ri emas: barcha yaroqli [`u32`] lar haqiqiy emas [`char`] lar.
/// `from_u32_unchecked()` buni e'tiborsiz qoldiradi va ko'r-ko'rona [`char`]-ga tashlanadi, ehtimol yaroqsizni yaratadi.
///
///
/// # Safety
///
/// Ushbu funktsiya xavfli emas, chunki u yaroqsiz `char` qiymatlarini yaratishi mumkin.
///
/// Ushbu funktsiyaning xavfsiz versiyasini [`from_u32`] funktsiyasiga qarang.
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `i` qiymatining haqiqiy ekanligiga kafolat berishi kerak.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] ni [`u32`] ga o'zgartiradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] ni [`u64`] ga o'zgartiradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char kod kodining qiymatiga o'tkaziladi, keyin nolga 64 bitgacha kengaytiriladi.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]-ga qarang
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] ni [`u128`] ga o'zgartiradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char kod kodining qiymatiga o'tkaziladi, so'ngra nolga 128 bitgacha kengaytiriladi.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]-ga qarang
        c as u128
    }
}

/// Kod nuqtasi bir xil qiymatga ega bo'lgan `char` ga 0x00 ..=0xFF-da baytni U + 0000 ..=U + 00FF-da xaritada aks ettiradi.
///
/// Unicode shunday yaratilganki, u IANA ISO-8859-1 deb ataydigan belgilar kodi bilan baytlarni samarali ravishda dekodlashi mumkin.
/// Ushbu kodlash ASCII bilan mos keladi.
///
/// E'tibor bering, bu ISO/IEC 8859-1 akadan farq qiladi
/// ISO 8859-1 (bitta kam defis bilan), bu esa biron bir belgiga berilmagan bayt qiymatlarini "blanks" qoldiradi.
/// ISO-8859-1 (IANA) ularni C0 va C1 boshqaruv kodlariga tayinlaydi.
///
/// E'tibor bering, bu Windows-1252 aka-dan *ham* farq qiladi
/// kod sahifasi 1252, bu ISO/IEC 8859-1 supersetidir, ba'zi (hammasi emas!) bo'sh joylarni tinish belgilariga va turli lotin belgilariga beradi.
///
/// Ishlarni yanada chalkashtirib yuborish uchun [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` va `windows-1252` Windows-1252 ning yuqori to'plami uchun boshqa taxallus bo'lib, ular qolgan bo'shliqlarni tegishli C0 va C1 boshqaruv kodlari bilan to'ldiradi.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] ni [`char`] ga o'zgartiradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Charni tahlil qilishda qaytarilishi mumkin bo'lgan xato.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // XAVFSIZLIK: bu qonuniy unikod qiymati ekanligini tekshirdi
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32-dan char-ga o'tish muvaffaqiyatsiz tugaganda, xato turi qaytarildi.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Berilgan radiusdagi raqamni `char` ga o'zgartiradi.
///
/// Bu erda 'radix' ba'zan 'base' deb ham nomlanadi.
/// Ikkala radius ikkitomonlama sonni, o'nning radiusini o'nlik va o'n oltinchi o'n oltinchi o'nlik radiusini bildiradi.
///
/// O'zboshimchalik bilan radikallar qo'llab-quvvatlanadi.
///
/// `from_digit()` agar kirish berilgan radiusdagi raqam bo'lmasa, `None` qaytadi.
///
/// # Panics
///
/// Agar radiusi 36 dan kattaroq bo'lsa, Panics.
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // 11-kasr-bu 16-asosdagi bitta raqam
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Kirish raqam bo'lmaganida `None`-ni qaytarish:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// panic ni keltirib chiqaradigan katta radiusdan o'tish:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}