//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char`-ga tegishli eng yuqori kodli nuqta.
    ///
    /// `char`-bu [Unicode Scalar Value], demak u [Code Point], lekin faqat ma'lum bir doirada bo'lganlar.
    /// `MAX` haqiqiy [Unicode Scalar Value] bo'lgan eng yuqori haqiqiy kod nuqtasi.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () kodni echishda xatolikni ifodalash uchun Unicode-da ishlatiladi.
    ///
    /// Bu, masalan, noto'g'ri shakllangan UTF-8 baytlarini [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) ga berishda paydo bo'lishi mumkin.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Unicode qismlari `char` va `str` usullariga asoslangan [Unicode](http://www.unicode.org/) versiyasi.
    ///
    /// Unicode-ning yangi versiyalari muntazam ravishda chiqariladi va keyinchalik Unicode-ga bog'liq bo'lgan standart kutubxonadagi barcha usullar yangilanadi.
    /// Shuning uchun ba'zi `char` va `str` usullarining xatti-harakatlari va bu doimiy qiymat vaqt o'tishi bilan o'zgarib turadi.
    /// Bu *keskin o'zgarish deb hisoblanmaydi*.
    ///
    /// Versiya raqamlash sxemasi [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) da tushuntirilgan.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter`-da UTF-16 kodlangan kod nuqtalari ustida iterator yaratadi va juftlanmagan surrogatlarni "Err" sifatida qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` natijalarini almashtirish belgisi bilan almashtirish orqali yo'qotadigan dekoderni olish mumkin:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32`-ni `char`-ga o'zgartiradi.
    ///
    /// Shuni esda tutingki, barcha `char`lar ['u32`] larda yaroqli va biriga o'tkazilishi mumkin
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Biroq, buning teskari tomoni to'g'ri emas: barcha yaroqli [`u32`] lar to'g'ri char'lar emas.
    /// `from_u32()` agar kirish `char` uchun to'g'ri qiymat bo'lmasa, `None` ni qaytaradi.
    ///
    /// Ushbu tekshiruvlarni e'tiborsiz qoldiradigan ushbu funktsiyaning xavfli versiyasi uchun [`from_u32_unchecked`]-ga qarang.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Kirish haqiqiy `char` bo'lmaganida `None`-ni qaytarish:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// `u32`-ni `char`-ga o'zgartiradi, haqiqiyligini hisobga olmaydi.
    ///
    /// Shuni esda tutingki, barcha `char`lar ['u32`] larda yaroqli va biriga o'tkazilishi mumkin
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Biroq, buning teskari tomoni to'g'ri emas: barcha yaroqli [`u32`] lar to'g'ri char'lar emas.
    /// `from_u32_unchecked()` buni e'tiborsiz qoldiradi va ko'r-ko'rona `char`-ga tashlanadi, ehtimol yaroqsizni yaratadi.
    ///
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya xavfli emas, chunki u yaroqsiz `char` qiymatlarini yaratishi mumkin.
    ///
    /// Ushbu funktsiyaning xavfsiz versiyasini [`from_u32`] funktsiyasiga qarang.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // XAVFSIZLIK: xavfsizlik shartnomasi qo'ng'iroq qiluvchi tomonidan bajarilishi kerak.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Berilgan radiusdagi raqamni `char` ga o'zgartiradi.
    ///
    /// Bu erda 'radix' ba'zan 'base' deb ham nomlanadi.
    /// Ikkala radius ikkitomonlama sonni, o'nning radiusini o'nlik va o'n oltinchi o'n oltinchi o'nlik radiusini bildiradi.
    ///
    /// O'zboshimchalik bilan radikallar qo'llab-quvvatlanadi.
    ///
    /// `from_digit()` agar kirish berilgan radiusdagi raqam bo'lmasa, `None` qaytadi.
    ///
    /// # Panics
    ///
    /// Agar radiusi 36 dan kattaroq bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // 11-kasr-bu 16-asosdagi bitta raqam
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Kirish raqam bo'lmaganida `None`-ni qaytarish:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// panic ni keltirib chiqaradigan katta radiusdan o'tish:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// `char` berilgan radiusdagi raqam ekanligini tekshiradi.
    ///
    /// Bu erda 'radix' ba'zan 'base' deb ham nomlanadi.
    /// Ikkala radius ikkitomonlama sonni, o'nning radiusini o'nlik va o'n oltinchi o'n oltinchi o'nlik radiusini bildiradi.
    ///
    /// O'zboshimchalik bilan radikallar qo'llab-quvvatlanadi.
    ///
    /// [`is_numeric()`] bilan taqqoslaganda, bu funktsiya faqat `0-9`, `a-z` va `A-Z` belgilarini taniydi.
    ///
    /// 'Digit' faqat quyidagi belgilar sifatida belgilangan:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' haqida batafsilroq ma'lumot olish uchun [`is_numeric()`]-ga qarang.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Agar radiusi 36 dan kattaroq bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// panic ni keltirib chiqaradigan katta radiusdan o'tish:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char`-ni berilgan radiusdagi raqamga o'zgartiradi.
    ///
    /// Bu erda 'radix' ba'zan 'base' deb ham nomlanadi.
    /// Ikkala radius ikkitomonlama sonni, o'nning radiusini o'nlik va o'n oltinchi o'n oltinchi o'nlik radiusini bildiradi.
    ///
    /// O'zboshimchalik bilan radikallar qo'llab-quvvatlanadi.
    ///
    /// 'Digit' faqat quyidagi belgilar sifatida belgilangan:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Agar `char` berilgan radiusdagi raqamga murojaat qilmasa, `None` qaytaradi.
    ///
    /// # Panics
    ///
    /// Agar radiusi 36 dan kattaroq bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Raqamli bo'lmagan raqamni topshirish muvaffaqiyatsizlikka olib keladi:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// panic ni keltirib chiqaradigan katta radiusdan o'tish:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kod bu erda `radix` doimiy va 10 yoki undan kichik bo'lgan holatlarda ijro tezligini yaxshilash uchun bo'linadi
        //
        let val = if likely(radix <= 10) {
            // Agar raqam bo'lmasa, radixdan katta raqam hosil bo'ladi.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Belgining o'n oltilik Unicode qochishini "char`s" sifatida beradigan iteratorni qaytaradi.
    ///
    /// Bu `\u{NNNNNN}` shaklidagi Rust sintaksisidagi belgilardan qochadi, bu erda `NNNNNN`-o'n oltinchi raqamli vakillik.
    ///
    ///
    /// # Examples
    ///
    /// Takrorlovchi sifatida:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// To'g'ridan-to'g'ri `println!`-dan foydalanish:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Ikkalasi ham quyidagilarga teng:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` dan foydalanish:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 c==0 uchun kod bitta raqamni bosib chiqarilishini va (u bir xil)(31, 32) quyilishdan saqlanishini ta'minlaydi.
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // eng muhim olti raqamli ko'rsatkich
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Ixtiyoriy ravishda kengaytirilgan Grapheme kod nuqtalaridan qochishga imkon beruvchi kengaytirilgan `escape_debug` versiyasi.
    /// Bu bizga satr boshida bo'lgan vaqt oralig'ida bo'lmagan belgilar kabi belgilarni yaxshiroq formatlash imkonini beradi.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Belgining to'g'ridan-to'g'ri qochish kodini `char`s sifatida beradigan iteratorni qaytaradi.
    ///
    /// Bu `str` yoki `char` dasturlarining `Debug` o'xshash belgilaridan qochadi.
    ///
    ///
    /// # Examples
    ///
    /// Takrorlovchi sifatida:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// To'g'ridan-to'g'ri `println!`-dan foydalanish:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Ikkalasi ham quyidagilarga teng:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` dan foydalanish:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Belgining to'g'ridan-to'g'ri qochish kodini `char`s sifatida beradigan iteratorni qaytaradi.
    ///
    /// Odatiy bo'lib, turli xil tillarda, shu jumladan C++ 11 va shunga o'xshash C oilaviy tillarida qonuniy bo'lgan adabiyotlarni ishlab chiqarish tarafdorligi tanlanadi.
    /// To'liq qoidalar:
    ///
    /// * Tab `\t` sifatida qochib ketdi.
    /// * Vagonni qaytarish `\r` sifatida qochib ketadi.
    /// * `\n` sifatida chiziqli ozuqa qochib ketdi.
    /// * Bitta kotirovka `\'` sifatida qochib ketgan.
    /// * Ikki tirnoq `\"` sifatida qochib ketgan.
    /// * Orqaga burilish `\\` sifatida qochib qutuldi.
    /// * "Bosib chiqariladigan ASCII" `0x20` .. `0x7e` inklyuzividagi har qanday belgidan qochib bo'lmaydi.
    /// * Boshqa barcha belgilar unicode-ning o'n oltinchi raqamiga berilgan;[`escape_unicode`] ga qarang.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Takrorlovchi sifatida:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// To'g'ridan-to'g'ri `println!`-dan foydalanish:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Ikkalasi ham quyidagilarga teng:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` dan foydalanish:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 da kodlangan bo'lsa, ushbu `char` kerak bo'ladigan baytlar sonini qaytaradi.
    ///
    /// Ushbu baytlar soni har doim 1 dan 4 gacha, shu jumladan.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` turi uning mazmuni UTF-8 ekanligini kafolatlaydi va shuning uchun har bir kod nuqtasi `char` va boshqalar `&str` sifatida ifodalangan bo'lsa, biz uni davomiyligini taqqoslashimiz mumkin:
    ///
    ///
    /// ```
    /// // chars sifatida
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ikkalasi ham uchta bayt sifatida ifodalanishi mumkin
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str sifatida, bu ikkitasi UTF-8-da kodlangan
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // jami olti baytni olishlarini ko'rishimiz mumkin ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... xuddi &str kabi
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 da kodlangan bo'lsa, `char` uchun kerak bo'ladigan 16 bitli kod birliklarining sonini qaytaradi.
    ///
    ///
    /// Ushbu kontseptsiyani ko'proq tushuntirish uchun [`len_utf8()`] uchun hujjatlarni ko'rib chiqing.
    /// Ushbu funktsiya oyna, ammo UTF-8 o'rniga UTF-16 uchun.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Ushbu belgini berilgan bayt buferiga UTF-8 sifatida kodlaydi va keyin kodlangan belgini o'z ichiga olgan bufer sublitsiyasini qaytaradi.
    ///
    ///
    /// # Panics
    ///
    /// Agar bufer etarlicha katta bo'lmasa, Panics.
    /// To'rt uzunlikdagi bufer har qanday `char` ni kodlash uchun etarlicha katta.
    ///
    /// # Examples
    ///
    /// Ushbu ikkala misolda 'ß' kodlash uchun ikki baytni oladi.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Bufer juda kichik:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // XAVFSIZLIK: `char` surrogat emas, shuning uchun bu UTF-8 uchun amal qiladi.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Ushbu belgini UTF-16 sifatida taqdim etilgan `u16` buferiga kodlaydi va keyin kodlangan belgini o'z ichiga olgan bufer sublitsiyasini qaytaradi.
    ///
    ///
    /// # Panics
    ///
    /// Agar bufer etarlicha katta bo'lmasa, Panics.
    /// 2-uzunlikdagi bufer har qanday `char`-ni kodlash uchun etarlicha katta.
    ///
    /// # Examples
    ///
    /// Ushbu ikkala misolda '𝕊' kodlash uchun ikkita u16 qiymatini oladi.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Bufer juda kichik:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Agar bu `char` `Alphabetic` xususiyatiga ega bo'lsa, `true`-ni qaytaradi.
    ///
    /// `Alphabetic` [Unicode Standard] ning 4-bobida (Belgilar xususiyatlari) tavsiflangan va [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-da ko'rsatilgan.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // sevgi ko'p narsadir, lekin u alifbo emas
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Agar bu `char` `Lowercase` xususiyatiga ega bo'lsa, `true`-ni qaytaradi.
    ///
    /// `Lowercase` [Unicode Standard] ning 4-bobida (Belgilar xususiyatlari) tavsiflangan va [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-da ko'rsatilgan.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Turli xitoy yozuvlari va tinish belgilarida bunday holatlar mavjud emas va shuning uchun:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Agar bu `char` `Uppercase` xususiyatiga ega bo'lsa, `true`-ni qaytaradi.
    ///
    /// `Uppercase` [Unicode Standard] ning 4-bobida (Belgilar xususiyatlari) tavsiflangan va [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-da ko'rsatilgan.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Turli xitoy yozuvlari va tinish belgilarida bunday holatlar mavjud emas va shuning uchun:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Agar bu `char` `White_Space` xususiyatiga ega bo'lsa, `true`-ni qaytaradi.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`]-da ko'rsatilgan.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // buzilmaydigan bo'shliq
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// `true` qaytaradi, agar bu `char` [`is_alphabetic()`] yoki [`is_numeric()`] ni qondirsa.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Agar ushbu `char` boshqaruv kodlari uchun umumiy toifaga ega bo'lsa, `true`-ni qaytaradi.
    ///
    /// Boshqarish kodlari (`Cc` umumiy toifali kod punktlari) [Unicode Standard] ning 4-bobida (Belgilar xususiyatlari) tavsiflangan va [Unicode Character Database][ucd] [`UnicodeData.txt`] da ko'rsatilgan.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATORI
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Agar bu `char` `Grapheme_Extend` xususiyatiga ega bo'lsa, `true`-ni qaytaradi.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] da tavsiflangan va [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] da ko'rsatilgan.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Agar bu `char` raqamlar uchun umumiy toifalardan biriga ega bo'lsa, `true`-ni qaytaradi.
    ///
    /// Raqamlar uchun umumiy toifalar (o'nlik raqamlar uchun `Nd`, harfga o'xshash raqamli belgilar uchun `Nl` va boshqa raqamli belgilar uchun `No`) [Unicode Character Database][ucd] [`UnicodeData.txt`] da ko'rsatilgan.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Ushbu `char`-ning kichik harfli xaritasini bitta yoki bir nechta qilib beradigan iteratorni qaytaradi
    /// `char`s.
    ///
    /// Agar ushbu `char` kichkina xaritaga ega bo'lmasa, iterator bir xil `char` hosil qiladi.
    ///
    /// Agar bu `char`-da [Unicode Character Database][ucd] [`UnicodeData.txt`] tomonidan berilgan birma-bir kichik harflar xaritasi bo'lsa, iterator `char` ni beradi.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Agar bu `char` maxsus mulohazalarni talab qilsa (masalan, bir nechta `` char ''), iterator [`SpecialCasing.txt`] tomonidan berilgan 'char' (lar) ni beradi.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ushbu operatsiya shartsiz xaritalashni bichimsiz amalga oshiradi.Ya'ni konversiya kontekst va tilga bog'liq emas.
    ///
    /// [Unicode Standard]-da, 4-bob (Belgilar xususiyatlari) ishlarni xaritalashni umuman muhokama qiladi va 3-bobda (Conformance) ishlarni konvertatsiya qilish uchun standart algoritmni muhokama qiladi.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Takrorlovchi sifatida:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// To'g'ridan-to'g'ri `println!`-dan foydalanish:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Ikkalasi ham quyidagilarga teng:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` dan foydalanish:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Ba'zan natija bitta belgidan ko'proq bo'ladi:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Ikkala katta va kichik harflarga ega bo'lmagan belgilar o'zlariga aylanadi.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Ushbu `char`-ning bosh xaritasini bitta yoki bir nechta qilib keltiradigan iteratorni qaytaradi
    /// `char`s.
    ///
    /// Agar bu `char` katta xaritaga ega bo'lmasa, iterator bir xil `char` hosil qiladi.
    ///
    /// Agar bu `char`-da [Unicode Character Database][ucd] [`UnicodeData.txt`] tomonidan berilgan birma-bir katta xaritalar bo'lsa, iterator `char` ni beradi.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Agar bu `char` maxsus mulohazalarni talab qilsa (masalan, bir nechta `` char ''), iterator [`SpecialCasing.txt`] tomonidan berilgan 'char' (lar) ni beradi.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ushbu operatsiya shartsiz xaritalashni bichimsiz amalga oshiradi.Ya'ni konversiya kontekst va tilga bog'liq emas.
    ///
    /// [Unicode Standard]-da, 4-bob (Belgilar xususiyatlari) ishlarni xaritalashni umuman muhokama qiladi va 3-bobda (Conformance) ishlarni konvertatsiya qilish uchun standart algoritmni muhokama qiladi.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Takrorlovchi sifatida:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// To'g'ridan-to'g'ri `println!`-dan foydalanish:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Ikkalasi ham quyidagilarga teng:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` dan foydalanish:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Ba'zan natija bitta belgidan ko'proq bo'ladi:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Ikkala katta va kichik harflarga ega bo'lmagan belgilar o'zlariga aylanadi.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Mahalliy til haqida eslatma
    ///
    /// Turk tilida lotin tilidagi 'i' ekvivalenti ikkita o'rniga besh shaklga ega:
    ///
    /// * 'Dotless': I/ı, ba'zida ï yoziladi
    /// * 'Dotted': I/i
    ///
    /// Kichik harfli 'i' lotin bilan bir xil ekanligini unutmang.Shuning uchun:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Bu erda `upper_i` qiymati matn tiliga asoslanadi: agar biz `en-US` da bo'lsak, u `"I"`, lekin biz `tr_TR` da bo'lsak, u `"İ"` bo'lishi kerak.
    /// `to_uppercase()` buni hisobga olmaydi va shuning uchun:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// tillarda mavjud.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Qiymat ASCII oralig'ida ekanligini tekshiradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Qiymatning nusxasini ASCII katta bosh harfiga tenglashtiradi.
    ///
    /// 'a' dan 'z' gacha bo'lgan ASCII harflari 'A' dan 'Z' gacha xaritalanadi, ammo ASCII bo'lmagan harflar o'zgarmaydi.
    ///
    /// Joydagi qiymatni kattalashtirish uchun [`make_ascii_uppercase()`] dan foydalaning.
    ///
    /// ASCII bo'lmagan belgilarga qo'shimcha ravishda ASCII belgilarini kattalashtirish uchun [`to_uppercase()`] dan foydalaning.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// ASCII kichik harf ekvivalenti bilan qiymatning nusxasini yaratadi.
    ///
    /// 'A' dan 'Z' gacha bo'lgan ASCII harflari 'a' dan 'z' gacha xaritalanadi, ammo ASCII bo'lmagan harflar o'zgarmaydi.
    ///
    /// Joydagi qiymatni kamaytirish uchun [`make_ascii_lowercase()`] dan foydalaning.
    ///
    /// ASCII bo'lmagan belgilarga qo'shimcha ravishda ASCII belgilarini kichraytirish uchun [`to_lowercase()`] dan foydalaning.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Ikki qiymat ASCII-ga mos kelmaydigan mos kelishini tekshiradi.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ga teng.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Ushbu turni o'z o'rniga ASCII katta bosh harfiga aylantiradi.
    ///
    /// 'a' dan 'z' gacha bo'lgan ASCII harflari 'A' dan 'Z' gacha xaritalanadi, ammo ASCII bo'lmagan harflar o'zgarmaydi.
    ///
    /// Mavjud qiymatni o'zgartirmasdan yangi bosh harfni qaytarish uchun [`to_ascii_uppercase()`] dan foydalaning.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Ushbu turni o'z o'rnida kichik ASCII kichik harfiga o'zgartiradi.
    ///
    /// 'A' dan 'Z' gacha bo'lgan ASCII harflari 'a' dan 'z' gacha xaritalanadi, ammo ASCII bo'lmagan harflar o'zgarmaydi.
    ///
    /// Mavjud qiymatni o'zgartirmasdan yangi kichik harfli qiymatni qaytarish uchun [`to_ascii_lowercase()`] dan foydalaning.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Qiymat ASCII alifbo belgisi ekanligini tekshiradi:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', yoki
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Qiymat ASCII katta harfli belgi ekanligini tekshiradi:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Qiymat ASCII kichik harfli belgi ekanligini tekshiradi:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Qiymat ASCII alfasayısal belgisi ekanligini tekshiradi:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', yoki
    /// - U + 0061 'a' ..=U + 007A 'z', yoki
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Qiymat ASCII o'nlik raqamli ekanligini tekshiradi:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Qiymat ASCII o'n oltinchi raqam ekanligini tekshiradi:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', yoki
    /// - U + 0041 'A' ..=U + 0046 'F', yoki
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Qiymat ASCII tinish belgisidir yoki yo'qligini tekshiradi:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, yoki
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, yoki
    /// - U + 005B ..=U + 0060 `"[\] ^ _``, yoki
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Qiymat ASCII grafik belgisi ekanligini tekshiradi:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Qiymat ASCII bo'shliq belgisi ekanligini tekshiradi:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED yoki U + 000D CARRIET RETURN.
    ///
    /// Rust WhatWG Infra Standard-ning [definition of ASCII whitespace][infra-aw]-dan foydalanadi.Keng qo'llanishda bir nechta boshqa ta'riflar mavjud.
    /// Masalan, [the POSIX locale][pct] U + 000B VERTICAL TAB-ni va yuqoridagi barcha belgilarni o'z ichiga oladi, lekin-xuddi shu spetsifikatsiyadan-[Bourne shell-dagi "field splitting" uchun standart qoidalar][bfs]*only* SPACE, HORIZONTAL TAB va Bo'shliq sifatida LINE FEED.
    ///
    ///
    /// Agar siz mavjud fayl formatini qayta ishlaydigan dastur yozayotgan bo'lsangiz, ushbu funktsiyani ishlatishdan oldin ushbu bo'shliqning ushbu bo'shliq ta'rifi nima ekanligini tekshiring.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Qiymat ASCII boshqaruv belgisi ekanligini tekshiradi:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, yoki U + 007F DELETE.
    /// E'tibor bering, ASCII bo'shliq belgilarining aksariyati boshqaruv belgilaridir, ammo SPACE yo'q.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// u32 qiymatini UTF-8 sifatida berilgan bayt buferiga kodlaydi va keyin kodlangan belgini o'z ichiga olgan bufer sublitsiyasini qaytaradi.
///
///
/// `char::encode_utf8`-dan farqli o'laroq, ushbu usul surrogat oralig'idagi kod nuqtalarini ham boshqaradi.
/// (Surrogat oralig'ida `char` yaratish UB.) Natijada [generalized UTF-8] haqiqiy, ammo UTF-8 haqiqiy emas.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Agar bufer etarlicha katta bo'lmasa, Panics.
/// To'rt uzunlikdagi bufer har qanday `char` ni kodlash uchun etarlicha katta.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// u32 qiymatini UTF-16 sifatida taqdim etilgan `u16` buferiga kodlaydi va keyin kodlangan belgini o'z ichiga olgan bufer sublitsiyasini qaytaradi.
///
///
/// `char::encode_utf16`-dan farqli o'laroq, ushbu usul surrogat oralig'idagi kod nuqtalarini ham boshqaradi.
/// (Surrogat oralig'ida `char` yaratish UB.)
///
/// # Panics
///
/// Agar bufer etarlicha katta bo'lmasa, Panics.
/// 2-uzunlikdagi bufer har qanday `char`-ni kodlash uchun etarlicha katta.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // XAVFSIZLIK: har bir qo'l yozish uchun bitlar mavjudligini tekshiradi
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP tushadi
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Qo'shimcha samolyotlar surrogatlarga ajraladi.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}