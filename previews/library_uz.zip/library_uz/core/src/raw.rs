#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! O'rnatilgan kompilyator turlarini joylashtirish uchun strukturaviy ta'riflarni o'z ichiga oladi.
//!
//! Ular to'g'ridan-to'g'ri xom vakolatxonalarni manipulyatsiya qilish uchun xavfli kodda transmutes maqsadlari sifatida ishlatilishi mumkin.
//!
//!
//! Ularning ta'rifi har doim `rustc_middle::ty::layout` da belgilangan ABIga mos kelishi kerak.
//!

/// `&dyn SomeTrait` kabi trait ob'ektining namoyishi.
///
/// Ushbu struktura `&dyn SomeTrait` va `Box<dyn AnotherTrait>` kabi bir xil tartibga ega.
///
/// `TraitObject` maketlarga mos kelishi kafolatlangan, ammo bu trait moslamalarining turi emas (masalan, maydonlarga `&dyn SomeTrait`-da to'g'ridan-to'g'ri kirish mumkin emas) va u bu tartibni boshqarmaydi (ta'rifni o'zgartirish `&dyn SomeTrait`-ning tartibini o'zgartirmaydi).
///
/// U faqat past darajadagi tafsilotlarni boshqarishi kerak bo'lgan xavfli kod tomonidan ishlatilishi uchun mo'ljallangan.
///
/// Barcha trait ob'ektlariga umumiy murojaat qilishning imkoni yo'q, shuning uchun bu turdagi qiymatlarni yaratishning yagona usuli [`std::mem::transmute`][transmute] kabi funktsiyalardir.
/// Xuddi shunday, `TraitObject` qiymatidan haqiqiy trait ob'ektini yaratishning yagona usuli `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Mos kelmaydigan turlar bilan trait ob'ektini sintez qilish-bu vtable ma'lumotlar ko'rsatgichi ko'rsatadigan qiymat turiga mos kelmaydigan narsa-aniqlanmagan xatti-harakatga olib kelishi mumkin.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // misol trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // kompilyator trait ob'ekti qilsin
/// let object: &dyn Foo = &value;
///
/// // xom vakolatxonaga qarang
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ma'lumotlar ko'rsatgichi `value` manzili
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `i32` vtable-ni `object` dan ehtiyotkorlik bilan foydalanib, boshqa `i32`-ni ko'rsatib, yangi ob'ektni qurish
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // xuddi biz `other_value`-dan to'g'ridan-to'g'ri trait moslamasini qurganimiz kabi ishlashi kerak
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}