//! "Bilvosita ko'chirilishi" mumkin bo'lmagan turlar uchun `Clone` trait.
//!
//! Rust-da ba'zi oddiy turlari "implicitly copyable" bo'lib, ularni tayinlaganingizda yoki ularni dalil sifatida berganingizda qabul qiluvchiga asl qiymati joyida qoldirilib, nusxasi beriladi.
//! Ushbu turlarga nusxa ko'chirish uchun ajratish talab qilinmaydi va finalizatorlar mavjud emas (ya'ni ularda tegishli qutilar mavjud emas yoki [`Drop`] moslamasi mavjud emas), shuning uchun kompilyator ularni ko'chirishda arzon va xavfsiz deb biladi.
//!
//! Boshqa turlar uchun nusxalar [`Clone`] trait-ni tatbiq etish va [`clone`] usulini chaqirish orqali aniq nusxada olinishi kerak.
//!
//! [`clone`]: Clone::clone
//!
//! Asosiy foydalanish misoli:
//!
//! ```
//! let s = String::new(); // String turi Clone-ni amalga oshiradi
//! let copy = s.clone(); // shuning uchun biz uni klonlashimiz mumkin
//! ```
//!
//! Clone trait-ni osongina amalga oshirish uchun siz `#[derive(Clone)]`-dan foydalanishingiz mumkin.Misol:
//!
//! ```
//! #[derive(Clone)] // Morpheus structga Clone trait qo'shamiz
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // va endi biz uni klonlashimiz mumkin!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Ob'ektni aniq nusxalash qobiliyati uchun keng tarqalgan trait.
///
/// [`Copy`]-dan farq qiladi, chunki [`Copy`] noaniq va juda arzon, `Clone` har doim aniq va qimmat bo'lishi mumkin yoki bo'lmasligi mumkin.
/// Ushbu xususiyatlarni amalga oshirish uchun Rust [`Copy`]-ni qayta ishlashga imkon bermaydi, lekin siz `Clone`-ni qayta o'rnatishingiz va o'zboshimchalik bilan kod ishlatishingiz mumkin.
///
/// `Clone` [`Copy`] ga qaraganda umumiyroq bo'lganligi sababli, siz [`Copy`]-ni `Clone`-ga avtomatik ravishda kiritishingiz mumkin.
///
/// ## Derivable
///
/// Agar barcha maydonlar `Clone` bo'lsa, bu trait-dan `#[derive]` bilan foydalanish mumkin.[`Clone`]-ning "derive`d" dasturi har bir sohada [`clone`]-ni chaqiradi.
///
/// [`clone`]: Clone::clone
///
/// Umumiy struktura uchun `#[derive]` umumiy parametrlarga bog'langan `Clone` qo'shish orqali shartli ravishda `Clone` ni amalga oshiradi.
///
/// ```
/// // `derive` O'qish uchun klonni amalga oshiradi<T>T klon bo'lsa.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## `Clone` ni qanday amalga oshirishim mumkin?
///
/// [`Copy`] bo'lgan turdagi `Clone` ahamiyatsiz bajarilishi kerak.Rasmiy ravishda:
/// agar `T: Copy`, `x: T` va `y: &T` bo'lsa, u holda `let x = y.clone();` `let x = *y;` ga teng.
/// Qo'lda qo'llaniladigan dasturlar ushbu o'zgarmaslikni saqlashga ehtiyot bo'lishlari kerak;ammo, xavfli kod, xotira xavfsizligini ta'minlash uchun unga ishonmasligi kerak.
///
/// Masalan, funktsiya ko'rsatgichini ushlab turuvchi umumiy struktura.Bunday holda, `Clone` dasturini "olish" mumkin emas, lekin quyidagicha amalga oshirish mumkin:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Qo'shimcha dasturchilar
///
/// [implementors listed below][impls]-ga qo'shimcha ravishda quyidagi turlari ham `Clone`-ni amalga oshiradi:
///
/// * Funktsiya elementlari turlari (ya'ni har bir funktsiya uchun aniqlangan turlar)
/// * Funktsiya ko'rsatkichlari turlari (masalan, `fn() -> i32`)
/// * Array turlari, har qanday o'lcham uchun, agar element turi ham `Clone` ni qo'llasa (masalan, `[i32; 123456]`)
/// * Tuple turlari, agar har bir komponent `Clone` ni amalga oshirsa (masalan, `()`, `(i32, bool)`)
/// * Yopish turlari, agar ular atrof-muhitdan hech qanday ahamiyatga ega bo'lmasa yoki olingan barcha qiymatlar `Clone`-ni o'zlashtirsa.
///   Shuni esda tutingki, umumiy ma'lumot bilan olingan o'zgaruvchilar har doim `Clone`-ni qo'llaydi (hatto referent bo'lmasa ham), o'zgaruvchan mos yozuvlar bilan olingan o'zgaruvchilar hech qachon `Clone`-ni qo'llamaydi.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Qiymatning nusxasini qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str Klonni amalga oshiradi
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source`-dan nusxa ko'chirishni amalga oshiradi.
    ///
    /// `a.clone_from(&b)` funktsional jihatdan `a = b.clone()` ga teng, ammo keraksiz ajratmalarga yo'l qo'ymaslik uchun `a` manbalarini qayta ishlatish uchun bekor qilinishi mumkin.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` implini yaratadigan so'lni oling.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): Ushbu tuzilmalar faqat#[derive] tomonidan har bir komponentning Clone yoki Copy nusxalarini bajarishini tasdiqlash uchun ishlatiladi.
//
//
// Ushbu tuzilmalar hech qachon foydalanuvchi kodida ko'rinmasligi kerak.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Ibtidoiy turlar uchun `Clone` dasturlari.
///
/// Rust-da tasvirlab bo'lmaydigan dasturlar `traits::SelectionContext::copy_clone_conditions()`-da `rustc_trait_selection`-da amalga oshiriladi.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Umumiy ma'lumotnomalarni klonlash mumkin, ammo o'zgarishi mumkin bo'lgan ma'lumotnomalar * mumkin emas!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Umumiy ma'lumotnomalarni klonlash mumkin, ammo o'zgarishi mumkin bo'lgan ma'lumotnomalar * mumkin emas!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}