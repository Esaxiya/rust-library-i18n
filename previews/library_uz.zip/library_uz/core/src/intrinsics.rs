//! Kompilyatorning ichki xususiyatlari.
//!
//! Tegishli ta'riflar `compiler/rustc_codegen_llvm/src/intrinsic.rs` da.
//! Tegishli konstruktsiyalar `compiler/rustc_mir/src/interpret/intrinsics.rs`-da
//!
//! # Doimiy ichki narsalar
//!
//! Note: ichki xususiyatlarning o'zgarishiga oid har qanday o'zgarishlar til jamoasi bilan muhokama qilinishi kerak.
//! Bunga qattiqlik barqarorligining o'zgarishi kiradi.
//!
//! Kompilyatsiya vaqtida ichki foydalanishga yaroqli bo'lish uchun dasturni <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> dan `compiler/rustc_mir/src/interpret/intrinsics.rs` gacha nusxalash va ichki narsaga `#[rustc_const_unstable(feature = "foo", issue = "01234")]` qo'shish kerak.
//!
//!
//! Agar ichki `const fn` atributi bilan `const fn` dan foydalanilishi kerak bo'lsa, ichki atribut `rustc_const_stable` bo'lishi kerak.
//! Bunday o'zgarish T-lang maslahatisiz amalga oshirilmasligi kerak, chunki u kompilyator ko'magisiz foydalanuvchi kodida takrorlab bo'lmaydigan xususiyatni tilga kiritadi.
//!
//! # Volatiles
//!
//! O'zgaruvchan ichki qurilmalar I/O xotirasida ishlashga mo'ljallangan operatsiyalarni ta'minlaydi, ular boshqa uchuvchi ichki narsalar bo'yicha kompilyator tomonidan qayta tartiblanmasligi kafolatlanadi.[[volatile]]-da LLVM hujjatlarini ko'ring.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atom ichki elementlari bir nechta mumkin bo'lgan xotira buyurtmalariga ega bo'lgan mashina so'zlari bo'yicha umumiy atom operatsiyalarini ta'minlaydi.Ular C++ 11 kabi semantikaga bo'ysunadilar.[[atomics]]-da LLVM hujjatlarini ko'ring.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Xotiraga buyurtma berish bo'yicha tezkor yangilanish:
//!
//! * Qulfni sotib olish uchun to'siqni sotib oling.Keyingi o'qish va yozish to'siqdan keyin sodir bo'ladi.
//! * Chiqarish, qulfni chiqarish uchun to'siq.Oldingi o'qish va yozish to'siqdan oldin sodir bo'ladi.
//! * Ketma-ket izchil, ketma-ket izchil operatsiyalar tartibda bajarilishi kafolatlanadi.Bu atom turlari bilan ishlashning standart rejimi va Java ning `volatile`-ga teng.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Ushbu import hujjat ichidagi aloqalarni soddalashtirish uchun ishlatiladi
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // XAVFSIZLIK: `ptr::drop_in_place` ga qarang
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, bu ichki narsalar xom ko'rsatkichlarni oladi, chunki ular `&` yoki `&mut` uchun yaroqsiz bo'lgan xotirani o'zgartiradi.
    //

    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange` usuli orqali [`Ordering::SeqCst`] ni `success` va `failure` parametrlari sifatida o'tkazish orqali mavjud.
    ///
    /// Masalan, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange` usuli orqali [`Ordering::Acquire`] ni `success` va `failure` parametrlari sifatida o'tkazish orqali mavjud.
    ///
    /// Masalan, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange` usuli orqali [`Ordering::Release`] ni `success` va [`Ordering::Relaxed`] ni `failure` parametrlari orqali o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange` usuli orqali [`Ordering::AcqRel`] ni `success` va [`Ordering::Acquire`] ni `failure` parametrlari orqali o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange` usuli orqali [`Ordering::Relaxed`] ni `success` va `failure` parametrlari sifatida o'tkazish orqali mavjud.
    ///
    /// Masalan, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange` usuli orqali [`Ordering::SeqCst`] ni `success` va [`Ordering::Relaxed`] ni `failure` parametrlari orqali o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange` usuli orqali [`Ordering::SeqCst`] ni `success` va [`Ordering::Acquire`] ni `failure` parametrlari orqali o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange` usuli orqali [`Ordering::Acquire`] ni `success` va [`Ordering::Relaxed`] ni `failure` parametrlari orqali o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange` usuli orqali [`Ordering::AcqRel`] ni `success` va [`Ordering::Relaxed`] ni `failure` parametrlari orqali o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange_weak` usuli orqali [`Ordering::SeqCst`] ni `success` va `failure` parametrlari sifatida o'tkazish orqali mavjud.
    ///
    /// Masalan, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange_weak` usuli orqali [`Ordering::Acquire`] ni `success` va `failure` parametrlari sifatida o'tkazish orqali mavjud.
    ///
    /// Masalan, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange_weak` usuli orqali [`Ordering::Release`] ni `success` va [`Ordering::Relaxed`] ni `failure` parametrlari orqali o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange_weak` usuli orqali [`Ordering::AcqRel`] ni `success` va [`Ordering::Acquire`] ni `failure` parametrlari orqali o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange_weak` usuli orqali [`Ordering::Relaxed`] ni `success` va `failure` parametrlari sifatida o'tkazish orqali mavjud.
    ///
    /// Masalan, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange_weak` usuli orqali [`Ordering::SeqCst`] ni `success` va [`Ordering::Relaxed`] ni `failure` parametrlari orqali o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange_weak` usuli orqali [`Ordering::SeqCst`] ni `success` va [`Ordering::Acquire`] ni `failure` parametrlari orqali o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange_weak` usuli orqali [`Ordering::Acquire`] ni `success` va [`Ordering::Relaxed`] ni `failure` parametrlari orqali o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Joriy qiymat `old` qiymati bilan bir xil bo'lsa, qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `compare_exchange_weak` usuli orqali [`Ordering::AcqRel`] ni `success` va [`Ordering::Relaxed`] ni `failure` parametrlari orqali o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Ko'rsatkichning joriy qiymatini yuklaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `load` usuli orqali [`Ordering::SeqCst`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Ko'rsatkichning joriy qiymatini yuklaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `load` usuli orqali [`Ordering::Acquire`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Ko'rsatkichning joriy qiymatini yuklaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `load` usuli orqali [`Ordering::Relaxed`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Belgilangan xotira joyidagi qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `store` usuli orqali [`Ordering::SeqCst`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Belgilangan xotira joyidagi qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `store` usuli orqali [`Ordering::Release`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Belgilangan xotira joyidagi qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `store` usuli orqali [`Ordering::Relaxed`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Eski qiymatni qaytarib, belgilangan xotira joyida qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `swap` usuli orqali [`Ordering::SeqCst`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Eski qiymatni qaytarib, belgilangan xotira joyida qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `swap` usuli orqali [`Ordering::Acquire`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Eski qiymatni qaytarib, belgilangan xotira joyida qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `swap` usuli orqali [`Ordering::Release`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Eski qiymatni qaytarib, belgilangan xotira joyida qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `swap` usuli orqali [`Ordering::AcqRel`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Eski qiymatni qaytarib, belgilangan xotira joyida qiymatni saqlaydi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `swap` usuli orqali [`Ordering::Relaxed`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Avvalgi qiymatni qaytarib, joriy qiymatga qo'shiladi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_add` usuli orqali [`Ordering::SeqCst`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Avvalgi qiymatni qaytarib, joriy qiymatga qo'shiladi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_add` usuli orqali [`Ordering::Acquire`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Avvalgi qiymatni qaytarib, joriy qiymatga qo'shiladi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_add` usuli orqali [`Ordering::Release`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Avvalgi qiymatni qaytarib, joriy qiymatga qo'shiladi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_add` usuli orqali [`Ordering::AcqRel`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Avvalgi qiymatni qaytarib, joriy qiymatga qo'shiladi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_add` usuli orqali [`Ordering::Relaxed`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Oldingi qiymatni qaytarib, joriy qiymatdan chiqaring.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_sub` usuli orqali [`Ordering::SeqCst`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, joriy qiymatdan chiqaring.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_sub` usuli orqali [`Ordering::Acquire`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, joriy qiymatdan chiqaring.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_sub` usuli orqali [`Ordering::Release`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, joriy qiymatdan chiqaring.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_sub` usuli orqali [`Ordering::AcqRel`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, joriy qiymatdan chiqaring.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_sub` usuli orqali [`Ordering::Relaxed`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Oldingi qiymatni qaytarib, bitli va joriy qiymat bilan.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_and` usuli orqali [`Ordering::SeqCst`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, bitli va joriy qiymat bilan.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_and` usuli orqali [`Ordering::Acquire`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, bitli va joriy qiymat bilan.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_and` usuli orqali [`Ordering::Release`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, bitli va joriy qiymat bilan.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_and` usuli orqali [`Ordering::AcqRel`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, bitli va joriy qiymat bilan.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_and` usuli orqali [`Ordering::Relaxed`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Oldingi qiymatni qaytarib, joriy qiymat bilan bit nand.
    ///
    /// Ushbu ichki versiyaning stabillashgan versiyasi [`AtomicBool`] turida `fetch_nand` usuli orqali [`Ordering::SeqCst`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, joriy qiymat bilan bit nand.
    ///
    /// Ushbu ichki versiyaning stabillashgan versiyasi [`AtomicBool`] turida `fetch_nand` usuli orqali [`Ordering::Acquire`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, joriy qiymat bilan bit nand.
    ///
    /// Ushbu ichki versiyaning stabillashgan versiyasi [`AtomicBool`] turida `fetch_nand` usuli orqali [`Ordering::Release`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, joriy qiymat bilan bit nand.
    ///
    /// Ushbu ichki versiyaning stabillashgan versiyasi [`AtomicBool`] turida `fetch_nand` usuli orqali [`Ordering::AcqRel`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, joriy qiymat bilan bit nand.
    ///
    /// Ushbu ichki versiyaning stabillashgan versiyasi [`AtomicBool`] turida `fetch_nand` usuli orqali [`Ordering::Relaxed`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Oldingi qiymatni qaytarib, bitli yoki joriy qiymat bilan.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_or` usuli orqali [`Ordering::SeqCst`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, bitli yoki joriy qiymat bilan.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_or` usuli orqali [`Ordering::Acquire`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, bitli yoki joriy qiymat bilan.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_or` usuli orqali [`Ordering::Release`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, bitli yoki joriy qiymat bilan.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_or` usuli orqali [`Ordering::AcqRel`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, bitli yoki joriy qiymat bilan.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_or` usuli orqali [`Ordering::Relaxed`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Oldingi qiymatni qaytarib, joriy qiymat bilan bitwise xor.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_xor` usuli orqali [`Ordering::SeqCst`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, joriy qiymat bilan bitwise xor.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_xor` usuli orqali [`Ordering::Acquire`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, joriy qiymat bilan bitwise xor.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_xor` usuli orqali [`Ordering::Release`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, joriy qiymat bilan bitwise xor.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_xor` usuli orqali [`Ordering::AcqRel`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oldingi qiymatni qaytarib, joriy qiymat bilan bitwise xor.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] turlarida `fetch_xor` usuli orqali [`Ordering::Relaxed`] dan `order` ga o'tish orqali mavjud.
    /// Masalan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Imzolangan taqqoslash yordamida joriy qiymat bilan maksimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] imzolangan tamsayı turlarida `fetch_max` usuli orqali [`Ordering::SeqCst`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzolangan taqqoslash yordamida joriy qiymat bilan maksimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] imzolangan tamsayı turlarida `fetch_max` usuli orqali [`Ordering::Acquire`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzolangan taqqoslash yordamida joriy qiymat bilan maksimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] imzolangan tamsayı turlarida `fetch_max` usuli orqali [`Ordering::Release`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzolangan taqqoslash yordamida joriy qiymat bilan maksimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] imzolangan tamsayı turlarida `fetch_max` usuli orqali [`Ordering::AcqRel`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Joriy qiymat bilan maksimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] imzolangan tamsayı turlarida `fetch_max` usuli orqali [`Ordering::Relaxed`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Imzolangan taqqoslash yordamida joriy qiymat bilan minimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] imzolangan tamsayı turlarida `fetch_min` usuli orqali [`Ordering::SeqCst`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzolangan taqqoslash yordamida joriy qiymat bilan minimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] imzolangan tamsayı turlarida `fetch_min` usuli orqali [`Ordering::Acquire`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzolangan taqqoslash yordamida joriy qiymat bilan minimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] imzolangan tamsayı turlarida `fetch_min` usuli orqali [`Ordering::Release`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzolangan taqqoslash yordamida joriy qiymat bilan minimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] imzolangan tamsayı turlarida `fetch_min` usuli orqali [`Ordering::AcqRel`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzolangan taqqoslash yordamida joriy qiymat bilan minimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] imzolangan tamsayı turlarida `fetch_min` usuli orqali [`Ordering::Relaxed`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Imzo qo'yilmagan taqqoslash yordamida joriy qiymat bilan minimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] belgisiz tamsayı turlarida `fetch_min` usuli orqali [`Ordering::SeqCst`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzo qo'yilmagan taqqoslash yordamida joriy qiymat bilan minimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] belgisiz tamsayı turlarida `fetch_min` usuli orqali [`Ordering::Acquire`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzo qo'yilmagan taqqoslash yordamida joriy qiymat bilan minimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] belgisiz tamsayı turlarida `fetch_min` usuli orqali [`Ordering::Release`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzo qo'yilmagan taqqoslash yordamida joriy qiymat bilan minimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] belgisiz tamsayı turlarida `fetch_min` usuli orqali [`Ordering::AcqRel`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzo qo'yilmagan taqqoslash yordamida joriy qiymat bilan minimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] belgisiz tamsayı turlarida `fetch_min` usuli orqali [`Ordering::Relaxed`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Imzosiz taqqoslash yordamida joriy qiymat bilan maksimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] belgisiz tamsayı turlarida `fetch_max` usuli orqali [`Ordering::SeqCst`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzosiz taqqoslash yordamida joriy qiymat bilan maksimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] belgisiz tamsayı turlarida `fetch_max` usuli orqali [`Ordering::Acquire`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzosiz taqqoslash yordamida joriy qiymat bilan maksimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] belgisiz tamsayı turlarida `fetch_max` usuli orqali [`Ordering::Release`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzosiz taqqoslash yordamida joriy qiymat bilan maksimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] belgisiz tamsayı turlarida `fetch_max` usuli orqali [`Ordering::AcqRel`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imzosiz taqqoslash yordamida joriy qiymat bilan maksimal.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic`] belgisiz tamsayı turlarida `fetch_max` usuli orqali [`Ordering::Relaxed`] ni `order` sifatida o'tkazish orqali mavjud.
    /// Masalan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ichki `prefetch` kod ishlab chiqaruvchisi, agar qo'llab-quvvatlansa, oldindan qabul qilish buyrug'ini kiritish uchun bir maslahatdir;aks holda, bu no-op.
    /// Prefetches dasturning ishiga ta'sir qilmaydi, lekin uning ishlash xususiyatlarini o'zgartirishi mumkin.
    ///
    /// `locality` argumenti doimiy tamsayı bo'lishi kerak va (0) dan tortib, (3) gacha bo'lgan vaqtinchalik mahalliylikni aniqlovchi bo'lib, juda keshda saqlanadi.
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Ichki `prefetch` kod ishlab chiqaruvchisi, agar qo'llab-quvvatlansa, oldindan qabul qilish buyrug'ini kiritish uchun bir maslahatdir;aks holda, bu no-op.
    /// Prefetches dasturning ishiga ta'sir qilmaydi, lekin uning ishlash xususiyatlarini o'zgartirishi mumkin.
    ///
    /// `locality` argumenti doimiy tamsayı bo'lishi kerak va (0) dan tortib, (3) gacha bo'lgan vaqtinchalik mahalliylikni aniqlovchi bo'lib, juda keshda saqlanadi.
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Ichki `prefetch` kod ishlab chiqaruvchisi, agar qo'llab-quvvatlansa, oldindan qabul qilish buyrug'ini kiritish uchun bir maslahatdir;aks holda, bu no-op.
    /// Prefetches dasturning ishiga ta'sir qilmaydi, lekin uning ishlash xususiyatlarini o'zgartirishi mumkin.
    ///
    /// `locality` argumenti doimiy tamsayı bo'lishi kerak va (0) dan tortib, (3) gacha bo'lgan vaqtinchalik mahalliylikni aniqlovchi bo'lib, juda keshda saqlanadi.
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Ichki `prefetch` kod ishlab chiqaruvchisi, agar qo'llab-quvvatlansa, oldindan qabul qilish buyrug'ini kiritish uchun bir maslahatdir;aks holda, bu no-op.
    /// Prefetches dasturning ishiga ta'sir qilmaydi, lekin uning ishlash xususiyatlarini o'zgartirishi mumkin.
    ///
    /// `locality` argumenti doimiy tamsayı bo'lishi kerak va (0) dan tortib, (3) gacha bo'lgan vaqtinchalik mahalliylikni aniqlovchi bo'lib, juda keshda saqlanadi.
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atom panjarasi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic::fence`]-da [`Ordering::SeqCst`]-ni `order` sifatida o'tkazish orqali mavjud.
    ///
    ///
    pub fn atomic_fence();
    /// Atom panjarasi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic::fence`]-da [`Ordering::Acquire`]-ni `order` sifatida o'tkazish orqali mavjud.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atom panjarasi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic::fence`]-da [`Ordering::Release`]-ni `order` sifatida o'tkazish orqali mavjud.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atom panjarasi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic::fence`]-da [`Ordering::AcqRel`]-ni `order` sifatida o'tkazish orqali mavjud.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Faqat kompilyatorga mo'ljallangan xotira to'sig'i.
    ///
    /// Xotiraga kirish hech qachon kompilyator tomonidan ushbu to'siq bo'ylab qayta tartibga solinmaydi, ammo buning uchun hech qanday ko'rsatma berilmaydi.
    /// Bu xuddi shu ipda, masalan, signal ishlov beruvchilar bilan o'zaro aloqada bo'lgan operatsiyalar uchun javob beradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic::compiler_fence`]-da [`Ordering::SeqCst`]-ni `order` sifatida o'tkazish orqali mavjud.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Faqat kompilyatorga mo'ljallangan xotira to'sig'i.
    ///
    /// Xotiraga kirish hech qachon kompilyator tomonidan ushbu to'siq bo'ylab qayta tartibga solinmaydi, ammo buning uchun hech qanday ko'rsatma berilmaydi.
    /// Bu xuddi shu ipda, masalan, signal ishlov beruvchilar bilan o'zaro aloqada bo'lgan operatsiyalar uchun javob beradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic::compiler_fence`]-da [`Ordering::Acquire`]-ni `order` sifatida o'tkazish orqali mavjud.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Faqat kompilyatorga mo'ljallangan xotira to'sig'i.
    ///
    /// Xotiraga kirish hech qachon kompilyator tomonidan ushbu to'siq bo'ylab qayta tartibga solinmaydi, ammo buning uchun hech qanday ko'rsatma berilmaydi.
    /// Bu xuddi shu ipda, masalan, signal ishlov beruvchilar bilan o'zaro aloqada bo'lgan operatsiyalar uchun javob beradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic::compiler_fence`]-da [`Ordering::Release`]-ni `order` sifatida o'tkazish orqali mavjud.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Faqat kompilyatorga mo'ljallangan xotira to'sig'i.
    ///
    /// Xotiraga kirish hech qachon kompilyator tomonidan ushbu to'siq bo'ylab qayta tartibga solinmaydi, ammo buning uchun hech qanday ko'rsatma berilmaydi.
    /// Bu xuddi shu ipda, masalan, signal ishlov beruvchilar bilan o'zaro aloqada bo'lgan operatsiyalar uchun javob beradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`atomic::compiler_fence`]-da [`Ordering::AcqRel`]-ni `order` sifatida o'tkazish orqali mavjud.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// O'zining ma'nosini funktsiyaga biriktirilgan atributlardan kelib chiqadigan sehrli ichki.
    ///
    /// Masalan, dataflow bundan statik tasdiqlarni kiritish uchun foydalanadi, shunda `rustc_peek(potentially_uninitialized)` haqiqatan ham ma'lumotlar oqimining boshqaruv oqimining o'sha nuqtasida initsializatsiya qilinmaganligini hisoblaganligini ikki marta tekshiradi.
    ///
    ///
    /// Ushbu ichki kompilyatordan tashqarida ishlatilmasligi kerak.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Jarayonning bajarilishini bekor qiladi.
    ///
    /// Ushbu operatsiyani yanada qulay va barqaror versiyasi-[`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Optimizatorga kodning ushbu nuqtasiga erishish mumkin emasligi haqida xabar beradi va keyingi optimallashtirishga imkon beradi.
    ///
    /// Eslatib o'tamiz, bu `unreachable!()` makrosidan juda farq qiladi: panics bajarilayotganda foydalaniladigan makrosdan farqli o'laroq, ushbu funktsiya bilan belgilangan kodga erishish * aniqlanmagan xatti-harakatlardir.
    ///
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Optimizatorga shart har doim to'g'ri ekanligi to'g'risida xabar beradi.
    /// Agar shart noto'g'ri bo'lsa, xatti-harakatlar aniqlanmagan.
    ///
    /// Ushbu ichki uchun hech qanday kod yaratilmaydi, lekin optimallashtiruvchi uni (va uning holatini) o'tkazmalar oralig'ida saqlab qolishga harakat qiladi, bu esa atrofdagi kodni optimallashtirishga xalaqit berishi va ishlashni pasaytiradi.
    /// Agar invariantni o'zi optimallashtiruvchi tomonidan topilishi mumkin bo'lsa yoki u sezilarli darajada optimallashtirishga imkon bermasa, uni ishlatmaslik kerak.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// branch sharti to'g'ri bo'lishi mumkinligi haqida kompilyatorga ko'rsatmalar.
    /// Unga o'tkazilgan qiymatni qaytaradi.
    ///
    /// `if` bayonotlaridan tashqari har qanday foydalanish, ehtimol, ta'sir ko'rsatmaydi.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// branch sharti noto'g'ri bo'lishi mumkinligi haqida kompilyatorga ko'rsatmalar.
    /// Unga o'tkazilgan qiymatni qaytaradi.
    ///
    /// `if` bayonotlaridan tashqari har qanday foydalanish, ehtimol, ta'sir ko'rsatmaydi.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Tuzatuvchi tuzoqni tuzatuvchini tekshirish uchun bajaradi.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn breakpoint();

    /// Turning hajmi baytlarda.
    ///
    /// Aniqroq aytganda, bu bir xil turdagi ketma-ket elementlar orasidagi baytlarda, shu jumladan, tekislash to'ldirishida.
    ///
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Turning minimal hizalanması.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Bir turdagi afzal qilingan hizalama.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Ko'rsatilgan qiymatning baytdagi hajmi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Yo'naltirilgan qiymatning kerakli hizalanishi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Turning nomini o'z ichiga olgan statik mag'lubiyatni oladi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Belgilangan turga global miqyosda noyob identifikatorni oladi.
    /// Ushbu funktsiya qaysi crate ishlatilishidan qat'i nazar, tur uchun bir xil qiymatni qaytaradi.
    ///
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// `T` yashamagan bo'lsa, hech qachon bajarib bo'lmaydigan xavfli funktsiyalar uchun qo'riqchi:
    /// Bu statik ravishda panic bo'ladi yoki hech narsa qilmaydi.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// `T` nol-boshlashga ruxsat bermasa, hech qachon bajarib bo'lmaydigan xavfli funktsiyalar uchun qo'riqchi: Bu statik ravishda panic yoki hech narsa qilmaydi.
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn assert_zero_valid<T>();

    /// `T`-da yaroqsiz bit naqshlari bo'lsa, hech qachon bajarib bo'lmaydigan xavfli funktsiyalar uchun qo'riqchi: Bu statik ravishda panic bo'ladi yoki hech narsa qilmaydi.
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn assert_uninit_valid<T>();

    /// Qaerga chaqirilganligini ko'rsatuvchi statik `Location`-ga havola keladi.
    ///
    /// Buning o'rniga [`core::panic::Location::caller`](crate::panic::Location::caller) dan foydalanishni o'ylab ko'ring.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Qopqoqni ishlatmasdan qiymatni doiradan tashqariga chiqaradi.
    ///
    /// Bu faqat [`mem::forget_unsized`] uchun mavjud;oddiy `forget` o'rniga `ManuallyDrop` ishlatadi.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Bir turdagi qiymat bitlarini boshqa tur sifatida qayta sharhlaydi.
    ///
    /// Ikkala tur ham bir xil o'lchamga ega bo'lishi kerak.
    /// Asl nusxa ham, natija ham [invalid value](../../nomicon/what-unsafe-does.html) bo'lishi mumkin emas.
    ///
    /// `transmute` semantik jihatdan bir turdagi bittasini ikkinchisiga ko'chirishga tengdir.U bitlarni manba qiymatidan maqsadga ko'chiradi, so'ngra asl nusxasini unutadi.
    /// Bu xuddi `transmute_copy` singari qopqoq ostidagi C ning `memcpy`-ga teng.
    ///
    /// `transmute` qo'shimcha qiymatli operatsiya bo'lgani uchun,*o'tkazilgan qiymatlarning* o'zaro kelishuvi tashvishlantirmaydi.
    /// Boshqa funktsiyalarda bo'lgani kabi, kompilyator allaqachon `T` va `U`-ning to'g'ri hizalanishini ta'minlaydi.
    /// Biroq,*boshqa joyga ishora qiluvchi* qiymatlarni uzatishda (masalan, ko'rsatgichlar, ma'lumotnomalar, qutilar ...), qo'ng'iroq qiluvchining ishora qilingan qiymatlarini to'g'ri mosligini ta'minlashi kerak.
    ///
    /// `transmute` ** nihoyatda xavfli.Ushbu funktsiya bilan [undefined behavior][ub] ni keltirib chiqaradigan juda ko'p usullar mavjud.`transmute` mutlaq so'nggi chora bo'lishi kerak.
    ///
    /// [nomicon](../../nomicon/transmutes.html) qo'shimcha hujjatlarga ega.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` juda foydali bo'lgan bir nechta narsalar mavjud.
    ///
    /// Ko'rsatkichni funktsiya ko'rsatgichiga aylantirish.Bu funktsiya ko'rsatgichlari va ma'lumotlar ko'rsatkichlari turli o'lchamlarga ega bo'lgan mashinalar uchun *ko'chirilmaydi*.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Bir umrni uzaytirish yoki o'zgarmas umrni qisqartirish.Bu rivojlangan, juda xavfli Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Umidingizni yo'qotmang: `transmute`-dan ko'p foydalanishga boshqa vositalar yordamida erishish mumkin.
    /// Quyida `transmute`-ning keng tarqalgan ilovalari mavjud bo'lib, ularni xavfsiz konstruktsiyalar bilan almashtirish mumkin.
    ///
    /// bytes(`&[u8]`) ni `u32`, `f64` va boshqalarga aylantirish:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // o'rniga `u32::from_ne_bytes` dan foydalaning
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // yoki endiannessni aniqlash uchun `u32::from_le_bytes` yoki `u32::from_be_bytes` dan foydalaning
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Ko'rsatkichni `usize` ga aylantirish:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Buning o'rniga `as` gipsidan foydalaning
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T`-ni `&mut T`-ga aylantirish:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Buning o'rniga reborrowdan foydalaning
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T`-ni `&mut U`-ga aylantirish:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Endi `as`-ni birlashtiring va qayta tug'ilishga e'tibor bering, `as` `as`-ning zanjiri vaqtinchalik emas
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str`-ni `&[u8]`-ga aylantirish:
    ///
    /// ```
    /// // buni amalga oshirishning yaxshi usuli emas.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Siz `str::as_bytes` dan foydalanishingiz mumkin
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Yoki bayt satridan foydalaning, agar siz mag'lubiyatni boshqaradigan bo'lsangiz
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>`-ni `Vec<Option<&T>>`-ga aylantirish.
    ///
    /// Idish tarkibidagi ichki turini o'zgartirish uchun siz konteynerning hech qanday o'zgarmasligini buzmasligingizga ishonch hosil qilishingiz kerak.
    /// `Vec` uchun bu ichki turlarning o'lchamlari *va hizalanması* mos kelishi kerakligini anglatadi.
    /// Boshqa konteynerlar turining o'lchamiga, hizalanishiga yoki hatto `TypeId` ga bog'liq bo'lishi mumkin, bu holda transmisyon konteynerning o'zgaruvchanligini buzmasdan umuman mumkin bo'lmaydi.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector-ni klonlang, chunki ularni keyinroq qayta ishlatamiz
    /// let v_clone = v_orig.clone();
    ///
    /// // Transmute-dan foydalanish: bu `Vec`-ning aniqlanmagan ma'lumotlar sxemasiga asoslanadi, bu noto'g'ri fikr va noaniq xatti-harakatga olib kelishi mumkin.
    /////
    /// // Biroq, bu nusxa ko'chirilmaydi.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Bu tavsiya etilgan, xavfsiz usul.
    /// // Bu butun vector-ni yangi qatorga ko'chiradi.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Bu "transmuting"-ning `Vec`-ning nusxasini ko'chirishning xavfli usuli, ma'lumotlar maketiga tayanmasdan.
    /// // `transmute`-ni so'zma-so'z chaqirishning o'rniga, biz ko'rsatgichni amalga oshiramiz, ammo asl ichki (`&i32`) turini yangisiga (`Option<&i32>`) ga o'tkazish nuqtai nazaridan bu bir xil ogohlantirishlarga ega.
    /////
    /// // Yuqorida keltirilgan ma'lumotlardan tashqari, [`from_raw_parts`] hujjatlariga murojaat qiling.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME vec_into_raw_parts stabillashganida buni yangilang.
    ///     // Asl vector tashlanmaganligiga ishonch hosil qiling.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut`-ni amalga oshirish:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Buning bir necha yo'li mavjud va quyidagi (transmute) usuli bilan bir nechta muammolar mavjud.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // birinchisi: transmute xavfsiz emas;faqat T va ekanligini tekshiradi
    ///         // U bir xil o'lchamda.
    ///         // Ikkinchidan, aynan shu erda sizda bir xil xotiraga ishora qiluvchi ikkita o'zgaruvchan ma'lumot mavjud.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Bu turdagi xavfsizlik muammolaridan xalos bo'ladi;`&mut *` sizga* faqat *`&mut T` yoki `* mut T` dan `&mut T` beradi.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // ammo, sizda bir xil xotiraga ishora qiluvchi ikkita o'zgaruvchan ma'lumot mavjud.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Standart kutubxona buni shunday qiladi.
    /// // Agar siz bunga o'xshash biror narsa qilishingiz kerak bo'lsa, bu eng yaxshi usul
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Endi bir xil xotiraga ishora qiluvchi uchta o'zgaruvchan ma'lumot mavjud.`slice`, ret.0 qiymati va ret.1 qiymati.
    ///         // `slice` hech qachon `let ptr = ...` dan keyin ishlatilmaydi va shuning uchun uni "dead" deb hisoblash mumkin va shuning uchun sizda faqat ikkita haqiqiy o'zgaruvchan tilim mavjud.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Bu ichki konstni barqaror qilsa-da, bizda const fn-da ba'zi bir maxsus kodlar mavjud
    // `const fn` ichida foydalanishga to'sqinlik qiladigan tekshiruvlar.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Agar `T` sifatida berilgan haqiqiy turga tomchi elim kerak bo'lsa, `true` qaytariladi;agar `T` uchun taqdim etilgan haqiqiy turi `Copy` ni amalga oshirsa, `false` ni qaytaradi.
    ///
    ///
    /// Agar haqiqiy turga na tomchi yopishtiruvchi kerak bo'lsa va na `Copy` bajarilsa, u holda bu funktsiyani qaytarish qiymati aniqlanmagan.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Ko'rsatkichdan ofsetni hisoblab chiqadi.
    ///
    /// Bu konvertatsiya qilish kerak bo'lgan ma'lumotni tashlab yuborishi sababli, butun songa va undan konversiyani oldini olish uchun ichki sifatida amalga oshiriladi.
    ///
    /// # Safety
    ///
    /// Ikkala boshlang'ich va natijada ko'rsatgich chegaralarda yoki ajratilgan ob'ekt oxiridan bitta baytda bo'lishi kerak.
    /// Agar biron bir ko'rsatkich chegaradan tashqarida bo'lsa yoki arifmetik toshib ketsa, qaytarilgan qiymatdan keyingi foydalanish aniqlanmagan xatti-harakatga olib keladi.
    ///
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ko'rsatkichdan ofsetni potentsial o'ralgan holda hisoblab chiqadi.
    ///
    /// Bu konvertatsiya muayyan optimallashtirishni inhibe qilganligi sababli, butun songa va undan konversiyani oldini olish uchun ichki sifatida amalga oshiriladi.
    ///
    /// # Safety
    ///
    /// Ichki `offset` dan farqli o'laroq, bu ichki hosil bo'lgan ko'rsatkichni ajratilgan ob'ekt oxiriga yoki bitta baytga o'tishni cheklamaydi va ikkitasini to'ldiruvchi arifmetikasi bilan o'raladi.
    /// Olingan qiymat, albatta, xotiraga kirish uchun ishlatilishi shart emas.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// `count`*`size_of::<T>()` o'lchamiga ega va mos keladigan ichki `llvm.memcpy.p0i8.0i8.*` ga teng.
    ///
    /// `min_align_of::<T>()`
    ///
    /// O'zgaruvchan parametr `true` ga o'rnatildi, shuning uchun uning hajmi nolga teng bo'lmaguncha u optimallashtirilmaydi.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Tegishli ichki `llvm.memmove.p0i8.0i8.*` ga teng, hajmi `count* size_of::<T>()` va hizalanishi bilan
    ///
    /// `min_align_of::<T>()`
    ///
    /// O'zgaruvchan parametr `true` ga o'rnatildi, shuning uchun uning hajmi nolga teng bo'lmaguncha u optimallashtirilmaydi.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Tegishli ichki `llvm.memset.p0i8.*` ga teng, hajmi `count* size_of::<T>()` va tekisligi `min_align_of::<T>()`.
    ///
    ///
    /// O'zgaruvchan parametr `true` ga o'rnatildi, shuning uchun uning hajmi nolga teng bo'lmaguncha u optimallashtirilmaydi.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` ko'rsatkichidan uchuvchan yukni bajaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` ko'rsatkichiga uchuvchan do'konni amalga oshiradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` ko'rsatkichidan uchuvchan yukni bajaradi Ko'rsatkichni tekislash talab qilinmaydi.
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` ko'rsatkichiga uchuvchan do'konni amalga oshiradi.
    /// Ko'rsatkichni tekislash talab qilinmaydi.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` kvadrat ildizini qaytaradi
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` kvadrat ildizini qaytaradi
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` ni butun quvvatga ko'taradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` ni butun quvvatga ko'taradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` sinusini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` sinusini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` kosinusini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` kosinusini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` ni `f32` quvvatiga ko'taradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64` ni `f64` quvvatiga ko'taradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32` eksponentligini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64` eksponentligini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// `f32` quvvatiga ko'tarilgan 2 ni qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// `f64` quvvatiga ko'tarilgan 2 ni qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32` ning tabiiy logarifmini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64` ning tabiiy logarifmini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// `f32` ning 10 ta asosiy logaritmasini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// `f64` ning 10 ta asosiy logaritmasini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// `f32` ning asosiy 2 ta logarifmini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// `f64` ning asosiy 2 ta logarifmini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` qiymatlari uchun `a * b + c` qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` qiymatlari uchun `a * b + c` qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` ning mutlaq qiymatini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` ning mutlaq qiymatini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Minimal ikkita `f32` qiymatini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Minimal ikkita `f64` qiymatini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Maksimal ikkita `f32` qiymatini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Maksimal ikkita `f64` qiymatini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` qiymatlari uchun `y` dan `x` gacha bo'lgan belgini nusxalash.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` qiymatlari uchun `y` dan `x` gacha bo'lgan belgini nusxalash.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` dan kichik yoki teng bo'lgan eng katta butun sonni qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` dan kichik yoki teng bo'lgan eng katta butun sonni qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` dan katta yoki teng bo'lgan eng kichik butun sonni qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` dan katta yoki teng bo'lgan eng kichik butun sonni qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` ning butun qismini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` ning butun qismini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Eng yaqin butun sonni `f32` ga qaytaradi.
    /// Agar argument tamsayı bo'lmasa, aniq bo'lmagan suzuvchi nuqta istisnosini keltirib chiqarishi mumkin.
    pub fn rintf32(x: f32) -> f32;
    /// Eng yaqin butun sonni `f64` ga qaytaradi.
    /// Agar argument tamsayı bo'lmasa, aniq bo'lmagan suzuvchi nuqta istisnosini keltirib chiqarishi mumkin.
    pub fn rintf64(x: f64) -> f64;

    /// Eng yaqin butun sonni `f32` ga qaytaradi.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Eng yaqin butun sonni `f64` ga qaytaradi.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Eng yaqin butun sonni `f32` ga qaytaradi.Yarim yo'l holatlarini noldan uzoqlashtiradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Eng yaqin butun sonni `f64` ga qaytaradi.Yarim yo'l holatlarini noldan uzoqlashtiradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Algebraik qoidalar asosida optimallashtirishga imkon beruvchi suzuvchi qo'shimchalar.
    /// Kirishlar cheklangan deb taxmin qilishi mumkin.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Algebraik qoidalar asosida optimallashtirishga imkon beruvchi suzuvchi olib tashlash.
    /// Kirishlar cheklangan deb taxmin qilishi mumkin.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Algebraik qoidalar asosida optimallashtirishga imkon beradigan float multiplikatsiyasi.
    /// Kirishlar cheklangan deb taxmin qilishi mumkin.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Algebraik qoidalar asosida optimallashtirishga imkon beradigan float bo'limi.
    /// Kirishlar cheklangan deb taxmin qilishi mumkin.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Algebraik qoidalar asosida optimallashtirishga imkon beradigan suzuvchi qoldiq.
    /// Kirishlar cheklangan deb taxmin qilishi mumkin.
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Dvigateldan tashqaridagi qiymatlar uchun undef qiymatini qaytarishi mumkin bo'lgan LLVM ning fptoui/fptosi bilan aylantiring
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] va [`f64::to_int_unchecked`] sifatida barqarorlashtirildi.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Butun sonli `T` turiga o'rnatilgan bitlar sonini qaytaradi
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `count_ones` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// `T` tamsayı turidagi etakchi o'rnatilmagan bitlar sonini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `leading_zeros` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` qiymatiga ega bo'lgan `x` `T` bit kengligini qaytaradi.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` singari, ammo `0` qiymatiga ega `x` berilganda `undef` ni qaytarishi sababli juda xavfli.
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// `T` tamsayı turidagi ketma-ket o'rnatilmagan bitlar sonini qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `trailing_zeros` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` qiymatiga ega bo'lgan `x` `T` bit kengligini qaytaradi:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` singari, ammo `0` qiymatiga ega `x` berilganda `undef` ni qaytarishi sababli juda xavfli.
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// `T` tipidagi baytlarni teskari yo'naltiradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `swap_bytes` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Bitta `T` tipidagi bitlarni teskari yo'naltiradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `reverse_bits` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Belgilangan tamsayı qo'shilishini amalga oshiradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `overflowing_add` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Belgilangan tamsayı olib tashlashni amalga oshiradi
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `overflowing_sub` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Belgilangan butun sonni ko'paytirishni amalga oshiradi
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `overflowing_mul` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// To'liq bo'linishni amalga oshiradi, natijada `x % y != 0` yoki `y == 0` yoki `x == T::MIN && y == -1` aniqlanmagan xatti-harakatlarga olib keladi
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Tekshirilmagan bo'linishni amalga oshiradi, natijada `y == 0` yoki `x == T::MIN && y == -1` aniqlanmagan xatti-harakatlarga olib keladi
    ///
    ///
    /// Ushbu ichki uchun xavfsiz paketlar `checked_div` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// `y == 0` yoki `x == T::MIN && y == -1` paytida aniqlanmagan xatti-harakatlarga olib keladigan tekshirilmagan bo'linmaning qolgan qismini qaytaradi
    ///
    ///
    /// Ushbu ichki uchun xavfsiz paketlar `checked_rem` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Tekshirilmagan chap siljishni amalga oshiradi, natijada `y < 0` yoki `y >= N` aniqlanmagan xatti-harakatlarga olib keladi, bu erda N bitlarning T kengligi.
    ///
    ///
    /// Ushbu ichki uchun xavfsiz paketlar `checked_shl` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Tekshirilmagan o'ng siljishni amalga oshiradi, natijada `y < 0` yoki `y >= N` aniqlanmagan xatti-harakatlarga olib keladi, bu erda N bitlarning T kengligi.
    ///
    ///
    /// Ushbu ichki uchun xavfsiz paketlar `checked_shr` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Tekshirilmagan qo'shilish natijasini qaytaradi, natijada `x + y > T::MAX` yoki `x + y < T::MIN` aniqlanmagan xatti-harakatlarga olib keladi.
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Tekshirilmagan olib tashlash natijasini qaytaradi, natijada `x - y > T::MAX` yoki `x - y < T::MIN` aniqlanmagan xatti-harakatlarga olib keladi.
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Tekshirilmagan ko'paytirish natijasini qaytaradi, natijada `x *y > T::MAX` yoki `x* y < T::MIN` aniqlanmagan xatti-harakatlarga olib keladi.
    ///
    ///
    /// Ushbu ichki barqaror hamkasbiga ega emas.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Chapga burilishni bajaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `rotate_left` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// To'g'ri aylantirishni amalga oshiradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `rotate_right` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// (A + b) mod 2 <sup>N ni</sup> qaytaradi, bu erda N-bitlarning T ning kengligi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `wrapping_add` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// (A, b) mod 2 <sup>N ni</sup> qaytaradi, bu erda N-bitlarning T ning kengligi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `wrapping_sub` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// (A * b) mod 2 <sup>N ni</sup> qaytaradi, bu erda N-bitlarning T ning kengligi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `wrapping_mul` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Raqam chegaralarida to'yingan `a + b` ni hisoblab chiqadi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `saturating_add` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Raqam chegaralarida to'yingan holda, `a - b` ni hisoblab chiqadi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyalari `saturating_sub` usuli orqali butun sonli ibtidoiylarda mavjud.
    /// Masalan,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' dagi variant uchun diskriminant qiymatini qaytaradi;
    /// agar `T` diskriminantiga ega bo'lmasa, `0` ni qaytaradi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtirilgan versiyasi [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// X001 ga chiqarilgan `T` tipidagi variantlar sonini qaytaradi;
    /// agar `T` variantlari bo'lmasa, `0` ni qaytaradi.Yashash variantlari hisobga olinadi.
    ///
    /// Ushbu ichki versiyaning barqarorlashtiriladigan versiyasi [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust ning "try catch" konstruktsiyasi, `try_fn` funktsiya ko'rsatgichini `data` ma'lumot ko'rsatkichi bilan ishlaydi.
    ///
    /// Uchinchi argument, agar panic paydo bo'lsa, chaqiriladigan funktsiya.
    /// Ushbu funktsiya ma'lumotlar ko'rsatgichini va ko'rsatgichni aniq maqsadga yo'naltirilgan istisno ob'ektiga olib boradi.
    ///
    /// Qo'shimcha ma'lumot uchun kompilyatorning manbasini va std-ning ta'qib qilinishini ko'ring.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVM bo'yicha `!nontemporal` do'konini chiqaradi (ularning hujjatlarini ko'ring).
    /// Ehtimol, hech qachon barqaror bo'lmaydi.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Tafsilotlar uchun `<*const T>::offset_from` hujjatlariga qarang.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Tafsilotlar uchun `<*const T>::guaranteed_eq` hujjatlariga qarang.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Tafsilotlar uchun `<*const T>::guaranteed_ne` hujjatlariga qarang.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Kompilyatsiya vaqtida ajratish.Ish vaqtida qo'ng'iroq qilinmasligi kerak.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Ba'zi funktsiyalar bu erda aniqlangan, chunki ular tasodifan ushbu modulda barqaror holatga keltirilgan.
// <https://github.com/rust-lang/rust/issues/15702>-ga qarang.
// (`transmute` ham ushbu toifaga kiradi, lekin `T` va `U` o'lchamlari bir xil bo'lganligi sababli uni o'rab bo'lmaydi.)
//

/// `ptr` ning `align_of::<T>()` ga to'g'ri mos kelishini tekshiradi.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` baytlarini `src` dan `dst` gacha nusxa ko'chiradi.Manba va manzil* bir-biriga mos kelmasligi kerak.
///
/// Bir-birining ustiga tushishi mumkin bo'lgan xotira hududlari o'rniga [`copy`]-dan foydalaning.
///
/// `copy_nonoverlapping` semantik jihatdan C ning [`memcpy`]-ga teng, ammo argument tartibi almashtirilgan.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `src` `count * size_of::<T>()` baytlarni o'qish uchun [valid] bo'lishi kerak.
///
/// * `dst` `count * size_of::<T>()` baytlarni yozish uchun [valid] bo'lishi kerak.
///
/// * Ham `src`, ham `dst` to'g'ri hizalanmalıdır.
///
/// * `src`-dan boshlanadigan xotira mintaqasi "hisoblash" hajmi bilan *
///   hajmi_of: :<T>() `baytlar bir xil o'lchamdagi `dst` dan boshlanadigan xotira mintaqasi bilan * * bo'lmasligi kerak.
///
/// [`read`] singari, `copy_nonoverlapping`, `T` ning [`Copy`] bo'lishidan qat'i nazar, `T` ning bitli nusxasini yaratadi.
/// Agar `T` [`Copy`] bo'lmasa, `*src` dan boshlanadigan mintaqadagi va `* dst` dan boshlanadigan mintaqadagi qiymatlarni *ikkala* dan foydalanib [violate memory safety][read-ownership] qilishi mumkin.
///
///
/// E'tibor bering, hatto samarali nusxalangan hajm ("count * size_of: :<T>()`) `0`, ko'rsatkichlar NULL bo'lmasligi va to'g'ri hizalanishi kerak.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`]-ni qo'lda qo'llang:
///
/// ```
/// use std::ptr;
///
/// /// `src`-ning barcha elementlarini `dst`-ga o'tkazadi va `src`-ni bo'sh qoldiradi.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // `dst`-ning barcha `src`-ni ushlab turish uchun etarli hajmga ega ekanligiga ishonch hosil qiling.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Ofset chaqiruvi har doim xavfsizdir, chunki `Vec` hech qachon `isize::MAX` baytdan ko'proq ajratmaydi.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Tarkibini tushirmasdan `src`-ni kesib oling.
///         // Agar biz panics-da pastga tushadigan bo'lsa, muammolarga duch kelmaslik uchun avval buni qilamiz.
///         src.set_len(0);
///
///         // Ikkala mintaqa bir-birini qoplay olmaydi, chunki o'zgaruvchan havolalar taxallusga ega emas va ikki xil vectors bir xil xotiraga ega bo'lolmaydi.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst`-ga hozirda `src` tarkibini saqlaganligi to'g'risida xabar bering.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ushbu tekshiruvlarni faqat ish vaqtida bajaring
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Kodgen ta'sirini kichikroq qilish uchun vahima qo'ymang.
        abort();
    }*/

    // XAVFSIZLIK: `copy_nonoverlapping` uchun xavfsizlik shartnomasi bo'lishi kerak
    // chaqiruvchi tomonidan qo'llab-quvvatlandi.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` baytlarini `src` dan `dst` gacha nusxa ko'chiradi.Manba va manzil bir-biriga to'g'ri kelishi mumkin.
///
/// Agar manba va manzil *hech qachon* bir-biriga to'g'ri kelmasa, uning o'rniga [`copy_nonoverlapping`] ishlatilishi mumkin.
///
/// `copy` semantik jihatdan C ning [`memmove`]-ga teng, ammo argument tartibi almashtirilgan.
/// Nusxalash baytlar `src` dan vaqtinchalik qatorga ko'chirilgandek va keyin massivdan `dst` ga ko'chirilgandek amalga oshiriladi.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `src` `count * size_of::<T>()` baytlarni o'qish uchun [valid] bo'lishi kerak.
///
/// * `dst` `count * size_of::<T>()` baytlarni yozish uchun [valid] bo'lishi kerak.
///
/// * Ham `src`, ham `dst` to'g'ri hizalanmalıdır.
///
/// [`read`] singari, `copy`, `T` ning [`Copy`] bo'lishidan qat'i nazar, `T` ning bitli nusxasini yaratadi.
/// Agar `T` [`Copy`] bo'lmasa, `*src` dan boshlanadigan mintaqadagi va `* dst` dan boshlanadigan mintaqadagi ikkala qiymatdan foydalanib [violate memory safety][read-ownership] bo'lishi mumkin.
///
///
/// E'tibor bering, hatto samarali nusxalangan hajm ("count * size_of: :<T>()`) `0`, ko'rsatkichlar NULL bo'lmasligi va to'g'ri hizalanishi kerak.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Xavfsiz buferdan Rust vector-ni samarali yarating:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` uning turi va nolga to'g'ri kelmasligi kerak.
/// /// * `ptr` `T` tipidagi `elts` tutashgan elementlarini o'qish uchun yaroqli bo'lishi kerak.
/// /// * Ushbu funktsiyani chaqirgandan so'ng, `T: Copy` bo'lmasa, ushbu elementlardan foydalanmaslik kerak.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // XAVFSIZLIK: Bizning old shartimiz manbaning to'g'ri kelishini va haqiqiyligini ta'minlaydi,
///     // va `Vec::with_capacity` ularni yozish uchun qulay maydonimiz borligini ta'minlaydi.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // XAVFSIZLIK: Biz uni ilgari shuncha quvvat bilan yaratgan edik,
///     // va oldingi `copy` ushbu elementlarni ishga tushirgan.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ushbu tekshiruvlarni faqat ish vaqtida bajaring
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Kodgen ta'sirini kichikroq qilish uchun vahima qo'ymang.
        abort();
    }*/

    // XAVFSIZLIK: `copy` uchun xavfsizlik shartnomasi qo'ng'iroq qiluvchi tomonidan bajarilishi kerak.
    unsafe { copy(src, dst, count) }
}

/// `count * size_of::<T>()` baytni `dst` dan `val` gacha o'rnatadi.
///
/// `write_bytes` C ning [`memset`]-ga o'xshash, ammo `count * size_of::<T>()` baytlarini `val` ga o'rnatadi.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `dst` `count * size_of::<T>()` baytlarni yozish uchun [valid] bo'lishi kerak.
///
/// * `dst` to'g'ri hizalanmış bo'lishi kerak.
///
/// Bundan tashqari, qo'ng'iroq qiluvchi `count * size_of::<T>()` baytni xotiraning berilgan hududiga yozish natijasida haqiqiy qiymat `T` bo'lishiga ishonch hosil qilishi kerak.
/// `T` qiymatini o'z ichiga olgan `T` sifatida yozilgan xotira mintaqasidan foydalanish aniqlanmagan xatti-harakatlardir.
///
/// E'tibor bering, hatto samarali nusxalangan hajm ("count * size_of: :<T>()`) `0`, ko'rsatkich NULL bo'lmasligi va to'g'ri hizalanishi kerak.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Yaroqsiz qiymat yaratish:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // `Box<T>`-ni bo'sh ko'rsatgich bilan yozish orqali avval saqlanib qolgan qiymatni yo'qotadi.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Shu nuqtada, `v`-dan foydalanish yoki tushirish aniqlanmagan xatti-harakatlarga olib keladi.
/// // drop(v); // ERROR
///
/// // Hatto `v` "uses"-ni chiqarib yuborish va shuning uchun aniqlanmagan xatti-harakatlar.
/// // mem::forget(v); // ERROR
///
/// // Aslida, `v` asosiy joylashuv o'zgaruvchanligiga ko'ra yaroqsiz, shuning uchun unga tegadigan *har qanday* operatsiya aniqlanmagan xatti-harakatlardir.
/////
/// // v2 =v bo'lsin;//XATO
///
/// unsafe {
///     // Buning o'rniga haqiqiy qiymatni qo'yaylik
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Endi quti yaxshi
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // XAVFSIZLIK: `write_bytes` uchun xavfsizlik shartnomasi qo'ng'iroq qiluvchi tomonidan bajarilishi kerak.
    unsafe { write_bytes(dst, val, count) }
}