use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Asenkron iteratorlar bilan ishlash interfeysi.
///
/// Bu trait asosiy oqimi.
/// Odatda oqimlar tushunchasi haqida ko'proq ma'lumot olish uchun [module-level documentation]-ga qarang.
/// Xususan, siz [implement `Stream`][impl]-ni qanday qilishni bilishni xohlashingiz mumkin.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Oqim natijasida hosil bo'lgan narsalar turi.
    type Item;

    /// Ushbu oqimning navbatdagi qiymatini chiqarishga urinish, agar qiymat hali mavjud bo'lmasa, uyg'onish uchun joriy vazifani ro'yxatdan o'tkazish va oqim tugagan bo'lsa, `None`-ni qaytarish.
    ///
    /// # Qaytish qiymati
    ///
    /// Qaytish mumkin bo'lgan bir nechta qiymatlar mavjud, ularning har biri alohida oqim holatini bildiradi:
    ///
    /// - `Poll::Pending` bu oqimning keyingi qiymati hali tayyor emasligini anglatadi.Amalga oshirish, keyingi qiymat tayyor bo'lishi mumkin bo'lganida, joriy vazifani xabardor qilishni ta'minlaydi.
    ///
    /// - `Poll::Ready(Some(val))` oqim `val` qiymatini muvaffaqiyatli ishlab chiqardi va keyingi `poll_next` qo'ng'iroqlarida qo'shimcha qiymatlarni ishlab chiqishi mumkinligini anglatadi.
    ///
    /// - `Poll::Ready(None)` oqim tugaganligini anglatadi va `poll_next` qayta chaqirilmasligi kerak.
    ///
    /// # Panics
    ///
    /// Oqim tugagandan so'ng (qaytib `Ready(None)` from `poll_next`), uning `poll_next` usulini qayta chaqirish panic, abadiy bloklanishi yoki boshqa muammolarni keltirib chiqarishi mumkin; `Stream` trait bunday chaqiruv ta'siriga hech qanday talab qo'ymaydi.
    ///
    /// Biroq, `poll_next` usuli `unsafe` bilan belgilanmaganligi sababli, Rust odatdagi qoidalari qo'llaniladi: qo'ng'iroqlar oqim holatidan qat'i nazar, hech qachon aniqlanmagan xatti-harakatlarga (xotiraning buzilishi, `unsafe` funktsiyalaridan noto'g'ri foydalanish yoki shunga o'xshashlar) sabab bo'lmasligi kerak.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Oqimning qolgan uzunligidagi chegaralarni qaytaradi.
    ///
    /// `size_hint()`, birinchi element pastki chegara, ikkinchi element esa yuqori chegara bo'lgan yo'lakchani qaytaradi.
    ///
    /// Qaytgan katakning ikkinchi yarmi ["Option`]"<`[`usize`] `>` dir.
    /// [`None`] bu erda ma'lum bo'lgan yuqori chegara yo'qligini yoki yuqori chegara [`usize`] dan katta ekanligini anglatadi.
    ///
    /// # Amalga oshirish yozuvlari
    ///
    /// Translyatsiyani amalga oshirish e'lon qilingan elementlarning sonini berishi majburiy emas.Buggy oqim elementlarning pastki chegarasidan kamroq yoki yuqori chegaralaridan ko'proq hosil berishi mumkin.
    ///
    /// `size_hint()` birinchi navbatda oqim elementlari uchun joy ajratish kabi optimallashtirish uchun ishlatilishi kerak, ammo ishonchsiz bo'lishi kerak, masalan, xavfsiz kodni tekshirishni bekor qilish.
    /// `size_hint()`-ning noto'g'ri bajarilishi xotira xavfsizligini buzilishiga olib kelmasligi kerak.
    ///
    /// Ya'ni, amalga oshirish to'g'ri taxminni ta'minlashi kerak, chunki aks holda bu trait protokolini buzgan bo'ladi.
    ///
    /// Standart dastur har qanday oqim uchun to'g'ri bo'lgan "(0,` ["None`]")"ni qaytaradi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}