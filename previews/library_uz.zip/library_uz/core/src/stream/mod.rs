//! Asenkron takrorlanadigan takrorlanadigan takrorlash.
//!
//! Agar futures asenkron qiymatlar bo'lsa, oqimlar asinxron iteratorlardir.
//! Agar siz o'zingizni biron bir turdagi asenkron kollektsiyani topsangiz va ushbu to'plam elementlari bo'yicha operatsiyani bajarishingiz kerak bo'lsa, tezda 'streams'-ga o'tasiz.
//! Oqimlar idiomatik asenkron Rust kodida juda ko'p ishlatiladi, shuning uchun ular bilan tanishib chiqishga arziydi.
//!
//! Ko'proq tushuntirishdan oldin, ushbu modul qanday tuzilganligi haqida to'xtalamiz:
//!
//! # Organization
//!
//! Ushbu modul asosan turlari bo'yicha tashkil etilgan:
//!
//! * [Traits] asosiy qismi: bu traits qanday oqimlarning mavjudligini va ular bilan nima qilishingiz mumkinligini aniqlaydi.Ushbu traits usullari qo'shimcha o'qish vaqtini sarflashga arziydi.
//! * Funktsiyalar ba'zi bir asosiy oqimlarni yaratishning foydali usullarini taqdim etadi.
//! * Strukturalar ko'pincha ushbu modulning traits-dagi turli xil usullarning qaytish turlari hisoblanadi.Odatda `struct` ning o'zi emas, balki `struct` ni yaratadigan usulni ko'rib chiqishni xohlaysiz.
//! Buning sababi haqida ko'proq ma'lumot olish uchun '[Amalga oshiriladigan oqim](#amalga oshirish-oqim)' ni ko'ring.
//!
//! [Traits]: #traits
//!
//! Bo'ldi shu!Keling, soylarni qazib olaylik.
//!
//! # Stream
//!
//! Ushbu modulning yuragi va ruhi [`Stream`] trait.[`Stream`] yadrosi quyidagicha ko'rinadi:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! `Iterator`-dan farqli o'laroq, `Stream` `Stream`-ni `Stream`-ni amalga oshirishda ishlatiladigan va oqimni iste'mol qilishda ishlatiladigan (to-be-implemented)-`next`-usulini ajratib turadi.
//!
//! `Stream` iste'molchilari faqat `next` ni hisobga olishlari kerak, bu chaqirilganda `Option<Stream::Item>` hosil qiladigan future qaytaradi.
//!
//! `next` tomonidan qaytarilgan future elementlar mavjud bo'lganda `Some(Item)` beradi va ularning hammasi tugagandan so'ng iteratsiya tugaganligini ko'rsatish uchun `None` hosil bo'ladi.
//! Agar biz asenkron echimini kutayotgan bo'lsak, future oqim yana hosil bo'lguncha kutib turadi.
//!
//! Shaxsiy oqimlar iteratsiyani davom ettirishni tanlashi mumkin va shuning uchun yana `next` ga qo'ng'iroq qilish, biron bir vaqt ichida yana `Some(Item)` hosil qilishi mumkin yoki bo'lmasligi mumkin.
//!
//! ["Oqim"] ning to'liq ta'rifi qator boshqa usullarni ham o'z ichiga oladi, ammo ular [`poll_next`]-ning ustiga o'rnatilgan standart usullar va shuning uchun siz ularni bepul olasiz.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Oqim amalga oshirilmoqda
//!
//! O'zingizning oqimingizni yaratish ikki bosqichni o'z ichiga oladi: oqim holatini ushlab turish uchun `struct` yaratish va shu `struct` uchun [`Stream`] ni amalga oshirish.
//!
//! `1` dan `5` gacha hisoblanadigan `Counter` nomli oqim hosil qilaylik:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Birinchidan, struct:
//!
//! /// Birdan beshgacha hisoblanadigan oqim
//! struct Counter {
//!     count: usize,
//! }
//!
//! // biz hisobimiz birdan boshlanishini istaymiz, shuning uchun yordam berish uchun new() usulini qo'shaylik.
//! // Bu juda zarur emas, lekin qulay.
//! // E'tibor bering, biz `count` ni noldan boshlaymiz, nima uchun `poll_next()`'s dasturida quyida ko'rib chiqamiz.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Keyin, biz `Counter` uchun `Stream`-ni qo'llaymiz:
//!
//! impl Stream for Counter {
//!     // usize bilan hisoblashamiz
//!     type Item = usize;
//!
//!     // poll_next() talab qilinadigan yagona usul
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Bizning sonimizni ko'paytiring.Shuning uchun biz noldan boshladik.
//!         self.count += 1;
//!
//!         // Hisoblashni tugatgan-qilmaganligimizni tekshiring.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Oqimlar *dangasa*.Bu shuni anglatadiki, faqat oqim yaratishda _do_ ko'p narsa bo'lmaydi.`next`-ga qo'ng'iroq qilmaguningizcha, hech narsa bo'lmaydi.
//! Bu oqimni faqat uning yon ta'siri uchun yaratishda ba'zida chalkashliklarni keltirib chiqaradi.
//! Tuzuvchi bizni bunday xatti-harakatlar to'g'risida ogohlantiradi:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;