//! `Result` turi bilan ishlashda xato.
//!
//! [`Result<T, E>`][`Result`] xatolarni qaytarish va ko'paytirish uchun ishlatiladigan tur.
//! Bu muvaffaqiyatni ifodalovchi va qiymatni o'z ichiga olgan [`Ok(T)`] variantlari bilan xat va [`Err(E)`], xatoni ifodalovchi va xato qiymatini o'z ichiga oladi.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! Funktsiyalar [`Result`]-ni xatolar kutilgan va tiklanadigan har doim qaytaradi.`std` crate-da [`Result`] [I/O](../../std/io/index.html) uchun eng mashhur hisoblanadi.
//!
//! [`Result`]-ni qaytaradigan oddiy funktsiya quyidagicha aniqlanishi va ishlatilishi mumkin:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! ["Natija"] bo'yicha naqshlarni moslashtirish oddiy holatlar uchun tushunarli va tushunarli, ammo [`Result`] u bilan ishlashni qisqartiradigan ba'zi qulay usullar bilan ta'minlangan.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok` va `is_err` usullari ular aytganlarini bajaradi.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` `Result` ni iste'mol qiladi va boshqasini ishlab chiqaradi.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // Hisoblashni davom ettirish uchun `and_then` dan foydalaning.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // Xatoni boshqarish uchun `or_else` dan foydalaning.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // Natijani iste'mol qiling va tarkibini `unwrap` bilan qaytaring.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # Natijalardan foydalanish kerak
//!
//! Qaytish qiymatlarini xatolarni ko'rsatish uchun ishlatishda tez-tez uchraydigan muammo shundaki, qaytarish qiymatini e'tiborsiz qoldirish oson, shuning uchun xatoga yo'l qo'yilmaydi.
//! [`Result`] `#[must_use]` atributi bilan izohlanadi, natijada natija qiymati e'tiborsiz qoldirilganda kompilyator ogohlantiradi.
//! Bu [`Result`]-ni, ayniqsa, xatolarga duch kelishi mumkin bo'lgan funktsiyalar bilan foydali qiladi, ammo aks holda foydali qiymatni qaytarmaydi.
//!
//! I/O turlari uchun [`Write`] trait tomonidan belgilangan [`write_all`] usulini ko'rib chiqing:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`] ning haqiqiy ta'rifi [`io::Result`]-dan foydalanadi, bu shunchaki ["Natija"] "ning sinonimi<T,`[`io: :Error`]`>".*
//!
//! Ushbu usul qiymat bermaydi, lekin yozish muvaffaqiyatsiz bo'lishi mumkin.Xatolar bilan ishlash juda muhimdir va *emas* shunga o'xshash narsalarni yozing:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // Agar `write_all` xatolari bo'lsa, unda biz hech qachon bilmaymiz, chunki qaytarish qiymati e'tiborga olinmaydi.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! Agar siz Rust-da yozsangiz *, kompilyator sizga ogohlantirish beradi (sukut bo'yicha, `unused_must_use` lint tomonidan boshqariladi).
//!
//! Buning o'rniga, agar siz xatoga yo'l qo'yishni istamasangiz, shunchaki [`expect`] bilan muvaffaqiyat qozonishingiz mumkin.
//! Yozish bajarilmasa, bu juda foydali xabarni taqdim etadigan panic bo'ladi:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! Siz shunchaki muvaffaqiyatni tasdiqlashingiz mumkin:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! Yoki [`?`] bilan qo'ng'iroqlar to'plamidagi xatoni tarqating:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # Savol belgisi operatori, `?`
//!
//! [`Result`] turini qaytaradigan ko'plab funktsiyalarni chaqiradigan kodni yozishda xatolarni boshqarish zerikarli bo'lishi mumkin.
//! Savol belgisi operatori [`?`] qo'ng'iroqlar stakasida tarqaladigan xatolarning ba'zi bir plitalarini yashiradi.
//!
//! Buning o'rnini bosadi:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // Xatolarni erta qaytarish
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! Bu bilan:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // Xatolarni erta qaytarish
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *Bu juda yoqimli!*
//!
//! [`?`] bilan ifodani yakunlash, natijada [`Err`] bo'lmasa, ([`Ok`]) qiymatining ochilishiga olib keladi, bu holda [`Err`] yopilish funktsiyasidan erta qaytariladi.
//!
//!
//! [`?`] faqat [`Result`] ni qaytaradigan funktsiyalarda ishlatilishi mumkin, chunki u [`Err`] ning erta qaytishi bilan ta'minlaydi.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` ([`Ok`]) muvaffaqiyatini yoki ([`Err`]) muvaffaqiyatsizligini ifodalovchi tur.
///
/// Tafsilotlar uchun [module documentation](self)-ga qarang.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// Muvaffaqiyat qiymatini o'z ichiga oladi
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// Xato qiymatini o'z ichiga oladi
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// Turini amalga oshirish
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // Mavjud qiymatlarni so'rov qilish
    /////////////////////////////////////////////////////////////////////////

    /// Natijada [`Ok`] bo'lsa, `true` ni qaytaradi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// Natijada [`Err`] bo'lsa, `true` ni qaytaradi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// Natijada, agar berilgan qiymatni o'z ichiga olgan [`Ok`] qiymati bo'lsa, `true` qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// Natijada, agar berilgan qiymatni o'z ichiga olgan [`Err`] qiymati bo'lsa, `true` qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Har bir variant uchun adapter
    /////////////////////////////////////////////////////////////////////////

    /// `Result<T, E>` dan [`Option<T>`] ga o'zgartiradi.
    ///
    /// `self`-ni [`Option<T>`]-ga o'zgartiradi, `self`-ni iste'mol qiladi va agar mavjud bo'lsa, xatoni bekor qiladi.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// `Result<T, E>` dan [`Option<E>`] ga o'zgartiradi.
    ///
    /// `self`-ni [`Option<E>`]-ga o'zgartiradi, `self`-ni iste'mol qiladi va agar mavjud bo'lsa, muvaffaqiyat qiymatini bekor qiladi.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adabiyotlar bilan ishlash uchun adapter
    /////////////////////////////////////////////////////////////////////////

    /// `&Result<T, E>` dan `Result<&T, &E>` ga o'zgartiradi.
    ///
    /// Aslini o'zgartirib, asl nusxasini joyida qoldirib, yangi `Result` ishlab chiqaradi.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// `&mut Result<T, E>` dan `Result<&mut T, &mut E>` ga o'zgartiradi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // O'z ichiga olgan qiymatlarni o'zgartirish
    /////////////////////////////////////////////////////////////////////////

    /// `Result<T, E>`-`Result<U, E>`-ni o'z ichiga olgan [`Ok`] qiymatiga funktsiyani qo'llash orqali [`Err`] qiymatiga tegmasdan qoldiring.
    ///
    ///
    /// Ushbu funktsiyadan ikkita funktsiya natijalarini tuzish uchun foydalanish mumkin.
    ///
    /// # Examples
    ///
    /// Ipning har bir satridagi raqamlarni ikkiga ko'paytirib chop eting.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// Mavjud qiymatga funktsiyani qo'llaydi (agar [`Ok`] bo'lsa) yoki taqdim etilgan standartni qaytaradi (agar [`Err`] bo'lsa).
    ///
    /// `map_or`-ga berilgan argumentlar ishtiyoq bilan baholanadi;agar siz funktsiya chaqiruvining natijasini berayotgan bo'lsangiz, dangasa baholangan [`map_or_else`] dan foydalanish tavsiya etiladi.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// `Result<T, E>` dan `U` gacha bo'lgan funktsiyalarni o'z ichiga olgan [`Ok`] qiymatiga yoki orqaga qaytish funktsiyalarini o'z ichiga olgan [`Err`] qiymatlariga qo'llash orqali xaritalar.
    ///
    ///
    /// Ushbu funktsiya xato bilan ishlash paytida muvaffaqiyatli natijani ochish uchun ishlatilishi mumkin.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// `Result<T, E>`-`Result<T, F>`-ni o'z ichiga olgan [`Err`] qiymatiga funktsiyani qo'llash orqali [`Ok`] qiymatiga tegmasdan qoldiring.
    ///
    ///
    /// Ushbu funktsiyani xato bilan ishlash paytida muvaffaqiyatli natijadan o'tish uchun ishlatish mumkin.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Iterator konstruktorlari
    /////////////////////////////////////////////////////////////////////////

    /// Mumkin bo'lgan qiymat bo'yicha iteratorni qaytaradi.
    ///
    /// Natija [`Result::Ok`] bo'lsa, takrorlovchi bitta qiymat beradi, aks holda yo'q.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// Mumkin bo'lgan qiymat bo'yicha o'zgaruvchan iteratorni qaytaradi.
    ///
    /// Natija [`Result::Ok`] bo'lsa, takrorlovchi bitta qiymat beradi, aks holda yo'q.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // Mantiqiy qadriyatlar bo'yicha operatsiyalar, g'ayratli va dangasa
    /////////////////////////////////////////////////////////////////////////

    /// Natijada [`Ok`] bo'lsa, `res` qiymatini qaytaradi, aks holda `self` qiymatining [`Err`] qiymatini qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// Natijada [`Ok`] bo'lsa, `op`-ga qo'ng'iroq qiladi, aks holda `self`-ning [`Err`] qiymatini qaytaradi.
    ///
    ///
    /// Ushbu funktsiyani `Result` qiymatlari asosida boshqarish oqimi uchun ishlatish mumkin.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// Natijada [`Err`] bo'lsa, `res` qiymatini qaytaradi, aks holda `self` qiymatining [`Ok`] qiymatini qaytaradi.
    ///
    /// `or`-ga berilgan argumentlar ishtiyoq bilan baholanadi;agar siz funktsiya chaqiruvining natijasini berayotgan bo'lsangiz, dangasa baholangan [`or_else`] dan foydalanish tavsiya etiladi.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// Natijada [`Err`] bo'lsa, `op`-ga qo'ng'iroq qiladi, aks holda `self`-ning [`Ok`] qiymatini qaytaradi.
    ///
    ///
    /// Ushbu funktsiyani natija qiymatlari asosida boshqarish oqimi uchun ishlatish mumkin.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// Tarkibidagi [`Ok`] qiymatini yoki taqdim etilgan sukutni qaytaradi.
    ///
    /// `unwrap_or`-ga berilgan argumentlar ishtiyoq bilan baholanadi;agar siz funktsiya chaqiruvining natijasini berayotgan bo'lsangiz, dangasa baholangan [`unwrap_or_else`] dan foydalanish tavsiya etiladi.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// Tarkibidagi [`Ok`] qiymatini qaytaradi yoki yopilishidan hisoblaydi.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// `self` qiymatini iste'mol qilgan holda, uning [`Err`] emasligini tekshirmasdan, o'z ichiga olgan [`Ok`] qiymatini qaytaradi.
    ///
    ///
    /// # Safety
    ///
    /// Ushbu usulni [`Err`]-da chaqirish *[noefined behavior]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // Aniqlanmagan xatti-harakatlar!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // XAVFSIZLIK: xavfsizlik shartnomasi qo'ng'iroq qiluvchi tomonidan bajarilishi kerak.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// `self` qiymatini iste'mol qilgan holda, uning [`Ok`] emasligini tekshirmasdan, o'z ichiga olgan [`Err`] qiymatini qaytaradi.
    ///
    ///
    /// # Safety
    ///
    /// Ushbu usulni [`Ok`]-da chaqirish *[noefined behavior]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // Aniqlanmagan xatti-harakatlar!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // XAVFSIZLIK: xavfsizlik shartnomasi qo'ng'iroq qiluvchi tomonidan bajarilishi kerak.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// `Ok` qismining tarkibini nusxalash orqali `Result<&T, E>`-dan `Result<T, E>`-ga xaritalar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// `Ok` qismining tarkibini nusxalash orqali `Result<&mut T, E>`-dan `Result<T, E>`-ga xaritalar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// `Ok` qismining tarkibini klonlash orqali `Result<&T, E>` dan `Result<T, E>` gacha xaritalar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// `Ok` qismining tarkibini klonlash orqali `Result<&mut T, E>` dan `Result<T, E>` gacha xaritalar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// `self` qiymatini iste'mol qilgan holda [`Ok`] qiymatini qaytaradi.
    ///
    /// # Panics
    ///
    /// Panics, agar qiymati [`Err`] bo'lsa, panic xabari, shu jumladan uzatilgan xabar va [`Err`] mazmuni.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// `self` qiymatini iste'mol qilgan holda [`Ok`] qiymatini qaytaradi.
    ///
    /// Ushbu funktsiya panic bo'lishi mumkinligi sababli, uni ishlatish odatda taqiqlanadi.
    /// Buning o'rniga naqsh mosligini ishlatishni afzal ko'ring va [`Err`] ishini aniq ko'rib chiqing yoki [`unwrap_or`], [`unwrap_or_else`] yoki [`unwrap_or_default`] raqamlariga qo'ng'iroq qiling.
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics, agar qiymat [`Err`] bo'lsa, panic xabari ["Err"] qiymati bilan ta'minlanadi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// `self` qiymatini iste'mol qilgan holda [`Err`] qiymatini qaytaradi.
    ///
    /// # Panics
    ///
    /// Panics, agar qiymati [`Ok`] bo'lsa, panic xabari, shu jumladan uzatilgan xabar va [`Ok`] mazmuni.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// `self` qiymatini iste'mol qilgan holda [`Err`] qiymatini qaytaradi.
    ///
    /// # Panics
    ///
    /// Agar Panics qiymati, agar [`Ok`] bo'lsa, [Z Okpan] qiymati bilan maxsus panic xabari taqdim etiladi.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// O'z ichiga olgan [`Ok`] qiymatini yoki sukut bo'yicha qaytaradi
    ///
    /// `self` argumentini sarflaydi, keyin [`Ok`] bo'lsa, kiritilgan qiymatni qaytaradi, aks holda [`Err`] bo'lsa, ushbu turdagi standart qiymatni qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// Satrni tamsayıga o'zgartiradi va noto'g'ri shakllangan satrlarni 0 ga aylantiradi (butun sonlar uchun standart qiymat).
    /// [`parse`] mag'lubiyatni [`FromStr`]-ni amalga oshiradigan boshqa har qanday turga o'zgartiradi va [`Err`]-ni xatoga qaytaradi.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// Tarkibidagi [`Ok`] qiymatini qaytaradi, lekin hech qachon panics bo'lmaydi.
    ///
    /// [`unwrap`]-dan farqli o'laroq, ushbu usul hech qachon amalga oshirilmagan natija turlarida panic uchun ma'lum emas.
    /// Shuning uchun, `unwrap` o'rniga, `Result` ning xato turi keyinchalik yuzaga kelishi mumkin bo'lgan xatoga o'zgartirilsa, kompilyatsiya qilinmaydigan parvarishlash kafolati sifatida foydalanish mumkin.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// `Result<T, E>` (yoki `&Result<T, E>`) dan `Result<&<T as Deref>::Target, &E>` ga o'zgartiradi.
    ///
    /// [`Deref`](crate::ops::Deref) orqali asl [`Result`] ning [`Ok`] variantini majbur qiladi va yangi [`Result`] ni qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// `Result<T, E>` (yoki `&mut Result<T, E>`) dan `Result<&mut <T as DerefMut>::Target, &mut E>` ga o'zgartiradi.
    ///
    /// [`DerefMut`](crate::ops::DerefMut) orqali asl [`Result`] ning [`Ok`] variantini majbur qiladi va yangi [`Result`] ni qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// `Option` ning `Result` ni `Result` ning `Option` ga o'tkazadi.
    ///
    /// `Ok(None)` `None`-ga moslashtiriladi.
    /// `Ok(Some(_))` va `Err(_)` `Some(Ok(_))` va `Some(Err(_))` bilan taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// `Result<Result<T, E>, E>` dan `Result<T, E>` ga o'zgartiradi
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// Yassilash bir vaqtning o'zida faqat bitta uyalash darajasini olib tashlaydi:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// `self` `Ok` bo'lsa, [`Ok`] qiymatini va `self` `Err` bo'lsa, [`Err`] qiymatini qaytaradi.
    ///
    /// Boshqacha qilib aytganda, bu funktsiya `Result<T, T>` qiymatini (`T`) `Ok` yoki `Err` bo'lishidan qat'iy nazar qaytaradi.
    ///
    /// Bu [`Atomic*::compare_exchange`] yoki [`slice::binary_search`] kabi API bilan birgalikda foydali bo'lishi mumkin, ammo natijaning `Ok` bo'lganligi yoki yo'qligi sizga ahamiyatsiz bo'lgan hollarda.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// Bu usullarning kod hajmini kamaytirish uchun alohida funktsiya
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait dasturlari
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Mumkin bo'lgan qiymat bo'yicha iste'mol qiluvchi iteratorni qaytaradi.
    ///
    /// Natija [`Result::Ok`] bo'lsa, takrorlovchi bitta qiymat beradi, aks holda yo'q.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Natija takrorlovchilari
/////////////////////////////////////////////////////////////////////////////

/// [`Result`] ning [`Ok`] variantiga havola qilingan iterator.
///
/// Natija [`Ok`] bo'lsa, takrorlovchi bitta qiymat beradi, aks holda yo'q.
///
/// [`Result::iter`] tomonidan yaratilgan.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// [`Result`] ning [`Ok`] variantiga o'zgaruvchan mos yozuvlar orqali iterator.
///
/// [`Result::iter_mut`] tomonidan yaratilgan.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Result`] ning [`Ok`] variantidagi qiymat ustidan iterator.
///
/// Natija [`Ok`] bo'lsa, takrorlovchi bitta qiymat beradi, aks holda yo'q.
///
/// Ushbu struktur [`into_iter`] usuli bilan [`Result`] da yaratilgan ([`IntoIterator`] trait tomonidan taqdim etilgan).
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// `Iterator` dagi har bir elementni oladi: agar u `Err` bo'lsa, qo'shimcha elementlar olinmaydi va `Err` qaytariladi.
    /// Agar `Err` yuzaga kelmasa, har bir `Result` qiymatiga ega konteyner qaytariladi.
    ///
    /// To'liqligini tekshirib, vector dagi har bir butun sonni ko'paytiradigan misol:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// Boshqa tamsayılar ro'yxatidan birini olib tashlashga urinadigan yana bir misol, bu safar quyi oqimni tekshirish:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// Mana oldingi misolning o'zgarishi, birinchi `Err` dan keyin `iter` dan boshqa elementlar olinmasligini ko'rsatmoqda.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Uchinchi element suv oqimini keltirib chiqarganligi sababli, boshqa elementlar olinmagan, shuning uchun `shared` ning yakuniy qiymati 16 emas, 6 (= `3 + 2 + 1`) dir.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): Ushbu ishlash xatosi yopilganda, uni Iterator::scan bilan almashtirish mumkin.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}