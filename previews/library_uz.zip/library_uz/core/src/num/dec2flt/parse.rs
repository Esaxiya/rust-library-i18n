//! Shaklning o'nlik qatorini tasdiqlash va ajratish:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Boshqacha qilib aytganda, suzuvchi nuqta sintaksisining ikkita istisnosiz: ishora yo'q va "inf" va "NaN" bilan ishlash yo'q.Ular (super::dec2flt) haydovchi funktsiyasi tomonidan boshqariladi.
//!
//! Garchi haqiqiy kirishni tanib olish nisbatan oson bo'lsa-da, ushbu modul panic-ni hech qachon bekor qiladigan va ko'plab modullarni bekor qilishi kerak, va boshqa modullar o'z navbatida panic-ga (yoki toshib ketishiga) ishonmaydi.
//!
//! Eng yomoni, bularning barchasi kirish orqali bitta o'tishda sodir bo'ladi.
//! Shunday qilib, har qanday narsani o'zgartirganda ehtiyot bo'ling va boshqa modullar bilan qayta tekshiring.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// O'nli qatorning qiziqarli qismlari.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// O'nli kasr, 18 dan kam o'nlik raqamlarga ega bo'lishi kafolatlangan.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Kirish satrining suzuvchi nuqta raqami ekanligini tekshiradi va agar shunday bo'lsa, undagi ajralmas qism, kasr qismi va ko'rsatkichni toping.
/// Belgilar bilan ishlamaydi.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' oldidan raqamlar yo'q
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Biz nuqta oldidan yoki keyin kamida bitta raqamni talab qilamiz.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Kesirli qismdan keyin keraksiz narsalar
            }
        }
        _ => Invalid, // Birinchi raqamli qatordan keyin keraksiz narsalar
    }
}

/// Birinchi raqamli bo'lmagan belgiga qadar o'nli raqamlarni o'chiradi.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Ko'rsatkichlarni chiqarish va xatolarni tekshirish.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Ko'rsatkichdan keyin keraksiz narsalar
    }
    if number.is_empty() {
        return Invalid; // Bo'sh ko'rsatkich
    }
    // Shu nuqtada bizda albatta raqamlar qatori mavjud.`i64`-ga qo'yish juda uzoq bo'lishi mumkin, ammo agar u juda katta bo'lsa, kirish shubhasiz nol yoki cheksizdir.
    // O'nli raqamlardagi har bir nol faqat ko'rsatkichni +/-1 ga moslashtirganligi sababli, exp=10 ^ 18 da kirish cheklangan bo'lishiga masofadan yaqinlashish uchun 17 eksabayt (!) nolga teng bo'lishi kerak edi.
    //
    // Bu biz murojaat qilishimiz kerak bo'lgan foydalanish holati emas.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}