//! IEEE 754 suzuvchi suzgichlarida biroz sust.Salbiy raqamlar bilan ishlash kerak emas va kerak emas.
//! Oddiy suzuvchi nuqta raqamlari (frac, exp) kabi kanonik ko'rinishga ega, shuning uchun qiymat 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), bu erda N-bitlar soni).
//!
//! Subnormallar biroz boshqacha va g'alati, ammo xuddi shu printsip qo'llaniladi.
//!
//! Biroq, bu erda biz ularni (sig, k) sifatida ifoda etamiz, masalan f qiymati *
//! 2 <sup>e</sup> ."hidden bit"-ni aniq qilishdan tashqari, bu mantisani almashtirish deb ataladigan ko'rsatkichni o'zgartiradi.
//!
//! Boshqacha qilib aytganda, odatda floats (1) sifatida yoziladi, ammo bu erda ular (2) sifatida yoziladi:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Biz (1) ni **kasrli namoyish** va (2) ni **integral tasvir** deb ataymiz.
//!
//! Ushbu moduldagi ko'plab funktsiyalar faqat oddiy raqamlar bilan ishlaydi.Dec2flt tartiblari juda kichik va juda katta sonlar uchun konservativ ravishda sekin to'g'ri yo'lni (Algoritm M) oladi.
//! Ushbu algoritmga faqat subnormal va nollarni boshqaradigan next_float() kerak.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` va `f64` uchun barcha konversiya kodlarini takrorlashdan saqlanish uchun yordamchi trait.
///
/// Buning sababi nima uchun ota-ona modulining doc sharhini ko'rib chiqing.
///
/// **hech qachon** hech qachon ** boshqa turlarga tatbiq etilmasligi yoki dec2flt modulidan tashqarida ishlatilishi kerak.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` va `from_bits` tomonidan ishlatiladigan tur.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Xom transmutatsiyani butun songa bajaradi.
    fn to_bits(self) -> Self::Bits;

    /// Butun sondan xom transmutatsiyani amalga oshiradi.
    fn from_bits(v: Self::Bits) -> Self;

    /// Ushbu raqam kiradigan toifani qaytaradi.
    fn classify(self) -> FpCategory;

    /// Mantissa, ko'rsatkich va belgini butun son sifatida qaytaradi.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Float kodini dekodlash.
    fn unpack(self) -> Unpacked;

    /// To'liq ifodalanishi mumkin bo'lgan kichik butun sondan tashlanadi.
    /// Agar Panic, agar butun sonni ifodalash mumkin bo'lmasa, ushbu moduldagi boshqa kod hech qachon bunga yo'l qo'ymasligiga ishonch hosil qiladi.
    fn from_int(x: u64) -> Self;

    /// Oldindan hisoblangan jadvaldan 10 <sup>e</sup> qiymatini oladi.
    /// `e >= CEIL_LOG5_OF_MAX_SIG` uchun Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// Ism nima deyilgan.
    /// Ichki materiallarni jonglyor qilishdan va LLVM doimiy katlamasini umid qilishdan ko'ra qattiq kodlash osonroq.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Haddan tashqari yoki nolga teng hosil qila olmaydigan kirishlarning o'nli raqamlariga bog'liq bo'lgan konservativ
    /// subnormallar.Ehtimol, maksimal normal qiymatning o'nlik ko'rsatkichi, shuning uchun nom.
    const MAX_NORMAL_DIGITS: usize;

    /// Agar eng muhim o'nlik raqamning joy qiymati bundan kattaroq bo'lsa, bu raqam cheksizgacha yaxlitlanadi.
    ///
    const INF_CUTOFF: i64;

    /// Agar eng muhim o'nlik raqamning joy qiymati bundan kam bo'lsa, raqam nolga yaxlitlanadi.
    ///
    const ZERO_CUTOFF: i64;

    /// Ko'rsatkichdagi bitlar soni.
    const EXP_BITS: u8;

    /// Belgilangan bitdagi bitlar soni, shu jumladan * yashirin bit.
    const SIG_BITS: u8;

    /// Belgilangan bitdagi bitlar soni, yashirin bitdan tashqari *.
    const EXPLICIT_SIG_BITS: u8;

    /// Fraksiyonel vakolatxonada maksimal qonuniy ko'rsatkich.
    const MAX_EXP: i16;

    /// Subnormallarni hisobga olmaganda, fraksiyonel vakolatxonadagi minimal qonuniy ko'rsatkich.
    const MIN_EXP: i16;

    /// `MAX_EXP` integral tasvir uchun, ya'ni siljish qo'llanilganda.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kodlangan (ya'ni ofset tomoni bilan)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` integral tasvir uchun, ya'ni siljish qo'llanilganda.
    const MIN_EXP_INT: i16;

    /// Integral tasvirda maksimal normallashtirilgan belgi.
    const MAX_SIG: u64;

    /// Integral tasvirda minimal normallashtirilgan belgi.
    const MIN_SIG: u64;
}

// Ko'pincha #34344 uchun vaqtinchalik echim.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Mantissa, ko'rsatkich va belgini butun son sifatida qaytaradi.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Ko'rsatkich tarafkashligi + mantissa siljishi
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe, `as` barcha platformalarda to'g'ri aylanadimi yoki yo'qmi, noaniq.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Mantissa, ko'rsatkich va belgini butun son sifatida qaytaradi.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Ko'rsatkich tarafkashligi + mantissa siljishi
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe, `as` barcha platformalarda to'g'ri aylanadimi yoki yo'qmi, noaniq.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp`-ni eng yaqin mashina suzuvchi turiga o'zgartiradi.
/// Anormal natijalarga ta'sir qilmaydi.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 bit, shuning uchun xe mantissaning siljishiga 63 ga teng
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64-bitli belgini T::SIG_BITS-bitgacha yarim-juftga aylantiring.
/// Ko'rsatkichlarning oshib ketishiga yo'l qo'yilmaydi.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Mantissa siljishini sozlang
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Normallashtirilgan raqamlar uchun teskari `RawFloat::unpack()`.
/// Belgilangan ko'rsatkich yoki ko'rsatkich normallashtirilgan raqamlar uchun yaroqsiz bo'lsa, Panics.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Yashirin bitni olib tashlang
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ko'rsatkich tarafkashligi va mantissa siljishi uchun ko'rsatkichni sozlang
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 0 ("+") darajasida bitni qoldiring, bizning raqamlarimiz ijobiydir
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Subnormal tuzing.Mantissaga 0 ga ruxsat beriladi va nolni tashkil qiladi.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Kodlangan ko'rsatkich 0, ishora biti 0, shuning uchun biz bitlarni qayta sharhlashimiz kerak.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Fp bilan bignumni taxminiy baholang.0.5 ULP ichida yarimdan-juftgacha aylanadi.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // `start` indeksidan oldin biz barcha bitlarni kesib tashladik, ya'ni biz `start` miqdorida o'ng tomonga siljiymiz, shuning uchun bu biz uchun zarur bo'lgan ko'rsatkichdir.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Kesilgan bitlarga qarab (half-to-even) dumaloq.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Argumentdan qat'iy ravishda kichikroq eng katta suzuvchi nuqta sonini topadi.
/// Subnormallarni, nolni yoki yuqori darajadagi quyishni boshqarmaydi.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Argumentdan qatiy kattaroq suzuvchi nuqta sonini toping.
// Ushbu operatsiya to'yingan, ya'ni next_float(inf) ==inf.
// Ushbu modulning aksariyat kodlaridan farqli o'laroq, bu funktsiya nol, subnormal va cheksiz ishlarni bajaradi.
// Biroq, boshqa barcha kodlar singari, u NaN va salbiy raqamlar bilan ishlamaydi.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Bu haqiqat bo'lish uchun juda yaxshi ko'rinadi, lekin u ishlaydi.
        // 0.0 nolinchi so'z sifatida kodlangan.Subnormallar 0x000m ... m, bu erda m mantissa.
        // Xususan, eng kichik subnormal 0x0 ... 01, eng kattasi 0x000F ... F.
        // Eng kichik normal raqam 0x0010 ... 0, shuning uchun bu burchak holati ham ishlaydi.
        // Agar o'sish mantissadan oshib ketsa, ko'chirish biti biz xohlagan darajadagi ko'rsatkichni oshiradi va mantissa bitlari nolga aylanadi.
        // Yashirin bit konvensiyasi tufayli bu ham biz xohlagan narsadir!
        // Va nihoyat, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}