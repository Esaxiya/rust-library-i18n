//! Qog'ozdan turli xil algoritmlar.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp-dagi ahamiyatli bitlar soni
const P: u32 = 64;

// Biz shunchaki *all* ko'rsatkichlari uchun eng yaxshi taxminiylikni saqlaymiz, shuning uchun "h" o'zgaruvchisi va u bilan bog'liq sharoitlar qoldirilishi mumkin.
// Bu ko'rsatkich bir necha kilobayt bo'shliq uchun sotiladi.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Ko'pgina arxitekturalarda suzuvchi nuqta operatsiyalari aniq bit hajmiga ega, shuning uchun hisoblashning aniqligi operatsiya asosida aniqlanadi.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86-da, SSE/SSE2 kengaytmalari mavjud bo'lmasa, x87 FPU float operatsiyalari uchun ishlatiladi.
// x87 FPU sukut bo'yicha 80 bit aniqlik bilan ishlaydi, ya'ni qiymatlar oxir-oqibat ifodalanganida, ikki tomonlama yaxlitlashni keltirib chiqaradigan operatsiyalar 80 bitgacha yaxlitlanadi.
//
// 32/64 bit float qiymatlari.Buni bartaraf etish uchun FPU boshqaruv so'zini hisoblashlar kerakli aniqlikda bajarilishi uchun sozlash mumkin.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// FPU boshqaruv so'zining asl qiymatini saqlab qolish uchun foydalaniladigan tuzilma, chunki struktura tushganda uni qayta tiklash mumkin.
    ///
    ///
    /// x87 FPU 16-bitli registr bo'lib, uning maydonlari quyidagicha:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Barcha maydonlar uchun hujjatlar IA-32 Architectures Software Developer qo'llanmasida mavjud (1-jild).
    ///
    /// Quyidagi kod uchun tegishli bo'lgan yagona maydon-bu kompyuter, Precision Control.
    /// Ushbu maydon FPU tomonidan bajariladigan operatsiyalarning aniqligini aniqlaydi.
    /// U quyidagicha o'rnatilishi mumkin:
    ///  - 0b00, bitta aniqlik, ya'ni 32-bit
    ///  - 0b10, ikki aniqlik, ya'ni 64 bit
    ///  - 0b11, ikki tomonlama kengaytirilgan aniqlik, ya'ni 80 bit (standart holat) 0b01 qiymati zaxiralangan va ishlatilmasligi kerak.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // XAVFSIZLIK: `fldcw` yo'riqnomasi to'g'ri ishlashi uchun tekshirilgan
        // har qanday `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: LLVM 8 va LLVM 9 ni qo'llab-quvvatlash uchun ATT sintaksisidan foydalanmoqdamiz.
                options(att_syntax, nostack),
            )
        }
    }

    /// FPU-ning aniq maydonini `T`-ga o'rnatadi va `FPUControlWord`-ni qaytaradi.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // `T` uchun mos bo'lgan Precision Control maydonining qiymatini hisoblang.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bit
            8 => 0x0200, // 64 bit
            _ => 0x0300, // sukut bo'yicha, 80 bit
        };

        // Keyinchalik `FPUControlWord` tuzilmasi tushirilgandan so'ng uni qayta tiklash uchun boshqaruv so'zining asl qiymatini oling XAVFSIZLIK: `fnstcw` buyrug'i har qanday `u16` bilan to'g'ri ishlashi uchun tekshirilgan
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: LLVM 8 va LLVM 9 ni qo'llab-quvvatlash uchun ATT sintaksisidan foydalanmoqdamiz.
                options(att_syntax, nostack),
            )
        }

        // Boshqarish so'zini kerakli aniqlikka o'rnating.
        // Bunga eski aniqlikni (8 va 9-bitlar, 0x300) niqoblash va uni yuqorida hisoblangan aniq bayroq bilan almashtirish orqali erishish mumkin.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Mashinaning kattaligi va suzuvchi yordamida Bellerophonning tezkor yo'li.
///
/// Bu alohida funktsiyaga ajratiladi, shunda bignumni qurishdan oldin uni sinab ko'rish mumkin.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Biz aniq qiymatni oxirigacha MAX_SIG bilan taqqoslaymiz, bu shunchaki tez va arzon rad etish (shuningdek, kodning qolgan qismini suv quyilishi xavotiridan xalos qiladi).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Tez yo'l juda muhim, arifmetikaning to'g'ri sonlar soniga yaxlitlashiga bog'liq.
    // x86-da (SSE yoki SSE2 holda) bu x87 FPU to'plamining aniqligini o'zgartirishni talab qiladi, shunda u to'g'ridan-to'g'ri 64/32 bitiga aylanadi.
    // `set_precision` funktsiyasi (x87 FPU" ning boshqaruv so'zi kabi) global holatni o'zgartirish orqali uni o'rnatishni talab qiladigan me'morchilikka aniqlik kiritish haqida g'amxo'rlik qiladi.
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // E <0 holatini boshqa branch ichiga katlab bo'lmaydi.
    // Salbiy kuchlar ikkilik sonda takrorlanadigan kasr qismining yaxlitlashiga olib keladi va bu yakuniy natijada haqiqiy (va ba'zida juda muhim!) Xatolarni keltirib chiqaradi.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Alleritm Bellerophon-bu ahamiyatsiz bo'lmagan raqamli tahlil bilan asoslangan ahamiyatsiz kod.
///
/// U "f"-ni 64 bitlik belgisi bilan suzuvchi tomonga aylantiradi va uni `10^e` ning eng yaxshi yaqinlashuvi bilan ko'paytiradi (bir xil o'zgaruvchan nuqta formatida).Bu ko'pincha to'g'ri natijani olish uchun etarli.
/// Biroq, natija ikkita qo'shni (ordinary) suzuvchi o'rtasida yarimga yaqinlashganda, ikkita taxminiy sonni ko'paytiradigan birikma yaxlitlash xatosi natija bir necha bitga o'chirilishi mumkinligini anglatadi.
/// Bu sodir bo'lganda, takrorlanuvchi R algoritmi ishlarni to'g'rilaydi.
///
/// Qo'lda to'lqinli "close to halfway" qog'ozdagi raqamli tahlil orqali aniq qilingan.
/// Klingerning so'zlari bilan:
///
/// > Eng kam ahamiyatli bit birliklarida ifodalangan qiyalik xato uchun inklyuziv majburiy hisoblanadi
/// > f * 10 ^ e ga yaqinlashishini suzuvchi nuqta hisoblash paytida to'plangan.(Nishab
/// > haqiqiy xato uchun chegara emas, balki z va taxminiy orasidagi farqni chegaralaydi
/// > $ P $ bit qiymatlarini ishlatadigan mumkin bo'lgan eng yaxshi taxmin.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) holatlari fast_path() da
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // N bitgacha yaxlitlashda farq qilish uchun qiyalik etarlimi?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// `f * 10^e` suzuvchi nuqta yaqinlashishini yaxshilaydigan takrorlanadigan algoritm.
///
/// Har bir iteratsiya so'nggi joyda bitta birlikni yaqinlashtiradi, albatta, agar `z0` hatto o'chirilgan bo'lsa, bu yaqinlashishi juda uzoq davom etadi.
/// Yaxshiyamki, Bellerophon uchun zaxira sifatida ishlatilganda, boshlang'ich taxminiy qiymati eng ko'p ULP bilan o'chirilgan.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // `x`, `y` musbat tamsayılarini toping, shunda `x / y` to'liq `(f *10^e) / (m* 2^k)` bo'ladi.
        // Bu nafaqat `e` va `k` belgilari bilan ishlashdan qochadi, balki biz `10^e` va `2^k` uchun umumiy bo'lgan ikkita raqamni kichikroq qilish uchun kuchini yo'q qilamiz.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Bu biroz noqulay yozilgan, chunki bizning bignumlarimiz salbiy sonlarni qo'llab-quvvatlamaydi, shuning uchun biz mutlaq qiymat + belgi ma'lumotlaridan foydalanamiz.
        // M_digits bilan ko'paytma ko'payib ketishi mumkin emas.
        // Agar `x` yoki `y` etarlicha katta bo'lsa, biz toshib ketishidan xavotirlanishimiz kerak, demak ular `make_ratio` fraktsiyani 2 ^ 64 yoki undan ko'p marta kamaytiradigan darajada katta.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Boshqa x kerak emas, clone()-ni saqlang.
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Hali ham y kerak, nusxasini oling.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// `f` odatdagi kabi o'nlik raqamlarni ifodalovchi `x = f` va `y = m` hisobga olinsa va `m` suzuvchi nuqta yaqinlashuvining ahamiyati bo'lsa, `x / y` nisbatini `(f *10^e) / (m* 2^k)` ga tenglashtiring, ehtimol ikkalasining kuchi bilan kamaytirilishi umumiydir.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, bundan tashqari biz kasrni ikkiga teng kuchga kamaytiramiz.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Buning ustiga toshib bo'lmaydi, chunki u ijobiy `e` va manfiy `k` talab qiladi, bu faqat 1 ga juda yaqin qiymatlar uchun sodir bo'lishi mumkin, ya'ni `e` va `k` nisbatan kichik bo'ladi.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Bu ham toshib bo'lmaydi, yuqoriga qarang.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), yana ikkitaning umumiy kuchiga kamayadi.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Kontseptual ravishda, Algoritm M-bu o'nli kasrni suzuvchi tomonga aylantirishning eng oddiy usuli.
///
/// Biz `f * 10^e` ga teng bo'lgan nisbatni hosil qilamiz, so'ngra u ikkitadan kuchga ega bo'lib, u haqiqiy suzuvchi belgini beradi.
/// Ikkilik daraja `k`-bu biz raqamni yoki maxrajni ikkiga ko'paytirganimiz sonidir, ya'ni `f *10^e` har doim `(u / v)* 2^k` ga teng.
/// Biz ahamiyatni aniqlaganimizda, bo'linmaning qolgan qismini tekshirib, faqat quyida yordamchi funktsiyalarda bajarishimiz kerak.
///
///
/// Ushbu algoritm, hatto `quick_start()`-da tasvirlangan optimallashtirish bilan ham juda sekin.
/// Biroq, bu algoritmlarning eng oddiyi, to'lib toshish, quyish va normal bo'lmagan natijalarga moslashish.
/// Ushbu dastur Bellerophon va Algoritm R ni haddan tashqari oshirib yuborilganda amalga oshiriladi.
/// Oqim va toshib ketishni aniqlash oson: bu nisbat hali intervalgacha ahamiyatga ega emas, ammo minimum/maximum ko'rsatkichiga erishildi.
/// Agar toshib ketgan bo'lsa, biz shunchaki abadiylikni qaytaramiz.
///
/// Pastki va pastki normallarni boshqarish ayyorroq.
/// Bitta katta muammo shundaki, minimal ko'rsatkich bilan nisbati ahamiyat uchun juda katta bo'lishi mumkin.
/// Tafsilotlar uchun underflow()-ga qarang.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME mumkin bo'lgan optimallashtirish: biz bu erda fp_to_float(big_to_fp(u)) ekvivalentini bajarishimiz uchun big_to_fp-ni umumlashtiramiz, faqat ikkita yaxlitlashsiz.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Minimal ko'rsatkichda to'xtashimiz kerak, agar `k < T::MIN_EXP_INT` gacha kutib tursak, unda biz ikki baravar kam bo'lamiz.
            // Afsuski, bu biz normal sonlarni minimal ko'rsatkich bilan ajratishimiz kerakligini anglatadi.
            // FIXME yanada oqlangan formulani toping, lekin haqiqatan ham to'g'ri ekanligiga ishonch hosil qilish uchun `tiny-pow10` sinovini o'tkazing!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Algoritm M takrorlanishining ko'pini bit uzunligini tekshirish orqali o'tkazib yuboradi.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bitning uzunligi-bu ikkita asosiy logaritma va log(u / v) = log(u), log(v).
    // Bashorat eng ko'pi bilan 1 ga teng, ammo har doim ham kam baholanadi, shuning uchun log(u) va log(v)-dagi xato bir xil belgiga ega va bekor qilinadi (agar ikkalasi ham katta bo'lsa).
    // Shuning uchun log(u / v) uchun xato ko'pi bilan bitta.
    // Maqsad nisbati-bu u/v intervalgacha ahamiyatga ega.Shunday qilib bizning tugatish shartimiz log2(u / v), ahamiyatli bitlar, plus/minus bit.
    // FIXME Ikkinchi bitni ko'rib chiqish taxminni yaxshilashi va boshqa bo'linishlarga yo'l qo'ymasligi mumkin.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Pastki yoki normal bo'lmagan.Uni asosiy funktsiyaga qoldiring.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // To'ldirish.Uni asosiy funktsiyaga qoldiring.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Nisbat minimal ko'rsatkichga ega bo'lgan intervalgacha ahamiyatga ega emas, shuning uchun biz ortiqcha bitlarni yaxlitlashimiz va ko'rsatkichni mos ravishda sozlashimiz kerak.
    // Endi haqiqiy qiymat quyidagicha ko'rinadi:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(rem bilan ifodalangan)
    //
    // Shuning uchun, yaxlitlangan bitlar!= 0.5 ULP bo'lganda, ular yaxlitlashni o'zlari hal qiladilar.
    // Agar ular teng bo'lsa va qolgan qismi nolga teng bo'lmasa, qiymat hali ham yaxlitlanishi kerak.
    // Faqat yaxlitlangan bitlar 1/2 bo'lganda va qolgan qismi nolga teng bo'lganda, bizda yarim-juft holat mavjud.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Oddiy dumaloq uchun, bo'linishning qolgan qismi asosida yumaloqlash kerak.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}