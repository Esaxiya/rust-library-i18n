//! Integral turlarga o'tkazish uchun xato turlari.

use crate::convert::Infallible;
use crate::fmt;

/// Tekshirilgan integral turini konvertatsiya qilish muvaffaqiyatsiz tugaganda, xato turi qaytarildi.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Yuqoridagi `From<Infallible> for TryFromIntError` kabi kod `Infallible` `!` uchun taxallusga aylanganda ishlashni davom ettirishiga ishonch hosil qilish uchun emas, balki moslashtiring.
        //
        //
        match never {}
    }
}

/// Butun sonni ajratishda qaytarilishi mumkin bo'lgan xato.
///
/// Ushbu xato [`i8::from_str_radix`] kabi ibtidoiy tamsayı turlarida `from_str_radix()` funktsiyalari uchun xato turi sifatida ishlatiladi.
///
/// # Mumkin bo'lgan sabablar
///
/// Boshqa sabablar qatorida `ParseIntError`, masalan, standart kirish joyidan olinganida, bo'shliqning etakchi yoki orqada joylashganligi sababli tashlanishi mumkin.
///
/// [`str::trim()`] usulidan foydalanib, tahlil qilishdan oldin bo'sh joy qolmasligini ta'minlaydi.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// To'liq sonni tahlil qilishda muvaffaqiyatsizlikka olib kelishi mumkin bo'lgan har xil turdagi xatolarni saqlash uchun Enum.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Qiymatni tahlil qilish bo'sh.
    ///
    /// Boshqa sabablarga ko'ra, ushbu variant bo'sh satrni ajratishda tuziladi.
    Empty,
    /// Kontekstida yaroqsiz raqam mavjud.
    ///
    /// Boshqa sabablarga ko'ra, ushbu variant ASCII bo'lmagan charni o'z ichiga olgan qatorni ajratishda yaratiladi.
    ///
    /// Ushbu variant, shuningdek, `+` yoki `-` satr ichida o'z-o'zidan yoki raqamning o'rtasiga noto'g'ri joylashtirilganda ham tuziladi.
    ///
    ///
    InvalidDigit,
    /// Butun son juda katta, maqsadli tamsayı turida saqlash mumkin emas.
    PosOverflow,
    /// Integer maqsadli tamsayı turida saqlash uchun juda kichikdir.
    NegOverflow,
    /// Qiymat nolga teng edi
    ///
    /// Ushbu variant ajralish satri nolga teng bo'lganda chiqariladi, bu nolga teng bo'lmagan turlari uchun noqonuniy bo'ladi.
    ///
    Zero,
}

impl ParseIntError {
    /// Butun sonni ajralishining batafsil sababini chiqaradi.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}