//! 8-bit imzosiz tamsayı turi uchun sobit.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Yangi kod bog'langan doimiylardan to'g'ridan-to'g'ri ibtidoiy turda foydalanishi kerak.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }