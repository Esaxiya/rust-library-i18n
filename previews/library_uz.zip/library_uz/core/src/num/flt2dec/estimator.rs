//! Eksponent baholovchi.

/// X001 kabi `k_0` topadi.
///
/// Bu `k = ceil(log_10 (mant * 2^exp))` ni taxmin qilish uchun ishlatiladi;
/// haqiqiy `k` yoki `k_0` yoki `k_0+1`.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits agar mant> 0 bo'lsa
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2), shuning uchun bu har doim kam baholanadi (yoki aniq), lekin ko'p emas.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}