//! Suzuvchi nuqta qiymatini alohida qismlarga va xato oralig'iga dekod qiladi.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekodlangan imzosiz cheklangan qiymat, quyidagicha:
///
/// - Asl qiymati `mant * 2^exp` ga teng.
///
/// - `(mant - minus)*2^exp` dan `(mant + plus)* 2^exp` gacha bo'lgan har qanday raqam asl qiymatiga aylanadi.
/// Faqat `inclusive` `true` bo'lganda intervalli.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Miqdor mantissa.
    pub mant: u64,
    /// Pastki xato oralig'i.
    pub minus: u64,
    /// Yuqori xato oralig'i.
    pub plus: u64,
    /// 2-bazada umumiy ko'rsatkich.
    pub exp: i16,
    /// Xatolar oralig'i inklyuziv bo'lganda to'g'ri.
    ///
    /// IEEE 754-da, bu asl mantissa teng bo'lganda to'g'ri keladi.
    pub inclusive: bool,
}

/// Shifrlangan imzosiz qiymat.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Cheksizliklar, ijobiy yoki salbiy.
    Infinite,
    /// Nol, ijobiy yoki salbiy.
    Zero,
    /// Keyingi dekodlangan maydonlar bilan cheklangan sonlar.
    Finite(Decoded),
}

/// "Dekodlash" d bo'lishi mumkin bo'lgan suzuvchi nuqta turi.
pub trait DecodableFloat: RawFloat + Copy {
    /// Minimal ijobiy normallashtirilgan qiymat.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Belgilangan suzuvchi nuqta raqamidan (salbiy bo'lsa, to'g'ri) va `FullDecoded` qiymatini qaytaradi.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // qo'shnilar: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode har doim eksponentni saqlaydi, shuning uchun mantissa subnormallar uchun o'lchovlanadi.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // qo'shnilar: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // bu erda maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // qo'shnilar: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}