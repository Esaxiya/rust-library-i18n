//! Deyarli to'g'ridan-to'g'ri (lekin biroz optimallashtirilgan) Rust tarjimasi "Suzuvchi nuqta raqamlarini tez va aniq bosib chiqarish" ning 3-rasmini [^ 1].
//!
//!
//! [^1]: Burger, RG va Dybvig, RK 1996. Suzuvchi nuqta raqamlarini chop etish
//!   tez va aniq.SIGPLAN Yo'q.31, 5 (1996 yil may), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n) uchun "Digit`" ning oldindan hisoblangan massivlari
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// faqat `x < 16 * scale` bo'lganda foydalanish mumkin;`scaleN` `scale.mul_small(N)` bo'lishi kerak
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Dragon uchun eng qisqa rejimni amalga oshirish.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // formatlash uchun `v` raqami ma'lum:
    // - `mant * 2^exp` ga teng;
    // - oldin asl nusxada `(mant - 2 *minus)* 2^exp`;va
    // - so'ngra asl nusxada `(mant + 2 *plus)* 2^exp`.
    //
    // Shubhasiz, `minus` va `plus` nolga teng bo'lmaydi.(cheksizliklar uchun biz diapazondan tashqari qiymatlardan foydalanamiz.) shuningdek, kamida bitta raqam hosil bo'ladi, ya'ni `mant` ham nolga teng bo'lolmaydi deb o'ylaymiz.
    //
    // bu shuni anglatadiki, `low = (mant - minus)*2^exp` va `high = (mant + plus)* 2^exp` orasidagi har qanday sonlar aynan shu suzuvchi nuqta raqamiga to'g'ri keladi va chegaralari asl mantissa teng bo'lganda (ya'ni, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` bu `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` ni qondiradigan asl ma'lumotlardan `k_0` ni baholang.
    // `10^(k-1) < high <= 10^k` ni qondiradigan qattiq bog'langan `k` keyinroq hisoblanadi.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp`-ni kasr shakliga aylantiring, shunda:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` ni `10^k` ga bo'ling.endi `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // `mant + plus > scale` (yoki `>=`) bo'lganda tuzatish.
    // biz aslida `scale` ni o'zgartirmayapmiz, chunki buning o'rniga dastlabki ko'paytmani o'tkazib yuborishimiz mumkin.
    // endi `scale < mant + plus <= scale * 10` va biz raqamlarni ishlab chiqarishga tayyormiz.
    //
    // `scale - plus < mant < scale` bo'lganda `d[0]` * nolga teng bo'lishi mumkinligini unutmang.
    // bu holda yaxlitlash sharti (quyida `up`) darhol ishga tushiriladi.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // `scale` ni 10 ga kattalashtirishga teng
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // raqamli avlod uchun `(2, 4, 8) * scale` keshi.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // `d[0..n-1]` hozirgacha hosil qilingan raqamlar bo'lgan invariantlar:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (shuning uchun `mant / scale < 10`), bu erda `d[i..j]`-d [i] * 10 ^ (ji) + ... uchun stenografiya.
        // + d [j-1] * 10 + d[j]`.

        // bitta raqam hosil qiling: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // bu o'zgartirilgan Dragon algoritmining soddalashtirilgan tavsifi.
        // qulaylik uchun ko'plab oraliq hosilalar va to'liqlik argumentlari chiqarib tashlangan.
        //
        // o'zgartirilgan invariantlardan boshlang, chunki biz `n`-ni yangiladik:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // `d[0..n-1]`-`low` va `high` o'rtasidagi eng qisqa vakillik, ya'ni `d[0..n-1]` quyidagilarning ikkalasini ham qondiradi, ammo `d[0..n-2]` buni bajarmaydi:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (biektivlik: `v` gacha bo'lgan raqamlar);va
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (oxirgi raqam to'g'ri).
        //
        // ikkinchi shart `2 * mant <= scale` gacha soddalashtiradi.
        // o'zgarmaslarni `mant`, `low` va `high` bo'yicha echish birinchi shartning sodda versiyasini beradi: `-plus < mant < minus`.
        // chunki `-plus < 0 <= mant`, biz `mant < minus` va `2 * mant <= scale` bo'lganda eng qisqa vakolatlarga egamiz.
        // (dastlabki mantissa teng bo'lganda, birinchisi `mant <= minus` ga aylanadi.)
        //
        // ikkinchisi ishlamasa (`2 * mant> o'lchov`), biz oxirgi raqamni oshirishimiz kerak.
        // bu ushbu holatni tiklash uchun etarli: biz allaqachon raqamli avlod `0 <= v / 10^(k-n) - d[0..n-1] < 1` ga kafolat berishini bilamiz.
        // bu holda birinchi shart `-plus < mant - scale < minus` bo'ladi.
        // avloddan keyin `mant < scale` dan beri bizda `scale < mant + plus` mavjud.
        // (yana, bu asl mantissa teng bo'lganda `scale <= mant + plus` bo'ladi.)
        //
        // qisqasi:
        // - `mant < minus` (yoki `<=`) bo'lganda `down` ni to'xtating va aylantiring (raqamlarni saqlang).
        // - `scale < mant + plus` (yoki `<=`) bo'lganda `up` ni to'xtating va aylantiring (oxirgi raqamni oshiring).
        // - aks holda ishlab chiqarishda davom eting.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // biz eng qisqa vakolatxonaga egamiz, yaxlitlashga o'ting

        // invariantlarni tiklash.
        // bu algoritmni har doim tugatishga majbur qiladi: `minus` va `plus` har doim ko'payadi, lekin `mant` `scale` moduli bilan kesiladi va `scale` aniqlanadi.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // yaxlitlash i) faqat yaxlitlash sharti ishga tushirilganda yoki ii) ikkala shart ham ishga tushirilganda va galstuk taqish yaxlitlashni afzal ko'rganda sodir bo'ladi.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // agar yaxlitlash uzunlikni o'zgartirsa, ko'rsatkich ham o'zgarishi kerak.
        // aftidan bu shartni qondirish juda qiyin (ehtimol imkonsiz), lekin biz bu erda xavfsiz va izchil bo'lmoqdamiz.
        //
        // XAVFSIZLIK: biz ushbu xotirani yuqorida ishga tushirdik.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // XAVFSIZLIK: biz ushbu xotirani yuqorida ishga tushirdik.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Dragon uchun aniq va qat'iy rejimni amalga oshirish.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` ni qondiradigan asl ma'lumotlardan `k_0` ni baholang.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` ni `10^k` ga bo'ling.endi `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // `mant + plus >= scale` qachon tuzatish, qaerda `plus / scale = 10^-buf.len() / 2`.
    // belgilangan o'lchamdagi bignumni saqlab qolish uchun biz aslida `mant + floor(plus) >= scale` dan foydalanamiz.
    // biz aslida `scale` ni o'zgartirmayapmiz, chunki buning o'rniga dastlabki ko'paytmani o'tkazib yuborishimiz mumkin.
    // yana eng qisqa algoritm bilan `d[0]` nolga teng bo'lishi mumkin, ammo oxir-oqibat yaxlitlanadi.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // `scale` ni 10 ga kattalashtirishga teng
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // agar biz oxirgi raqamli cheklov bilan ishlayotgan bo'lsak, ikki marta yaxlitlashni oldini olish uchun buferni haqiqiy ko'rsatilishidan oldin qisqartirishimiz kerak.
    //
    // Dumaloqlashganda buferni yana kattalashtirishimiz kerakligini unutmang!
    let mut len = if k < limit {
        // xattoki *bitta* raqamni ham ishlab chiqara olmaymiz.
        // masalan, bizda 9.5 kabi narsa bor va u 10 ga yaxlitlanganda mumkin.
        // biz bo'sh tamponni qaytaramiz, keyinroq yaxlitlash holati bundan mustasno, `k == limit` paydo bo'lganda va aniq bitta raqamni chiqarishi kerak.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // raqamli avlod uchun `(2, 4, 8) * scale` keshi.
        // (bu qimmat bo'lishi mumkin, shuning uchun bufer bo'sh bo'lganda ularni hisoblamang.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // quyidagi raqamlarning barchasi nolga teng, biz bu erda to'xtaymiz * yaxlitlashni bajarishga urinmang!qolgan raqamlarni to'ldiring.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // XAVFSIZLIK: biz ushbu xotirani yuqorida ishga tushirdik.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // agar raqamlar o'rtasida to'xtasak yaxlitlash, agar quyidagi raqamlar to'liq 5000 ... bo'lsa, oldingi raqamni tekshiring va juftga aylantirishga harakat qiling (ya'ni oldingi raqam teng bo'lganda yaxlitlashdan saqlaning).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // XAVFSIZLIK: `buf[len-1]` ishga tushirildi.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // agar yaxlitlash uzunlikni o'zgartirsa, ko'rsatkich ham o'zgarishi kerak.
        // lekin bizdan aniq sonli raqam so'ralgan, shuning uchun buferni o'zgartirmang ...
        // XAVFSIZLIK: biz ushbu xotirani yuqorida ishga tushirdik.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... agar buning o'rniga bizdan aniq aniqlik talab qilinmasa.
            // agar biz bufer bo'sh bo'lsa, qo'shimcha raqamni faqat `k == limit` (edge ishi) qo'shilishi mumkinligini tekshirishimiz kerak.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // XAVFSIZLIK: biz ushbu xotirani yuqorida ishga tushirdik.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}