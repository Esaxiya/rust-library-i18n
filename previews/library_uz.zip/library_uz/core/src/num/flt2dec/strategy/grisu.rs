//! "Suzuvchi nuqta raqamlarini butun sonlar bilan tez va aniq bosib chiqarish" da tasvirlangan Grisu3 algoritmining Rust moslashuvi [^ 1].
//! Bu taxminan 1KB oldindan hisoblangan jadvaldan foydalanadi va o'z navbatida, bu ko'pgina kirish uchun juda tezdir.
//!
//! [^1]: Florian Loitsch.2010. Suzuvchi nuqta raqamlarini tez va bosib chiqarish
//!   aniq sonlar bilan.SIGPLAN Yo'q.45, 6 (iyun, 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// mantiq uchun `format_shortest_opt`-dagi izohlarni ko'ring.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Berilgan `x > 0`, `(k, 10^k)` ni `10^k <= x < 10^(k+1)` ga qaytaradi.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Grisu uchun eng qisqa rejimni amalga oshirish.
///
/// Aks holda aniq bo'lmagan vakolatni qaytarganda `None` ni qaytaradi.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // bizga kamida uch bit qo'shimcha aniqlik kerak

    // umumiy ko'rsatkich bilan normallashtirilgan qiymatlardan boshlang
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // `ALPHA <= minusk + plus.e + 64 <= GAMMA` ga o'xshash har qanday `cached = 10^minusk` toping.
    // chunki `plus` normallashtirilgan, bu `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)` degan ma'noni anglatadi;
    // bizning `ALPHA` va `GAMMA` tanlovlarimizni hisobga olgan holda, bu `plus * cached` ni `[4, 2^32)` ga qo'yadi.
    //
    // Shubhasiz, `GAMMA - ALPHA`-ni maksimal darajaga ko'tarish kerak, shuning uchun biz 10 ta keshlangan kuchga muhtoj emasmiz, ammo ba'zi fikrlar mavjud:
    //
    //
    // 1. biz `floor(plus * cached)` ni `u32` ichida saqlamoqchimiz, chunki u qimmat bo'linishga muhtoj.
    //    (bu haqiqatan ham oldini olish mumkin emas, aniqlikni baholash uchun qoldiq talab qilinadi.)
    // 2.
    // qolgan `floor(plus * cached)` 10 marta ko'paytiriladi va u to'kilmasligi kerak.
    //
    // birinchisi `64 + GAMMA <= 32`, ikkinchisi `10 * 2^-ALPHA <= 2^64` beradi;
    // -60 va -32 bu cheklov bilan maksimal diapazon bo'lib, V8 ulardan ham foydalanadi.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // miqyosi fps.bu 1 ulpning maksimal xatosini beradi (5.1 teoremasidan isbotlangan).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-minusning haqiqiy diapazoni
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // yuqorida `minus`, `v` va `plus`*kvantlangan* taxminlar (xato <1 ulp).
    // biz xato ijobiy yoki salbiy ekanligini bilmasligimiz sababli, biz teng masofada joylashgan ikkita yaqinlashuvdan foydalanamiz va maksimal xato 2 ulpsga teng.
    //
    // "unsafe region"-biz dastlab yaratadigan liberal interval.
    // "safe region" biz qabul qiladigan konservativ intervaldir.
    // biz xavfli mintaqada to'g'ri repr bilan boshlaymiz va xavfsiz mintaqada joylashgan `v`-ga eng yaqin reprni topishga harakat qilamiz.
    // agar qila olmasak, biz voz kechamiz.
    //
    let plus1 = plus.f + 1;
    // plus0 = plus.f, 1 bo'lsin;//faqat tushuntirish uchun minus0 = minus.f + 1;//faqat tushuntirish uchun
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // umumiy ko'rsatkich

    // `plus1` ni integral va kasr qismlarga ajrating.
    // ajralmas qismlar u32 ga mos kelishiga kafolat beradi, chunki keshlangan quvvat `plus < 2^32` va normalizatsiya qilingan `plus.f` kafolati har doim aniqligi sababli `2^64 - 2^4` dan kam.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // eng katta `10^max_kappa` ni `plus1` dan ko'p bo'lmagan holda hisoblang (shuning uchun `plus1 < 10^(max_kappa+1)`).
    // bu quyida `kappa` ning yuqori chegarasi.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: agar `k` eng katta st bo'lsa
    // `0 <= y mod 10^k <= y - x`,              u holda `V = floor(y / 10^k) * 10^k` `[x, y]`-da va ushbu diapazondagi eng qisqa tasvirlardan biri (muhim raqamlarning minimal soni bilan).
    //
    //
    // 6.2 teoremasi bo'yicha `(minus1, plus1)` orasidagi `kappa` raqam uzunligini toping.
    // 6.2 teoremasi o'rniga `y mod 10^k < y - x` ni talab qilib, `x` ni chiqarib tashlash uchun qabul qilinishi mumkin.
    // (masalan, `x` =32000, `y` =32777; `kappa` =2 chunki "y mod 10 ^ 3=777 <y, x=777".) algoritm `y` ni chiqarib tashlash uchun keyingi tekshirish bosqichiga asoslanadi.
    //
    let delta1 = plus1 - minus1;
    // delta1int=(delta1>> e) foydalanishga yaroqli bo'lsin;//faqat tushuntirish uchun
    let delta1frac = delta1 & ((1 << e) - 1);

    // har bir qadamda aniqligini tekshirishda ajralmas qismlarni ko'rsatish.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // hali raqamlar ko'rsatilmaydi
    loop {
        // bizda har doim `plus1 >= 10^kappa` invariantlari sifatida ko'rsatish uchun kamida bitta raqam mavjud:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (`remainder = plus1int % 10^(kappa+1)` shundan kelib chiqadi)
        //
        //

        // `remainder` ni `10^kappa` ga bo'ling.ikkalasi ham `2^-e` tomonidan o'lchanadi.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; biz to'g'ri `kappa` topdik.
            let ten_kappa = (ten_kappa as u64) << e; // masshtab 10 ^ kappa umumiy eksponentga qaytish
            return round_and_weed(
                // XAVFSIZLIK: biz ushbu xotirani yuqorida ishga tushirdik.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // barcha integral raqamlarni keltirganimizda tsiklni uzing.
        // raqamlarning aniq soni `plus1 < 10^(max_kappa+1)` sifatida `max_kappa + 1`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // invariantlarni tiklash
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // har bir qadamda aniqligini tekshirishda kasr qismlarini ko'rsatish.
    // bu safar biz takroriy ko'paytmalarga tayanamiz, chunki bo'linish aniqlikni yo'qotadi.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // keyingi raqam muhim bo'lishi kerak, chunki biz `m = max_kappa + 1` (ajralmas qismdagi raqamlar) o'zgarmasligini sinashdan oldin:
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // toshib ketmaydi, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // `remainder` ni `10^kappa` ga bo'ling.
        // ikkalasi ham `2^e / 10^kappa` tomonidan o'lchanadi, shuning uchun ikkinchisi bu erda yashirin.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // yashirin bo'luvchi
            return round_and_weed(
                // XAVFSIZLIK: biz ushbu xotirani yuqorida ishga tushirdik.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // invariantlarni tiklash
        kappa -= 1;
        remainder = r;
    }

    // biz `plus1`-ning barcha muhim raqamlarini yaratdik, ammo bu eng maqbul raqam ekanligiga amin emasmiz.
    // masalan, `minus1` 3.14153 ... va `plus1` 3.14158 ... bo'lsa, 3.14154 dan 3.14158 gacha bo'lgan 5 ta eng qisqa tasvir mavjud, ammo bizda faqat eng kattasi bor.
    // biz oxirgi raqamni ketma-ket kamaytirishimiz va bu eng maqbul repr ekanligini tekshirishimiz kerak.
    // eng ko'p 9 nomzod bor (..1 dan ..9 gacha), shuning uchun bu juda tez.("rounding" fazasi)
    //
    // funktsiya ushbu "optimal" reprning ulp oralig'ida ekanligini tekshiradi va shuningdek, yaxlitlash xatosi tufayli "second-to-optimal" repr aslida optimal bo'lishi mumkin.
    // har qanday holatda ham bu `None` ni qaytaradi.
    // ("weeding" fazasi)
    //
    // bu erda barcha argumentlar umumiy (ammo noaniq) `k` qiymati bilan o'lchanadi, shuning uchun:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (va shuningdek, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (shuningdek, oldingi invariantlardan `threshold > plus1v`)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // 1.5 yaralari ichida `v` (aslida `plus1 - v`) ga ikki yaqinlashishni hosil qiling.
        // hosil bo'lgan vakillik ikkalasiga ham eng yaqin vakil bo'lishi kerak.
        //
        // bu erda `plus1 - v` ishlatiladi, chunki hisob-kitoblar overflow/underflow-dan qochish uchun `plus1`-ga nisbatan amalga oshiriladi (shuning uchun o'zgartirilgan ko'rinadigan nomlar).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // oxirgi raqamni kamaytiring va `v + 1 ulp` ga eng yaqin joyda to'xtating.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // biz dastlab `plus1 - plus1 % 10^kappa` ga teng bo'lgan `w(n)` taxminiy raqamlari bilan ishlaymiz.pastadir tanasini `n` marta ishlagandan so'ng, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // biz tekshiruvlarni soddalashtirish uchun `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` ni o'rnatdik (shuning uchun "qoldiq= plus1w(0)`).
            // `plus1w(n)` har doim ko'payib borayotganiga e'tibor bering.
            //
            // tugatish uchun uchta shartimiz bor.ularning har qanday biri loopni davom eta olmaydi, ammo bizda `v + 1 ulp`-ga eng yaqin bo'lgan kamida bitta haqiqiy vakolat mavjud.
            // Biz ularni qisqartirish uchun TC1 dan TC3 gacha belgilaymiz.
            //
            // TC1: `w(n) <= v + 1 ulp`, ya'ni bu eng yaqin bo'lishi mumkin bo'lgan so'nggi repr.
            // bu `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up` ga teng.
            // TC2 bilan birlashtirilib (`w(n+1)` is valid) mavjudligini tekshiradi, bu `plus1w(n)` ni hisoblashda mumkin bo'lgan toshib ketishning oldini oladi.
            //
            // TC2: `w(n+1) < minus1`, ya'ni keyingi takrorlash, albatta, `v` ga aylanmaydi.
            // bu `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold` ga teng.
            // chap tomon toshib ketishi mumkin, ammo biz `threshold > plus1v` ni bilamiz, shuning uchun TC1 noto'g'ri bo'lsa, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` va biz uning o'rniga `threshold - plus1w(n) < 10^kappa` ni xavfsiz tekshirib ko'rishimiz mumkin.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ya'ni keyingi repr
            // hozirgi nashrga qaraganda `v + 1 ulp` ga yaqinroq emas.
            // berilgan `z(n) = plus1v_up - plus1w(n)`, bu `abs(z(n)) <= abs(z(n+1))` bo'ladi.yana TC1 yolg'on deb taxmin qilsak, bizda `z(n) > 0` mavjud.ko'rib chiqishimiz kerak bo'lgan ikkita holat mavjud:
            //
            // - qachon `z(n+1) >= 0`: TC3 `z(n) <= z(n+1)` ga aylanadi.
            // chunki `plus1w(n)` ko'payib borayotgan bo'lsa, `z(n)` kamayishi kerak va bu aniq noto'g'ri.
            // - qachon `z(n+1) < 0`:
            //   - TC3a: oldingi shart `plus1v_up < plus1w(n) + 10^kappa`.TC2 yolg'on bo'lsa, `threshold >= plus1w(n) + 10^kappa`, shuning uchun u toshib ketolmaydi.
            //   - TC3b: TC3 `z(n) <= -z(n+1)` ga aylanadi, ya'ni `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   inkor qilingan TC1 `plus1v_up > plus1w(n)` beradi, shuning uchun u TC3a bilan birikganda toshib keta olmaydi yoki to'kilmaydi.
            //
            // binobarin, biz `TC1 || TC2 || (TC3a && TC3b)` qachon to'xtatishimiz kerak.quyidagi uning teskari tomoniga teng, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // eng qisqa takrorlash `0` bilan tugamaydi
                plus1w += ten_kappa;
            }
        }

        // ushbu vakillikning `v - 1 ulp`-ga eng yaqin vakili ekanligini tekshiring.
        //
        // bu shunchaki `v + 1 ulp` uchun tugatish shartlari bilan bir xil, uning o'rniga barcha `plus1v_up` `plus1v_down` bilan almashtiriladi.
        // toshib ketish tahlili teng darajada ushlab turiladi.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // Endi biz `plus1` va `minus1` orasida `v` ga eng yaqin vakolatxonamiz.
        // ammo bu juda liberaldir, shuning uchun biz `plus0` va `minus0`, ya'ni `plus1 - plus1w(n) <= minus0` yoki `plus1 - plus1w(n) >= plus0` orasida emas, balki har qanday `w(n)` ni rad etamiz.
        // biz `threshold = plus1 - minus1` va `plus1 - plus0 = minus0 - minus1 = 2 ulp` faktlaridan foydalanamiz.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Dragonning orqaga qaytishi bilan Grisu uchun eng qisqa rejimni amalga oshirish.
///
/// Bu ko'p hollarda ishlatilishi kerak.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // XAVFSIZLIK: Qarz tekshiruvchisi bizni `buf` dan foydalanishga imkon beradigan darajada aqlli emas
    // ikkinchi branch-da, shuning uchun biz bu erda umrni yuvamiz.
    // Ammo biz `buf` ni faqat `format_shortest_opt` `None` ni qaytargan taqdirda qayta ishlatamiz, shuning uchun bu yaxshi.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Grisu uchun aniq va aniq rejimni amalga oshirish.
///
/// Aks holda aniq bo'lmagan vakolatni qaytarganda `None` ni qaytaradi.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // bizga kamida uch bit qo'shimcha aniqlik kerak
    assert!(!buf.is_empty());

    // normallashtirish va `v` o'lchamlari.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // `v` ni integral va kasr qismlarga ajrating.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // ham eski `v`, ham yangi `v` (`10^-k` tomonidan o'lchamlari) <1 ulp (Theorem 5.1).
    // chunki xato ijobiy yoki manfiy ekanligini bilmasligimiz sababli, biz teng masofada joylashgan ikkita yaqinlashuvdan foydalanamiz va maksimal xato 2 ulps (eng qisqa holatga o'xshash).
    //
    //
    // Maqsad `v - 1 ulp` va `v + 1 ulp` uchun umumiy bo'lgan aniq yumaloq qatorlarni topishdir, shunda biz maksimal darajada o'zimizga ishonamiz.
    // agar buning iloji bo'lmasa, qaysi biri `v` uchun to'g'ri chiqish ekanligini bilmaymiz, shuning uchun biz voz kechamiz va orqaga qaytamiz.
    //
    // `err` bu erda `1 ulp * 2^e` deb belgilanadi (`vfrac` dagi ulp bilan bir xil) va biz `v` miqyosi olganda uni kattalashtiramiz.
    //
    //
    //
    let mut err = 1;

    // eng katta `10^max_kappa` ni `v` dan ko'p bo'lmagan holda hisoblang (shuning uchun `v < 10^(max_kappa+1)`).
    // bu quyida `kappa` ning yuqori chegarasi.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // agar biz oxirgi raqamli cheklov bilan ishlayotgan bo'lsak, ikki marta yaxlitlashni oldini olish uchun buferni haqiqiy ko'rsatilishidan oldin qisqartirishimiz kerak.
    //
    // Dumaloqlashganda buferni yana kattalashtirishimiz kerakligini unutmang!
    let len = if exp <= limit {
        // xattoki *bitta* raqamni ham ishlab chiqara olmaymiz.
        // masalan, bizda 9.5 kabi narsa bor va u 10 ga yaxlitlanganda mumkin.
        //
        // printsipial ravishda biz darhol bo'sh tampon bilan `possibly_round` ni chaqira olamiz, lekin `max_ten_kappa << e` ni 10 ga kattalashtirish toshib ketishiga olib kelishi mumkin.
        //
        // Shunday qilib, biz bu erda sustkashlik qilmoqdamiz va xatolar doirasini 10 baravar kengaytiramiz.
        // bu noto'g'ri salbiy ko'rsatkichni oshiradi, lekin juda juda,*juda* bir oz;
        // mantissasi 60 bitdan kattaroq bo'lganda u faqat muhim ahamiyatga ega bo'lishi mumkin.
        //
        // XAVFSIZLIK: `len=0`, shuning uchun ushbu xotirani ishga tushirish majburiyati ahamiyatsiz.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // ajralmas qismlarni ko'rsatish.
    // xato to'liq kasrli, shuning uchun uni ushbu qismda tekshirishga hojat yo'q.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // hali raqamlar ko'rsatilmaydi
    loop {
        // invariantlarni ko'rsatish uchun har doim kamida bitta raqamga egamiz:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (`remainder = vint % 10^(kappa+1)` shundan kelib chiqadi)
        //
        //

        // `remainder` ni `10^kappa` ga bo'ling.ikkalasi ham `2^-e` tomonidan o'lchanadi.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // bufer to'la emasmi?yaxlitlash pasini qoldiq bilan ishlating.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // XAVFSIZLIK: biz `len` ko'plab baytlarni ishga tushirdik.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // barcha integral raqamlarni keltirganimizda tsiklni uzing.
        // raqamlarning aniq soni `plus1 < 10^(max_kappa+1)` sifatida `max_kappa + 1`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // invariantlarni tiklash
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // kasr qismlarini ko'rsatish.
    //
    // printsipial ravishda biz oxirgi mavjud raqamga o'tishni davom ettiramiz va to'g'riligini tekshiramiz.
    // afsuski, biz cheklangan o'lchamdagi tamsayılar bilan ishlayapmiz, shuning uchun toshib ketishini aniqlash uchun biron bir mezon kerak.
    // V8 `remainder > err` dan foydalanadi, bu `v - 1 ulp` va `v` ning birinchi `i` muhim raqamlari farqlanganda noto'g'ri bo'ladi.
    // ammo bu juda ko'p boshqa kiritishni rad etadi.
    //
    // keyingi bosqich to'g'ri to'lib toshganligini aniqlaganligi sababli, biz buning o'rniga qattiqroq mezonni qo'llaymiz:
    // `err` va `v + 1 ulp` oralig'ida albatta ikki yoki undan ortiq yumaloq tasvirlar bo'lishi uchun `err` tilini `10^kappa / 2` dan oshirishni davom ettirmoqdamiz.
    //
    // ma'lumot uchun bu `possibly_round` ning dastlabki ikkita taqqoslashiga o'xshaydi.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariantlar, bu erda `m = max_kappa + 1` (ajralmas qismdagi raqamlar#):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // toshib ketmaydi, `2^e * 10 < 2^64`
        err *= 10; // toshib ketmaydi, `err * 10 < 2^e * 5 < 2^64`

        // `remainder` ni `10^kappa` ga bo'ling.
        // ikkalasi ham `2^e / 10^kappa` tomonidan o'lchanadi, shuning uchun ikkinchisi bu erda yashirin.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // bufer to'la emasmi?yaxlitlash pasini qoldiq bilan ishlating.
        if i == len {
            // XAVFSIZLIK: biz `len` ko'plab baytlarni ishga tushirdik.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // invariantlarni tiklash
        remainder = r;
    }

    // qo'shimcha hisoblash foydasiz (`possibly_round` aniq bajarilmaydi), shuning uchun biz voz kechamiz.
    return None;

    // biz `v`-ning barcha kerakli raqamlarini yaratdik, ular `v - 1 ulp`-ning tegishli raqamlari bilan bir xil bo'lishi kerak.
    // endi biz `v - 1 ulp` va `v + 1 ulp` tomonidan taqsimlanadigan noyob vakillik mavjudligini tekshiramiz;bu hosil qilingan raqamlarga yoki ushbu raqamlarning yaxlitlangan versiyasiga o'xshash bo'lishi mumkin.
    //
    // agar diapazonda bir xil uzunlikdagi bir nechta tasvir mavjud bo'lsa, biz ishonchimiz komil emas va buning o'rniga `None` ni qaytarishimiz kerak.
    //
    // bu erda barcha argumentlar umumiy (ammo noaniq) `k` qiymati bilan o'lchanadi, shuning uchun:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // XAVFSIZLIK: `buf` ning birinchi `len` baytlari ishga tushirilishi kerak.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (mos yozuvlar uchun nuqta chiziq berilgan raqamlar sonidagi mumkin bo'lgan tasvirlarning aniq qiymatini bildiradi.)
        //
        //
        // xato juda katta, chunki `v - 1 ulp` va `v + 1 ulp` o'rtasida kamida uchta mumkin bo'lgan vakillar mavjud.
        // qaysi biri to'g'ri ekanligini aniqlay olmaymiz.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // aslida 1/2 ulp ikkita mumkin bo'lgan vakolatxonalarni kiritish uchun etarli.
        // (`v - 1 ulp` va "v + 1 ulp" uchun noyob vakolatxonaga ehtiyoj borligini unutmang.) bu birinchi tekshiruvdan boshlab `ulp < ten_kappa` kabi to'lib toshmaydi.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // agar `v + 1 ulp` yaxlitlangan ko'rinishga yaqinroq bo'lsa (u allaqachon `buf` da bo'lsa), biz xavfsiz tarzda qaytib kelishimiz mumkin.
        // `v - 1 ulp` * joriy vakolatxonadan kamroq bo'lishi mumkinligini unutmang, ammo `1 ulp < 10^kappa / 2` sifatida bu shart etarli:
        // `v - 1 ulp` va joriy tasvir o'rtasidagi masofa `10^kappa / 2` dan oshmasligi kerak.
        //
        // shart `remainder + ulp < 10^kappa / 2` ga teng.
        // chunki bu osonlikcha toshib ketishi mumkin, avval `remainder < 10^kappa / 2` ekanligini tekshiring.
        // biz `ulp < 10^kappa / 2` ni tasdiqladik, chunki `10^kappa` toshib ketmaguncha, ikkinchi tekshiruv yaxshi.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // XAVFSIZLIK: qo'ng'iroq qiluvchimiz ushbu xotirani ishga tushirdi.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------qoldiq------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // boshqa tomondan, agar `v - 1 ulp` yaxlitlangan vakolatxonaga yaqinroq bo'lsa, biz to'planib, qaytishimiz kerak.
        // shu sababli biz `v + 1 ulp`-ni tekshirishga hojat yo'q.
        //
        // shart `remainder - ulp >= 10^kappa / 2` ga teng.
        // yana biz avval `remainder > ulp` ni tekshiramiz (bu `remainder >= ulp` emasligiga e'tibor bering, chunki `10^kappa` hech qachon nolga teng emas).
        //
        // shuningdek, `remainder - ulp <= 10^kappa` ekanligini unutmang, shuning uchun ikkinchi tekshiruv ortiqcha bo'lmaydi.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // XAVFSIZLIK: qo'ng'iroq qiluvchimiz ushbu xotirani ishga tushirgan bo'lishi kerak.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // faqat aniq aniqlik talab qilinganida qo'shimcha raqam qo'shing.
                // agar biz bufer bo'sh bo'lsa, qo'shimcha raqamni faqat `exp == limit` (edge ishi) qo'shilishi mumkinligini tekshirishimiz kerak.
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // XAVFSIZLIK: biz va qo'ng'iroq qiluvchimiz ushbu xotirani ishga tushirdik.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // aks holda biz halok bo'lamiz (ya'ni `v - 1 ulp` va `v + 1 ulp` orasidagi ba'zi qiymatlar yaxlitlanadi, boshqalari esa yaxlitlanadi) va voz kechamiz.
        //
        None
    }
}

/// Dragonning orqaga qaytishi bilan Grisu uchun aniq va aniq rejimni amalga oshirish.
///
/// Bu ko'p hollarda ishlatilishi kerak.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // XAVFSIZLIK: Qarz tekshiruvchisi bizni `buf` dan foydalanishga imkon beradigan darajada aqlli emas
    // ikkinchi branch-da, shuning uchun biz bu erda umrni yuvamiz.
    // Ammo biz `buf` ni faqat `format_exact_opt` `None` ni qaytargan taqdirda qayta ishlatamiz, shuning uchun bu yaxshi.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}