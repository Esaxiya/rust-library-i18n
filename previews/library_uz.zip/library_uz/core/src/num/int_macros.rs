macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Ushbu tamsayı turi bilan ifodalanadigan eng kichik qiymat.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Ushbu tamsayı turi bilan ifodalanadigan eng katta qiymat.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Ushbu tamsayt turining bitli kattaligi.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Belgilangan bazadagi qatorli bo'lakni butun songa o'zgartiradi.
        ///
        /// Satr ixtiyoriy `+` yoki `-` belgisi bo'lishi kerak, keyin raqamlar.
        /// Bo'shliqning etakchi va orqada joylashganligi xatoni anglatadi.
        /// Raqamlar-`radix` ga qarab, ushbu belgilarning kichik to'plami:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Ushbu funktsiya panics, agar `radix` 2 dan 36 gacha bo'lmasa.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` ikkilik tasviridagi sonlar sonini qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// `self` ikkilik tasviridagi nol sonini qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` ikkilik vakolatxonasidagi etakchi nol sonini qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// `self` ikkilik vakolatxonasida ketayotgan nol sonini qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// `self` ikkilik vakolatxonasida etakchilar sonini qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// `self` ikkilik vakolatxonasida orqada qolganlar sonini qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Kesilgan bitlarni hosil bo'lgan sonning oxirigacha o'rab, bitlarni belgilangan miqdordagi chapga, `n` ga siljitadi.
        ///
        ///
        /// Iltimos, e'tibor bering, bu `<<` o'zgaruvchan operator bilan bir xil operatsiya emas!
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Kesilgan bitlarni hosil bo'lgan sonning boshiga o'rab, bitlarni belgilangan miqdordagi `n` tomonga o'ngga siljitadi.
        ///
        ///
        /// Iltimos, e'tibor bering, bu `>>` o'zgaruvchan operator bilan bir xil operatsiya emas!
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Butun sonning bayt tartibini o'zgartiradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Butun sonda bitlarning tartibini o'zgartiradi.
        /// Eng kam ahamiyatli bit eng muhim bitga, ikkinchisi eng kichik bit ikkinchi eng muhim bitga aylanadi va hokazo.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Butun sonni katta endiandan maqsadning maqsadga muvofiqligini o'zgartiradi.
        ///
        /// Katta endian bu no-op.Kichik endianda baytlar almashtiriladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// agar cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } boshqa {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Butun sonni kichik endiandan maqsadning endianness darajasiga o'zgartiradi.
        ///
        /// Kichkina endian bu no-op.Katta endianda baytlar almashtiriladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// agar cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } boshqa {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self`-ni maqsadning endianness-dan katta endian-ga o'zgartiradi.
        ///
        /// Katta endian bu no-op.Kichik endianda baytlar almashtiriladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// agar cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // yoki bo'lmaslik kerakmi?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self`-ni maqsadning endianness-dan kichik endian-ga o'zgartiradi.
        ///
        /// Kichkina endian bu no-op.Katta endianda baytlar almashtiriladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// agar cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// To'liq son qo'shilishi tekshirildi.
        /// Agar `self + rhs` ni hisoblab chiqadi, agar toshib ketgan bo'lsa, `None` ni qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Belgilanmagan tamsayı qo'shilishi.Agar toshib ketishi mumkin emas deb hisoblasa, `self + rhs` ni hisoblab chiqadi.
        /// Bu qachon aniqlanmagan xatti-harakatga olib keladi
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // XAVFSIZLIK: qo'ng'iroq qiluvchi `unchecked_add` uchun xavfsizlik shartnomasini bajarishi kerak.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Butun sonni ayirish.
        /// Agar `self - rhs` ni hisoblab chiqadi, agar toshib ketgan bo'lsa, `None` ni qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Belgilanmagan tamsayı olib tashlash.Agar toshib ketishi mumkin emas deb hisoblasa, `self - rhs` ni hisoblab chiqadi.
        /// Bu qachon aniqlanmagan xatti-harakatga olib keladi
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // XAVFSIZLIK: qo'ng'iroq qiluvchi `unchecked_sub` uchun xavfsizlik shartnomasini bajarishi kerak.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Butun sonni ko'paytirish tekshirildi.
        /// Agar `self * rhs` ni hisoblab chiqadi, agar toshib ketgan bo'lsa, `None` ni qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Belgilanmagan butun sonni ko'paytirish.Agar toshib ketishi mumkin emas deb hisoblasa, `self * rhs` ni hisoblab chiqadi.
        /// Bu qachon aniqlanmagan xatti-harakatga olib keladi
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // XAVFSIZLIK: qo'ng'iroq qiluvchi `unchecked_mul` uchun xavfsizlik shartnomasini bajarishi kerak.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// To'liq bo'linish tekshirildi.
        /// `self / rhs` ni hisoblab chiqadi, agar `rhs == 0` yoki bo'linish natijasida toshib ketadigan bo'lsa, `None` qaytariladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // XAVFSIZLIK: div nolga va INT_MIN tomonidan yuqorida tekshirilgan
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Evklid bo'linmasi tekshirildi.
        /// `self.div_euclid(rhs)` ni hisoblab chiqadi, agar `rhs == 0` yoki bo'linish natijasida toshib ketadigan bo'lsa, `None` qaytariladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Qolgan qoldiq.
        /// `self % rhs` ni hisoblab chiqadi, agar `rhs == 0` yoki bo'linish natijasida toshib ketadigan bo'lsa, `None` qaytariladi.
        ///
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // XAVFSIZLIK: div nolga va INT_MIN tomonidan yuqorida tekshirilgan
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Evklid qoldig'i tekshirildi.
        /// `self.rem_euclid(rhs)` ni hisoblab chiqadi, agar `rhs == 0` yoki bo'linish natijasida toshib ketadigan bo'lsa, `None` qaytariladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Tekshirilgan inkor.
        /// `-self`-ni hisoblab chiqadi, agar `self == MIN` bo'lsa `None`-ni qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Chapga siljish tekshirildi.
        /// `self << rhs`-ni hisoblab chiqadi, agar `rhs` `self`-dagi bitlar sonidan kattaroq yoki teng bo'lsa, `None`-ni qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// O'ngga siljish tekshirildi.
        /// `self >> rhs`-ni hisoblab chiqadi, agar `rhs` `self`-dagi bitlar sonidan kattaroq yoki teng bo'lsa, `None`-ni qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Mutlaq qiymat tekshirildi.
        /// `self.abs()`-ni hisoblab chiqadi, agar `self == MIN` bo'lsa `None`-ni qaytaradi.
        ///
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Belgilangan ko'rsatkich.
        /// Agar `self.pow(exp)` ni hisoblab chiqadi, agar toshib ketgan bo'lsa, `None` ni qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // chunki exp!=0, nihoyat exp 1 bo'lishi kerak.
            // Ko'rsatkichning yakuniy biti bilan alohida muomala qiling, chunki keyinchalik bazani kvadratga solish shart emas va keraksiz toshib ketishiga olib kelishi mumkin.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// To'yingan butun son qo'shilishi.
        /// To'ldirish o'rniga raqamli chegaralarga to'yingan `self + rhs` ni hisoblab chiqadi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// To`yingan butun sonni ayirish.
        /// To'ldirish o'rniga raqamli chegaralarga to'yingan `self - rhs` ni hisoblab chiqadi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// To`yingan butunlikni inkor etish.
        /// `-self` ni hisoblab chiqadi, agar `self == MIN` to'lib toshish o'rniga `MAX` ni qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// To'yingan mutlaq qiymat.
        /// `self.abs()` ni hisoblab chiqadi, agar `self == MIN` to'lib toshish o'rniga `MAX` ni qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// To`yingan sonni ko`paytirish.
        /// To'ldirish o'rniga raqamli chegaralarga to'yingan `self * rhs` ni hisoblab chiqadi.
        ///
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// To`yingan tamsayı ko`rsatkichi.
        /// To'ldirish o'rniga raqamli chegaralarga to'yingan `self.pow(exp)` ni hisoblab chiqadi.
        ///
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// (modular) qo'shimchasini o'rash.
        /// `self + rhs`-ni hisoblab chiqadi, tur chegarasida o'raladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) olib tashlashni o'rash.
        /// `self - rhs`-ni hisoblab chiqadi, tur chegarasida o'raladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) ko'paytmasini o'rash.
        /// `self * rhs`-ni hisoblab chiqadi, tur chegarasida o'raladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) bo'linmasini o'rash.`self / rhs`-ni hisoblab chiqadi, tur chegarasida o'raladi.
        ///
        /// Bunday o'rash sodir bo'lishi mumkin bo'lgan yagona holat-bu `MIN / -1` ni imzolangan turga ajratish (bu erda `MIN`-bu turdagi minimal minimal qiymat);bu `-MIN` ga teng, bu turdagi qiymatni ko'rsatish uchun juda katta bo'lgan ijobiy qiymat.
        /// Bunday holda, ushbu funktsiya `MIN`-ni o'zi qaytaradi.
        ///
        /// # Panics
        ///
        /// Agar `rhs` 0 bo'lsa, bu funktsiya panic bo'ladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Evklid bo'linishini o'rash.
        /// `self.div_euclid(rhs)`-ni hisoblab chiqadi, tur chegarasida o'raladi.
        ///
        /// Saralash faqat imzolangan turdagi `MIN / -1` da bo'ladi (bu erda `MIN`-bu turdagi minimal minimal qiymat).
        /// Bu `-MIN`-ga teng, bu turdagi qiymatni ko'rsatish uchun juda katta bo'lgan ijobiy qiymat.
        /// Bunday holda, ushbu usul `MIN`-ni o'zi qaytaradi.
        ///
        /// # Panics
        ///
        /// Agar `rhs` 0 bo'lsa, bu funktsiya panic bo'ladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// (modular) qoldig'ini o'rash.`self % rhs`-ni hisoblab chiqadi, tur chegarasida o'raladi.
        ///
        /// Bunday o'rash hech qachon matematik tarzda ro'y bermaydi;amalga oshirish artefaktlari `x % y` ni imzolangan turdagi `MIN / -1` uchun yaroqsiz holga keltiradi (bu erda `MIN` manfiy minimal qiymat).
        ///
        /// Bunday holda, ushbu funktsiya `0`-ni qaytaradi.
        ///
        /// # Panics
        ///
        /// Agar `rhs` 0 bo'lsa, bu funktsiya panic bo'ladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Evklid qoldig'ini o'rash.`self.rem_euclid(rhs)`-ni hisoblab chiqadi, tur chegarasida o'raladi.
        ///
        /// Saralash faqat imzolangan turdagi `MIN % -1` da bo'ladi (bu erda `MIN`-bu turdagi minimal minimal qiymat).
        /// Bunday holda, ushbu usul 0 ni qaytaradi.
        ///
        /// # Panics
        ///
        /// Agar `rhs` 0 bo'lsa, bu funktsiya panic bo'ladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// (modular) inkorini o'rash.`-self`-ni hisoblab chiqadi, tur chegarasida o'raladi.
        ///
        /// Bunday o'rash sodir bo'lishi mumkin bo'lgan yagona holat-bu imzolangan turdagi `MIN` ni bekor qilish (bu erda `MIN`-bu turdagi minimal minimal qiymat);bu turdagi qiymat uchun juda katta bo'lgan ijobiy qiymat.
        /// Bunday holda, ushbu funktsiya `MIN`-ni o'zi qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic bepul chapga siljish chapga;`self << mask(rhs)` hosil qiladi, bu erda `mask` har qanday yuqori tartibli `rhs` bitlarini olib tashlaydi, bu esa siljish turining kengligidan oshib ketishiga olib keladi.
        ///
        /// Shuni esda tutingki, bu * chapga burish bilan bir xil emas;chapga o'ralgan RHS chap tomonga qaytarilgan LHS dan chiqib ketadigan bitlar o'rniga, tur oralig'ida cheklangan.
        ///
        /// Ibtidoiy tamsayı turlarining barchasi [`rotate_left`](Self::rotate_left) funktsiyasini amalga oshiradi, buning o'rniga siz xohlagan narsa bo'lishi mumkin.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // XAVFSIZLIK: bitning o'lchamlari bilan niqoblash biz siljimasligimizni ta'minlaydi
            // chegaradan
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-bitsiz siljish-o'ngga;`self >> mask(rhs)` hosil qiladi, bu erda `mask` har qanday yuqori tartibli `rhs` bitlarini olib tashlaydi, bu esa siljish turining kengligidan oshib ketishiga olib keladi.
        ///
        /// Shuni esda tutingki, bu * o'ngga aylantirish bilan bir xil emas;o'ng tomonga o'ralgan RHS, boshqa uchiga qaytarilgan LHS dan tashqariga siljigan bitlar o'rniga, tur doirasi bilan cheklangan.
        ///
        /// Ibtidoiy tamsayı turlarining barchasi [`rotate_right`](Self::rotate_right) funktsiyasini amalga oshiradi, buning o'rniga siz xohlagan narsa bo'lishi mumkin.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // XAVFSIZLIK: bitning o'lchamlari bilan niqoblash biz siljimasligimizni ta'minlaydi
            // chegaradan
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) mutlaq qiymatini o'rash.`self.abs()`-ni hisoblab chiqadi, tur chegarasida o'raladi.
        ///
        /// Bunday o'rash sodir bo'lishi mumkin bo'lgan yagona holat-bu turdagi salbiy minimal qiymatning mutlaq qiymatini olishdir;bu turdagi qiymat uchun juda katta bo'lgan ijobiy qiymat.
        /// Bunday holda, ushbu funktsiya `MIN`-ni o'zi qaytaradi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// `self` ning mutlaq qiymatini hech qanday o'ramasdan yoki vahima bosmasdan hisoblab chiqadi.
        ///
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// (modular) eksponentatsiyasini o'rash.
        /// `self.pow(exp)`-ni hisoblab chiqadi, tur chegarasida o'raladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // chunki exp!=0, nihoyat exp 1 bo'lishi kerak.
            // Ko'rsatkichning yakuniy biti bilan alohida muomala qiling, chunki keyinchalik bazani kvadratga solish shart emas va keraksiz toshib ketishiga olib kelishi mumkin.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` ni hisoblab chiqadi
        ///
        /// Alifmetik toshish yuz beradimi-yo'qligini ko'rsatadigan mantiqiy qo'shimchani qo'shadi.
        /// Agar toshib ketgan bo'lsa, o'ralgan qiymat qaytariladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` ni hisoblab chiqadi
        ///
        /// Aftmetik toshma sodir bo'lishini ko'rsatadigan mantiqiy bilan birga olib tashlashning katakchasini qaytaradi.
        /// Agar toshib ketgan bo'lsa, o'ralgan qiymat qaytariladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` va `rhs` ko'paytmalarini hisoblab chiqadi.
        ///
        /// Arifmetik toshish sodir bo'lishini ko'rsatadigan mantiqiy son bilan birga ko'paytma katakchasini qaytaradi.
        /// Agar toshib ketgan bo'lsa, o'ralgan qiymat qaytariladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, rost));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` `rhs` ga bo'linganda bo'luvchini hisoblab chiqadi.
        ///
        /// Alohida arifmetik toshish yuz beradimi-yo'qligini ko'rsatuvchi mantiqiy qism bilan birga bo'linuvchi grafigini qaytaradi.
        /// Agar toshib ketish sodir bo'lsa, u holda o'z-o'zidan qaytariladi.
        ///
        /// # Panics
        ///
        /// Agar `rhs` 0 bo'lsa, bu funktsiya panic bo'ladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// `self.div_euclid(rhs)` evklid bo'linishini hisoblab chiqadi.
        ///
        /// Alohida arifmetik toshish yuz beradimi-yo'qligini ko'rsatuvchi mantiqiy qism bilan birga bo'linuvchi grafigini qaytaradi.
        /// Agar toshib ketish sodir bo'lsa, `self` qaytariladi.
        ///
        /// # Panics
        ///
        /// Agar `rhs` 0 bo'lsa, bu funktsiya panic bo'ladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// `self` `rhs` ga bo'linganida qoldiqni hisoblab chiqadi.
        ///
        /// Bo'limga bo'linib, qoldiqning armaturasini arifmetik toshish sodir bo'lishini ko'rsatuvchi mantiqiy bilan qaytaradi.
        /// Agar to'lib toshgan bo'lsa, 0 qaytariladi.
        ///
        /// # Panics
        ///
        /// Agar `rhs` 0 bo'lsa, bu funktsiya panic bo'ladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// To'kib ketgan Evklid qoldig'i.`self.rem_euclid(rhs)` ni hisoblab chiqadi.
        ///
        /// Bo'limga bo'linib, qoldiqning armaturasini arifmetik toshish sodir bo'lishini ko'rsatuvchi mantiqiy bilan qaytaradi.
        /// Agar to'lib toshgan bo'lsa, 0 qaytariladi.
        ///
        /// # Panics
        ///
        /// Agar `rhs` 0 bo'lsa, bu funktsiya panic bo'ladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// O'ziga salbiy ta'sir qiladi, agar bu minimal qiymatga teng bo'lsa.
        ///
        /// O'zini inkor qilingan versiyasining gorizontalini, shuningdek, to'lib toshganmi yoki yo'qligini ko'rsatadigan boolean bilan qaytaradi.
        /// Agar `self` minimal qiymat bo'lsa (masalan, `i32` tipidagi qiymatlar uchun `i32::MIN`), unda minimal qiymat yana qaytariladi va `true` toshib ketishi uchun qaytariladi.
        ///
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// O'zini `rhs` bit bilan qoldiradi.
        ///
        /// Shift qiymatining bitlar sonidan kattaroq yoki tengligini ko'rsatadigan mantiqiy yozuv bilan birga o'z-o'zidan siljigan versiyasining grafigini qaytaradi.
        /// Agar siljish qiymati juda katta bo'lsa, u holda (N-1) qiymati maskalanadi, bu erda N-bitlar soni va bu qiymat siljishni amalga oshirish uchun ishlatiladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, rost));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// O'zini `rhs` bitga o'zgartiradi.
        ///
        /// Shift qiymatining bitlar sonidan kattaroq yoki tengligini ko'rsatadigan mantiqiy yozuv bilan birga o'z-o'zidan siljigan versiyasining grafigini qaytaradi.
        /// Agar siljish qiymati juda katta bo'lsa, u holda (N-1) qiymati maskalanadi, bu erda N-bitlar soni va bu qiymat siljishni amalga oshirish uchun ishlatiladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, rost));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// `self` ning mutlaq qiymatini hisoblab chiqadi.
        ///
        /// O'z-o'zidan absolyut versiyasining grafigini mantiqiy naycha bilan birga haddan tashqari toshib ketganligini bildiradi.
        /// Agar o'zini o'zi minimal qiymat bo'lsa
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// keyin minimal qiymat yana qaytariladi va to'lib toshganligi uchun haqiqiy qaytariladi.
        ///
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// O'zini `exp` kuchiga ko'taradi, kvadratni kvadrat yordamida eksponentlashdan foydalanadi.
        ///
        /// Ko'tarilish sodir bo'lganligini yoki yo'qligini ko'rsatuvchi bool bilan birga eksponentatsiya grafigini qaytaradi.
        ///
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, rost));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Overflowing_mul natijalarini saqlash uchun chizish maydoni.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // chunki exp!=0, nihoyat exp 1 bo'lishi kerak.
            // Ko'rsatkichning yakuniy biti bilan alohida muomala qiling, chunki keyinchalik bazani kvadratga solish shart emas va keraksiz toshib ketishiga olib kelishi mumkin.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// O'zini `exp` kuchiga ko'taradi, kvadratni kvadrat yordamida eksponentlashdan foydalanadi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // chunki exp!=0, nihoyat exp 1 bo'lishi kerak.
            // Ko'rsatkichning yakuniy biti bilan alohida muomala qiling, chunki keyinchalik bazani kvadratga solish shart emas va keraksiz toshib ketishiga olib kelishi mumkin.
            //
            //
            acc * base
        }

        /// `self` ning `rhs` ga evklid bo'linish miqdorini hisoblab chiqadi.
        ///
        /// Bu `n` butun sonini hisoblaydi, shunda `self = n * rhs + self.rem_euclid(rhs)`, `0 <= self.rem_euclid(rhs) < rhs` bilan.
        ///
        ///
        /// Boshqacha qilib aytganda, natijada `self / rhs` butun `n` raqamiga yaxlitlanadi, shunday qilib `self >= n * rhs`.
        /// Agar `self > 0` bo'lsa, bu nolga yaqinlashishga teng (Rust-da standart);
        /// agar `self < 0` bo'lsa, bu +/-cheksizlik tomon aylanishga teng.
        ///
        /// # Panics
        ///
        /// Ushbu funktsiya, agar `rhs` 0 bo'lsa yoki bo'linish oqib chiqsa, panic bo'ladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// b=4 bo'lsin;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// `self (mod rhs)` ning eng kam salbiy qoldig'ini hisoblab chiqadi.
        ///
        /// Bu xuddi Evklid bo'linish algoritmi bo'yicha amalga oshiriladi-`r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` va `0 <= r < abs(rhs)` berilgan.
        ///
        ///
        /// # Panics
        ///
        /// Ushbu funktsiya, agar `rhs` 0 bo'lsa yoki bo'linish oqib chiqsa, panic bo'ladi.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// b=4 bo'lsin;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// `self` ning mutlaq qiymatini hisoblab chiqadi.
        ///
        /// # Haddan tashqari harakat
        ///
        /// Ning mutlaq qiymati
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// sifatida ifodalanishi mumkin emas
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// va uni hisoblashga urinish toshib ketishiga olib keladi.
        /// Bu shuni anglatadiki, disk raskadrovka rejimidagi kod panic ni ishga tushiradi va optimallashtirilgan kod qaytadi
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// panic holda.
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // E'tibor bering, yuqoridagi#[inline] olib tashlash semantikasi biz kiritgan crate ga bog'liqligini anglatadi.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// `self` belgisini ko'rsatadigan raqamni qaytaradi.
        ///
        ///  - `0` agar raqam nolga teng bo'lsa
        ///  - `1` agar raqam ijobiy bo'lsa
        ///  - `-1` agar raqam salbiy bo'lsa
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Agar `self` ijobiy bo'lsa, `true`, agar raqam nol yoki salbiy bo'lsa, `false` ni qaytaradi.
        ///
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Agar `self` manfiy bo'lsa `true`, agar nol yoki musbat bo'lsa `false` ni qaytaradi.
        ///
        ///
        /// # Examples
        ///
        /// Asosiy foydalanish:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Ushbu tamsaytning xotira hajmini bayt qatori sifatida katta endian (network) bayt tartibida qaytaring.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Ushbu tamsaytning xotirani kichik sonli bayt tartibida bayt qatori sifatida qaytaring.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Ushbu tamsaytning xotira tasvirini bayt qatori sifatida bayt tartibida qaytaring.
        ///
        /// Maqsadli platformaning mahalliy endiannessidan foydalanilganda, ko'chma kod o'rniga mos ravishda [`to_be_bytes`] yoki [`to_le_bytes`] dan foydalanishi kerak.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bayt, agar cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } boshqa {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // XAVFSIZLIK: const ovozi, chunki tamsayılar oddiy eski ma'lumotlar tiplari, shuning uchun biz har doim ham qila olamiz
        // ularni baytlar qatoriga o'tkazing
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // XAVFSIZLIK: tamsayılar oddiy eski ma'lumotlar tiplari, shuning uchun biz ularni har doim o'zgartira olamiz
            // baytlar qatori
            unsafe { mem::transmute(self) }
        }

        /// Ushbu tamsaytning xotira tasvirini bayt qatori sifatida bayt tartibida qaytaring.
        ///
        ///
        /// [`to_ne_bytes`] iloji boricha bundan ustun bo'lishi kerak.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// bayt= num.as_ne_bytes();
        /// assert_eq!(
        ///     bayt, agar cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } boshqa {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // XAVFSIZLIK: tamsayılar oddiy eski ma'lumotlar tiplari, shuning uchun biz ularni har doim o'zgartira olamiz
            // baytlar qatori
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Katta endianda baytlar qatori sifatida uning vakolatxonasidan butun son hosil qiling.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto dan foydalaning;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * kirish=dam olish;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Kichik endian-da bayt qatori sifatida uning tasviridan butun sonni yarating.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto dan foydalaning;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * kirish=dam olish;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Uning mahalliy xotirasida baytlar qatori sifatida uning xotirasi tasviridan butun son hosil qiling.
        ///
        /// Maqsadli platformaning mahalliy endiannessidan foydalanilganda, ko'chma kod, ehtimol o'rniga [`from_be_bytes`] yoki [`from_le_bytes`] dan foydalanishni xohlaydi.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } boshqa {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto dan foydalaning;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * kirish=dam olish;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // XAVFSIZLIK: const ovozi, chunki tamsayılar oddiy eski ma'lumotlar tiplari, shuning uchun biz har doim ham qila olamiz
        // ularga transmute
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // XAVFSIZLIK: tamsayılar oddiy eski ma'lumotlar tiplari, shuning uchun biz har doim ularga o'tishimiz mumkin
            unsafe { mem::transmute(bytes) }
        }

        /// Yangi koddan foydalanishni afzal ko'rish kerak
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Ushbu tamsayı turi bilan ifodalanadigan eng kichik qiymatni qaytaradi.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Yangi koddan foydalanishni afzal ko'rish kerak
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Ushbu tamsayı turi bilan ifodalanadigan eng katta qiymatni qaytaradi.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}