//! Kompozitsiyali tashqi takrorlash.
//!
//! Agar siz o'zingizni qandaydir to'plam bilan topsangiz va ushbu to'plam elementlari ustida operatsiya qilishingiz kerak bo'lsa, tezda 'iterators'-ga duch kelasiz.
//! Iteratorlar idiomatik Rust kodida juda ko'p ishlatiladi, shuning uchun ular bilan tanishib chiqishga arziydi.
//!
//! Ko'proq tushuntirishdan oldin, ushbu modul qanday tuzilganligi haqida to'xtalamiz:
//!
//! # Organization
//!
//! Ushbu modul asosan turlari bo'yicha tashkil etilgan:
//!
//! * [Traits] asosiy qismi: bu traits qanday iteratorlar mavjudligini va ular bilan nima qilishingiz mumkinligini aniqlaydi.Ushbu traits usullari qo'shimcha o'qish vaqtini sarflashga arziydi.
//! * [Functions] ba'zi bir asosiy iteratorlarni yaratishning foydali usullarini taqdim eting.
//! * [Structs] ko'pincha ushbu modulning traits-dagi turli xil usullarning qaytish turlari.Odatda `struct` ning o'zi emas, balki `struct` ni yaratadigan usulni ko'rib chiqishni xohlaysiz.
//! Buning sabablari haqida ko'proq ma'lumot olish uchun '[Implementing Iterator](#uygulama-iterator)' ga qarang.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Bo'ldi shu!Keling, iteratorlarni ko'rib chiqaylik.
//!
//! # Iterator
//!
//! Ushbu modulning yuragi va ruhi [`Iterator`] trait.[`Iterator`] yadrosi quyidagicha ko'rinadi:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iteratorda [`next`] usuli mavjud, u chaqirilganda [`Option`] 'ni qaytaradi<Item>".
//! [`next`] elementlar mavjud bo'lganda [`Some(Item)`]-ni qaytaradi va ularning hammasi tugagandan so'ng, takrorlash tugaganligini bildirish uchun `None`-ni qaytaradi.
//! Shaxsiy iteratorlar takrorlashni davom ettirishni tanlashlari mumkin va shuning uchun yana [`next`]-ga qo'ng'iroq qilish [`Some(Item)`]-ni biron bir vaqtga qaytarishni boshlashi yoki boshlamasligi mumkin (masalan, [`TryIter`]-ga qarang).
//!
//!
//! ["Iterator"] ning to'liq ta'rifi qator boshqa usullarni ham o'z ichiga oladi, ammo ular standart usullar bo'lib, [`next`] ustiga o'rnatilgan bo'lib, siz ularni bepul olasiz.
//!
//! Iteratorlar ham bir-biriga mos keladi va ularni qayta ishlashning yanada murakkab shakllarini bajarish uchun ularni zanjirga ulash odatiy holdir.Qo'shimcha ma'lumot olish uchun quyidagi [Adapters](#adapters) bo'limiga qarang.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Takrorlashning uchta shakli
//!
//! To'plamdan iteratorlarni yaratadigan uchta keng tarqalgan usul mavjud:
//!
//! * `iter()`, bu `&T` orqali takrorlanadi.
//! * `iter_mut()`, bu `&mut T` orqali takrorlanadi.
//! * `into_iter()`, bu `T` orqali takrorlanadi.
//!
//! Standart kutubxonadagi turli xil narsalar, agar kerak bo'lsa, uchta uchta yoki bittasini amalga oshirishi mumkin.
//!
//! # Iterator dasturini amalga oshirish
//!
//! O'zingizning iteratoringizni yaratish ikki bosqichni o'z ichiga oladi: iterator holatini ushlab turish uchun `struct` yaratish va shu `struct` uchun [`Iterator`] ni amalga oshirish.
//! Shuning uchun ushbu modulda juda ko'p "struct`" mavjud: har bir iterator va iterator adapteri uchun bitta.
//!
//! `1` dan `5` gacha hisoblanadigan `Counter` nomli iteratorni yarataylik:
//!
//! ```
//! // Birinchidan, struct:
//!
//! /// Birdan beshgacha hisoblanadigan iterator
//! struct Counter {
//!     count: usize,
//! }
//!
//! // biz hisobimiz birdan boshlanishini istaymiz, shuning uchun yordam berish uchun new() usulini qo'shaylik.
//! // Bu juda zarur emas, lekin qulay.
//! // E'tibor bering, biz `count` ni noldan boshlaymiz, nima uchun `next()`'s dasturida quyida ko'rib chiqamiz.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Keyin, biz `Counter` uchun `Iterator`-ni qo'llaymiz:
//!
//! impl Iterator for Counter {
//!     // usize bilan hisoblashamiz
//!     type Item = usize;
//!
//!     // next() talab qilinadigan yagona usul
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Bizning sonimizni ko'paytiring.Shuning uchun biz noldan boshladik.
//!         self.count += 1;
//!
//!         // Hisoblashni tugatgan-qilmaganligimizni tekshiring.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Va endi biz undan foydalanishimiz mumkin!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`]-ga qo'ng'iroq qilish takrorlanadi.Rust-da `None` ga yetguncha sizning iteratoringizda [`next`]-ni chaqira oladigan konstruktsiya mavjud.Keling, keling.
//!
//! Shuni ham yodda tutingki, `Iterator` `nth` va `fold` kabi ichki usullarni chaqiradigan standart usullarni taqdim etadi.
//! Ammo, agar iterator ularni `next` ga qo'ng'iroq qilmasdan yanada samarali hisoblab chiqsa, `nth` va `fold` kabi usullarni maxsus dasturini yozish mumkin.
//!
//! # `for` ko'chadan va `IntoIterator`
//!
//! Rust ning `for` tsikli sintaksisi aslida iteratorlar uchun shakardir.`for` ning asosiy namunasi:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Bu raqamlar birdan beshgacha, har biri o'z satrida chop etiladi.Ammo bu erda nimanidir sezasiz: biz hech qachon vector-da iterator ishlab chiqarish uchun hech narsa chaqirmaganmiz.Nima beradi?
//!
//! Biror narsani iteratorga aylantirish uchun standart kutubxonada trait mavjud: [`IntoIterator`].
//! Ushbu trait-da bitta usul mavjud, [`into_iter`], bu [`IntoIterator`]-ni amalga oshiruvchi narsani iteratorga aylantiradi.
//! Keling, ushbu `for` tsiklini yana ko'rib chiqamiz va kompilyator uni nimaga o'zgartiradi:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust buni quyidagicha susaytiradi:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Birinchidan, biz `into_iter()` qiymatiga qo'ng'iroq qilamiz.Keyin, biz qaytib kelgan iteratorda mos kelamiz, `None` ko'rmagunimizcha [`next`] ni qayta-qayta chaqiramiz.
//! O'sha paytda biz `break` ko'chadan chiqdik va takrorlashni tugatdik.
//!
//! Bu erda yana bir nozik narsa bor: standart kutubxonada [`IntoIterator`]-ning qiziqarli dasturi mavjud:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Boshqacha qilib aytganda, barcha [`Iterator`] o'zlarini qaytarish orqali [`IntoIterator`] ni amalga oshiradilar.Bu ikki narsani anglatadi:
//!
//! 1. Agar siz [`Iterator`] yozayotgan bo'lsangiz, uni `for` tsikli bilan ishlatishingiz mumkin.
//! 2. Agar siz kollektsiyani yaratayotgan bo'lsangiz, u uchun [`IntoIterator`] dasturini qo'llash sizning to'plamingizdan `for` ko'chadan foydalanishga imkon beradi.
//!
//! # Malumot bo'yicha takrorlash
//!
//! [`into_iter()`] qiymati bo'yicha `self` ni qabul qilganligi sababli, `for` tsikli yordamida to'plam ustida takrorlash ushbu to'plamni sarf qiladi.Ko'pincha, kollektsiyani iste'mol qilmasdan takrorlashni xohlashingiz mumkin.
//! Ko'pgina to'plamlar mos ravishda `iter()` va `iter_mut()` deb nomlangan mos yozuvlar bo'yicha iteratorlarni taqdim etadigan usullarni taklif qiladi:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` hali ham ushbu funktsiyaga tegishli.
//! ```
//!
//! Agar `C` to'plami `iter()`-ni taqdim etsa, u odatda `&C` uchun `IntoIterator`-ni amalga oshiradi va shunchaki `iter()`-ni chaqiradi.
//! Xuddi shu tarzda, `iter_mut()`-ni taqdim etadigan `C` to'plami, `&mut C` uchun `IntoIterator`-ni `iter_mut()`-ga topshirish orqali amalga oshiradi.Bu qulay stenografiyani beradi:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` bilan bir xil
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` bilan bir xil
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Ko'pgina to'plamlarda `iter()` taqdim etilsa-da, barchasi `iter_mut()`-ni taklif qilmaydi.
//! Masalan, [`HashSet<T>`] yoki [`HashMap<K, V>`] tugmachalarini mutatsiyalash, agar kalit xeshlari o'zgargan bo'lsa, to'plamni mos kelmaydigan holatga keltirishi mumkin, shuning uchun bu to'plamlar faqat `iter()` ni taklif qiladi.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! [`Iterator`]-ni qabul qiladigan va boshqa [`Iterator`]-ni qaytaradigan funktsiyalar ko'pincha "adapter adapterlari" deb nomlanadi, chunki ular "adapter" ning bir shakli.
//! pattern'.
//!
//! Umumiy iterator adapterlariga [`map`], [`take`] va [`filter`] kiradi.
//! Qo'shimcha ma'lumot uchun ularning hujjatlariga qarang.
//!
//! Agar iterator adapteri panics bo'lsa, iterator aniqlanmagan (lekin xotirada xavfsiz) holatda bo'ladi.
//! Ushbu holatga Rust versiyalarida bir xil bo'lishiga kafolat berilmaydi, shuning uchun vahima qo'zg'agan iterator tomonidan qaytarilgan aniq qiymatlarga ishonishdan saqlanishingiz kerak.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratorlar (va [adapters](#adapters)) iteratori *dangasa*. Bu shuni anglatadiki, faqat iterator yaratish shunchaki ko'p _do_ emas. [`next`] ga qo'ng'iroq qilguningizcha hech narsa bo'lmaydi.
//! Faqatgina uning yon ta'siri uchun iterator yaratishda bu ba'zida chalkashliklarni keltirib chiqaradi.
//! Masalan, [`map`] usuli takrorlanadigan har bir elementning yopilishini chaqiradi:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Bu hech qanday qiymatlarni chop etmaydi, chunki biz uni ishlatishdan ko'ra faqat iterator yaratdik.Tuzuvchi bizni bunday xatti-harakatlar to'g'risida ogohlantiradi:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! [`map`] ni nojo'ya ta'sirlari uchun yozishning idiomatik usuli-`for` tsiklidan foydalanish yoki [`for_each`] usulini chaqirish:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Iteratorni baholashning yana bir keng tarqalgan usuli-yangi to'plam yaratish uchun [`collect`] usulidan foydalanish.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratorlar cheklangan bo'lishi shart emas.Misol tariqasida, ochiq chegaralar cheksiz iterator hisoblanadi:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Cheksiz iteratorni cheklanganga aylantirish uchun [`take`] iterator adapteridan foydalanish odatiy holdir:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Bu `0` dan `4` gacha bo'lgan raqamlarni har biri o'z satrida chop etadi.
//!
//! Shuni yodda tutingki, cheksiz iteratorlarda, hattoki natija matematik tarzda cheklangan vaqt ichida aniqlanishi mumkin bo'lgan usullarda ham tugamasligi mumkin.
//! Xususan, odatda, iteratorda har bir elementni bosib o'tishni talab qiladigan [`min`] kabi usullar, hech qanday cheksiz takrorlovchilar uchun muvaffaqiyatli qaytmasligi mumkin.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh yo'q!Cheksiz tsikl!
//! // `ones.min()` cheksiz pastadirni keltirib chiqaradi, shuning uchun biz bu darajaga etib bormaymiz!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;