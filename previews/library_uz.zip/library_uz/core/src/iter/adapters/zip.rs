use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// Bir vaqtning o'zida yana ikkita iteratorni takrorlaydigan takrorlovchi.
///
/// Ushbu `struct` [`Iterator::zip`] tomonidan yaratilgan.
/// Qo'shimcha ma'lumot uchun uning hujjatlariga qarang.
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // index, len va a_len faqat zipning ixtisoslashtirilgan versiyasi tomonidan qo'llaniladi
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // XAVFSIZLIK: `ZipImpl::__iterator_get_unchecked` bir xil xavfsizlikka ega
        // `Iterator::__iterator_get_unchecked` kabi talablar.
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// Zip ixtisoslashuvi trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // Bu `Iterator::__iterator_get_unchecked` bilan bir xil xavfsizlik talablariga ega
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// General Zip impl
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // A, b ni teng uzunlikka sozlang
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // XAVFSIZLIK: `i` `self.len` dan kichik, shuning uchun `self.a.len()` va `self.b.len()` dan kichik
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // xavfsizlikni ta'minlash: biz `i` <`self.a.len()` ekanligini tekshirdik
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // XAVFSIZLIK: `delta` ni hisoblash uchun `cmp::min` dan foydalanish
                // `end` ning `self.len` dan kichik yoki unga teng bo'lishini ta'minlaydi, shuning uchun `i` ham `self.len` dan kichikroq.
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // XAVFSIZLIK: yuqoridagi kabi.
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // A, b-ni teng uzunlikka sozlang, faqat `next_back` ning birinchi qo'ng'irog'i buni amalga oshirganligiga ishonch hosil qiling, aks holda biz `get_unchecked()`-ga qo'ng'iroq qilgandan keyin `self.next_back()`-ga qo'ng'iroqlarning cheklanishini buzamiz.
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // XAVFSIZLIK: `i` oldingi `self.len` qiymatidan kichikroq,
            // bu ham `self.a.len()` va `self.b.len()` dan kichik yoki unga teng
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `Iterator::__iterator_get_unchecked` uchun shartnomani qo'llab-quvvatlashi kerak.
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// Zip iteratsiyasining chap tomonini o'zboshimchalik bilan "source" olinadigan qilib tanlaydi, bu trait bounds ikkalasini ham sinab ko'rish uchun kerak bo'ladi
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // XAVFSIZLIK: bir xil talablarga javob beradigan xavfli funktsiyani xavfli funktsiyaga yo'naltirish
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// Element bilan cheklangan: nusxa ko'chirish, chunki Zip-ning TrustedRandomAccess va Drop-dan foydalanish manbasini o'zaro ta'siri aniq emas.
//
// Manbaning mantiqiy ravishda takomillashtirilgan sonini qaytaradigan qo'shimcha usul (manbaning qolgan qismini to'g'ri tushirish uchun next()) qo'ng'iroq qilmasdan kerak bo'ladi.
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Fmt-ni mavjud iteratorlarga qo'ng'iroq qilish *xavfsiz emas*, chunki biz ularni takrorlashni boshlaganimizdan so'ng, ular g'alati, xavfli bo'lishi mumkin bo'lgan holatlarda.
        //
        f.debug_struct("Zip").finish()
    }
}

/// Elementlari tasodifiy kirish imkoniga ega bo'lgan iterator
///
/// # Safety
///
/// Takrorlash qurilmasining `size_hint` telefoni aniq va arzon bo'lishi kerak.
///
/// `size` bekor qilinmasligi mumkin.
///
/// `<Self as Iterator>::__iterator_get_unchecked` quyidagi shartlar bajarilgan taqdirda qo'ng'iroq qilish xavfsiz bo'lishi kerak.
///
/// 1. `0 <= idx` va `idx < self.size()`.
/// 2. Agar `self: !Clone` bo'lsa, u holda `get_unchecked` hech qachon bir xil indeks bilan `self` da bir necha marta chaqirilmaydi.
/// 3. `self.get_unchecked(idx)` chaqirilgandan so'ng, `next_back` faqat ko'pi bilan `self.size() - idx - 1` marta chaqiriladi.
/// 4. `get_unchecked` chaqirilgandan so'ng, `self`-da faqat quyidagi usullar chaqiriladi:
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// Bundan tashqari, ushbu shartlar bajarilishini hisobga olgan holda, quyidagilarga kafolat berish kerak:
///
/// * `size_hint` dan qaytarilgan qiymatni o'zgartirmaydi
/// * Yuqorida sanab o'tilgan usullarni kerakli traits bajarilishini taxmin qilib, `get_unchecked`-ga qo'ng'iroq qilgandan keyin `self`-da qo'ng'iroq qilish xavfsiz bo'lishi kerak.
///
/// * `get_unchecked` raqamiga qo'ng'iroq qilgandan keyin `self` ni tushirish ham xavfsiz bo'lishi kerak.
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // Qulaylik usuli.
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` agar iterator elementini olish yon ta'sirga ega bo'lishi mumkin.
    /// Ichki iteratorlarni hisobga olishni unutmang.
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// `Iterator::__iterator_get_unchecked` singari, lekin kompilyatordan `U: TrustedRandomAccess` ekanligini bilishni talab qilmaydi.
///
///
/// ## Safety
///
/// To'g'ridan-to'g'ri `get_unchecked`-ni chaqiradigan bir xil talablar.
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `Iterator::__iterator_get_unchecked` uchun shartnomani qo'llab-quvvatlashi kerak.
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// Agar `Self: TrustedRandomAccess` bo'lsa, `Iterator::__iterator_get_unchecked(self, index)` raqamiga qo'ng'iroq qilish xavfsiz bo'lishi kerak.
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `Iterator::__iterator_get_unchecked` uchun shartnomani qo'llab-quvvatlashi kerak.
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}