use crate::{iter::FusedIterator, ops::Try};

/// Cheksiz ravishda takrorlanadigan iterator.
///
/// Ushbu `struct` [`Iterator`] da [`cycle`] usuli bilan yaratilgan.
/// Qo'shimcha ma'lumot uchun uning hujjatlariga qarang.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // tsikl iteratori bo'sh yoki cheksizdir
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // joriy iteratorni to'liq takrorlang.
        // bu kerak, chunki `self.orig` bo'lmasa ham `self.iter` bo'sh bo'lishi mumkin
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // to'liq tsiklni bajaring, velosiped iteratorining bo'sh yoki yo'qligini kuzatib boring.
        // cheksiz tsiklni oldini olish uchun bo'sh iterator bo'lsa, biz erta qaytib kelishimiz kerak
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // `fold` bekor qilinmaydi, chunki `fold` `Cycle` uchun juda mantiqiy emas va biz sukut bo'yicha yaxshiroq narsa qila olmaymiz.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}