use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Ushbu trait ushbu sharoitda interator-adapter quvur liniyasida manba bosqichiga o'tish imkoniyatini beradi
/// * iterator manbasi `S` o'zi `SourceIter<Source = S>` ni amalga oshiradi
/// * manba va quvur liniyasi iste'molchisi o'rtasidagi quvur liniyasidagi har bir adapter uchun ushbu trait-ni vakolatli amalga oshirish mavjud.
///
/// Agar manba egasi iterator tuzilmasi bo'lsa (odatda `IntoIter` deb nomlanadi), bu [`FromIterator`] dasturlarini ixtisoslashishi yoki iterator qisman tugagandan so'ng qolgan elementlarni tiklash uchun foydali bo'lishi mumkin.
///
///
/// Amalga oshirish uchun quvur liniyasining eng ichki manbasiga kirishni ta'minlash shart emasligiga e'tibor bering.Vaziyatli oraliq adapter quvur liniyasining bir qismini ishtiyoq bilan baholashi va uning ichki xotirasini manba sifatida ko'rsatishi mumkin.
///
/// trait xavfli emas, chunki dasturchilar qo'shimcha xavfsizlik xususiyatlarini qo'llab-quvvatlashlari kerak.
/// Tafsilotlar uchun [`as_inner`]-ga qarang.
///
/// # Examples
///
/// Qisman iste'mol qilingan manbani olish:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Iterator quvur liniyasining manba bosqichi.
    type Source: Iterator;

    /// Iterator quvur liniyasining manbasini oling.
    ///
    /// # Safety
    ///
    /// Amalga oshirilish dasturlari, agar qo'ng'iroq qiluvchi tomonidan almashtirilmasa, ularning hayoti davomida bir xil o'zgaruvchan ma'lumotni qaytarishi kerak.
    /// Qo'ng'iroq qiluvchilar faqat takrorlanishni to'xtatgandan so'ng ma'lumotni almashtirishlari va manbani chiqargandan so'ng iterator quvur liniyasini tashlashlari mumkin.
    ///
    /// Bu shuni anglatadiki, iterator adapterlari takrorlanish jarayonida o'zgarmas manbaga ishonishi mumkin, ammo ular o'zlarining Drop dasturlarida unga ishonishlari mumkin emas.
    ///
    /// Ushbu usulni tatbiq etish shuni anglatadiki, adapterlar o'z manbalariga faqat xususiy kirish huquqidan voz kechishadi va faqat usul qabul qiluvchilar turlariga asoslangan kafolatlarga ishonishlari mumkin.
    /// Cheklangan kirishning etishmasligi, shuningdek, adapterlar ichki manbalarga kirish imkoniga ega bo'lgan taqdirda ham, manba ochiq API-ni qo'llab-quvvatlashi kerak.
    ///
    /// Qo'ng'iroq qiluvchilar o'z navbatida manbaning ochiq API-ga mos keladigan har qanday holatda bo'lishini kutishlari kerak, chunki u bilan manba o'rtasida o'tirgan adapterlar bir xil kirish huquqiga ega.
    /// Xususan, adapter zarur bo'lgandan ko'ra ko'proq elementlarni iste'mol qilgan bo'lishi mumkin.
    ///
    /// Ushbu talablarning umumiy maqsadi iste'molchiga quvur liniyasidan foydalanishga ruxsat berishdir
    /// * iteratsiya to'xtaganidan keyin manbada nima qolsa
    /// * iste'mol qiluvchi iteratorni rivojlantirish orqali foydalanilmay qolgan xotira
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Asosiy iterator `Result::Ok` qiymatlarini ishlab chiqarguncha chiqishni ishlab chiqaradigan iterator adapteri.
///
///
/// Agar xatolik yuzaga kelsa, iterator to'xtaydi va xato saqlanadi.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Berilgan iteratorni xuddi `Result<T, _>` o'rniga `T` hosil qilganidek ishlang.
/// Har qanday xatolar ichki iteratorni to'xtatadi va umumiy natija xato bo'ladi.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}