/// Uning uzunligini aniq biladigan iterator.
///
/// Ko'pchilik [Iterator`] necha marta takrorlanishini bilmaydi, ammo ba'zilari buni biladi.
/// Agar iterator necha marta takrorlanishini bilsa, ushbu ma'lumotlarga kirish foydali bo'lishi mumkin.
/// Masalan, agar siz orqaga yinelemeyi istasangiz, yaxshi boshlanish qaerda tugashini bilishdir.
///
/// `ExactSizeIterator`-ni amalga oshirishda siz [`Iterator`]-ni ham amalga oshirishingiz kerak.
/// Shunday qilib, [`Iterator::size_hint`]*dasturining bajarilishi* iteratorning aniq hajmini qaytarishi kerak.
///
/// [`len`] usuli standart dasturga ega, shuning uchun siz uni amalga oshirmasligingiz kerak.
/// Biroq, siz odatdagidan ko'ra ko'proq bajarilishini ta'minlay olasiz, shuning uchun uni bekor qilish mantiqan to'g'ri keladi.
///
///
/// Shuni esda tutingki, ushbu trait xavfsiz trait hisoblanadi va shuning uchun qaytarilgan uzunlikning to'g'riligiga *emas* va * kafolat berolmaydi.
/// Bu shuni anglatadiki, `unsafe` kodi ** [`Iterator::size_hint`] to'g'riligiga ishonmasligi kerak.
/// Beqaror va xavfli [`TrustedLen`](super::marker::TrustedLen) trait ushbu qo'shimcha kafolatni beradi.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// // cheklangan diapazon necha marta takrorlanishini aniq biladi
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs]-da biz [`Iterator`]-ni qo'lladik, `Counter`.
/// Buning uchun `ExactSizeIterator`-ni ham qo'llaylik:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Qolgan takroriy sonlarni osongina hisoblashimiz mumkin.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Va endi biz undan foydalanishimiz mumkin!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Yineleyicinin aniq uzunligini qaytaradi.
    ///
    /// Amalga oshirish, iterator [`None`]-ni qaytarishdan oldin, [`Some(T)`] qiymatidan [`Some(T)`] qiymatidan ko'proq marta qaytib kelishini ta'minlaydi.
    ///
    /// Ushbu usul standart dasturga ega, shuning uchun uni to'g'ridan-to'g'ri amalga oshirmaslik kerak.
    /// Ammo, agar siz samaraliroq amalga oshirishni ta'minlasangiz, buni amalga oshirishingiz mumkin.
    /// Misol uchun [trait-level] hujjatlarini ko'ring.
    ///
    /// Ushbu funktsiya [`Iterator::size_hint`] funktsiyasi kabi xavfsizlik kafolatlariga ega.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// // cheklangan diapazon necha marta takrorlanishini aniq biladi
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Ushbu tasdiq haddan tashqari mudofaa xususiyatiga ega, ammo o'zgarmaslikni tekshiradi
        // trait tomonidan kafolatlangan.
        // Agar bu trait rust-ichki bo'lsa, biz debug_assert dan foydalanishimiz mumkin !;assert_eq!barcha Rust foydalanuvchi dasturlarini ham tekshiradi.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Agar iterator bo'sh bo'lsa, `true`-ni qaytaradi.
    ///
    /// Ushbu usul [`ExactSizeIterator::len()`] yordamida standart dasturga ega, shuning uchun uni o'zingiz amalga oshirishingiz shart emas.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}