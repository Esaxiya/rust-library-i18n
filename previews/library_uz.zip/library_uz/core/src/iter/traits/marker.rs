/// Har doim charchaganida `None` ni berishda davom etadigan iterator.
///
/// `None`-ni bir marta qaytarib yuborgan eritilgan iterator-ga qo'ng'iroq qilish yana [`None`]-ni qaytarishga kafolat beradi.
/// Ushbu trait o'zini shunday tutadigan barcha iteratorlar tomonidan amalga oshirilishi kerak, chunki bu [`Iterator::fuse()`] ni optimallashtirishga imkon beradi.
///
///
/// Note: Umuman olganda, `FusedIterator`-ni umumiy chegaralarda ishlatmaslik kerak, agar sizga eritilgan iterator kerak bo'lsa.
/// Buning o'rniga, faqat iteratorda [`Iterator::fuse()`]-ga qo'ng'iroq qilishingiz kerak.
/// Agar iterator allaqachon birlashtirilgan bo'lsa, qo'shimcha [`Fuse`] o'rami no-op bo'ladi va ishlash jazosi yo'q.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Size_hint yordamida aniq uzunlik haqida xabar beruvchi iterator.
///
/// Takrorlovchi o'lcham bo'yicha ishora qiladi, bu erda u aniq (pastki chegara yuqori chegaraga teng) yoki yuqori chegara [`None`] bo'ladi.
///
/// Haqiqiy iterator uzunligi [`usize::MAX`] dan katta bo'lsa, yuqori chegara faqat [`None`] bo'lishi kerak.
/// Bunday holda, pastki chegara [`usize::MAX`] bo'lishi kerak, natijada [`Iterator::size_hint()`] `(usize::MAX, None)` bo'ladi.
///
/// Yineleyicinin o'zi xabar bergan elementlarning sonini ishlab chiqarishi yoki oxirigacha farq qilishi kerak.
///
/// # Safety
///
/// Ushbu trait faqat shartnoma bajarilganda amalga oshirilishi kerak.
/// Ushbu trait iste'molchilari [`Iterator::size_hint()`]’s yuqori chegarasini tekshirishlari kerak.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Ob'ektni berishda uning tagidagi [`SourceIter`] dan kamida bitta elementni olgan bo'lishi kerak bo'lgan iterator.
///
/// Iteratorni rivojlantiradigan har qanday usulni chaqirish, masalan
/// [`next()`] yoki [`try_fold()`], har bir qadam uchun iteratorning asosiy manbasining kamida bitta qiymati ko'chirilganligini va manbaning strukturaviy cheklovlari bunday qo'shilishga yo'l qo'ygan deb hisoblasa, uning o'rniga iterator zanjiri natijasini kiritishni kafolatlaydi.
///
/// Boshqacha qilib aytganda, ushbu trait iterator quvur liniyasini joyida yig'ish mumkinligini ko'rsatadi.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}