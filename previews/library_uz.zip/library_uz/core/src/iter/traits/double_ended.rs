use crate::ops::{ControlFlow, Try};

/// Ikkala uchidan ham elementlarni chiqarishga qodir bo'lgan iterator.
///
/// `DoubleEndedIterator`-ni amalga oshiradigan narsa, [`Iterator`]-ni amalga oshiradigan narsalarga nisbatan bitta qo'shimcha imkoniyatga ega: "Item`s" ni orqa tomondan, shuningdek old tomondan olish qobiliyati.
///
///
/// Shuni ta'kidlash kerakki, oldinga va orqaga bir xil diapazonda ishlaydi va kesib o'tilmaydi: iteratsiya o'rtada uchrashganda tugaydi.
///
/// [`Iterator`] protokoliga o'xshash tarzda, bir marta `DoubleEndedIterator` [`None`] ni [`next_back()`] dan qaytaradi va uni qayta chaqirish [`Some`] ni qaytarib berishi mumkin yoki bo'lmasligi mumkin.
/// [`next()`] va [`next_back()`] bu maqsad uchun almashtirilishi mumkin.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Takrorlovchi uchidan elementni olib tashlaydi va qaytaradi.
    ///
    /// Boshqa elementlar bo'lmaganida `None`-ni qaytaradi.
    ///
    /// [trait-level] hujjatlari qo'shimcha ma'lumotlarni o'z ichiga oladi.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// "DoubleEndedIterator" uslublari tomonidan berilgan elementlar [Iterator`] usullaridan kelib chiqqan holda farq qilishi mumkin:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Orqadan iteratorni `n` elementlari bilan oldinga siljiydi.
    ///
    /// `advance_back_by` bu [`advance_by`] ning teskari versiyasi.Ushbu usul `n` elementlarini [`None`] duch kelguniga qadar [`next_back`]-ni `n` marta chaqirib, orqadan boshlanadigan ishtiyoq bilan o'tadi.
    ///
    /// `advance_back_by(n)` agar iterator `n` elementlari bo'yicha muvaffaqiyatli harakatlansa [`Ok(())`] ni qaytaradi yoki [`None`] duch kelsa [`Err(k)`], bu erda `k`-elementlar tugamasdan oldin takrorlanadigan elementlar soni (ya'ni
    /// iteratorning uzunligi).
    /// `k` har doim `n` dan kam ekanligini unutmang.
    ///
    /// `advance_back_by(0)`-ga qo'ng'iroq qilish hech qanday elementni iste'mol qilmaydi va har doim [`Ok(())`]-ni qaytaradi.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // faqat `&3` o'tkazib yuborildi
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Takrorlovchi oxiridan `n`th elementni qaytaradi.
    ///
    /// Bu aslida [`Iterator::nth()`]-ning teskari versiyasi.
    /// Ko'pgina indekslash operatsiyalari singari, hisoblash noldan boshlanadi, shuning uchun `nth_back(0)` birinchi qiymatni oxiridan, `nth_back(1)` ikkinchisini va boshqalarni qaytaradi.
    ///
    ///
    /// Tugatilgan va qaytarilgan element orasidagi barcha elementlar, shu jumladan qaytarilgan element iste'mol qilinishini unutmang.
    /// Bu shuni anglatadiki, `nth_back(0)`-ni bir xil iteratorda bir necha marta chaqirish turli xil elementlarni qaytaradi.
    ///
    /// `nth_back()` agar `n` yineleyicinin uzunligidan katta yoki teng bo'lsa, [`None`] qaytadi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()`-ga bir necha marta qo'ng'iroq qilish iteratorni orqaga qaytarmaydi:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Agar `n + 1` dan kam element bo'lsa, `None`-ni qaytarish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Bu [`Iterator::try_fold()`]-ning teskari versiyasi: iteratorning orqa qismidan boshlab elementlarni oladi.
    ///
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Qisqa tutashganligi sababli, qolgan elementlar hali ham iterator orqali mavjud.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iterator elementlarini orqadan boshlab yagona, yakuniy qiymatiga tushiradigan iterator usuli.
    ///
    /// Bu [`Iterator::fold()`]-ning teskari versiyasi: iteratorning orqa qismidan boshlab elementlarni oladi.
    ///
    /// `rfold()` ikkita argumentni oladi: dastlabki qiymat va ikkita argument bilan yopilish: 'accumulator' va element.
    /// Yopish akkumulyatorning keyingi takrorlash uchun qiymatini qaytaradi.
    ///
    /// Dastlabki qiymat-bu akkumulyatorning birinchi qo'ng'iroqdagi qiymatidir.
    ///
    /// Ushbu yopilishni iteratorning har bir elementiga qo'llaganingizdan so'ng, `rfold()` akkumulyatorni qaytaradi.
    ///
    /// Ushbu operatsiyani ba'zida 'reduce' yoki 'inject' deb atashadi.
    ///
    /// Katlama, agar sizda biron bir to'plam mavjud bo'lsa va undan bitta qiymat ishlab chiqarishni xohlasangiz foydali bo'ladi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a elementlarining barchasi yig'indisi
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ushbu misol, boshlang'ich qiymatdan boshlab va har bir elementning orqasidan oldigacha davom etadigan qatorni yaratadi:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Orqadan predikatni qondiradigan iterator elementini qidiradi.
    ///
    /// `rfind()` `true` yoki `false` ni qaytaradigan yopilishni oladi.
    /// Ushbu yopilishni oxiridan boshlab iteratorning har bir elementiga taalluqlidir va agar ulardan biri `true` ni qaytarsa, `rfind()` [`Some(element)`] ni qaytaradi.
    /// Agar ularning hammasi `false` ni qaytarsa, u [`None`] ni qaytaradi.
    ///
    /// `rfind()` qisqa tutashuv;boshqacha qilib aytganda, `true` yopilishi bilanoq, u qayta ishlashni to'xtatadi.
    ///
    /// `rfind()` ma'lumotnomani olganligi sababli va ko'plab iteratorlar mos yozuvlar ustida takrorlanadi, bu argument ikki nusxadagi ma'lumot bo'lishi mumkin bo'lgan chalkash vaziyatga olib keladi.
    ///
    /// Ushbu effektni quyidagi misollarda, `&&x` yordamida ko'rishingiz mumkin.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Birinchi `true`-da to'xtash:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // biz hali ham `iter` dan foydalanishimiz mumkin, chunki ko'proq elementlar mavjud.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}