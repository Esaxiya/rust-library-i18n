/// [`Iterator`]-dan konversiya.
///
/// `FromIterator`-ni turga tatbiq etish orqali siz uni iteratordan qanday yaratilishini aniqlaysiz.
/// Bu ba'zi bir to'plamni tavsiflaydigan turlar uchun keng tarqalgan.
///
/// [`FromIterator::from_iter()`] kamdan-kam hollarda aniq nomlanadi va uning o'rniga [`Iterator::collect()`] usuli bilan ishlatiladi.
///
/// Ko'proq misollar uchun [`Iterator::collect()`]'s hujjatlariga qarang.
///
/// Shuningdek qarang: [`IntoIterator`].
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` ni bilvosita ishlatish uchun [`Iterator::collect()`] dan foydalanish:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Sizning turingiz uchun `FromIterator`-ni amalga oshirish:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Namuna to'plami, bu shunchaki Vec ustiga o'ralgan narsa<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Keling, unga bir nechta usullarni beraylik, shunda biz uni yaratamiz va unga narsalar qo'shamiz.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // va biz FromIterator dasturini amalga oshiramiz
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Endi biz yangi iterator qila olamiz ...
/// let iter = (0..5).into_iter();
///
/// // ... va undan MyCollection yarating
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // asarlarni ham to'plang!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Takrorlovchi tomonidan qiymat hosil qiladi.
    ///
    /// Qo'shimcha ma'lumot uchun [module-level documentation]-ga qarang.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`]-ga o'tish.
///
/// Turi uchun `IntoIterator`-ni qo'llash orqali siz uni qanday qilib iteratorga aylantirilishini aniqlaysiz.
/// Bu ba'zi bir to'plamni tavsiflaydigan turlar uchun keng tarqalgan.
///
/// `IntoIterator` ni amalga oshirishning bir foydasi shundaki, sizning turingiz [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) bo'ladi.
///
///
/// Shuningdek qarang: [`FromIterator`].
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Sizning turingiz uchun `IntoIterator`-ni amalga oshirish:
///
/// ```
/// // Namuna to'plami, bu shunchaki Vec ustiga o'ralgan narsa<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Keling, unga bir nechta usullarni beraylik, shunda biz uni yaratamiz va unga narsalar qo'shamiz.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // va biz IntoIterator dasturini amalga oshiramiz
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Endi biz yangi to'plamni yaratishimiz mumkin ...
/// let mut c = MyCollection::new();
///
/// // ... unga ba'zi narsalarni qo'shing ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... va keyin uni Iteratorga aylantiring:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` dan trait bound sifatida foydalanish odatiy holdir.Bu kiritishni yig'ish turini o'zgartirishga imkon beradi, agar u hali ham iterator bo'lsa.
/// Qo'shimcha chegaralarni cheklash orqali belgilash mumkin
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Qayta takrorlanadigan elementlarning turi.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Buni qaysi iteratorga aylantirmoqdamiz?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Qiymatdan iterator yaratadi.
    ///
    /// Qo'shimcha ma'lumot uchun [module-level documentation]-ga qarang.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// To'plamni iterator mazmuni bilan kengaytiring.
///
/// Iteratorlar bir qator qiymatlarni hosil qiladi, shuningdek to'plamlarni bir qator qiymatlar deb hisoblash mumkin.
/// `Extend` trait ushbu bo'shliqni ko'prik bilan to'ldiradi, shu bilan ushbu iterator tarkibiga kiritilgan to'plamni kengaytirishga imkon beradi.
/// To'plamni allaqachon mavjud bo'lgan kalit bilan kengaytirganda, ushbu yozuv yangilanadi yoki teng kalitlarga ega bo'lgan bir nechta yozuvlarga ruxsat berilgan to'plamlarda, bu yozuv kiritiladi.
///
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// // Stringni ba'zi belgilar bilan kengaytirishingiz mumkin:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend`-ni amalga oshirish:
///
/// ```
/// // Namuna to'plami, bu shunchaki Vec ustiga o'ralgan narsa<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Keling, unga bir nechta usullarni beraylik, shunda biz uni yaratamiz va unga narsalar qo'shamiz.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection i32s ro'yxatiga ega bo'lgani uchun biz i32 uchun Extend dasturini amalga oshiramiz
/// impl Extend<i32> for MyCollection {
///
///     // Bu aniq turdagi imzo bilan biroz osonroq: biz i32s beradigan Iteratorga aylanadigan har qanday narsaga kengaytmani chaqira olamiz.
///     // MyCollection-ga qo'yish uchun bizga i32 kerak.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Amalga oshirish juda oson: iterator orqali aylanib chiqing va har bir elementni o'zimizga add().
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // to'plamimizni yana uchta raqam bilan kengaytiraylik
/// c.extend(vec![1, 2, 3]);
///
/// // biz ushbu elementlarni oxirigacha qo'shdik
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// To'plamni iterator mazmuni bilan kengaytiradi.
    ///
    /// Ushbu trait uchun talab qilinadigan yagona usul bo'lgani uchun, [trait-level] hujjatlari qo'shimcha ma'lumotlarni o'z ichiga oladi.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// // Stringni ba'zi belgilar bilan kengaytirishingiz mumkin:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// To'liq bitta element bilan to'plamni kengaytiradi.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Berilgan qo'shimcha elementlar uchun to'plamdagi zaxira hajmi.
    ///
    /// Standart dastur hech narsa qilmaydi.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}