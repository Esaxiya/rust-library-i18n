use crate::fmt;

/// Har bir iteratsiya `F: FnMut() -> Option<T>` yopilishini chaqiradigan yangi iteratorni yaratadi.
///
/// Bu maxsus turdagi yaratish va [`Iterator`] trait-ni amalga oshirishning batafsil sintaksisini ishlatmasdan har qanday xatti-harakatlar bilan maxsus iterator yaratishga imkon beradi.
///
/// Shuni esda tutingki, `FromFn` iteratori yopilish harakati haqida taxminlar qilmaydi va shuning uchun konservativ ravishda [`FusedIterator`] ni amalga oshirmaydi yoki [`Iterator::size_hint()`]-ni standart `(0, None)`-dan bekor qiladi.
///
///
/// Yopish holatni takrorlash holatini kuzatish uchun tortishish va uning atrof-muhitidan foydalanishi mumkin.Yineleyicinin qanday ishlatilishiga qarab, bu yopilishida [`move`] kalit so'zini ko'rsatishni talab qilishi mumkin.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Keling, [module-level documentation]-dan hisoblagich iteratorini qayta bajaramiz:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Bizning sonimizni ko'paytiring.Shuning uchun biz noldan boshladik.
///     count += 1;
///
///     // Hisoblashni tugatgan-qilmaganligimizni tekshiring.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Har bir takrorlash taqdim etilgan yopilishni `F: FnMut() -> Option<T>` deb ataydigan iterator.
///
/// Ushbu `struct` [`iter::from_fn()`] funktsiyasi tomonidan yaratilgan.
/// Qo'shimcha ma'lumot uchun uning hujjatlariga qarang.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}