use crate::iter::{FusedIterator, TrustedLen};

/// Taqdim etilgan yopilishni taklif qilish orqali dangasa bir marta aniq qiymat hosil qiladigan iterator yaratadi.
///
/// Bu odatda bitta qiymat generatorini [`chain()`] boshqa takrorlanish turlariga moslashtirish uchun ishlatiladi.
/// Ehtimol, sizda deyarli hamma narsani qamrab oladigan iterator bor, ammo sizga qo'shimcha maxsus ish kerak.
/// Ehtimol, sizda iteratorlarda ishlaydigan funktsiyangiz bor, lekin siz faqat bitta qiymatni qayta ishlashingiz kerak.
///
/// [`once()`]-dan farqli o'laroq, bu funktsiya talabga binoan dangasa qiymat hosil qiladi.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::iter;
///
/// // bittasi eng yolg'iz raqam
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // faqat bittasi, biz faqat shu narsani olamiz
/// assert_eq!(None, one.next());
/// ```
///
/// Boshqa iterator bilan birgalikda zanjirband qilish.
/// Aytaylik, biz `.foo` katalogining har bir faylida takrorlashni xohlaymiz, shuningdek konfiguratsiya fayli,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // biz DirEntry-s iteratoridan PathBufs iteratoriga o'tishimiz kerak, shuning uchun biz xaritadan foydalanamiz
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // Endi bizning konfiguratsiya fayli uchun bizning iteratorimiz
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // ikkita iteratorni bitta katta iteratorga zanjirlang
/// let files = dirs.chain(config);
///
/// // bu bizga .foo hamda .foorc dagi barcha fayllarni beradi
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Taqdim etilgan `F: FnOnce() -> A` yopilishini qo'llash orqali `A` tipidagi bitta elementni beradigan iterator.
///
///
/// Ushbu `struct` [`once_with()`] funktsiyasi tomonidan yaratilgan.
/// Qo'shimcha ma'lumot uchun uning hujjatlariga qarang.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}