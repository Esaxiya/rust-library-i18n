use crate::iter::{FusedIterator, TrustedLen};

/// Bitta elementni cheksiz takrorlaydigan yangi iterator yaratadi.
///
/// `repeat()` funktsiyasi bitta qiymatni qayta-qayta takrorlaydi.
///
/// `repeat()` kabi cheksiz iteratorlar ko'pincha ularni chekli qilish uchun [`Iterator::take()`] kabi adapterlarda ishlatiladi.
///
/// Agar sizga kerak bo'lgan iteratorning element turi `Clone`-ni bajarmasa yoki takrorlangan elementni xotirada saqlashni xohlamasangiz, uning o'rniga [`repeat_with()`] funktsiyasidan foydalanishingiz mumkin.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::iter;
///
/// // to'rtinchi raqam 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, hali to'rtta
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] bilan cheklangan o'tish:
///
/// ```
/// use std::iter;
///
/// // bu oxirgi misol juda ko'p to'rtliklar edi.Kelinglar, faqat to'rttasi bor.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... va endi ishimiz tugadi
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Elementni cheksiz takrorlaydigan takrorlovchi.
///
/// Ushbu `struct` [`repeat()`] funktsiyasi tomonidan yaratilgan.Qo'shimcha ma'lumot uchun uning hujjatlariga qarang.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}