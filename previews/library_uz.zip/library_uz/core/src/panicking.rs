//! Libcore uchun Panic-ni qo'llab-quvvatlash
//!
//! Asosiy kutubxona vahima tushunchasini aniqlay olmaydi, ammo vahima *e'lon qiladi*.
//! Bu shuni anglatadiki, libcore ichidagi funktsiyalar panic-ga ruxsat berilgan, ammo yuqoridagi crate foydali bo'lishi uchun libcore-dan foydalanish uchun vahima aniqlanishi kerak.
//! Vahima uchun joriy interfeys:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Ushbu ta'rif har qanday umumiy xabar bilan vahima qo'zg'ashga imkon beradi, ammo `Box<Any>` qiymati bilan ishlamaslikka yo'l qo'ymaydi.
//! (`PanicInfo` faqat `&(dyn Any + Send)`-ni o'z ichiga oladi, buning uchun biz "PanicInfo: : internal_constructor" dummy qiymatini to'ldiramiz.) Buning sababi libcore-ni ajratishga ruxsat berilmaganligi.
//!
//!
//! Ushbu modulda vahima qo'zg'atadigan bir nechta boshqa funktsiyalar mavjud, ammo bular faqat kompilyator uchun kerakli til elementlari.Barcha panics ushbu funktsiya orqali amalga oshiriladi.
//! H00X atributi orqali haqiqiy belgi e'lon qilinadi.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Hech qanday formatlash ishlatilmaganda libcore-ning `panic!` so'lini amalga oshirish.
#[cold]
// qo'ng'iroq saytlarida iloji boricha kod shishishini oldini olish uchun panic_immediate_abort bo'lmasa, hech qachon ichkariga kirmang
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // toshib ketishda va boshqa `Assert` MIR terminatorlarida panic uchun codegen kerak
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Qo'shimcha xarajatlarni kamaytirish uchun format_args! ("{}", Expr) o'rniga Arguments::new_v1 foydalaning.
    // Format_args!makrosi str-ning Display trait-dan expr yozish uchun foydalanadi, bu Formatter::pad-ni chaqiradi, bu satrlarni qisqartirish va to'ldirishni o'z ichiga olishi kerak (garchi bu erda ishlatilmasa ham).
    //
    // Arguments::new_v1-dan foydalanish kompilyatorga Formatter::pad-ni chiqadigan ikkilikdan chiqarib, bir necha kilobaytgacha tejashga imkon berishi mumkin.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // const-baholangan panics uchun zarur
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice-ga kirish uchun panic uchun codegen kerak
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Formatlashda libcore-ning `panic!` makrosining asosiy qo'llanilishidan foydalaniladi.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Izoh Ushbu funktsiya hech qachon FFI chegarasini kesib o'tmaydi;bu 0Rust-Rust chaqiruvi bo'lib, u `#[panic_handler]` funktsiyasini hal qiladi.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // XAVFSIZLIK: `panic_impl` xavfsiz Rust kodida aniqlangan va shuning uchun qo'ng'iroq qilish xavfsizdir.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` va `assert_ne!` makrolari uchun ichki funktsiya
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}