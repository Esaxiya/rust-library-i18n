//! Ushbu modul `Any` trait-ni amalga oshiradi, bu esa har qanday `'static` turini ish vaqtini aks ettirish orqali dinamik terishga imkon beradi.
//!
//! `Any` o'zi `TypeId` olish uchun ishlatilishi mumkin va trait ob'ekti sifatida ishlatilganda ko'proq xususiyatlarga ega.
//! `&dyn Any` (qarzga olingan trait ob'ekti) sifatida u `is` va `downcast_ref` usullariga ega, tarkibida berilgan qiymat berilganligini tekshiradi va ichki qiymatga tip sifatida murojaat qiladi.
//! `&mut dyn Any` sifatida ichki qiymatga o'zgaruvchan mos yozuvlar olish uchun `downcast_mut` usuli ham mavjud.
//! `Box<dyn Any>` `Box<T>` ga o'tkazishga harakat qiladigan `downcast` usulini qo'shadi.
//! To'liq ma'lumot uchun [`Box`] hujjatlariga qarang.
//!
//! Shuni esda tutingki, `&dyn Any` qiymati belgilangan beton turiga tegishli ekanligini tekshirish bilan cheklanadi va uning turi trait ni amalga oshiradimi-yo'qligini tekshirish uchun ishlatilmaydi.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Aqlli ko'rsatkichlar va `dyn Any`
//!
//! `Any`-ni trait ob'ekti sifatida ishlatishda, ayniqsa `Box<dyn Any>` yoki `Arc<dyn Any>` kabi turlarda yodda tutish kerak bo'lgan bitta xatti-harakatlar, shunchaki `.type_id()` qiymatiga qo'ng'iroq qilish *trait ob'ekti emas, balki* konteyner * ning `TypeId`-ni hosil qiladi.
//!
//! Buning o'rniga aqlli ko'rsatgichni `&dyn Any` ga o'zgartirib, ob'ektning `TypeId` qiymatini qaytaradi.
//! Masalan:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Siz buni xohlashingiz mumkin:
//! let actual_id = (&*boxed).type_id();
//! // ... bundan:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Funktsiyaga berilgan qiymatdan chiqishni istagan vaziyatni ko'rib chiqing.
//! Biz disk raskadrovka moslamalari ustida ishlayotganimizni bilamiz, ammo uning aniq turini bilmaymiz.Biz ma'lum turlarga alohida muomala qilmoqchimiz: bu holda ularning qiymatidan oldin String qiymatlari uzunligini chop etish.
//! Biz kompilyatsiya vaqtida qiymatimizning aniq turini bilmaymiz, shuning uchun buning o'rniga ish vaqti aksini ishlatishimiz kerak.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Tuzatishni amalga oshiradigan har qanday turdagi logger funktsiyasi.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Bizning qiymatimizni `String` ga o'tkazishga harakat qiling.
//!     // Muvaffaqiyatli bo'lsa, biz String` uzunligini va uning qiymatini chiqarishni xohlaymiz.
//!     // Agar yo'q bo'lsa, bu boshqa xil: shunchaki bezaksiz chop eting.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ushbu funktsiya u bilan ishlashdan oldin o'z parametrini o'chirib qo'yishni xohlaydi.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... boshqa ishlarni bajaring
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Har qanday trait
///////////////////////////////////////////////////////////////////////////////

/// Dinamik yozishni taqlid qilish uchun trait.
///
/// Ko'pgina turlari `Any`-ni qo'llaydi.Biroq, "statik" bo'lmagan ma'lumotni o'z ichiga olgan har qanday turdagi ma'lumot yo'q.
/// Qo'shimcha ma'lumot uchun [module-level documentation][mod]-ga qarang.
///
/// [mod]: crate::any
// Ushbu trait xavfli emas, ammo biz uning xavfsizligi kodida (masalan, `downcast`) yagona impl-ning `type_id` funktsiyasining o'ziga xos xususiyatlariga tayanamiz.Odatda, bu muammo bo'lishi mumkin, ammo `Any` ning yagona ma'nosi adyolni amalga oshirish bo'lgani uchun, boshqa hech qanday kod `Any` ni amalga oshira olmaydi.
//
// Biz ushbu trait-ni xavfli qilib qo'yishimiz mumkin edi-bu buzilishga olib kelmaydi, chunki biz barcha dasturlarni nazorat qilamiz-lekin biz bu ikkalasini ham kerak emas deb hisoblaymiz va foydalanuvchilarni xavfli traits va xavfli usullarni ajratib turishi mumkin (ya'ni, `type_id`-ga qo'ng'iroq qilish hali ham xavfsiz bo'lar edi, lekin biz buni hujjatlarda ko'rsatishni xohlaymiz).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` ning `TypeId`-ni oladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Har qanday trait moslamalarini kengaytirish usullari.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Masalan, ipni birlashtirish natijasi bosib chiqarilishi va shu sababli `unwrap` bilan ishlatilishini ta'minlang.
// Agar jo'natish upcasting bilan ishlasa, oxir-oqibat endi kerak bo'lmaydi.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Belgilangan turi `T` bilan bir xil bo'lsa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Ushbu funktsiya yaratilgan `TypeId` turini oling.
        let t = TypeId::of::<T>();

        // 0trait ob'ekti (`self`) turidagi `TypeId` ni oling.
        let concrete = self.type_id();

        // Ikkala TypeId-ni tenglik bo'yicha solishtiring.
        t == concrete
    }

    /// `T` tipidagi qutidagi qiymatga, agar u bo'lmasa `None` ga tegishli ma'lumotni qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // XAVFSIZLIK: to'g'ri turga ishora qilayotganimizni tekshirib ko'ring va biz unga ishonishimiz mumkin
            // xotira xavfsizligini tekshiradi, chunki biz har qanday narsani har qanday dasturni amalga oshirdik;boshqa impllar mavjud bo'lishi mumkin emas, chunki ular bizning imlimizga zid keladi.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// `T` tipidagi qutidagi qiymatga tegishli o'zgaruvchan ma'lumotni qaytaradi, agar u bo'lmasa `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // XAVFSIZLIK: to'g'ri turga ishora qilayotganimizni tekshirib ko'ring va biz unga ishonishimiz mumkin
            // xotira xavfsizligini tekshiradi, chunki biz har qanday narsani har qanday dasturni amalga oshirdik;boshqa impllar mavjud bo'lishi mumkin emas, chunki ular bizning imlimizga zid keladi.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` turida aniqlangan usulga yo'naltiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` turida aniqlangan usulga yo'naltiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` turida aniqlangan usulga yo'naltiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` turida aniqlangan usulga yo'naltiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` turida aniqlangan usulga yo'naltiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` turida aniqlangan usulga yo'naltiriladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID va uning usullari
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` turi uchun dunyo miqyosida noyob identifikatorni aks ettiradi.
///
/// Har bir `TypeId` shaffof bo'lmagan ob'ekt bo'lib, u ichidagi narsalarni tekshirishga imkon bermaydi, lekin klonlash, taqqoslash, bosib chiqarish va namoyish qilish kabi asosiy operatsiyalarga imkon beradi.
///
///
/// `TypeId` hozirda faqat `'static` ga tegishli bo'lgan turlari uchun mavjud, ammo bu cheklov future da o'chirilishi mumkin.
///
/// `TypeId` `Hash`, `PartialOrd` va `Ord` ni amalga oshirar ekan, shuni ta'kidlash kerakki, xeshlar va buyurtma Rust versiyalari orasida o'zgarib turadi.
/// O'zingizning kodingiz ichida ularga ishonishdan ehtiyot bo'ling!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Ushbu umumiy funktsiya yaratilgan `TypeId` turini qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Turning nomini mag'lubiyat bo'lagi sifatida qaytaradi.
///
/// # Note
///
/// Bu diagnostik maqsadlarda foydalanish uchun mo'ljallangan.
/// Qaytarilgan mag'lubiyatning aniq mazmuni va formati aniqlanmagan, faqat turning eng yaxshi tavsifi.
/// Masalan, `type_name::<Option<String>>()` qaytarishi mumkin bo'lgan qatorlar orasida `"Option<String>"` va `"std::option::Option<std::string::String>"` mavjud.
///
///
/// Qaytgan mag'lubiyat turning o'ziga xos identifikatori deb qaralmasligi kerak, chunki bir nechta turlar bitta turdagi nomga mos kelishi mumkin.
/// Xuddi shunday, qaytarilgan satrda turning barcha qismlari paydo bo'lishiga kafolat yo'q: masalan, umr bo'yi aniqlovchilar hozircha kiritilmagan.
/// Bundan tashqari, chiqish kompilyator versiyalari orasida o'zgarishi mumkin.
///
/// Amaldagi dastur kompilyator diagnostikasi va debuginfo bilan bir xil infratuzilmani ishlatadi, ammo bunga kafolat berilmaydi.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Belgilangan qiymat turining nomini mag'lubiyat bo'lagi sifatida qaytaradi.
/// Bu `type_name::<T>()` bilan bir xil, ammo o'zgaruvchining turi osonlikcha mavjud bo'lmagan joyda foydalanish mumkin.
///
/// # Note
///
/// Bu diagnostik maqsadlarda foydalanish uchun mo'ljallangan.Ipning aniq mazmuni va formati aniqlanmagan, faqat turning eng yaxshi tavsifi.
/// Masalan, `type_name_of_val::<Option<String>>(None)` `"Option<String>"` yoki `"std::option::Option<std::string::String>"` ni qaytarishi mumkin, ammo `"foobar"` emas.
///
/// Bundan tashqari, chiqish kompilyator versiyalari orasida o'zgarishi mumkin.
///
/// Ushbu funktsiya trait moslamalarini hal qilmaydi, ya'ni `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` ni qaytarishi mumkin, ammo `"u32"` emas.
///
/// Turning nomi turning noyob identifikatori deb qaralmasligi kerak;
/// bir nechta turdagi nomlar bir xil turdagi bo'lishi mumkin.
///
/// Amaldagi dastur kompilyator diagnostikasi va debuginfo bilan bir xil infratuzilmani ishlatadi, ammo bunga kafolat berilmaydi.
///
/// # Examples
///
/// Odatiy tamsayı va suzuvchi turlarini chop etadi.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}