//! Buyurtma berish va taqqoslash uchun funktsionallik.
//!
//! Ushbu modulda buyurtma berish va qiymatlarni taqqoslash uchun turli xil vositalar mavjud.Qisqa bayoni; yakunida:
//!
//! * [`Eq`] va [`PartialEq`]-bu traits, bu mos ravishda qiymatlar orasidagi to'liq va qisman tenglikni aniqlashga imkon beradi.
//! Ularni amalga oshirish `==` va `!=` operatorlarini ortiqcha yuklaydi.
//! * [`Ord`] va [`PartialOrd`] traits bo'lib, ular mos ravishda qiymatlar orasidagi to'liq va qisman buyurtmalarni belgilashga imkon beradi.
//!
//! Ularni amalga oshirish `<`, `<=`, `>` va `>=` operatorlarini ortiqcha yuklaydi.
//! * [`Ordering`] [`Ord`] va [`PartialOrd`] asosiy funktsiyalari tomonidan qaytarilgan enum bo'lib, buyurtma berishni tavsiflaydi.
//! * [`Reverse`] buyurtmani osongina teskari yo'naltirishga imkon beradigan strukturadir.
//! * [`max`] va [`min`]-bu [`Ord`] dan kelib chiqadigan va ikkita qiymatning maksimal yoki minimal qiymatini topishga imkon beradigan funktsiyalar.
//!
//! Qo'shimcha ma'lumot olish uchun ro'yxatdagi har bir elementning tegishli hujjatlariga qarang.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) bo'lgan tenglikni taqqoslash uchun Trait.
///
/// Ushbu trait to'liq ekvivalentlik munosabatlariga ega bo'lmagan turlar uchun qisman tenglikka imkon beradi.
/// Masalan, suzuvchi nuqta raqamlarida `NaN != NaN`, suzuvchi nuqta turlari `PartialEq` ni amalga oshiradi, ammo [`trait@Eq`] emas.
///
/// Rasmiy ravishda tenglik (`A`, `B`, `C` turdagi barcha `a`, `b`, `c` uchun) bo'lishi kerak:
///
/// - **Nosimmetrik**: agar `A: PartialEq<B>` va `B: PartialEq<A>` bo'lsa, u holda **`a==b`` b==a`** ni anglatadi;va
///
/// - **o'tish davri**: agar `A: PartialEq<B>` va `B: PartialEq<C>` va `A:
///   Qisman tenglama<C>`, keyin **` a==b`va `b == c` a==c`** ni anglatadi.
///
/// Shuni esda tutingki, `B: PartialEq<A>` (symmetric) va `A: PartialEq<C>` (transitive) impllari majburiy ravishda mavjud emas, ammo bu talablar ular mavjud bo'lganda qo'llaniladi.
///
/// ## Derivable
///
/// Ushbu trait dan `#[derive]` bilan foydalanish mumkin.Agar "derive`d"tuzilishda, barcha maydonlar teng bo'lsa, ikkita misol teng bo'ladi, agar biron bir maydon teng bo'lmasa-teng bo'lmaydi.Enumlarda"derive`d" bo'lsa, har bir variant o'ziga teng va boshqa variantlarga teng emas.
///
/// ## `PartialEq` ni qanday amalga oshirishim mumkin?
///
/// `PartialEq` faqat [`eq`] usulini amalga oshirishni talab qiladi;[`ne`] sukut bo'yicha unga ko'ra belgilanadi.[`ne`]*ning har qanday qo'lda bajarilishi*[`eq`] ning [`ne`] ning teskari teskari ekanligi qoidalariga rioya qilishi kerak;ya'ni X003 bo'lsa va faqat `!(a == b)` bo'lsa.
///
/// `PartialEq`, [`PartialOrd`] va [`Ord`]*dasturlari* bir-biriga mos kelishi kerak.traits ning bir qismini keltirib, boshqalarini qo'lda amalga oshirish orqali ularni tasodifan kelishmovchilikka olib kelish oson.
///
/// Ikki kitob bir xil kitob deb hisoblanadigan domen uchun misol, agar ularning formatlari turlicha bo'lsa ham, agar ularning ISBN mos bo'lsa:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Ikki xil turni qanday taqqoslash mumkin?
///
/// Siz solishtirishingiz mumkin bo'lgan tur "PartialEq" ning parametri tomonidan boshqariladi.
/// Masalan, avvalgi kodimizni biroz o'zgartiraylik:
///
/// ```
/// // Qabul qiluvchi vositalar<BookFormat>==<BookFormat>taqqoslashlar
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Amalga oshirish<Book>==<BookFormat>taqqoslashlar
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Amalga oshirish<BookFormat>==<Book>taqqoslashlar
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book`-ni `impl PartialEq<BookFormat> for Book`-ga o'zgartirib, biz "BookFormat"-ni "Book`s" bilan taqqoslashga imkon beramiz.
///
/// Strukturaning ba'zi maydonlarini e'tiborsiz qoldiradigan yuqoridagi kabi taqqoslash xavfli bo'lishi mumkin.Bu bemalol qisman ekvivalentlik munosabatlari talablarini kutilmagan ravishda buzilishiga olib kelishi mumkin.
/// Masalan, agar biz `BookFormat` uchun yuqoridagi dasturni `BookFormat` uchun ushlab tursak va `Book` uchun `PartialEq<Book>` dasturini qo'shsak (yoki `#[derive]` orqali yoki birinchi misoldan qo'lda amalga oshirish orqali) bo'lsa, natija tranzitivlikni buzadi:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Ushbu usul `self` va `other` qiymatlarining tengligini tekshiradi va `==` tomonidan qo'llaniladi.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Ushbu usul `!=` uchun sinovlarni o'tkazadi.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq` implini yaratadigan so'lni oling.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) bo'lgan tenglikni taqqoslash uchun Trait.
///
/// Bu shuni anglatadiki, `a == b` va `a != b` qat'iy teskari bo'lishdan tashqari, tenglik (barcha `a`, `b` va `c` uchun) bo'lishi kerak:
///
/// - reflexive: `a == a`;
/// - nosimmetrik: `a == b` `b == a` ni nazarda tutadi;va
/// - o'tish: `a == b` va `b == c` `a == c` ni nazarda tutadi.
///
/// Ushbu xususiyat kompilyator tomonidan tekshirilishi mumkin emas va shuning uchun `Eq` [`PartialEq`] ni nazarda tutadi va qo'shimcha usullarga ega emas.
///
/// ## Derivable
///
/// Ushbu trait dan `#[derive]` bilan foydalanish mumkin.
/// Agar "derive`d" bo'lsa, chunki `Eq` da qo'shimcha usullar mavjud emas, bu faqat kompilyatorga bu qisman ekvivalentlik munosabati emas, balki ekvivalentlik munosabati ekanligi haqida ma'lumot beradi.
///
/// E'tibor bering, `derive` strategiyasida barcha maydonlar `Eq` bo'lishi kerak, bu har doim ham istalmaydi.
///
/// ## `Eq` ni qanday amalga oshirishim mumkin?
///
/// Agar siz `derive` strategiyasidan foydalana olmasangiz, unda sizning usulingiz bo'lmagan `Eq`-ni bajarishini ko'rsating:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // bu usul faqat#[deriving] tomonidan har bir turdagi komponentning o'zi [[hosil]] ni amalga oshirishini tasdiqlash uchun ishlatiladi, hozirgi derivatsiya infratuzilmasi ushbu tasdiqni ushbu trait usulidan foydalanmasdan bajarishni deyarli imkonsiz deb biladi.
    //
    //
    // Bu hech qachon qo'l bilan amalga oshirilmasligi kerak.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq` implini yaratadigan so'lni oling.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: bu struct faqat#[derive] to tomonidan ishlatiladi
// Turning har bir komponenti tenglamani bajarishini tasdiqlang.
//
// Ushbu tizim hech qachon foydalanuvchi kodida ko'rinmasligi kerak.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering`-bu ikki qiymat o'rtasidagi taqqoslash natijasidir.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Taqqoslangan qiymat boshqasidan kichik bo'lgan buyurtma.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Qiyoslangan qiymat boshqasiga teng bo'lgan tartib.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Taqqoslangan qiymat boshqasidan kattaroq bo'lgan buyurtma.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Agar buyurtma `Equal` varianti bo'lsa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Agar buyurtma `Equal` varianti bo'lmasa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Agar buyurtma `Less` variant bo'lsa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Agar buyurtma `Greater` varianti bo'lsa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Agar buyurtma `Less` yoki `Equal` varianti bo'lsa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Agar buyurtma `Greater` yoki `Equal` varianti bo'lsa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering`-ni o'zgartiradi.
    ///
    /// * `Less` `Greater` ga aylanadi.
    /// * `Greater` `Less` ga aylanadi.
    /// * `Equal` `Equal` ga aylanadi.
    ///
    /// # Examples
    ///
    /// Asosiy xatti-harakatlar:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Ushbu usul taqqoslashni qaytarish uchun ishlatilishi mumkin:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // massivni kattadan kichikgacha saralash.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Ikkita buyurtmani zanjirlar.
    ///
    /// `Equal` bo'lmaganida `self`-ni qaytaradi.Aks holda `other` qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Berilgan funktsiya bilan tartiblashni zanjirlaydi.
    ///
    /// `Equal` bo'lmaganida `self`-ni qaytaradi.
    /// Aks holda `f` ga qo'ng'iroq qiladi va natijani qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Orqaga buyurtma berish uchun yordamchi tuzilma.
///
/// Ushbu struct [`Vec::sort_by_key`] kabi funktsiyalarda ishlatilishi mumkin bo'lgan yordamchidir va kalitning bir qismini teskari tartiblash uchun ishlatilishi mumkin.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// [total order](https://en.wikipedia.org/wiki/Total_order) hosil qiluvchi turlar uchun Trait.
///
/// Buyurtma bu umumiy buyurtma, agar u (barcha `a`, `b` va `c` uchun) bo'lsa:
///
/// - jami va assimetrik: to'liq `a < b`, `a == b` yoki `a > b` bittasi to'g'ri;va
/// - o'tish, `a < b` va `b < c` `a < c` ni nazarda tutadi.Xuddi shu narsa `==` va `>` uchun ham amal qilishi kerak.
///
/// ## Derivable
///
/// Ushbu trait dan `#[derive]` bilan foydalanish mumkin.
/// Strukturalar bo'yicha "derive`d" bo'lsa, u struktura a'zolarining yuqoridan pastga deklaratsiya tartibiga asoslanib [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) tartibini ishlab chiqaradi.
///
/// Enumlarda `derive`d bo'lsa, variantlar yuqoridan pastgacha diskriminantlik tartibiga ko'ra tartiblanadi.
///
/// ## Leksikografik taqqoslash
///
/// Leksikografik taqqoslash quyidagi xususiyatlarga ega operatsiya:
///  - Ikki ketma-ketlik elementlar bilan taqqoslanadi.
///  - Birinchi mos kelmaydigan element qaysi ketma-ketlikni leksikografik jihatdan boshqasidan kam yoki kattaroqligini aniqlaydi.
///  - Agar bitta ketma-ketlik boshqa qo'shimchaning prefiksi bo'lsa, qisqacha ketma-ketlik leksikografik jihatdan boshqasiga qaraganda kamroq bo'ladi.
///  - Agar ikkita ketma-ketlik teng elementlarga ega bo'lsa va bir xil uzunlikda bo'lsa, unda ketma-ketliklar leksikografik jihatdan tengdir.
///  - Bo'sh ketma-ketlik leksikografik jihatdan har qanday bo'sh bo'lmagan ketma-ketlikdan kam.
///  - Ikki bo'sh ketma-ketlik leksikografik jihatdan teng.
///
/// ## `Ord` ni qanday amalga oshirishim mumkin?
///
/// `Ord` turi [`PartialOrd`] va [`Eq`] ([`PartialEq`] talab qilinadi) bo'lishini talab qiladi.
///
/// Keyin [`cmp`] uchun dasturni belgilashingiz kerak.[`cmp`]-ni sizning turingizdagi maydonlarda ishlatish foydali bo'lishi mumkin.
///
/// [`PartialEq`], [`PartialOrd`] va `Ord`*dasturlari* bir-biriga mos kelishi kerak.
/// Ya'ni, `a.cmp(b) == Ordering::Equal`, agar `a == b` va `Some(a.cmp(b)) == a.partial_cmp(b)` barcha `a` va `b` uchun bo'lsa.
/// traits ning bir qismini keltirib, boshqalarini qo'lda amalga oshirish orqali ularni tasodifan kelishmovchilikka olib kelish oson.
///
/// `id` va `name` ni hisobga olmagan holda odamlarni faqat bo'yi bo'yicha saralashni istagan misol:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Ushbu usul `self` va `other` o'rtasida [`Ordering`] qiymatini qaytaradi.
    ///
    /// An'anaga ko'ra, `self.cmp(&other)`, agar rost bo'lsa, `self <operator> other` ifodasiga mos keladigan buyurtmani qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Ikkala maksimal qiymatni taqqoslaydi va qaytaradi.
    ///
    /// Agar taqqoslash ularning tengligini aniqlasa, ikkinchi argumentni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Minimal ikkita qiymatni taqqoslaydi va qaytaradi.
    ///
    /// Agar taqqoslash ularning tengligini aniqlasa, birinchi argumentni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Qiymatni ma'lum bir oraliq bilan cheklang.
    ///
    /// `self` `max` dan katta bo'lsa `max`, `self` `min` dan kichik bo'lsa `min` qaytaradi.
    /// Aks holda, bu `self` ni qaytaradi.
    ///
    /// # Panics
    ///
    /// Agar `min > max` bo'lsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord` implini yaratadigan so'lni oling.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Saralash tartibi bilan taqqoslanadigan qiymatlar uchun Trait.
///
/// Taqqoslash barcha `a`, `b` va `c` uchun javob berishi kerak:
///
/// - assimetriya: agar `a < b` keyin `!(a > b)` bo'lsa, shuningdek `a > b` `!(a < b)` ni nazarda tutsa;va
/// - o'tuvchanlik: `a < b` va `b < c` `a < c` ni nazarda tutadi.Xuddi shu narsa `==` va `>` uchun ham amal qilishi kerak.
///
/// E'tibor bering, ushbu talablar trait ning o'zi nosimmetrik va tranzitiv tarzda amalga oshirilishi kerakligini anglatadi: agar `T: PartialOrd<U>` va `U: PartialOrd<V>`, keyin `U: PartialOrd<T>` va `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Ushbu trait dan `#[derive]` bilan foydalanish mumkin.Struktlardan kelib chiqqan holda, u struktura a'zolarining yuqoridan pastgacha deklaratsiya tartibiga asoslanib leksikografik tartibni ishlab chiqaradi.
/// Enumlarda `derive`d bo'lsa, variantlar yuqoridan pastgacha diskriminantlik tartibiga ko'ra tartiblanadi.
///
/// ## `PartialOrd` ni qanday amalga oshirishim mumkin?
///
/// `PartialOrd` faqat [`partial_cmp`] usulini amalga oshirishni talab qiladi, boshqalari esa standart dasturlardan hosil bo'ladi.
///
/// Ammo boshqalarni umumiy buyurtma bo'lmagan turlar bo'yicha alohida amalga oshirish mumkin.
/// Masalan, suzuvchi nuqta raqamlari uchun `NaN < 0 == false` va `NaN >= 0 == false` (qarang.
/// IEEE 754-2008 bo'limi 5.11).
///
/// `PartialOrd` sizning turingiz [`PartialEq`] bo'lishini talab qiladi.
///
/// [`PartialEq`], `PartialOrd` va [`Ord`]*dasturlari* bir-biriga mos kelishi kerak.
/// traits ning bir qismini keltirib, boshqalarini qo'lda amalga oshirish orqali ularni tasodifan kelishmovchilikka olib kelish oson.
///
/// Agar sizning turingiz [`Ord`] bo'lsa, siz [`cmp`] yordamida [`partial_cmp`] ni amalga oshirishingiz mumkin:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`partial_cmp`]-dan o'zingizning turlaringizda foydalanish foydali bo'lishi mumkin.
/// `Person` turidagi suzuvchi nuqtaga ega bo'lgan `Person` turlarining namunasi, bu saralash uchun ishlatiladigan yagona maydon:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Ushbu usul mavjud bo'lsa, `self` va `other` qiymatlari o'rtasida tartibni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Taqqoslash imkonsiz bo'lganda:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Ushbu usul (`self` va `other` uchun) dan kamini sinovdan o'tkazadi va `<` operatori tomonidan qo'llaniladi.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Ushbu usul (`self` va `other` uchun) dan kam yoki teng bo'lganlarni sinab ko'radi va `<=` operatori tomonidan qo'llaniladi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Ushbu usul (`self` va `other` uchun) dan kattaroq sinovlarni amalga oshiradi va `>` operatori tomonidan qo'llaniladi.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Ushbu usul (`self` va `other` uchun) dan katta yoki unga teng sinovlarni o'tkazadi va `>=` operatori tomonidan qo'llaniladi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` implini yaratadigan so'lni oling.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Minimal ikkita qiymatni taqqoslaydi va qaytaradi.
///
/// Agar taqqoslash ularning tengligini aniqlasa, birinchi argumentni qaytaradi.
///
/// Ichki ravishda [`Ord::min`] uchun taxallusni ishlatadi.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Belgilangan taqqoslash funktsiyasiga nisbatan minimal ikkita qiymatni qaytaradi.
///
/// Agar taqqoslash ularning tengligini aniqlasa, birinchi argumentni qaytaradi.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Belgilangan funktsiyadan minimal qiymat beradigan elementni qaytaradi.
///
/// Agar taqqoslash ularning tengligini aniqlasa, birinchi argumentni qaytaradi.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Ikkala maksimal qiymatni taqqoslaydi va qaytaradi.
///
/// Agar taqqoslash ularning tengligini aniqlasa, ikkinchi argumentni qaytaradi.
///
/// Ichki ravishda [`Ord::max`] uchun taxallusni ishlatadi.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Belgilangan taqqoslash funktsiyasiga nisbatan maksimal ikkita qiymatni qaytaradi.
///
/// Agar taqqoslash ularning tengligini aniqlasa, ikkinchi argumentni qaytaradi.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Belgilangan funktsiyadan maksimal qiymatni beradigan elementni qaytaradi.
///
/// Agar taqqoslash ularning tengligini aniqlasa, ikkinchi argumentni qaytaradi.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Ibtidoiy turlar uchun PartialEq, Eq, PartialOrd va Ord ni amalga oshirish
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Bu erda buyurtma yanada maqbul yig'ishni yaratish uchun muhimdir.
                    // Qo'shimcha ma'lumot olish uchun <https://github.com/rust-lang/rust/issues/63758>-ga qarang.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // I8-ga quyish va farqni Buyurtmaga o'tkazish eng maqbul yig'ilishni yaratadi.
            //
            // Qo'shimcha ma'lumot olish uchun <https://github.com/rust-lang/rust/issues/66780>-ga qarang.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // XAVFSIZLIK: bool sifatida i8 0 yoki 1 qiymatini qaytaradi, shuning uchun farq boshqa narsa bo'lishi mumkin emas
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &ko'rsatgichlar

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}