//! Xotirada joylashgan joyiga ma'lumotlarni mahkamlaydigan turlar.
//!
//! Ba'zida harakatlanmasligi kafolatlangan ob'ektlarga ega bo'lish foydali bo'ladi, bu ularning xotirada joylashishi o'zgarmaydi va shu bilan ularga ishonish mumkin.
//! Bunday stsenariyning eng yaxshi namunasi o'z-o'ziga yo'naltirilgan tuzilmalarni yaratish bo'lishi mumkin, chunki ko'rsatgichlar bilan ob'ektni o'ziga ko'chirish ularni bekor qiladi va bu aniqlanmagan xatti-harakatga olib kelishi mumkin.
//!
//! Yuqori darajadagi [`Pin<P>`] har qanday ko'rsatgich `P` pointei xotirada barqaror joylashishini ta'minlaydi, ya'ni uni boshqa joyga ko'chirish mumkin emas va uning xotirasi tushmaguncha uni taqsimlash mumkin emas.Pointee "pinned" deb aytamiz.Qoplanmagan ma'lumotlar bilan biriktirilgan turlarni muhokama qilishda narsalar yanada nozikroq bo'ladi;Qo'shimcha ma'lumot uchun [see below](#projections-and-structural-pinning).
//!
//! Odatiy bo'lib, Rust-dagi barcha turlari harakatlanuvchi.
//! Rust barcha turdagi qiymatlarni uzatishga imkon beradi va [`Box<T>`] va `&mut T` kabi keng tarqalgan aqlli ko'rsatgich turlari ular tarkibidagi qiymatlarni almashtirish va ko'chirishga imkon beradi: siz [`Box<T>`] dan chiqib ketishingiz yoki [`mem::swap`] dan foydalanishingiz mumkin.
//! [`Pin<P>`] `P` tipidagi ko'rsatgichni o'rab oladi, shuning uchun [`Pin`]`<`[`Box`] `<T>>"odatdagidek ishlaydi
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] '<T>> `tushadi, shuning uchun uning mazmuni ham bajariladi va xotira oladi
//!
//! ajratilgan.Xuddi shunday, [`Pin`]` <&mut T> 'ham `&mut T` ga juda o'xshaydi.Biroq, [`Pin<P>`] mijozlarga haqiqatan ham aniqlangan ma'lumotlarga [`Box<T>`] yoki `&mut T` olishlariga yo'l qo'ymaydi, bu sizning [`mem::swap`] kabi operatsiyalardan foydalana olmasligingizni anglatadi.
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` `&mut T` kerak, lekin biz uni ololmaymiz.
//!     // Biz tiqilib qoldik, biz ushbu ma'lumotlarning mazmunini o'zgartira olmaymiz.
//!     // Biz `Pin::get_unchecked_mut`-dan foydalanishimiz mumkin edi, ammo bu xavfli emas:
//!     // biz uni `Pin` dan narsalarni ko'chirish uchun ishlatishga ruxsat berilmagan.
//! }
//! ```
//!
//! Shuni ta'kidlash kerakki, [`Pin<P>`] Rust kompilyatori barcha turdagi harakatlanuvchi deb hisoblaganligini *o'zgartirmaydi*.[`mem::swap`] har qanday `T` uchun qo'ng'iroq qilinadigan bo'lib qoladi.Buning o'rniga, [`Pin<P>`] ba'zi *qiymatlarni*([`Pin<P>`] ga o'ralgan ko'rsatgichlar bilan ishora qiladi) ularni `&mut T` talab qiladigan usullarni (masalan, [`mem::swap`]) chaqirishning iloji yo'qligi sababli harakatlanishiga to'sqinlik qiladi.
//!
//! [`Pin<P>`] har qanday `P` tipidagi ko'rsatgichni o'rash uchun ishlatilishi mumkin va shuning uchun u [`Deref`] va [`DerefMut`] bilan o'zaro ta'sir qiladi.[`Pin<P>`], bu erda `P: Deref` pinli `P::Target` ga "`P`-style pointer" sifatida qaralishi kerak-demak, [`Pin`]`<`[`Box`] "<T>>`pinlangan `T`-ga tegishli ko'rsatgich va [`Pin`] `<` [`Rc`] '<T>> "bu bog'langan `T` uchun mos yozuvlar hisoblangan ko'rsatkich.
//! To'g'ri bo'lishi uchun [`Pin<P>`] [`Deref`] va [`DerefMut`] dasturlarini o'zlarining `self` parametrlaridan tashqariga chiqmasliklariga va faqat mahkamlangan ko'rsatgichga chaqirilganda ko'rsatgichni mahkamlangan ma'lumotlarga qaytarishiga ishonadi.
//!
//! # `Unpin`
//!
//! Ko'pgina turlar har doim erkin ko'chiriladi, hatto mahkamlanganda ham, chunki ular barqaror manzilga ishonmaydi.Bunga barcha asosiy turlar (masalan, [`bool`], [`i32`] va havolalar) va faqat shu turlardan iborat turlar kiradi.PIN-kodga ahamiyat bermaydigan turlar [`Pin<P>`] ta'sirini bekor qiladigan [`Unpin`] avtomatik trait-ni qo'llaydi.
//! `T: Unpin` uchun [`Pin`]`<`[`Box`] `<T>>`va [`Box<T>`] bir xil ishlaydi, [[Pin`]` <&mut T> `va `&mut T` kabi.
//!
//! Shuni esda tutingki, pinning va [`Unpin`] faqat `P::Target` tipiga ta'sir qiladi, [`Pin<P>`] ga o'ralgan `P` turiga emas.Masalan, [`Box<T>`] ning [`Unpin`] bo'ladimi yoki yo'qmi [`Pin`]`<`[`Box`] "xatti-harakatlariga ta'sir qilmaydi<T>>`(bu erda, `T`-yo'naltirilgan tip).
//!
//! # Misol: o'z-o'ziga yo'naltiruvchi struct
//!
//! `Pin<T>` bilan bog'liq bo'lgan kafolatlar va tanlovlarni tushuntirish uchun batafsil ma'lumot berishdan oldin, biz uni qanday ishlatish mumkinligi haqida ba'zi misollarni muhokama qilamiz.
//! [skip to where the theoretical discussion continues](#drop-guarantee)-ga murojaat qiling.
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Bu o'z-o'ziga murojaat qilish strukturasi, chunki tilim maydoni ma'lumotlar maydoniga ishora qiladi.
//! // Biz bu haqda kompilyatorga odatdagi ma'lumotnoma bilan xabar berolmaymiz, chunki bu namunani odatdagi qarz olish qoidalari bilan ta'riflab bo'lmaydi.
//! //
//! // Buning o'rniga biz xom ko'rsatkichni ishlatamiz, ammo u nolga teng emasligi ma'lum, chunki u mag'lubiyatga ishora qilmoqda.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Funktsiya qaytarilganda ma'lumotlar siljimasligini ta'minlash uchun biz uni ob'ektning umri davomida saqlanadigan joyga joylashtiramiz va unga kirishning yagona usuli bu unga ishora orqali bo'lishi mumkin.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // biz ko'rsatgichni ma'lumotlar mavjud bo'lgandan keyingina yaratamiz, aks holda ular biz hali boshlamasdan oldin ko'chib ketgan bo'ladi
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // biz buni xavfsiz deb bilamiz, chunki maydonni o'zgartirish butun strukturani harakatga keltirmaydi
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Struktura siljimagan ekan, ko'rsatkich to'g'ri joyga ko'rsatilishi kerak.
//! //
//! // Ayni paytda, biz ko'rsatgichni harakatga keltiramiz.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Bizning turimiz Unpin-ni qo'llamaganligi sababli, bu quyidagilarni bajarib bo'lmaydi:
//! // mut new_unmoved= Unmovable::new("world".to_string()) qilaylik;
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Misol: intruziv ikki tomonlama bog'langan ro'yxat
//!
//! Intruziv ikki tomonlama bog'langan ro'yxatda, to'plam aslida elementlarning o'zi uchun xotirani ajratmaydi.
//! Ajratish mijozlar tomonidan boshqariladi va elementlar to'plamdan ko'ra qisqa umr ko'radigan stak ramkasida yashashi mumkin.
//!
//! Ushbu ishni bajarish uchun har bir element ro'yxatdagi avvalgisiga va vorisiga ko'rsatgichlarga ega.Elementlarni faqat mahkamlanganda qo'shish mumkin, chunki elementlarning atrofida harakat qilish ko'rsatkichlarni bekor qiladi.Bundan tashqari, bog'langan ro'yxat elementining [`Drop`]-ni amalga oshirish, o'zlarini ro'yxatdan olib tashlash uchun avvalgi va vorisning ko'rsatgichlarini yamaydi.
//!
//! Eng muhimi, biz [`drop`] chaqirilishiga ishonishimiz kerak.Agar elementni [`drop`]-ga qo'ng'iroq qilmasdan ajratish yoki boshqa yo'l bilan bekor qilish mumkin bo'lsa, unga qo'shni elementlardan ko'rsatgichlar yaroqsiz bo'lib qoladi va bu ma'lumotlar tuzilishini buzadi.
//!
//! Shuning uchun pinning ham ["tushish"] bilan bog'liq kafolati bilan birga keladi.
//!
//! # `Drop` guarantee
//!
//! Pinning maqsadi-xotirada ba'zi ma'lumotlarning joylashishiga ishonish.
//! Ushbu ishni bajarish uchun faqat ma'lumotlarni ko'chirish cheklanmaydi;ma'lumotlarni saqlash uchun foydalaniladigan xotirani taqsimlash, qayta yo'naltirish yoki boshqa yo'l bilan bekor qilish ham cheklangan.
//! Konkret ravishda, mahkamlangan ma'lumotlar uchun siz uning xotirasi bekor qilingan paytdan boshlab [`drop`] chaqirilguniga qadar * bekor qilinmasligi yoki o'zgarib ketmasligi o'zgarmasligini saqlashingiz kerak.[`drop`] qaytganidan yoki panics dan keyingina xotira qayta ishlatilishi mumkin.
//!
//! Xotira ajratish yo'li bilan "invalidated" bo'lishi mumkin, shuningdek [`Some(v)`] ni [`None`] ga almashtirish yoki vector ning ba'zi elementlarini [`Vec::set_len`] dan "kill" ga chaqirish orqali ham bo'lishi mumkin.Avval uni destruktorga qo'ng'iroq qilmasdan, uni ustiga yozish uchun [`ptr::write`] yordamida o'zgartirish mumkin.[`drop`] raqamiga qo'ng'iroq qilmasdan pinlangan ma'lumotlarga ruxsat berilmaydi.
//!
//! Bu avvalgi bo'limdagi zo'ravonlik bilan bog'langan ro'yxatning to'g'ri ishlashi uchun zarur bo'lgan kafolat.
//!
//! E'tibor bering, ushbu kafolat *xotira sızmayacağını anglatmaydi!Shnurlangan elementga [`drop`] raqamiga qo'ng'iroq qilish hech qachon umuman yaxshi emas (masalan, siz hali ham [`mem::forget`] raqamiga [`Pin`]"<`[`Box`] "da qo'ng'iroq qilishingiz mumkin.<T>>`).Ikkala bog'langan ro'yxat misolida ushbu element faqat ro'yxatda qoladi.Shu bilan birga siz [`drop`]* qo'ng'iroqisiz * saqlash joyini bo'shata olmaysiz yoki qayta ishlata olmaysiz.
//!
//! # `Drop` implementation
//!
//! Agar sizning turingiz pinningdan foydalansa (masalan, yuqoridagi ikkita misol), siz [`Drop`]-ni amalga oshirishda ehtiyot bo'lishingiz kerak.[`drop`] funktsiyasi `&mut self`-ni oladi, ammo bu sizning turingiz ilgari mahkamlangan bo'lsa ham * deb nomlanadi!Xuddi kompilyator avtomatik ravishda [`Pin::get_unchecked_mut`] deb nomlangan.
//!
//! Bu hech qachon xavfsiz kodda muammo tug'dirishi mumkin emas, chunki pinirovkaga asoslangan turni amalga oshirish xavfli kodni talab qiladi, ammo shuni bilingki, sizning turingizdagi pinnatsiyadan foydalanishga qaror qiling (masalan, ["Pin`]"<&Self-da ba'zi operatsiyalarni bajarish orqali>"yoki [`Pin`] "<&mut Self>`) sizning [`Drop`] dasturingizni amalga oshirishda ham oqibatlarga olib keladi: agar sizning elementingiz mahkamlangan bo'lsa, siz [`Drop`]-ga ["Pin"] "<&mut O'zi>".
//!
//!
//! Masalan, siz `Drop`-ni quyidagicha amalga oshirishingiz mumkin:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` yaxshi, chunki biz bilamizki, bu qiymat tushirilgandan keyin hech qachon qayta ishlatilmaydi.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Haqiqiy tomchi kod bu erda.
//!         }
//!     }
//! }
//! ```
//!
//! `inner_drop` funktsiyasi [`drop`] * ga ega bo'lishi kerak bo'lgan turga ega, shuning uchun `self`/`this`-ni tasodifan pinnga zid keladigan tarzda ishlatmasligingizga ishonch hosil qiladi.
//!
//! Bundan tashqari, agar sizning turingiz `#[repr(packed)]` bo'lsa, kompilyator ularni tashlab yuborish uchun avtomatik ravishda maydonlarni harakatga keltiradi.Hatto etarli darajada mos keladigan maydonlar uchun ham buni amalga oshirish mumkin.Natijada, siz `#[repr(packed)]` turi bilan biriktirishdan foydalana olmaysiz.
//!
//! # Proektsiyalar va tizimli pinning
//!
//! Qoplangan konstruktsiyalar bilan ishlashda ushbu strukturaning maydonlariga faqat ["Pin`]"<&mut Struct>"ni qabul qiladigan usulda qanday kirish mumkinligi haqida savol tug'iladi.
//! Odatiy yondashuv-bu yordamchi usullarni yozish (*proektsiyalar* deb nomlanadi), ular ['Pin`]`<&mut Struct>' ni maydonga havolaga aylantiradi, ammo bu ma'lumotnoma qaysi turga ega bo'lishi kerak?Bu [`Pin`]`<&mut Field>`yoki `&mut Field`?
//! Xuddi shu savol `enum` maydonlari bilan, shuningdek [`Vec<T>`], [`Vec<T>`], [`Box<T>`] yoki [`RefCell<T>`] kabi container/wrapper turlarini ko'rib chiqishda paydo bo'ladi.
//! (Bu savol o'zgaruvchan va umumiy ma'lumotlarga tegishli, biz misol uchun o'zgaruvchan havolalarning keng tarqalgan holatidan foydalanamiz.)
//!
//! Ma'lum bir maydon uchun mahkamlangan proektsiyaning [`Pin`]`<&mut Struct>`ni [`Pin`] `<&mut Field> 'ga aylantiradimi yoki yo'qmi, aslida ma'lumotlar strukturasi muallifiga bog'liq. `&mut Field`.Shunga qaramay, ba'zi cheklovlar mavjud va eng muhim cheklov *barqarorlik*:
//! har bir maydon *bog'langan ma'lumotnomada prognoz qilinishi mumkin* yoki * proektsiyaning bir qismi sifatida pinning o'chirilishi mumkin.
//! Agar ikkalasi ham bitta maydon uchun bajarilgan bo'lsa, bu befoyda bo'lishi mumkin!
//!
//! Ma'lumotlar strukturasining muallifi sifatida siz har bir maydon uchun "propagates"-ni ushbu maydonga o'rnatadimi yoki yo'qmi degan qarorga kelasiz.
//! Ko'payadigan pimlash "structural" deb ham ataladi, chunki u turning tuzilishiga amal qiladi.
//! Keyingi bo'limlarda biz har qanday tanlov uchun qilinishi kerak bo'lgan fikrlarni bayon qilamiz.
//!
//! ## Pinning *`field` uchun* tarkibiy emas
//!
//! Qarama-qarshi intuitiv bo'lib tuyulishi mumkin, bu mahkamlangan strukturaning maydonini mahkamlamasligi mumkin, ammo bu aslida eng oson tanlov: agar [[Pin`]`<&mut Field>" hech qachon yaratilmasa, hech narsa yomonlashi mumkin emas!Shunday qilib, agar siz biron bir sohada strukturaviy pinning yo'qligiga qaror qilsangiz, siz ushbu maydonga hech qachon bog'langan havolani yaratmasligingiz kerak.
//!
//! Strukturaviy biriktirmasdan maydonlar [`Pin`]` <&mut Struct> 'ni `&mut Field` ga aylantiradigan proektsion usulga ega bo'lishi mumkin:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Bu yaxshi, chunki `field` hech qachon mahkamlangan deb hisoblanmaydi.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! `field` turi [`Unpin`] bo'lmasa ham, siz `impl Unpin for Struct` * qilishingiz mumkin.Hech qachon [`Pin`]"<&mut Field>"yaratilmasa, ushbu turdagi mahkamlash haqida o'ylaydigan narsa ahamiyatli emas.
//!
//! ## Pinning *`field` uchun* tarkibiy
//!
//! Boshqa variant, pinning `field` uchun "structural" ekanligiga qaror qilishdir, ya'ni agar struktura bog'langan bo'lsa, maydon ham shunday bo'ladi.
//!
//! Bu ["Pin`]"<&mut Field>"hosil qiladigan proektsiyani yozishga imkon beradi va shu bilan maydonning mahkamlanganligiga guvoh bo'lamiz:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Bu yaxshi, chunki `field` `self` bo'lganda mahkamlanadi.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Biroq, strukturaviy pinning bir nechta qo'shimcha talablari mavjud:
//!
//! 1. Struktura faqat [`Unpin`] bo'lishi kerak, agar barcha strukturaviy maydonlar [`Unpin`] bo'lsa.Bu asl qiymati, ammo [`Unpin`] xavfsiz trait, shuning uchun strukturaning muallifi `impl<T> Unpin for Struct<T>` kabi narsalarni qo'shish uchun *emas* sizning javobgarligingizdir.
//! (E'tibor bering, proektsion operatsiyani qo'shish xavfli kodni talab qiladi, shuning uchun [`Unpin`] xavfsiz trait ekanligi, agar siz "xavfli" dan foydalansangiz, bu haqda tashvishlanishingiz kerak degan tamoyilni buzmaydi.)
//! 2. Strukturaning destruktori tarkibiy maydonlarni argumentidan tashqariga chiqarmasligi kerak.Bu [previous section][drop-impl]-da ko'tarilgan aniq nuqta: `drop` `&mut self`-ni oladi, lekin struct (va shuning uchun uning maydonlari) ilgari mahkamlangan bo'lishi mumkin.
//!     Siz o'zingizning [`Drop`] dasturingiz ichidagi maydonni ko'chirmasligingizga kafolat berishingiz kerak.
//!     Xususan, ilgari aytib o'tilganidek, bu sizning tuzilmangiz *bo'lmasligi kerak* degan ma'noni anglatadi `#[repr(packed)]`.
//!     [`drop`]-ni kompilyator sizga tasodifiy pinni buzmaslikka yordam beradigan tarzda qanday yozishni ushbu bo'limga qarang.
//! 3. Siz [`Drop` guarantee][drop-guarantee]-ni qo'llab-quvvatlaganingizga ishonch hosil qilishingiz kerak:
//!     sizning tuzilmangiz mahkamlangandan so'ng, tarkibni o'z ichiga olgan xotira yozilmaydi yoki kontentni buzadigan qurilmalarni chaqirmasdan ajratilmaydi.
//!     [`VecDeque<T>`] guvohi bo'lganidek, bu hiyla-nayrang bo'lishi mumkin: agar panics destruktorlaridan biri bo'lsa, [`VecDeque<T>`] destruktori barcha elementlarda [`drop`] ni chaqira olmaydi.Bu [`Drop`] kafolatini buzadi, chunki bu elementlarning destruktori chaqirilmasdan ajratilishiga olib kelishi mumkin.([`VecDeque<T>`]-da pinning proektsiyalari yo'q, shuning uchun bu asossizlikni keltirib chiqarmaydi.)
//! 4. Sizning turingiz mahkamlanganda ma'lumotlar strukturaviy maydonlardan ko'chirilishiga olib keladigan boshqa operatsiyalarni taklif qilishingiz shart emas.Masalan, agar strukturada [`Option<T>`] mavjud bo'lsa va `fn(Pin<&mut Struct<T>>) -> Option<T>` turi bilan "qabul qilish" ga o'xshash operatsiya mavjud bo'lsa, bu operatsiya `T` ni mahkamlangan `Struct<T>` ichidan ko'chirish uchun ishlatilishi mumkin-demak, bu tutashgan maydon uchun mahkamlash strukturaviy bo'lolmaydi. ma'lumotlar.
//!
//!     Ma'lumotlarni mahkamlangan turdan ko'chirishning yanada murakkab misoli uchun [`RefCell<T>`] da `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` usuli bo'lganligini tasavvur qiling.
//!     Keyin biz quyidagilarni qila olamiz:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Bu halokatli, demak biz avval [`RefCell<T>`] tarkibini mahkamlashimiz mumkin (`RefCell::get_pin_mut` yordamida), so'ngra keyinchalik olingan o'zgaruvchan mos yozuvlar yordamida ushbu tarkibni ko'chirishimiz mumkin.
//!
//! ## Examples
//!
//! [`Vec<T>`] kabi turdagi har ikkala imkoniyat ham (strukturaviy pinning yoki yo'q) mantiqiy.
//! Strukturaviy biriktirgichli [`Vec<T>`] elementlarga bog'langan havolalarni olish uchun `get_pin`/`get_pin_mut` usullariga ega bo'lishi mumkin.Shu bilan birga, [`pop`][Vec::pop]-ni mahkamlangan [`Vec<T>`]-ga qo'ng'iroq qilishga * ruxsat bera olmadi, chunki (tarkibida mahkamlangan) tarkibni siljitadi!Shuningdek, u [`push`][Vec::push]-ga ruxsat berolmaydi, bu esa qayta taqsimlanishi va shu bilan tarkibni ko'chirishi mumkin.
//!
//! Strukturaviy biriktirilmagan [`Vec<T>`] `impl<T> Unpin for Vec<T>` bo'lishi mumkin, chunki tarkib hech qachon mahkamlanmaydi va [`Vec<T>`] o'zi ham ko'chirilishi bilan yaxshi.
//! O'sha paytda pinning vector-ga umuman ta'siri yo'q.
//!
//! Standart kutubxonada ko'rsatgich turlari odatda strukturaviy biriktirishga ega emas va shuning uchun ular pin proektsiyalarini taklif qilmaydi.Shuning uchun `Box<T>: Unpin` barcha `T` uchun amal qiladi.
//! Buni ko'rsatgich turlari uchun qilish mantiqan to'g'ri keladi, chunki `Box<T>` ni harakatga keltirish `T` ni harakatga keltirmaydi: `T` bo'lmasa ham, [`Box<T>`] erkin harakatlanishi mumkin (aka `Unpin`).Aslida, hatto [`Pin`]`<`[`Box`] '<T>> `va [` Pin`]`<&mut T> 'har doim ham [`Unpin`] ning o'zi, shu sababli: ularning tarkibi (`T`) mahkamlanadi, lekin ko'rsatgichlarning o'zi mahkamlangan ma'lumotlarni ko'chirmasdan ko'chirilishi mumkin.
//! Ham [`Box<T>`], ham [`Pin`]"<`[`Box`] "uchun<T>>`, kontentning mahkamlanganligi, ko'rsatgichning mahkamlanganligidan mutlaqo mustaqildir, ya'ni pinning *tarkibiy emas* degan ma'noni anglatadi.
//!
//! [`Future`] kombinatorini amalga oshirayotganda, odatda, o'rnatilgan futures uchun tizimli biriktirish kerak bo'ladi, chunki [`poll`] ga qo'ng'iroq qilish uchun ularga bog'langan ma'lumotnomalarni olish kerak.
//! Agar sizning kombinatoringizda mahkamlashni talab qilmaydigan boshqa biron bir ma'lumot bo'lsa, siz ushbu maydonlarni tizimli bo'lmagan holatga keltirishingiz mumkin va shuning uchun [[Pin`]"<&mut Self>" (masalan, o'zingizning [`poll`] dasturingizda bo'lgani kabi).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Qoplangan ko'rsatkich.
///
/// Bu "pin" ko'rsatkichini o'z o'rnida bajaradigan va shu ko'rsatgich tomonidan havola qilinadigan qiymatni [`Unpin`]-ni qo'llamaguncha ko'chirilishini oldini oladigan bir xil ko'rsatgich atrofidagi o'rash.
///
///
/// *PIN-kodni tushuntirish uchun [`pin` module] hujjatlariga qarang.*
///
/// [`pin` module]: self
///
// Note: Quyida keltirilgan `Clone` hosilasi noaniqlikni keltirib chiqaradi, chunki uni amalga oshirish mumkin
// `Clone` o'zgaruvchan havolalar uchun.
// Qo'shimcha ma'lumot uchun <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>-ga qarang.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Sog'lomlikni oldini olish uchun quyidagi dasturlar ishlab chiqilmagan.
// `&self.pointer` ishonchsiz trait dasturlari uchun mavjud bo'lmasligi kerak.
//
// Qo'shimcha ma'lumot uchun <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>-ga qarang.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// [`Unpin`]-ni amalga oshiradigan ba'zi bir ma'lumotlarga ko'rsatgich atrofida yangi `Pin<P>` tuzing.
    ///
    /// `Pin::new_unchecked`-dan farqli o'laroq, bu usul xavfsizdir, chunki `P` ko'rsatgichi [`Unpin`] turiga murojaat qiladi, bu esa mahkamlash kafolatlarini bekor qiladi.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // XAVFSIZLIK: ko'rsatilgan qiymat `Unpin`, shuning uchun hech qanday talablar yo'q
        // pinning atrofida.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Ushbu `Pin<P>`-ni pastki ko'rsatkichni qaytarib ochadi.
    ///
    /// Buning uchun ushbu `Pin` ichidagi ma'lumotlar [`Unpin`] bo'lishi kerak, shuning uchun biz uni echishda pinning o'zgarmasligini e'tiborsiz qoldiramiz.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// `Unpin` ni amalga oshirishi mumkin yoki bajarmasligi mumkin bo'lgan ba'zi bir ma'lumotlarga havola atrofida yangi `Pin<P>` tuzing.
    ///
    /// Agar `pointer` `Unpin` turiga tegishli bo'lsa, uning o'rniga `Pin::new` ishlatilishi kerak.
    ///
    /// # Safety
    ///
    /// Ushbu konstruktor xavfli emas, chunki biz `pointer` tomonidan ko'rsatilgan ma'lumotlarning mahkamlanganligiga kafolat bera olmaymiz, ya'ni ma'lumotlar tashlanmaguncha ko'chirilmaydi yoki saqlanishi yaroqsiz bo'ladi.
    /// Agar qurilgan `Pin<P>` `P` ko'rsatgan ma'lumotlarning mahkamlanishiga kafolat bermasa, bu API shartnomasini buzish va keyingi (safe) operatsiyalarida aniqlanmagan harakatlarga olib kelishi mumkin.
    ///
    /// Ushbu usuldan foydalanib, agar ular mavjud bo'lsa, `P::Deref` va `P::DerefMut` dasturlari haqida promise-ni yaratasiz.
    /// Eng muhimi, ular o'zlarining `self` argumentlaridan chiqib ketmasliklari kerak: `Pin::as_mut` va `Pin::as_ref` pinlangan ko'rsatgichda `DerefMut::deref_mut` va `Deref::deref` * ga qo'ng'iroq qilishadi va bu usullar pinning o'zgarmasligini qo'llab-quvvatlashni kutishadi.
    /// Bundan tashqari, ushbu usulni chaqirish orqali siz promise-ga murojaat qiling, chunki `P` ma'lumotnomalari qayta ko'chirilmaydi;Xususan, `&mut P::Target` ni olish va undan keyin ushbu ma'lumotnomadan chiqib ketish (masalan, [`mem::swap`] yordamida) mumkin bo'lmasligi kerak.
    ///
    ///
    /// Masalan, `&'a mut T`-ga `&'a mut T`-ga qo'ng'iroq qilish xavfli emas, chunki siz uni `'a`-ni umr bo'yi mahkamlashingiz mumkin bo'lsa-da, siz `'a` tugagandan so'ng uni mahkamlab qo'yishingizni nazorat qila olmaysiz:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Bu shuni anglatadiki, `a` pointei boshqa hech qachon harakatlana olmaydi.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // `a` manzili "b" ning stack slotiga o'zgartirildi, shuning uchun `a` biz ilgari mahkamlagan bo'lsak ham ko'chib o'tdi!Biz API API shartnomasini buzdik.
    /////
    /// }
    /// ```
    ///
    /// Bir marta mahkamlangandan keyin qiymat abadiy mahkamlangan bo'lib qolishi kerak (agar uning turi `Unpin` ni qo'llamasa).
    ///
    /// Xuddi shunday, `Pin::new_unchecked`-ni `Rc<T>`-da qo'ng'iroq qilish xavfli emas, chunki bir xil ma'lumotlarga pinni cheklashlar kiritilmagan taxalluslar bo'lishi mumkin:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Bu shuni anglatadiki, pointee boshqa hech qachon harakatlana olmaydi.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Endi, agar `x` yagona ma'lumotnoma bo'lgan bo'lsa, biz avvalgi misolda ko'rganimizdek, uni ko'chirish uchun foydalanishimiz mumkin bo'lgan yuqoriga mahkamlagan ma'lumotlarga o'zgaruvchan havola mavjud.
    ///     // Biz API API shartnomasini buzdik.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Ushbu mahkamlangan ko'rsatgichdan mahkamlangan umumiy ma'lumotni oladi.
    ///
    /// Bu `&Pin<Pointer<T>>` dan `Pin<&T>` ga o'tishning umumiy usuli.
    /// Bu xavfsizdir, chunki `Pin::new_unchecked` shartnomasining bir qismi sifatida, `Pin<Pointer<T>>` yaratilgandan so'ng, pointee harakatlana olmaydi.
    ///
    /// "Malicious" `Pointer::Deref` dasturlari ham `Pin::new_unchecked` shartnomasi bilan bekor qilingan.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // XAVFSIZLIK: ushbu funktsiya bo'yicha hujjatlarni ko'ring
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Ushbu `Pin<P>`-ni pastki ko'rsatkichni qaytarib ochadi.
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya xavfli.Siz ushbu funktsiyani chaqirgandan so'ng `P` ko'rsatkichiga mahkamlangan holda ishlov berishni davom ettirishingizga kafolat berishingiz kerak, shunda `Pin` turidagi o'zgaruvchilar saqlanishi mumkin.
    /// Agar olingan `P`-dan foydalanadigan kod pinning o'zgarmasligini davom ettirmasa, bu API shartnomasini buzishi va keyingi (safe) operatsiyalarida aniqlanmagan harakatlarga olib kelishi mumkin.
    ///
    ///
    /// Agar asosiy ma'lumotlar [`Unpin`] bo'lsa, uning o'rniga [`Pin::into_inner`] ishlatilishi kerak.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Ushbu mahkamlangan ko'rsatgichdan mahkamlangan o'zgaruvchan ma'lumotni oladi.
    ///
    /// Bu `&mut Pin<Pointer<T>>` dan `Pin<&mut T>` ga o'tishning umumiy usuli.
    /// Bu xavfsizdir, chunki `Pin::new_unchecked` shartnomasining bir qismi sifatida, `Pin<Pointer<T>>` yaratilgandan so'ng, pointee harakatlana olmaydi.
    ///
    /// "Malicious" `Pointer::DerefMut` dasturlari ham `Pin::new_unchecked` shartnomasi bilan bekor qilingan.
    ///
    /// Ushbu usul mahkamlangan turni iste'mol qiladigan funktsiyalarga bir nechta qo'ng'iroqlarni amalga oshirishda foydalidir.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // nimadir qil
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` `self` iste'mol qiladi, shuning uchun `Pin<&mut Self>` ni `as_mut` orqali qayta tiklang.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // XAVFSIZLIK: ushbu funktsiya bo'yicha hujjatlarni ko'ring
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Belgilangan ma'lumotnomaning orqasida xotiraga yangi qiymat tayinlaydi.
    ///
    /// Bu mahkamlangan ma'lumotlarning ustiga yoziladi, ammo bu yaxshi: uning destruktori yozilishidan oldin ishlaydi, shuning uchun hech qanday pinning kafolati buzilmaydi.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Ichki qiymatni xaritalash orqali yangi pinni quradi.
    ///
    /// Masalan, siz biron bir narsaning maydonini `Pin` olishni xohlasangiz, ushbu satrga bitta kod satrida kirish uchun foydalanishingiz mumkin.
    /// Biroq, ushbu "pinning projections" bilan bir nechta gotchalar mavjud;
    /// ushbu mavzu bo'yicha batafsil ma'lumot uchun [`pin` module] hujjatlariga qarang.
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya xavfli.
    /// Siz qaytargan ma'lumotlar argument qiymati harakat qilmaguncha (masalan, bu qiymatning maydonlaridan biri bo'lganligi sababli) siljimasligiga, shuningdek siz olgan argumentdan tashqariga chiqmasligingizga kafolat berishingiz kerak. ichki funktsiya.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // XAVFSIZLIK: `new_unchecked` uchun xavfsizlik shartnomasi bo'lishi kerak
        // chaqiruvchi tomonidan qo'llab-quvvatlandi.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// PIN-koddan umumiy ma'lumotni oladi.
    ///
    /// Bu xavfsizdir, chunki umumiy ma'lumotnomadan chiqib ketish mumkin emas.
    /// Bu erda ichki o'zgaruvchanlik bilan bog'liq muammo paydo bo'lishi mumkin: aslida `T`-ni `&RefCell<T>`-dan ko'chirish *mumkin*.
    /// Shu bilan birga, xuddi shu ma'lumotlarga ishora qiluvchi `Pin<&T>` mavjud bo'lmasa va `RefCell<T>` uning tarkibiga bog'langan ma'lumotnoma yaratishga imkon bermasa, bu muammo emas.
    ///
    /// Batafsil ma'lumot uchun ["pinning projections"]-dagi munozarani ko'ring.
    ///
    /// Note: `Pin` shuningdek, maqsadga ichki qiymatga kirish uchun ishlatilishi mumkin bo'lgan `Deref`-ni amalga oshiradi.
    /// Shu bilan birga, `Deref` `Pin` ning umri davomida emas, balki faqat `Pin` ning qarzigacha yashaydigan ma'lumotnomani taqdim etadi.
    /// Ushbu usul `Pin`-ni asl `Pin` bilan bir xil ishlash muddatiga mos yozuvlarga aylantirishga imkon beradi.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Ushbu `Pin<&mut T>` ni xuddi shu umrga ega bo'lgan `Pin<&T>` ga o'zgartiradi.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Ushbu `Pin` ichidagi ma'lumotlarga o'zgaruvchan mos yozuvlar oladi.
    ///
    /// Buning uchun ushbu `Pin` ichidagi ma'lumotlar `Unpin` bo'lishi kerak.
    ///
    /// Note: `Pin` ma'lumotlarga ichki qiymatga kirish uchun ishlatilishi mumkin bo'lgan `DerefMut`-ni ham amalga oshiradi.
    /// Shu bilan birga, `DerefMut` `Pin` ning umri davomida emas, balki faqat `Pin` ning qarzigacha yashaydigan ma'lumotnomani taqdim etadi.
    ///
    /// Ushbu usul `Pin`-ni asl `Pin` bilan bir xil ishlash muddatiga mos yozuvlarga aylantirishga imkon beradi.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Ushbu `Pin` ichidagi ma'lumotlarga o'zgaruvchan mos yozuvlar oladi.
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya xavfli.
    /// Siz ushbu funktsiyani chaqirganingizda hech qachon ma'lumotlarni o'zgaruvchan ma'lumotnomadan tashqariga chiqarmasligingizga kafolat berishingiz kerak, shunda `Pin` turidagi o'zgaruvchilar saqlanib qoladi.
    ///
    ///
    /// Agar asosiy ma'lumotlar `Unpin` bo'lsa, uning o'rniga `Pin::get_mut` ishlatilishi kerak.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Ichki qiymatni xaritalash orqali yangi pim tuzing.
    ///
    /// Masalan, siz biron bir narsaning maydonini `Pin` olishni xohlasangiz, ushbu satrga bitta kod satrida kirish uchun foydalanishingiz mumkin.
    /// Biroq, ushbu "pinning projections" bilan bir nechta gotchalar mavjud;
    /// ushbu mavzu bo'yicha batafsil ma'lumot uchun [`pin` module] hujjatlariga qarang.
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya xavfli.
    /// Siz qaytargan ma'lumotlar argument qiymati harakat qilmaguncha (masalan, bu qiymatning maydonlaridan biri bo'lganligi sababli) siljimasligiga, shuningdek siz olgan argumentdan tashqariga chiqmasligingizga kafolat berishingiz kerak. ichki funktsiya.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi telefonni harakatlantirmaslik uchun javobgardir
        // ushbu ma'lumotnomaning qiymati.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // XAVFSIZLIK: chunki `this` qiymati yo'qligi kafolatlanadi
        // ko'chirildi, `new_unchecked`-ga ushbu qo'ng'iroq xavfsizdir.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Statik ma'lumotnomadan mahkamlangan ma'lumotnomani oling.
    ///
    /// Bu xavfsizdir, chunki `T` hech qachon tugamaydigan `'static` umr bo'yi qarz oladi.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // XAVFSIZLIK: "Statik qarz" ma'lumotlar mavjud bo'lmasligini kafolatlaydi
        // moved/invalidated u tushguncha (bu hech qachon bo'lmaydi).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Statik o'zgaruvchan ma'lumotnomadan mahkamlangan o'zgaruvchan ma'lumotnomani oling.
    ///
    /// Bu xavfsizdir, chunki `T` hech qachon tugamaydigan `'static` umr bo'yi qarz oladi.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // XAVFSIZLIK: "Statik qarz" ma'lumotlar mavjud bo'lmasligini kafolatlaydi
        // moved/invalidated u tushguncha (bu hech qachon bo'lmaydi).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: bu majburlashga imkon beradigan har qanday `CoerceUnsized` implini anglatadi
// `Deref<Target=impl !Unpin>`-ni `Deref<Target=Unpin>`-ga qo'shadigan turga ishonish mumkin emas.
// Ehtimol, boshqa sabablarga ko'ra har qanday bunday imlossiz bo'lishi mumkin, shuning uchun biz shunchaki std ga tushishiga yo'l qo'ymaslik uchun ehtiyot bo'lishimiz kerak.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}