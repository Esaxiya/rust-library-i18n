use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Ushbu funktsiya bir joyda ishlatilgan bo'lsa va uni amalga oshirish mumkin bo'lsa, avvalgi urinishlar rustc-ni sekinlashtirdi:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Xotira blokining joylashuvi.
///
/// `Layout` misoli xotiraning ma'lum bir tartibini tavsiflaydi.
/// Siz `Layout`-ni ajratuvchiga berish uchun kirish sifatida yaratasiz.
///
/// Barcha maketlar bir-biriga mos o'lchamga va ikkitadan quvvatga mos keladigan hizalanishga ega.
///
/// (Shuni esda tutingki, `GlobalAlloc` barcha xotira so'rovlari nolga teng bo'lmagan hajmda bo'lishini talab qilsa ham, nolga teng bo'lmagan o'lchamlarga ega bo'lish uchun * tartiblar talab qilinmaydi.
/// Qo'ng'iroq qiluvchi ushbu kabi shartlarning bajarilishini ta'minlashi, yumshoq talablarga ega bo'lgan maxsus taqsimlovchilarni ishlatishi yoki yumshoqroq `Allocator` interfeysidan foydalanishi kerak.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // bayt bilan o'lchanadigan so'ralgan xotira blokining hajmi.
    size_: usize,

    // baytlarda o'lchanadigan so'ralgan xotira blokini tekislash.
    // biz buni har doim ikkitaning kuchi bo'lishini ta'minlaymiz, chunki API kabi `posix_memalign` buni talab qiladi va bu Layout konstruktorlariga yuklash uchun oqilona cheklovdir.
    //
    //
    // (Ammo, biz shunga o'xshash tarzda "align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) ni talab qilmaymiz
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Berilgan `size` va `align` dan `Layout` tuzadi yoki quyidagi shartlardan biri bajarilmasa `LayoutError` ni qaytaradi:
    ///
    /// * `align` nol bo'lmasligi kerak,
    ///
    /// * `align` ikkita kuch bo'lishi kerak,
    ///
    /// * `size`, `align` kataligiga qadar yaxlitlanganda toshib ketmasligi kerak (ya'ni yaxlitlangan qiymat `usize::MAX` dan kam yoki unga teng bo'lishi kerak).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (ikkitaning kuchi tenglashtirishni anglatadi!=0.)

        // Yumaloq o'lcham:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Yuqoridan bilamizki, hizalanish!=0.
        // Agar (hizalamak, 1) qo'shilmasa, yaxlitlash yaxshi bo'ladi.
        //
        // Aksincha, (bilan tekislang, 1) bilan&-masking faqat past tartibli bitlarni olib tashlaydi.
        // Shunday qilib, agar ortiqcha yig'indisi bilan sodir bo'lsa,&-mask ortiqcha to'ldirishni bekor qilish uchun etarlicha ayirolmaydi.
        //
        //
        // Yuqorida shuni ko'rsatadiki, yig'indidan oshib ketishini tekshirish ham zarur, ham etarli.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // XAVFSIZLIK: `from_size_align_unchecked` uchun shartlar mavjud edi
        // yuqorida tekshirilgan.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Barcha tekshiruvlarni chetlab o'tib, maket yaratadi.
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya xavfli emas, chunki u [`Layout::from_size_align`]-dan oldingi shartlarni tasdiqlamaydi.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `align` noldan katta bo'lishini ta'minlashi kerak.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Ushbu maketning xotira bloki uchun baytdagi minimal o'lcham.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Ushbu maketning xotira bloki uchun minimal baytlarni tekislash.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `T` turidagi qiymatni ushlab turish uchun mos `Layout` ni quradi.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // XAVFSIZLIK: hizalanish Rust tomonidan ikki va ning kuchiga ega bo'lishi kafolatlanadi
        // size + align combo bizning manzil maydonimizga mos kelishi kafolatlanadi.
        // Natijada panics kodini kiritishni oldini olish uchun tekshirilmagan konstruktordan foydalaning, agar u etarli darajada optimallashtirilmagan bo'lsa.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` uchun zaxira tuzilmasini ajratish uchun ishlatilishi mumkin bo'lgan yozuvni tavsiflovchi tartibni ishlab chiqaradi (bu trait yoki tilim kabi boshqa o'lchamsiz turi bo'lishi mumkin).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // XAVFSIZLIK: `new`-dagi mantiqiy asosga qarang, nima uchun bu xavfli variantni ishlatmoqda
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` uchun zaxira tuzilmasini ajratish uchun ishlatilishi mumkin bo'lgan yozuvni tavsiflovchi tartibni ishlab chiqaradi (bu trait yoki tilim kabi boshqa o'lchamsiz turi bo'lishi mumkin).
    ///
    /// # Safety
    ///
    /// Ushbu funktsiyani faqat quyidagi shartlar mavjud bo'lganda qo'ng'iroq qilish xavfsizdir:
    ///
    /// - Agar `T` `Sized` bo'lsa, bu funktsiya har doim qo'ng'iroq qilish uchun xavfsizdir.
    /// - Agar `T` o'lchamsiz dumi:
    ///     - [slice] bo'lsa, u holda tilim quyruqining uzunligi intializatsiya qilingan butun songa va *butun qiymat*(dinamik quyruq uzunligi + statik o'lchamdagi prefiks) kattaligi `isize` ga to'g'ri kelishi kerak.
    ///     - Agar [trait object] bo'lsa, u holda ko'rsatgichning vtable qismi o'lchamsiz koersion tomonidan olingan `T` turi uchun haqiqiy vtable-ga ishora qilishi kerak va *butun qiymat*(dinamik quyruq uzunligi + statik o'lchamdagi prefiks) hajmi `isize` ga to'g'ri kelishi kerak.
    ///
    ///     - (unstable) [extern type] bo'lsa, u holda bu funktsiya har doim qo'ng'iroq qilish uchun xavfsizdir, lekin panic yoki boshqa yo'l bilan noto'g'ri qiymatni qaytarishi mumkin, chunki tashqi tipning tuzilishi ma'lum emas.
    ///     Bu tashqi turdagi dumga murojaat qilishda [`Layout::for_value`] bilan bir xil xatti-harakatlar.
    ///     - aks holda, ushbu funktsiyani chaqirishga konservativ ravishda yo'l qo'yilmaydi.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // XAVFSIZLIK: biz ushbu funktsiyalarning old shartlari bo'yicha qo'ng'iroq qiluvchiga o'tamiz
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // XAVFSIZLIK: `new`-dagi mantiqiy asosga qarang, nima uchun bu xavfli variantni ishlatmoqda
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Osilib turgan, ammo ushbu Layout uchun yaxshi moslangan `NonNull` yaratadi.
    ///
    /// E'tibor bering, ko'rsatgich qiymati potentsial ravishda to'g'ri ko'rsatgichni ko'rsatishi mumkin, ya'ni bu "not yet initialized" qo'riqchisi qiymati sifatida ishlatilmasligi kerak.
    /// Dangasa ajratadigan turlar boshlang'ichni boshqa usullar bilan kuzatishi kerak.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // XAVFSIZLIK: tekislash nolga teng emasligi kafolatlanadi
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` bilan bir xil tartibdagi qiymatga ega bo'lishi mumkin bo'lgan yozuvni tavsiflovchi tartibni yaratadi, lekin u `align` (baytlarda o'lchanadigan) hizalanishga moslashtiriladi.
    ///
    ///
    /// Agar `self` allaqachon belgilangan hizalamaya javob bersa, u holda `self` qaytadi.
    ///
    /// Qaytgan tartib boshqa hizalanishga ega bo'lishidan qat'i nazar, ushbu usul umumiy hajmga hech qanday plomba qo'shmasligini unutmang.
    /// Boshqacha qilib aytganda, agar `K` 16 o'lchamga ega bo'lsa, `K.align_to(32)`*baribir* 16 o'lchamga ega bo'ladi.
    ///
    /// `self.size()` va berilgan `align` kombinatsiyasi [`Layout::from_size_align`] da keltirilgan shartlarni buzsa, xatolikni qaytaradi.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Quyidagi manzil `align` (bayt bilan o'lchangan) ga javob berishiga ishonch hosil qilish uchun `self` dan keyin to'ldirishimiz kerak bo'lgan plomba miqdorini qaytaradi.
    ///
    /// masalan, agar `self.size()` 9 bo'lsa, u holda `self.padding_needed_for(4)` 3 ni qaytaradi, chunki bu 4 qatorli manzilni olish uchun zarur bo'lgan to'ldirish baytlarining minimal soni (mos keladigan xotira bloki 4 qatorli manzildan boshlanadi).
    ///
    ///
    /// Ushbu funktsiyani qaytarish qiymati, agar `align` ikkinchisining kuchi bo'lmasa, hech qanday ma'noga ega emas.
    ///
    /// Qaytgan qiymatning foydaliligi `align`-dan ajratilgan xotiraning butun bloki uchun boshlang'ich manzilning hizalanmasından kam yoki teng bo'lishini talab qiladi.Ushbu cheklovni qondirishning bir usuli-`align <= self.align()` ni ta'minlash.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Yumaloq qiymat:
        //   len_rounded_up=(len + align, 1)&! (hizalamak, 1);
        // va keyin biz to'ldirilgan farqni qaytaramiz: `len_rounded_up - len`.
        //
        // Biz modulli arifmetikadan quyidagicha foydalanamiz:
        //
        // 1. align> 0 bo'lishi kafolatlanadi, shuning uchun hizalanish, 1 har doim amal qiladi.
        //
        // 2.
        // `len + align - 1` ko'pi bilan `align - 1` ga oshib ketishi mumkin, shuning uchun `!(align - 1)` bilan&-mask, ortiqcha bo'lsa, `len_rounded_up` ning o'zi 0 bo'lishini ta'minlaydi.
        //
        //    Shunday qilib, qaytarilgan plomba, `len` ga qo'shilganda, 0 hosil qiladi, bu esa `align` tekislanishini ahamiyatsiz qondiradi.
        //
        // (Albatta, hajmi va to'ldirilishi yuqoridagi tarzda to'ldirilgan xotira bloklarini ajratishga urinishlar, baribir, ajratuvchida xatolikka yo'l qo'yishi mumkin.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Ushbu maketning o'lchamlarini maketning ko'p hizalanishiga qadar yaxlitlash orqali maket yaratadi.
    ///
    ///
    /// Bu `padding_needed_for` natijasini maketning joriy hajmiga qo'shishga teng.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Bu toshib bo'lmaydi.Layout invariantidan iqtibos:
        // > `size`, `align` ning eng yaqin multiplikatoriga yaxlitlanganda,
        // > toshib ketmasligi kerak (ya'ni yaxlitlangan qiymatdan kam bo'lishi kerak)
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` ning `n` nusxalari uchun yozuvni tavsiflovchi tartibni yaratadi va har bir nusxaning kerakli o'lchamlari va hizalanishini ta'minlash uchun har biri o'rtasida mos miqdordagi plomba mavjud.
    /// Muvaffaqiyatli bo'lsa, `(k, offs)` qaytadi, bu erda `k`-bu massivning joylashuvi va `offs`-bu har bir elementning boshlanishi orasidagi masofa.
    ///
    /// Arifmetik toshib ketganda, `LayoutError` qaytadi.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Bu toshib bo'lmaydi.Layout invariantidan iqtibos:
        // > `size`, `align` ning eng yaqin multiplikatoriga yaxlitlanganda,
        // > toshib ketmasligi kerak (ya'ni yaxlitlangan qiymatdan kam bo'lishi kerak)
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // XAVFSIZLIK: self.align allaqachon haqiqiy ekanligi ma'lum va ajratish_size bo'lgan
        // allaqachon to'ldirilgan.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` uchun yozuvni tavsiflovchi tartibni yaratadi, so'ngra `next`, shu jumladan `next` to'g'ri hizalanishini ta'minlash uchun zarur bo'lgan plomba, lekin *oxirgi to'ldirish yo'q*.
    ///
    /// C vakolatxonasi `repr(C)`-ga mos kelish uchun barcha maydonlarni kengaytirgandan so'ng `pad_to_align` raqamiga qo'ng'iroq qilishingiz kerak.
    /// (Standart Rust vakolatxonasi `repr(Rust)`, as it is unspecified.)-ga mos keladigan hech qanday usul yo'q
    ///
    /// Ikkala qismning hizalanishini ta'minlash uchun, natijada joylashtirilgan tartibni maksimal darajada `self` va `next` darajalariga tenglashtirishga e'tibor bering.
    ///
    /// `Ok((k, offset))`-ni qaytaradi, bu erda `k`-bu biriktirilgan yozuvning joylashuvi va `offset`-bu mos yozuvlar ichiga o'rnatilgan `next` boshlanishining nisbiy joylashuvi (baytning o'zi 0 ofsetdan boshlanadi).
    ///
    ///
    /// Arifmetik toshib ketganda, `LayoutError` qaytadi.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` strukturasining joylashishini va maydonlarning joylarini uning maydonlarining sxemalaridan hisoblash uchun:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` bilan yakunlashni unutmang!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // uning ishlashini sinab ko'ring
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` ning `n` nusxalari uchun yozuvni tavsiflovchi tartibni yaratadi, har bir nusxa o'rtasida hech qanday to'ldirish bo'lmaydi.
    ///
    /// Shuni yodda tutingki, `repeat` dan farqli o'laroq, `repeat_packed`, `self` ning takrorlangan nusxalari to'g'ri hizalanishiga kafolat bermaydi, hatto `self` ning bir nusxasi to'g'ri hizalanmış bo'lsa ham.
    /// Boshqacha qilib aytganda, agar `repeat_packed` tomonidan qaytarilgan tartib massivni ajratish uchun ishlatilsa, massivdagi barcha elementlarning to'g'ri hizalanishi kafolatlanmaydi.
    ///
    /// Arifmetik toshib ketganda, `LayoutError` qaytadi.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self` uchun yozuvni tavsiflovchi tartibni yaratadi, so'ngra `next` o'rtasida ikkala qo'shimcha plomba yo'q.
    /// Hech qanday plomba kiritilmaganligi sababli, `next`-ning tekislashi ahamiyatsiz va natijada *umuman* kiritilmagan.
    ///
    ///
    /// Arifmetik toshib ketganda, `LayoutError` qaytadi.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` uchun yozuvni tavsiflovchi maket yaratadi.
    ///
    /// Arifmetik toshib ketganda, `LayoutError` qaytadi.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` yoki boshqa biron bir `Layout` konstruktoriga berilgan parametrlar uning hujjatlashtirilgan cheklovlarini qondirmaydi.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (biz buni trait xatosining pastki oqimi uchun kerak)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}