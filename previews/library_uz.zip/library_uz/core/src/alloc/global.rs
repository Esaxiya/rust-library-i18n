use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// `#[global_allocator]` atributi orqali standart kutubxonaning standart qiymati sifatida ro'yxatdan o'tkazilishi mumkin bo'lgan xotira ajratuvchisi.
///
/// Ba'zi usullar xotira blokini *hozirda ajratuvchi orqali ajratilishini* talab qiladi.Bu shuni anglatadiki:
///
/// * ushbu xotira blokining boshlang'ich manzili avvalgi qo'ng'iroq bilan `alloc` kabi ajratish uslubiga qaytarilgan va
///
/// * keyinchalik xotira bloki taqsimlanmagan, bu erda bloklar `dealloc` kabi taqsimlash uslubiga o'tish yoki nolga teng bo'lmagan ko'rsatkichni qaytaradigan qayta taqsimlash uslubiga o'tish orqali taqsimlanadi.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait bir necha sabablarga ko'ra `unsafe` trait hisoblanadi va dasturlar ushbu shartnomalarga rioya qilishlarini ta'minlashi kerak:
///
/// * Agar global ajratuvchilar bo'shashsa, bu aniqlanmagan xatti-harakatlar.Ushbu cheklov future-da bekor qilinishi mumkin, ammo hozirda ushbu funktsiyalarning har qandayidan panic xotiraning xavfsizligiga olib kelishi mumkin.
///
/// * `Layout` so'rovlar va umuman hisob-kitoblar to'g'ri bo'lishi kerak.Ushbu trait-ning qo'ng'iroqchilariga har bir usul bo'yicha belgilangan shartnomalarga tayanishga ruxsat beriladi va ijrochilar bunday shartnomalarning haqiqiyligini ta'minlashi kerak.
///
/// * Manbada aniq yig'ma ajratmalar mavjud bo'lsa ham, siz aslida bo'linmalarga ishonishingiz mumkin emas.
/// Optimizator foydalanilmaydigan ajratmalarni aniqlab olishi mumkin, bu ularni butunlay yo'q qilishi yoki stekka o'tishi mumkin va shuning uchun hech qachon ajratuvchini chaqirmaydi.
/// Optimizator ajratishni xatosiz deb o'ylashi mumkin, shuning uchun ilgari ajratgichning ishlamay qolishi sababli ishlamay qolgan kod endi to'satdan ishlashi mumkin, chunki optimallashtiruvchi ajratish zarurati atrofida ishlagan.
/// Aniqroq qilib aytganda, quyidagi kod misoli, sizning xususiy taqsimlagichingiz qancha ajratilganligini hisoblashga imkon berishidan qat'iy nazar, asossizdir.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Yuqorida aytib o'tilgan optimallashtirishlarni qo'llash mumkin bo'lgan yagona optimallash emasligini unutmang.Odatda, agar ular dasturning harakatini o'zgartirmasdan olib tashlanishi mumkin bo'lsa, siz uyum ajratmalariga ishonishingiz mumkin emas.
///   Ajratishlarning sodir bo'lishi yoki bo'lmasligi dastur xatti-harakatining bir qismi emas, hatto uni ajratish vositalarini bosib chiqarish orqali kuzatadigan yoki boshqa ta'sir ko'rsatadigan ajratuvchi orqali aniqlanishi mumkin.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Berilgan `layout` tomonidan ta'riflanganidek, xotirani ajrating.
    ///
    /// Belgilagichni yangi ajratilgan xotiraga qaytaradi yoki ajratish xatoligini ko'rsatish uchun null qiymatini beradi.
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya xavfli emas, chunki agar qo'ng'iroq qiluvchi `layout`-ning nolga teng bo'lmagan o'lchamiga ishonch hosil qilmasa, aniqlanmagan xatti-harakatlar paydo bo'lishi mumkin.
    ///
    /// (Kengaytirilgan subtraitlar xatti-harakatlarga nisbatan aniqroq chegaralarni taqdim etishi mumkin, masalan, nol o'lchamdagi ajratish so'roviga javoban qo'riqchi manzili yoki nol ko'rsatkichni kafolatlash.)
    ///
    /// Xotiraning ajratilgan bloki ishga tushirilishi mumkin yoki bo'lmasligi mumkin.
    ///
    /// # Errors
    ///
    /// Nol ko'rsatkichni qaytarish, xotira tugaganligini yoki `layout` ushbu ajratuvchining o'lchamiga yoki tekislash cheklovlariga javob bermasligini ko'rsatadi.
    ///
    /// Amalga oshirish abort qilishdan ko'ra xotirani charchashga qaytarish tavsiya etiladi, ammo bu qat'iy talab emas.
    /// (Xususan: ushbu trait-ni xotira tugashini to'xtatadigan asosiy mahalliy ajratish kutubxonasi ustida amalga oshirish * qonuniydir.)
    ///
    /// Ajratish xatosiga javoban hisobni bekor qilishni istagan mijozlarga to'g'ridan-to'g'ri `panic!` yoki shunga o'xshashlarni chaqirish o'rniga, [`handle_alloc_error`] funktsiyasini chaqirish tavsiya etiladi.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// `ptr` ko'rsatkichidagi xotira blokini berilgan `layout` bilan taqsimlang.
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya xavfli emas, chunki agar qo'ng'iroq qiluvchi quyidagilarning barchasini ta'minlamasa, aniqlanmagan xatti-harakatlar paydo bo'lishi mumkin.
    ///
    ///
    /// * `ptr` hozirda ushbu ajratuvchi orqali ajratilgan xotira blokini ko'rsatishi kerak,
    ///
    /// * `layout` ushbu xotira blokini ajratish uchun ishlatilgan tartib bo'lishi kerak.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// `alloc` kabi o'zini tutadi, lekin qaytarilishdan oldin tarkibni nolga o'rnatilishini ta'minlaydi.
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya `alloc` bilan bir xil sabablarga ko'ra xavfli hisoblanadi.
    /// Ammo ajratilgan xotira blokini ishga tushirish kafolatlanadi.
    ///
    /// # Errors
    ///
    /// Nol ko'rsatkichni qaytarish shuni anglatadiki, xotira tugagan yoki `layout` xuddi `alloc` da bo'lgani kabi, ajratuvchining o'lchamiga yoki tekislash cheklovlariga javob bermaydi.
    ///
    /// Ajratish xatosiga javoban hisobni bekor qilishni istagan mijozlarga to'g'ridan-to'g'ri `panic!` yoki shunga o'xshashlarni chaqirish o'rniga, [`handle_alloc_error`] funktsiyasini chaqirish tavsiya etiladi.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // XAVFSIZLIK: `alloc` uchun xavfsizlik shartnomasi qo'ng'iroq qiluvchi tomonidan bajarilishi kerak.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // XAVFSIZLIK: `ptr`-dan ajratish muvaffaqiyatli amalga oshirildi
            // `size` o'lchamdagi yozuvlar uchun haqiqiy ekanligi kafolatlanadi.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Berilgan `new_size`-ga xotira blokini qisqartiring yoki kattalashtiring.
    /// Blok berilgan `ptr` ko'rsatkichi va `layout` bilan tavsiflanadi.
    ///
    /// Agar bu nol bo'lmagan ko'rsatkichni qaytarsa, `ptr` tomonidan havola qilingan xotira blokiga egalik huquqi ushbu ajratuvchiga o'tkazilgan.
    /// Xotira ajratilgan yoki bo'linmagan bo'lishi mumkin va uni yaroqsiz deb hisoblash kerak (agar u ushbu usulning qaytish qiymati orqali yana qo'ng'iroq qiluvchiga qaytarib berilmagan bo'lsa).
    /// Yangi xotira bloki `layout` bilan ajratilgan, ammo `size` `new_size` ga yangilangan.
    /// Ushbu yangi tartib `dealloc` bilan yangi xotira blokini ajratishda ishlatilishi kerak.
    /// Yangi xotira blokining `0..min(layout.size(), new_size) `oralig'i asl blok bilan bir xil qiymatlarga ega bo'lishiga kafolat beradi.
    ///
    /// Agar bu usul null qiymatni qaytarsa, unda xotira blokiga egalik huquqi ushbu ajratuvchiga o'tkazilmagan va xotira blokining tarkibi o'zgarmagan.
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya xavfli emas, chunki agar qo'ng'iroq qiluvchi quyidagilarning barchasini ta'minlamasa, aniqlanmagan xatti-harakatlar paydo bo'lishi mumkin.
    ///
    /// * `ptr` hozirda ushbu ajratuvchi orqali ajratilishi kerak,
    ///
    /// * `layout` ushbu xotira blokini ajratish uchun ishlatilgan tartib bo'lishi kerak,
    ///
    /// * `new_size` noldan katta bo'lishi kerak.
    ///
    /// * `new_size`, `layout.align()` ning eng yaqin multiplikatorigacha yaxlitlanganda, toshib ketmasligi kerak (ya'ni yaxlitlangan qiymat `usize::MAX` dan kam bo'lishi kerak).
    ///
    /// (Kengaytirilgan subtraitlar xatti-harakatlarga nisbatan aniqroq chegaralarni taqdim etishi mumkin, masalan, nol o'lchamdagi ajratish so'roviga javoban qo'riqchi manzili yoki nol ko'rsatkichni kafolatlash.)
    ///
    /// # Errors
    ///
    /// Agar yangi tartib taqsimlovchining o'lchamlari va tekislash cheklovlariga javob bermasa yoki aks holda qayta taqsimlash muvaffaqiyatsiz bo'lsa, null qiymatini qaytaradi.
    ///
    /// Amalga oshirilgan choralar vahima yoki abort qilishdan ko'ra xotiraning charchagan holatiga qaytishga da'vat etiladi, ammo bu qat'iy talab emas.
    /// (Xususan: ushbu trait-ni xotira tugashini to'xtatadigan asosiy mahalliy ajratish kutubxonasi ustida amalga oshirish * qonuniydir.)
    ///
    /// Qayta taqsimlash xatosiga javoban hisobni bekor qilishni istagan mijozlar to'g'ridan-to'g'ri `panic!` yoki shunga o'xshashlarni chaqirish o'rniga, [`handle_alloc_error`] funktsiyasini chaqirishlari tavsiya qilinadi.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `new_size` ning to'kilmasligini ta'minlashi kerak.
        // `layout.align()` `Layout`-dan keladi va shu sababli uning amal qilishiga kafolat beriladi.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `new_layout` noldan katta bo'lishini ta'minlashi kerak.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // XAVFSIZLIK: ilgari ajratilgan blok yangi ajratilgan blok bilan qoplana olmaydi.
            // `dealloc` uchun xavfsizlik shartnomasini chaqiruvchi qo'llab-quvvatlashi kerak.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}