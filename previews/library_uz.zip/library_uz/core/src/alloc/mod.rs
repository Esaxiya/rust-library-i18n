//! Xotirani ajratish API-lari

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` xatosi ajratish qobiliyatsizligini ko'rsatishi mumkin, bu resursning tugashi yoki ushbu ajratuvchi bilan berilgan kirish argumentlarini birlashtirganda noto'g'ri bo'lishi mumkin.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (biz buni trait xatosining pastki oqimi uchun kerak)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` dasturini [`Layout`][] orqali tavsiflangan ma'lumotlarning o'zboshimchalik bloklarini ajratish, kattalashtirish, qisqartirish va taqsimlash mumkin.
///
/// `Allocator` ZST-larda, ma'lumotnomalarda yoki aqlli ko'rsatgichlarda bajarilishi uchun ishlab chiqilgan, chunki `MyAlloc([u8; N])` singari ajratgichni ajratilgan xotiraga yangilamasdan, ko'chirish mumkin emas.
///
/// [`GlobalAlloc`][]-dan farqli o'laroq, `Allocator`-da nol o'lchamdagi ajratmalarga ruxsat beriladi.
/// Agar asosiy ajratuvchi buni qo'llab-quvvatlamasa (masalan, jemalloc) yoki bo'sh ko'rsatgichni qaytarsa (masalan, `libc::malloc`), uni amalga oshirish kerak.
///
/// ### Hozirda ajratilgan xotira
///
/// Ba'zi usullar xotira blokini *hozirda ajratuvchi orqali ajratilishini* talab qiladi.Bu shuni anglatadiki:
///
/// * ushbu xotira blokining boshlang'ich manzili avval [`allocate`], [`grow`] yoki [`shrink`] tomonidan qaytarilgan va
///
/// * keyinchalik xotira bloki taqsimlanmagan, bu erda bloklar to'g'ridan-to'g'ri [`deallocate`] ga o'tish orqali taqsimlanadi yoki `Ok` ni qaytaradigan [`grow`] yoki [`shrink`] ga o'tkazilib o'zgartiriladi.
///
/// Agar `grow` yoki `shrink` `Err` ni qaytargan bo'lsa, o'tgan ko'rsatkich amal qiladi.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Xotira moslamasi
///
/// Ba'zi usullar uchun tartib *xotira blokiga* mos kelishini talab qiladi.
/// "fit" formatidagi xotira blokining ma'nosi (yoki shunga o'xshash tarzda, "fit" xotira bloki uchun maket) degani, quyidagi shartlar bajarilishi kerak:
///
/// * Blokni [`layout.align()`] bilan bir xil yo'nalishda ajratish kerak va
///
/// * Taqdim etilgan [`layout.size()`] `min ..= max` oralig'iga to'g'ri kelishi kerak, bu erda:
///   - `min` blokni taqsimlash uchun eng so'nggi ishlatilgan tartib hajmi va
///   - `max` [`allocate`], [`grow`] yoki [`shrink`] dan qaytarilgan eng so'nggi haqiqiy o'lchamdir.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Distribyutordan qaytarilgan xotira bloklari yaroqli xotiraga ishora qilishi va nusxa va uning barcha klonlari tushguncha o'z kuchini saqlab turishi kerak,
///
/// * klonlash yoki ajratuvchini siljitish ushbu ajratuvchidan qaytarilgan xotira bloklarini bekor qilmasligi kerak.Klonlangan ajratuvchi xuddi shu ajratuvchi singari o'zini tutishi kerak va
///
/// * [*currently allocated*] bo'lgan xotira blokidagi har qanday ko'rsatgich ajratgichning boshqa har qanday usuliga o'tkazilishi mumkin.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Xotira blokini ajratishga urinishlar.
    ///
    /// Muvaffaqiyatli bo'lganida, `layout` o'lchamlari va tekislash kafolatlariga javob beradigan [`NonNull<[u8]>`][NonNull] qaytariladi.
    ///
    /// Qaytgan blok `layout.size()` tomonidan belgilanganidan kattaroq hajmga ega bo'lishi mumkin va uning tarkibi boshlangan bo'lishi mumkin yoki bo'lmasligi mumkin.
    ///
    /// # Errors
    ///
    /// `Err`-ni qaytarish shuni ko'rsatadiki, xotira tugagan yoki `layout` ajratuvchi o'lchamiga yoki tekislash cheklovlariga javob bermaydi.
    ///
    /// Amalga oshirilgan choralar vahima yoki abort qilish o'rniga `Err` xotirani charchashga qaytarish uchun tavsiya etiladi, ammo bu qat'iy talab emas.
    /// (Xususan: ushbu trait-ni xotira tugashini to'xtatadigan asosiy mahalliy ajratish kutubxonasi ustida amalga oshirish * qonuniydir.)
    ///
    /// Ajratish xatosiga javoban hisobni bekor qilishni istagan mijozlarga to'g'ridan-to'g'ri `panic!` yoki shunga o'xshashlarni chaqirish o'rniga, [`handle_alloc_error`] funktsiyasini chaqirish tavsiya etiladi.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` kabi o'zini tutadi, lekin qaytarilgan xotiraning nol-boshlanishini ta'minlaydi.
    ///
    /// # Errors
    ///
    /// `Err`-ni qaytarish shuni ko'rsatadiki, xotira tugagan yoki `layout` ajratuvchi o'lchamiga yoki tekislash cheklovlariga javob bermaydi.
    ///
    /// Amalga oshirilgan choralar vahima yoki abort qilish o'rniga `Err` xotirani charchashga qaytarish uchun tavsiya etiladi, ammo bu qat'iy talab emas.
    /// (Xususan: ushbu trait-ni xotira tugashini to'xtatadigan asosiy mahalliy ajratish kutubxonasi ustida amalga oshirish * qonuniydir.)
    ///
    /// Ajratish xatosiga javoban hisobni bekor qilishni istagan mijozlarga to'g'ridan-to'g'ri `panic!` yoki shunga o'xshashlarni chaqirish o'rniga, [`handle_alloc_error`] funktsiyasini chaqirish tavsiya etiladi.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // XAVFSIZLIK: `alloc` tegishli xotira blokini qaytaradi
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` tomonidan havola qilingan xotirani taqsimlaydi.
    ///
    /// # Safety
    ///
    /// * `ptr` ushbu ajratuvchi orqali [*currently allocated*] xotira blokini belgilashi kerak va
    /// * `layout` bu xotira bloki [*fit*] bo'lishi kerak.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Xotira blokini kengaytirishga urinishlar.
    ///
    /// Ko'rsatkich va ajratilgan xotiraning haqiqiy hajmini o'z ichiga olgan yangi [`NonNull<[u8]>`][NonNull]-ni qaytaradi.Ko'rsatkich `new_layout` tomonidan tavsiflangan ma'lumotlarni saqlash uchun javob beradi.
    /// Buni amalga oshirish uchun ajratuvchi `ptr` tomonidan havola qilingan ajratishni yangi tartibga mos ravishda kengaytirishi mumkin.
    ///
    /// Agar bu `Ok` ni qaytaradigan bo'lsa, unda `ptr` tomonidan havola qilingan xotira blokiga egalik huquqi ushbu ajratuvchiga o'tkazilgan.
    /// Xotira bo'shatilgan bo'lishi mumkin yoki bo'lmasligi mumkin va agar u ushbu usulning qaytish qiymati orqali qayta qo'ng'iroq qiluvchiga qaytarilmasa, uni yaroqsiz deb hisoblash kerak.
    ///
    /// Agar bu usul `Err` ni qaytaradigan bo'lsa, unda xotira blokiga egalik huquqi ushbu ajratuvchiga o'tkazilmagan va xotira blokining tarkibi o'zgarmagan.
    ///
    /// # Safety
    ///
    /// * `ptr` ushbu ajratuvchi orqali [*currently allocated*] xotira blokini belgilashi kerak.
    /// * `old_layout` xotira bloki [*fit*] bo'lishi kerak (`new_layout` argumenti unga mos kelmasligi kerak.)
    /// * `new_layout.size()` `old_layout.size()` dan katta yoki unga teng bo'lishi kerak.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err`-ni qaytaradi, agar yangi tartib taqsimlovchining o'lchamiga va ajratuvchining cheklovlariga javob bermasa yoki boshqa yo'l bilan o'sish ishlamasa.
    ///
    /// Amalga oshirilgan choralar vahima yoki abort qilish o'rniga `Err` xotirani charchashga qaytarish uchun tavsiya etiladi, ammo bu qat'iy talab emas.
    /// (Xususan: ushbu trait-ni xotira tugashini to'xtatadigan asosiy mahalliy ajratish kutubxonasi ustida amalga oshirish * qonuniydir.)
    ///
    /// Ajratish xatosiga javoban hisobni bekor qilishni istagan mijozlarga to'g'ridan-to'g'ri `panic!` yoki shunga o'xshashlarni chaqirish o'rniga, [`handle_alloc_error`] funktsiyasini chaqirish tavsiya etiladi.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // XAVFSIZLIK: chunki `new_layout.size()` kattaroq yoki teng bo'lishi kerak
        // `old_layout.size()`, eski va yangi xotira ajratish `old_layout.size()` bayt uchun o'qish va yozish uchun amal qiladi.
        // Bundan tashqari, eski ajratish hali taqsimlanmaganligi sababli, u `new_ptr` bilan qoplanishi mumkin emas.
        // Shunday qilib, `copy_nonoverlapping`-ga qo'ng'iroq xavfsizdir.
        // `dealloc` uchun xavfsizlik shartnomasini chaqiruvchi qo'llab-quvvatlashi kerak.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` kabi o'zini tutadi, lekin qaytarilguncha yangi tarkib nolga o'rnatilishini ta'minlaydi.
    ///
    /// Muvaffaqiyatli qo'ng'iroqdan so'ng xotira bloki quyidagi tarkibni o'z ichiga oladi
    /// `grow_zeroed`:
    ///   * `0..old_layout.size()` baytlari asl taqsimotdan saqlanib qolgan.
    ///   * `old_layout.size()..old_size` baytlari, saqlovchining bajarilishiga qarab saqlanib qoladi yoki nolga teng bo'ladi.
    ///   `old_size` `grow_zeroed` chaqiruvidan oldin xotira blokining hajmiga ishora qiladi, u ajratilganda dastlab talab qilingan hajmdan kattaroq bo'lishi mumkin.
    ///   * `old_size..new_size` baytlari nolga teng.`new_size`, `grow_zeroed` chaqiruvi bilan qaytarilgan xotira blokining hajmini anglatadi.
    ///
    /// # Safety
    ///
    /// * `ptr` ushbu ajratuvchi orqali [*currently allocated*] xotira blokini belgilashi kerak.
    /// * `old_layout` xotira bloki [*fit*] bo'lishi kerak (`new_layout` argumenti unga mos kelmasligi kerak.)
    /// * `new_layout.size()` `old_layout.size()` dan katta yoki unga teng bo'lishi kerak.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err`-ni qaytaradi, agar yangi tartib taqsimlovchining o'lchamiga va ajratuvchining cheklovlariga javob bermasa yoki boshqa yo'l bilan o'sish ishlamasa.
    ///
    /// Amalga oshirilgan choralar vahima yoki abort qilish o'rniga `Err` xotirani charchashga qaytarish uchun tavsiya etiladi, ammo bu qat'iy talab emas.
    /// (Xususan: ushbu trait-ni xotira tugashini to'xtatadigan asosiy mahalliy ajratish kutubxonasi ustida amalga oshirish * qonuniydir.)
    ///
    /// Ajratish xatosiga javoban hisobni bekor qilishni istagan mijozlarga to'g'ridan-to'g'ri `panic!` yoki shunga o'xshashlarni chaqirish o'rniga, [`handle_alloc_error`] funktsiyasini chaqirish tavsiya etiladi.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // XAVFSIZLIK: chunki `new_layout.size()` kattaroq yoki teng bo'lishi kerak
        // `old_layout.size()`, eski va yangi xotira ajratish `old_layout.size()` bayt uchun o'qish va yozish uchun amal qiladi.
        // Bundan tashqari, eski ajratish hali taqsimlanmaganligi sababli, u `new_ptr` bilan qoplanishi mumkin emas.
        // Shunday qilib, `copy_nonoverlapping`-ga qo'ng'iroq xavfsizdir.
        // `dealloc` uchun xavfsizlik shartnomasini chaqiruvchi qo'llab-quvvatlashi kerak.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Xotira blokini qisqartirishga urinishlar.
    ///
    /// Ko'rsatkich va ajratilgan xotiraning haqiqiy hajmini o'z ichiga olgan yangi [`NonNull<[u8]>`][NonNull]-ni qaytaradi.Ko'rsatkich `new_layout` tomonidan tavsiflangan ma'lumotlarni saqlash uchun javob beradi.
    /// Buni amalga oshirish uchun ajratuvchi `ptr` tomonidan havola qilingan ajratishni yangi maketga moslashtirishi mumkin.
    ///
    /// Agar bu `Ok` ni qaytaradigan bo'lsa, unda `ptr` tomonidan havola qilingan xotira blokiga egalik huquqi ushbu ajratuvchiga o'tkazilgan.
    /// Xotira bo'shatilgan bo'lishi mumkin yoki bo'lmasligi mumkin va agar u ushbu usulning qaytish qiymati orqali qayta qo'ng'iroq qiluvchiga qaytarilmasa, uni yaroqsiz deb hisoblash kerak.
    ///
    /// Agar bu usul `Err` ni qaytaradigan bo'lsa, unda xotira blokiga egalik huquqi ushbu ajratuvchiga o'tkazilmagan va xotira blokining tarkibi o'zgarmagan.
    ///
    /// # Safety
    ///
    /// * `ptr` ushbu ajratuvchi orqali [*currently allocated*] xotira blokini belgilashi kerak.
    /// * `old_layout` xotira bloki [*fit*] bo'lishi kerak (`new_layout` argumenti unga mos kelmasligi kerak.)
    /// * `new_layout.size()` `old_layout.size()` dan kichik yoki unga teng bo'lishi kerak.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err`-ni qaytaradi, agar yangi tartib taqsimlovchining o'lchamiga va ajratuvchining cheklovlariga mos kelmasa yoki boshqa yo'l bilan qisqarish muvaffaqiyatsiz tugasa.
    ///
    /// Amalga oshirilgan choralar vahima yoki abort qilish o'rniga `Err` xotirani charchashga qaytarish uchun tavsiya etiladi, ammo bu qat'iy talab emas.
    /// (Xususan: ushbu trait-ni xotira tugashini to'xtatadigan asosiy mahalliy ajratish kutubxonasi ustida amalga oshirish * qonuniydir.)
    ///
    /// Ajratish xatosiga javoban hisobni bekor qilishni istagan mijozlarga to'g'ridan-to'g'ri `panic!` yoki shunga o'xshashlarni chaqirish o'rniga, [`handle_alloc_error`] funktsiyasini chaqirish tavsiya etiladi.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // XAVFSIZLIK: chunki `new_layout.size()` undan past yoki unga teng bo'lishi kerak
        // `old_layout.size()`, eski va yangi xotira ajratish `new_layout.size()` bayt uchun o'qish va yozish uchun amal qiladi.
        // Bundan tashqari, eski ajratish hali taqsimlanmaganligi sababli, u `new_ptr` bilan qoplanishi mumkin emas.
        // Shunday qilib, `copy_nonoverlapping`-ga qo'ng'iroq xavfsizdir.
        // `dealloc` uchun xavfsizlik shartnomasini chaqiruvchi qo'llab-quvvatlashi kerak.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ushbu `Allocator` misoli uchun "by reference" adapterini yaratadi.
    ///
    /// Qaytgan adapter `Allocator`-ni ham amalga oshiradi va shunchaki qarz oladi.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // XAVFSIZLIK: xavfsizlik shartnomasi qo'ng'iroq qiluvchi tomonidan bajarilishi kerak
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // XAVFSIZLIK: xavfsizlik shartnomasi qo'ng'iroq qiluvchi tomonidan bajarilishi kerak
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // XAVFSIZLIK: xavfsizlik shartnomasi qo'ng'iroq qiluvchi tomonidan bajarilishi kerak
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // XAVFSIZLIK: xavfsizlik shartnomasi qo'ng'iroq qiluvchi tomonidan bajarilishi kerak
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}