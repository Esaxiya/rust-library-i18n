use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Kompilyatorni "T" destruktorini avtomatik ravishda chaqirishga xalaqit beradigan o'rash.
/// Ushbu o'ram 0 narxga ega.
///
/// `ManuallyDrop<T>` `T` kabi tartibni optimallashtirishga bo'ysunadi.
/// Natijada, kompilyator uning tarkibi haqidagi taxminlariga *hech qanday ta'sir qilmaydi*.
/// Masalan, `ManuallyDrop<&mut T>`-ni [`mem::zeroed`] bilan boshlash aniqlanmagan xatti-harakatlardir.
/// Agar sizga boshlang'ich ma'lumotlarini ishlatishingiz kerak bo'lsa, uning o'rniga [`MaybeUninit<T>`] dan foydalaning.
///
/// `ManuallyDrop<T>` ichidagi qiymatga kirish xavfsizligini unutmang.
/// Bu shuni anglatadiki, tarkibi tushirilgan `ManuallyDrop<T>` ommaviy xavfsiz API orqali ta'sirlanmasligi kerak.
/// Shunga mos ravishda, `ManuallyDrop::drop` xavfli emas.
///
/// # `ManuallyDrop` va buyurtmani qoldiring.
///
/// Rust aniqlangan [drop order] qiymatlariga ega.
/// Maydonlar yoki mahalliy aholi ma'lum bir tartibda tashlanganligiga ishonch hosil qilish uchun deklaratsiyalarni tartibsiz tartibda joylashtiring, shunday qilib yopiq tushirish tartibi to'g'ri bo'ladi.
///
/// Tushirish tartibini boshqarish uchun `ManuallyDrop` dan foydalanish mumkin, ammo bu xavfli kodni talab qiladi va bo'shashish mavjud bo'lganda uni to'g'ri bajarish qiyin.
///
///
/// Masalan, agar ma'lum bir maydon boshqalardan keyin tashlanganligiga ishonch hosil qilishni xohlasangiz, uni strukturaning so'nggi maydoniga aylantiring:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` dan keyin tushadi.
///     // Rust deklaratsiya tartibida maydonlar tushirilishini kafolatlaydi.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Qo'lda tushirish uchun qiymatni o'rash.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Siz hali ham qiymat bo'yicha xavfsiz ishlashingiz mumkin
    /// assert_eq!(*x, "Hello");
    /// // Ammo `Drop` bu erda ishlamaydi
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` konteyneridan qiymat ajratib olinadi.
    ///
    /// Bu qiymatni yana tushirishga imkon beradi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Bu `Box` tushadi.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` konteyneridagi qiymatni chiqaradi.
    ///
    /// Ushbu usul birinchi navbatda qiymatlarni tomchilatib ko'chirish uchun mo'ljallangan.
    /// Qiymatni qo'lda tushirish uchun [`ManuallyDrop::drop`] dan foydalanish o'rniga, ushbu usul yordamida qiymatni olish va kerakli darajada ishlatish mumkin.
    ///
    /// Mumkin bo'lgan taqdirda, uning o'rniga [`into_inner`][`ManuallyDrop::into_inner`] dan foydalanish afzalroqdir, bu `ManuallyDrop<T>` tarkibini takrorlashni oldini oladi.
    ///
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya tarkibidagi qiymatni semantik ravishda keyingi foydalanishga xalaqit bermaydi va shu idishni holatini o'zgarmaydi.
    /// Ushbu `ManuallyDrop`-ning qayta ishlatilmasligini ta'minlash sizning javobgarligingizdir.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // XAVFSIZLIK: biz ma'lumotnomadan o'qiymiz, bu kafolatlangan
        // o'qish uchun yaroqli bo'lishi.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Tarkibiy qiymatni qo'lda tushiradi.Bu [`ptr::drop_in_place`]-ni ko'rsatilgan qiymatga ko'rsatgich bilan chaqirishga to'liq tengdir.
    /// Shunday qilib, agar mavjud qiymat to'plamli tuzilma bo'lmasa, destruktor qiymatni o'zgartirmasdan joyida chaqiriladi va shu bilan [pinned] ma'lumotlarini xavfsiz ravishda tushirish uchun ishlatilishi mumkin.
    ///
    /// Agar siz qiymatga egalik qilsangiz, uning o'rniga [`ManuallyDrop::into_inner`] dan foydalanishingiz mumkin.
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya tarkibidagi qiymatning destruktorini ishlaydi.
    /// Destroyer tomonidan qilingan o'zgarishlardan tashqari, xotira o'zgarishsiz qoladi va kompilyatorga kelsak, `T` turi uchun amal qiladigan bit-naqsh mavjud.
    ///
    ///
    /// Biroq, ushbu "zombie" qiymati xavfsiz kodga duch kelmasligi kerak va bu funktsiya bir necha marta chaqirilmasligi kerak.
    /// Qiymatni tushirishdan keyin foydalanish yoki qiymatni bir necha marta tushirish, Belgilanmagan xatti-harakatga olib kelishi mumkin (`drop` nima qilganiga qarab).
    /// Odatda bu tizim tizimi tomonidan oldini olinadi, ammo `ManuallyDrop` foydalanuvchilari kompilyatorning yordamisiz ushbu kafolatlardan foydalanishlari kerak.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // XAVFSIZLIK: biz o'zgarishi mumkin bo'lgan ma'lumotnomada ko'rsatilgan qiymatni tushiramiz
        // yozish uchun yaroqli bo'lishi kafolatlanadi.
        // `slot`-ning qayta tushirilmasligini tekshirish qo'ng'iroqchiga bog'liq.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}