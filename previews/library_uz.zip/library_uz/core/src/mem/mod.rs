//! Xotira bilan ishlashning asosiy funktsiyalari.
//!
//! Ushbu modul turlarning o'lchamlari va hizalanishini so'rash, xotirani ishga tushirish va boshqarish uchun funktsiyalarni o'z ichiga oladi.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Xususiyat va "forgets" qiymatini **uning destruktori** ishlatmasdan oladi.
///
/// Yig'ma xotira yoki fayl ushlagichi kabi boshqariladigan har qanday manbalar ulanib bo'lmaydigan holatda abadiy qoladi.Biroq, ushbu xotiraga ko'rsatgichlar amal qilishini kafolatlamaydi.
///
/// * Agar siz xotirani yo'qotmoqchi bo'lsangiz, [`Box::leak`]-ga qarang.
/// * Agar siz xotiraga xom ko'rsatkichni olishni istasangiz, [`Box::into_raw`]-ga qarang.
/// * Agar siz uning qiymatini yo'q qilmoqchi bo'lsangiz, uni yo'q qiluvchini ishlating, [`mem::drop`]-ga qarang.
///
/// # Safety
///
/// `forget` `unsafe` sifatida belgilanmagan, chunki Rust xavfsizligi kafolatlarida destruktorlar doimo ishlashi kafolati mavjud emas.
/// Masalan, dastur [`Rc`][rc] yordamida mos yozuvlar tsiklini yaratishi yoki ishlamaydigan destruktorlarsiz chiqish uchun [`process::exit`][exit] ni chaqirishi mumkin.
/// Shunday qilib, `mem::forget`-ga xavfsiz koddan foydalanish Rust-ning xavfsizlik kafolatlarini tubdan o'zgartirmaydi.
///
/// Aytish kerakki, xotira yoki I/O moslamalari kabi manbalarni oqish odatda istalmagan.
/// Ehtiyoj FFI yoki xavfli kod uchun ba'zi bir maxsus foydalanish holatlarida paydo bo'ladi, ammo shunga qaramay, odatda [`ManuallyDrop`] afzal ko'riladi.
///
/// Qiymatni unutishga ruxsat berilganligi sababli, siz yozgan har qanday `unsafe` kodi ushbu imkoniyatga imkon berishi kerak.Siz qiymatni qaytarib berolmaysiz va qo'ng'iroq qiluvchining qiymatni buzadigan vositani ishlatishini kutishingiz mumkin.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget`-dan kanonik ravishda xavfsiz foydalanish, `Drop` trait tomonidan amalga oshirilgan qiymatni buzuvchi vositani chetlab o'tishdir.Masalan, bu `File`-ni qochiradi, ya'ni
/// o'zgaruvchining egallagan maydonini qaytaring, lekin hech qachon asosiy tizim manbasini yopmang:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Bu asosiy manbaga egalik huquqi avval Rust tashqarisidagi kodga o'tkazilganda foydalidir, masalan, xom fayllar tavsiflovchisini C kodiga o'tkazish orqali.
///
/// # `ManuallyDrop` bilan aloqasi
///
/// `mem::forget`*xotira* egalik huquqini uzatish uchun ham ishlatilishi mumkin bo'lsa-da, bu xatoga yo'l qo'ymaydi.
/// [`ManuallyDrop`] o'rniga ishlatilishi kerak.Masalan, ushbu kodni ko'rib chiqing:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` tarkibidan foydalangan holda `String` yarating
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // qochqin `v`, chunki uning xotirasi endi `s` tomonidan boshqariladi
/// mem::forget(v);  // ERROR, v yaroqsiz va funktsiyaga o'tkazilmasligi kerak
/// assert_eq!(s, "Az");
/// // `s` bilvosita tashlab qo'yilgan va uning xotirasi ajratilgan.
/// ```
///
/// Yuqoridagi misolda ikkita muammo mavjud:
///
/// * Agar `String` qurilishi va `mem::forget()` chaqiruvi o'rtasida ko'proq kod qo'shilgan bo'lsa, uning ichidagi panic ikki baravar erkinlikka olib kelishi mumkin, chunki bir xil xotirani `v` va `s` ikkalasi ham boshqaradi.
/// * `v.as_mut_ptr()` raqamiga qo'ng'iroq qilib, `s` ma'lumotlariga egalik huquqini uzatgandan so'ng, `v` qiymati yaroqsiz.
/// Agar qiymat shunchaki `mem::forget` ga ko'chirilgan bo'lsa ham (uni tekshirmaydi), ba'zi bir turlari ularning qiymatlariga qat'iy talablar qo'yadi, bu ularni osib qo'yishda yaroqsiz holga keltiradi yoki endi egalik qilmaydi.
/// Yaroqsiz qiymatlarni har qanday usulda ishlatish, shu jumladan ularni funktsiyalarga o'tkazish yoki ularni qaytarish, aniqlanmagan xatti-harakatni tashkil qiladi va kompilyator tomonidan qilingan taxminlarni buzishi mumkin.
///
/// `ManuallyDrop`-ga o'tish ikkala masalani ham oldini oladi:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // `v`-ni xom qismlarga ajratishdan oldin uning tushmasligiga ishonch hosil qiling!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Endi `v`-ni ajratib oling.Ushbu operatsiyalar panic qila olmaydi, shuning uchun qochqin bo'lishi mumkin emas.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Nihoyat, `String`-ni yarating.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` bilvosita tashlab qo'yilgan va uning xotirasi ajratilgan.
/// ```
///
/// `ManuallyDrop` ikki tomonlama erkinlikni qat'iyan oldini oladi, chunki biz boshqa biron bir ishni qilishdan oldin "v" ning destruktorini o'chirib qo'yamiz.
/// `mem::forget()` bunga yo'l qo'ymaydi, chunki u o'z argumentini sarf qiladi va bizni `v`-dan kerakli narsalarni chiqargandan keyingina qo'ng'iroq qilishga majbur qiladi.
/// Agar panic `ManuallyDrop` qurilishi va mag'lubiyatni qurish o'rtasida kiritilgan bo'lsa ham (bu kodda ko'rsatilganidek bo'lmaydi), bu qochqinning paydo bo'lishiga olib keladi va er-xotin erkin bo'lmaydi.
/// Boshqacha qilib aytganda, `ManuallyDrop` (er-xotin) tushirish tomonida xatolik o'rniga oqish tomonida xatolar.
///
/// Shuningdek, `ManuallyDrop` egalik huquqini `s` ga o'tkazgandan so'ng bizni "touch" `v` ga ega bo'lishimizga to'sqinlik qiladi-uni yo'q qilish uchun `v` bilan o'zaro aloqaning yakuniy bosqichi butunlay yo'q qilinadi.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] singari, lekin o'lchamsiz qiymatlarni ham qabul qiladi.
///
/// Ushbu funktsiya `unsized_locals` xususiyati barqarorlashganda olib tashlanishi kerak bo'lgan shimdir.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Turning hajmini baytda qaytaradi.
///
/// Aniqrog'i, bu qator turidagi elementlar qatoridagi ketma-ket elementlar orasidagi baytlarni almashtirish, shu jumladan hizalama to'ldirishidir.
///
/// Shunday qilib, har qanday `T` turi va uzunligi `n` uchun `[T; n]` `n * size_of::<T>()` o'lchamiga ega.
///
/// Umuman olganda, turdagi o'lchamlar kompilyatsiyalar bo'yicha barqaror emas, lekin ibtidoiylar kabi o'ziga xos turlar.
///
/// Quyidagi jadvalda ibtidoiylar uchun hajm berilgan.
///
/// Turi |hajmi_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Bundan tashqari, `usize` va `isize` o'lchamlari bir xil.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` va `Option<Box<T>>` turlarining barchasi bir xil o'lchamga ega.
/// Agar `T` o'lchamiga ega bo'lsa, ularning barchasi `usize` bilan bir xil o'lchamga ega.
///
/// Ko'rsatkichning o'zgaruvchanligi uning hajmini o'zgartirmaydi.Shunday qilib, `&T` va `&mut T` bir xil o'lchamga ega.
/// Xuddi shu tarzda `*const T` va `* mut T` uchun.
///
/// # `#[repr(C)]` buyumlar hajmi
///
/// Ob'ektlar uchun `C` vakili belgilangan tartibga ega.
/// Ushbu maket yordamida barcha maydonlar barqaror o'lchamga ega bo'lsa, buyumlarning o'lchami ham barqaror bo'ladi.
///
/// ## Tarkiblarning kattaligi
///
/// `structs` uchun hajmi quyidagi algoritm bilan aniqlanadi.
///
/// Deklaratsiya tartibida buyurtma qilingan strukturadagi har bir maydon uchun:
///
/// 1. Maydon hajmini qo'shing.
/// 2. Joriy o'lchamni keyingi maydonning [alignment] katalogiga yaqinlashtiring.
///
/// Va nihoyat, strukturaning kattaligini [alignment] ning ko'pligiga yaqinlashtiring.
/// Strukturaning hizalanishi odatda uning barcha maydonlarining eng katta tekislashidir;buni `repr(align(N))` yordamida o'zgartirish mumkin.
///
/// `C`-dan farqli o'laroq, nol o'lchamdagi konstruktsiyalar hajmi bir baytgacha yaxlitlanmagan.
///
/// ## Enum hajmi
///
/// Diskriminantdan boshqa hech qanday ma'lumotga ega bo'lmagan enumlar, ular tuzilgan platformadagi S enumlari bilan bir xil hajmga ega.
///
/// ## Ittifoqlarning kattaligi
///
/// Birlashmaning kattaligi uning eng katta maydonining o'lchamidir.
///
/// `C`-dan farqli o'laroq, nol o'lchamdagi kasaba uyushmalari hajmi bir baytgacha yaxlitlanmagan.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Ba'zi ibtidoiy narsalar
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Ba'zi qatorlar
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Ko'rsatkich kattaligi tengligi
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` dan foydalanish.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Birinchi maydonning o'lchami 1, shuning uchun o'lchamga 1 qo'shing.Hajmi 1.
/// // Ikkinchi maydonning hizalanması 2 ga teng, shuning uchun to'ldirish uchun o'lchamga 1 qo'shing.Hajmi 2.
/// // Ikkinchi maydonning o'lchami 2 ga teng, shuning uchun o'lchamga 2 ni qo'shing.Hajmi 4.
/// // Uchinchi maydonning hizalanması 1 ga teng, shuning uchun to'ldirish uchun o'lchamga 0 qo'shing.Hajmi 4.
/// // Uchinchi maydonning o'lchami 1, shuning uchun o'lchamga 1 qo'shing.Hajmi 5 ga teng.
/// // Va nihoyat, strukturaning hizalanması 2 ga teng (chunki uning maydonlari orasidagi eng katta hizalanma 2 ga teng), shuning uchun to'ldirish uchun o'lchamga 1 qo'shing.
/// // Hajmi 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple konstruktsiyalari xuddi shu qoidalarga amal qiladi.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Maydonlarni qayta tartiblash hajmni pasaytirishi mumkinligini unutmang.
/// // Ikkala to'ldirish baytini `second` dan oldin `third` qo'yish orqali olib tashlashimiz mumkin.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Birlik hajmi-bu eng katta maydonning hajmi.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Belgilangan qiymatning hajmini baytda qaytaradi.
///
/// Bu odatda `size_of::<T>()` bilan bir xil.
/// Ammo, agar `T`*statik ravishda ma'lum o'lchamga ega bo'lmasa*, masalan, [`[T]`][slice] bo'lagi yoki [trait object] bo'lsa, u holda `size_of_val` dinamik ravishda ma'lum hajmni olish uchun ishlatilishi mumkin.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // XAVFSIZLIK: `val` mos yozuvlar, shuning uchun u to'g'ri xom ko'rsatkichdir
    unsafe { intrinsics::size_of_val(val) }
}

/// Belgilangan qiymatning hajmini baytda qaytaradi.
///
/// Bu odatda `size_of::<T>()` bilan bir xil.Ammo, agar `T`*statik ravishda ma'lum o'lchamga ega bo'lmasa*, masalan, [`[T]`][slice] bo'lagi yoki [trait object] bo'lsa, u holda `size_of_val_raw` dinamik ravishda ma'lum hajmni olish uchun ishlatilishi mumkin.
///
/// # Safety
///
/// Ushbu funktsiyani faqat quyidagi shartlar mavjud bo'lganda qo'ng'iroq qilish xavfsizdir:
///
/// - Agar `T` `Sized` bo'lsa, bu funktsiya har doim qo'ng'iroq qilish uchun xavfsizdir.
/// - Agar `T` o'lchamsiz dumi:
///     - Agar [slice] bo'lsa, unda tilim quyruqining uzunligi boshlangan butun son bo'lishi kerak va *butun qiymat* ning kattaligi (dinamik quyruq uzunligi + statik o'lchamdagi prefiks) `isize` ga to'g'ri kelishi kerak.
///     - a [trait object] bo'lsa, u holda ko'rsatgichning vtable qismi o'lchamsiz majburlash natijasida olingan haqiqiy vtable-ga ishora qilishi kerak va *butun qiymat* ning kattaligi (dinamik quyruq uzunligi + statik o'lchamdagi prefiks) `isize` ga to'g'ri kelishi kerak.
///
///     - (unstable) [extern type] bo'lsa, u holda bu funktsiya har doim qo'ng'iroq qilish uchun xavfsizdir, lekin panic yoki boshqa yo'l bilan noto'g'ri qiymatni qaytarishi mumkin, chunki tashqi tipning tuzilishi ma'lum emas.
///     Bu tashqi turdagi quyruqli turga nisbatan [`size_of_val`] bilan bir xil xatti-harakatlar.
///     - aks holda, ushbu funktsiyani chaqirishga konservativ ravishda yo'l qo'yilmaydi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // XAVFSIZLIK: qo'ng'iroq qiluvchida to'g'ri xom ko'rsatgich bo'lishi kerak
    unsafe { intrinsics::size_of_val(val) }
}

/// Turning [ABI] talab qilingan minimal hizalanishini qaytaradi.
///
/// `T` turidagi qiymatga har bir murojaat bu raqamning ko'paytmasi bo'lishi kerak.
///
/// Bu strukturaviy maydonlar uchun ishlatiladigan hizalama.Bu afzal qilingan hizalamadan kichikroq bo'lishi mumkin.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` ko'rsatgan qiymat turining [ABI] talab qilingan minimal hizalanishini qaytaradi.
///
/// `T` turidagi qiymatga har bir murojaat bu raqamning ko'paytmasi bo'lishi kerak.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // XAVFSIZLIK: val mos yozuvlar, shuning uchun u to'g'ri xom ko'rsatkichdir
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Turning [ABI] talab qilingan minimal hizalanishini qaytaradi.
///
/// `T` turidagi qiymatga har bir murojaat bu raqamning ko'paytmasi bo'lishi kerak.
///
/// Bu strukturaviy maydonlar uchun ishlatiladigan hizalama.Bu afzal qilingan hizalamadan kichikroq bo'lishi mumkin.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` ko'rsatgan qiymat turining [ABI] talab qilingan minimal hizalanishini qaytaradi.
///
/// `T` turidagi qiymatga har bir murojaat bu raqamning ko'paytmasi bo'lishi kerak.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // XAVFSIZLIK: val mos yozuvlar, shuning uchun u to'g'ri xom ko'rsatkichdir
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` ko'rsatgan qiymat turining [ABI] talab qilingan minimal hizalanishini qaytaradi.
///
/// `T` turidagi qiymatga har bir murojaat bu raqamning ko'paytmasi bo'lishi kerak.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Ushbu funktsiyani faqat quyidagi shartlar mavjud bo'lganda qo'ng'iroq qilish xavfsizdir:
///
/// - Agar `T` `Sized` bo'lsa, bu funktsiya har doim qo'ng'iroq qilish uchun xavfsizdir.
/// - Agar `T` o'lchamsiz dumi:
///     - Agar [slice] bo'lsa, unda tilim quyruqining uzunligi boshlangan butun son bo'lishi kerak va *butun qiymat* ning kattaligi (dinamik quyruq uzunligi + statik o'lchamdagi prefiks) `isize` ga to'g'ri kelishi kerak.
///     - a [trait object] bo'lsa, u holda ko'rsatgichning vtable qismi o'lchamsiz majburlash natijasida olingan haqiqiy vtable-ga ishora qilishi kerak va *butun qiymat* ning kattaligi (dinamik quyruq uzunligi + statik o'lchamdagi prefiks) `isize` ga to'g'ri kelishi kerak.
///
///     - (unstable) [extern type] bo'lsa, u holda bu funktsiya har doim qo'ng'iroq qilish uchun xavfsizdir, lekin panic yoki boshqa yo'l bilan noto'g'ri qiymatni qaytarishi mumkin, chunki tashqi tipning tuzilishi ma'lum emas.
///     Bu tashqi turdagi quyruqli turga nisbatan [`align_of_val`] bilan bir xil xatti-harakatlar.
///     - aks holda, ushbu funktsiyani chaqirishga konservativ ravishda yo'l qo'yilmaydi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // XAVFSIZLIK: qo'ng'iroq qiluvchida to'g'ri xom ko'rsatgich bo'lishi kerak
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Agar `T` turidagi qiymatlarni tushirish muhim bo'lsa, `true`-ni qaytaradi.
///
/// Bu faqat optimallashtirish bo'yicha maslahatdir va konservativ tarzda amalga oshirilishi mumkin:
/// u aslida tushirilishi shart bo'lmagan turlar uchun `true` ni qaytarishi mumkin.
/// Shunday qilib, har doim qaytariladigan `true` ushbu funktsiyani amalga oshirishi mumkin.Ammo, agar bu funktsiya haqiqatan ham `false` ni qaytaradigan bo'lsa, unda siz `T` ning tushishi hech qanday yon ta'sirga ega emasligiga amin bo'lishingiz mumkin.
///
/// Ma'lumotlarni qo'lda tashlab yuborish kerak bo'lgan to'plamlar kabi narsalarning past darajadagi tatbiq etilishi ushbu funktsiyadan foydalanib, ularning tarkibini yo'q qilishda keraksiz ravishda tashlab qo'yishdan saqlaydi.
///
/// Bu versiyalarni tuzishda farq qilmasligi mumkin (bu erda nojo'ya ta'sirlari bo'lmagan tsikl osongina aniqlanadi va yo'q qilinadi), lekin ko'pincha disk raskadrovka tuzilmalari uchun katta yutuq.
///
/// Shuni esda tutingki, [`drop_in_place`] ushbu tekshiruvni allaqachon amalga oshiradi, shuning uchun agar sizning ish hajmingiz ozgina [`drop_in_place`] qo'ng'iroqlariga kamaytirilsa, bundan foydalanish kerak emas.
/// Xususan, siz tilimni [`drop_in_place`] qilishingiz mumkin va bu barcha qiymatlar uchun bitta need_drop tekshiruvini amalga oshiradi.
///
/// Shuning uchun Vec kabi turdagi `needs_drop`-dan aniq foydalanmasdan shunchaki `drop_in_place(&mut self[..])`.
/// Boshqa tomondan, [`HashMap`] kabi turlar birma-bir qiymatlarni tushirishi kerak va ushbu API dan foydalanishi kerak.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// To'plam `needs_drop`-dan qanday foydalanishi mumkinligi haqida misol:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ma'lumotlarni tashlab qo'ying
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Barcha nol bayt naqshlari bilan ifodalangan `T` tipidagi qiymatni qaytaradi.
///
/// Bu shuni anglatadiki, masalan, `(u8, u16)` dagi to'ldirish bayti nolga teng emas.
///
/// Nolinchi bayt naqshlari `T` tipidagi haqiqiy qiymatni ko'rsatishiga kafolat yo'q.
/// Masalan, nolinchi bayt naqsh mos yozuvlar turlari ("&T`, `&mut T`) va funktsiyalar ko'rsatkichlari uchun yaroqli qiymat emas.
/// Bunday turdagi `zeroed`-dan foydalanish darhol [undefined behavior][ub]-ni keltirib chiqaradi, chunki [the Rust compiler assumes][inv] har doim boshlang'ich deb hisoblagan o'zgaruvchida haqiqiy qiymatga ega.
///
///
/// Bu [`MaybeUninit::zeroed().assume_init()`][zeroed] bilan bir xil ta'sirga ega.
/// Bu ba'zan FFI uchun foydalidir, ammo umuman undan qochish kerak.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Ushbu funktsiyani to'g'ri ishlatish: butun sonni nol bilan boshlash.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Noto'g'ri* ushbu funktsiyadan foydalanish: ma'lumotni nol bilan boshlash.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Aniqlanmagan xatti-harakatlar!
/// let _y: fn() = unsafe { mem::zeroed() }; // Va yana!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // XAVFSIZLIK: qo'ng'iroq qiluvchi barcha nolinchi qiymat `T` uchun amal qilishiga kafolat berishi kerak.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Rust-ning normal xotirani ishga tushirishni tekshiradi, lekin hech narsa qilmasdan, `T` tipidagi qiymatni ishlab chiqarishga harakat qiladi.
///
/// **Ushbu funktsiya eskirgan.** Buning o'rniga [`MaybeUninit<T>`] dan foydalaning.
///
/// Amortizatsiyaning sababi shundaki, funktsiyani asosan to'g'ri ishlatish mumkin emas: u [`MaybeUninit::uninit().assume_init()`][uninit] bilan bir xil ta'sirga ega.
///
/// [`assume_init` documentation][assume_init] tushuntirganidek, [the Rust compiler assumes][inv] qiymatlari to'g'ri boshlangan.
/// Natijada, masalan, qo'ng'iroq qilish
/// `mem::uninitialized::<bool>()` aniq `true` yoki `false` bo'lmagan `bool` ni qaytarish uchun darhol aniqlanmagan xatti-harakatlarni keltirib chiqaradi.
/// Bundan ham yomoni, bu erda qaytariladigan narsa kabi chindan ham boshlang'ich bo'lmagan xotira alohida, chunki kompilyator uning belgilangan qiymatga ega emasligini biladi.
/// Bu o'zgarmaydiganda boshlang'ich bo'lmagan ma'lumotlarga ega bo'lishni aniqlanmagan xatti-harakatga aylantiradi, hatto bu o'zgaruvchining butun sonli turi bo'lsa ham.
/// (E'tibor bering, boshlanmagan tamsayılar atrofidagi qoidalar hali yakunlanmagan, ammo ular bo'lguncha ulardan saqlanish tavsiya etiladi.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // XAVFSIZLIK: qo'ng'iroq qiluvchisi `T` uchun birliklashtirilgan qiymat haqiqiyligini kafolatlashi kerak.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Ikkala parametrni o'zgartirmasdan qiymatlarni ikkita o'zgaruvchan joyda almashtiradi.
///
/// * Agar siz standart yoki qo'pol qiymat bilan almashtirishni xohlasangiz, [`take`]-ga qarang.
/// * Agar siz eski qiymatni qaytarib, o'tgan qiymat bilan almashtirishni xohlasangiz, [`replace`]-ga qarang.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // XAVFSIZLIK: xom ko'rsatgichlar barcha mos keladigan xavfsiz o'zgaruvchan ma'lumotlardan yaratilgan
    // cheklovlar `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest`-ni standart `T` qiymati bilan almashtiradi va oldingi `dest` qiymatini qaytaradi.
///
/// * Agar ikkita o'zgaruvchining qiymatlarini almashtirishni xohlasangiz, [`swap`] ga qarang.
/// * Standart qiymat o'rniga o'tgan qiymat bilan almashtirishni xohlasangiz, [`replace`] ga qarang.
///
/// # Examples
///
/// Oddiy misol:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` strukturaviy maydonga egalik huquqini "empty" qiymati bilan almashtirish orqali olish imkonini beradi.
/// `take` holda siz quyidagi muammolarga duch kelishingiz mumkin:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Shuni esda tutingki, `T` [`Clone`]-ni amalga oshirishi shart emas, shuning uchun hatto `self.buf`-ni klonlash va qayta tiklash ham mumkin emas.
/// Ammo `take` `self.buf` ning asl qiymatini `self` dan ajratish uchun ishlatilishi mumkin va uni qaytarishga imkon beradi:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src`-ni havola qilingan `dest`-ga o'tkazadi, oldingi `dest` qiymatini qaytaradi.
///
/// Ikkala qiymat ham tushirilmaydi.
///
/// * Agar ikkita o'zgaruvchining qiymatlarini almashtirishni xohlasangiz, [`swap`] ga qarang.
/// * Agar siz standart qiymat bilan almashtirishni xohlasangiz, [`take`]-ga qarang.
///
/// # Examples
///
/// Oddiy misol:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` strukturaviy maydonni boshqa qiymat bilan almashtirish orqali iste'mol qilishga imkon beradi.
/// `replace` holda siz quyidagi muammolarga duch kelishingiz mumkin:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Shuni esda tutingki, `T` [`Clone`]-ni majburiy ravishda amalga oshirmaydi, shuning uchun biz harakatni oldini olish uchun `self.buf[i]`-ni klonlay olmaymiz.
/// Ammo `replace` ushbu indeksdagi asl qiymatni `self` dan ajratish uchun ishlatilishi mumkin, bu esa uni qaytarishga imkon beradi:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // XAVFSIZLIK: Biz `dest` dan o'qiymiz, lekin keyin to'g'ridan-to'g'ri unga `src` yozamiz,
    // shunday qilib eski qiymat takrorlanmaydi.
    // Hech narsa tashlanmaydi va panic bu erda hech narsa qila olmaydi.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Qiymatni yo'q qiladi.
///
/// Buni argumentni [`Drop`][drop] dasturini chaqirish orqali amalga oshiradi.
///
/// Bu, masalan, `Copy`-ni amalga oshiradigan turlar uchun hech narsa qilmaydi
/// integers.
/// Bunday qiymatlar ko'chiriladi va _then_ funktsiyaga ko'chiriladi, shuning uchun qiymat ushbu funktsiya chaqiruvidan keyin ham saqlanib qoladi.
///
///
/// Ushbu funktsiya sehrli emas;u tom ma'noda quyidagicha ta'riflanadi
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` funktsiyaga ko'chirilganligi sababli, funktsiya qaytguncha u avtomatik ravishda tushadi.
///
/// [drop]: Drop
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // vector-ni aniq tashlab qo'ying
/// ```
///
/// [`RefCell`] qarz olish qoidalarini ish vaqtida bajarganligi sababli, `drop` [`RefCell`] qarzini chiqarishi mumkin:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // ushbu uyadagi o'zgarishi mumkin bo'lgan qarzdan voz keching
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Butun sonlar va [`Copy`] ni amalga oshiradigan boshqa turlarga `drop` ta'sir qilmaydi.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` nusxasi ko'chiriladi va tashlanadi
/// drop(y); // `y` nusxasi ko'chiriladi va tashlanadi
///
/// println!("x: {}, y: {}", x, y.0); // hali ham mavjud
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src`-ni `&U` turiga o'xshash deb talqin qiladi va keyin mavjud bo'lgan qiymatni o'zgartirmasdan `src` o'qiydi.
///
/// Ushbu funktsiya `src` markerini [`size_of::<U>`][size_of] baytlari uchun `&T` ni `&U` ga o'tkazib, keyin `&U` ni o'qish orqali yaroqli deb hisoblaydi (bundan tashqari, bu `&U` `&T` ga nisbatan qattiqroq tekislash talablarini qo'ygan taqdirda ham to'g'ri bajariladi).
/// Bundan tashqari, u `src`-dan tashqariga chiqish o'rniga xavfsiz qiymat nusxasini yaratadi.
///
/// Agar `T` va `U` har xil o'lchamlarga ega bo'lsa, bu kompilyatsiya vaqtidagi xato emas, lekin faqat `T` va `U` o'lchamlari bir xil bo'lgan joyda ushbu funktsiyani chaqirish tavsiya etiladi.Agar `U` `T` dan katta bo'lsa, bu funktsiya [undefined behavior][ub] ni ishga tushiradi.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Ma'lumotlarni 'foo_array'-dan nusxalash va ularni 'Foo' sifatida ko'rib chiqish
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Nusxalangan ma'lumotlarni o'zgartiring
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' tarkibi o'zgarmasligi kerak edi
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Agar U yuqori tekislash talabiga ega bo'lsa, src mos kelmasligi mumkin.
    if align_of::<U>() > align_of::<T>() {
        // XAVFSIZLIK: `src` o'qish uchun yaroqliligi kafolatlangan ma'lumotnomadir.
        // Chaqiruvchi haqiqiy transmutatsiya xavfsizligini kafolatlashi kerak.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // XAVFSIZLIK: `src` o'qish uchun yaroqliligi kafolatlangan ma'lumotnomadir.
        // Biz shunchaki `src as *const U` to'g'ri moslashtirilganligini tekshirdik.
        // Chaqiruvchi haqiqiy transmutatsiya xavfsizligini kafolatlashi kerak.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Enum diskriminantini ifodalaydigan shaffof bo'lmagan turi.
///
/// Qo'shimcha ma'lumot olish uchun ushbu moduldagi [`discriminant`] funktsiyasini ko'ring.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ushbu trait dasturlarini olish mumkin emas, chunki biz T uchun chegaralarni istamaymiz.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v`-da enum variantini noyob aniqlaydigan qiymatni qaytaradi.
///
/// Agar `T` enum bo'lmasa, ushbu funktsiyani chaqirish noaniq xatti-harakatga olib kelmaydi, lekin qaytish qiymati aniqlanmagan.
///
///
/// # Stability
///
/// Enum ta'rifi o'zgargan taqdirda, enum variantining diskriminanti o'zgarishi mumkin.
/// Ba'zi bir variantning diskriminanti bir xil kompilyator bilan tuzilgan kompilyatsiyalar o'rtasida o'zgarmaydi.
///
/// # Examples
///
/// Bu ma'lumotni tashiydigan enumlarni taqqoslash uchun ishlatilishi mumkin, shu bilan birga haqiqiy ma'lumotlarga e'tibor berilmaydi:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// `T` enum turidagi variantlar sonini qaytaradi.
///
/// Agar `T` enum bo'lmasa, ushbu funktsiyani chaqirish noaniq xatti-harakatga olib kelmaydi, lekin qaytish qiymati aniqlanmagan.
/// Xuddi shu tarzda, agar `T` `usize::MAX` ga qaraganda ko'proq variantlarga ega bo'lsa, qaytish qiymati aniqlanmagan.
/// Yashash variantlari hisobga olinadi.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}