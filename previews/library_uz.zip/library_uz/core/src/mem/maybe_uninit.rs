use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` ning boshlang'ich bo'lmagan nusxalarini yaratish uchun o'ralgan turi.
///
/// # Initsializatsiya o'zgarmasdir
///
/// Umuman olganda, kompilyator o'zgaruvchining turi talablariga muvofiq o'zgaruvchining to'g'ri ishga tushirilishini taxmin qiladi.Masalan, mos yozuvlar turidagi o'zgaruvchi hizalanmalı va NULL bo'lmasligi kerak.
/// Bu o'zgarmasdir, uni *har doim* saqlash kerak, hatto xavfli kodda ham.
/// Natijada, mos yozuvlar turidagi o'zgaruvchini nol-boshlash, darhol [undefined behavior][ub]-ni keltirib chiqaradi, bu mos yozuvlar xotiraga kirish uchun odatlanib qoladimi yoki yo'qmi:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // aniqlanmagan xatti-harakatlar!️
/// // `MaybeUninit<&i32>` bilan teng kod:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // aniqlanmagan xatti-harakatlar!️
/// ```
///
/// Bu kompilyator tomonidan turli xil optimallashtirish uchun foydalaniladi, masalan, ish vaqtini tekshirishni o'tkazish va `enum` tartibini optimallashtirish.
///
/// Xuddi shunday, to'liq ishga tushirilmagan xotira har qanday tarkibga ega bo'lishi mumkin, `bool` har doim `true` yoki `false` bo'lishi kerak.Shunday qilib, boshlang'ich bo'lmagan `bool` yaratish aniqlanmagan xatti-harakatlardir:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // aniqlanmagan xatti-harakatlar!️
/// // `MaybeUninit<bool>` bilan teng kod:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // aniqlanmagan xatti-harakatlar!️
/// ```
///
/// Bundan tashqari, boshlang'ich bo'lmagan xotira doimiy qiymatga ega bo'lmaganligi bilan ajralib turadi ("fixed" "it won't change without being written to" ma'nosini anglatadi).Bir xil boshlanmagan baytni bir necha marta o'qish turli xil natijalar berishi mumkin.
/// Bu o'zgaruvchida boshlang'ich bo'lmagan ma'lumotlarga ega bo'lishni aniqlanmagan xatti-harakatga aylantiradi, hatto bu o'zgaruvchining tamsayı turi bo'lsa ham, aks holda har qanday *sobit* bit naqshini ushlab turishi mumkin:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // aniqlanmagan xatti-harakatlar!️
/// // `MaybeUninit<i32>` bilan teng kod:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // aniqlanmagan xatti-harakatlar!️
/// ```
/// (E'tibor bering, boshlanmagan tamsayılar atrofidagi qoidalar hali yakunlanmagan, ammo ular bo'lguncha ulardan saqlanish tavsiya etiladi.)
///
/// Buning ustiga, ko'pgina turlarning qo'shimcha darajadagi invariantlarga ega ekanligini unutmang.
/// Masalan, `1`-boshlangan [`Vec<T>`] ishga tushirilgan deb hisoblanadi (joriy dastur doirasida; bu barqaror kafolatni anglatmaydi), chunki kompilyatorning bilishi kerak bo'lgan yagona talab bu ma'lumot ko'rsatgichi null bo'lishi kerak.
/// Bunday `Vec<T>`-ni yaratish *darhol* aniqlanmagan xatti-harakatga olib kelmaydi, aksariyat xavfsiz operatsiyalar (shu jumladan, uni tashlab qo'yish) bilan aniqlanmagan xatti-harakatga olib keladi.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` xavfsiz bo'lmagan kodni ishga tushirilmagan ma'lumotlar bilan ishlashga imkon beradi.
/// Bu kompilyatorga bu erda ma'lumotlar * boshlanmasligi mumkinligini ko'rsatuvchi signal:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Aniq boshlanmagan ma'lumotnomani yarating.
/// // Tuzuvchi `MaybeUninit<T>` ichidagi ma'lumotlar yaroqsiz bo'lishi mumkinligini biladi va shuning uchun bu UB emas:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Uni to'g'ri qiymatga qo'ying.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Boshlangan ma'lumotlarni chiqarib oling-bu faqat `x` ni to'g'ri ishga tushirgandan so'ng * ruxsat etiladi!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Keyin kompilyator ushbu kod bo'yicha noto'g'ri taxminlar yoki optimallashtirishlar qilmasligini biladi.
///
/// Siz `MaybeUninit<T>` ni `Option<T>` ga o'xshash deb o'ylashingiz mumkin, ammo ish vaqtini kuzatmasdan va xavfsizlik tekshiruvlarisiz.
///
/// ## out-pointers
///
/// "out-pointers" ni amalga oshirish uchun `MaybeUninit<T>` dan foydalanishingiz mumkin: funktsiyadan ma'lumotlarni qaytarish o'rniga, natijani qo'yish uchun uni (uninitialized) xotirasiga ko'rsatgichni o'tkazing.
/// Qo'ng'iroq qiluvchining natija qanday saqlanishini boshqarish muhim bo'lganida va keraksiz harakatlardan saqlanish zarur bo'lganda foydali bo'lishi mumkin.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` eski tarkibni tashlamaydi, bu muhim.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Endi biz `v` ishga tushirilganligini bilamiz!Bu vector to'g'ri tushishiga ishonch hosil qiladi.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Massiv elementlarini elementlashtirish
///
/// `MaybeUninit<T>` katta massivni elementma-element boshlash uchun ishlatilishi mumkin:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` boshlanmagan qatorini yarating.
///     // `assume_init` xavfsizdir, chunki biz bu erda boshladik deb da'vo qilayotgan turimiz, "initialUning" talab qilinmaydigan "MaybeUninit" to'plamidir.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` tushirish hech narsa qilmaydi.
///     // Shunday qilib, `ptr::write` o'rniga xom ko'rsatkichni tayinlash yordamida eski boshlang'ich qiymati tushishiga olib kelmaydi.
/////
///     // Agar ushbu tsikl davomida panic bo'lsa, bizda xotira qochqinlari bor, lekin xotirada xavfsizlik muammosi yo'q.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Hammasi boshlangan.
///     // Massivni boshlangan turga o'tkazing.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Bundan tashqari, siz quyi darajadagi ma'lumotlar tuzilmalarida joylashgan qisman boshlangan massivlar bilan ishlashingiz mumkin.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` boshlanmagan qatorini yarating.
/// // `assume_init` xavfsizdir, chunki biz bu erda boshladik deb da'vo qilayotgan turimiz, "initialUning" talab qilinmaydigan "MaybeUninit" to'plamidir.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Biz tayinlagan elementlarning sonini hisoblang.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Massivdagi har bir element uchun, agar biz uni ajratgan bo'lsak, tushiring.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Strukturani maydonma-bosqich boshlash
///
/// Strukturalarni maydonlar bo'yicha boshlash uchun siz `MaybeUninit<T>` va [`std::ptr::addr_of_mut`] so'lidan foydalanishingiz mumkin:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` maydonini ishga tushirish
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` maydonini ishga tushirish Agar bu erda panic bo'lsa, u holda `name` maydonidagi `String` sizib chiqadi.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Barcha maydonlar ishga tushirildi, shuning uchun biz boshlang'ich Foo-ni olish uchun `assume_init`-ga qo'ng'iroq qilamiz.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` bilan bir xil o'lchamdagi, tekislangan va ABIga ega bo'lishi kafolatlanadi:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Shunga qaramay, `MaybeUninit<T>` ni o'z ichiga olgan * turi bir xil tartibda bo'lishi shart emasligini unutmang.Rust umuman `T` va `U` o'lchamlari va hizalanishi bir xil bo'lsa ham, `Foo<T>` maydonlari `Foo<U>` bilan bir xil tartibda bo'lishiga kafolat bermaydi.
///
/// Bundan tashqari, har qanday bit qiymati `MaybeUninit<T>` uchun yaroqli bo'lgani uchun kompilyator non-zero/niche-filling optimallashtirishlarini qo'llay olmaydi, bu esa katta hajmga olib keladi:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Agar `T` FFI xavfsiz bo'lsa, u holda `MaybeUninit<T>` ham xavfsizdir.
///
/// `MaybeUninit` `#[repr(transparent)]` bo'lsa-da (bu `T` bilan bir xil o'lchamdagi, tekislanganligi va ABI-ni kafolatlaydi), bu avvalgi ogohlantirishlarning hech birini o'zgartirmaydi.
/// `Option<T>` va `Option<MaybeUninit<T>>` hanuzgacha har xil o'lchamlarga ega bo'lishi mumkin va `T` tipidagi maydonni o'z ichiga olgan turlar `MaybeUninit<T>` bo'lganidan farqli ravishda joylashtirilishi (va o'lchamlari) bo'lishi mumkin.
/// `MaybeUninit` kasaba uyushma turi va kasaba uyushmalaridagi `#[repr(transparent)]` beqaror (qarang [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Vaqt o'tishi bilan `#[repr(transparent)]` ning kasaba uyushmalaridagi aniq kafolatlari o'zgarishi mumkin va `MaybeUninit` `#[repr(transparent)]` bo'lib qolishi yoki qolmasligi mumkin.
/// Aytgancha, `MaybeUninit<T>` * har doim `T` bilan bir xil o'lchamdagi, tekislangan va ABIga ega bo'lishiga kafolat beradi;shunchaki `MaybeUninit`-ning ushbu kafolatni amalga oshirish usuli rivojlanishi mumkin.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Tarkibni boshqa narsalarga o'rab olishimiz uchun.Bu generatorlar uchun foydalidir.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()`-ga qo'ng'iroq qilmasdan, biz buning uchun etarli darajada boshlanganligini bilmaymiz.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Berilgan qiymat bilan boshlangan yangi `MaybeUninit<T>` yaratadi.
    /// Ushbu funktsiyani qaytarish qiymati bo'yicha [`assume_init`] raqamiga qo'ng'iroq qilish xavfsizdir.
    ///
    /// E'tibor bering, `MaybeUninit<T>` tushishi hech qachon "T" ning tomchi kodiga qo'ng'iroq qilmaydi.
    /// Agar u ishga tushirilgan bo'lsa, `T` tushib ketishiga ishonch hosil qilish sizning javobgarligingizdir.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Boshlanmagan holatda yangi `MaybeUninit<T>` yaratadi.
    ///
    /// E'tibor bering, `MaybeUninit<T>` tushishi hech qachon "T" ning tomchi kodiga qo'ng'iroq qilmaydi.
    /// Agar u ishga tushirilgan bo'lsa, `T` tushib ketishiga ishonch hosil qilish sizning javobgarligingizdir.
    ///
    /// Ba'zi bir misollar uchun [type-level documentation][MaybeUninit]-ga qarang.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Boshlanmagan holatda yangi `MaybeUninit<T>` elementlarini yarating.
    ///
    /// Note: future Rust versiyasida ushbu usul keraksiz bo'lishi mumkin, agar massiv sintaksisiga [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) ruxsat berilsa.
    ///
    /// Quyidagi misolda `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` ishlatilishi mumkin.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Haqiqatan ham o'qilgan (ehtimol kichikroq) bir bo'lak ma'lumotni qaytaradi
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // XAVFSIZLIK: ishga tushirilmagan `[MaybeUninit<_>; LEN]` haqiqiy hisoblanadi.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Boshlanmagan holatda yangi `MaybeUninit<T>` yaratadi, xotirasi `0` bayt bilan to'ldiriladi.Bu `T` ga bog'liq bo'lib, u allaqachon to'g'ri ishga tushirishni amalga oshiradimi.
    ///
    /// Masalan, `MaybeUninit<usize>::zeroed()` ishga tushirildi, lekin `MaybeUninit<&'static i32>::zeroed()` emas, chunki havolalar bo'sh bo'lmasligi kerak.
    ///
    /// E'tibor bering, `MaybeUninit<T>` tushishi hech qachon "T" ning tomchi kodiga qo'ng'iroq qilmaydi.
    /// Agar u ishga tushirilgan bo'lsa, `T` tushib ketishiga ishonch hosil qilish sizning javobgarligingizdir.
    ///
    /// # Example
    ///
    /// Ushbu funktsiyani to'g'ri ishlatish: strukturani nol bilan boshlash, bu erda barcha strukturalar bit qiymatini 0 qiymatini to'g'ri qiymat sifatida ushlab turishi mumkin.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Noto'g'ri* ushbu funktsiyadan foydalanish: `0` turi uchun yaroqli bit-naqsh bo'lmasa, `x.zeroed().assume_init()`-ga qo'ng'iroq qilish:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Bir juftlik ichida biz haqiqiy diskriminantga ega bo'lmagan `NotZero` yaratamiz.
    /// // Bu aniqlanmagan xatti-harakatlar.️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // XAVFSIZLIK: `u.as_mut_ptr()` ajratilgan xotiraga ishora qiladi.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` qiymatini o'rnatadi.
    /// Bu avvalgi har qanday qiymatni o'chirmasdan yozadi, shuning uchun agar siz destruktorni o'tkazib yubormoqchi bo'lmasangiz, uni ikki marta ishlatmang.
    ///
    /// Sizga qulaylik uchun, bu shuningdek `self` tarkibidagi (endi xavfsiz ishga tushirilgan) o'zgaruvchan ma'lumotni qaytaradi.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // XAVFSIZLIK: Biz ushbu qiymatni boshladik.
        unsafe { self.assume_init_mut() }
    }

    /// Tarkibidagi qiymatga ko'rsatkichni oladi.
    /// Ushbu ko'rsatgichdan o'qish yoki uni mos yozuvlarga aylantirish, agar `MaybeUninit<T>` ishga tushirilmasa, aniqlanmagan xatti-harakatlardir.
    /// Ushbu ko'rsatgich (non-transitively) ko'rsatgan xotiraga yozish aniqlanmagan xatti-harakatlardir (`UnsafeCell<T>` ichidan tashqari).
    ///
    /// # Examples
    ///
    /// Ushbu usuldan to'g'ri foydalanish:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>`-ga mos yozuvlar yarating.Bu yaxshi, chunki biz uni boshladik.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Ushbu usuldan *noto'g'ri* foydalanish:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Biz boshlanmagan vector-ga havola yaratdik!Bu aniqlanmagan xatti-harakatlar.️
    /// ```
    ///
    /// (E'tibor bering, boshlanmagan ma'lumotlarga havolalar bo'yicha qoidalar hali yakunlanmagan, ammo ular bo'lguncha ulardan qochish tavsiya etiladi.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` va `ManuallyDrop` ikkalasi ham `repr(transparent)`, shuning uchun biz ko'rsatgichni tashlashimiz mumkin.
        self as *const _ as *const T
    }

    /// O'z ichiga olgan qiymatga o'zgaruvchan ko'rsatkichni oladi.
    /// Ushbu ko'rsatgichdan o'qish yoki uni mos yozuvlarga aylantirish, agar `MaybeUninit<T>` ishga tushirilmasa, aniqlanmagan xatti-harakatlardir.
    ///
    /// # Examples
    ///
    /// Ushbu usuldan to'g'ri foydalanish:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>`-ga mos yozuvlar yarating.
    /// // Bu yaxshi, chunki biz uni boshladik.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Ushbu usuldan *noto'g'ri* foydalanish:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Biz boshlanmagan vector-ga havola yaratdik!Bu aniqlanmagan xatti-harakatlar.️
    /// ```
    ///
    /// (E'tibor bering, boshlanmagan ma'lumotlarga havolalar bo'yicha qoidalar hali yakunlanmagan, ammo ular bo'lguncha ulardan qochish tavsiya etiladi.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` va `ManuallyDrop` ikkalasi ham `repr(transparent)`, shuning uchun biz ko'rsatgichni tashlashimiz mumkin.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` konteyneridan qiymat ajratib olinadi.Bu ma'lumotlar tushishini ta'minlashning ajoyib usuli, chunki natijada paydo bo'lgan `T` odatdagi tomchilar bilan ishlashga bog'liq.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` haqiqatan ham boshlang'ich holatida ekanligiga kafolat berish qo'ng'iroqchiga bog'liq.Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish darhol aniqlanmagan xatti-harakatlarni keltirib chiqaradi.
    /// [type-level documentation][inv] ushbu boshlang'ich o'zgarmasligi haqida ko'proq ma'lumotga ega.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Buning ustiga, ko'pgina turlarning qo'shimcha darajadagi invariantlarga ega ekanligini unutmang.
    /// Masalan, `1`-boshlangan [`Vec<T>`] ishga tushirilgan deb hisoblanadi (joriy dastur doirasida; bu barqaror kafolatni anglatmaydi), chunki kompilyatorning bilishi kerak bo'lgan yagona talab bu ma'lumot ko'rsatgichi null bo'lishi kerak.
    ///
    /// Bunday `Vec<T>`-ni yaratish *darhol* aniqlanmagan xatti-harakatga olib kelmaydi, aksariyat xavfsiz operatsiyalar (shu jumladan, uni tashlab qo'yish) bilan aniqlanmagan xatti-harakatga olib keladi.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Ushbu usuldan to'g'ri foydalanish:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Ushbu usuldan *noto'g'ri* foydalanish:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` hali ishga tushirilmagan edi, shuning uchun ushbu oxirgi satr aniqlanmagan xatti-harakatga sabab bo'ldi.️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` ishga tushirilishini kafolatlashi kerak.
        // Bu shuni anglatadiki, `self` `value` varianti bo'lishi kerak.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` konteyneridagi qiymatni o'qiydi.Olingan `T` odatdagi tomchilar bilan ishlov berishga bog'liq.
    ///
    /// Mumkin bo'lgan taqdirda, uning o'rniga [`assume_init`] dan foydalanish afzalroqdir, bu `MaybeUninit<T>` tarkibini takrorlashni oldini oladi.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` haqiqatan ham boshlang'ich holatida ekanligiga kafolat berish qo'ng'iroqchiga bog'liq.Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish noaniq xatti-harakatlarni keltirib chiqaradi.
    /// [type-level documentation][inv] ushbu boshlang'ich o'zgarmasligi haqida ko'proq ma'lumotga ega.
    ///
    /// Bundan tashqari, bu xuddi shu ma'lumotlarning nusxasini `MaybeUninit<T>`-da qoldiradi.
    /// Ma'lumotlarning bir nechta nusxalarini ishlatganda (`assume_init_read` raqamiga bir necha marta qo'ng'iroq qilish yoki birinchi navbatda `assume_init_read` va keyin [`assume_init`] raqamlariga qo'ng'iroq qilish orqali), ma'lumotlar haqiqatan ham takrorlanishi mumkinligiga ishonch hosil qilish.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Ushbu usuldan to'g'ri foydalanish:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` bu `Copy`, shuning uchun biz bir necha marta o'qishimiz mumkin.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` qiymatini takrorlash yaxshi, shuning uchun biz bir necha marta o'qishimiz mumkin.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Ushbu usuldan *noto'g'ri* foydalanish:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Endi biz bir xil vector-ning ikkita nusxasini yaratdik, ikkalasi ham tushib ketganda, er-xotin bepul ⚠️!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` ishga tushirilishini kafolatlashi kerak.
        // `self.as_ptr()`-dan o'qish xavfsizdir, chunki `self` ishga tushirilishi kerak.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Mavjud qiymatni joyiga tushiradi.
    ///
    /// Agar siz `MaybeUninit`-ga egalik qilsangiz, uning o'rniga [`assume_init`]-dan foydalanishingiz mumkin.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` haqiqatan ham boshlang'ich holatida ekanligiga kafolat berish qo'ng'iroqchiga bog'liq.Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish noaniq xatti-harakatlarni keltirib chiqaradi.
    ///
    /// Buning ustiga, `T` turidagi barcha qo'shimcha invariantlarni qondirish kerak, chunki `T` (yoki uning a'zolari) ning `Drop` bajarilishi bunga tayanishi mumkin.
    /// Masalan, `1`-boshlangan [`Vec<T>`] ishga tushirilgan deb hisoblanadi (joriy dastur doirasida; bu barqaror kafolatni anglatmaydi), chunki kompilyatorning bilishi kerak bo'lgan yagona talab bu ma'lumot ko'rsatgichi null bo'lishi kerak.
    ///
    /// Bunday `Vec<T>`-ni tashlab qo'yish, aniqlanmagan xatti-harakatga olib keladi.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // XAVFSIZLIK: qo'ng'iroq qiluvchida `self` ishga tushirilganligi va
        // `T` ning barcha invariantlarini qondiradi.
        // Agar shunday bo'lsa, qiymatni joyiga tushirish xavfsizdir.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Mavjud qiymatga umumiy ma'lumotni oladi.
    ///
    /// Biz ishga tushirilgan, lekin `MaybeUninit`-ga egalik qilmaydigan (`.assume_init()`) dan foydalanishni taqiqlaydigan) `MaybeUninit`-ga kirishni xohlaganimizda foydali bo'lishi mumkin.
    ///
    /// # Safety
    ///
    /// Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish noaniq xatti-harakatlarni keltirib chiqaradi: qo'ng'iroq qiluvchiga `MaybeUninit<T>` haqiqatan ham boshlang'ich holatda ekanligiga kafolat berish kerak.
    ///
    ///
    /// # Examples
    ///
    /// ### Ushbu usuldan to'g'ri foydalanish:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` ni ishga tushirish:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Endi bizning `MaybeUninit<_>`-ning ishga tushirilishi ma'lum bo'lganligi sababli, unga umumiy ma'lumotnoma yaratish yaxshi bo'ladi:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // XAVFSIZLIK: `x` ishga tushirildi.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Ushbu usuldan *noto'g'ri* foydalanish:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Biz boshlanmagan vector-ga havola yaratdik!Bu aniqlanmagan xatti-harakatlar.️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` yordamida `MaybeUninit`-ni ishga tushiring:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Ishga tushirilmagan `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` ishga tushirilishini kafolatlashi kerak.
        // Bu shuni anglatadiki, `self` `value` varianti bo'lishi kerak.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// O'z ichiga olinadigan qiymatga o'zgarishi mumkin bo'lgan (unique) ma'lumotnomasini oladi.
    ///
    /// Biz ishga tushirilgan, lekin `MaybeUninit`-ga egalik qilmaydigan (`.assume_init()`) dan foydalanishni taqiqlaydigan) `MaybeUninit`-ga kirishni xohlaganimizda foydali bo'lishi mumkin.
    ///
    /// # Safety
    ///
    /// Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish noaniq xatti-harakatlarni keltirib chiqaradi: qo'ng'iroq qiluvchiga `MaybeUninit<T>` haqiqatan ham boshlang'ich holatda ekanligiga kafolat berish kerak.
    /// Masalan, `.assume_init_mut()` ni `MaybeUninit` ni ishga tushirish uchun ishlatish mumkin emas.
    ///
    /// # Examples
    ///
    /// ### Ushbu usuldan to'g'ri foydalanish:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Kiritish buferining *barcha* baytlarini ishga tushiradi.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` ni ishga tushirish:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Endi biz `buf` ishga tushirilganligini bilamiz, shuning uchun uni `.assume_init()` qilishimiz mumkin.
    /// // Biroq, `.assume_init()` dan foydalanish 2048 baytdan `memcpy` ni keltirib chiqarishi mumkin.
    /// // Buferimiz nusxa olinmasdan ishga tushirilganligini tasdiqlash uchun biz `&mut MaybeUninit<[u8; 2048]>`-ni `&mut [u8; 2048]`-ga ko'taramiz:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // XAVFSIZLIK: `buf` ishga tushirildi.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Endi biz `buf` ni oddiy tilim sifatida ishlatishimiz mumkin:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Ushbu usuldan *noto'g'ri* foydalanish:
    ///
    /// Qiymatni boshlash uchun siz `.assume_init_mut()` dan foydalana olmaysiz:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Biz boshlanmagan `bool` uchun (mutable) ma'lumotnomasini yaratdik!
    ///     // Bu aniqlanmagan xatti-harakatlar.️
    /// }
    /// ```
    ///
    /// Masalan, siz [`Read`]-ni boshlanmagan buferga kirita olmaysiz:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ishga tushirilmagan xotiraga havola!
    ///                             // Bu aniqlanmagan xatti-harakatlar.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Asta-sekin bosqichma-bosqich ishga tushirishni amalga oshirish uchun to'g'ridan-to'g'ri maydon foydalanish imkoniyatidan ham foydalanishingiz mumkin emas:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ishga tushirilmagan xotiraga havola!
    ///                  // Bu aniqlanmagan xatti-harakatlar.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ishga tushirilmagan xotiraga havola!
    ///                  // Bu aniqlanmagan xatti-harakatlar.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Hozirda biz yuqoridagi ma'lumotlarning noto'g'ri ekanligiga ishonamiz, ya'ni bizda boshlanmagan ma'lumotlarga havolalar mavjud (masalan, `libcore/fmt/float.rs` da).
    // Stabilizatsiya oldidan qoidalar to'g'risida yakuniy qaror qabul qilishimiz kerak.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` ishga tushirilishini kafolatlashi kerak.
        // Bu shuni anglatadiki, `self` `value` varianti bo'lishi kerak.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Bir qator `MaybeUninit` konteynerlaridan qiymatlarni chiqaradi.
    ///
    /// # Safety
    ///
    /// Massivning barcha elementlari boshlang'ich holatida bo'lishiga kafolat berish qo'ng'iroqchiga bog'liq.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // XAVFSIZLIK: Endi biz barcha elementlarni boshlanganda xavfsiz
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Chaqiruvchi massivning barcha elementlari ishga tushirilishini kafolatlaydi
        // * `MaybeUninit<T>` va T ga bir xil tartibga ega bo'lish kafolatlanadi
        // * EhtimolUnint tushmaydi, shuning uchun er-xotin erkinliklar mavjud emas va shuning uchun konvertatsiya xavfsizdir
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Barcha elementlar boshlangan deb hisoblasangiz, ularga tilim oling.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` elementlari haqiqatan ham boshlang'ich holatida ekanligiga kafolat berish qo'ng'iroqchiga bog'liq.
    ///
    /// Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish noaniq xatti-harakatlarni keltirib chiqaradi.
    ///
    /// Batafsil ma'lumot va misollar uchun [`assume_init_ref`]-ga qarang.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // XAVFSIZLIK: tilimni `*const [T]` ga quyish xavfsizdir, chunki qo'ng'iroq qiluvchi buni kafolatlaydi
        // `slice` ishga tushirildi va "BalkiUninit" `T` bilan bir xil tartibga ega bo'lishi kafolatlangan.
        // Olingan ko'rsatgich haqiqiydir, chunki u `slice`-ga tegishli bo'lgan mos yozuvlar va shuning uchun o'qish uchun yaroqli bo'lgan xotiraga tegishli.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Barcha elementlar boshlangan deb hisoblasangiz, ularga o'zgaruvchan bo'lakni oling.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` elementlari haqiqatan ham boshlang'ich holatida ekanligiga kafolat berish qo'ng'iroqchiga bog'liq.
    ///
    /// Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish noaniq xatti-harakatlarni keltirib chiqaradi.
    ///
    /// Batafsil ma'lumot va misollar uchun [`assume_init_mut`]-ga qarang.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // XAVFSIZLIK: `slice_get_ref` uchun xavfsizlik yozuvlariga o'xshash, ammo bizda
        // o'zgarishi mumkin bo'lgan ma'lumotnoma, shuningdek yozish uchun amal qilishi kafolatlanadi
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Massivning birinchi elementiga ko'rsatkichni oladi.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Massivning birinchi elementiga o'zgaruvchan ko'rsatkichni oladi.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` dan `this` gacha bo'lgan elementlarni nusxa ko'chiradi va `this` tarkibiga kiritilgan o'zgaruvchan ma'lumotni qaytaradi.
    ///
    /// Agar `T` `Copy` ni amalga oshirmasa, [`write_slice_cloned`] dan foydalaning
    ///
    /// Bu [`slice::copy_from_slice`] ga o'xshaydi.
    ///
    /// # Panics
    ///
    /// Agar ikkala tilim turli uzunliklarga ega bo'lsa, bu funktsiya panic bo'ladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // XAVFSIZLIK: biz hozirda lenning barcha elementlarini zaxira hajmiga ko'chirdik
    /// // vecning birinchi src.len() elementlari hozirda amal qiladi.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // XAVFSIZLIK: &[T] va&[MaybeUninit<T>] bir xil tartibga ega
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // XAVFSIZLIK: Hozirgina haqiqiy elementlar `this`-ga ko'chirildi, shuning uchun u initsializatsiya qilindi
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` dan `this` gacha bo'lgan elementlarni klonlash, `this` ning hozirda initalizatsiya qilingan tarkibiga o'zgaruvchan havolani qaytarish.
    /// Har qanday allaqachon initalizatsiya qilingan elementlar tashlanmaydi.
    ///
    /// Agar `T` `Copy` ni amalga oshirsa, [`write_slice`] dan foydalaning
    ///
    /// Bu [`slice::clone_from_slice`] ga o'xshaydi, ammo mavjud elementlarni tashlamaydi.
    ///
    /// # Panics
    ///
    /// Agar ikkita tilim turli uzunliklarga ega bo'lsa yoki `Clone` panics amalga oshirilsa, bu funktsiya panic bo'ladi.
    ///
    /// Agar panic bo'lsa, allaqachon klonlangan elementlar tashlanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // XAVFSIZLIK: biz hozirda lenning barcha elementlarini zaxira quvvatiga klonladik
    /// // vecning birinchi src.len() elementlari hozirda amal qiladi.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice-dan farqli o'laroq, bu tilimdagi clone_from_slice deb nomlanmaydi, chunki `MaybeUninit<T: Clone>` Clone-ni qo'llamaydi.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // XAVFSIZLIK: ushbu xom tilim faqat boshlang'ich moslamalarni o'z ichiga oladi
                // Shuning uchun uni tashlab yuborishga ruxsat beriladi.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Biz ularni bir xil uzunlikda aniq kesib olishimiz kerak
        // chegaralarni tekshirish uchun va optimallashtiruvchi oddiy holatlar uchun memcpy hosil qiladi (masalan, T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // b/c panic klonlash paytida sodir bo'lishi mumkin
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // XAVFSIZLIK: Hozirgina haqiqiy elementlar `this`-ga yozilgan, shuning uchun u initsializatsiya qilingan
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}