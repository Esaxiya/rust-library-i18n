//! Standart kutubxonada Panic-ni qo'llab-quvvatlash.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic haqida ma'lumot beruvchi tizim.
///
/// `PanicInfo` struktura [`set_hook`] funktsiyasi tomonidan o'rnatilgan panic hook-ga uzatiladi.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic bilan bog'liq foydali yukni qaytaradi.
    ///
    /// Bu odatda, lekin har doim ham emas, `&'static str` yoki [`String`] bo'ladi.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Agar `core` crate-dan `panic!` makrosi (`std` dan emas) formatlash satri va ba'zi qo'shimcha argumentlar bilan ishlatilgan bo'lsa, ushbu xabarni, masalan, [`fmt::write`] bilan ishlatishga tayyor qilib qaytaradi.
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Agar mavjud bo'lsa, panic paydo bo'lgan joy haqida ma'lumot beradi.
    ///
    /// Ushbu usul hozirda har doim [`Some`]-ni qaytaradi, ammo bu future versiyalarida o'zgarishi mumkin.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Agar bu "Hech qachon" ni o'zgartiradigan bo'lsa,
        // bu ishni std::panicking::default_hook va std::panicking::begin_panic_fmt da ko'rib chiqing.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: downcast_ref: : dan foydalana olmaymiz<String>() Bu yerga
        // chunki string libcore-da mavjud emas!
        // `std::panic!` bir nechta argumentlar bilan chaqirilganda foydali yuk bu String, ammo bu holda xabar ham mavjud.
        //

        self.location.fmt(formatter)
    }
}

/// panic joylashuvi haqidagi ma'lumotlarni o'z ichiga olgan struktura.
///
/// Ushbu tuzilma [`PanicInfo::location()`] tomonidan yaratilgan.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Tenglik va buyurtma uchun taqqoslashlar faylda, satrda, keyin ustun ustunligida amalga oshiriladi.
/// Fayllar `Path` emas, balki satrlar bilan taqqoslanadi, bu kutilmagan bo'lishi mumkin.
/// Ko'proq muhokama qilish uchun ["Location: : file"] ning hujjatlariga qarang.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Ushbu funktsiyani chaqiruvchining manbasini qaytaradi.
    /// Agar ushbu funktsiyani chaqiruvchi izohlangan bo'lsa, u holda uning qo'ng'iroq qilingan joyi qaytariladi va shu bilan birga kuzatilmagan funktsiya tanasi ichidagi birinchi qo'ng'iroq stack-da.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// U chaqirilgan [`Location`]-ni qaytaradi.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Ushbu funktsiya ta'rifi ichidan [`Location`]-ni qaytaradi.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // bir xil kuzatilmagan funktsiyani boshqa joyda ishlatish bizga bir xil natijani beradi
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // kuzatilgan funktsiyani boshqa joyda ishlatish boshqacha qiymat hosil qiladi
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic kelib chiqqan manba faylining nomini qaytaradi.
    ///
    /// # `&str`, `&Path` emas
    ///
    /// Qaytgan ism kompilyatsiya tizimidagi manba yo'lini nazarda tutadi, ammo buni to'g'ridan-to'g'ri `&Path` sifatida ko'rsatish haqiqiy emas.
    /// Tuzilgan kod tarkibni ta'minlaydigan tizimdan farqli o'laroq, boshqa `Path` dasturiga ega bo'lgan boshqa tizimda ishlashi mumkin va bu kutubxonada hozirda boshqa "host path" turi mavjud emas.
    ///
    /// Eng ajablantiradigan xatti-harakatlar, "the same" fayliga modul tizimidagi bir nechta yo'llar orqali (odatda `#[path = "..."]` atributidan yoki shunga o'xshash narsalardan foydalangan holda) erishish mumkin bo'lganda sodir bo'ladi, bu bir xil kod ko'rinadigan narsaning ushbu funktsiyadan farqli qiymatlarni qaytarishiga olib kelishi mumkin.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Ushbu qiymat `Path::new` yoki shunga o'xshash konstruktorlarga o'tish uchun mos kelmaydi, chunki xost platformasi va maqsad platformasi farq qiladi.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic paydo bo'lgan qator raqamini qaytaradi.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic kelib chiqqan ustunni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Libstd-dan libstd-dan `panic_unwind`-ga va boshqa panic ish vaqtlariga ma'lumotlarni uzatish uchun ishlatiladigan ichki trait.
/// Yaqin orada barqarorlashtirish uchun mo'ljallanmagan, foydalanmang.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Tarkibga to'liq egalik qiling.
    /// Qaytish turi aslida `Box<dyn Any + Send>`, lekin biz libcore-da `Box` dan foydalana olmaymiz.
    ///
    /// Ushbu usul chaqirilgandan so'ng, `self`-da ba'zi bir qo'g'irchoq standart qiymat qoladi.
    /// Ushbu usulni ikki marta chaqirish yoki ushbu usulni chaqirgandan so'ng `get`-ni chaqirish xato.
    ///
    /// Argument qarz olindi, chunki panic ish vaqti (`__rust_start_panic`) faqat qarz olgan `dyn BoxMeUp` oladi.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Faqat tarkibini qarzga oling.
    fn get(&mut self) -> &(dyn Any + Send);
}