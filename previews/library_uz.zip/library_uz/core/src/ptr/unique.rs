use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// `*mut T` xom bo'lmagan atrofidagi o'rash, bu o'rash egasi referentga egalik qilishini bildiradi.
/// `Box<T>`, `Vec<T>`, `String` va `HashMap<K, V>` kabi abstraktlarni yaratish uchun foydalidir.
///
/// `*mut T`-dan farqli o'laroq, `Unique<T>` "as if"-ni boshqaradi, bu `T`-ning namunasi edi.
/// `T` `Send`/`Sync` bo'lsa, u `Send`/`Sync` ni amalga oshiradi.
/// Bu, shuningdek, `T` misoli kutishi mumkin bo'lgan kuchli aliasing kafolatlari turini anglatadi:
/// ko'rsatgichning referenti Unique-ga egalik qilishning noyob yo'lisiz o'zgartirilmasligi kerak.
///
/// Agar sizning maqsadlaringiz uchun `Unique` dan foydalanish to'g'riligiga ishonchingiz komil bo'lmasa, zaif semantikasi bo'lgan `NonNull` dan foydalaning.
///
///
/// `*mut T`-dan farqli o'laroq, ko'rsatgich hech qachon bekor qilinmagan bo'lsa ham, har doim nolga teng bo'lishi kerak.
/// Enumlar ushbu taqiqlangan qiymatdan diskriminant sifatida foydalanishlari uchun shunday bo'ladi-`Option<Unique<T>>` hajmi `Unique<T>` bilan bir xil.
/// Biroq, ko'rsatma berilmasa, u hali ham to'xtab qolishi mumkin.
///
/// `*mut T`-dan farqli o'laroq, `Unique<T>` `T`-dan farq qiladi.
/// Bu har doim Unique-ning taxallus talablarini qo'llab-quvvatlaydigan har qanday turga to'g'ri kelishi kerak.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: bu marker dispersiya uchun hech qanday oqibatlarga olib kelmaydi, ammo zarur
    // biz mantiqan `T`-ga egaligimizni tushunish uchun dropck uchun.
    //
    // Tafsilotlar uchun qarang:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` ko'rsatgichlar `Send`, agar `T` `Send` bo'lsa, chunki ular murojaat qilgan ma'lumotlar beparvo.
/// Shuni esda tutingki, bu o'zgaruvchan invariant tip tizimi tomonidan bajarilmaydi;`Unique` yordamida abstraktsiya uni bajarishi kerak.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` ko'rsatgichlar `Sync`, agar `T` `Sync` bo'lsa, chunki ular murojaat qilgan ma'lumotlar beparvo.
/// Shuni esda tutingki, bu o'zgaruvchan invariant tip tizimi tomonidan bajarilmaydi;`Unique` yordamida abstraktsiya uni bajarishi kerak.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Osilib turadigan, lekin yaxshi moslashtirilgan yangi `Unique` yaratadi.
    ///
    /// Bu `Vec::new` kabi dangasa ajratadigan turlarni ishga tushirish uchun foydalidir.
    ///
    /// Shuni esda tutingki, ko'rsatgich qiymati potentsial ravishda `T` uchun to'g'ri ko'rsatgichni ko'rsatishi mumkin, ya'ni bu "not yet initialized" qo'riqchisi qiymati sifatida ishlatilmasligi kerak.
    /// Dangasa ajratadigan turlar boshlang'ichni boshqa usullar bilan kuzatishi kerak.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // XAVFSIZLIK: mem::align_of() yaroqsiz, ko'rsatgichni qaytaradi.The
        // Shunday qilib, new_unchecked()-ga qo'ng'iroq qilish shartlari hurmat qilinadi.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Yangi `Unique` yaratadi.
    ///
    /// # Safety
    ///
    /// `ptr` null bo'lishi kerak.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `ptr` nolga teng emasligiga kafolat berishi kerak.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Agar `ptr` null bo'lsa, yangi `Unique` hosil qiladi.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // XAVFSIZLIK: Ko'rsatkich allaqachon tekshirilgan va bo'sh emas.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Asosiy `*mut` ko'rsatkichini oladi.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Tarkibni qisqartirish.
    ///
    /// Olingan umr o'z-o'zidan bog'liqdir, shuning uchun "as if" o'zini tutadi, chunki bu aslida qarz olayotgan T misoli edi.
    /// Agar ko'proq (unbound) umri zarur bo'lsa, `&*my_ptr.as_ptr()` dan foydalaning.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` barcha talablarga javob berishiga kafolat berishi kerak
        // ma'lumotnomaga qo'yiladigan talablar.
        unsafe { &*self.as_ptr() }
    }

    /// O'zaro aloqador tarkibni o'chirib tashlaydi.
    ///
    /// Olingan umr o'z-o'zidan bog'liqdir, shuning uchun "as if" o'zini tutadi, chunki bu aslida qarz olayotgan T misoli edi.
    /// Agar ko'proq (unbound) umri zarur bo'lsa, `&mut *my_ptr.as_ptr()` dan foydalaning.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` barcha talablarga javob berishiga kafolat berishi kerak
        // o'zgarishi mumkin bo'lgan ma'lumotnomaga qo'yiladigan talablar.
        unsafe { &mut *self.as_ptr() }
    }

    /// Boshqa turdagi ko'rsatgichga tashlanadi.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // XAVFSIZLIK: Unique::new_unchecked() yangi noyob va ehtiyojlarni yaratadi
        // berilgan ko'rsatkich nolga teng emas.
        // O'zimizni ko'rsatgich sifatida o'tayotganimiz uchun u nol bo'lishi mumkin emas.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // XAVFSIZLIK: O'zgaruvchan mos yozuvlar nol bo'lishi mumkin emas
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}