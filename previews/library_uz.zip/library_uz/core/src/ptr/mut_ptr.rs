use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Agar ko'rsatkich nol bo'lsa, `true`-ni qaytaradi.
    ///
    /// Shuni esda tutingki, o'lchamsiz turlar juda ko'p null ko'rsatkichlarga ega, chunki faqat xom ma'lumotlar ko'rsatkichi hisobga olinadi, ularning uzunligi, vtable va boshqalar.
    /// Shuning uchun nol bo'lgan ikkita ko'rsatkich hali ham bir-biriga teng kelmasligi mumkin.
    ///
    /// ## Konstni baholash paytida o'zini tutish
    ///
    /// Ushbu funktsiya konstni baholashda ishlatilganda, u ish vaqtida nolga teng bo'lgan ko'rsatkichlar uchun `false` qiymatini qaytarishi mumkin.
    /// Xususan, ba'zi bir xotiraga ko'rsatgich, natijada ko'rsatgich nolga teng bo'ladigan tarzda o'z chegaralaridan tashqariga chiqarilganda, funktsiya `false`-ni qaytaradi.
    ///
    /// CTFE uchun ushbu xotiraning mutlaq holatini bilish imkoniyati yo'q, shuning uchun ko'rsatgich nolga teng yoki yo'qligini aniqlay olmaymiz.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Gips orqali ingichka ko'rsatkichni taqqoslang, shuning uchun yog 'ko'rsatkichlari faqat "data" qismini bekor qilish uchun hisobga olishadi.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Boshqa turdagi ko'rsatgichga tashlanadi.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// (Keng bo'lishi mumkin) ko'rsatgichni manzil va metama'lumotlar komponentlariga ajrating.
    ///
    /// Keyinchalik ko'rsatkichni [`from_raw_parts_mut`] yordamida tiklash mumkin.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Agar ko'rsatgich null bo'lsa, `None`-ni qaytaradi yoki aks holda `Some`-ga o'ralgan qiymatga umumiy havolani qaytaradi.Agar qiymat ishga tushirilmagan bo'lsa, uning o'rniga [`as_uninit_ref`] ishlatilishi kerak.
    ///
    /// O'zgaruvchan hamkori uchun [`as_mut`]-ga qarang.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Ushbu usulni chaqirganda,* **ko'rsatkich NULL* yoki * quyidagilarning barchasi to'g'ri ekanligiga ishonch hosil qilishingiz kerak:
    ///
    /// * Ko'rsatkich to'g'ri tekislangan bo'lishi kerak.
    ///
    /// * [the module documentation] da belgilangan ma'noda "dereferencable" bo'lishi kerak.
    ///
    /// * Ko'rsatkich `T` ning boshlang'ich nusxasini ko'rsatishi kerak.
    ///
    /// * Qaytgan hayot muddati `'a` o'zboshimchalik bilan tanlanganligi va ma'lumotlarning haqiqiy ishlash muddatini aks ettirmasligi sababli Rust-ning taxallus qoidalarini bajarishingiz kerak.
    ///   Xususan, ushbu umr davomida ko'rsatgich ko'rsatgan xotira mutatsiyaga tushmasligi kerak (`UnsafeCell` ichidan tashqari).
    ///
    /// Ushbu usul natijasi ishlatilmagan bo'lsa ham amal qiladi!
    /// (Ishga tushirish qismi hali to'liq hal qilinmagan, ammo shu paytgacha yagona xavfsiz yondashuv ular haqiqatan ham ishga tushirilishini ta'minlashdir.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Tekshirilmagan versiya
    ///
    /// Agar siz ko'rsatgich hech qachon nolga teng bo'lmasligiga amin bo'lsangiz va `Option<&T>` o'rniga `&T` ni qaytaradigan biron bir `as_ref_unchecked` izlayotgan bo'lsangiz, bilingki, to'g'ridan-to'g'ri ko'rsatgichdan voz kechishingiz mumkin.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` ning a
        // agar u bo'sh bo'lsa, mos yozuvlar.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Agar ko'rsatgich null bo'lsa, `None` qiymatini qaytaradi yoki aks holda `Some` ga o'ralgan qiymatga umumiy havolani qaytaradi.
    /// [`as_ref`]-dan farqli o'laroq, bu qiymatni boshlashni talab qilmaydi.
    ///
    /// O'zgaruvchan hamkori uchun [`as_uninit_mut`]-ga qarang.
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ushbu usulni chaqirganda,* **ko'rsatkich NULL* yoki * quyidagilarning barchasi to'g'ri ekanligiga ishonch hosil qilishingiz kerak:
    ///
    /// * Ko'rsatkich to'g'ri tekislangan bo'lishi kerak.
    ///
    /// * [the module documentation] da belgilangan ma'noda "dereferencable" bo'lishi kerak.
    ///
    /// * Qaytgan hayot muddati `'a` o'zboshimchalik bilan tanlanganligi va ma'lumotlarning haqiqiy ishlash muddatini aks ettirmasligi sababli Rust-ning taxallus qoidalarini bajarishingiz kerak.
    ///
    ///   Xususan, ushbu umr davomida ko'rsatgich ko'rsatgan xotira mutatsiyaga tushmasligi kerak (`UnsafeCell` ichidan tashqari).
    ///
    /// Ushbu usul natijasi ishlatilmagan bo'lsa ham amal qiladi!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` barcha talablarga javob berishiga kafolat berishi kerak
        // ma'lumotnomaga qo'yiladigan talablar.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Ko'rsatkichdan ofsetni hisoblab chiqadi.
    ///
    /// `count` T birliklarida;Masalan, 3-ning `count`-si `3 * size_of::<T>()` baytining ko'rsatgich ofsetini bildiradi.
    ///
    /// # Safety
    ///
    /// Agar quyidagi shartlardan biri buzilgan bo'lsa, unda aniqlanmagan xatti-harakatlar paydo bo'ladi:
    ///
    /// * Har ikkala boshlang'ich va natijada ko'rsatgich chegaralarda yoki bir xil ajratilgan ob'ekt oxiridan bir bayt o'tishi kerak.
    /// Rust-da har bir (stack-allocated) o'zgaruvchisi alohida ajratilgan ob'ekt sifatida qaralishini unutmang.
    ///
    /// * Hisoblangan ofset,**baytda**, `isize` dan oshib keta olmaydi.
    ///
    /// * Chegarada bo'lgan ofset "wrapping around" manzil maydoniga ishona olmaydi.Ya'ni,**baytda** bo'lgan cheksiz aniqlik yig'indisi usize-ga mos kelishi kerak.
    ///
    /// Tuzuvchi va standart kutubxona odatda ajratmalar hech qachon ofset xavfi tug'diradigan hajmga etib bormasligini ta'minlashga harakat qiladi.
    /// Masalan, `Vec` va `Box` hech qachon `isize::MAX` baytdan ko'proq ajratmasligini ta'minlaydi, shuning uchun `vec.as_ptr().add(vec.len())` har doim xavfsizdir.
    ///
    /// Aksariyat platformalar hatto bunday ajratishni ham tuza olmaydi.
    /// Masalan, ma'lum bir 64-bitli platforma hech qachon sahifa jadvalidagi cheklovlar yoki manzil maydonini ajratish sababli 2 <sup>63</sup> baytlik so'rovni bajarishi mumkin emas.
    /// Biroq, ba'zi 32-bit va 16-bitli platformalar jismoniy manzil kengaytmasi kabi narsalar bilan `isize::MAX` baytdan ko'proq so'rovni muvaffaqiyatli bajarishi mumkin.
    ///
    /// Shunday qilib, to'g'ridan-to'g'ri ajratuvchilardan yoki xotira bilan bog'langan fayllardan olingan xotira * bu funktsiyani bajarish uchun juda katta bo'lishi mumkin.
    ///
    /// Ushbu cheklovlarni qondirish qiyin bo'lsa, buning o'rniga [`wrapping_offset`] dan foydalanishni o'ylab ko'ring.
    /// Ushbu usulning yagona afzalligi shundaki, u yanada agressiv kompilyator optimallashtirishga imkon beradi.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `offset` uchun xavfsizlik shartnomasini bajarishi kerak.
        // Olingan ko'rsatgich yozuvlar uchun amal qiladi, chunki qo'ng'iroq qiluvchi `self` bilan ajratilgan ob'ektga ishora qilishiga kafolat berishi kerak.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// O'rnatish arifmetikasi yordamida ko'rsatkichni ofsetni hisoblab chiqadi.
    /// `count` T birliklarida;Masalan, 3-ning `count`-si `3 * size_of::<T>()` baytining ko'rsatgich ofsetini bildiradi.
    ///
    /// # Safety
    ///
    /// Ushbu operatsiyaning o'zi har doim xavfsizdir, ammo natijada ko'rsatgichdan foydalanish mumkin emas.
    ///
    /// Olingan ko'rsatkich `self` ko'rsatgan bir xil ajratilgan ob'ektga biriktirilgan bo'lib qoladi.
    /// Boshqa ajratilgan ob'ektga kirish uchun *ishlatilmasligi* mumkin.Rust-da har bir (stack-allocated) o'zgaruvchisi alohida ajratilgan ob'ekt sifatida qaralishini unutmang.
    ///
    /// Boshqacha qilib aytganda, `let z = x.wrapping_offset((y as isize) - (x as isize))` `1` o'lchamiga ega deb hisoblasak va hech qanday toshib ketmasa ham, `let z = x.wrapping_offset((y as isize) - (x as isize))` `z` ni `y` bilan bir xil qilmaydi *: `z` hanuzgacha `x` moslamasiga biriktirilgan va uni ajratib ko'rsatish `x` bo'lmasa aniqlanmagan xatti-harakatlar `y` bir xil ajratilgan ob'ektga ishora qiladi.
    ///
    /// [`offset`] bilan taqqoslaganda, bu usul asosan bir xil ajratilgan ob'ekt ichida qolish talabini kechiktiradi: [`offset`]-ob'ekt chegaralarini kesib o'tishda darhol aniqlanmagan xatti-harakatlar;`wrapping_offset` ko'rsatgichni ishlab chiqaradi, lekin ko'rsatgich biriktirilgan ob'ekt chegarasidan tashqarida bo'lsa, u aniqlanmagan xatti-harakatga olib keladi.
    /// [`offset`] yaxshiroq optimallashtirilishi mumkin va shuning uchun ishlashga sezgir kodda afzalroqdir.
    ///
    /// Kechiktirilgan tekshiruv faqat ko'rsatgichning qiymatini hisobga oladi, yakuniy natijani hisoblash paytida ishlatiladigan oraliq qiymatlarni emas.
    /// Masalan, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` har doim `x` bilan bir xil.Boshqacha qilib aytganda, ajratilgan ob'ektni qoldirib, keyinroq uni qayta kiritishga ruxsat beriladi.
    ///
    /// Ob'ekt chegaralarini kesib o'tishingiz kerak bo'lsa, ko'rsatkichni butun songa qo'ying va u erda arifmetikani bajaring.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// // Xom ko'rsatkichni ikkita element o'sishida takrorlang
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // XAVFSIZLIK: ichki `arith_offset` deb nomlanadigan hech qanday shartlar mavjud emas.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Agar ko'rsatgich null bo'lsa, `None` qiymatini qaytaradi yoki aks holda `Some` ga o'ralgan qiymatga noyob havolani qaytaradi.Agar qiymat ishga tushirilmagan bo'lsa, uning o'rniga [`as_uninit_mut`] ishlatilishi kerak.
    ///
    /// Umumiy sherik uchun [`as_ref`]-ga qarang.
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Ushbu usulni chaqirganda,* **ko'rsatkich NULL* yoki * quyidagilarning barchasi to'g'ri ekanligiga ishonch hosil qilishingiz kerak:
    ///
    /// * Ko'rsatkich to'g'ri tekislangan bo'lishi kerak.
    ///
    /// * [the module documentation] da belgilangan ma'noda "dereferencable" bo'lishi kerak.
    ///
    /// * Ko'rsatkich `T` ning boshlang'ich nusxasini ko'rsatishi kerak.
    ///
    /// * Qaytgan hayot muddati `'a` o'zboshimchalik bilan tanlanganligi va ma'lumotlarning haqiqiy ishlash muddatini aks ettirmasligi sababli Rust-ning taxallus qoidalarini bajarishingiz kerak.
    ///   Xususan, ushbu umr davomida ko'rsatgich ko'rsatgan xotiraga boshqa ko'rsatgich orqali kirish (o'qish yoki yozish) kerak emas.
    ///
    /// Ushbu usul natijasi ishlatilmagan bo'lsa ham amal qiladi!
    /// (Ishga tushirish qismi hali to'liq hal qilinmagan, ammo shu paytgacha yagona xavfsiz yondashuv ular haqiqatan ham ishga tushirilishini ta'minlashdir.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // U chop etadi: "[4, 2, 3]".
    /// ```
    ///
    /// # Tekshirilmagan versiya
    ///
    /// Agar siz ko'rsatgich hech qachon nolga teng bo'lmasligiga amin bo'lsangiz va `Option<&mut T>` o'rniga `&mut T` ni qaytaradigan biron bir `as_mut_unchecked` izlayotgan bo'lsangiz, bilingki, to'g'ridan-to'g'ri ko'rsatgichdan voz kechishingiz mumkin.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // U chop etadi: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` uchun haqiqiyligini kafolatlashi kerak
        // o'zgarmas mos yozuvlar, agar u null bo'lmasa.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Agar ko'rsatgich null bo'lsa, `None` qiymatini qaytaradi yoki aks holda `Some` ga o'ralgan qiymatga noyob havolani qaytaradi.
    /// [`as_mut`]-dan farqli o'laroq, bu qiymatni boshlashni talab qilmaydi.
    ///
    /// Umumiy sherik uchun [`as_uninit_ref`]-ga qarang.
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Ushbu usulni chaqirganda,* **ko'rsatkich NULL* yoki * quyidagilarning barchasi to'g'ri ekanligiga ishonch hosil qilishingiz kerak:
    ///
    /// * Ko'rsatkich to'g'ri tekislangan bo'lishi kerak.
    ///
    /// * [the module documentation] da belgilangan ma'noda "dereferencable" bo'lishi kerak.
    ///
    /// * Qaytgan hayot muddati `'a` o'zboshimchalik bilan tanlanganligi va ma'lumotlarning haqiqiy ishlash muddatini aks ettirmasligi sababli Rust-ning taxallus qoidalarini bajarishingiz kerak.
    ///
    ///   Xususan, ushbu umr davomida ko'rsatgich ko'rsatgan xotiraga boshqa ko'rsatgich orqali kirish (o'qish yoki yozish) kerak emas.
    ///
    /// Ushbu usul natijasi ishlatilmagan bo'lsa ham amal qiladi!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` barcha talablarga javob berishiga kafolat berishi kerak
        // ma'lumotnomaga qo'yiladigan talablar.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Ikkala ko'rsatkichning tengligi kafolatlanganmi yoki yo'qligini qaytaradi.
    ///
    /// Ish paytida bu funktsiya `self == other` kabi ishlaydi.
    /// Biroq, ayrim kontekstlarda (masalan, kompilyatsiya vaqtini baholash) har doim ham ikkita ko'rsatkichning tengligini aniqlash mumkin emas, shuning uchun bu funktsiya keyinchalik teng bo'lgan ko'rsatkichlarga `false`-ni soxta ravishda qaytarishi mumkin.
    ///
    /// Ammo u `true` ni qaytarganda, ko'rsatkichlar teng bo'lishiga kafolat beradi.
    ///
    /// Ushbu funktsiya [`guaranteed_ne`] oynasidir, lekin uning teskari emas.Ikkala funktsiya ham `false` ni qaytaradigan ko'rsatkichlarni taqqoslash mavjud.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Qaytish qiymati kompilyator versiyasiga qarab o'zgarishi mumkin va xavfli kod bu funktsiya natijasiga ishonchliligi uchun ishonmasligi mumkin.
    /// Ushbu funktsiyadan faqat ishlashni optimallashtirish uchun foydalanish tavsiya etiladi, agar bu funktsiya bo'yicha soxta `false` qiymatlari natijaga ta'sir qilmasa, shunchaki ishlashga ta'sir qiladi.
    /// Ishlash vaqti va kompilyatsiya vaqti kodini boshqacha tutish uchun ushbu usuldan foydalanishning natijalari o'rganilmagan.
    /// Bunday farqni joriy qilish uchun ushbu usuldan foydalanmaslik kerak, shuningdek, biz ushbu masalani yaxshiroq tushunishdan oldin uni barqarorlashtirish kerak emas.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Ikkala ko'rsatkich tengsizligi kafolatlanganmi yoki yo'qligini qaytaradi.
    ///
    /// Ish paytida bu funktsiya `self != other` kabi ishlaydi.
    /// Biroq, ba'zi bir sharoitlarda (masalan, kompilyatsiya vaqtini baholash) har doim ham ikkita ko'rsatgichning tengsizligini aniqlash mumkin emas, shuning uchun bu funktsiya keyinchalik tengsiz bo'lib chiqadigan ko'rsatkichlar uchun `false` ni soxta ravishda qaytarishi mumkin.
    ///
    /// Ammo u `true` ni qaytarganda, ko'rsatgichlar teng bo'lmasligi kafolatlanadi.
    ///
    /// Ushbu funktsiya [`guaranteed_eq`] oynasidir, lekin uning teskari emas.Ikkala funktsiya ham `false` ni qaytaradigan ko'rsatkichlarni taqqoslash mavjud.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Qaytish qiymati kompilyator versiyasiga qarab o'zgarishi mumkin va xavfli kod bu funktsiya natijasiga ishonchliligi uchun ishonmasligi mumkin.
    /// Ushbu funktsiyadan faqat ishlashni optimallashtirish uchun foydalanish tavsiya etiladi, agar bu funktsiya bo'yicha soxta `false` qiymatlari natijaga ta'sir qilmasa, shunchaki ishlashga ta'sir qiladi.
    /// Ishlash vaqti va kompilyatsiya vaqti kodini boshqacha tutish uchun ushbu usuldan foydalanishning natijalari o'rganilmagan.
    /// Bunday farqni joriy qilish uchun ushbu usuldan foydalanmaslik kerak, shuningdek, biz ushbu masalani yaxshiroq tushunishdan oldin uni barqarorlashtirish kerak emas.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Ikki ko'rsatgich orasidagi masofani hisoblab chiqadi.Qaytgan qiymat T birliklarida: baytlardagi masofa `mem::size_of::<T>()` ga bo'linadi.
    ///
    /// Ushbu funktsiya [`offset`]-ga teskari.
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Agar quyidagi shartlardan biri buzilgan bo'lsa, unda aniqlanmagan xatti-harakatlar paydo bo'ladi:
    ///
    /// * Boshlang'ich va boshqa ko'rsatgich chegaralarda yoki bir xil ajratilgan ob'ekt oxiridan bir baytda bo'lishi kerak.
    /// Rust-da har bir (stack-allocated) o'zgaruvchisi alohida ajratilgan ob'ekt sifatida qaralishini unutmang.
    ///
    /// * Ikkala ko'rsatgich ham bir xil ob'ektga ko'rsatgichdan * olinishi kerak.
    ///   (Misol uchun quyida ko'ring.)
    ///
    /// * Ko'rsatkichlar orasidagi masofa baytda, `T` o'lchamining aniq ko'paytmasi bo'lishi kerak.
    ///
    /// * Ko'rsatkichlar orasidagi masofa,**baytda**, `isize` dan oshib keta olmaydi.
    ///
    /// * Chegaralarda bo'lgan masofa "wrapping around" manzil maydoniga tayanolmaydi.
    ///
    /// Rust turlari hech qachon `isize::MAX` dan kattaroq emas va Rust taqsimotlari hech qachon manzil maydonini o'rab olmaydi, shuning uchun har qanday Rust `T` tipidagi bir nechta qiymatdagi ikkita ko'rsatkich har doim oxirgi ikki shartni qondiradi.
    ///
    /// Standart kutubxona, odatda, ajratmalar hech qachon ofset xavfi tug'diradigan hajmga etmasligini ta'minlaydi.
    /// Masalan, `Vec` va `Box` hech qachon `isize::MAX` baytdan ko'proq ajratmasligini ta'minlaydi, shuning uchun `ptr_into_vec.offset_from(vec.as_ptr())` har doim oxirgi ikkita shartni qondiradi.
    ///
    /// Aksariyat platformalar hatto bunday katta hajmdagi mablag'ni barpo eta olmaydi.
    /// Masalan, ma'lum bir 64-bitli platforma hech qachon sahifa jadvalidagi cheklovlar yoki manzil maydonini ajratish sababli 2 <sup>63</sup> baytlik so'rovni bajarishi mumkin emas.
    /// Biroq, ba'zi 32-bit va 16-bitli platformalar jismoniy manzil kengaytmasi kabi narsalar bilan `isize::MAX` baytdan ko'proq so'rovni muvaffaqiyatli bajarishi mumkin.
    /// Shunday qilib, to'g'ridan-to'g'ri ajratuvchilardan yoki xotira bilan bog'langan fayllardan olingan xotira * bu funktsiyani bajarish uchun juda katta bo'lishi mumkin.
    /// (E'tibor bering, [`offset`] va [`add`] ham shunga o'xshash cheklovlarga ega va shuning uchun bunday katta ajratmalarda ham foydalanish mumkin emas.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ushbu funktsiya panics, agar `T` nol o'lchamdagi ("ZST") turi bo'lsa.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Noto'g'ri* foydalanish:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Ptr2_other-ni "alias"-dan "alias" qiling, lekin ptr1-dan kelib chiqadi.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Ptr2_other va ptr2 ko'rsatgichlardan turli xil ob'ektlarga kelib chiqqanligi sababli, ular bir xil manzilga ishora qilsalar ham, ularning o'rnini hisoblash aniqlanmagan xatti-harakatlardir!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Aniqlanmagan xatti-harakatlar
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `offset_from` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Ko'rsatkichdan ofsetni hisoblab chiqadi (`.offset(count as isize)`) uchun qulaylik.
    ///
    /// `count` T birliklarida;Masalan, 3-ning `count`-si `3 * size_of::<T>()` baytining ko'rsatgich ofsetini bildiradi.
    ///
    /// # Safety
    ///
    /// Agar quyidagi shartlardan biri buzilgan bo'lsa, unda aniqlanmagan xatti-harakatlar paydo bo'ladi:
    ///
    /// * Har ikkala boshlang'ich va natijada ko'rsatgich chegaralarda yoki bir xil ajratilgan ob'ekt oxiridan bir bayt o'tishi kerak.
    /// Rust-da har bir (stack-allocated) o'zgaruvchisi alohida ajratilgan ob'ekt sifatida qaralishini unutmang.
    ///
    /// * Hisoblangan ofset,**baytda**, `isize` dan oshib keta olmaydi.
    ///
    /// * Chegaralangan ofset "wrapping around" manzil maydoniga ishona olmaydi.Ya'ni cheksiz aniqlik yig'indisi `usize` ga to'g'ri kelishi kerak.
    ///
    /// Tuzuvchi va standart kutubxona odatda ajratmalar hech qachon ofset xavfi tug'diradigan hajmga etib bormasligini ta'minlashga harakat qiladi.
    /// Masalan, `Vec` va `Box` hech qachon `isize::MAX` baytdan ko'proq ajratmasligini ta'minlaydi, shuning uchun `vec.as_ptr().add(vec.len())` har doim xavfsizdir.
    ///
    /// Aksariyat platformalar hatto bunday ajratishni ham tuza olmaydi.
    /// Masalan, ma'lum bir 64-bitli platforma hech qachon sahifa jadvalidagi cheklovlar yoki manzil maydonini ajratish sababli 2 <sup>63</sup> baytlik so'rovni bajarishi mumkin emas.
    /// Biroq, ba'zi 32-bit va 16-bitli platformalar jismoniy manzil kengaytmasi kabi narsalar bilan `isize::MAX` baytdan ko'proq so'rovni muvaffaqiyatli bajarishi mumkin.
    ///
    /// Shunday qilib, to'g'ridan-to'g'ri ajratuvchilardan yoki xotira bilan bog'langan fayllardan olingan xotira * bu funktsiyani bajarish uchun juda katta bo'lishi mumkin.
    ///
    /// Ushbu cheklovlarni qondirish qiyin bo'lsa, buning o'rniga [`wrapping_add`] dan foydalanishni o'ylab ko'ring.
    /// Ushbu usulning yagona afzalligi shundaki, u yanada agressiv kompilyator optimallashtirishga imkon beradi.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `offset` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { self.offset(count as isize) }
    }

    /// Ko'rsatkichdan ofsetni hisoblaydi (.. Ofset uchun qulaylik ((isize).wrapping_neg())`) deb hisoblang).
    ///
    /// `count` T birliklarida;Masalan, 3-ning `count`-si `3 * size_of::<T>()` baytining ko'rsatgich ofsetini bildiradi.
    ///
    /// # Safety
    ///
    /// Agar quyidagi shartlardan biri buzilgan bo'lsa, unda aniqlanmagan xatti-harakatlar paydo bo'ladi:
    ///
    /// * Har ikkala boshlang'ich va natijada ko'rsatgich chegaralarda yoki bir xil ajratilgan ob'ekt oxiridan bir bayt o'tishi kerak.
    /// Rust-da har bir (stack-allocated) o'zgaruvchisi alohida ajratilgan ob'ekt sifatida qaralishini unutmang.
    ///
    /// * Hisoblangan ofset `isize::MAX`**bayt** dan oshmasligi kerak.
    ///
    /// * Chegarada bo'lgan ofset "wrapping around" manzil maydoniga ishona olmaydi.Ya'ni cheksiz aniqlik yig'indisi usize-ga mos kelishi kerak.
    ///
    /// Tuzuvchi va standart kutubxona odatda ajratmalar hech qachon ofset xavfi tug'diradigan hajmga etib bormasligini ta'minlashga harakat qiladi.
    /// Masalan, `Vec` va `Box` hech qachon `isize::MAX` baytdan ko'proq ajratmasligini ta'minlaydi, shuning uchun `vec.as_ptr().add(vec.len()).sub(vec.len())` har doim xavfsizdir.
    ///
    /// Aksariyat platformalar hatto bunday ajratishni ham tuza olmaydi.
    /// Masalan, ma'lum bir 64-bitli platforma hech qachon sahifa jadvalidagi cheklovlar yoki manzil maydonini ajratish sababli 2 <sup>63</sup> baytlik so'rovni bajarishi mumkin emas.
    /// Biroq, ba'zi 32-bit va 16-bitli platformalar jismoniy manzil kengaytmasi kabi narsalar bilan `isize::MAX` baytdan ko'proq so'rovni muvaffaqiyatli bajarishi mumkin.
    ///
    /// Shunday qilib, to'g'ridan-to'g'ri ajratuvchilardan yoki xotira bilan bog'langan fayllardan olingan xotira * bu funktsiyani bajarish uchun juda katta bo'lishi mumkin.
    ///
    /// Ushbu cheklovlarni qondirish qiyin bo'lsa, buning o'rniga [`wrapping_sub`] dan foydalanishni o'ylab ko'ring.
    /// Ushbu usulning yagona afzalligi shundaki, u yanada agressiv kompilyator optimallashtirishga imkon beradi.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `offset` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// O'rnatish arifmetikasi yordamida ko'rsatkichni ofsetni hisoblab chiqadi.
    /// (`.wrapping_offset(count as isize)`) uchun qulaylik
    ///
    /// `count` T birliklarida;Masalan, 3-ning `count`-si `3 * size_of::<T>()` baytining ko'rsatgich ofsetini bildiradi.
    ///
    /// # Safety
    ///
    /// Ushbu operatsiyaning o'zi har doim xavfsizdir, ammo natijada ko'rsatgichdan foydalanish mumkin emas.
    ///
    /// Olingan ko'rsatkich `self` ko'rsatgan bir xil ajratilgan ob'ektga biriktirilgan bo'lib qoladi.
    /// Boshqa ajratilgan ob'ektga kirish uchun *ishlatilmasligi* mumkin.Rust-da har bir (stack-allocated) o'zgaruvchisi alohida ajratilgan ob'ekt sifatida qaralishini unutmang.
    ///
    /// Boshqacha qilib aytganda, X0 `T``1` o'lchamiga ega bo'lsa va ortiqcha toshib ketmasa ham, `let z = x.wrapping_add((y as usize) - (x as usize))` `z` ni `y` bilan bir xil qilmaydi *: `z` hali ham `x` ob'ektiga biriktirilgan va uni ajratish, `x` va `y` bir xil ajratilgan ob'ektga ishora qiladi.
    ///
    /// [`add`] bilan taqqoslaganda, bu usul asosan bir xil ajratilgan ob'ekt ichida qolish talabini kechiktiradi: [`add`]-ob'ekt chegaralarini kesib o'tishda darhol aniqlanmagan xatti-harakatlar;`wrapping_add` ko'rsatgichni ishlab chiqaradi, lekin ko'rsatgich biriktirilgan ob'ekt chegarasidan tashqarida bo'lsa, u aniqlanmagan xatti-harakatga olib keladi.
    /// [`add`] yaxshiroq optimallashtirilishi mumkin va shuning uchun ishlashga sezgir kodda afzalroqdir.
    ///
    /// Kechiktirilgan tekshiruv faqat ko'rsatgichning qiymatini hisobga oladi, yakuniy natijani hisoblash paytida ishlatiladigan oraliq qiymatlarni emas.
    /// Masalan, `x.wrapping_add(o).wrapping_sub(o)` har doim `x` bilan bir xil.Boshqacha qilib aytganda, ajratilgan ob'ektni qoldirib, keyinroq uni qayta kiritishga ruxsat beriladi.
    ///
    /// Ob'ekt chegaralarini kesib o'tishingiz kerak bo'lsa, ko'rsatkichni butun songa qo'ying va u erda arifmetikani bajaring.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// // Xom ko'rsatkichni ikkita element o'sishida takrorlang
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ushbu pastadir "1, 3, 5, "-ni bosib chiqaradi
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// O'rnatish arifmetikasi yordamida ko'rsatkichni ofsetni hisoblab chiqadi.
    /// (.wrapping_offset uchun qulaylik ((isize).wrapping_neg())`) deb hisoblang
    ///
    /// `count` T birliklarida;Masalan, 3-ning `count`-si `3 * size_of::<T>()` baytining ko'rsatgich ofsetini bildiradi.
    ///
    /// # Safety
    ///
    /// Ushbu operatsiyaning o'zi har doim xavfsizdir, ammo natijada ko'rsatgichdan foydalanish mumkin emas.
    ///
    /// Olingan ko'rsatkich `self` ko'rsatgan bir xil ajratilgan ob'ektga biriktirilgan bo'lib qoladi.
    /// Boshqa ajratilgan ob'ektga kirish uchun *ishlatilmasligi* mumkin.Rust-da har bir (stack-allocated) o'zgaruvchisi alohida ajratilgan ob'ekt sifatida qaralishini unutmang.
    ///
    /// Boshqacha qilib aytganda, `let z = x.wrapping_sub((x as usize) - (y as usize))` `1` o'lchamiga ega deb hisoblasak va hech qanday toshib ketmasa ham, `let z = x.wrapping_sub((x as usize) - (y as usize))` `z` ni `y` bilan bir xil qilmaydi *: `z` hali ham `x` ob'ektiga biriktirilgan va uni ajratib ko'rsatish `x` va boshqa holatlar bundan mustasno. `y` bir xil ajratilgan ob'ektga ishora qiladi.
    ///
    /// [`sub`] bilan taqqoslaganda, bu usul asosan bir xil ajratilgan ob'ekt ichida qolish talabini kechiktiradi: [`sub`]-ob'ekt chegaralarini kesib o'tishda darhol aniqlanmagan xatti-harakatlar;`wrapping_sub` ko'rsatgichni ishlab chiqaradi, lekin ko'rsatgich biriktirilgan ob'ekt chegarasidan tashqarida bo'lsa, u aniqlanmagan xatti-harakatga olib keladi.
    /// [`sub`] yaxshiroq optimallashtirilishi mumkin va shuning uchun ishlashga sezgir kodda afzalroqdir.
    ///
    /// Kechiktirilgan tekshiruv faqat ko'rsatgichning qiymatini hisobga oladi, yakuniy natijani hisoblash paytida ishlatiladigan oraliq qiymatlarni emas.
    /// Masalan, `x.wrapping_add(o).wrapping_sub(o)` har doim `x` bilan bir xil.Boshqacha qilib aytganda, ajratilgan ob'ektni qoldirib, keyinroq uni qayta kiritishga ruxsat beriladi.
    ///
    /// Ob'ekt chegaralarini kesib o'tishingiz kerak bo'lsa, ko'rsatkichni butun songa qo'ying va u erda arifmetikani bajaring.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// // (backwards) elementlarining o'sishida xom ko'rsatgich yordamida takrorlang
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ushbu pastadir "5, 3, 1, "-ni bosib chiqaradi
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Ko'rsatkich qiymatini `ptr` ga o'rnatadi.
    ///
    /// Agar `self` o'lchamsiz turga ko'rsatuvchi (fat) ko'rsatkichi bo'lsa, bu operatsiya faqat ko'rsatgich qismiga ta'sir qiladi, (thin) ko'rsatkichlari uchun esa o'lchamdagi turlarga bu oddiy topshiriq bilan bir xil ta'sir ko'rsatadi.
    ///
    /// Olingan ko'rsatkich `val` ni tasdiqlaydi, ya'ni semiz ko'rsatkichi uchun bu operatsiya ma'no jihatidan `val` ma'lumotlar ko'rsatgichi qiymati bilan `self` metama'lumiga ega bo'lgan yangi yog 'ko'rsatkichini yaratish bilan bir xildir.
    ///
    ///
    /// # Examples
    ///
    /// Ushbu funktsiya, birinchi navbatda, potentsial yog 'ko'rsatkichlarida baytli ko'rsatkich arifmetikasiga ruxsat berish uchun foydalidir:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // "3"-ni chop etadi
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // XAVFSIZLIK: yupqa ko'rsatgich bo'lsa, bu amallar bir xil bo'ladi
        // oddiy topshiriqqa.
        // Yog 'ko'rsatgichi holatida, joriy yog' ko'rsatgichining joylashuvi bilan, bunday ko'rsatkichning birinchi maydoni har doim ham xuddi shu tarzda tayinlangan ma'lumotlar ko'rsatkichidir.
        //
        unsafe { *thin = val };
        self
    }

    /// `self`-dan qiymatni harakatga keltirmasdan o'qiydi.
    /// Bu `self` xotirani o'zgarmaydi.
    ///
    /// [`ptr::read`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { read(self) }
    }

    /// `self`-dan qiymatni o'zgartirmasdan o'qiydi.Bu `self` xotirani o'zgarishsiz qoldiradi.
    ///
    /// O'zgaruvchan operatsiyalar I/O xotirasida ishlashga mo'ljallangan bo'lib, boshqa uchuvchan operatsiyalar bo'yicha kompilyator tomonidan o'tkazilmasligi yoki tartiblashtirilmasligi kafolatlanadi.
    ///
    ///
    /// [`ptr::read_volatile`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `read_volatile` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { read_volatile(self) }
    }

    /// `self`-dan qiymatni harakatga keltirmasdan o'qiydi.
    /// Bu `self` xotirani o'zgarmaydi.
    ///
    /// `read`-dan farqli o'laroq, ko'rsatgich tekislanmagan bo'lishi mumkin.
    ///
    /// [`ptr::read_unaligned`]-ga qarang, xavfsizlik masalalari va misollar
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `read_unaligned` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { read_unaligned(self) }
    }

    /// `count * size_of<T>` baytlarini `self` dan `dest` gacha nusxa ko'chiradi.
    /// Manba va manzil bir-biriga to'g'ri kelishi mumkin.
    ///
    /// NOTE: bu [`ptr::copy`] bilan *bir xil* argument tartibiga ega.
    ///
    /// [`ptr::copy`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `copy` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { copy(self, dest, count) }
    }

    /// `count * size_of<T>` baytlarini `self` dan `dest` gacha nusxa ko'chiradi.
    /// Manba va manzil *bir-biriga mos kelmasligi mumkin*.
    ///
    /// NOTE: bu [`ptr::copy_nonoverlapping`] bilan *bir xil* argument tartibiga ega.
    ///
    /// [`ptr::copy_nonoverlapping`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `copy_nonoverlapping` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// `count * size_of<T>` baytlarini `src` dan `self` gacha nusxa ko'chiradi.
    /// Manba va manzil bir-biriga to'g'ri kelishi mumkin.
    ///
    /// NOTE: bu [`ptr::copy`]*qarshi* argument tartibiga ega.
    ///
    /// [`ptr::copy`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `copy` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { copy(src, self, count) }
    }

    /// `count * size_of<T>` baytlarini `src` dan `self` gacha nusxa ko'chiradi.
    /// Manba va manzil *bir-biriga mos kelmasligi mumkin*.
    ///
    /// NOTE: bu [`ptr::copy_nonoverlapping`]*qarshi* argument tartibiga ega.
    ///
    /// [`ptr::copy_nonoverlapping`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `copy_nonoverlapping` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Belgilangan qiymatning destruktorini (agar mavjud bo'lsa) bajaradi.
    ///
    /// [`ptr::drop_in_place`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `drop_in_place` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { drop_in_place(self) }
    }

    /// Eski qiymatni o'qimasdan yoki tushirmasdan, berilgan qiymat bilan xotira o'rnini yozadi.
    ///
    ///
    /// [`ptr::write`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `write` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { write(self, val) }
    }

    /// `count * size_of::<T>()` baytli xotirani `self` dan `val` gacha o'rnatib, belgilangan ko'rsatkich bo'yicha memset-ni chaqiradi.
    ///
    ///
    /// [`ptr::write_bytes`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `write_bytes` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { write_bytes(self, val, count) }
    }

    /// Eski qiymatni o'qimasdan yoki tushirmasdan berilgan qiymatga ega bo'lgan xotira joyining o'zgaruvchan yozilishini amalga oshiradi.
    ///
    /// O'zgaruvchan operatsiyalar I/O xotirasida ishlashga mo'ljallangan bo'lib, boshqa uchuvchan operatsiyalar bo'yicha kompilyator tomonidan o'tkazilmasligi yoki tartiblashtirilmasligi kafolatlanadi.
    ///
    ///
    /// [`ptr::write_volatile`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `write_volatile` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { write_volatile(self, val) }
    }

    /// Eski qiymatni o'qimasdan yoki tushirmasdan, berilgan qiymat bilan xotira o'rnini yozadi.
    ///
    ///
    /// `write`-dan farqli o'laroq, ko'rsatgich tekislanmagan bo'lishi mumkin.
    ///
    /// [`ptr::write_unaligned`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `write_unaligned` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { write_unaligned(self, val) }
    }

    /// `self` qiymatini `src` bilan almashtiradi, eskirgan qiymatni qaytaradi, ham tushirmasdan.
    ///
    ///
    /// [`ptr::replace`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `replace` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { replace(self, src) }
    }

    /// Bir xil turdagi ikkita o'zgaruvchan joyda qiymatlarni almashtiradi, ularni deinitsializatsiya qilmasdan.
    /// `mem::swap`-dan farqli o'laroq, ular bir-biriga o'xshash bo'lishi mumkin.
    ///
    /// [`ptr::swap`]-ga qarang, xavfsizlik masalalari va misollar.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `swap` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { swap(self, with) }
    }

    /// `align` ga to'g'ri kelishi uchun ko'rsatkichga qo'llanilishi kerak bo'lgan ofsetni hisoblab chiqadi.
    ///
    /// Agar ko'rsatgichni tekislash imkoni bo'lmasa, dastur `usize::MAX` ni qaytaradi.
    /// Amalga oshirish uchun *har doim*`usize::MAX` qaytishiga ruxsat beriladi.
    /// Faqat sizning algoritmingizning ishlashi bu erda uning to'g'riligiga emas, balki foydalanish mumkin bo'lgan ofsetni olishiga bog'liq bo'lishi mumkin.
    ///
    /// Ofset baytlarda emas, balki `T` elementlar sonida ifodalanadi.Qaytgan qiymatdan `wrapping_add` usuli bilan foydalanish mumkin.
    ///
    /// Ko'rsatkichni ofset bilan to'ldirish hech qanday kafolatlar yo'q yoki ko'rsatgich ko'rsatadigan ajratishdan tashqariga chiqmaydi.
    ///
    /// Qaytgan ofsetning tekislashdan boshqa barcha jihatlarda to'g'ri ekanligiga ishonch hosil qilish qo'ng'iroqchiga bog'liq.
    ///
    /// # Panics
    ///
    /// panics funktsiyasi, agar `align` ikkinchisining kuchi bo'lmasa.
    ///
    /// # Examples
    ///
    /// `u8`-ga `u16` sifatida kirish
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // ko'rsatkichni `offset` orqali tekislash mumkin bo'lsa, u ajratishdan tashqariga ishora qiladi
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // XAVFSIZLIK: `align` yuqorida 2 ga teng ekanligi tekshirildi
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Xom bo'lakning uzunligini qaytaradi.
    ///
    /// Qaytgan qiymat-bu baytlar soni emas, balki **elementlar** soni.
    ///
    /// Ushbu funktsiya xavfsiz, hatto xom bo'lakni tilimga yo'naltirish mumkin emas, chunki ko'rsatgich nol yoki tekislanmagan.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // XAVFSIZLIK: bu xavfsizdir, chunki `*const [T]` va `FatPtr<T>` bir xil tartibga ega.
            // Ushbu kafolatni faqat `std` taqdim etishi mumkin.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Xom ko'rsatkichni tilimning buferiga qaytaradi.
    ///
    /// Bu `self`-ni `*mut T`-ga o'tkazishga teng, ammo ko'proq xavfsiz.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Xom ko'rsatkichni chegara tekshirmasdan elementga yoki pastki qismga qaytaradi.
    ///
    /// Ushbu usulni chegaradan tashqaridagi indeks bilan chaqirish yoki `self` ni ajratib bo'lmaydigan bo'lsa,*[aniqlanmagan xatti-harakatlar]* natijada ko'rsatgich ishlatilmasa ham.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self`-ni ajratib bo'lmaydigan va `index`-ning chegarasida bo'lishini ta'minlaydi.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Agar ko'rsatgich null bo'lsa, `None` qiymatini qaytaradi yoki aks holda umumiy bo'lakni `Some` ga o'ralgan qiymatga qaytaradi.
    /// [`as_ref`]-dan farqli o'laroq, bu qiymatni boshlashni talab qilmaydi.
    ///
    /// O'zgaruvchan hamkori uchun [`as_uninit_slice_mut`]-ga qarang.
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ushbu usulni chaqirganda,* **ko'rsatkich NULL* yoki * quyidagilarning barchasi to'g'ri ekanligiga ishonch hosil qilishingiz kerak:
    ///
    /// * Ko'rsatkich `ptr.len() * mem::size_of::<T>()` ko'p bayt uchun o'qish uchun [valid] bo'lishi kerak va u to'g'ri hizalanmalıdır.Bu, xususan:
    ///
    ///     * Ushbu tilimning butun xotira diapazoni bitta ajratilgan ob'ekt ichida bo'lishi kerak!
    ///       Bo'limlar hech qachon bir nechta ajratilgan ob'ektlar bo'ylab tarqalib keta olmaydi.
    ///
    ///     * Ko'rsatkich nol uzunlikdagi bo'laklar uchun ham tekislanishi kerak.
    ///     Buning bir sababi shundaki, enum tartibini optimallashtirish mos yozuvlar (har qanday uzunlikdagi tilimlarni o'z ichiga olgan holda) hizalanmış va boshqa ma'lumotlardan ajratib turishi mumkin.
    ///
    ///     [`NonNull::dangling()`] yordamida nol uzunlikdagi bo'laklar uchun `data` sifatida ishlatilishi mumkin bo'lgan ko'rsatkichni olishingiz mumkin.
    ///
    /// * Dilimning umumiy hajmi `ptr.len() * mem::size_of::<T>()` `isize::MAX` dan katta bo'lmasligi kerak.
    ///   [`pointer::offset`] xavfsizlik hujjatlariga qarang.
    ///
    /// * Qaytgan hayot muddati `'a` o'zboshimchalik bilan tanlanganligi va ma'lumotlarning haqiqiy ishlash muddatini aks ettirmasligi sababli Rust-ning taxallus qoidalarini bajarishingiz kerak.
    ///   Xususan, ushbu umr davomida ko'rsatgich ko'rsatgan xotira mutatsiyaga tushmasligi kerak (`UnsafeCell` ichidan tashqari).
    ///
    /// Ushbu usul natijasi ishlatilmagan bo'lsa ham amal qiladi!
    ///
    /// Shuningdek, [`slice::from_raw_parts`][]-ga qarang.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // XAVFSIZLIK: qo'ng'iroq qiluvchi `as_uninit_slice` uchun xavfsizlik shartnomasini bajarishi kerak.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Agar ko'rsatgich null bo'lsa, `None` qiymatini qaytaradi, aks holda `Some` ga o'ralgan qiymatga noyob bo'lakni qaytaradi.
    /// [`as_mut`]-dan farqli o'laroq, bu qiymatni boshlashni talab qilmaydi.
    ///
    /// Umumiy sherik uchun [`as_uninit_slice`]-ga qarang.
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Ushbu usulni chaqirganda,* **ko'rsatkich NULL* yoki * quyidagilarning barchasi to'g'ri ekanligiga ishonch hosil qilishingiz kerak:
    ///
    /// * Ko'rsatkich `ptr.len() * mem::size_of::<T>()` ko'p baytlarni o'qish va yozish uchun [valid] bo'lishi kerak va u to'g'ri hizalanmalıdır.Bu, xususan:
    ///
    ///     * Ushbu tilimning butun xotira diapazoni bitta ajratilgan ob'ekt ichida bo'lishi kerak!
    ///       Bo'limlar hech qachon bir nechta ajratilgan ob'ektlar bo'ylab tarqalib keta olmaydi.
    ///
    ///     * Ko'rsatkich nol uzunlikdagi bo'laklar uchun ham tekislanishi kerak.
    ///     Buning bir sababi shundaki, enum tartibini optimallashtirish mos yozuvlar (har qanday uzunlikdagi tilimlarni o'z ichiga olgan holda) hizalanmış va boshqa ma'lumotlardan ajratib turishi mumkin.
    ///
    ///     [`NonNull::dangling()`] yordamida nol uzunlikdagi bo'laklar uchun `data` sifatida ishlatilishi mumkin bo'lgan ko'rsatkichni olishingiz mumkin.
    ///
    /// * Dilimning umumiy hajmi `ptr.len() * mem::size_of::<T>()` `isize::MAX` dan katta bo'lmasligi kerak.
    ///   [`pointer::offset`] xavfsizlik hujjatlariga qarang.
    ///
    /// * Qaytgan hayot muddati `'a` o'zboshimchalik bilan tanlanganligi va ma'lumotlarning haqiqiy ishlash muddatini aks ettirmasligi sababli Rust-ning taxallus qoidalarini bajarishingiz kerak.
    ///   Xususan, ushbu umr davomida ko'rsatgich ko'rsatgan xotiraga boshqa ko'rsatgich orqali kirish (o'qish yoki yozish) kerak emas.
    ///
    /// Ushbu usul natijasi ishlatilmagan bo'lsa ham amal qiladi!
    ///
    /// Shuningdek, [`slice::from_raw_parts_mut`][]-ga qarang.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // XAVFSIZLIK: qo'ng'iroq qiluvchi `as_uninit_slice_mut` uchun xavfsizlik shartnomasini bajarishi kerak.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Ko'rsatkichlar uchun tenglik
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}