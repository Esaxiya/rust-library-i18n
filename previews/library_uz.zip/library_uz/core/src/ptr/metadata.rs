#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Ko'rsatilgan har qanday turdagi metadata ko'rsatgich turini beradi.
///
/// # Pointer metadata
///
/// Rust-da xom ko'rsatgich turlari va mos yozuvlar turlarini ikki qismdan iborat deb hisoblash mumkin:
/// qiymatning xotira manzili va ba'zi bir metadata o'z ichiga olgan ma'lumotlar ko'rsatgichi.
///
/// Statik o'lchamdagi turlar uchun (`Sized` traits ni amalga oshiradigan), shuningdek `extern` turlari uchun ko'rsatgichlar "ingichka" deb aytiladi: metama'lumotlar nolga teng va uning turi `()`.
///
///
/// [dynamically-sized types][dst]-ga ko'rsatgichlar "keng" yoki "semiz" deyiladi, ularning nolga teng bo'lmagan metadatalari bor:
///
/// * Oxirgi maydoni DST bo'lgan tuzilmalar uchun metama'lumotlar oxirgi maydon uchun metama'lumotlardir
/// * `str` turi uchun metadata `usize` sifatida bayt uzunligini anglatadi
/// * `[T]` kabi bo'lak turlari uchun metadata `usize` kabi elementlarning uzunligini anglatadi
/// * `dyn SomeTrait` kabi trait moslamalari uchun metama'lumotlar [`DynMetadata<Self>`][DynMetadata] (masalan, `DynMetadata<dyn SomeTrait>`)
///
/// future-da Rust tili har xil ko'rsatgich metama'lumotlariga ega bo'lgan yangi turlarga ega bo'lishi mumkin.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Ushbu trait-ning nuqtasi uning `Metadata` bilan bog'langan turi bo'lib, u `()` yoki `usize` yoki `DynMetadata<_>` yuqorida tavsiflangan.
/// Har qanday tur uchun avtomatik ravishda amalga oshiriladi.
/// U tegishli kontekstsiz ham umumiy kontekstda amalga oshiriladi deb taxmin qilish mumkin.
///
/// # Usage
///
/// Xom ko'rsatkichlarni [`to_raw_parts`] usuli bilan ma'lumotlar manzili va metama'lumotlar qismlariga ajratish mumkin.
///
/// Shu bilan bir qatorda, [`metadata`] funktsiyasi bilan faqat metama'lumotlarni olish mumkin.
/// Malumotni [`metadata`]-ga yuborish va to'g'ridan-to'g'ri majburlash mumkin.
///
/// (possibly-wide) ko'rsatgichini [`from_raw_parts`] yoki [`from_raw_parts_mut`] bilan o'z manzilidan va metama'lumotlaridan qaytarib qo'yish mumkin.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Metadata uchun ko'rsatgichlar va `Self`-ga havolalar turi.
    #[lang = "metadata_type"]
    // NOTE: trait bounds ni `static_assert_expected_bounds_for_metadata` da saqlang
    //
    // `library/core/src/ptr/metadata.rs`-da bu erda bo'lganlar bilan sinxronlash:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Ushbu trait taxallusini amalga oshiruvchi turlarga ko'rsatgichlar "ingichka".
///
/// Bunga statik o'lchamdagi va `extern` turlari kiradi.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: buni trait taxalluslari tilda barqaror bo'lishidan oldin barqarorlashtirmayapsizmi?
pub trait Thin = Pointee<Metadata = ()>;

/// Ko'rsatkichning metadata komponentini ajratib oling.
///
/// `*mut T`, `&T` yoki `&mut T` turdagi qiymatlar to'g'ridan-to'g'ri ushbu funktsiyaga o'tkazilishi mumkin, chunki ular bevosita `* const T` ga majburlanadi.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // XAVFSIZLIK: `PtrRepr` birlashmasidan qiymatga kirish * const T dan beri xavfsizdir
    // va PtrComponentlar<T>bir xil xotira tartibiga ega.
    // Ushbu kafolatni faqat std berishi mumkin.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Ma'lumotlar manzili va metama'lumotlaridan (possibly-wide) xom ko'rsatgichini hosil qiladi.
///
/// Ushbu funktsiya xavfsiz, ammo qaytarilgan ko'rsatgich o'chirib qo'yilishi shart emas.
/// Dilimlarni xavfsizlik talablari uchun [`slice::from_raw_parts`] hujjatiga qarang.
/// trait moslamalari uchun metama'lumotlar ko'rsatgichdan bir xil asosiy pasaytirilgan turga o'tishi kerak.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // XAVFSIZLIK: `PtrRepr` birlashmasidan qiymatga kirish * const T dan beri xavfsizdir
    // va PtrComponentlar<T>bir xil xotira tartibiga ega.
    // Ushbu kafolatni faqat std berishi mumkin.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// [`from_raw_parts`] bilan bir xil funktsiyalarni bajaradi, faqat xom `*const` ko'rsatkichidan farqli o'laroq, xom `* mut` ko'rsatkichi qaytariladi.
///
///
/// Qo'shimcha ma'lumot olish uchun [`from_raw_parts`] hujjatiga qarang.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // XAVFSIZLIK: `PtrRepr` birlashmasidan qiymatga kirish * const T dan beri xavfsizdir
    // va PtrComponentlar<T>bir xil xotira tartibiga ega.
    // Ushbu kafolatni faqat std berishi mumkin.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` bilan bog'lanishni oldini olish uchun qo'lda impl.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` bilan bog'lanishni oldini olish uchun qo'lda impl.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait ob'ekti turi uchun metama'lumotlar.
///
/// Bu trait ob'ekti ichida saqlangan beton turini boshqarish uchun barcha kerakli ma'lumotlarni aks ettiruvchi vtable (virtual chaqiruv jadvali) ko'rsatgichidir.
/// Vtable quyidagilarni o'z ichiga oladi:
///
/// * turi hajmi
/// * turini hizalamak
/// * turdagi `drop_in_place` impl-ga ko'rsatgich (oddiy eski ma'lumotlar uchun no-op bo'lishi mumkin)
/// * trait turini amalga oshirishning barcha usullariga ishora qiladi
///
/// Shuni esda tutingki, dastlabki uchtasi har qanday trait ob'ektini ajratish, tushirish va ajratish uchun zarur bo'lganligi uchun juda muhimdir.
///
/// Ushbu strukturani `dyn` trait ob'ekti bo'lmagan (masalan, `DynMetadata<u64>`) tip parametri bilan nomlash mumkin, ammo bu strukturaning mazmunli qiymatini olish mumkin emas.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Barcha vtables-ning umumiy prefiksi.Undan keyin trait usullari uchun funktsiya ko'rsatkichlari keladi.
///
/// `DynMetadata::size_of` va boshqalarni xususiy tatbiq etish tafsilotlari.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Ushbu vtable bilan bog'liq turdagi hajmini qaytaradi.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Ushbu vtable bilan bog'langan turdagi moslashtirishni qaytaradi.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// `Layout` sifatida o'lcham va tekislikni qaytaradi
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // XAVFSIZLIK: kompilyator ushbu vtable-ni Rust beton uchun chiqargan
        // haqiqiy tartibga ega ekanligi ma'lum.`Layout::for_value`-dagi kabi asos.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` chegaralaridan qochish uchun kerakli qo'llanmalar.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}