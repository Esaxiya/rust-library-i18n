//! Xom ko'rsatkichlar orqali xotirani qo'lda boshqarish.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Ushbu moduldagi ko'plab funktsiyalar xom ko'rsatgichlarni argument sifatida qabul qiladi va o'qiydi yoki ularga yozadi.Buning xavfsiz bo'lishi uchun ushbu ko'rsatgichlar *haqiqiy* bo'lishi kerak.
//! Ko'rsatkichning haqiqiyligi uning ishlatilishi (o'qish yoki yozish) operatsiyasiga va kirilgan xotira hajmiga (ya'ni read/written necha bayt) bog'liq.
//! Ko'pgina funktsiyalar faqat bitta qiymatga kirish uchun `*mut T` va `* const T`-dan foydalanadilar, bu holda hujjatlar hajmini qoldirib, uni `size_of::<T>()` bayt deb bilishadi.
//!
//! Amal qilishning aniq qoidalari hali aniqlanmagan.Ushbu nuqtada berilgan kafolatlar juda kam:
//!
//! * [null] ko'rsatkichi *hech qachon* yaroqsiz, hatto [size zero][zst] kirish uchun ham.
//! * Ko'rsatkich to'g'ri bo'lishi uchun ko'rsatgich *ajratilishi mumkin* bo'lishi kerak, lekin har doim ham etarli emas: ko'rsatgichdan boshlangan berilgan o'lchamdagi xotira diapazoni bitta ajratilgan ob'ekt chegaralarida bo'lishi kerak.
//!
//! Rust-da har bir (stack-allocated) o'zgaruvchisi alohida ajratilgan ob'ekt sifatida qaralishini unutmang.
//! * [size zero][zst] operatsiyalari uchun ham ko'rsatgich ajratilgan xotiraga ishora qilmasligi kerak, ya'ni taqsimlash nol o'lchovli operatsiyalar uchun ham ko'rsatgichlarni bekor qiladi.
//! Biroq, ko'rsatgichga nolga teng bo'lmagan biron bir butun sonni *literal* tashlash nol o'lchovli kirish uchun amal qiladi, hatto ba'zi bir xotira ushbu manzilda mavjud bo'lib, ular taqsimlangan bo'lsa ham.
//! Bu o'zingizning ajratuvchingizni yozishga mos keladi: nol o'lchamdagi moslamalarni ajratish juda qiyin emas.
//! Nol o'lchovli kirish uchun yaroqli bo'lgan ko'rsatgichni olishning kanonik usuli [`NonNull::dangling`].
//! * Ushbu moduldagi funktsiyalar tomonidan amalga oshiriladigan barcha kirishlar *atomik bo'lmagan*[atomic operations] ma'nosida iplar orasidagi sinxronizatsiya uchun ishlatiladi.
//! Bu shuni anglatadiki, har ikkala kirish faqat xotiradan o'qilmasa, har xil iplardan bir joyga bir vaqtning o'zida ikkita kirishni amalga oshirish.
//! E'tibor bering, bu [`read_volatile`] va [`write_volatile`]-ni aniq o'z ichiga oladi: uchuvchan kirishni tarmoqlararo sinxronizatsiya qilish uchun ishlatish mumkin emas.
//! * Ko'rsatkichga havola berish natijasi asosiy ob'ekt jonli bo'lganida va bir xil xotiraga kirish uchun mos yozuvlar (faqat xom ko'rsatkichlar) ishlatilmaguncha amal qiladi.
//!
//! Ushbu aksiomalar, ko'rsatkich arifmetikasi uchun [`offset`]-dan ehtiyotkorlik bilan foydalanish bilan birga, xavfli kodda ko'plab foydali narsalarni to'g'ri bajarish uchun etarli.
//! Oxir-oqibat kuchli kafolatlar beriladi, chunki [aliasing] qoidalari aniqlanmoqda.
//! Qo'shimcha ma'lumot olish uchun [book]-ga, shuningdek [undefined behavior][ub]-ga bag'ishlangan ma'lumotnomadagi bo'limga qarang.
//!
//! ## Alignment
//!
//! Yuqorida tavsiflangan haqiqiy xom ko'rsatkichlar to'g'ri hizalanmagan bo'lishi kerak (bu erda "proper" hizalanishi pointee turi bilan belgilanadi, ya'ni `*const T` `mem::align_of::<T>()` ga to'g'ri kelishi kerak).
//! Biroq, aksariyat funktsiyalar o'zlarining dalillarini to'g'ri muvofiqlashtirishni talab qiladi va hujjatlarda ushbu talabni aniq ko'rsatib beradi.
//! Buning muhim istisnolari [`read_unaligned`] va [`write_unaligned`].
//!
//! Agar funktsiya to'g'ri tekislashni talab qilsa, kirish 0 o'lchamiga ega bo'lsa ham, ya'ni xotiraga tegmagan bo'lsa ham buni amalga oshiradi.Bunday hollarda [`NonNull::dangling`] dan foydalanishni o'ylab ko'ring.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Belgilangan qiymatning destruktorini (agar mavjud bo'lsa) bajaradi.
///
/// Bu semantik jihatdan [`ptr::read`]-ni chaqirishga va natijani bekor qilishga teng, ammo quyidagi afzalliklarga ega:
///
/// * trait moslamalari kabi o'lchamsiz turlarni tashlash uchun `drop_in_place`-dan foydalanish *talab qilinadi*, chunki ularni stakka o'qib bo'lmaydi va odatdagidek tushadi.
///
/// * Qo'l bilan ajratilgan xotirani tashlaganingizda (masalan, `Box`/`Rc`/`Vec` dasturlarida) buni optimallashtirish uchun [`ptr::read`] orqali amalga oshirish qulayroq, chunki kompilyator nusxani chiqarib olish uchun ovozli ekanligini isbotlashning hojati yo'q.
///
///
/// * `T` `repr(packed)` bo'lmaganida [pinned] ma'lumotlarini tushirish uchun ishlatilishi mumkin (mahkamlangan ma'lumotlar tashlanishidan oldin ko'chirilmasligi kerak).
///
/// Tartibsiz qiymatlarni joyiga tushirish mumkin emas, avval ularni [`ptr::read_unaligned`] yordamida moslashtirilgan joyga ko'chirish kerak.Paketlangan tuzilmalar uchun bu harakat avtomatik ravishda kompilyator tomonidan amalga oshiriladi.
/// Bu shuni anglatadiki, qadoqlangan konstruktsiyalar maydonlari o'z joylariga tashlanmaydi.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `to_drop` ham o'qish, ham yozish uchun [valid] bo'lishi kerak.
///
/// * `to_drop` to'g'ri hizalanmış bo'lishi kerak.
///
/// * Belgilangan qiymat `to_drop` tushirish uchun yaroqli bo'lishi kerak, demak u qo'shimcha invariantlarni qo'llab-quvvatlashi kerak, bu turga bog'liq.
///
/// Bundan tashqari, agar `T` [`Copy`] bo'lmasa, `drop_in_place` chaqirgandan keyin belgilangan qiymatdan foydalanish aniqlanmagan xatti-harakatga olib kelishi mumkin.Shuni esda tutingki, `*to_drop = foo` foydalanish sifatida hisoblanadi, chunki bu qiymat yana pasayishiga olib keladi.
/// [`write()`] ma'lumotlar o'chirilishiga olib kelmasdan, ularni ustiga yozish uchun ishlatilishi mumkin.
///
/// E'tibor bering, `T` `0` o'lchamiga ega bo'lsa ham, ko'rsatgich NULL bo'lmasligi va to'g'ri hizalanishi kerak.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Oxirgi elementni vector-dan qo'lda olib tashlang:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // `v`-dagi oxirgi elementga xom ko'rsatkichni oling.
///     let ptr = &mut v[1] as *mut _;
///     // Oxirgi element tushishiga yo'l qo'ymaslik uchun `v`-ni qisqartiring.
///     // Agar biz panics ostidagi `drop_in_place` bo'lsa, muammolarni oldini olish uchun avval buni qilamiz.
///     v.set_len(1);
///     // `drop_in_place` qo'ng'iroqisiz oxirgi element hech qachon o'chirilmaydi va u boshqaradigan xotira sızdırılır.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Oxirgi narsa o'chirilganligiga ishonch hosil qiling.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// E'tibor bering, kompilyator qadoqlangan konstruktsiyalarni tushirganda ushbu nusxani avtomatik ravishda bajaradi, ya'ni siz `drop_in_place`-ga qo'l bilan qo'ng'iroq qilmasangiz, odatda bunday muammolar haqida tashvishlanishingiz shart emas.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Bu erda kod muhim emas, bu kompilyator tomonidan haqiqiy tomchi elim bilan almashtiriladi.
    //

    // XAVFSIZLIK: yuqoridagi izohga qarang
    unsafe { drop_in_place(to_drop) }
}

/// Nol xom ko'rsatkichni yaratadi.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Nol o'zgaruvchan xom ko'rsatkichni yaratadi.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// `T: Clone` bilan bog'lanishni oldini olish uchun qo'lda impl.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// `T: Copy` bilan bog'lanishni oldini olish uchun qo'lda impl.
impl<T> Copy for FatPtr<T> {}

/// Ko'rsatkich va uzunlikdan xom bo'lak hosil qiladi.
///
/// `len` argumenti **element** soni, baytlar soni emas.
///
/// Ushbu funktsiya xavfsiz, lekin aslida qaytish qiymatidan foydalanish xavfli emas.
/// Dilim xavfsizligi talablari uchun [`slice::from_raw_parts`] hujjatlariga qarang.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // birinchi elementga ko'rsatgich bilan boshlanganda tilim ko'rsatkichini yarating
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // XAVFSIZLIK: `Repr` birlashmasidan qiymatga kirish * const [T] dan beri xavfsizdir
        //
        // va FatPtr bir xil xotira sxemalariga ega.Ushbu kafolatni faqat std berishi mumkin.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// [`slice_from_raw_parts`] bilan bir xil funktsiyalarni bajaradi, faqat xom o'zgarmas bo'lakdan farqli o'laroq, xom o'zgaruvchan tilim qaytariladi.
///
///
/// Qo'shimcha ma'lumot olish uchun [`slice_from_raw_parts`] hujjatiga qarang.
///
/// Ushbu funktsiya xavfsiz, lekin aslida qaytish qiymatidan foydalanish xavfli emas.
/// Dilim xavfsizligi talablari uchun [`slice::from_raw_parts_mut`] hujjatlariga qarang.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // tilimdagi indeks bo'yicha qiymatni belgilang
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // XAVFSIZLIK: `Repr` birlashmasidan qiymatga kirish * mut [T] dan beri xavfsizdir
        // va FatPtr bir xil xotira sxemalariga ega
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Bir xil turdagi ikkita o'zgaruvchan joyda qiymatlarni almashtiradi, ularni deinitsializatsiya qilmasdan.
///
/// Ammo quyidagi ikkita istisno uchun ushbu funktsiya semantik jihatdan [`mem::swap`] ga teng:
///
///
/// * U havolalar o'rniga xom ko'rsatgichlarda ishlaydi.
/// Ma'lumotlar mavjud bo'lganda, [`mem::swap`] ga ustunlik berish kerak.
///
/// * Ikkala ko'rsatilgan qiymatlar bir-biriga to'g'ri kelishi mumkin.
/// Agar qiymatlar bir-biriga mos keladigan bo'lsa, u holda `x` dan ustma-ust keladigan xotira mintaqasidan foydalaniladi.
/// Bu quyidagi ikkinchi misolda ko'rsatilgan.
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * Ham o'qish, ham yozish uchun `x` va `y` ikkalasi ham [valid] bo'lishi kerak.
///
/// * Ham `x`, ham `y` to'g'ri hizalanmalıdır.
///
/// E'tibor bering, agar `T` `0` o'lchamiga ega bo'lsa ham, ko'rsatgichlar NULL bo'lmagan va to'g'ri hizalangan bo'lishi kerak.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Bir-birini takrorlamaydigan ikkita mintaqani almashtirish:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // bu `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // bu `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Ikki ustma-ust keladigan mintaqalarni almashtirish:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // bu `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // bu `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Dilimning `1..3` indekslari `x` va `y` o'rtasida bir-biriga to'g'ri keladi.
///     // `0..3` indekslari `[1, 2, 3]` (`swap` dan oldingi `y`) bo'lishi uchun ular uchun oqilona natijalar `[2, 3]` bo'lishi mumkin;yoki ular uchun `[0, 1]` bo'lishi kerak, shunda `1..4` indekslari `[0, 1, 2]` bo'ladi (`swap` dan oldingi `x`).
/////
///     // Ushbu dastur oxirgi tanlovni amalga oshirish uchun belgilanadi.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Ishlash uchun o'zimizga biroz bo'sh joy bering.
    // Biz tomchilar haqida xavotirlanmasligimiz kerak: `MaybeUninit` tushganda hech narsa qilmaydi.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Almashtirishni amalga oshiring XAVFSIZLIK: qo'ng'iroq qiluvchi `x` va `y` yozuvlari uchun yaroqli va to'g'ri hizalanishiga kafolat berishi kerak.
    // `tmp` `x` yoki `y` bilan bir-birini qoplash mumkin emas, chunki `tmp` stakka alohida ajratilgan ob'ekt sifatida ajratilgan.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` va `y` ustma-ust tushishi mumkin
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// `count * size_of::<T>()` baytlarni `x` va `y` dan boshlanadigan xotiraning ikki mintaqasi o'rtasida almashtiradi.
/// Ikki mintaqa *bir-biriga* to'g'ri kelmasligi kerak.
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * "Hisoblash" ni o'qish va yozish uchun `x` va `y` ikkalasi ham [valid] bo'lishi kerak *
///   hajmi_of: :<T>() `bayt.
///
/// * Ham `x`, ham `y` to'g'ri hizalanmalıdır.
///
/// * `x`-dan boshlanadigan xotira mintaqasi "hisoblash" hajmi bilan *
///   hajmi_of: :<T>() `baytlar bir xil o'lchamdagi `y` dan boshlanadigan xotira mintaqasi bilan * * bo'lmasligi kerak.
///
/// E'tibor bering, hatto samarali nusxalangan hajm ("count * size_of: :<T>()`) `0`, ko'rsatkichlar NULL bo'lmasligi va to'g'ri hizalanishi kerak.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `x` va `y` ekanligini kafolatlashi kerak
    // yozish uchun yaroqli va to'g'ri hizalangan.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Quyidagi bloklarni optimallashtirishdan kichikroq turlari uchun kodgenni pessimizatsiya qilmaslik uchun to'g'ridan-to'g'ri almashtiring.
    //
    if mem::size_of::<T>() < 32 {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `x` va `y` haqiqiyligini kafolatlashi kerak
        // to'g'ri yozilgan va bir-biriga mos kelmaydigan yozuvlar uchun.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `swap_nonoverlapping` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Bu erda x va y ni samarali almashtirish uchun simd-dan foydalanish kerak.
    // Sinov shuni ko'rsatadiki, bir vaqtning o'zida 32 bayt yoki 64 baytni almashtirish Intel Haswell E protsessorlari uchun eng samarali hisoblanadi.
    // LLVM, agar biz strukturani to'g'ridan-to'g'ri ishlatmasak ham, biz #[repr(simd)] strukturasini beradigan bo'lsak, optimallashtirishga qodir.
    //
    //
    // FIXME repr(simd) yozilgan va redoksda buzilgan
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // X&y-ni ko'rib chiqing, ularni bir vaqtning o'zida `Block`-ga nusxalash Optimizator NB-ning aksariyat turlari uchun tsiklni to'liq ochishi kerak
    // Biz for for dan foydalana olmaymiz, chunki `range` impl `mem::swap` ni rekursiv chaqiradi
    //
    let mut i = 0;
    while i + block_size <= len {
        // Bir nechta boshlang'ich xotirani yarating, chunki u bo'sh joyni `t` deb e'lon qilsa, bu tsikl ishlatilmaganda to'plamni tekislashdan saqlaydi.
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // XAVFSIZLIK: `i < len` sifatida va qo'ng'iroq qiluvchida `x` va `y` haqiqiyligiga kafolat bo'lishi kerak.
        // `len` bayt uchun `x + i` va `y + i` haqiqiy manzillar bo'lishi kerak, bu `add` uchun xavfsizlik shartnomasini bajaradi.
        //
        // Shuningdek, qo'ng'iroq qiluvchi `x` va `y` yozuvlari, to'g'ri hizalanishi va bir-birining ustiga chiqmasligi uchun yaroqli bo'lishiga kafolat berishi kerak, bu esa `copy_nonoverlapping` uchun xavfsizlik shartnomasini bajaradi.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Vaqtinchalik tampon sifatida t dan foydalanib, x&y bayt blokini almashtiring Bu mavjud bo'lgan joyda samarali SIMD operatsiyalariga moslashtirilishi kerak
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Qolgan baytlarni almashtiring
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // XAVFSIZLIK: oldingi xavfsizlik sharhiga qarang.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// `src`-ni oldingi `dst` qiymatini qaytarib, `dst`-ga ishora qiladi.
///
/// Ikkala qiymat ham tushirilmaydi.
///
/// Ushbu funktsiya ma'naviy jihatdan [`mem::replace`] ga teng, faqat u havolalar o'rniga xom ko'rsatgichlarda ishlaydi.
/// Ma'lumotlar mavjud bo'lganda, [`mem::replace`] ga ustunlik berish kerak.
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `dst` ham o'qish, ham yozish uchun [valid] bo'lishi kerak.
///
/// * `dst` to'g'ri hizalanmış bo'lishi kerak.
///
/// * `dst` `T` tipidagi to'g'ri boshlangan qiymatga ishora qilishi kerak.
///
/// E'tibor bering, `T` `0` o'lchamiga ega bo'lsa ham, ko'rsatgich NULL bo'lmasligi va to'g'ri hizalanishi kerak.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` xavfli blokni talab qilmasdan xuddi shunday ta'sirga ega bo'lar edi.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `dst` haqiqiyligini kafolatlashi kerak
    // o'zgarishi mumkin bo'lgan ma'lumotnomaga tashlangan (yozish, hizalamak, ishga tushirish uchun yaroqli) va `src` bilan qoplana olmaydi, chunki `dst` alohida ajratilgan ob'ektga ishora qilishi kerak.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // bir-birining ustiga chiqa olmaydi
    }
    src
}

/// `src`-dan qiymatni harakatga keltirmasdan o'qiydi.Bu `src` xotirani o'zgarishsiz qoldiradi.
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `src` o'qish uchun [valid] bo'lishi kerak.
///
/// * `src` to'g'ri hizalanmış bo'lishi kerak.Agar bunday bo'lmasa, [`read_unaligned`]-dan foydalaning.
///
/// * `src` `T` tipidagi to'g'ri boshlangan qiymatga ishora qilishi kerak.
///
/// E'tibor bering, `T` `0` o'lchamiga ega bo'lsa ham, ko'rsatgich NULL bo'lmasligi va to'g'ri hizalanishi kerak.
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`]-ni qo'lda qo'llang:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // `tmp` da `a` qiymatining bitli nusxasini yarating.
///         let tmp = ptr::read(a);
///
///         // Ushbu nuqtadan chiqish (aniq qaytarish yoki panics funktsiyasini chaqirish orqali) `tmp` qiymatining pasayishiga olib keladi, xuddi shu qiymat hali ham `a` tomonidan havola qilinadi.
///         // Agar `T` `Copy` bo'lmasa, bu aniqlanmagan xatti-harakatni keltirib chiqarishi mumkin.
/////
/////
///
///         // `a` da `b` qiymatining bitli nusxasini yarating.
///         // Bu xavfsizdir, chunki o'zgaruvchan havolalar taxallus qila olmaydi.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Yuqoridagi kabi, bu erdan chiqish aniqlanmagan xatti-harakatni keltirib chiqarishi mumkin, chunki `a` va `b` bir xil qiymatga murojaat qilishadi.
/////
///
///         // `tmp`-ni `b`-ga o'tkazing.
///         ptr::write(b, tmp);
///
///         // `tmp` ko'chirildi (`write` o'zining ikkinchi argumentiga egalik qiladi), shuning uchun bu erda hech narsa aniq tashlab qo'yilmaydi.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Qaytarilgan qiymatga egalik
///
/// `read` `T` ning [`Copy`] bo'lishidan qat'i nazar, `T` ning bitli nusxasini yaratadi.
/// Agar `T` [`Copy`] bo'lmasa, qaytarilgan qiymat va `*src` qiymatidan foydalanish xotira xavfsizligini buzishi mumkin.
/// Shuni esda tutingki, `*src` ga tayinlash foydalanish sifatida hisoblanadi, chunki u `* src` qiymatini tushirishga harakat qiladi.
///
/// [`write()`] ma'lumotlar o'chirilishiga olib kelmasdan, ularni ustiga yozish uchun ishlatilishi mumkin.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` endi `s` bilan bir xil asosiy xotiraga ishora qiladi.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // `s2`-ga tayinlash uning asl qiymati pasayishiga olib keladi.
///     // Ushbu nuqtadan tashqari, `s` endi ishlatilmasligi kerak, chunki asosiy xotira bo'shatilgan.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // `s`-ga tayinlash eski qiymatni qayta tushirilishiga olib keladi va natijada xatti-harakatlar aniqlanmaydi.
/////
///     // s= String::from("bar");//XATO
///
///     // `ptr::write` qiymatini tushirmasdan uning ustiga yozish uchun foydalanish mumkin.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `src` o'qish uchun yaroqliligini kafolatlashi kerak.
    // `src` `tmp` bilan qoplanishi mumkin emas, chunki `tmp` shunchaki stackda alohida ajratilgan ob'ekt sifatida ajratilgan.
    //
    //
    // Bundan tashqari, biz `tmp`-ga haqiqiy qiymatni yozganimiz sababli, uni to'g'ri ishga tushirish kafolatlangan.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// `src`-dan qiymatni harakatga keltirmasdan o'qiydi.Bu `src` xotirani o'zgarishsiz qoldiradi.
///
/// [`read`]-dan farqli o'laroq, `read_unaligned` tekislanmagan ko'rsatkichlar bilan ishlaydi.
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `src` o'qish uchun [valid] bo'lishi kerak.
///
/// * `src` `T` tipidagi to'g'ri boshlangan qiymatga ishora qilishi kerak.
///
/// [`read`] singari, `read_unaligned`, `T` ning [`Copy`] bo'lishidan qat'i nazar, `T` ning bitli nusxasini yaratadi.
/// Agar `T` [`Copy`] bo'lmasa, qaytarilgan qiymatdan va `*src` qiymatidan foydalanib [violate memory safety][read-ownership] bo'lishi mumkin.
///
/// E'tibor bering, agar `T` `0` o'lchamiga ega bo'lsa ham, ko'rsatkich NULL bo'lmasligi kerak.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## `packed` tuzilmalarida
///
/// Hozirda paketlangan strukturaning tekislanmagan maydonlariga xom ko'rsatgichlar yaratish mumkin emas.
///
/// `&packed.unaligned as *const FieldType` kabi ifoda bilan `unaligned` struct maydoniga xom ko'rsatkichni yaratishga urinish, uni xom ko'rsatgichga aylantirishdan oldin oraliq tekislanmagan ma'lumotnoma hosil qiladi.
///
/// Ushbu ma'lumot vaqtinchalik va darhol tashlanishi ahamiyatsiz, chunki kompilyator har doim mos yozuvlar mos kelishini kutadi.
/// Natijada, `&packed.unaligned as *const FieldType`-dan foydalanish sizning dasturingizda zudlik bilan* noaniq xatti-harakatlarni * keltirib chiqaradi.
///
/// Nima qilmaslik kerakligi va bu `read_unaligned` bilan qanday bog'liqligi haqida misol:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Bu erda biz tekislanmagan 32-bitli tamsayı manzilini olishga harakat qilamiz.
///     let unaligned =
///         // Vaqtinchalik mos kelmagan ma'lumotnoma bu erda yaratiladi, natijada havola ishlatilgan yoki ishlatilmaganligidan qat'iy nazar aniqlanmagan xatti-harakatlarga olib keladi.
/////
///         &packed.unaligned
///         // Xom ko'rsatkichga quyish yordam bermaydi;xato allaqachon sodir bo'lgan.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Ammo, masalan, `packed.unaligned` bilan mos kelmagan maydonlarga kirish xavfsizdir.
///
///
///
///
///
///
// FIXME: RFC #2582 va do'stlari natijalariga ko'ra hujjatlarni yangilang.
/// # Examples
///
/// Bayt buferidan foydalanuvchi qiymatini o'qing:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `src` o'qish uchun yaroqliligini kafolatlashi kerak.
    // `src` `tmp` bilan qoplanishi mumkin emas, chunki `tmp` shunchaki stackda alohida ajratilgan ob'ekt sifatida ajratilgan.
    //
    //
    // Bundan tashqari, biz `tmp`-ga haqiqiy qiymatni yozganimiz sababli, uni to'g'ri ishga tushirish kafolatlangan.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Eski qiymatni o'qimasdan yoki tushirmasdan, berilgan qiymat bilan xotira o'rnini yozadi.
///
/// `write` `dst` tarkibini tushirmaydi.
/// Bu xavfsiz, ammo ajratmalar yoki manbalar oqishi mumkin, shuning uchun tashlab ketilishi kerak bo'lgan ob'ektning ustiga yozilmasligi kerak.
///
///
/// Bundan tashqari, u `src` tushmaydi.Semantik jihatdan `src` `dst` tomonidan ko'rsatilgan joyga ko'chiriladi.
///
/// Bu ishga tushirilmagan xotirani ishga tushirish yoki oldin [`read`] bo'lgan xotirani qayta yozish uchun javob beradi.
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `dst` yozish uchun [valid] bo'lishi kerak.
///
/// * `dst` to'g'ri hizalanmış bo'lishi kerak.Agar bunday bo'lmasa, [`write_unaligned`]-dan foydalaning.
///
/// E'tibor bering, `T` `0` o'lchamiga ega bo'lsa ham, ko'rsatgich NULL bo'lmasligi va to'g'ri hizalanishi kerak.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`]-ni qo'lda qo'llang:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // `tmp` da `a` qiymatining bitli nusxasini yarating.
///         let tmp = ptr::read(a);
///
///         // Ushbu nuqtadan chiqish (aniq qaytarish yoki panics funktsiyasini chaqirish orqali) `tmp` qiymatining pasayishiga olib keladi, xuddi shu qiymat hali ham `a` tomonidan havola qilinadi.
///         // Agar `T` `Copy` bo'lmasa, bu aniqlanmagan xatti-harakatni keltirib chiqarishi mumkin.
/////
/////
///
///         // `a` da `b` qiymatining bitli nusxasini yarating.
///         // Bu xavfsizdir, chunki o'zgaruvchan havolalar taxallus qila olmaydi.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Yuqoridagi kabi, bu erdan chiqish aniqlanmagan xatti-harakatni keltirib chiqarishi mumkin, chunki `a` va `b` bir xil qiymatga murojaat qilishadi.
/////
///
///         // `tmp`-ni `b`-ga o'tkazing.
///         ptr::write(b, tmp);
///
///         // `tmp` ko'chirildi (`write` o'zining ikkinchi argumentiga egalik qiladi), shuning uchun bu erda hech narsa aniq tashlab qo'yilmaydi.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Biz ishlab chiqarilgan kodda funktsiya chaqiruvlaridan qochish uchun ichki narsalarni to'g'ridan-to'g'ri chaqirmoqdamiz, chunki `intrinsics::copy_nonoverlapping` bu o'rash funktsiyasi.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // XAVFSIZLIK: qo'ng'iroq qiluvchi `dst` yozuvlar uchun yaroqliligini kafolatlashi kerak.
    // `dst` `src` bilan bir-birini qoplay olmaydi, chunki `src` ushbu funktsiyaga egalik qilganda, qo'ng'iroq qiluvchining `dst`-ga o'zgarishi mumkin bo'lgan kirish huquqiga ega.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Eski qiymatni o'qimasdan yoki tushirmasdan, berilgan qiymat bilan xotira o'rnini yozadi.
///
/// [`write()`]-dan farqli o'laroq, ko'rsatgich tekislanmagan bo'lishi mumkin.
///
/// `write_unaligned` `dst` tarkibini tushirmaydi.Bu xavfsiz, ammo ajratmalar yoki manbalar oqishi mumkin, shuning uchun tashlab ketilishi kerak bo'lgan ob'ektning ustiga yozilmasligi kerak.
///
/// Bundan tashqari, u `src` tushmaydi.Semantik jihatdan `src` `dst` tomonidan ko'rsatilgan joyga ko'chiriladi.
///
/// Bu boshlanmagan xotirani ishga tushirish yoki oldin [`read_unaligned`] bilan o'qilgan xotirani qayta yozish uchun javob beradi.
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `dst` yozish uchun [valid] bo'lishi kerak.
///
/// E'tibor bering, agar `T` `0` o'lchamiga ega bo'lsa ham, ko'rsatkich NULL bo'lmasligi kerak.
///
/// [valid]: self#safety
///
/// ## `packed` tuzilmalarida
///
/// Hozirda paketlangan strukturaning tekislanmagan maydonlariga xom ko'rsatgichlar yaratish mumkin emas.
///
/// `&packed.unaligned as *const FieldType` kabi ifoda bilan `unaligned` struct maydoniga xom ko'rsatkichni yaratishga urinish, uni xom ko'rsatgichga aylantirishdan oldin oraliq tekislanmagan ma'lumotnoma hosil qiladi.
///
/// Ushbu ma'lumot vaqtinchalik va darhol tashlanishi ahamiyatsiz, chunki kompilyator har doim mos yozuvlar mos kelishini kutadi.
/// Natijada, `&packed.unaligned as *const FieldType`-dan foydalanish sizning dasturingizda zudlik bilan* noaniq xatti-harakatlarni * keltirib chiqaradi.
///
/// Nima qilmaslik kerakligi va bu `write_unaligned` bilan qanday bog'liqligi haqida misol:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Bu erda biz tekislanmagan 32-bitli tamsayı manzilini olishga harakat qilamiz.
///     let unaligned =
///         // Vaqtinchalik mos kelmagan ma'lumotnoma bu erda yaratiladi, natijada havola ishlatilgan yoki ishlatilmaganligidan qat'iy nazar aniqlanmagan xatti-harakatlarga olib keladi.
/////
///         &mut packed.unaligned
///         // Xom ko'rsatkichga quyish yordam bermaydi;xato allaqachon sodir bo'lgan.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Ammo, masalan, `packed.unaligned` bilan mos kelmagan maydonlarga kirish xavfsizdir.
///
///
///
///
///
///
///
///
///
// FIXME: RFC #2582 va do'stlari natijalariga ko'ra hujjatlarni yangilang.
/// # Examples
///
/// Bayt buferiga usize qiymatini yozing:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `dst` yozuvlar uchun yaroqliligini kafolatlashi kerak.
    // `dst` `src` bilan bir-birini qoplay olmaydi, chunki `src` ushbu funktsiyaga egalik qilganda, qo'ng'iroq qiluvchining `dst`-ga o'zgarishi mumkin bo'lgan kirish huquqiga ega.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Yaratilgan koddagi funktsiya chaqiruvlaridan qochish uchun biz to'g'ridan-to'g'ri ichki telefonni chaqiramiz.
        intrinsics::forget(src);
    }
}

/// `src`-dan qiymatni o'zgartirmasdan o'qiydi.Bu `src` xotirani o'zgarishsiz qoldiradi.
///
/// O'zgaruvchan operatsiyalar I/O xotirasida ishlashga mo'ljallangan bo'lib, boshqa uchuvchan operatsiyalar bo'yicha kompilyator tomonidan o'tkazilmasligi yoki tartiblashtirilmasligi kafolatlanadi.
///
/// # Notes
///
/// Rust hozirda qat'iy va rasmiy ravishda belgilangan xotira modeliga ega emas, shuning uchun "volatile" bu erda nimani anglatishini aniq semantikasi vaqt o'tishi bilan o'zgarishi mumkin.
/// Aytish joizki, semantika deyarli har doim [C11's definition of volatile][c11] ga juda o'xshash bo'ladi.
///
/// Tuzuvchi xotira operatsiyalarining nisbiy tartibini yoki sonini o'zgartirmasligi kerak.
/// Shu bilan birga, nol o'lchamdagi turg'un xotira operatsiyalari (masalan, agar nol o'lchovli turdagi `read_volatile` ga o'tkazilsa) noops bo'lib, ularga e'tibor berilmasligi mumkin.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `src` o'qish uchun [valid] bo'lishi kerak.
///
/// * `src` to'g'ri hizalanmış bo'lishi kerak.
///
/// * `src` `T` tipidagi to'g'ri boshlangan qiymatga ishora qilishi kerak.
///
/// [`read`] singari, `read_volatile`, `T` ning [`Copy`] bo'lishidan qat'i nazar, `T` ning bitli nusxasini yaratadi.
/// Agar `T` [`Copy`] bo'lmasa, qaytarilgan qiymatdan va `*src` qiymatidan foydalanib [violate memory safety][read-ownership] bo'lishi mumkin.
/// Biroq, ['Copy'] turlarini doimiy xotirada saqlash deyarli aniq emas.
///
/// E'tibor bering, `T` `0` o'lchamiga ega bo'lsa ham, ko'rsatgich NULL bo'lmasligi va to'g'ri hizalanishi kerak.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Xuddi C-da bo'lgani kabi, operatsiya o'zgaruvchan bo'ladimi, bir nechta iplardan bir vaqtning o'zida kirish bilan bog'liq savollarga hech qanday ta'sir ko'rsatmaydi.Uchuvchan kirish bu borada xuddi atom bo'lmagan kirish kabi o'zini tutadi.
///
/// Xususan, `read_volatile` va bir xil joyga yozish operatsiyasi o'rtasidagi poyga aniqlanmagan xatti-harakatlardir.
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Kodgen ta'sirini kichikroq qilish uchun vahima qo'ymang.
        abort();
    }
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `volatile_load` uchun xavfsizlik shartnomasini bajarishi kerak.
    unsafe { intrinsics::volatile_load(src) }
}

/// Eski qiymatni o'qimasdan yoki tushirmasdan berilgan qiymatga ega bo'lgan xotira joyining o'zgaruvchan yozilishini amalga oshiradi.
///
/// O'zgaruvchan operatsiyalar I/O xotirasida ishlashga mo'ljallangan bo'lib, boshqa uchuvchan operatsiyalar bo'yicha kompilyator tomonidan o'tkazilmasligi yoki tartiblashtirilmasligi kafolatlanadi.
///
/// `write_volatile` `dst` tarkibini tushirmaydi.Bu xavfsiz, ammo ajratmalar yoki manbalar oqishi mumkin, shuning uchun tashlab ketilishi kerak bo'lgan ob'ektning ustiga yozilmasligi kerak.
///
/// Bundan tashqari, u `src` tushmaydi.Semantik jihatdan `src` `dst` tomonidan ko'rsatilgan joyga ko'chiriladi.
///
/// # Notes
///
/// Rust hozirda qat'iy va rasmiy ravishda belgilangan xotira modeliga ega emas, shuning uchun "volatile" bu erda nimani anglatishini aniq semantikasi vaqt o'tishi bilan o'zgarishi mumkin.
/// Aytish joizki, semantika deyarli har doim [C11's definition of volatile][c11] ga juda o'xshash bo'ladi.
///
/// Tuzuvchi xotira operatsiyalarining nisbiy tartibini yoki sonini o'zgartirmasligi kerak.
/// Shu bilan birga, nol o'lchamdagi turg'un xotira operatsiyalari (masalan, agar nol o'lchovli turdagi `write_volatile` ga o'tkazilsa) noops bo'lib, ularga e'tibor berilmasligi mumkin.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Quyidagi shartlardan biri buzilgan taqdirda o'zini tutishi aniqlanmaydi:
///
/// * `dst` yozish uchun [valid] bo'lishi kerak.
///
/// * `dst` to'g'ri hizalanmış bo'lishi kerak.
///
/// E'tibor bering, `T` `0` o'lchamiga ega bo'lsa ham, ko'rsatgich NULL bo'lmasligi va to'g'ri hizalanishi kerak.
///
/// [valid]: self#safety
///
/// Xuddi C-da bo'lgani kabi, operatsiya o'zgaruvchan bo'ladimi, bir nechta iplardan bir vaqtning o'zida kirish bilan bog'liq savollarga hech qanday ta'sir ko'rsatmaydi.Uchuvchan kirish bu borada xuddi atom bo'lmagan kirish kabi o'zini tutadi.
///
/// Xususan, `write_volatile` va boshqa har qanday operatsiya (o'qish yoki yozish) o'rtasida bir xil joyda poyga aniqlanmagan xatti-harakatlardir.
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Kodgen ta'sirini kichikroq qilish uchun vahima qo'ymang.
        abort();
    }
    // XAVFSIZLIK: qo'ng'iroq qiluvchi `volatile_store` uchun xavfsizlik shartnomasini bajarishi kerak.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// `p` ko'rsatkichini tekislang.
///
/// `p` ko'rsatkichi `a` ga to'g'ri kelishi uchun `p` ko'rsatkichiga qo'llanilishi kerak bo'lgan ofsetni (`stride` qadam elementlari bo'yicha) hisoblang.
///
/// Note: Ushbu dastur ehtiyotkorlik bilan panic-ga moslashtirilmagan.Buning uchun panic uchun UB.
/// Bu erda amalga oshirilishi mumkin bo'lgan yagona o'zgarish-bu `INV_TABLE_MOD_16` va unga bog'liq doimiylarning o'zgarishi.
///
/// Agar biz biron bir kuchga ega bo'lmagan `a` bilan ichki telefonni chaqirishga qaror qilsak, ehtimol bu o'zgarishlarga moslashish uchun emas, balki sodda dasturga o'tish yanada oqilona bo'ladi.
///
///
/// Har qanday savol@nagisa ga yuboriladi.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Ushbu ichki narsalardan to'g'ridan-to'g'ri foydalanish kodenni opt darajasida sezilarli darajada yaxshilaydi <=
    // 1, bu erda ushbu operatsiyalarning uslubiy versiyalari chizilgan emas.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// `x` modulining `m` ning multiplikativ modulli teskari tomonini hisoblang.
    ///
    /// Ushbu dastur `align_offset` uchun moslashtirilgan va quyidagi shartlarga ega:
    ///
    /// * `m` ikkinchisining kuchi;
    /// * `x < m`; (agar `x ≥ m` bo'lsa, uning o'rniga `x % m` ga o'ting)
    ///
    /// Ushbu funktsiyani amalga oshirish panic bo'lmasligi kerak.Har doim.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikatsion modulli teskari jadval moduli 2⁴=16.
        ///
        /// Ushbu jadvalda teskari mavjud bo'lmagan qiymatlar mavjud emasligiga e'tibor bering (ya'ni, `0⁻¹ mod 16`, `2⁻¹ mod 16` va boshqalar uchun).
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// `INV_TABLE_MOD_16` mo'ljallangan modul.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // XAVFSIZLIK: `m` ikkita quvvatga ega bo'lishi kerak, shuning uchun nolga teng bo'lmaydi.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Biz quyidagi formuladan foydalanib "up" ni takrorlaymiz:
            //
            // $$ xy-1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // 2²ⁿ m gacha.Keyin `mod m` natijasini olish orqali biz kerakli `m` ga tushishimiz mumkin.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Shuni e'tiborga olish kerakki, biz bu erda o'rash operatsiyalarini ataylab ishlatamiz-asl formulada, masalan, `mod n` ayirma ishlatiladi.
                // Buning o'rniga ularni `mod usize::MAX` qilish juda yaxshi, chunki biz `mod n` natijasini oxiriga etkazamiz.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // XAVFSIZLIK: `a`-ikkitaning kuchi, shuning uchun nolga teng emas.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` ishni `-p (mod a)` orqali oddiyroq hisoblash mumkin, ammo bu LLVM ning `lea` kabi ko'rsatmalarni tanlash imkoniyatini inhibe qiladi.Buning o'rniga biz hisoblaymiz
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // operatsiyalarni yuk ko'taruvchi atrofida taqsimlaydi, lekin LLVM uchun o'zi biladigan turli xil optimallashtirishlardan foydalanish uchun `and`-ni etarli darajada pessimizatsiya qiladi.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Allaqachon moslashtirilgan.Vajjaj!
        return 0;
    } else if stride == 0 {
        // Agar ko'rsatgich tekislanmagan bo'lsa va element nolga teng bo'lsa, unda hech qanday element ko'rsatkichni hech qachon tekislamaydi.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // XAVFSIZLIK: a-ikkitaning kuchi, shuning uchun nolga teng emas.stride==0 ishi yuqorida ko'rib chiqilgan.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // XAVFSIZLIK: gcdpow yuqori chegaraga ega, bu eng ko'p usize-da bitlar sonidir.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // XAVFSIZLIK: gcd har doim katta yoki 1 ga teng.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Ushbu branch quyidagi chiziqli muvofiqlik tenglamasini echadi:
        //
        // ` p + so = 0 mod a `
        //
        // `p` bu erda `s` ko'rsatkichi, `T` qadam, `o` ofset `T`s va `a`, talab qilingan hizalama.
        //
        // `g = gcd(a, s)` bilan va yuqoridagi shart `p` ning `g` ga bo'linishini tasdiqlasa, biz `a' = a/g`, `s' = s/g`, `p' = p/g` ni belgilashimiz mumkin, keyin bu quyidagiga teng bo'ladi:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Birinchi atama "the relative alignment of `p` to `a`" (`g` ga bo'linadi), ikkinchi muddat "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (yana `g` ga bo'linadi).
        //
        // Agar `a` va `s` birlamchi bo'lmasa, teskari yaxshi hosil qilish uchun `g` ga bo'linish kerak.
        //
        // Bundan tashqari, ushbu eritma tomonidan ishlab chiqarilgan natija "minimal" emas, shuning uchun `o mod lcm(s, a)` natijasini olish kerak.Biz `lcm(s, a)`-ni faqat `a'` bilan almashtirishimiz mumkin.
        //
        //
        //
        //
        //

        // XAVFSIZLIK: `gcdpow` yuqori chegaraga ega, bu `a` dagi 0-bitlar sonidan ko'p emas.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // XAVFSIZLIK: `a2` nolga teng emas.`a`-ni `gcdpow`-ga almashtirish belgilangan bitlarning hech birini siljitmaydi
        // `a`-da (ulardan bittasi bor).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // XAVFSIZLIK: `gcdpow` yuqori chegaraga ega, bu `a` dagi 0-bitlar sonidan ko'p emas.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // XAVFSIZLIK: `gcdpow` ning chegarasi 0 bitdan ortib ketmaydigan songa ega
        // `a`.
        // Bundan tashqari, olib tashlash ortiqcha bo'lolmaydi, chunki `a2 = a >> gcdpow` har doim `(p % a) >> gcdpow` dan kattaroq bo'ladi.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // XAVFSIZLIK: `a2`-yuqorida tasdiqlanganidek, ikkitaning kuchi.`s2` `a2` dan qat'iyan kam
        // chunki `(s % a) >> gcdpow` qat'iy ravishda `a >> gcdpow` dan kam.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Hech qanday tekislash mumkin emas.
    usize::MAX
}

/// Tenglik uchun xom ko'rsatkichlarni taqqoslaydi.
///
/// Bu `==` operatoridan foydalanish bilan bir xil, ammo kamroq umumiy:
/// argumentlar `PartialEq` ni amalga oshiradigan narsa emas, balki `*const T` xom ko'rsatgichlari bo'lishi kerak.
///
/// Bu `&T` havolalarini (ular `*const T` ga to'g'ridan-to'g'ri majburlanadigan) o'zlari ko'rsatgan qiymatlarni taqqoslash o'rniga ularning manzillari bilan taqqoslash uchun ishlatilishi mumkin (bu `PartialEq for &T` dasturini amalga oshiradi).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Dilimlarni uzunligi bilan taqqoslaganda (yog 'ko'rsatkichlari):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits shuningdek, ularni amalga oshirish bilan taqqoslanadi:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Ko'rsatkichlar teng manzillarga ega.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Ob'ektlar teng manzillarga ega, ammo `Trait` turli xil dasturlarga ega.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Malumotni `*const u8`-ga o'tkazish manzil bo'yicha taqqoslanadi.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Xom ko'rsatkichni aralashtiramiz.
///
/// Bu `&T` ma'lumotnomasini (u `*const T` ga to'g'ridan-to'g'ri majburlanadigan) ko'rsatilgan manzilga emas, balki manziliga qarab aralashtirish uchun ishlatilishi mumkin (bu `Hash for &T` dasturini amalga oshiradi).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Funktsiya ko'rsatkichlari uchun impls
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR uchun usize sifatida oraliq gips kerak
                // manba funktsiyasining ko'rsatgichining manzil maydoni oxirgi funktsiya ko'rsatgichida saqlanib qolishi uchun.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR uchun usize sifatida oraliq gips kerak
                // manba funktsiyasining ko'rsatgichining manzil maydoni oxirgi funktsiya ko'rsatgichida saqlanib qolishi uchun.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // 0 parametrli variadik funktsiyalar yo'q
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// `const` xom ko'rsatkichini oraliq ma'lumotnoma yaratmasdan joyga yarating.
///
/// `&`/`&mut` bilan ma'lumotnoma yaratishga faqat ko'rsatgich to'g'ri hizalansa va boshlangan ma'lumotlarga ishora qilsa ruxsat beriladi.
/// Bunday talablarga javob beradigan holatlar o'rniga xom ko'rsatgichlardan foydalanish kerak.
/// Biroq, `&expr as *const _` xom ko'rsatgichga tashlanishidan oldin mos yozuvlar yaratadi va bu ma'lumotnoma barcha boshqa havolalar bilan bir xil qoidalarga bo'ysunadi.
///
/// Ushbu so'l avval ko'rsatma yaratmasdan * xom ko'rsatgich yaratishi mumkin.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` mos kelmagan ma'lumotnomani yaratadi va shu bilan aniqlanmagan xatti-harakatlar bo'ladi!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// `mut` xom ko'rsatkichini oraliq ma'lumotnoma yaratmasdan joyga yarating.
///
/// `&`/`&mut` bilan ma'lumotnoma yaratishga faqat ko'rsatgich to'g'ri hizalansa va boshlangan ma'lumotlarga ishora qilsa ruxsat beriladi.
/// Bunday talablarga javob beradigan holatlar o'rniga xom ko'rsatgichlardan foydalanish kerak.
/// Biroq, `&mut expr as *mut _` xom ko'rsatgichga tashlanishidan oldin mos yozuvlar yaratadi va bu ma'lumotnoma barcha boshqa havolalar bilan bir xil qoidalarga bo'ysunadi.
///
/// Ushbu so'l avval ko'rsatma yaratmasdan * xom ko'rsatgich yaratishi mumkin.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` mos kelmagan ma'lumotnomani yaratadi va shu bilan aniqlanmagan xatti-harakatlar bo'ladi!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` mos yozuvlar yaratish o'rniga maydonni nusxalashga majbur qiladi.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}