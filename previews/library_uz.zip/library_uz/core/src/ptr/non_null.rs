use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` lekin nolga teng bo'lmagan va kovariant.
///
/// Xom ko'rsatgichlar yordamida ma'lumotlar tuzilmalarini qurishda bu ko'pincha to'g'ri narsadir, ammo qo'shimcha xususiyatlar tufayli foydalanish yanada xavfli.Agar siz `NonNull<T>`-dan foydalanishingiz kerakligiga ishonchingiz komil bo'lmasa, shunchaki `*mut T`-dan foydalaning!
///
/// `*mut T`-dan farqli o'laroq, ko'rsatgich hech qachon bekor qilinmagan bo'lsa ham, har doim nolga teng bo'lishi kerak.Enumlar ushbu taqiqlangan qiymatdan diskriminant sifatida foydalanishlari uchun shunday bo'ladi-`Option<NonNull<T>>` hajmi `* mut T` bilan bir xil.
/// Biroq, ko'rsatma berilmasa, u hali ham to'xtab qolishi mumkin.
///
/// `*mut T`-dan farqli o'laroq, `NonNull<T>` `T`-dan kovariant sifatida tanlangan.Bu kovariant turlarini yaratishda `NonNull<T>` dan foydalanishga imkon beradi, ammo aslida kovariant bo'lmasligi kerak bo'lgan turda ishlatilsa, noaniqlik xavfini keltirib chiqaradi.
/// (Qarama-qarshi tanlov `*mut T` uchun qilingan, garchi texnik jihatdan befarqlikka faqat xavfli funktsiyalarni chaqirish sabab bo'lishi mumkin.)
///
/// Kovaryans `Box`, `Rc`, `Arc`, `Vec` va `LinkedList` kabi eng xavfsiz abstraktsiyalar uchun to'g'ri keladi.Buning sababi shundaki, ular Rust-ning odatdagi umumiy XOR o'zgaruvchan qoidalariga amal qiladigan umumiy API-ni taqdim etadilar.
///
/// Agar sizning turingiz xavfsiz ravishda kovariant bo'la olmasa, uning o'zgarmasligini ta'minlash uchun qo'shimcha maydon mavjudligini ta'minlashingiz kerak.Ko'pincha bu maydon `PhantomData<Cell<T>>` yoki `PhantomData<&'a mut T>` kabi [`PhantomData`] turi bo'ladi.
///
/// `NonNull<T>`-da `&T` uchun `From` misoli borligiga e'tibor bering.Biroq, bu mutatsiyani [`UnsafeCell<T>`] ichida sodir bo'lmaguncha (a-dan olingan ko'rsatgich) umumiy havola orqali mutatsiyani aniqlanmagan xatti-harakatlar ekanligini o'zgartirmaydi.Xuddi shu narsa umumiy ma'lumotdan o'zgarishi mumkin bo'lgan ma'lumotnomani yaratish uchun ham amal qiladi.
///
/// Ushbu `From` nusxasini `UnsafeCell<T>` holda ishlatishda, sizning `as_mut` hech qachon chaqirilmasligini va `as_ptr` mutatsiya uchun ishlatilmasligini ta'minlash sizning javobgarligingizdir.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ko'rsatgichlar `Send` emas, chunki ular murojaat qilgan ma'lumotlar boshqa nomga ega bo'lishi mumkin.
// NB, bu shrift kerak emas, lekin yaxshiroq xato xabarlarini taqdim etishi kerak.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ko'rsatgichlar `Sync` emas, chunki ular murojaat qilgan ma'lumotlar boshqa nomga ega bo'lishi mumkin.
// NB, bu shrift kerak emas, lekin yaxshiroq xato xabarlarini taqdim etishi kerak.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Osilib turadigan, lekin yaxshi moslashtirilgan yangi `NonNull` yaratadi.
    ///
    /// Bu `Vec::new` kabi dangasa ajratadigan turlarni ishga tushirish uchun foydalidir.
    ///
    /// Shuni esda tutingki, ko'rsatgich qiymati potentsial ravishda `T` uchun to'g'ri ko'rsatgichni ko'rsatishi mumkin, ya'ni bu "not yet initialized" qo'riqchisi qiymati sifatida ishlatilmasligi kerak.
    /// Dangasa ajratadigan turlar boshlang'ichni boshqa usullar bilan kuzatishi kerak.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // XAVFSIZLIK: mem::align_of() nolga teng bo'lmagan foydalanishni qaytaradi va keyin tashlanadi
        // a * mut T. ga
        // Shuning uchun `ptr` nolga teng emas va new_unchecked() qo'ng'iroq qilish shartlariga rioya qilinadi.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Qiymatga umumiy havolalarni qaytaradi.[`as_ref`]-dan farqli o'laroq, bu qiymatni boshlashni talab qilmaydi.
    ///
    /// O'zgaruvchan hamkori uchun [`as_uninit_mut`]-ga qarang.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ushbu usulni chaqirganda, siz quyidagilarning barchasi to'g'ri ekanligiga ishonch hosil qilishingiz kerak:
    ///
    /// * Ko'rsatkich to'g'ri tekislangan bo'lishi kerak.
    ///
    /// * [the module documentation] da belgilangan ma'noda "dereferencable" bo'lishi kerak.
    ///
    /// * Qaytgan hayot muddati `'a` o'zboshimchalik bilan tanlanganligi va ma'lumotlarning haqiqiy ishlash muddatini aks ettirmasligi sababli Rust-ning taxallus qoidalarini bajarishingiz kerak.
    ///
    ///   Xususan, ushbu umr davomida ko'rsatgich ko'rsatgan xotira mutatsiyaga tushmasligi kerak (`UnsafeCell` ichidan tashqari).
    ///
    /// Ushbu usul natijasi ishlatilmagan bo'lsa ham amal qiladi!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` barcha talablarga javob berishiga kafolat berishi kerak
        // ma'lumotnomaga qo'yiladigan talablar.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Qiymatga noyob havolalarni qaytaradi.[`as_mut`]-dan farqli o'laroq, bu qiymatni boshlashni talab qilmaydi.
    ///
    /// Umumiy sherik uchun [`as_uninit_ref`]-ga qarang.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Ushbu usulni chaqirganda, siz quyidagilarning barchasi to'g'ri ekanligiga ishonch hosil qilishingiz kerak:
    ///
    /// * Ko'rsatkich to'g'ri tekislangan bo'lishi kerak.
    ///
    /// * [the module documentation] da belgilangan ma'noda "dereferencable" bo'lishi kerak.
    ///
    /// * Qaytgan hayot muddati `'a` o'zboshimchalik bilan tanlanganligi va ma'lumotlarning haqiqiy ishlash muddatini aks ettirmasligi sababli Rust-ning taxallus qoidalarini bajarishingiz kerak.
    ///
    ///   Xususan, ushbu umr davomida ko'rsatgich ko'rsatgan xotiraga boshqa ko'rsatgich orqali kirish (o'qish yoki yozish) kerak emas.
    ///
    /// Ushbu usul natijasi ishlatilmagan bo'lsa ham amal qiladi!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` barcha talablarga javob berishiga kafolat berishi kerak
        // ma'lumotnomaga qo'yiladigan talablar.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Yangi `NonNull` yaratadi.
    ///
    /// # Safety
    ///
    /// `ptr` null bo'lishi kerak.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `ptr` nolga teng emasligiga kafolat berishi kerak.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Agar `ptr` null bo'lsa, yangi `NonNull` hosil qiladi.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // XAVFSIZLIK: Ko'rsatkich allaqachon tekshirilgan va bo'sh emas
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// [`std::ptr::from_raw_parts`] bilan bir xil funktsiyalarni bajaradi, faqat `*const` ko'rsatkichidan farqli o'laroq, `NonNull` ko'rsatkichi qaytariladi.
    ///
    ///
    /// Qo'shimcha ma'lumot olish uchun [`std::ptr::from_raw_parts`] hujjatiga qarang.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // XAVFSIZLIK: `ptr::from::raw_parts_mut` natijasi nolga teng emas, chunki `data_address` shunday.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// (Keng bo'lishi mumkin) ko'rsatgichni manzil va metama'lumotlar komponentlariga ajrating.
    ///
    /// Keyinchalik ko'rsatkichni [`NonNull::from_raw_parts`] yordamida tiklash mumkin.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Asosiy `*mut` ko'rsatkichini oladi.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Qiymat haqida umumiy ma'lumotni qaytaradi.Agar qiymat boshlanmagan bo'lsa, uning o'rniga [`as_uninit_ref`] ishlatilishi kerak.
    ///
    /// O'zgaruvchan hamkori uchun [`as_mut`]-ga qarang.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Ushbu usulni chaqirganda, siz quyidagilarning barchasi to'g'ri ekanligiga ishonch hosil qilishingiz kerak:
    ///
    /// * Ko'rsatkich to'g'ri tekislangan bo'lishi kerak.
    ///
    /// * [the module documentation] da belgilangan ma'noda "dereferencable" bo'lishi kerak.
    ///
    /// * Ko'rsatkich `T` ning boshlang'ich nusxasini ko'rsatishi kerak.
    ///
    /// * Qaytgan hayot muddati `'a` o'zboshimchalik bilan tanlanganligi va ma'lumotlarning haqiqiy ishlash muddatini aks ettirmasligi sababli Rust-ning taxallus qoidalarini bajarishingiz kerak.
    ///
    ///   Xususan, ushbu umr davomida ko'rsatgich ko'rsatgan xotira mutatsiyaga tushmasligi kerak (`UnsafeCell` ichidan tashqari).
    ///
    /// Ushbu usul natijasi ishlatilmagan bo'lsa ham amal qiladi!
    /// (Ishga tushirish qismi hali to'liq hal qilinmagan, ammo shu paytgacha yagona xavfsiz yondashuv ular haqiqatan ham ishga tushirilishini ta'minlashdir.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` barcha talablarga javob berishiga kafolat berishi kerak
        // ma'lumotnomaga qo'yiladigan talablar.
        unsafe { &*self.as_ptr() }
    }

    /// Qiymatga noyob havolani qaytaradi.Agar qiymat boshlanmagan bo'lsa, uning o'rniga [`as_uninit_mut`] ishlatilishi kerak.
    ///
    /// Umumiy sherik uchun [`as_ref`]-ga qarang.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Ushbu usulni chaqirganda, siz quyidagilarning barchasi to'g'ri ekanligiga ishonch hosil qilishingiz kerak:
    ///
    /// * Ko'rsatkich to'g'ri tekislangan bo'lishi kerak.
    ///
    /// * [the module documentation] da belgilangan ma'noda "dereferencable" bo'lishi kerak.
    ///
    /// * Ko'rsatkich `T` ning boshlang'ich nusxasini ko'rsatishi kerak.
    ///
    /// * Qaytgan hayot muddati `'a` o'zboshimchalik bilan tanlanganligi va ma'lumotlarning haqiqiy ishlash muddatini aks ettirmasligi sababli Rust-ning taxallus qoidalarini bajarishingiz kerak.
    ///
    ///   Xususan, ushbu umr davomida ko'rsatgich ko'rsatgan xotiraga boshqa ko'rsatgich orqali kirish (o'qish yoki yozish) kerak emas.
    ///
    /// Ushbu usul natijasi ishlatilmagan bo'lsa ham amal qiladi!
    /// (Ishga tushirish qismi hali to'liq hal qilinmagan, ammo shu paytgacha yagona xavfsiz yondashuv ular haqiqatan ham ishga tushirilishini ta'minlashdir.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self` barcha talablarga javob berishiga kafolat berishi kerak
        // o'zgarishi mumkin bo'lgan ma'lumotnomaga qo'yiladigan talablar.
        unsafe { &mut *self.as_ptr() }
    }

    /// Boshqa turdagi ko'rsatgichga tashlanadi.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // XAVFSIZLIK: `self`-bu mutlaqo bo'sh bo'lmagan `NonNull` ko'rsatkichi
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Nozik bo'lmagan xom tilimni ingichka ko'rsatkich va uzunlikdan hosil qiladi.
    ///
    /// `len` argumenti **element** soni, baytlar soni emas.
    ///
    /// Ushbu funktsiya xavfsiz, ammo qaytish qiymatini ajratish xavfli emas.
    /// Dilim xavfsizligi talablari uchun [`slice::from_raw_parts`] hujjatlariga qarang.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // birinchi elementga ko'rsatgich bilan boshlanganda tilim ko'rsatkichini yarating
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Shuni esda tutingki, ushbu misol sun'iy ravishda ushbu usuldan foydalanishni namoyish etadi, ammo `tilim= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // XAVFSIZLIK: `data`-bu mutlaqo bo'sh bo'lmagan `NonNull` ko'rsatkichi
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Nol bo'lmagan xom bo'lakning uzunligini qaytaradi.
    ///
    /// Qaytgan qiymat-bu baytlar soni emas, balki **elementlar** soni.
    ///
    /// Nol bo'lmagan xom bo'lakni tilimga ajratib bo'lmaydigan bo'lsa ham, bu funktsiya xavfsizdir, chunki ko'rsatgichda tegishli manzil yo'q.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Nol bo'lmagan ko'rsatkichni tilimning buferiga qaytaradi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // XAVFSIZLIK: Biz `self` ning nol ekanligini bilamiz.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Xom ko'rsatkichni tilimning buferiga qaytaradi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Ehtimol, boshlang'ich qiymatlari bo'linmasiga umumiy havolani qaytaradi.[`as_ref`]-dan farqli o'laroq, bu qiymatni boshlashni talab qilmaydi.
    ///
    /// O'zgaruvchan hamkori uchun [`as_uninit_slice_mut`]-ga qarang.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ushbu usulni chaqirganda, siz quyidagilarning barchasi to'g'ri ekanligiga ishonch hosil qilishingiz kerak:
    ///
    /// * Ko'rsatkich `ptr.len() * mem::size_of::<T>()` ko'p bayt uchun o'qish uchun [valid] bo'lishi kerak va u to'g'ri hizalanmalıdır.Bu, xususan:
    ///
    ///     * Ushbu tilimning butun xotira diapazoni bitta ajratilgan ob'ekt ichida bo'lishi kerak!
    ///       Bo'limlar hech qachon bir nechta ajratilgan ob'ektlar bo'ylab tarqalib keta olmaydi.
    ///
    ///     * Ko'rsatkich nol uzunlikdagi bo'laklar uchun ham tekislanishi kerak.
    ///     Buning bir sababi shundaki, enum tartibini optimallashtirish mos yozuvlar (har qanday uzunlikdagi tilimlarni o'z ichiga olgan holda) hizalanmış va boshqa ma'lumotlardan ajratib turishi mumkin.
    ///
    ///     [`NonNull::dangling()`] yordamida nol uzunlikdagi bo'laklar uchun `data` sifatida ishlatilishi mumkin bo'lgan ko'rsatkichni olishingiz mumkin.
    ///
    /// * Dilimning umumiy hajmi `ptr.len() * mem::size_of::<T>()` `isize::MAX` dan katta bo'lmasligi kerak.
    ///   [`pointer::offset`] xavfsizlik hujjatlariga qarang.
    ///
    /// * Qaytgan hayot muddati `'a` o'zboshimchalik bilan tanlanganligi va ma'lumotlarning haqiqiy ishlash muddatini aks ettirmasligi sababli Rust-ning taxallus qoidalarini bajarishingiz kerak.
    ///   Xususan, ushbu umr davomida ko'rsatgich ko'rsatgan xotira mutatsiyaga tushmasligi kerak (`UnsafeCell` ichidan tashqari).
    ///
    /// Ushbu usul natijasi ishlatilmagan bo'lsa ham amal qiladi!
    ///
    /// Shuningdek, [`slice::from_raw_parts`]-ga qarang.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `as_uninit_slice` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Ehtimol boshlanmagan qiymatlar bo'lagiga noyob havolani qaytaradi.[`as_mut`]-dan farqli o'laroq, bu qiymatni boshlashni talab qilmaydi.
    ///
    /// Umumiy sherik uchun [`as_uninit_slice`]-ga qarang.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Ushbu usulni chaqirganda, siz quyidagilarning barchasi to'g'ri ekanligiga ishonch hosil qilishingiz kerak:
    ///
    /// * Ko'rsatkich `ptr.len() * mem::size_of::<T>()` ko'p baytlarni o'qish va yozish uchun [valid] bo'lishi kerak va u to'g'ri hizalanmalıdır.Bu, xususan:
    ///
    ///     * Ushbu tilimning butun xotira diapazoni bitta ajratilgan ob'ekt ichida bo'lishi kerak!
    ///       Bo'limlar hech qachon bir nechta ajratilgan ob'ektlar bo'ylab tarqalib keta olmaydi.
    ///
    ///     * Ko'rsatkich nol uzunlikdagi bo'laklar uchun ham tekislanishi kerak.
    ///     Buning bir sababi shundaki, enum tartibini optimallashtirish mos yozuvlar (har qanday uzunlikdagi tilimlarni o'z ichiga olgan holda) hizalanmış va boshqa ma'lumotlardan ajratib turishi mumkin.
    ///
    ///     [`NonNull::dangling()`] yordamida nol uzunlikdagi bo'laklar uchun `data` sifatida ishlatilishi mumkin bo'lgan ko'rsatkichni olishingiz mumkin.
    ///
    /// * Dilimning umumiy hajmi `ptr.len() * mem::size_of::<T>()` `isize::MAX` dan katta bo'lmasligi kerak.
    ///   [`pointer::offset`] xavfsizlik hujjatlariga qarang.
    ///
    /// * Qaytgan hayot muddati `'a` o'zboshimchalik bilan tanlanganligi va ma'lumotlarning haqiqiy ishlash muddatini aks ettirmasligi sababli Rust-ning taxallus qoidalarini bajarishingiz kerak.
    ///   Xususan, ushbu umr davomida ko'rsatgich ko'rsatgan xotiraga boshqa ko'rsatgich orqali kirish (o'qish yoki yozish) kerak emas.
    ///
    /// Ushbu usul natijasi ishlatilmagan bo'lsa ham amal qiladi!
    ///
    /// Shuningdek, [`slice::from_raw_parts_mut`]-ga qarang.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Bu xavfsiz, chunki `memory` ko'p baytlarni o'qish va yozish uchun yaroqli.
    /// // Shuni esda tutingki, bu erda `memory.as_mut()` raqamiga qo'ng'iroq qilish taqiqlangan, chunki tarkib boshlanmagan bo'lishi mumkin.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `as_uninit_slice_mut` uchun xavfsizlik shartnomasini bajarishi kerak.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Xom ko'rsatkichni chegara tekshirmasdan elementga yoki pastki qismga qaytaradi.
    ///
    /// Ushbu usulni chegaradan tashqaridagi indeks bilan chaqirish yoki `self` ni ajratib bo'lmaydigan bo'lsa,*[aniqlanmagan xatti-harakatlar]* natijada ko'rsatgich ishlatilmasa ham.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi `self`-ni ajratib bo'lmaydigan va `index`-ning chegarasida bo'lishini ta'minlaydi.
        // Natijada, natijada ko'rsatgich NULL bo'lishi mumkin emas.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // XAVFSIZLIK: Noyob ko'rsatgich null bo'lishi mumkin emas, shuning uchun shartlar
        // new_unchecked() hurmatga sazovor.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // XAVFSIZLIK: O'zgaruvchan mos yozuvlar nol bo'lishi mumkin emas.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // XAVFSIZLIK: Ma'lumot null bo'lishi mumkin emas, shuning uchun shartlar
        // new_unchecked() hurmatga sazovor.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}