//! Qarzga olingan ma'lumotlar bilan ishlash moduli.

#![stable(feature = "rust1", since = "1.0.0")]

/// Ma'lumotni qarz olish uchun trait.
///
/// Rust-da, har xil foydalanish holatlari uchun turdagi har xil tasvirlarni taqdim etish odatiy holdir.
/// Masalan, qiymatni saqlash joyi va boshqaruvi [`Box<T>`] yoki [`Rc<T>`] kabi ko'rsatgich turlari orqali ma'lum foydalanishga mos ravishda tanlanishi mumkin.
/// Har qanday turdagi ishlatilishi mumkin bo'lgan ushbu umumiy o'ramlardan tashqari, ba'zi turlari mumkin bo'lgan funktsiyalarni ta'minlaydigan ixtiyoriy jihatlarni taqdim etadi.
/// Bunday turga misol [`String`] bo'lib, u asosiy [`str`] ga mag'lubiyatni kengaytirish imkoniyatini qo'shadi.
/// Bu oddiy, o'zgarmas mag'lubiyat uchun qo'shimcha ma'lumotlarni keraksiz saqlashni talab qiladi.
///
/// Ushbu turlar ushbu ma'lumotlarning turiga havolalar orqali asosiy ma'lumotlarga kirishni ta'minlaydi.Ular ushbu turdagi "qarzga olingan" deb aytishadi.
/// Masalan, [`Box<T>`] ni `T` sifatida, [`String`] ni esa `str` sifatida olish mumkin.
///
/// Turlar, ularni `T` turi sifatida X0Xni amalga oshirish orqali qarzga olish mumkinligini bildiradi va trait ning [`borrow`] usulida `T` ga havola qiladi.Turi bir necha xil turlari sifatida qarz olish uchun bepul.
/// Agar u o'zaro mutanosib ravishda qarz olishni xohlasa-asosiy ma'lumotlarni o'zgartirishga imkon beradigan bo'lsa, u qo'shimcha ravishda [`BorrowMut<T>`]-ni amalga oshirishi mumkin.
///
/// Bundan tashqari, qo'shimcha traits uchun dasturlarni taqdim etishda, ular ushbu turdagi turlarning vakili sifatida harakat qilishlari natijasida o'zlarini asosiy turdagi bilan bir xil tutishlari kerakmi, deb o'ylash kerak.
/// Umumiy kod odatda `Borrow<T>`-ni ushbu qo'shimcha trait dasturlarining bir xil xatti-harakatlariga asoslangan holda ishlatadi.
/// Ushbu traits qo'shimcha trait bounds sifatida paydo bo'lishi mumkin.
///
/// Xususan, `Eq`, `Ord` va `Hash` qarzga olingan va tegishli qiymatlarga teng bo'lishi kerak: `x.borrow() == y.borrow()` `x == y` bilan bir xil natijani berishi kerak.
///
/// Agar umumiy kod faqatgina tegishli `T` turiga havola beradigan barcha turlar uchun ishlashi kerak bo'lsa, ko'pincha [`AsRef<T>`] dan foydalanish yaxshiroq, chunki uni ko'proq turlari xavfsiz amalga oshirishi mumkin.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Ma'lumotlar to'plami sifatida [`HashMap<K, V>`] ikkala kalit va qiymatlarga ega.Agar kalitning haqiqiy ma'lumotlari biron bir turdagi boshqaruv turiga o'ralgan bo'lsa, shunga qaramay, kalit ma'lumotlariga havola yordamida qiymatni qidirish mumkin bo'lishi kerak.
/// Masalan, agar kalit mag'lubiyatga ega bo'lsa, u holda xash xaritada [`String`] sifatida saqlanadi, [`&str`][`str`] yordamida qidirish imkoniyati bo'lishi kerak.
/// Shunday qilib, `insert` `String`-da ishlashi kerak, `get` esa `&str`-dan foydalanishi kerak.
///
/// `HashMap<K, V>`-ning tegishli qismlari biroz soddalashtirilgan bo'lib, quyidagicha ko'rinadi:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // maydonlar qoldirilgan
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Butun xash xaritasi `K` kalit turi bo'yicha umumiydir.Ushbu kalitlar xash xaritasi bilan saqlanganligi sababli, ushbu turdagi kalit ma'lumotlariga egalik qilishi kerak.
/// Kalit-qiymat juftligini kiritishda xaritaga shunday `K` beriladi va to'g'ri xash paqirini topishi va shu `K` asosida kalit allaqachon mavjudligini tekshirishi kerak.Shuning uchun `K: Hash + Eq` kerak.
///
/// Xaritada qiymatni qidirishda `K`-ga havola qilish kerak, chunki uni qidirish uchun kalit har doim shunday qiymatni yaratishni talab qiladi.
/// Satr kalitlari uchun bu faqat `str` mavjud bo'lgan holatlarni qidirish uchun `String` qiymatini yaratish kerakligini anglatadi.
///
/// Buning o'rniga, `get` usuli yuqoridagi usul imzosida `Q` deb nomlangan asosiy ma'lumotlar turiga nisbatan umumiydir.`K`, `K: Borrow<Q>` talab qilib, `Q` sifatida qarz olishini aytadi.
/// `Q: Hash + Eq`-ni qo'shimcha ravishda talab qilib, `K` va `Q`-da `Hash` va `Eq` traits-ning bir xil natijalarga olib keladigan dasturlari bo'lishi kerakligi to'g'risida signal beradi.
///
/// `get`-ni amalga oshirish, xususan, `K` qiymatidan hisoblangan xash qiymatiga asoslanib kalitni kiritgan bo'lsa ham, `Hash::hash`-ni `Hash::hash`-ga qo'ng'iroq qilib kalitning xash paqirini aniqlash orqali `Hash`-ning bir xil dasturlariga tayanadi.
///
///
/// Natijada, `Q` qiymatini o'ragan `K` `Q` dan farqli xash hosil qilsa, xash xaritasi buziladi.Masalan, sizda mag'lubiyatni o'ralgan, ammo ularning ishlarini inobatga olmasdan ASCII harflarini taqqoslaydigan turingiz borligini tasavvur qiling:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Ikki teng qiymat bir xil xash qiymatini yaratishi kerakligi sababli, `Hash` dasturini ASCII holatini ham e'tiborsiz qoldirish kerak:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` `Borrow<str>` ni amalga oshirishi mumkinmi?Bu, albatta, o'z ichiga olgan satr orqali mag'lubiyat tilimiga havola berishi mumkin.
/// Ammo uning `Hash` dasturi boshqacha bo'lgani uchun, u `str` dan boshqacha yo'l tutadi va shuning uchun aslida `Borrow<str>` ni amalga oshirmasligi kerak.
/// Agar u boshqalarga asosiy `str`-ga kirishga ruxsat berishni xohlasa, buni `AsRef<str>` orqali amalga oshirishi mumkin, bu qo'shimcha talablarni o'z ichiga olmaydi.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// O'ziga tegishli qiymatdan o'zgarmas ravishda qarz oladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Qarama-qarshi ma'lumot olish uchun trait.
///
/// Ushbu trait [`Borrow<T>`]-ning sherigi sifatida, o'zgaruvchan ma'lumotni taqdim etish orqali asosiy tur sifatida qarz olishga imkon beradi.
/// Boshqa turdagi qarz olish to'g'risida ko'proq ma'lumot olish uchun [`Borrow<T>`]-ga qarang.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// O'ziga tegishli qiymatdan qarz oladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}