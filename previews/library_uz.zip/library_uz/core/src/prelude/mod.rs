//! Libcore prelude
//!
//! Ushbu modul libcore foydalanuvchilari uchun mo'ljallangan, ular libstd-ga ulanmaydi.
//! Ushbu modul standart kutubxonaning prelude usuli bilan `#![no_std]` ishlatilganda sukut bo'yicha import qilinadi.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// prelude yadrosining 2015 yilgi versiyasi.
///
/// Qo'shimcha ma'lumot uchun [module-level documentation](self)-ga qarang.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude yadrosining 2018 yilgi versiyasi.
///
/// Qo'shimcha ma'lumot uchun [module-level documentation](self)-ga qarang.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// prelude yadrosining 2021 versiyasi.
///
/// Qo'shimcha ma'lumot uchun [module-level documentation](self)-ga qarang.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Yana narsalar qo'shing.
}