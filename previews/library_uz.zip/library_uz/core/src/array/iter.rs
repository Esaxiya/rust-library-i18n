//! Massivlar uchun `IntoIter`-ga tegishli iteratorni aniqlaydi.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// [array] qiymatini takrorlovchi.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Bu biz takrorlayotgan qator.
    ///
    /// `i` indeksiga ega bo'lgan elementlar, u erda `alive.start <= i < alive.end` hali olinmagan va amaldagi qator yozuvlari hisoblanadi.
    /// `i < alive.start` yoki `i >= alive.end` indekslari bo'lgan elementlar allaqachon ishlab chiqarilgan va endi ularga kirish mumkin emas!Ushbu o'lik elementlar hatto umuman boshlanmagan holatda bo'lishi mumkin!
    ///
    ///
    /// Demak, invariantlar:
    /// - `data[alive]` tirik (ya'ni tegishli elementlarni o'z ichiga oladi)
    /// - `data[..alive.start]` va `data[alive.end..]` o'lik (ya'ni elementlar allaqachon o'qilgan va ularga tegmaslik kerak!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data`-dagi hali olinmagan elementlar.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Berilgan `array` ustida yangi iterator yaratadi.
    ///
    /// *Izoh*: bu usul future da, [`IntoIterator` is implemented for arrays][array-into-iter] dan keyin bekor qilinishi mumkin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` turi bu erda `&i32` o'rniga `i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // XAVFSIZLIK: Bu erda transmute aslida xavfsizdir.`MaybeUninit` hujjatlari
        // promise:
        //
        // > `MaybeUninit<T>` bir xil o'lchamda va tekislashda kafolatlangan
        // > `T` sifatida.
        //
        // Hujjatlar hatto `MaybeUninit<T>` qatoridan `T` qatoriga transmututni ham ko'rsatadi.
        //
        //
        // Shu bilan, bu boshlang'ich invariantlarni qondiradi.

        // FIXME(LukasKalbertodt): aslida const generics bilan ishlagandan so'ng, bu erda `mem::transmute` dan foydalaning:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // O'sha vaqtga qadar biz `mem::transmute_copy`-dan bittadan nusxa ko'chirishni boshqa tur sifatida yaratishimiz mumkin, keyin `array`-ni esdan chiqaramiz, shunda u tushmaydi.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Hali berilmagan barcha elementlarning o'zgarmas bo'lagini qaytaradi.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // XAVFSIZLIK: Biz `alive` ichidagi barcha elementlarning to'g'ri ishga tushirilganligini bilamiz.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Hali ham hosil qilinmagan barcha elementlarning o'zgaruvchan qismini qaytaradi.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // XAVFSIZLIK: Biz `alive` ichidagi barcha elementlarning to'g'ri ishga tushirilganligini bilamiz.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Oldindan keyingi indeksni oling.
        //
        // `alive.start` ni 1 ga oshirish `alive` ga nisbatan o'zgarmaslikni saqlaydi.
        // Biroq, ushbu o'zgarish tufayli qisqa vaqt ichida tirik mintaqa endi `data[alive]` emas, balki `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Massivdan elementni o'qing.
            // XAVFSIZLIK: `idx`-bu oldingi "alive" mintaqasining indeksidir
            // qator.Ushbu elementni o'qish, `data[idx]` ni o'lik deb hisoblashini anglatadi (ya'ni tegmang).
            // `idx` tirik zonaning boshlanishi bo'lganligi sababli, tirik zona yana `data[alive]` bo'lib, barcha invariantlarni tiklaydi.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Orqa tomondan keyingi ko'rsatkichni oling.
        //
        // `alive.end` ni 1 ga kamaytirish `alive` ga nisbatan o'zgarmaslikni saqlaydi.
        // Biroq, ushbu o'zgarish tufayli qisqa vaqt ichida tirik mintaqa endi `data[alive]` emas, balki `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Massivdan elementni o'qing.
            // XAVFSIZLIK: `idx`-bu oldingi "alive" mintaqasining indeksidir
            // qator.Ushbu elementni o'qish, `data[idx]` ni o'lik deb hisoblashini anglatadi (ya'ni tegmang).
            // `idx` tirik zonaning oxiri bo'lganligi sababli, tirik zona yana `data[alive]` bo'lib, barcha invariantlarni tiklaydi.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // XAVFSIZLIK: Bu xavfsiz: `as_mut_slice` to'liq pastki tilimni qaytaradi
        // hali ko'chirilmagan va tashlab ketilishi kerak bo'lgan elementlarning
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // "Live.start <=" o'zgarmasligi sababli hech qachon to'kilmaydi
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Takrorlovchi haqiqatan ham to'g'ri uzunlik haqida xabar beradi.
// "alive" elementlari soni (ular hali ham olinadi) `alive` oralig'ining uzunligi.
// Ushbu diapazon `next` yoki `next_back` da qisqartiriladi.
// Ushbu usullarda har doim 1 ga kamayadi, lekin faqat `Some(_)` qaytarilsa.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // E'tibor bering, biz haqiqatan ham bir xil jonli diapazonga mos kelishimiz shart emas, shuning uchun biz `self` qaerda bo'lishidan qat'i nazar, 0 ofsetiga o'tishimiz mumkin.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Barcha tirik elementlarni klonlash.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Yangi qatorga klon yozing, so'ngra uning jonli diapazonini yangilang.
            // Agar panics klonlashtirilsa, biz avvalgi elementlarni to'g'ri tashlaymiz.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Faqat hali berilmagan elementlarni chop eting: endi olingan elementlarga kira olmaymiz.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}