Joriy ipni Panics.

Bu dasturni darhol tugatishga va dasturni chaqiruvchiga teskari aloqani ta'minlashga imkon beradi.
`panic!` dastur tiklanib bo'lmaydigan holatga kelganda ishlatilishi kerak.

Ushbu so'l misol kodlari va testlarda shartlarni tasdiqlashning eng yaxshi usuli hisoblanadi.
`panic!` ikkala [`Option`][ounwrap] va [`Result`][runwrap] enumlarining `unwrap` usuli bilan chambarchas bog'liq.
Ikkala dastur ham [`None`] yoki [`Err`] variantlariga o'rnatilganda `panic!` deb nomlanadi.

`panic!()`-dan foydalanganda siz [`format!`] sintaksisidan foydalangan holda magistralning foydali yukini belgilashingiz mumkin.
Ushbu foydali yuk panic-ni chaqiruvchi Rust ipiga kiritishda ishlatiladi va bu ipni butunlay panic ga olib keladi.

Standart `std` hook ning harakati, ya'ni
to'g'ridan-to'g'ri panic chaqirilgandan so'ng ishlaydigan kod `panic!()` chaqiruvining file/line/column ma'lumotlari bilan birga `stderr`-ga xabar yukini chop etishdir.

Siz [`std::panic::set_hook()`] yordamida panic hook-ni bekor qilishingiz mumkin.
hook ichida panic-ga `&dyn Any + Send` sifatida kirish mumkin, unda oddiy `panic!()` chaqiruvlari uchun `&str` yoki `String` mavjud.
Boshqa turdagi qiymatga ega panic uchun [`panic_any`] ishlatilishi mumkin.

[`Result`] enum ko'pincha `panic!` so'lini ishlatishdan ko'ra xatolarni tiklash uchun yaxshiroq echimdir.
Ushbu so'l tashqi qiymatlardan, masalan, noto'g'ri qiymatlardan foydalanishni oldini olish uchun ishlatilishi kerak.
Xatolarni ko'rib chiqish haqida batafsil ma'lumot [book]-da joylashgan.

Kompilyatsiya paytida xatolar yuzaga kelishi uchun [`compile_error!`] so'lini ko'ring.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Amaldagi dastur

Agar asosiy panics ish zarrachasi bo'lsa, u sizning barcha yo'nalishlaringizni tugatadi va `101` kodi bilan dasturingizni tugatadi.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





