#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Qo'ng'iroq qiluvchining nashriga qarab `$crate::panic::panic_2015` yoki `$crate::panic::panic_2021` ga kengayadi.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Ikki ibora bir-biriga teng ekanligini tasdiqlaydi ([`PartialEq`] yordamida).
///
/// panic-da ushbu so'l iboralar qiymatlarini disk raskadrovka tasvirlari bilan bosib chiqaradi.
///
///
/// [`assert!`] singari, ushbu so'lning ikkinchi shakli ham mavjud bo'lib, unda maxsus panic xabarini taqdim etish mumkin.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Quyidagi qayta tiklanishlar qasddan qilingan.
                    // Ularsiz, qarz olish uchun stack uyasi qiymatlarni taqqoslashdan oldin ham ishga tushiriladi va bu sezilarli sekinlashuvga olib keladi.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Quyidagi qayta tiklanishlar qasddan qilingan.
                    // Ularsiz, qarz olish uchun stack uyasi qiymatlarni taqqoslashdan oldin ham ishga tushiriladi va bu sezilarli sekinlashuvga olib keladi.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Ikki ibora bir-biriga teng emasligini tasdiqlaydi ([`PartialEq`] yordamida).
///
/// panic-da ushbu so'l iboralar qiymatlarini disk raskadrovka tasvirlari bilan bosib chiqaradi.
///
///
/// [`assert!`] singari, ushbu so'lning ikkinchi shakli ham mavjud bo'lib, unda maxsus panic xabarini taqdim etish mumkin.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Quyidagi qayta tiklanishlar qasddan qilingan.
                    // Ularsiz, qarz olish uchun stack uyasi qiymatlarni taqqoslashdan oldin ham ishga tushiriladi va bu sezilarli sekinlashuvga olib keladi.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Quyidagi qayta tiklanishlar qasddan qilingan.
                    // Ularsiz, qarz olish uchun stack uyasi qiymatlarni taqqoslashdan oldin ham ishga tushiriladi va bu sezilarli sekinlashuvga olib keladi.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Mantiqiy ifoda ish paytida `true` ekanligini tasdiqlaydi.
///
/// Agar taqdim etilgan ifodani ish vaqtida `true` ga baholash imkoni bo'lmasa, bu [`panic!`] makrosini chaqiradi.
///
/// [`assert!`] singari, ushbu so'lning ikkinchi versiyasi ham mavjud, bu erda maxsus panic xabarini taqdim etish mumkin.
///
/// # Uses
///
/// [`assert!`]-dan farqli o'laroq, `debug_assert!` so'zlari faqat sukut bo'yicha optimallashtirilmagan tuzilmalarda yoqiladi.
/// `-C debug-assertions` kompilyatorga o'tkazilmasa, optimallashtirilgan qurilish `debug_assert!` bayonotlarini bajarmaydi.
/// Bu `debug_assert!`-ni chiqarishda juda qimmat bo'lgan tekshiruvlar uchun foydalidir, ammo ishlab chiqish paytida foydali bo'lishi mumkin.
/// `debug_assert!`-ni kengaytirish natijasi har doim tekshiriladi.
///
/// Tekshirilmagan tasdiqlash mos kelmaydigan holatdagi dasturni ishlashini davom ettirishga imkon beradi, bu esa kutilmagan oqibatlarga olib kelishi mumkin, ammo bu faqat xavfsiz kodda sodir bo'lganda xavfsizlikni keltirib chiqarmaydi.
///
/// Tasdiqlarning ishlash qiymati, umuman olganda, o'lchovli emas.
/// Shunday qilib, [`assert!`]-ni `debug_assert!`-ga almashtirish faqat batafsil profildan so'ng rag'batlantiriladi, eng muhimi, faqat xavfsiz kodda!
///
/// # Examples
///
/// ```
/// // ushbu tasdiqlar uchun panic xabari berilgan ifodaning satrlangan qiymati.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // juda oddiy funktsiya
/// debug_assert!(some_expensive_computation());
///
/// // maxsus xabar bilan tasdiqlang
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Ikki ibora bir-biriga teng ekanligini tasdiqlaydi.
///
/// panic-da ushbu so'l iboralar qiymatlarini disk raskadrovka tasvirlari bilan bosib chiqaradi.
///
/// [`assert_eq!`]-dan farqli o'laroq, `debug_assert_eq!` so'zlari faqat sukut bo'yicha optimallashtirilmagan tuzilmalarda yoqiladi.
/// `-C debug-assertions` kompilyatorga o'tkazilmasa, optimallashtirilgan qurilish `debug_assert_eq!` bayonotlarini bajarmaydi.
/// Bu `debug_assert_eq!`-ni chiqarishda juda qimmat bo'lgan tekshiruvlar uchun foydalidir, ammo ishlab chiqish paytida foydali bo'lishi mumkin.
///
/// `debug_assert_eq!`-ni kengaytirish natijasi har doim tekshiriladi.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Ikki ibora bir-biriga teng emasligini tasdiqlaydi.
///
/// panic-da ushbu so'l iboralar qiymatlarini disk raskadrovka tasvirlari bilan bosib chiqaradi.
///
/// [`assert_ne!`]-dan farqli o'laroq, `debug_assert_ne!` so'zlari faqat sukut bo'yicha optimallashtirilmagan tuzilmalarda yoqiladi.
/// `-C debug-assertions` kompilyatorga o'tkazilmasa, optimallashtirilgan qurilish `debug_assert_ne!` bayonotlarini bajarmaydi.
/// Bu `debug_assert_ne!`-ni chiqarishda juda qimmat bo'lgan, ammo ishlab chiqish paytida foydali bo'lishi mumkin bo'lgan cheklar uchun foydali qiladi.
///
/// `debug_assert_ne!`-ni kengaytirish natijasi har doim tekshiriladi.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Berilgan ifoda berilgan naqshlarga mos keladimi-yo'qligini qaytaradi.
///
/// `match` ifodasida bo'lgani kabi, naqshni ixtiyoriy ravishda `if` va naqsh bilan bog'langan nomlarga kirish huquqiga ega bo'lgan himoya ifodasi ham qo'shishi mumkin.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Natijani ochadi yoki uning xatosini tarqatadi.
///
/// `try!` o'rniga `?` operatori qo'shildi va uning o'rniga foydalanish kerak.
/// Bundan tashqari, `try` Rust 2018-da zaxiralangan so'zdir, shuning uchun uni ishlatishingiz kerak bo'lsa, [raw-identifier syntax][ris]-dan foydalanishingiz kerak bo'ladi: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` berilgan [`Result`] bilan mos keladi.`Ok` variantida, ifoda o'ralgan qiymatning qiymatiga ega.
///
/// `Err` variantida, u ichki xatoni qaytaradi.`try!` keyinchalik `From` yordamida konversiyani amalga oshiradi.
/// Bu ixtisoslashgan va umumiy xatolar o'rtasida avtomatik konversiyani ta'minlaydi.
/// Natijada paydo bo'lgan xato darhol qaytariladi.
///
/// Erta qaytish tufayli `try!` faqat [`Result`] qaytaradigan funktsiyalarda ishlatilishi mumkin.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Xatolarni tez qaytarishning afzal usuli
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Xatolarni tezda qaytarishning oldingi usuli
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Bu quyidagilarga teng:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Formatlangan ma'lumotlarni buferga yozadi.
///
/// Ushbu so'l 'writer', format qatorini va argumentlar ro'yxatini qabul qiladi.
/// Argumentlar belgilangan format qatoriga muvofiq formatlanadi va natija yozuvchiga beriladi.
/// Yozuvchi `write_fmt` usuli bilan har qanday qiymatga ega bo'lishi mumkin;odatda bu [`fmt::Write`] yoki [`io::Write`] trait dasturlarini amalga oshirishdan kelib chiqadi.
/// Makro `write_fmt` usuli qaytargan narsani qaytaradi;odatda [`fmt::Result`] yoki [`io::Result`].
///
/// Format sintaksisiga oid qo'shimcha ma'lumot uchun [`std::fmt`]-ga qarang.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Modul `std::fmt::Write` va `std::io::Write`-ni import qilishi va `write!`-ni ikkalasini ham amalga oshiradigan ob'ektlarga chaqirishi mumkin, chunki ob'ektlar odatda ikkalasini ham amalga oshirmaydi.
///
/// Biroq, modul traits-ni malakali ravishda import qilishi kerak, shuning uchun ularning nomlari ziddiyatli bo'lmaydi:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt dan foydalanadi
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt dan foydalanadi
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Ushbu so'lni `no_std` sozlamalarida ham ishlatish mumkin.
/// `no_std` sozlamalarida siz komponentlarning bajarilish tafsilotlari uchun javobgarsiz.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Formatlangan ma'lumotlarni yangi qator qo'shilgan holda buferga yozing.
///
/// Barcha platformalarda yangi satr faqat LINE FEED belgisi (`\n`/`U+000A`) (qo'shimcha CARRIAGE RETURN (`\r`/`U+000D`) yo'q).
///
/// Qo'shimcha ma'lumot olish uchun [`write!`]-ga qarang.Format mag'lubiyati sintaksisiga oid ma'lumotlarni [`std::fmt`] ga qarang.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Modul `std::fmt::Write` va `std::io::Write`-ni import qilishi va `write!`-ni ikkalasini ham amalga oshiradigan ob'ektlarga chaqirishi mumkin, chunki ob'ektlar odatda ikkalasini ham amalga oshirmaydi.
/// Biroq, modul traits-ni malakali ravishda import qilishi kerak, shuning uchun ularning nomlari ziddiyatli bo'lmaydi:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt dan foydalanadi
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt dan foydalanadi
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Qabul qilinmaydigan kodni bildiradi.
///
/// Bu kompilyator ba'zi bir kodlarga ulanib bo'lmaydiganligini aniqlay olmagan har qanday vaqtda foydalidir.Masalan:
///
/// * Qo'llarni qo'riqlash shartlari bilan moslashtiring.
/// * Dinamik ravishda tugaydigan tsikllar.
/// * Dinamik ravishda tugaydigan takrorlovchilar.
///
/// Agar kodni topish mumkin emasligini aniqlash noto'g'ri bo'lsa, dastur darhol [`panic!`] bilan tugaydi.
///
/// Ushbu so'lning xavfli hamkori [`unreachable_unchecked`] funktsiyasidir, agar kodga erishilsa, u aniqlanmagan xatti-harakatga olib keladi.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Bu har doim [`panic!`] bo'ladi.
///
/// # Examples
///
/// Uchrashuv qo'llari:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // izohlangan bo'lsa, kompilyatsiya xatosi
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3-ning eng yomon dasturlaridan biri
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Amalga oshirilmagan kodni "not implemented" xabari bilan vahima bosish orqali ko'rsatadi.
///
/// Bu sizning kodingizni yozishni tekshirishga imkon beradi, bu siz trait prototipini yaratishda yoki amalga oshirishda foydalidir, bu sizning barchangizni ishlatishni rejalashtirmaydigan bir nechta usullarni talab qiladi.
///
/// `unimplemented!` va [`todo!`] o'rtasidagi farq shundan iboratki, agar `todo!` funktsiyani keyinchalik amalga oshirish niyatini bildirsa va xabar "not yet implemented" bo'lsa, `unimplemented!` bunday da'volarni ilgari surmaydi.
/// Uning xabari "not implemented".
/// Shuningdek, ba'zi IDElar "todo!" Belgisini qo'yadilar.
///
/// # Panics
///
/// Bu har doim [`panic!`] bo'ladi, chunki `unimplemented!` `panic!` uchun faqat stsenariy bo'lib, aniq, aniq xabarga ega.
///
/// `panic!` singari, ushbu so'lda ham maxsus qiymatlarni ko'rsatish uchun ikkinchi shakl mavjud.
///
/// # Examples
///
/// Bizda trait `Foo` bor deb ayting:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Biz 'MyStruct' uchun `Foo`-ni amalga oshirishni xohlaymiz, ammo ba'zi sabablarga ko'ra `bar()` funktsiyasini bajarish mantiqan to'g'ri keladi.
/// `baz()` va `qux()` hali ham `Foo` ni amalga oshirishda aniqlanishi kerak, ammo biz kodimizni kompilyatsiya qilish uchun `unimplemented!` ni ularning ta'riflarida ishlatishimiz mumkin.
///
/// Amalga oshirilmagan usullarga erishilsa, biz hali ham dasturimizni to'xtatishni xohlaymiz.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` ning `MyStruct` uchun ma'nosi yo'q, shuning uchun bu erda bizda umuman mantiq yo'q.
/////
///         // Bu "thread 'main' panicked at 'not implemented'"-ni namoyish etadi.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Bu erda bizda mantiq bor, amalga oshirilmaganlarga xabar qo'shishimiz mumkin!etishmovchiligimizni ko'rsatish uchun.
///         // Bu quyidagilarni namoyish etadi: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Tugallanmagan kodni bildiradi.
///
/// Agar siz prototip yaratayotgan bo'lsangiz va kodingizni matn terish usulini tekshirmoqchi bo'lsangiz, bu sizga foydali bo'lishi mumkin.
///
/// [`unimplemented!`] va `todo!` o'rtasidagi farq shundan iboratki, agar `todo!` funktsiyani keyinchalik amalga oshirish niyatini bildirsa va xabar "not yet implemented" bo'lsa, `unimplemented!` bunday da'volarni ilgari surmaydi.
/// Uning xabari "not implemented".
/// Shuningdek, ba'zi IDElar "todo!" Belgisini qo'yadilar.
///
/// # Panics
///
/// Bu har doim [`panic!`] bo'ladi.
///
/// # Examples
///
/// Bu erda ba'zi bir bajarilayotgan kodlarga misol keltirilgan.Bizda trait `Foo` mavjud:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Biz `Foo`-ni bizning turlarimizdan birida amalga oshirishni xohlaymiz, lekin bundan oldin faqat `bar()` ustida ishlashni xohlaymiz.Bizning kodni kompilyatsiya qilish uchun biz `baz()` ni qo'llashimiz kerak, shuning uchun biz `todo!` dan foydalanishimiz mumkin:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // amalga oshirish bu erda
///     }
///
///     fn baz(&self) {
///         // hozircha baz() dasturini amalga oshirish haqida tashvishlanmaylik
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // biz hatto baz() dan foydalanmayapmiz, shuning uchun bu yaxshi.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// O'rnatilgan makrolarning ta'riflari.
///
/// Ibratli xususiyatlarning aksariyati (barqarorlik, ko'rinadigan va boshqalar) bu erda manba kodidan olinadi, agar kengayish funktsiyalari bundan mustasno, makro kirishni natijaga aylantirsa, bu funktsiyalar kompilyator tomonidan ta'minlanadi.
///
///
pub(crate) mod builtin {

    /// Uchrashganda, berilgan xato xabari bilan kompilyatsiya ishlamay qolishiga olib keladi.
    ///
    /// Ushbu so'lni crate shartli kompilyatsiya strategiyasidan foydalangan holda xato holatlar uchun yaxshiroq xato xabarlarini taqdim etish uchun ishlatilishi kerak.
    ///
    /// Bu [`panic!`] kompilyator darajasidagi shakli, ammo *ish vaqti* emas, balki *kompilyatsiya* paytida xatolik yuzaga keladi.
    ///
    /// # Examples
    ///
    /// Ikkita shunday misollar makro va `#[cfg]` muhitidir.
    ///
    /// Agar so'l yaroqsiz qiymatga o'tkazilsa, yaxshiroq kompilyator xatosini chiqaring.
    /// Yakuniy branch bo'lmasa, kompilyator xatoga yo'l qo'yishi mumkin edi, ammo xato xabari ikkita haqiqiy qiymatni eslatmaydi.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Agar bir qator funktsiyalardan biri mavjud bo'lmasa, kompilyator xatosini chiqaring.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Boshqa satrlarni formatlash makroslari uchun parametrlarni tuzadi.
    ///
    /// Ushbu so'l har bir qo'shimcha argument uchun `{}` ni o'z ichiga olgan formatlash satrini qabul qilish orqali ishlaydi.
    /// `format_args!` chiqishni mag'lubiyat sifatida talqin qilinishini ta'minlash uchun qo'shimcha parametrlarni tayyorlaydi va argumentlarni bitta turga kanoniklashtiradi.
    /// [`Display`] trait-ni amalga oshiradigan har qanday qiymat `format_args!`-ga o'tkazilishi mumkin, shuningdek, [`Debug`]-ning har qanday bajarilishi formatlash satrida `{:?}`-ga o'tkazilishi mumkin.
    ///
    ///
    /// Ushbu so'l [`fmt::Arguments`] turini ishlab chiqaradi.Ushbu qiymat foydali yo'naltirishni amalga oshirish uchun [`std::fmt`] ichidagi makrolarga uzatilishi mumkin.
    /// Qolgan barcha formatlash makroslari (["format!"], [`write!`], [`println!`] va boshqalar) shu orqali proksi qilinadi.
    /// `format_args!`, uning makroslaridan farqli o'laroq, uyumlarni ajratishdan qochadi.
    ///
    /// Siz `format_args!` ning `Debug` va `Display` kontekstida qaytaradigan [`fmt::Arguments`] qiymatini quyida ko'rsatilganidan foydalanishingiz mumkin.
    /// Masalan, `Debug` va `Display` formatlari xuddi shu narsaga o'xshashligini ko'rsatadi: `format_args!`-da interpolatsiyalangan format qatori.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Qo'shimcha ma'lumot olish uchun [`std::fmt`]-dagi hujjatlarni ko'ring.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` bilan bir xil, ammo oxirida yangi qator qo'shiladi.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Kompilyatsiya vaqtida atrof-muhit o'zgaruvchisini tekshiradi.
    ///
    /// Ushbu so'l kompilyatsiya vaqtida nomlangan muhit o'zgaruvchisi qiymatiga qadar kengayadi va `&'static str` turidagi ifodani beradi.
    ///
    ///
    /// Agar atrof-muhit o'zgaruvchisi aniqlanmagan bo'lsa, unda kompilyatsiya xatosi chiqariladi.
    /// Kompilyatsiya xatosini chiqarmaslik uchun uning o'rniga [`option_env!`] so'lidan foydalaning.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Ikkinchi parametr sifatida mag'lubiyatni yuborib, xato haqidagi xabarni sozlashingiz mumkin:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Agar `documentation` muhit o'zgaruvchisi aniqlanmasa, siz quyidagi xatoga yo'l qo'yasiz:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ixtiyoriy ravishda kompilyatsiya vaqtida muhit o'zgaruvchisini tekshiradi.
    ///
    /// Agar nomlangan muhit o'zgaruvchisi kompilyatsiya vaqtida mavjud bo'lsa, bu `Option<&'static str>` tipidagi ifodaga kengayadi, uning qiymati atrof-muhit o'zgaruvchisi qiymatining `Some` ga teng.
    /// Agar muhit o'zgaruvchisi mavjud bo'lmasa, u holda `None` kengaytiriladi.
    /// Ushbu turdagi qo'shimcha ma'lumot uchun [`Option<T>`][Option]-ga qarang.
    ///
    /// Ushbu so'ldan foydalanganda atrof-muhit o'zgaruvchisi mavjud bo'lishidan qat'i nazar, kompilyatsiya vaqtidagi xato hech qachon chiqmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Identifikatorlarni bitta identifikatorga birlashtiradi.
    ///
    /// Ushbu so'l har qanday vergul bilan ajratilgan identifikatorlarni oladi va ularning barchasini birlashtirgan holda yangi identifikator bo'lgan ifodani beradi.
    /// E'tibor bering, gigiena ushbu so'l mahalliy o'zgaruvchilarni qamrab ololmaydigan darajada qiladi.
    /// Bundan tashqari, odatda, makrolarga faqat element, bayonot yoki ifoda holatida ruxsat beriladi.
    /// Demak, ushbu so'lni mavjud o'zgaruvchilar, funktsiyalar yoki modullarga murojaat qilish uchun ishlatishingiz mumkin, ammo siz u bilan yangisini aniqlay olmaysiz.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (yangi, qiziqarli, ism) { }//bu tarzda foydalanishga yaroqsiz!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Metalllarni statik chiziqli bo'lakka birlashtiradi.
    ///
    /// Ushbu so'l vergul bilan ajratilgan istalgan sonli harflarni oladi va `&'static str` turidagi ifodani beradi, bu chapdan o'ngga biriktirilgan barcha harflarni ifodalaydi.
    ///
    ///
    /// Butun sonli va suzuvchi nuqta harflari birlashtirilishi uchun torlanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// U chaqirilgan qator raqamiga kengaytiriladi.
    ///
    /// [`column!`] va [`file!`] bilan ushbu makrolar ishlab chiquvchilar uchun manba ichidagi joylashuvi to'g'risida disk raskadrovka ma'lumotlarini taqdim etadi.
    ///
    /// Kengaytirilgan ifoda `u32` turiga ega va 1 ga asoslangan, shuning uchun har bir fayldagi birinchi satr 1 ga, ikkinchisi 2 ga va hokazolarga baholanadi.
    /// Bu umumiy kompilyatorlar yoki mashhur muharrirlarning xato xabarlari bilan mos keladi.
    /// Qaytgan satr *shartli ravishda*`line!` chaqiruvining o'zi emas, balki `line!` so'lini chaqirishga olib boradigan birinchi so'l chaqiruvdir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// U chaqirilgan ustun raqamiga kengaytiriladi.
    ///
    /// [`line!`] va [`file!`] bilan ushbu makrolar ishlab chiquvchilar uchun manba ichidagi joylashuvi to'g'risida disk raskadrovka ma'lumotlarini taqdim etadi.
    ///
    /// Kengaytirilgan ifoda `u32` turiga ega va 1 asosga ega, shuning uchun har bir satrda birinchi ustun 1 ga, ikkinchisiga 2 ga va hokazolarni baholaydi.
    /// Bu umumiy kompilyatorlar yoki mashhur muharrirlarning xato xabarlari bilan mos keladi.
    /// Qaytgan ustun *`column!` chaqiruvining o'zi* emas, balki `column!` so'lini chaqirishga olib boradigan birinchi so'l chaqiruvidir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// U chaqirilgan fayl nomini kengaytiradi.
    ///
    /// [`line!`] va [`column!`] bilan ushbu makrolar ishlab chiquvchilar uchun manba ichidagi joylashuvi to'g'risida disk raskadrovka ma'lumotlarini taqdim etadi.
    ///
    /// Kengaytirilgan ifoda `&'static str` turiga ega va qaytarilgan fayl `file!` makrosining o'zi emas, aksincha `file!` makrosini chaqirishga olib boradigan birinchi so'l chaqiruvidir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Uning dalillarini belgilaydi.
    ///
    /// Ushbu so'l makroga o'tgan barcha tokens-ning stringifikatsiyasi bo'lgan `&'static str` tipidagi ifodani beradi.
    /// Ibratli chaqiruvning o'zi sintaksisiga cheklovlar qo'yilmaydi.
    ///
    /// tokens kirishining kengaytirilgan natijalari future da o'zgarishi mumkinligini unutmang.Agar siz chiqishga ishonsangiz ehtiyot bo'lishingiz kerak.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Satr sifatida UTF-8 kodlangan faylni o'z ichiga oladi.
    ///
    /// Fayl joriy faylga nisbatan joylashgan (modullarning topilishiga o'xshash).
    /// Taqdim etilgan yo'l kompilyatsiya vaqtida platformaga xos tarzda sharhlanadi.
    /// Masalan, `\` teskari burilishlarini o'z ichiga olgan Windows yo'li bilan chaqiruv Unix da to'g'ri kompilyatsiya qilinmaydi.
    ///
    ///
    /// Ushbu so'l faylning mazmuni bo'lgan `&'static str` turini ifodalaydi.
    ///
    /// # Examples
    ///
    /// Xuddi shu katalogda quyidagi fayllar bilan ikkita fayl mavjud deb taxmin qiling:
    ///
    /// 'spanish.in' fayli:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' fayli:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs'-ni kompilyatsiya qilish va natijada olingan ikkilikni ishga tushirish "adiós"-ni chiqaradi.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Faylni baytlar qatoriga havola sifatida o'z ichiga oladi.
    ///
    /// Fayl joriy faylga nisbatan joylashgan (modullarning topilishiga o'xshash).
    /// Taqdim etilgan yo'l kompilyatsiya vaqtida platformaga xos tarzda sharhlanadi.
    /// Masalan, `\` teskari burilishlarini o'z ichiga olgan Windows yo'li bilan chaqiruv Unix da to'g'ri kompilyatsiya qilinmaydi.
    ///
    ///
    /// Ushbu so'l faylning mazmuni bo'lgan `&'static [u8; N]` turini ifodalaydi.
    ///
    /// # Examples
    ///
    /// Xuddi shu katalogda quyidagi fayllar bilan ikkita fayl mavjud deb taxmin qiling:
    ///
    /// 'spanish.in' fayli:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' fayli:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs'-ni kompilyatsiya qilish va natijada olingan ikkilikni ishga tushirish "adiós"-ni chiqaradi.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Joriy modul yo'lini ifodalovchi qatorga kengayadi.
    ///
    /// Amaldagi modul yo'lini crate root ga qaytadigan modullar iyerarxiyasi deb hisoblash mumkin.
    /// Qaytgan yo'lning birinchi komponenti hozirda tuzilayotgan crate nomi.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Kompilyatsiya vaqtida konfiguratsiya bayroqlarining mantiqiy kombinatsiyalarini baholaydi.
    ///
    /// `#[cfg]` atributidan tashqari, ushbu so'l konfiguratsiya bayroqlarini mantiqiy ifodalashni baholash uchun taqdim etiladi.
    /// Bu tez-tez kamroq takrorlanadigan kodga olib keladi.
    ///
    /// Ushbu so'lga berilgan sintaksis [`cfg`] atributi bilan bir xil sintaksisdir.
    ///
    /// `cfg!`, `#[cfg]`-dan farqli o'laroq, hech qanday kodni o'chirmaydi va faqat true yoki false qiymatiga baho beradi.
    /// Masalan, if/else ifodasidagi barcha bloklar, `cfg!` qanday baho berishidan qat'iy nazar, shart uchun `cfg!` ishlatilganda haqiqiy bo'lishi kerak.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Faylni ifoda yoki kontekstga muvofiq element sifatida ajratadi.
    ///
    /// Fayl joriy faylga nisbatan joylashgan (modullarning topilishiga o'xshash).Taqdim etilgan yo'l kompilyatsiya vaqtida platformaga xos tarzda sharhlanadi.
    /// Masalan, `\` teskari burilishlarini o'z ichiga olgan Windows yo'li bilan chaqiruv Unix da to'g'ri kompilyatsiya qilinmaydi.
    ///
    /// Ushbu so'lni ishlatish ko'pincha yomon fikrdir, chunki agar fayl ifoda sifatida ajratilgan bo'lsa, u atrofdagi gigienik kodga joylashtiriladi.
    /// Buning natijasida o'zgaruvchilar yoki funktsiyalar, agar faylda bir xil nomdagi o'zgaruvchilar yoki funktsiyalar mavjud bo'lsa, ular fayl kutganidan farq qiladi.
    ///
    ///
    /// # Examples
    ///
    /// Xuddi shu katalogda quyidagi fayllar bilan ikkita fayl mavjud deb taxmin qiling:
    ///
    /// 'monkeys.in' fayli:
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 'main.rs' fayli:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs'-ni kompilyatsiya qilish va natijada olingan ikkilikni ishga tushirish "🙈🙊🙉🙈🙊🙉"-ni chiqaradi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Mantiqiy ifoda ish paytida `true` ekanligini tasdiqlaydi.
    ///
    /// Agar taqdim etilgan ifodani ish vaqtida `true` ga baholash imkoni bo'lmasa, bu [`panic!`] makrosini chaqiradi.
    ///
    /// # Uses
    ///
    /// Tasdiqlashlar har doim disk raskadrovka va versiyalar tuzilishida tekshiriladi va ularni o'chirib bo'lmaydi.
    /// Sukut bo'yicha ishlab chiqarishda yoqilmagan tasdiqlarni [`debug_assert!`]-ga qarang.
    ///
    /// Xavfsiz kod ish vaqti o'zgarmasligini ta'minlash uchun `assert!`-ga ishonishi mumkin, agar buzilgan bo'lsa, bu xavfsizlikka olib kelishi mumkin.
    ///
    /// `assert!`-ning boshqa holatlariga, ish vaqtidagi o'zgaruvchanlarni xavfsiz kodda sinovdan o'tkazish va ularni kiritish kiradi (ularning buzilishi xavfsizlikka olib kelmaydi).
    ///
    ///
    /// # Maxsus xabarlar
    ///
    /// Ushbu so'lning ikkinchi shakli mavjud, bu erda maxsus panic xabarini formatlash uchun argumentlar bilan yoki argumentlarsiz ta'minlash mumkin.
    /// Ushbu shakl uchun sintaksis uchun [`std::fmt`]-ga qarang.
    /// Format argumenti sifatida ishlatilgan iboralar, agar tasdiq bajarilmasa, baholanadi.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ushbu tasdiqlar uchun panic xabari berilgan ifodaning satrlangan qiymati.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // juda oddiy funktsiya
    ///
    /// assert!(some_computation());
    ///
    /// // maxsus xabar bilan tasdiqlang
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Ichki yig'ish.
    ///
    /// Foydalanish uchun [unstable book]-ni o'qing.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM uslubidagi ichki yig'ilish.
    ///
    /// Foydalanish uchun [unstable book]-ni o'qing.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Modul darajasida ichki yig'ish.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Bosib chiqarishlar tokens-ni standart chiqishga o'tkazdi.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Boshqa makrolarni disk raskadrovka qilish uchun ishlatiladigan kuzatuv funksiyasini yoqadi yoki o'chiradi.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Derivativ makroslarni qo'llash uchun ishlatiladigan atribut makrosi.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Funksiyani birlik sinoviga aylantirish uchun qo'llaniladigan atribut so'l.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Funktsiyani benchmark testiga aylantirish uchun qo'llaniladigan atribut makrosi.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` va `#[bench]` makroslarini amalga oshirish tafsilotlari.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Atribut makrosi uni global ajratuvchi sifatida ro'yxatdan o'tkazish uchun statikka qo'llaniladi.
    ///
    /// Shuningdek, [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html)-ga qarang.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// O'tkazilgan yo'lga kirish imkoni bo'lsa, qo'llaniladigan elementni saqlaydi va aks holda uni olib tashlaydi.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Qo'llaniladigan kod qismidagi barcha `#[cfg]` va `#[cfg_attr]` atributlarini kengaytiradi.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` kompilyatorining beqaror bajarilish tafsilotlari, foydalanmang.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` kompilyatorining beqaror bajarilish tafsilotlari, foydalanmang.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}