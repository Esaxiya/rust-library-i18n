# `rustc-std-workspace-core` crate

Ushbu crate shunchaki `libcore` ga bog'liq bo'lgan va uning tarkibidagi barcha narsalarni qayta eksport qiladigan shim va bo'sh crate.
crate standart kutubxonani crates.io dan crates ga bog'liqligini kuchaytirishning asosidir.

Standart kutubxona bog'liq bo'lgan crates.io-dagi Crates, bo'sh bo'lgan crates.io-dan `rustc-std-workspace-core` crate ga bog'liq bo'lishi kerak.

`[patch]`-ni ushbu omborda ushbu crate-ga almashtirish uchun ishlatamiz.
Natijada, crates.io-dagi crates, ushbu omborda belgilangan versiya bo'lgan edge-ga `libcore`-ga bog'liqlikni keltirib chiqaradi.
Cargo-ning crates-ni muvaffaqiyatli tuzishini ta'minlash uchun barcha bog'liqlik chekkalarini chizish kerak!

Hammasi to'g'ri ishlashi uchun crates.io-dagi crates ushbu crate-ga `core` nomi bilan bog'liq bo'lishi kerakligini unutmang.Buning uchun ular quyidagilarni qo'llashlari mumkin:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` tugmasi yordamida crate nomi `core` ga o'zgartirildi, ya'ni u o'xshash bo'ladi

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

qachon Cargo kompilyatorni chaqirganda, kompilyator tomonidan AOK qilingan yashirin `extern crate core` direktivasini qondiradi.




