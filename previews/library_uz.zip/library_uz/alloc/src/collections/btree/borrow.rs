use core::marker::PhantomData;
use core::ptr::NonNull;

/// Qayta tiklanish va uning barcha avlodlari (ya'ni, undan olingan barcha ko'rsatgichlar va havolalar) endi biron bir vaqtda ishlatilmasligini bilganingizda, ba'zi bir noyob ma'lumotnomalarni qayta tiklashni modellashtiradi, shundan so'ng siz asl noyob ma'lumotnomani yana ishlatmoqchisiz .
///
///
/// Qarz tekshiruvchisi odatda siz uchun qarzlarni stacking bilan shug'ullanadi, ammo bu stackingni bajaradigan ba'zi boshqaruv oqimlari kompilyatorga amal qilish uchun juda murakkab.
/// `DormantMutRef` o'zingizni qarz olishni tekshirishga imkon beradi, shu bilan birga uning mohiyatini ifodalaydi va buni amalga oshirish uchun zarur bo'lgan xom ko'rsatgich kodini aniqlanmagan xatti-harakatlarsiz qamrab oladi.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Noyob qarzni oling va darhol uni qayta tiklang.
    /// Tuzuvchi uchun yangi ma'lumotnomaning ishlash muddati asl ma'lumotnomaning ishlash muddati bilan bir xil, ammo siz undan qisqa muddat foydalanish uchun promise.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // XAVFSIZLIK: biz qarzni `_marker` orqali ushlab turamiz va fosh qilamiz
        // faqat ushbu ma'lumotnoma, shuning uchun u noyobdir.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Dastlab olingan noyob qarzga qayting.
    ///
    /// # Safety
    ///
    /// Qayta tiklanish tugagan bo'lishi kerak, ya'ni `new` tomonidan qaytarilgan ma'lumotnoma va undan olingan barcha ko'rsatgichlar va havolalar endi ishlatilmasligi kerak.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // XAVFSIZLIK: bizning xavfsizligimiz shartlari shuni anglatadiki, ushbu ma'lumotnoma yana noyobdir.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;