use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Muayyan voqealarni kuzatib boradigan halokat sinovlari uchun qo'g'irchoq misollar uchun reja.
/// Ba'zi holatlar bir vaqtlar panic-ga sozlanishi mumkin.
/// Voqealar `clone`, `drop` yoki ba'zi bir anonim `query`.
///
/// Crash testi qo'g'irchoqlari identifikator tomonidan aniqlanadi va buyurtma qilinadi, shuning uchun ular BTreeMap-da kalit sifatida ishlatilishi mumkin.
/// Amalga oshirishda qasddan foydalaniladigan `Debug` trait dan tashqari crate da aniqlangan narsalarga ishonilmaydi.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Buzilish testi qo'g'irchoqli dizaynini yaratadi.`id` misollar tartibini va tengligini belgilaydi.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Qanday voqealar sodir bo'lganligini va ixtiyoriy ravishda panics-ni qayd etadigan halokat testi qo'g'irchog'ining nusxasini yaratadi.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Dummy nusxalari necha marta klonlanganligini qaytaradi.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Dummy nusxalari necha marta tushirilganligini qaytaradi.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// `query` a'zosi qancha marta qo'g'irchoqning chaqirilganligini qaytaradi.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Natija allaqachon berilgan ba'zi noma'lum so'rovlar.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}