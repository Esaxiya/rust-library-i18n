// Bu idealga amal qilgan holda amalga oshirishga urinishdir
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust aslida qaram turlarga va polimorfik rekursiyaga ega bo'lmaganligi sababli, biz ko'plab xavfsizlikni ta'minlaymiz.
//

// Ushbu modulning asosiy maqsadi-daraxtni umumiy (agar g'alati shakldagi bo'lsa) idish sifatida ko'rib chiqish va B-Tree invariantlarining aksariyati bilan ishlashdan qochish orqali murakkablikdan qochishdir.
//
// Shunday qilib, ushbu modulda yozuvlar saralanadimi, qaysi tugunlar kam to'la bo'lishi mumkin yoki hatto to'liq emas degani ahamiyatsiz.Biroq, biz bir nechta invariantlarga tayanamiz:
//
// - Daraxtlarda bir xil depth/height bo'lishi kerak.Bu shuni anglatadiki, ma'lum bir tugundan bargga tushadigan har bir yo'l to'liq uzunlikka ega.
// - `n` uzunlikdagi tugunda `n` tugmachalari, `n` qiymatlari va `n + 1` qirralari mavjud.
//   Bu shuni anglatadiki, bo'sh tugunda ham kamida bitta edge mavjud.
//   Barg tuguni uchun "having an edge" faqat tugundagi pozitsiyani aniqlay olamiz degan ma'noni anglatadi, chunki barg qirralari bo'sh va ma'lumotlarning ko'rsatilishiga ehtiyoj qolmaydi.
// Ichki tugunda edge ikkalasi ham pozitsiyani aniqlaydi va bola tuguniga ko'rsatgichni o'z ichiga oladi.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Barg tugunlarining asosiy ko'rinishi va ichki tugunlarning bir qismi.
struct LeafNode<K, V> {
    /// Biz `K` va `V`-da kovariant bo'lishni xohlaymiz.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Ushbu tugunning indeksini ota tugunning `edges` qatoriga kiritish.
    /// `*node.parent.edges[node.parent_idx]` `node` bilan bir xil bo'lishi kerak.
    /// Bu faqat `parent` nolga teng bo'lganda ishga tushirilishi kafolatlanadi.
    parent_idx: MaybeUninit<u16>,

    /// Ushbu tugunni saqlaydigan kalitlar va qiymatlar soni.
    len: u16,

    /// Tugunning haqiqiy ma'lumotlarini saqlaydigan massivlar.
    /// Har bir massivning faqat birinchi `len` elementlari initsializatsiya qilinadi va amal qiladi.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// O'z o'rnida yangi `LeafNode`-ni ishga tushiradi.
    unsafe fn init(this: *mut Self) {
        // Umumiy siyosat sifatida, agar iloji bo'lsa, biz maydonlarni boshlang'ichsiz qoldiramiz, chunki bu Valgrindda biroz tezroq va kuzatib borish osonroq bo'lishi kerak.
        //
        unsafe {
            // parent_idx, tugmachalar va vals-bularning hammasi UseUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Yangi quti `LeafNode` yaratadi.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Ichki tugunlarning asosiy ko'rinishi."LeafNode" da bo'lgani kabi, boshlang'ich tugmachalari va qiymatlarini tashlab qo'ymaslik uchun ularni "BoxedNode" ning orqasida yashirish kerak.
/// `InternalNode` uchun har qanday ko'rsatgich tugunning asosiy `LeafNode` qismiga to'g'ridan-to'g'ri ko'rsatgichga uzatilishi mumkin, bu esa kodning barg va ichki tugunlarda umumiy ravishda harakat qilishiga imkon beradi.
///
/// Ushbu xususiyat `repr(C)` yordamida yoqilgan.
///
#[repr(C)]
// gdb_providers.py introspection uchun ushbu turdagi nomdan foydalanadi.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Ushbu tugunning bolalariga ko'rsatgichlar.
    /// `len + 1` shulardan biri boshlang'ich va haqiqiy deb hisoblanadi, faqat oxirigacha, daraxt `Dying` qarz turi orqali ushlab turilgan bo'lsa, bu ko'rsatkichlarning ba'zilari osilib turadi.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Yangi quti `InternalNode` yaratadi.
    ///
    /// # Safety
    /// Ichki tugunlarning o'zgarmas tomoni shundaki, ular kamida bitta boshlangan va haqiqiy edge ga ega.
    /// Ushbu funktsiya bunday edge-ni o'rnatmaydi.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Biz faqat ma'lumotlarni ishga tushirishimiz kerak;qirralari BəlgayUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Tugunga boshqariladigan, bo'sh bo'lmagan ko'rsatkich.Bu `LeafNode<K, V>`-ga tegishli bo'lgan yoki `InternalNode<K, V>`-ga tegishli bo'lgan ko'rsatkichdir.
///
/// Shu bilan birga, `BoxedNode`-da u aslida ikkita turdagi tugunlarning qaysi biri haqida ma'lumot mavjud emas va qisman ushbu ma'lumot etishmasligi tufayli alohida turdagi emas va destruktorga ega emas.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Tegishli daraxtning ildiz tuguni.
///
/// E'tibor bering, unda destruktor yo'q va uni qo'lda tozalash kerak.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Dastlab bo'sh bo'lgan o'z ildiz tuguniga ega bo'lgan yangi daraxtni qaytaradi.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` nol bo'lmasligi kerak.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// O'ziga tegishli ildiz tugunini qarzga oladi.
    /// `reborrow_mut`-dan farqli o'laroq, bu xavfsizdir, chunki qaytish qiymati ildizni yo'q qilish uchun ishlatilmaydi va daraxtga boshqa havolalar bo'lishi mumkin emas.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// O'ziga tegishli ildiz tugunini ozgina mutanosib ravishda qarzga oladi.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Qaytishsiz o'tish uchun ruxsat beruvchi va buzg'unchi usullarni taklif qiladigan ma'lumotnomaga o'tadi.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Oldingi ildiz tuguniga ishora qiluvchi bitta edge bilan yangi ichki tugunni qo'shadi, uni yangi tugunni ildiz tuguniga aylantiradi va uni qaytaradi.
    /// Bu balandlikni 1 ga oshiradi va `pop_internal_level` ga teskari bo'ladi.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, bundan tashqari biz hozir ichki ekanligimizni unutganmiz:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Birinchi ildiz tugunini yangi ildiz tuguni sifatida ishlatib, ichki ildiz tugunini olib tashlaydi.
    /// Ildiz tugunida faqat bitta bola bo'lsa, uni chaqirish uchun mo'ljallanganligi sababli, hech qanday tugmachalarda, qiymatlarda va boshqa bolalarda tozalash amalga oshirilmaydi.
    ///
    /// Bu balandlikni 1 ga kamaytiradi va `push_internal_level` ga teskari bo'ladi.
    ///
    /// Ildiz tuguniga emas, balki `Root` ob'ektiga eksklyuziv kirishni talab qiladi;
    /// u boshqa tugmachalarni yoki ildiz tuguniga havolalarni bekor qilmaydi.
    ///
    /// Agar ichki daraja bo'lmasa, ya'ni ildiz tuguni barg bo'lsa, Panics.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // XAVFSIZLIK: biz ichki ekanligimizni ta'kidladik.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // XAVFSIZLIK: biz `self`-ni faqat qarz oldik va uning qarz turi eksklyuzivdir.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // XAVFSIZLIK: birinchi edge har doim ishga tushiriladi.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` har doim `K` va `V`-da, hatto `BorrowType` `Mut` bo'lsa ham, o'zgaruvchan bo'ladi.
// Bu texnik jihatdan noto'g'ri, ammo `NodeRef` ichki ishlatilishi sababli hech qanday xavfsizlikni keltirib chiqara olmaydi, chunki biz `K` va `V` orqali umuman umumiy bo'lib qolamiz.
//
// Biroq, har qanday ommaviy turdagi `NodeRef` o'ralgan bo'lsa, uning to'g'ri dispersiyasiga ega ekanligiga ishonch hosil qiling.
//
/// Tugunga havola.
///
/// Ushbu turdagi ishlashini boshqaradigan bir qator parametrlarga ega:
/// - `BorrowType`: Qarz turini tavsiflovchi va umr bo'yi olib boradigan qo'g'irchoq turi.
///    - Agar bu `Immut<'a>` bo'lsa, `NodeRef` taxminan `&'a Node` kabi ishlaydi.
///    - Agar bu `ValMut<'a>` bo'lsa, `NodeRef` kalitlarga va daraxt tuzilishiga nisbatan taxminan `&'a Node` kabi ishlaydi, shuningdek, daraxt bo'ylab qiymatlarga ko'plab o'zgaruvchan mos yozuvlar mavjud bo'lishiga imkon beradi.
///    - Agar bu `Mut<'a>` bo'lsa, `NodeRef` taxminan `&'a mut Node` kabi ishlaydi, garchi insert usullari o'zgaruvchan ko'rsatkichni qiymatni birga bo'lishiga imkon beradi.
///    - Agar bu `Owned` bo'lsa, `NodeRef` taxminan `Box<Node>` kabi ishlaydi, lekin destruktorga ega emas va uni qo'lda tozalash kerak.
///    - Agar bu `Dying` bo'lsa, `NodeRef` hanuzgacha `Box<Node>` kabi ishlaydi, lekin daraxtni oz-ozidan yo'q qilish usullari mavjud va oddiy usullar qo'ng'iroq qilish xavfli deb belgilanmagan bo'lsa ham, noto'g'ri chaqirilsa UB-ni chaqirishi mumkin.
///
///   Har qanday `NodeRef` daraxt bo'ylab harakatlanishiga imkon berganligi sababli, `BorrowType` tugunning o'zi uchun emas, balki butun daraxt uchun samarali qo'llaniladi.
/// - `K` va `V`: Bu tugunlarda saqlanadigan kalit va qiymatlarning turlari.
/// - `Type`: Bu `Leaf`, `Internal` yoki `LeafOrInternal` bo'lishi mumkin.
/// Agar bu `Leaf` bo'lsa, `NodeRef` barg tuguniga, `Internal` bo'lganda `NodeRef` ichki tugunga ishora qiladi va agar `LeafOrInternal` bo'lsa, `NodeRef` har qanday tugun turiga ishora qilishi mumkin.
///   `Type` `NodeRef` tashqarisida ishlatilganda `NodeType` deb nomlanadi.
///
/// `BorrowType` va `NodeType` ikkalasi ham statik turdagi xavfsizlikni ishlatish uchun qanday usullarni qo'llayotganimizni cheklaydi.Bunday cheklovlarni qo'llashda cheklovlar mavjud:
/// - Har bir turdagi parametr uchun biz faqat umumiy yoki ma'lum bir turdagi usulni aniqlay olamiz.
/// Masalan, biz `into_kv` kabi usulni barcha `BorrowType` uchun umumiy ravishda yoki butun umrni olib yuradigan barcha turlari uchun bir marta aniqlay olmaymiz, chunki `&'a` ma'lumotlarini qaytarishini xohlaymiz.
///   Shuning uchun biz uni faqat eng kam quvvatli `Immut<'a>` turi uchun aniqlaymiz.
/// - Biz `Mut<'a>` dan `Immut<'a>` gacha yashirin majburlashni ololmaymiz.
///   Shuning uchun, `into_kv` kabi usulga erishish uchun biz `reborrow` ni yanada kuchli `NodeRef` da chaqirishimiz kerak.
///
/// `NodeRef`-da ba'zi bir ma'lumotnomalarni qaytaradigan barcha usullar:
/// - `self`-ni qiymati bo'yicha oling va `BorrowType` tomonidan olib borilgan umrini qaytaring.
///   Ba'zan, bunday usulni qo'llash uchun biz `reborrow_mut` raqamiga qo'ng'iroq qilishimiz kerak.
/// - `self`-ni mos yozuvlar bilan oling va (implicitly) `BorrowType` tomonidan olib boriladigan umr o'rniga, ushbu ma'lumotnomaning umrini qaytaradi.
/// Shunday qilib, qarz tekshiruvchisi qaytarilgan ma'lumotdan foydalanilganda `NodeRef`-ning qarz olishiga kafolat beradi.
///   Insert-ni qo'llab-quvvatlovchi usullar, bu qoidani xom ko'rsatgichni, ya'ni umr bo'yi qaytarib qaytaradi.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Tugun va barglar sathi bir-biridan ajralib turadigan darajalar soni, bu `Type` tomonidan to'liq ta'riflanmaydigan tugunning doimiyligi va tugunning o'zi saqlamaydi.
    /// Biz faqat ildiz tugunining balandligini saqlashimiz va undan har bir tugunning balandligini olishimiz kerak.
    /// `Type` `Leaf` bo'lsa nolga, `Type` `Internal` bo'lsa nolga teng bo'lishi kerak.
    ///
    ///
    height: usize,
    /// Bargga yoki ichki tugunga ko'rsatgich.
    /// `InternalNode` ta'rifi ko'rsatgich har qanday holatda ham haqiqiyligini ta'minlaydi.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` sifatida to'ldirilgan tugun ma'lumotnomasini echib oling.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ichki tugunning ma'lumotlarini ochib beradi.
    ///
    /// Ushbu tugunga boshqa havolalarni bekor qilmaslik uchun xom ptrni qaytaradi.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // XAVFSIZLIK: statik tugun turi `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ichki tugunning ma'lumotlariga eksklyuziv kirishni qarz oladi.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Tugunning uzunligini topadi.Bu tugmalar yoki qiymatlar soni.
    /// Qirralarning soni `len() + 1`.
    /// Xavfsiz bo'lishiga qaramay, ushbu funktsiyani chaqirish xavfli kod yaratgan o'zgaruvchan havolalarni bekor qilishning yon ta'siriga ega bo'lishi mumkinligini unutmang.
    ///
    pub fn len(&self) -> usize {
        // Muhimi, biz bu erda faqat `len` maydoniga kiramiz.
        // Agar BorrowType marker::ValMut bo'lsa, biz bekor qilmasligimiz kerak bo'lgan qiymatlarga ajoyib o'zgaruvchan havolalar bo'lishi mumkin.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Tugun va barglar bir-biridan ajratilgan darajalar sonini qaytaradi.
    /// Nol balandligi tugunning o'zi barg ekanligini anglatadi.
    /// Agar siz tepada ildizi bo'lgan daraxtlarni tasavvur qilsangiz, raqam tugun qaysi balandlikda paydo bo'lishini bildiradi.
    /// Agar siz tepada barglari bo'lgan daraxtlarni tasavvur qilsangiz, raqam daraxtning tugun ustida qanchalik balandligini bildiradi.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Vaqtincha o'sha tugunga boshqa, o'zgarmas havolani chiqaradi.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Har qanday barg yoki ichki tugunning barg qismini ochib beradi.
    ///
    /// Ushbu tugunga boshqa havolalarni bekor qilmaslik uchun xom ptrni qaytaradi.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Tugun hech bo'lmaganda LeafNode qismi uchun amal qilishi kerak.
        // Bu NodeRef turidagi ma'lumotnoma emas, chunki u noyob yoki umumiy bo'lishi kerakligini bilmaymiz.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Joriy tugunning ota-onasini topadi.
    /// Agar joriy tugun aslida ota-onaga ega bo'lsa, `Ok(handle)`-ni qaytaradi, bu erda `handle` ota-onaning edge-ni joriy tugunga ishora qiladi.
    ///
    /// Agar hozirgi tugunda ota-ona bo'lmasa, asl `NodeRef`-ni qaytarib beradigan bo'lsa, `Err(self)`-ni qaytaradi.
    ///
    /// Usul nomi sizning tepangizda ildiz tuguni bo'lgan daraxtlarni tasvirlashingizni taxmin qiladi.
    ///
    /// `edge.descend().ascend().unwrap()` va `node.ascend().unwrap().descend()` ikkalasi ham muvaffaqiyatga erishgandan keyin hech narsa qilmasligi kerak.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Biz tugunlarga xom ko'rsatgichlardan foydalanishimiz kerak, chunki agar BorrowType marker::ValMut bo'lsa, biz bekor qilmasligimiz kerak bo'lgan qiymatlarga nisbatan o'zgaruvchan mos yozuvlar bo'lishi mumkin.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` bo'sh bo'lishi kerakligiga e'tibor bering.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` bo'sh bo'lishi kerakligiga e'tibor bering.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// O'zgarmas daraxtda har qanday barg yoki ichki tugunning barg qismini ochib beradi.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // XAVFSIZLIK: `Immut` sifatida olingan ushbu daraxtga o'zgartirishlar kiritilishi mumkin emas.
        unsafe { &*ptr }
    }

    /// Tugunda saqlangan tugmachalarga ko'rinishni qarz beradi.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend`-ga o'xshash, tugunning ota tuguniga havola oladi, shuningdek, jarayondagi joriy tugunni taqsimlaydi.
    /// Bu xavfli emas, chunki ajratilganiga qaramay, hozirgi tugunga kirish mumkin bo'ladi.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Xavfsiz ravishda kompilyatorga ushbu tugun `Leaf` ekanligi haqidagi statik ma'lumotni tasdiqlaydi.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Xavfsiz ravishda kompilyatorga ushbu tugun `Internal` ekanligi to'g'risida statik ma'lumot beriladi.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Vaqtincha o'sha tugunga boshqa, o'zgarishi mumkin bo'lgan ma'lumotnomani chiqaradi.Ehtiyot bo'ling, chunki bu usul juda xavfli, ikki baravar ko'p, chunki u darhol xavfli bo'lib ko'rinmasligi mumkin.
    ///
    /// O'zgaruvchan ko'rsatkichlar daraxt atrofida har qanday joyda yurishi mumkinligi sababli, qaytarilgan ko'rsatgich yordamida osongina asl ko'rsatkichni osilgan, chegaradan tashqarida yoki biriktirilgan qarz olish qoidalari bo'yicha yaroqsiz holga keltirish mumkin.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) qayta tiklangan ko'rsatgichlarda navigatsiya usullaridan foydalanishni cheklaydigan `NodeRef`-ga yana bir turdagi parametrlarni qo'shishni o'ylab ko'ring, bu xavfsizlikni oldini oladi.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Har qanday barg yoki ichki tugunning barg qismiga eksklyuziv kirishni qarz oladi.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // XAVFSIZLIK: biz butun tugunga eksklyuziv kirish imkoniyatiga egamiz.
        unsafe { &mut *ptr }
    }

    /// Har qanday barg yoki ichki tugunning barg qismiga eksklyuziv kirishni taklif qiladi.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // XAVFSIZLIK: biz butun tugunga eksklyuziv kirish imkoniyatiga egamiz.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Kalit saqlash maydonining elementiga eksklyuziv kirishni qarz oladi.
    ///
    /// # Safety
    /// `index` 0. .IQTISODIY chegarada
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi o'z-o'zidan qo'shimcha usullarni chaqira olmaydi
        // asosiy tilim ma'lumotnomasi tushguncha, chunki biz qarz olish muddati davomida noyob imkoniyatga egamiz.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Tugun qiymatini saqlash maydonining elementi yoki bo'lagiga eksklyuziv kirishni qarz oladi.
    ///
    /// # Safety
    /// `index` 0. .IQTISODIY chegarada
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi o'z-o'zidan qo'shimcha usullarni chaqira olmaydi
        // qarz muddati davomida noyob kirish huquqiga ega bo'lganimiz sababli, qiymat tilimiga mos yozuvlar tushguncha.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge tarkibi uchun tugunni saqlash maydonining elementi yoki bo'lagiga eksklyuziv kirish huquqini oladi.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY + 1 chegaralarida
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi o'z-o'zidan qo'shimcha usullarni chaqira olmaydi
        // edge tilim ma'lumotnomasi tashlanmaguncha, chunki biz qarz olish muddati davomida noyob imkoniyatga egamiz.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Tugun `idx` dan ortiq boshlangan elementlarga ega.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Boshqa elementlarga, xususan, avvalgi takrorlashda qo'ng'iroq qiluvchiga qaytarilgan narsalarga ajoyib havolalar bilan nom berishdan saqlanish uchun biz faqat bitta elementga havola yaratamiz.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust #74679 muammosi tufayli biz o'lchamagan qator ko'rsatkichlariga majbur qilishimiz kerak.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Tugun uzunligiga eksklyuziv kirishni qarz oladi.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Tugunning boshqa havolalarini bekor qilmasdan tugunning havolasini ota-ona edge-ga o'rnatadi.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Ildizning ota-ona edge bilan bog'lanishini tozalaydi.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Tugun oxiriga kalit-qiymat juftligini qo'shadi.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` tomonidan qaytarilgan har bir element tugun uchun haqiqiy edge indeksidir.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Kalit-qiymat juftligini qo'shadi va edge tugmachaning oxirigacha shu juftlikning o'ng tomoniga o'ting.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Tugun `Internal` tugunmi yoki `Leaf` tugunmi yoki yo'qligini tekshiradi.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Tugun ichidagi ma'lum bir kalit-qiymat juftligiga yoki edge-ga havola.
/// `Node` parametri `NodeRef` bo'lishi kerak, `Type` esa `KV` (kalit-qiymat juftidagi dastani bildiruvchi) yoki `Edge` (edge dagi dastani bildiruvchi) bo'lishi mumkin.
///
/// E'tibor bering, hatto `Leaf` tugunlarida ham `Edge` tutqichlari bo'lishi mumkin.
/// Farzand tuguniga ko'rsatgichni ko'rsatish o'rniga, ular bolalar ko'rsatkichlari kalit-qiymat juftlari o'rtasida o'tadigan bo'shliqlarni aks ettiradi.
/// Masalan, uzunligi 2 bo'lgan tugunda uchta mumkin bo'lgan edge joyi bo'lar edi, ulardan biri tugunning chap tomonida, ikkitasi ikkala juft o'rtasida, ikkinchisi tugunning o'ng tomonida.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Bizga `#[derive(Clone)]` ning to'liq umumiyligi kerak emas, chunki `Node` "Clone" bo'lishi mumkin bo'lgan yagona vaqt, bu o'zgarmas mos yozuvlar bo'lganda va shuning uchun `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Ushbu tutqich ko'rsatadigan edge yoki kalit-qiymat juftligini o'z ichiga olgan tugunni oladi.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Ushbu tutqichning tugundagi holatini qaytaradi.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node`-da kalit-qiymat juftligiga yangi dastani yaratadi.
    /// Xavfsiz, chunki qo'ng'iroq qiluvchi `idx < node.len()` ekanligini ta'minlashi kerak.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq-ning ommaviy qo'llanilishi bo'lishi mumkin, lekin faqat ushbu modulda ishlatiladi.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Vaqtincha o'sha joyda boshqa, o'zgarmas tutqichni chiqaradi.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Biz Handle::new_kv yoki Handle::new_edge dan foydalana olmaymiz, chunki biz o'z turimizni bilmaymiz
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Xavfsiz ravishda kompilyatorga tutqich tuguni `Leaf` ekanligi haqidagi statik ma'lumotlarni tasdiqlaydi.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Vaqtincha o'sha joyda boshqa, o'zgarishi mumkin bo'lgan tutqichni chiqaradi.
    /// Ehtiyot bo'ling, chunki bu usul juda xavfli, ikki baravar ko'p, chunki u darhol xavfli bo'lib ko'rinmasligi mumkin.
    ///
    ///
    /// Tafsilotlar uchun `NodeRef::reborrow_mut`-ga qarang.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Biz Handle::new_kv yoki Handle::new_edge dan foydalana olmaymiz, chunki biz o'z turimizni bilmaymiz
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node`-da edge uchun yangi dastani yaratadi.
    /// Xavfsiz, chunki qo'ng'iroq qiluvchi `idx <= node.len()` ekanligini ta'minlashi kerak.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Sig'imga to'ldirilgan tugunga qo'shmoqchi bo'lgan edge indeksini hisobga olgan holda, ajratilgan nuqtaning oqilona KV indeksini va kiritishni qaerda amalga oshirishni hisoblaymiz.
///
/// Bo'linish maqsadi uning kaliti va qiymati ota tugunida tugashidir;
/// bo'linish nuqtasining chap tomonidagi tugmachalar, qiymatlar va qirralar chap bolaga aylanadi;
/// bo'linish nuqtasining o'ng tomonidagi tugmachalar, qiymatlar va qirralar to'g'ri bolaga aylanadi.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust-sonli #74834 ushbu nosimmetrik qoidalarni tushuntirishga harakat qiladi.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ushbu edge-dan o'ngga va chapga kalit-qiymat juftliklari orasiga yangi kalit-qiymat juftligini qo'shadi.
    /// Ushbu usul tugunda yangi juftga mos kelishi uchun etarli joy borligini taxmin qiladi.
    ///
    /// Qaytgan ko'rsatgich kiritilgan qiymatga ishora qiladi.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ushbu edge-dan o'ngga va chapga kalit-qiymat juftliklari orasiga yangi kalit-qiymat juftligini qo'shadi.
    /// Agar etarli joy bo'lmasa, bu usul tugunni ajratadi.
    ///
    /// Qaytgan ko'rsatgich kiritilgan qiymatga ishora qiladi.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ushbu edge ulanadigan bola tugunidagi ota-ona ko'rsatkichi va indeksini tuzatadi.
    /// Bu qirralarning tartibini o'zgartirganda foydalidir,
    fn correct_parent_link(self) {
        // Tugunga boshqa havolalarni bekor qilmasdan orqa ko'rsatkichni yarating.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ushbu edge va ushbu edge ning o'ng tomonidagi kalit-qiymat juftligi orasidagi yangi juftlikning o'ng tomoniga o'tadigan yangi kalit-qiymat juftligini va edge-ni qo'shadi.
    /// Ushbu usul tugunda yangi juftga mos kelishi uchun etarli joy borligini taxmin qiladi.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Ushbu edge va ushbu edge ning o'ng tomonidagi kalit-qiymat juftligi orasidagi yangi juftlikning o'ng tomoniga o'tadigan yangi kalit-qiymat juftligini va edge-ni qo'shadi.
    /// Agar etarli joy bo'lmasa, bu usul tugunni ajratadi.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ushbu edge-dan o'ngga va chapga kalit-qiymat juftliklari orasiga yangi kalit-qiymat juftligini qo'shadi.
    /// Agar bu usul etarli bo'lmasa, tugunni ajratadi va ajratilgan qismni ildiz tugaguniga qadar ota tugunga rekursiv ravishda kiritishga harakat qiladi.
    ///
    ///
    /// Agar qaytarilgan natija `Fit` bo'lsa, uning tugmachasi bu edge tuguni yoki ajdodi bo'lishi mumkin.
    /// Agar qaytarilgan natija `Split` bo'lsa, `left` maydoni ildiz tuguni bo'ladi.
    /// Qaytgan ko'rsatgich kiritilgan qiymatga ishora qiladi.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Ushbu edge tomonidan ko'rsatilgan tugunni topadi.
    ///
    /// Usul nomi sizning tepangizda ildiz tuguni bo'lgan daraxtlarni tasvirlashingizni taxmin qiladi.
    ///
    /// `edge.descend().ascend().unwrap()` va `node.ascend().unwrap().descend()` ikkalasi ham muvaffaqiyatga erishgandan keyin hech narsa qilmasligi kerak.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Biz tugunlarga xom ko'rsatgichlardan foydalanishimiz kerak, chunki agar BorrowType marker::ValMut bo'lsa, biz bekor qilmasligimiz kerak bo'lgan qiymatlarga nisbatan o'zgaruvchan mos yozuvlar bo'lishi mumkin.
        // Balandlik maydoniga kirishda tashvishlanmaslik kerak, chunki bu qiymat ko'chiriladi.
        // E'tibor bering, tugun ko'rsatgichi ajratilgandan so'ng, biz chekka qatoriga mos yozuvlar bilan murojaat qilamiz (Rust-sonli #73987) va massivga yoki uning ichidagi boshqa havolalarni yaroqsiz holga keltiramiz.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Biz alohida kalit va qiymat usullarini chaqira olmaymiz, chunki ikkinchisini chaqirish birinchisi tomonidan qaytarilgan ma'lumotni bekor qiladi.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// KV tutqichiga tegishli bo'lgan kalit va qiymatni almashtiring.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Barg ma'lumotlarini parvarish qilish orqali ma'lum bir `NodeType` uchun `split` dasturlarini amalga oshirishga yordam beradi.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Asosiy tugunni uch qismga ajratadi:
    ///
    /// - Tugun faqat ushbu tutqichning chap tomonidagi kalit-qiymat juftlarini o'z ichiga olgan holda qisqartiriladi.
    /// - Ushbu tutqich tomonidan ko'rsatilgan kalit va qiymat ajratib olinadi.
    /// - Ushbu tutqichning o'ng tomonidagi barcha kalit-qiymat juftliklari yangi ajratilgan tugunga joylashtirilgan.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Ushbu tutqich tomonidan ko'rsatilgan kalit-qiymat juftligini olib tashlaydi va kalit-qiymat juftligi qulab tushgan edge bilan birga qaytaradi.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Asosiy tugunni uch qismga ajratadi:
    ///
    /// - Tugun faqat shu tutqichning chap tomonidagi qirralar va kalit-juft juftliklarini o'z ichiga olishi uchun qisqartiriladi.
    /// - Ushbu tutqich tomonidan ko'rsatilgan kalit va qiymat ajratib olinadi.
    /// - Ushbu tutqichning o'ng tomonidagi barcha qirralar va kalit-qiymat juftliklari yangi ajratilgan tugunga qo'yilgan.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Ichki kalit-qiymat juftligi atrofida muvozanat operatsiyasini baholash va bajarish uchun sessiyani anglatadi.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Bolaligida tugunni o'z ichiga olgan muvozanat kontekstini tanlaydi, shuning uchun KV o'rtasida ota-ona tugunida darhol chapga yoki o'ngga.
    /// Agar ota-ona bo'lmasa, `Err`-ni qaytaradi.
    /// Agar ota-ona bo'sh bo'lsa, Panics.
    ///
    /// Chap tomonni afzal ko'radi, agar berilgan tugun qandaydir darajada kam bo'lsa, demak bu erda faqat chap ukasidan va agar ular mavjud bo'lsa, o'ng ukasidan kamroq elementlar mavjud.
    /// Bunday holda, chap birodar bilan birlashish tezroq bo'ladi, chunki biz faqat tugunning N elementlarini o'ng tomonga siljitish va oldidagi N elementlardan ko'proq harakat qilish o'rniga harakatlantirishimiz kerak.
    /// Chap aka-ukadan o'g'irlash ham tezroq bo'ladi, chunki biz birodarning kamida N elementlarini chapga siljitish o'rniga tugunning N elementlarini o'ngga siljitishimiz kerak.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Birlashtirish mumkinmi, ya'ni markaziy KVni ikkala qo'shni bolalar tugunlari bilan birlashtirish uchun tugunda etarli joy mavjudmi yoki yo'qligini qaytaradi.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Birlashishni amalga oshiradi va yopilishga nima qaytib kelishini hal qiladi.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // XAVFSIZLIK: birlashtirilayotgan tugunlarning balandligi balandlikdan pastroq
                // ushbu edge tugunining noldan yuqori bo'lishi, shuning uchun ular ichki.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Ota-onaning kalit-qiymat juftligini va ikkala qo'shni bola tugunlarini chap tugunga qo'shib, kichraytirilgan ota tugunini qaytaradi.
    ///
    ///
    /// Agar biz `.can_merge()` bo'lmasak, Panics.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Ota-onaning kalit-qiymat juftligini va ikkala qo'shni bola tugunlarini chap tugunga qo'shib, ushbu tugunni qaytaradi.
    ///
    ///
    /// Agar biz `.can_merge()` bo'lmasak, Panics.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Ota-onaning kalit qiymati juftligini va ikkala qo'shni bola tugunlarini chap tugunga qo'shadi va edge kuzatilgan bola tugagan joyda tugmachadagi edge tutqichini qaytaradi,
    ///
    ///
    /// Agar biz `.can_merge()` bo'lmasak, Panics.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Chapdagi boladan kalit-qiymat juftligini olib tashlaydi va uni ota-onaning kalit-xotirasida saqlaydi, shu bilan birga eski ota-ona juftligi uchun kerakli bolani itaradi.
    ///
    /// `track_right_edge_idx` tomonidan ko'rsatilgan asl edge tugagan joyga mos keladigan o'ng bolada edge-ga tutqichni qaytaradi.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Kalit-qiymat juftligini o'ng farzanddan olib tashlaydi va uni ota-onaning kalit-xotirasida saqlaydi, shu bilan birga eski ota-ona juftligi chap farzandiga suradi.
    ///
    /// `track_left_edge_idx` tomonidan belgilangan chap bolada edge-ga dastani qaytaradi, u harakatlanmaydi.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Bu `steal_left` ga o'xshash o'g'irlik qiladi, lekin bir vaqtning o'zida bir nechta elementni o'g'irlaydi.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Xavfsiz o'g'irlashimizga ishonch hosil qiling.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Barg ma'lumotlarini ko'chirish.
            {
                // To'g'ri bolada o'g'irlangan elementlar uchun joy oching.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Elementlarni chap boladan o'ngga siljiting.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Eng ko'p o'g'irlangan juftlikni ota-onaga o'tkazing.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ota-onaning kalit-qiymat juftligini to'g'ri bolaga o'tkazing.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // O'g'irlangan qirralarga joy ajratib bering.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Qirralarini o'g'irlash.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` ning nosimmetrik kloni.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Xavfsiz o'g'irlashimizga ishonch hosil qiling.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Barg ma'lumotlarini ko'chirish.
            {
                // Eng ko'p o'g'irlangan juftlikni ota-onaga o'tkazing.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ota-onaning kalit-qiymat juftligini chap bolaga o'tkazing.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Elementlarni o'ng boladan chapga siljiting.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Ilgari o'g'irlangan elementlar bo'lgan joyni to'ldiring.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Qirralarini o'g'irlash.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Ilgari o'g'irlangan qirralarning bo'sh joyini to'ldiring.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Ushbu tugun `Leaf` tuguni ekanligini tasdiqlovchi har qanday statik ma'lumotlarni olib tashlaydi.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ushbu tugun `Internal` tuguni ekanligini tasdiqlovchi har qanday statik ma'lumotlarni olib tashlaydi.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Asosiy tugun `Internal` tugunmi yoki `Leaf` tugunmi yoki yo'qligini tekshiradi.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` dan keyin qo'shimchani bitta tugundan boshqasiga ko'chiring.`right` bo'sh bo'lishi kerak.
    /// `right` ning birinchi edge qiymati o'zgarishsiz qolmoqda.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Qo'shish natijasi, tugun uning imkoniyatlaridan kattalashishi kerak bo'lganda.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` ning chap qismiga tegishli elementlar va qirralar bilan mavjud daraxtdagi tugunni o'zgartirdi.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Ba'zi bir kalit va qiymatlar boshqa joyga kiritilishi uchun bo'linadi.
    pub kv: (K, V),
    // `kv` o'ng tomoniga tegishli elementlar va qirralar bilan egalik qilingan, biriktirilmagan, yangi tugun.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Ushbu qarz turidagi tugun ma'lumotnomalari daraxtdagi boshqa tugunlarga o'tishga imkon beradimi.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal kerak emas, bu `borrow_mut` natijasi yordamida sodir bo'ladi.
        // O'tkazishni o'chirib qo'yish va faqat ildizlarga yangi havolalar yaratish orqali biz `Owned` turidagi har bir ma'lumot ildiz tuguniga tegishli ekanligini bilamiz.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Boshlangan elementlar bo'lagiga qiymat kiritadi, so'ngra bitta boshlanmagan element.
///
/// # Safety
/// Bo'limda `idx` dan ortiq elementlar mavjud.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Barcha boshlang'ich elementlarning bir qismidan qiymatni olib tashlaydi va orqada bitta boshlang'ich bo'lmagan elementni qoldiradi.
///
///
/// # Safety
/// Bo'limda `idx` dan ortiq elementlar mavjud.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Dilimdagi elementlarni chapga `distance` holatiga o'tkazadi.
///
/// # Safety
/// Dilim kamida `distance` elementlarga ega.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Dilimdagi elementlarni `distance` holatiga o'ng tomonga siljitadi.
///
/// # Safety
/// Dilim kamida `distance` elementlarga ega.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Barcha qadriyatlarni boshlang'ich elementlar bo'linmasidan boshlanmagan elementlar bo'lagiga o'tkazadi va `src`-ni barcha boshlang'ich sifatida qoldiradi.
///
/// `dst.copy_from_slice(src)` kabi ishlaydi, lekin `T` ning `Copy` bo'lishini talab qilmaydi.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;