use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Uchinchi tomon distribyutorlari va `RawVec` o'rtasida integratsiya testini yozish juda qiyin, chunki `RawVec` API-si noto'g'ri ajratish usullarini ko'rsatmaydi, shuning uchun biz ajratuvchi tugagandan keyin nima bo'lishini tekshirib bo'lmaydi (panic ni aniqlashdan tashqari).
    //
    //
    // Buning o'rniga, bu `RawVec` usullari hech bo'lmaganda saqlashni zaxiralashda Allocator API-dan o'tishini tekshiradi.
    //
    //
    //
    //
    //

    // Ajratish urinishlaridan oldin belgilangan miqdordagi yoqilg'ini sarf qiladigan soqov ajratuvchi ishlamay qolmoqda.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (realloc-ni keltirib chiqaradi, shuning uchun 50 + 150=200 birlik yoqilg'idan foydalaniladi)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Birinchidan, `reserve` `reserve_exact` kabi ajratadi.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 7 dan ikki baravar ko'p, shuning uchun `reserve` `reserve_exact` kabi ishlashi kerak.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3-bu 12 ning yarmidan kami, shuning uchun `reserve` muttasil o'sishi kerak.
        // Ushbu testni yozish paytida o'sish koeffitsienti 2 ga teng, shuning uchun yangi quvvat 24 ga teng, ammo 1.5 o'sish koeffitsienti ham yaxshi.
        //
        // Shuning uchun `>= 18` tasdiqlaydi.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}