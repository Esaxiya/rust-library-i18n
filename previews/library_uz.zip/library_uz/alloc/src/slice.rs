//! Dinamik o'lchamdagi ko'rinish, tutashgan ketma-ketlikka, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Dilimlar-bu ko'rsatkich va uzunlik sifatida ko'rsatilgan xotira blokidagi ko'rinish.
//!
//! ```
//! // Vecni kesish
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // massivni tilimga majburlash
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Tilimlar o'zgarishi mumkin yoki birgalikda ishlatiladi.
//! Umumiy tilim turi `&[T]`, o'zgaruvchan bo'lak turi `&mut [T]`, bu erda `T` element turini anglatadi.
//! Masalan, o'zgaruvchan bo'lak ko'rsatadigan xotira blokini mutatsiyalashingiz mumkin:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Ushbu modulda ba'zi narsalar mavjud:
//!
//! ## Structs
//!
//! Tilimchalar uchun foydali bo'lgan bir nechta tuzilmalar mavjud, masalan, tilim ustidagi iteratsiyani ifodalovchi [`Iter`].
//!
//! ## Trait dasturlari
//!
//! Dilimlar uchun umumiy traits-ning bir nechta dasturlari mavjud.Ba'zi misollarga quyidagilar kiradi:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], element turi [`Eq`] yoki [`Ord`] bo'lgan bo'laklar uchun.
//! * [`Hash`] - element turi [`Hash`] bo'lgan bo'laklar uchun.
//!
//! ## Iteration
//!
//! Dilimlar `IntoIterator` ni amalga oshiradi.Takrorlovchi tilim elementlariga havolalar beradi.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! O'zgaruvchan tilim elementlarga o'zgaruvchan havolalar beradi:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Ushbu takrorlovchi tilim elementlariga o'zgaruvchan havolalar beradi, shuning uchun bo'lakning element turi `i32` bo'lsa, iteratorning element turi `&mut i32`.
//!
//!
//! * [`.iter`] va [`.iter_mut`]-bu standart takrorlanuvchilarni qaytarishning aniq usullari.
//! * Takrorlagichlarni qaytaradigan qo'shimcha usullar [`.split`], [`.splitn`], [`.chunks`], [`.windows`] va boshqalar.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Ushbu moduldagi ko'plab qo'llanmalar faqat sinov konfiguratsiyasida qo'llaniladi.
// Unused_imports ogohlantirishini tuzatishdan ko'ra uni o'chirib qo'yish toza.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Dilimlarni kengaytirishning asosiy usullari
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB-ni sinab ko'rish paytida `vec!` makrosini amalga oshirish uchun zarur bo'lgan, batafsil ma'lumot uchun ushbu fayldagi `hack` moduliga qarang.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB-ni sinab ko'rish paytida `Vec::clone`-ni amalga oshirish uchun kerak bo'lsa, batafsil ma'lumot uchun ushbu fayldagi `hack` moduliga qarang.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` mavjud bo'lmaganda, bu uchta funktsiya aslida `impl [T]`-da, lekin `core::slice::SliceExt` da bo'lmagan usullardir, biz `test_permutations` testi uchun ushbu funktsiyalarni etkazib berishimiz kerak.
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Bunga inline atributini qo'shmasligimiz kerak, chunki bu asosan `vec!` makrosida ishlatiladi va mukammal regressiyani keltirib chiqaradi.
    // Muhokama va mukammal natijalar uchun #71204-ga qarang.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // buyumlar quyidagi tsiklda boshlangan deb belgilandi
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) chegara tekshiruvlarini olib tashlash uchun LLVM uchun zarur va zipdan yaxshiroq kodgenga ega.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec ajratilgan va boshlangan, hech bo'lmaganda shu uzunlikda.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // yuqorida `s` sig'imi bilan ajratilgan va quyida ptr::copy_to_non_overlapping da `s.len()` ga sozlang.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Dilimni saralash.
    ///
    /// Bunday tartib barqaror (ya'ni teng elementlarning tartibini o'zgartirmaydi) va *O*(*n*\*log(* n*)) eng yomon holat).
    ///
    /// Amalga oshirilganda, beqaror saralashga ustunlik beriladi, chunki u odatda barqaror saralashdan tezroq va yordamchi xotirani ajratmaydi.
    /// [`sort_unstable`](slice::sort_unstable)-ga qarang.
    ///
    /// # Amaldagi dastur
    ///
    /// Hozirgi algoritm [timsort](https://en.wikipedia.org/wiki/Timsort)-dan ilhomlangan moslashuvchan, iterativ birlashma turidir.
    /// U tilim deyarli saralangan holatlarda yoki birin ketin ketma-ket biriktirilgan ikki yoki undan ortiq tartiblangan ketma-ketliklardan iborat bo'lgan hollarda juda tez ishlashga mo'ljallangan.
    ///
    ///
    /// Shuningdek, u vaqtincha saqlash uchun `self` hajmining yarmini ajratadi, ammo uning o'rniga qisqa bo'laklar uchun ajratilmaydigan qo'shimchalar navi ishlatiladi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Kesimni taqqoslash funktsiyasi bilan saralaydi.
    ///
    /// Bunday tartib barqaror (ya'ni teng elementlarning tartibini o'zgartirmaydi) va *O*(*n*\*log(* n*)) eng yomon holat).
    ///
    /// Komparator funktsiyasi tilimdagi elementlarning umumiy tartibini belgilashi kerak.Agar buyurtma jami bo'lmasa, elementlarning tartibi aniqlanmagan.
    /// Buyurtma bu umumiy buyurtma, agar u (barcha `a`, `b` va `c` uchun) bo'lsa:
    ///
    /// * jami va antisimmetrik: aynan `a < b`, `a == b` yoki `a > b` bittasi to'g'ri va
    /// * o'tish, `a < b` va `b < c` `a < c` ni nazarda tutadi.Xuddi shu narsa `==` va `>` uchun ham amal qilishi kerak.
    ///
    /// Masalan, [`f64`] [`Ord`] ni amalga oshirmasa ham, chunki `NaN != NaN`, biz tilimda `NaN` mavjud emasligini bilsak, biz `partial_cmp` ni saralash funktsiyamiz sifatida ishlatishimiz mumkin.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Amalga oshirilganda, beqaror saralashga ustunlik beriladi, chunki u odatda barqaror saralashdan tezroq va yordamchi xotirani ajratmaydi.
    /// [`sort_unstable_by`](slice::sort_unstable_by)-ga qarang.
    ///
    /// # Amaldagi dastur
    ///
    /// Hozirgi algoritm [timsort](https://en.wikipedia.org/wiki/Timsort)-dan ilhomlangan moslashuvchan, iterativ birlashma turidir.
    /// U tilim deyarli saralangan holatlarda yoki birin ketin ketma-ket biriktirilgan ikki yoki undan ortiq tartiblangan ketma-ketliklardan iborat bo'lgan hollarda juda tez ishlashga mo'ljallangan.
    ///
    /// Shuningdek, u vaqtincha saqlash uchun `self` hajmining yarmini ajratadi, ammo uning o'rniga qisqa bo'laklar uchun ajratilmaydigan qo'shimchalar navi ishlatiladi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // teskari tartiblash
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Kalitni chiqarish funktsiyasi bilan bo'lakni saralash.
    ///
    /// Bunday tartib barqaror (ya'ni teng elementlarning tartibini o'zgartirmaydi) va *O*(*m*\* * n *\* log(*n*)) eng yomon holat, bu erda asosiy funktsiya *O*(*m*).
    ///
    /// Qimmatbaho asosiy funktsiyalar uchun (masalan,
    /// oddiy xususiyatlarga kirish yoki oddiy operatsiyalar bo'lmagan funktsiyalar), [`sort_by_cached_key`](slice::sort_by_cached_key) sezilarli darajada tezroq bo'lishi mumkin, chunki u element tugmachalarini qayta hisoblab chiqmaydi.
    ///
    ///
    /// Amalga oshirilganda, beqaror saralashga ustunlik beriladi, chunki u odatda barqaror saralashdan tezroq va yordamchi xotirani ajratmaydi.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key)-ga qarang.
    ///
    /// # Amaldagi dastur
    ///
    /// Hozirgi algoritm [timsort](https://en.wikipedia.org/wiki/Timsort)-dan ilhomlangan moslashuvchan, iterativ birlashma turidir.
    /// U tilim deyarli saralangan holatlarda yoki birin ketin ketma-ket biriktirilgan ikki yoki undan ortiq tartiblangan ketma-ketliklardan iborat bo'lgan hollarda juda tez ishlashga mo'ljallangan.
    ///
    /// Shuningdek, u vaqtincha saqlash uchun `self` hajmining yarmini ajratadi, ammo uning o'rniga qisqa bo'laklar uchun ajratilmaydigan qo'shimchalar navi ishlatiladi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Kalitni chiqarish funktsiyasi bilan bo'lakni saralash.
    ///
    /// Saralash paytida tugma funktsiyasi har bir element uchun atigi bir marta chaqiriladi.
    ///
    /// Bunday tartib barqaror (ya'ni teng elementlarning tartibini o'zgartirmaydi) va *O*(*m*\* * n *+* n *\* log(*n*)) eng yomon holat, bu erda asosiy funktsiya *O*(*m*) .
    ///
    /// Oddiy kalit funktsiyalar uchun (masalan, mulkka kirish yoki asosiy operatsiyalar), [`sort_by_key`](slice::sort_by_key) tezroq ishlaydi.
    ///
    /// # Amaldagi dastur
    ///
    /// Amaldagi algoritm Orson Pitersning [pattern-defeating quicksort][pdqsort]-ga asoslangan bo'lib, u tasodifiy kiktsortning tezkor o'rtacha holatini va eng yomon xayajon holatini birlashtirgan holda, ma'lum bir naqshli bo'laklarda chiziqli vaqtga erishishga imkon beradi.
    /// Degeneratsiya holatlarini oldini olish uchun ba'zi randomizatsiyadan foydalanadi, lekin har doim deterministik xatti-harakatni ta'minlash uchun qat'iy seed bilan.
    ///
    /// Eng yomon holatda, algoritm tilim uzunligidagi `Vec<(K, usize)>` vaqtinchalik saqlash joyini ajratadi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Ajratishni kamaytirish uchun bizning vector-ni eng kichik turlari bo'yicha indeksatsiya qilish uchun yordamchi makrosi.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` elementlari noyobdir, chunki ular indekslangan, shuning uchun har qanday tur asl tilimga nisbatan barqaror bo'ladi.
                // Biz `sort_unstable`-dan foydalanamiz, chunki u kamroq xotira ajratishni talab qiladi.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self`-ni yangi `Vec`-ga ko'chiradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Bu erda `s` va `x` mustaqil ravishda o'zgartirilishi mumkin.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self`-ni ajratuvchi bilan yangi `Vec`-ga ko'chiradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Bu erda `s` va `x` mustaqil ravishda o'zgartirilishi mumkin.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // Qo'shimcha ma'lumot uchun ushbu fayldagi `hack` moduliga qarang.
        hack::to_vec(self, alloc)
    }

    /// `self`-ni klonlashsiz va ajratmasdan vector ga o'zgartiradi.
    ///
    /// Natijada paydo bo'lgan vector qutisini `Vec orqali qaytarish mumkin<T>`into_boxed_slice` usuli.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` endi foydalanish mumkin emas, chunki u `x` ga aylantirildi.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // Qo'shimcha ma'lumot uchun ushbu fayldagi `hack` moduliga qarang.
        hack::into_vec(self)
    }

    /// Bir bo'lakni `n` marta takrorlash orqali vector hosil qiladi.
    ///
    /// # Panics
    ///
    /// Imkoniyatlar oshib ketganda, bu funktsiya panic bo'ladi.
    ///
    /// # Examples
    ///
    /// Asosiy foydalanish:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// To'ldirilganda panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Agar `n` noldan katta bo'lsa, uni `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` ga bo'lish mumkin.
        // `2^expn` bu `n` ning eng chap '1' biti bilan ifodalangan raqam va `rem`-`n` ning qolgan qismi.
        //
        //

        // `set_len()`-ga kirish uchun `Vec`-dan foydalanish.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` takrorlash `buf` ni ikki baravar oshirish orqali amalga oshiriladi.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Agar `m > 0` bo'lsa, eng chap '1' gacha bo'lgan bitlar mavjud.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` quvvatiga ega.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) takrorlash `buf` ning o'zidan birinchi `rem` takroriy nusxalarini nusxalash orqali amalga oshiriladi.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Bu `2^expn > rem` dan beri bir-birining ustiga chiqmaydi.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` ga teng (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` tilimini bitta `Self::Output` qiymatiga tekislaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T` bo'lakchasini bitta `Self::Output` qiymatiga tekislaydi va har biriga berilgan ajratgichni joylashtiradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T` bo'lakchasini bitta `Self::Output` qiymatiga tekislaydi va har biriga berilgan ajratgichni joylashtiradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Ushbu tilimning nusxasini o'z ichiga olgan vector-ni qaytaradi, bu erda har bir bayt ASCII bosh harfiga tenglashtiriladi.
    ///
    ///
    /// 'a' dan 'z' gacha bo'lgan ASCII harflari 'A' dan 'Z' gacha xaritalanadi, ammo ASCII bo'lmagan harflar o'zgarmaydi.
    ///
    /// Joydagi qiymatni kattalashtirish uchun [`make_ascii_uppercase`] dan foydalaning.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Ushbu tilimning nusxasini o'z ichiga olgan vector-ni qaytaradi, bu erda har bir bayt kichik ASCII kichik harfiga tenglashtiriladi.
    ///
    ///
    /// 'A' dan 'Z' gacha bo'lgan ASCII harflari 'a' dan 'z' gacha xaritalanadi, ammo ASCII bo'lmagan harflar o'zgarmaydi.
    ///
    /// Joydagi qiymatni kamaytirish uchun [`make_ascii_lowercase`] dan foydalaning.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ma'lumotlarning ma'lum turlari bo'yicha tilim uchun traits kengaytmasi
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`] uchun trait yordamchisi (tilim::concat).
///
/// Note: `Item` turi parametri ushbu trait-da ishlatilmaydi, ammo bu impllarni yanada umumiy bo'lishiga imkon beradi.
/// Bu holda, biz ushbu xatoni olamiz:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Buning sababi shundaki, bir nechta `Borrow<[_]>` tasavvurlari mavjud bo'lgan `V` turlari mavjud bo'lishi mumkin, chunki bir nechta `T` turlari qo'llanilishi mumkin:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Birlashtirilgandan keyin hosil bo'lgan tur
    type Output;

    /// [`[T]: : concat`] ni amalga oshirish (tilim::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`](tilim::qo'shilish) uchun trait yordamchisi
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Birlashtirilgandan keyin hosil bo'lgan tur
    type Output;

    /// [`[T]: : join`](slice::join) dasturini amalga oshirish
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Dilimlarga mo'ljallangan standart trait dasturlari
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // ustiga yozib bo'lmaydigan narsalarni tashlab qo'ying
        target.truncate(self.len());

        // target.len Yuqoridagi kesilganligi sababli <= self.len, shuning uchun bu erdagi bo'laklar har doim chegarada.
        //
        let (init, tail) = self.split_at(target.len());

        // allocations/resources qiymatlarini qayta ishlating.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` ni oldindan saralangan `v[1..]` ketma-ketligiga kiritadi, shunda butun `v[..]` saralanadi.
///
/// Bu qo'shish tartibining ajralmas subroutinasi.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Bu erda qo'shishni amalga oshirishning uchta usuli mavjud:
            //
            // 1. Birinchisi oxirgi manzilga yetguncha qo'shni elementlarni almashtiring.
            //    Biroq, shu bilan biz ma'lumotlarni kerakli miqdordan ko'proq nusxa ko'chiramiz.
            //    Agar elementlar katta tuzilmalar bo'lsa (nusxalash qimmat), bu usul sekin bo'ladi.
            //
            // 2. Birinchi element uchun kerakli joy topilmaguncha takrorlang.
            // Undan keyin joy topadigan elementlarni siljiting va nihoyat uni qolgan teshikka joylashtiring.
            // Bu yaxshi usul.
            //
            // 3. Birinchi elementni vaqtinchalik o'zgaruvchiga nusxalash.Kerakli joy topilmaguncha takrorlang.
            // Biz ketayotib, har bir o'tgan elementni oldingi uyaga nusxalash.
            // Nihoyat, vaqtinchalik o'zgaruvchidan ma'lumotlarni qolgan teshikka nusxalash.
            // Bu usul juda yaxshi.
            // Ko'rsatkichlar 2-usulga qaraganda bir oz yaxshiroq ishlashni namoyish etdi.
            //
            // Barcha usullar taqqoslandi va 3-chi eng yaxshi natijalarni ko'rsatdi.Shunday qilib biz uni tanladik.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Qo'shish jarayonining oraliq holatini har doim `hole` kuzatib boradi, bu ikki maqsadga xizmat qiladi:
            // 1. `v` yaxlitligini panics dan `is_less` da himoya qiladi.
            // 2. Oxir-oqibat `v` dagi qolgan teshikni to'ldiradi.
            //
            // Panic xavfsizligi:
            //
            // Agar jarayon davomida biron bir nuqtada `is_less` panics bo'lsa, `hole` tushadi va `v` dagi teshikni `tmp` bilan to'ldiradi va shu bilan `v` dastlab ushlab turgan har bir ob'ektni bir marotaba ushlab turishini ta'minlaydi.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` tushadi va shu tariqa `tmp` ni `v` dagi qolgan teshikka ko'chiradi.
        }
    }

    // Yiqilganda, `src` dan `dest` ga nusxa olinadi.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// `v[..mid]` va `v[mid..]` ishlarini vaqtincha saqlash sifatida `buf` yordamida kamaytirmaydigan ishlarni birlashtiradi va natijani `v[..]` formatida saqlaydi.
///
/// # Safety
///
/// Ikkala bo'lak bo'sh bo'lmasligi kerak va `mid` chegarada bo'lishi kerak.
/// Buffer `buf` qisqa tilimning nusxasini ushlab turish uchun etarlicha uzun bo'lishi kerak.
/// Bundan tashqari, `T` nol o'lchamdagi turdagi bo'lmasligi kerak.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Birlashtirish jarayoni avvalroq `buf`-ga qisqartirilgan nusxasini ko'chiradi.
    // Keyin u yangi nusxa ko'chirilgan va uzoqroq (yoki orqaga) yugurib, ularning keyingi iste'mol qilinmagan elementlarini taqqoslaydi va kichikroq (yoki kattaroq) birini `v` ga ko'chiradi.
    //
    // Qisqa muddat to'liq sarflanishi bilanoq, jarayon tugaydi.Agar birinchi navbatda uzoqroq muddat sarf qilinadigan bo'lsa, biz `v`-ning qolgan teshigiga qisqa vaqt ichida qolgan narsalarni nusxalashimiz kerak.
    //
    // Jarayonning oraliq holatini har doim ikkita maqsadga xizmat qiladigan `hole` kuzatib boradi:
    // 1. `v` yaxlitligini panics dan `is_less` da himoya qiladi.
    // 2. Agar uzoqroq ishlash birinchi bo'lib sarflansa, `v` dagi qolgan teshikni to'ldiradi.
    //
    // Panic xavfsizligi:
    //
    // Agar jarayon davomida biron bir nuqtada `is_less` panics bo'lsa, `hole` tushib qoladi va `v` dagi teshikni `buf` dagi iste'mol qilinmagan diapazon bilan to'ldiradi va shu bilan `v` dastlab ushlab turgan har bir ob'ektni bir marta to'liq ushlab turishini ta'minlaydi.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Chap yugurish qisqaroq.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Dastlab, bu ko'rsatkichlar o'zlarining massivlarining boshlanishiga ishora qiladilar.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Kam tomonni iste'mol qiling.
            // Agar teng bo'lsa, barqarorlikni saqlab qolish uchun chap harakatni afzal qiling.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // To'g'ri yugurish qisqaroq.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Dastlab, bu ko'rsatkichlar o'zlarining massivlari uchlarini bosib o'tishadi.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Katta tomonini iste'mol qiling.
            // Agar teng bo'lsa, barqarorlikni saqlash uchun to'g'ri harakatni afzal qiling.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Nihoyat, `hole` tushadi.
    // Agar qisqa muddat to'liq sarflanmagan bo'lsa, uning qolgan qismi endi `v` teshikka ko'chiriladi.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Yiqilganda, `start..end` diapazonini `dest..` ga nusxalash.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` nol o'lchovli tur emas, shuning uchun uning kattaligiga bo'lish yaxshi.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Ushbu birlashma turi TimSort-dan [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) batafsil tavsiflangan ba'zi (lekin hammasi emas) g'oyalarni oladi.
///
///
/// Algoritm tabiiy yugurish deb ataladigan qat'iy kamayuvchi va kamaymaydigan ketma-ketlikni aniqlaydi.Hali birlashtirilmagan kutilayotgan ishlarning to'plami mavjud.
/// Har bir yangi topilgan yugurish stakka suriladi, so'ngra ba'zi ikkita qo'shni yugurishlar ushbu ikkita o'zgarmas qondirilgunga qadar birlashtiriladi:
///
/// 1. har bir `i` uchun `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. har bir `i` uchun `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Invariantlar ishning umumiy vaqtini *O*(*n*\*log(* n*))-ning eng yomon holati) bo'lishini ta'minlaydi.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ushbu uzunlikgacha bo'lgan bo'laklar qo'shish tartibida saralanadi.
    const MAX_INSERTION: usize = 20;
    // Hech bo'lmaganda juda ko'p elementlarni qamrab olish uchun qo'shma tartib yordamida juda qisqa muddatli uzaytiriladi.
    const MIN_RUN: usize = 10;

    // Tartiblash nol o'lchovli turlari bo'yicha mazmunli harakatlarga ega emas.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Qisqa massivlar ajratishdan qochish uchun qo'shilish tartibida joyida tartiblanadi.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Chizish xotirasi sifatida foydalanish uchun buferni ajrating.Biz 0 uzunligini saqlaymiz, shuning uchun `v` tarkibidagi sayoz nusxalarni x01X panics bo'lsa, nusxada ishlaydigan dtorlarga xavf tug'dirmasdan saqlay olamiz.
    //
    // Ikkita tartiblangan operatsiyalarni birlashtirganda, bufer har doim eng ko'p `len / 2` uzunlikka ega bo'lgan qisqa muddatli nusxasini saqlaydi.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v`-da tabiiy yugurishlarni aniqlash uchun biz uni orqaga o'tkazamiz.
    // Bu g'alati qaror bo'lib tuyulishi mumkin, lekin birlashish tez-tez teskari yo'nalishda (forwards) tomonga o'tishini hisobga oling.
    // Etalonlarga ko'ra oldinga birlashish orqaga qarab birlashishdan biroz tezroq.
    // Xulosa qilish kerakki, yugurishlarni orqaga qarab bosib o'tish ish faoliyatini yaxshilaydi.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Keyingi tabiiy yugurishni toping va agar u qat'iy ravishda kamayayotgan bo'lsa, uni o'zgartiring.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Agar u juda qisqa bo'lsa, yana bir nechta elementlarni qo'shib qo'ying.
        // Kiritish tartibi qisqa ketma-ketlikdagi birlashma tartibiga qaraganda tezroq, shuning uchun bu ishlashni sezilarli darajada yaxshilaydi.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Ushbu yugurishni stakka suring.
        runs.push(Run { start, len: end - start });
        end = start;

        // Invariantlarni qondirish uchun qo'shni yugurish juftlarini birlashtiring.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Va nihoyat, bitta yugurish stakda qolishi kerak.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Yugurishlar to'plamini tekshiradi va birlashish uchun keyingi juftlikni aniqlaydi.
    // Aniqrog'i, agar `Some(r)` qaytarilsa, demak, `runs[r]` va `runs[r + 1]` birlashtirilishi kerak.
    // Agar algoritm o'rniga yangi ishga tushirishni davom ettirsa, `None` qaytariladi.
    //
    // TimSort bu erda ta'riflanganidek, buggy dasturlari bilan mashhur:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Hikoyaning mazmuni quyidagicha: biz to'rtta yugurishdagi invariantlarni stackda bajarishimiz kerak.
    // Ularni faqat birinchi uchlikka qo'shib qo'yish invariantlar to'plamdagi *hamma* ishlarni bajarishini ta'minlash uchun etarli emas.
    //
    // Ushbu funktsiya to'rtta ish uchun invariantlarni to'g'ri tekshiradi.
    // Bundan tashqari, agar eng yuqori ko'rsatkich 0 indeksidan boshlangan bo'lsa, u tartiblashni yakunlash uchun har doim stek to'liq qulaguncha birlashtirish operatsiyasini talab qiladi.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}