#![stable(feature = "wake_trait", since = "1.51.0")]
//! Asenkron vazifalar bilan ishlash turlari va Traits.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Ijrochida vazifani uyg'otish.
///
/// Ushbu trait yordamida [`Waker`] yaratish mumkin.
/// Ijrochi ushbu trait-ning bajarilishini belgilashi va undan foydalanib, ushbu ijrochida bajariladigan vazifalarga o'tishi uchun Wakerni qurishi mumkin.
///
/// Ushbu trait xotirada xavfsiz va [`RawWaker`] qurish uchun ergonomik alternativadir.
/// Bu vazifani uyg'otish uchun ishlatiladigan ma'lumotlar [`Arc`]-da saqlanadigan umumiy ijrochi dizaynini qo'llab-quvvatlaydi.
/// Ba'zi ijrochilar (ayniqsa, o'rnatilgan tizimlar uchun) ushbu API dan foydalana olmaydilar, shuning uchun [`RawWaker`] ushbu tizimlar uchun alternativa sifatida mavjud.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// future-ni qabul qiladigan va uni joriy ish zarrachasida bajaradigan asosiy `block_on` funktsiyasi.
///
/// **Note:** Ushbu misol to'g'riligini soddaligi bilan almashtiradi.
/// Qulflarning oldini olish uchun ishlab chiqarish darajasidagi dasturlar `thread::unpark`-ga oraliq qo'ng'iroqlarni va ichki chaqiriqlarni bajarishi kerak.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Qo'ng'iroq paytida hozirgi ipni uyg'otadigan uyg'otuvchi.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Amaldagi ipda tugatish uchun future-ni ishga tushiring.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // So'ralishi uchun future-ni pin qiling.
///     let mut fut = Box::pin(fut);
///
///     // future-ga uzatiladigan yangi kontekst yarating.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // future tugaguniga qadar ishga tushiring.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Ushbu vazifani uyg'oting.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Bu vazifani bedorni iste'mol qilmasdan uyg'oting.
    ///
    /// Agar ijrochi uyg'otuvchini iste'mol qilmasdan uyg'onishning arzonroq usulini qo'llab-quvvatlasa, bu usulni bekor qilishi kerak.
    /// Odatiy bo'lib, u [`Arc`]-ni klonlaydi va klonda [`wake`]-ni chaqiradi.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // XAVFSIZLIK: Bu xavfsiz, chunki raw_waker xavfsiz tarzda tuziladi
        // Arc-dan RawWaker<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker-ni qurish uchun ushbu xususiy funktsiya o'rniga ishlatiladi
// `From<Arc<W>> for Waker`-ning xavfsizligi trait-ning to'g'ri yuborilishiga bog'liq emasligini ta'minlash uchun buni `From<Arc<W>> for RawWaker` impl-ga kiritib, buning o'rniga ikkala so'z ham ushbu funktsiyani to'g'ridan-to'g'ri va aniq ravishda chaqiradi.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Uni klonlash uchun yoyning mos yozuvlar sonini ko'paytiring.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Arkni Wake::wake funktsiyasiga o'tkazib, qiymat bo'yicha uyg'oning
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Yo'naltiruvchi bilan uyg'oning, tushmasin uchun stakanni ManualDrop-ga o'rab qo'ying
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Arc-ning mos yozuvlar sonini pasayishiga kamaytiring
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}