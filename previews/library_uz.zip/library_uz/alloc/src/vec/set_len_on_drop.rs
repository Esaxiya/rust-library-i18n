// `SetLenOnDrop` qiymati doiradan chiqib ketganda vec uzunligini o'rnating.
//
// G'oya quyidagicha: SetLenOnDrop-dagi uzunlik maydoni-bu Vec-ning ma'lumot ko'rsatkichi orqali hech qanday do'konlar bilan optimallashtiruvchi ko'rmaydigan mahalliy o'zgaruvchidir.
// Bu #32155 taxallusini tahlil qilish uchun vaqtinchalik echim
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}