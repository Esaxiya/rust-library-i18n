//! `Vec<T>` yozilgan, to'plangan ajratilgan tarkibga ega bo'lgan qo'shni o'sadigan qator turi.
//!
//! Vectors `O(1)` indeksatsiyasiga ega, amortizatsiya qilingan `O(1)` surish (oxirigacha) va `O(1)` pop (oxiridan).
//!
//!
//! Vectors ularni hech qachon `isize::MAX` baytdan ko'proq ajratmasligini ta'minlaydi.
//!
//! # Examples
//!
//! Siz [`Vec::new`] bilan aniq [`Vec`] yaratishingiz mumkin:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... yoki [`vec!`] so'lidan foydalanib:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // o'n nol
//! ```
//!
//! Siz [`push`] qiymatlarini vector oxiriga qo'yishingiz mumkin (bu vector ni kerak bo'lganda o'sadi):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! O'chirish qiymatlari xuddi shu tarzda ishlaydi:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors shuningdek indekslashni qo'llab-quvvatlaydi ([`Index`] va [`IndexMut`] traits orqali):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// `Vec<T>` deb yozilgan va 'vector' deb talaffuz qilinadigan o'sib boruvchi qator turi.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] makrosi ishga tushirishni yanada qulayroq qilish uchun taqdim etiladi:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Shuningdek, u `Vec<T>` ning har bir elementini berilgan qiymat bilan ishga tushirishi mumkin.
/// Bu ajratish va ishga tushirishni alohida bosqichlarda bajarishdan ko'ra samaraliroq bo'lishi mumkin, ayniqsa vector nollarini ishga tushirishda:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Quyidagilar teng, ammo sekinroq bo'lishi mumkin:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Qo'shimcha ma'lumot uchun [Capacity and Reallocation](#capacity-and-reallocation)-ga qarang.
///
/// `Vec<T>`-dan samarali stek sifatida foydalaning:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // 3, 2, 1 nashrlari
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` turi indeks bo'yicha qiymatlarga kirishga imkon beradi, chunki u [`Index`] trait ni amalga oshiradi.Misol yanada aniqroq bo'ladi:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // u '2'-ni namoyish etadi
/// ```
///
/// Ammo ehtiyot bo'ling: agar siz `Vec` da bo'lmagan indeksga kirishga harakat qilsangiz, dasturiy ta'minotingiz panic bo'ladi!Siz buni qila olmaysiz:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Agar indeks `Vec`-da ekanligini tekshirishni istasangiz, [`get`] va [`get_mut`]-dan foydalaning.
///
/// # Slicing
///
/// `Vec` o'zgarishi mumkin.Boshqa tomondan, tilimlar faqat o'qish uchun mo'ljallangan ob'ektlardir.
/// [slice][prim@slice] olish uchun [`&`] dan foydalaning.Misol:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... va barchasi shu!
/// // siz buni quyidagicha qilishingiz mumkin:
/// let u: &[usize] = &v;
/// // yoki shunga o'xshash:
/// let u: &[_] = &v;
/// ```
///
/// Rust-da, siz o'qish uchun ruxsat berishni xohlaganingizda, tilimlarni vectors o'rniga argument sifatida berish odatiy holdir.Xuddi shu narsa [`String`] va [`&str`] uchun ham amal qiladi.
///
/// # Imkoniyatlar va qayta taqsimlash
///
/// vector sig`imi-bu vector ga qo`shiladigan har qanday future elementlari uchun ajratilgan joy miqdori.Buni vector ichidagi haqiqiy elementlar sonini belgilaydigan vector ning *uzunligi* bilan adashtirish mumkin emas.
/// Agar vector uzunligi uning imkoniyatlaridan oshib ketsa, uning hajmi avtomatik ravishda oshiriladi, lekin uning elementlarini qayta taqsimlash kerak bo'ladi.
///
/// Masalan, quvvati 10 va uzunligi 0 bo'lgan vector yana 10 ta element uchun bo'sh joy bo'lgan bo'sh vector bo'ladi.10 yoki undan kam elementlarni vector-ga surish uning imkoniyatlarini o'zgartirmaydi yoki qayta taqsimlanishiga olib kelmaydi.
/// Ammo, agar vector uzunligi 11 ga ko'paytirilsa, uni qayta taqsimlash kerak bo'ladi, bu sekin bo'lishi mumkin.Shu sababli, iloji boricha vector olishini taxmin qilish uchun [`Vec::with_capacity`] dan foydalanish tavsiya etiladi.
///
/// # Guarantees
///
/// Ajablanarlisi asosiy tabiati tufayli `Vec` uning dizayni haqida juda ko'p kafolatlar beradi.Bu uning umumiy holatida iloji boricha pastroq yuk bo'lishini va xavfli kod bilan ibtidoiy usullarda to'g'ri boshqarilishini ta'minlaydi.Ushbu kafolatlar malakasiz `Vec<T>`-ga tegishli ekanligini unutmang.
/// Agar qo'shimcha turdagi parametrlar qo'shilsa (masalan, maxsus ajratuvchilarni qo'llab-quvvatlash uchun), ularning standart parametrlarini bekor qilish xatti-harakatni o'zgartirishi mumkin.
///
/// Asosan, `Vec` (ko'rsatgich, imkoniyat, uzunlik) uchlik bo'lib qoladi va har doim ham shunday bo'ladi.Endi yo'q, kam emas.Ushbu maydonlarning tartibi to'liq aniqlanmagan va siz ularni o'zgartirish uchun tegishli usullardan foydalanishingiz kerak.
/// Ko'rsatkich hech qachon nolga teng bo'lmaydi, shuning uchun bu tur null-pointer-optimallashtirilgan.
///
/// Biroq, ko'rsatgich aslida ajratilgan xotiraga ishora qilmasligi mumkin.
/// Xususan, agar siz [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] orqali 0 sig'imli `Vec` qursangiz yoki bo'sh Vecda [`shrink_to_fit`] ni chaqirsangiz, u xotira ajratmaydi.Xuddi shunday, agar siz `Vec` ichida nol o'lchamdagi turlarni saqlasangiz, u ular uchun joy ajratmaydi.
/// *Shuni esda tutingki, bu holda `Vec` 0* ning [`capacity`] haqida xabar bermasligi mumkin.
/// `Vec` ajratadi va agar shunday bo'lsa, faqat [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Umuman olganda, "Vec" ning ajratish tafsilotlari juda nozik-agar siz `Vec` yordamida xotirani ajratmoqchi bo'lsangiz va undan boshqa narsa uchun foydalansangiz (xavfli kodga o'tish yoki o'zingizning xotirangizga asoslangan to'plamni yaratish uchun) `Vec`-ni qayta tiklash uchun `from_raw_parts`-dan foydalanib, keyin uni tashlab, ushbu xotirani ajratish uchun.
///
/// Agar `Vec` * xotirasi ajratilgan bo'lsa, u ko'rsatadigan xotira uyumda (ajratuvchi Rust tomonidan belgilab qo'yilganidek, sukut bo'yicha ishlatilishi uchun tuzilgan) va uning ko'rsatuvchisi [`len`] ishga tushirilgan, tutashgan elementlarni navbat bilan ko'rsatadi (siz nima qilasiz) uni bir bo'lakka majburlaganligingizni tekshiring), so'ngra [`sig'im ']`, `[` len`] mantiqiy ravishda boshlanmagan, qo'shni elementlar.
///
///
/// Sig'imi 4 bo'lgan `'a'` va `'b'` elementlarini o'z ichiga olgan vector quyidagi ko'rinishda bo'lishi mumkin.Yuqori qismi `Vec` tuzilmasi bo'lib, u uyum, uzunlik va sig'imga ajratish boshiga ko'rsatgichni o'z ichiga oladi.
/// Pastki qism-bu uyumdagi ajratish, tutashgan xotira bloki.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** ishga tushirilmagan xotirani anglatadi, [`MaybeUninit`]-ga qarang.
/// - Note: ABI barqaror emas va `Vec` xotiraning joylashuvi (shu jumladan maydonlarning tartibini) haqida hech qanday kafolat bermaydi.
///
/// `Vec` elementlar aslida ikkita sababga ko'ra stakda saqlanadigan "small optimization" ni hech qachon bajarmaydi:
///
/// * `Vec`-ni to'g'ri boshqarishni xavfli kod uchun qiyinlashtirishi mumkin edi.`Vec` mazmuni, agar u faqat ko'chirilgan bo'lsa, barqaror manzilga ega bo'lmaydi va agar `Vec` aslida xotira ajratganligini aniqlash qiyinroq bo'lsa.
///
/// * Bu har qanday kirish uchun qo'shimcha branch olib keladigan umumiy ishni jazolaydi.
///
/// `Vec` butunlay bo'sh bo'lsa ham, hech qachon avtomatik ravishda o'zini kamaytirmaydi.Bu keraksiz ajratmalar yoki taqsimotlarning ro'y bermasligini ta'minlaydi.`Vec`-ni bo'shatish va keyin uni xuddi shu [`len`]-ga to'ldirish, ajratuvchiga hech qanday qo'ng'iroq qilmasligi kerak.Agar siz foydalanilmagan xotirani bo'shatmoqchi bo'lsangiz, [`shrink_to_fit`] yoki [`shrink_to`] dan foydalaning.
///
/// [`push`] va [`insert`] hisobot hajmi etarli bo'lsa, uni hech qachon ajratmaydi.[`push`] va [`insert`] *, agar [`len`]`==`[`sig'im`] bo'lsa, (qayta) ajratadi.Ya'ni, hisobot qilingan quvvat to'liq aniq va unga ishonish mumkin.Hatto zarur bo'lsa, `Vec` tomonidan ajratilgan xotirani qo'lda bo'shatish uchun ham foydalanish mumkin.
/// Ommaviy kiritish usullari *kerak bo'lmaganda ham* qayta taqsimlanishi mumkin.
///
/// `Vec` to'liq bo'lganda qayta taqsimlashda yoki [`reserve`] chaqirilganda ma'lum bir o'sish strategiyasini kafolatlamaydi.Amaldagi strategiya asosiy va doimiy bo'lmagan o'sish omilidan foydalanish maqsadga muvofiq bo'lishi mumkin.Qaysi strategiyadan foydalanilmasin, albatta *O*(1) amortizatsiya qilingan [`push`] kafolatini beradi.
///
/// `vec![x; n]`, `vec![a, b, c, d]` va [`Vec::with_capacity(n)`][`Vec::with_capacity`], barchasi aniq `Vec` ni kerakli quvvatga ega ishlab chiqaradi.
/// Agar [`len`]`==`[`sig'im`], ([`vec!`] so'lida bo'lgani kabi) bo'lsa, u holda `Vec<T>` elementlarni qayta taqsimlamasdan yoki ko'chirmasdan [`Box<[T]>`][owned slice] ga va undan o'zgartirilishi mumkin.
///
/// `Vec` undan o'chirilgan ma'lumotlarning ustiga yozmaydi, shuningdek ularni saqlamaydi.Uning boshlang'ich xotirasi-bu kerakli joydan foydalanishi mumkin bo'lgan chizish maydoni.Umuman olganda, u eng samarali yoki oson amalga oshiriladigan ishlarni bajaradi.Xavfsizlik maqsadida o'chirilgan ma'lumotlarga ishonmang.
/// Agar siz `Vec` ni tashlasangiz ham, uning buferi boshqa `Vec` tomonidan qayta ishlatilishi mumkin.
/// Agar siz avval "Vec" xotirasini nolga tenglashtirsangiz ham, aslida bunday bo'lmasligi mumkin, chunki optimizator buni saqlab qolish kerak bo'lgan yon ta'sir deb hisoblamaydi.
/// Biz buzmaydigan bitta holat bor, lekin ortiqcha quvvatga yozish uchun `unsafe` kodidan foydalanib, so'ngra uzunlikni moslashtirish uchun har doim ham amal qiladi.
///
/// Hozirda `Vec` elementlarni tushirish tartibiga kafolat bermaydi.
/// Buyurtma ilgari o'zgargan va yana o'zgarishi mumkin.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Tabiiy usullar
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Yangi, bo'sh `Vec<T>` quradi.
    ///
    /// vector elementlar unga surilmaguncha ajratilmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Belgilangan quvvatga ega yangi, bo'sh `Vec<T>` quradi.
    ///
    /// vector aniq `capacity` elementlarini qayta taqsimlamasdan ushlab tura oladi.
    /// Agar `capacity` 0 bo'lsa, vector ajratilmaydi.
    ///
    /// Shuni ta'kidlash kerakki, qaytarilgan vector *sig'imi* ko'rsatilgan bo'lsa ham, vector nol *uzunligiga* ega bo'ladi.
    ///
    /// Uzunlik va sig'im o'rtasidagi farqni tushuntirish uchun *[Imkoniyatlar va qayta taqsimlash]* ga qarang.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector tarkibida ko'proq narsa bo'lsa ham, hech qanday element yo'q
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Bularning barchasi qayta taqsimlanmasdan amalga oshiriladi ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... lekin bu vector-ni qayta taqsimlashga olib kelishi mumkin
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// To'g'ridan-to'g'ri boshqa vector ning xom komponentlaridan `Vec<T>` hosil qiladi.
    ///
    /// # Safety
    ///
    /// Bu tekshirilmagan invariantlar soni tufayli bu juda xavfli.
    ///
    /// * `ptr` ilgari [`String`]/`Vec orqali ajratilgan bo'lishi kerak<T>"(hech bo'lmaganda, bunday bo'lmasa, ehtimol u noto'g'ri bo'lishi mumkin).
    /// * `T` `ptr` bilan ajratilgan o'lchamga va hizalanishga ega bo'lishi kerak.
    ///   (`T` unchalik qattiq bo'lmagan moslashtirishga ega emas, xotira bir xil tartib bilan ajratilishi va taqsimlanishi kerakligi haqidagi [`dealloc`] talabini qondirish uchun hizalama haqiqatan ham teng bo'lishi kerak.)
    ///
    /// * `length` `capacity` dan kam yoki unga teng bo'lishi kerak.
    /// * `capacity` ko'rsatgich ajratilgan hajmga ega bo'lishi kerak.
    ///
    /// Ularni buzish, ajratuvchining ichki ma'lumotlar tuzilmalarini buzish kabi muammolarni keltirib chiqarishi mumkin.Masalan,`Vec<u8>` ni ko'rsatgichdan C `char` qatorga `size_t` uzunlikgacha qurish ** xavfsiz emas.
    /// `Vec<u16>` va uning uzunligidan bittasini qurish ham xavfsiz emas, chunki ajratuvchi hizalanishga g'amxo'rlik qiladi va bu ikki tur turli xil tekislashlarga ega.
    /// Bufer 2-rostlash bilan ajratilgan (`u16` uchun), lekin uni `Vec<u8>` ga aylantirgandan so'ng u 1-hizalama bilan taqsimlanadi.
    ///
    /// `ptr`-ga egalik `Vec<T>`-ga samarali ravishda o'tkaziladi, keyinchalik u xohlagancha ko'rsatgich tomonidan ko'rsatilgan xotira tarkibini ajratishi, qayta taqsimlashi yoki o'zgartirishi mumkin.
    /// Ushbu funktsiyani chaqirgandan so'ng ko'rsatgichni boshqa hech narsa ishlatmasligiga ishonch hosil qiling.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME vec_into_raw_parts stabillashganida buni yangilang.
    ///     // "V" ning destruktorini ishga tushirishni oldini oling, shuning uchun biz ajratishni to'liq nazorat qilamiz.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` haqida turli xil muhim ma'lumotlarni chiqarib oling
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Xotirani 4, 5, 6 bilan yozing
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Barchasini Vec-ga qayta joylashtiring
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Yangi, bo'sh `Vec<T, A>` quradi.
    ///
    /// vector elementlar unga surilmaguncha ajratilmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Belgilangan sig'im bilan belgilangan quvvatga ega yangi, bo'sh `Vec<T, A>` quradi.
    ///
    /// vector aniq `capacity` elementlarini qayta taqsimlamasdan ushlab tura oladi.
    /// Agar `capacity` 0 bo'lsa, vector ajratilmaydi.
    ///
    /// Shuni ta'kidlash kerakki, qaytarilgan vector *sig'imi* ko'rsatilgan bo'lsa ham, vector nol *uzunligiga* ega bo'ladi.
    ///
    /// Uzunlik va sig'im o'rtasidagi farqni tushuntirish uchun *[Imkoniyatlar va qayta taqsimlash]* ga qarang.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector tarkibida ko'proq narsa bo'lsa ham, hech qanday element yo'q
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Bularning barchasi qayta taqsimlanmasdan amalga oshiriladi ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... lekin bu vector-ni qayta taqsimlashga olib kelishi mumkin
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// To'g'ridan-to'g'ri boshqa vector ning xom komponentlaridan `Vec<T, A>` hosil qiladi.
    ///
    /// # Safety
    ///
    /// Bu tekshirilmagan invariantlar soni tufayli bu juda xavfli.
    ///
    /// * `ptr` ilgari [`String`]/`Vec orqali ajratilgan bo'lishi kerak<T>"(hech bo'lmaganda, bunday bo'lmasa, ehtimol u noto'g'ri bo'lishi mumkin).
    /// * `T` `ptr` bilan ajratilgan o'lchamga va hizalanishga ega bo'lishi kerak.
    ///   (`T` unchalik qattiq bo'lmagan moslashtirishga ega emas, xotira bir xil tartib bilan ajratilishi va taqsimlanishi kerakligi haqidagi [`dealloc`] talabini qondirish uchun hizalama haqiqatan ham teng bo'lishi kerak.)
    ///
    /// * `length` `capacity` dan kam yoki unga teng bo'lishi kerak.
    /// * `capacity` ko'rsatgich ajratilgan hajmga ega bo'lishi kerak.
    ///
    /// Ularni buzish, ajratuvchining ichki ma'lumotlar tuzilmalarini buzish kabi muammolarni keltirib chiqarishi mumkin.Masalan,`Vec<u8>` ni ko'rsatgichdan C `char` qatorga `size_t` uzunlikgacha qurish ** xavfsiz emas.
    /// `Vec<u16>` va uning uzunligidan bittasini qurish ham xavfsiz emas, chunki ajratuvchi hizalanishga g'amxo'rlik qiladi va bu ikki tur turli xil tekislashlarga ega.
    /// Bufer 2-rostlash bilan ajratilgan (`u16` uchun), lekin uni `Vec<u8>` ga aylantirgandan so'ng u 1-hizalama bilan taqsimlanadi.
    ///
    /// `ptr`-ga egalik `Vec<T>`-ga samarali ravishda o'tkaziladi, keyinchalik u xohlagancha ko'rsatgich tomonidan ko'rsatilgan xotira tarkibini ajratishi, qayta taqsimlashi yoki o'zgartirishi mumkin.
    /// Ushbu funktsiyani chaqirgandan so'ng ko'rsatgichni boshqa hech narsa ishlatmasligiga ishonch hosil qiling.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME vec_into_raw_parts stabillashganida buni yangilang.
    ///     // "V" ning destruktorini ishga tushirishni oldini oling, shuning uchun biz ajratishni to'liq nazorat qilamiz.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` haqida turli xil muhim ma'lumotlarni chiqarib oling
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Xotirani 4, 5, 6 bilan yozing
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Barchasini Vec-ga qayta joylashtiring
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// `Vec<T>` ni xom tarkibiy qismlarga ajratadi.
    ///
    /// Xom ko'rsatkichni asosiy ma'lumotlarga, vector uzunligini (elementlarda) va ma'lumotlarning ajratilgan hajmini (elementlarda) qaytaradi.
    /// Bu [`from_raw_parts`] argumentlari bilan bir xil tartibda bir xil dalillar.
    ///
    /// Ushbu funktsiyani chaqirgandan so'ng, qo'ng'iroq qiluvchi avval `Vec` tomonidan boshqariladigan xotira uchun javobgardir.
    /// Buning yagona usuli-bu xom ko'rsatgichni, uzunlikni va quvvatni [`from_raw_parts`] funktsiyasi bilan `Vec` ga qaytarish, bu esa destruktorga tozalashni amalga oshirishga imkon beradi.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Endi biz tarkibiy qismlarga o'zgartirishlar kiritishimiz mumkin, masalan, xom ko'rsatkichni mos keladigan turga o'tkazish.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// `Vec<T>` ni xom tarkibiy qismlarga ajratadi.
    ///
    /// Xom ko'rsatkichni asosiy ma'lumotlarga qaytaradi, vector uzunligi (elementlarda), ma'lumotlarning ajratilgan hajmi (elementlarda) va ajratuvchi.
    /// Bu [`from_raw_parts_in`] argumentlari bilan bir xil tartibda bir xil dalillar.
    ///
    /// Ushbu funktsiyani chaqirgandan so'ng, qo'ng'iroq qiluvchi avval `Vec` tomonidan boshqariladigan xotira uchun javobgardir.
    /// Buning yagona usuli-bu xom ko'rsatgichni, uzunlikni va quvvatni [`from_raw_parts_in`] funktsiyasi bilan `Vec` ga qaytarish, bu esa destruktorga tozalashni amalga oshirishga imkon beradi.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Endi biz tarkibiy qismlarga o'zgartirishlar kiritishimiz mumkin, masalan, xom ko'rsatkichni mos keladigan turga o'tkazish.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// vector elementlari sonini qayta taqsimlamasdan qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Ushbu `Vec<T>` tarkibiga kiritilishi kerak bo'lgan kamida `additional` elementlari uchun zaxira hajmi.
    /// To'plam tez-tez qayta taqsimlanishiga yo'l qo'ymaslik uchun ko'proq joy ajratishi mumkin.
    /// `reserve`-ni chaqirgandan so'ng, imkoniyat `self.len() + additional`-dan katta yoki unga teng bo'ladi.
    /// Imkoniyatlar allaqachon etarli bo'lsa, hech narsa qilmaydi.
    ///
    /// # Panics
    ///
    /// Agar yangi quvvat `isize::MAX` baytdan oshsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Berilgan `Vec<T>`-ga ko'proq `additional` elementlarini kiritish uchun minimal quvvatni saqlaydi.
    ///
    /// `reserve_exact`-ni chaqirgandan so'ng, imkoniyat `self.len() + additional`-dan katta yoki unga teng bo'ladi.
    /// Imkoniyatlar allaqachon etarli bo'lsa, hech narsa qilmaydi.
    ///
    /// E'tibor bering, ajratuvchi kollektsiyaga so'raganidan ko'ra ko'proq joy berishi mumkin.
    /// Shuning uchun, imkoniyatlarning aniq minimal ekanligiga ishonish mumkin emas.
    /// Agar future qo'shimchalari kutilsa, `reserve`-ni afzal ko'rsating.
    ///
    /// # Panics
    ///
    /// Agar yangi quvvat `usize` dan oshib ketsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Ushbu `Vec<T>`-ga kamida kamida `additional` element kiritish uchun imkoniyatni zaxiralashga harakat qiladi.
    /// To'plam tez-tez qayta taqsimlanishiga yo'l qo'ymaslik uchun ko'proq joy ajratishi mumkin.
    /// `try_reserve`-ni chaqirgandan so'ng, imkoniyat `self.len() + additional`-dan katta yoki unga teng bo'ladi.
    /// Imkoniyatlar allaqachon etarli bo'lsa, hech narsa qilmaydi.
    ///
    /// # Errors
    ///
    /// Agar imkoniyatlar oshib ketsa yoki ajratuvchi xato haqida xabar bersa, unda xato qaytariladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Xotirani oldindan zaxiralash, agar imkonimiz bo'lmasa, chiqish
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Endi biz buni bilamiz OOM bizning murakkab ishimiz o'rtasida
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // juda murakkab
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Berilgan `Vec<T>`-ga aniq `additional` elementlarini kiritish uchun minimal quvvatni saqlashga harakat qiladi.
    /// `try_reserve_exact`-ni chaqirgandan so'ng, agar u `Ok(())`-ni qaytarsa, imkoniyat `self.len() + additional`-dan katta yoki unga teng bo'ladi.
    ///
    /// Imkoniyatlar allaqachon etarli bo'lsa, hech narsa qilmaydi.
    ///
    /// E'tibor bering, ajratuvchi kollektsiyaga so'raganidan ko'ra ko'proq joy berishi mumkin.
    /// Shuning uchun, imkoniyatlarning aniq minimal ekanligiga ishonish mumkin emas.
    /// Agar future qo'shimchalari kutilsa, `reserve`-ni afzal ko'rsating.
    ///
    /// # Errors
    ///
    /// Agar imkoniyatlar oshib ketsa yoki ajratuvchi xato haqida xabar bersa, unda xato qaytariladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Xotirani oldindan zaxiralash, agar imkonimiz bo'lmasa, chiqish
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Endi biz buni bilamiz OOM bizning murakkab ishimiz o'rtasida
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // juda murakkab
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// vector quvvatini iloji boricha qisqartiradi.
    ///
    /// U uzunlikka imkon qadar yaqinroq tushadi, lekin ajratuvchi yana bir nechta elementlar uchun joy borligini vector-ga etkazishi mumkin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Imkoniyat hech qachon uzunlikdan kam bo'lmaydi va ular teng bo'lganda hech narsa qilish mumkin emas, shuning uchun biz `RawVec::shrink_to_fit`-dagi panic ishini faqat katta quvvat bilan chaqirish orqali oldini olishimiz mumkin.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// vector quvvatini pastki chegarasi bilan kamaytiradi.
    ///
    /// Imkoniyat kamida uzunlik va ta'minlangan qiymat kabi katta bo'lib qoladi.
    ///
    ///
    /// Agar hozirgi quvvati pastki chegaradan kam bo'lsa, bu no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector-ni [`Box<[T]>`][owned slice] ga o'zgartiradi.
    ///
    /// E'tibor bering, bu ortiqcha quvvatni pasaytiradi.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Har qanday ortiqcha imkoniyat o'chiriladi:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Birinchi `len` elementlarini saqlab, qolganlarini tashlab, vector-ni qisqartiradi.
    ///
    /// Agar `len` vector ning joriy uzunligidan katta bo'lsa, bu hech qanday ta'sir qilmaydi.
    ///
    /// [`drain`] usuli `truncate` ni taqlid qilishi mumkin, ammo ortiqcha elementlarning tushishi o'rniga qaytarilishiga olib keladi.
    ///
    ///
    /// Ushbu usul vector ning ajratilgan quvvatiga ta'sir qilmasligini unutmang.
    ///
    /// # Examples
    ///
    /// Beshta vector elementini ikkita elementga qisqartirish:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// `len` vector ning joriy uzunligidan kattaroq bo'lganda kesilish bo'lmaydi:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// `len == 0` [`clear`] usulini chaqirishga teng bo'lganda qisqartirish.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Bu xavfsiz, chunki:
        //
        // * `drop_in_place`-ga uzatilgan tilim amal qiladi;`len > self.len` ishi yaroqsiz bo'lak yaratishni oldini oladi va
        // * vector-ning `len`-si `drop_in_place`-ga qo'ng'iroq qilishdan oldin qisqaradi, chunki `drop_in_place` panic-ga bir marta tushganda hech qanday qiymat ikki baravar kamaymaydi (agar u panics-dan ikki marta bo'lsa, dastur bekor qilinadi).
        //
        //
        //
        unsafe {
            // Note: Bu `>=` emas, balki `>` ekanligi atayin.
            //       Uni `>=` ga o'zgartirish ba'zi holatlarda ishlashning salbiy oqibatlarini keltirib chiqaradi.
            //       Qo'shimcha ma'lumot olish uchun #78884-ga qarang.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Butun vector o'z ichiga olgan bo'lakni chiqaradi.
    ///
    /// `&s[..]` ga teng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Butun vector ning o'zgaruvchan bo'lagini chiqaradi.
    ///
    /// `&mut s[..]` ga teng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// X0 ko'rsatkichini vector buferiga qaytaradi.
    ///
    /// Qo'ng'iroq qiluvchi vector ko'rsatkichining ushbu funktsiyani qaytarishini ta'minlashi kerak, aks holda u axlatga ishora qiladi.
    /// vector-ni o'zgartirish uning buferini qayta taqsimlanishiga olib kelishi mumkin, bu esa unga ko'rsatgichlarni bekor qiladi.
    ///
    /// Qo'ng'iroq qiluvchi shuningdek, (non-transitively) ko'rsatgichi ko'rsatgan xotiraning ushbu ko'rsatgich yoki undan olingan har qanday ko'rsatgich yordamida hech qachon (`UnsafeCell` ichkarisida) yozilmasligini ta'minlashi kerak.
    /// Agar tilim tarkibini mutatsiyalash kerak bo'lsa, [`as_mut_ptr`] dan foydalaning.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Biz `deref` orqali o'tmaslik uchun bir xil nomdagi bo'lak usulini soya qilamiz, bu esa oraliq ma'lumotnoma hosil qiladi.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Xavfsiz o'zgaruvchan ko'rsatkichni vector buferiga qaytaradi.
    ///
    /// Qo'ng'iroq qiluvchi vector ko'rsatkichining ushbu funktsiyani qaytarishini ta'minlashi kerak, aks holda u axlatga ishora qiladi.
    ///
    /// vector-ni o'zgartirish uning buferini qayta taqsimlanishiga olib kelishi mumkin, bu esa unga ko'rsatgichlarni bekor qiladi.
    ///
    /// # Examples
    ///
    /// ```
    /// // 4 element uchun etarlicha katta vector-ni ajrating.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Elementlarni xom ko'rsatgich yozuvlari orqali boshlang, so'ngra uzunlikni o'rnating.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Biz `deref_mut` orqali o'tmaslik uchun bir xil nomdagi bo'lak usulini soya qilamiz, bu esa oraliq ma'lumotnoma hosil qiladi.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Asosiy ajratuvchiga havolani qaytaradi.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector uzunligini `new_len` ga majbur qiladi.
    ///
    /// Bu turdagi oddiy invariantlarning hech birini saqlamaydigan past darajadagi operatsiya.
    /// Odatda vector uzunligini o'zgartirish uning o'rniga [`truncate`], [`resize`], [`extend`] yoki [`clear`] kabi xavfsiz operatsiyalardan biri yordamida amalga oshiriladi.
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] dan kam yoki unga teng bo'lishi kerak.
    /// - `old_len..new_len`-dagi elementlarni boshlash kerak.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Ushbu usul vector boshqa kodlar uchun, xususan FFI orqali bufer bo'lib xizmat qiladigan holatlar uchun foydali bo'lishi mumkin:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Bu hujjat namunasi uchun minimal skelet;
    /// # // buni haqiqiy kutubxonaning boshlang'ich nuqtasi sifatida ishlatmang.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // FFI uslubining hujjatlari bo'yicha, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // XAVFSIZLIK: `deflateGetDictionary` `Z_OK` ni qaytarganda, quyidagilarni ushlab turadi:
    ///     // 1. `dict_length` elementlar ishga tushirildi.
    ///     // 2.
    ///     // `dict_length` <= (32_768) hajmi, bu `set_len` ni qo'ng'iroq qilish uchun xavfsiz qiladi.
    ///     unsafe {
    ///         // FFI qo'ng'iroqini amalga oshiring ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... va boshlang'ich hajmini yangilang.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Quyidagi misol ovozli bo'lsa ham, ichki vectors `set_len` chaqiruvidan oldin bo'shatilmaganligi sababli xotira oqishi mavjud:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` bo'sh, shuning uchun hech qanday elementni boshlash kerak emas.
    /// // 2. `0 <= capacity` har doim `capacity` nima bo'lishidan qat'iy nazar.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Odatda, bu erda tarkibni to'g'ri tushirish va shu sababli xotirani sızdırmamak uchun [`clear`] ishlatilishi mumkin.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Elementni vector dan olib tashlaydi va qaytaradi.
    ///
    /// Olib tashlangan element vector ning oxirgi elementi bilan almashtiriladi.
    ///
    /// Bu buyurtmani saqlamaydi, lekin O(1).
    ///
    /// # Panics
    ///
    /// Agar 0Panics, agar `index` chegaradan tashqarida bo'lsa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Biz self [indeks] ni oxirgi element bilan almashtiramiz.
            // E'tibor bering, agar yuqoridagi chegara tekshiruvi muvaffaqiyatli bo'lsa, oxirgi element bo'lishi kerak (u o'zini o'zi [indeks] o'zi bo'lishi mumkin).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// vector ichida `index` holatiga element kiritadi, undan keyin barcha elementlarni o'ng tomonga siljitadi.
    ///
    ///
    /// # Panics
    ///
    /// Agar `index > len` bo'lsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // yangi element uchun joy
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // xatosiz yangi qiymatni qo'yish joyi
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Joy bo'shatish uchun hamma narsani o'zgartiring.
                // ("Index`th" elementini ketma-ket ikkita joyga takrorlash.)
                ptr::copy(p, p.offset(1), len - index);
                // Uni "index`th" elementining birinchi nusxasini yozib yozing.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Elementni vector ichidagi `index` holatida olib tashlaydi va qaytaradi, keyin barcha elementlarni chapga siljitadi.
    ///
    ///
    /// # Panics
    ///
    /// Agar 0Panics, agar `index` chegaradan tashqarida bo'lsa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // biz olib borayotgan joy.
                let ptr = self.as_mut_ptr().add(index);
                // nusxa ko'chiring, bir vaqtning o'zida to'plamdagi va vector-dagi qiymat nusxasi xavfli.
                //
                ret = ptr::read(ptr);

                // Ushbu joyni to'ldirish uchun hamma narsani pastga siljiting.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Faqat predikat tomonidan ko'rsatilgan elementlarni saqlab qoladi.
    ///
    /// Boshqacha qilib aytganda, `e` barcha elementlarini olib tashlang, shunda `f(&e)` `false` ni qaytaradi.
    /// Ushbu usul o'z o'rnida ishlaydi, har bir elementga asl tartibda to'liq bir marta tashrif buyuradi va saqlanib qolgan elementlarning tartibini saqlaydi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Elementlarga dastlabki tartibda aynan bir marta tashrif buyurilganligi sababli, qaysi elementlarni saqlash kerakligini hal qilish uchun tashqi holatdan foydalanish mumkin.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Agar tomchi qo'riqchi bajarilmasa, ikki marta tushishdan saqlaning, chunki jarayon davomida ba'zi teshiklar paydo bo'lishi mumkin.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-qayta ishlangan len-> |^-tekshirish yonida
        //                  | <-o'chirilgan cnt-> |
        //      | <-original_len-> |Qo'llab-quvvatlanadigan narsa: predikatni aniqlaydigan elementlar haqiqiy bo'ladi.
        //
        // Teshik: ko'chirilgan yoki tushirilgan elementlar uyasi.
        // Belgilanmagan: Tekshirilmagan yaroqli elementlar.
        //
        // Ushbu tomchi qo'riqchi predikat yoki `drop` elementi vahimaga tushganda chaqiriladi.
        // Teshiklarni yopish uchun tekshirilmagan elementlarni siljitadi va `set_len` to'g'ri uzunlikka.
        // Agar predikat va `drop` hech qachon vahimaga tushmasa, u optimallashtiriladi.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // XAVFSIZLIK: Tekshirilmagan elementlar amal qilishi kerak, chunki biz ularga hech qachon tegmaymiz.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // XAVFSIZLIK: Teshiklarni to'ldirgandan so'ng, barcha narsalar qo'shni xotirada.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // XAVFSIZLIK: Belgilanmagan element haqiqiy bo'lishi kerak.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Agar `drop_in_place` vahimaga tushgan bo'lsa, er-xotin tushishining oldini olish uchun oldindan avans qiling.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // XAVFSIZLIK: Yiqilganidan keyin biz ushbu elementga boshqa tegmaymiz.
                unsafe { ptr::drop_in_place(cur) };
                // Biz allaqachon hisoblagichni oldik.
                continue;
            }
            if g.deleted_cnt > 0 {
                // XAVFSIZLIK: `deleted_cnt`> 0, shuning uchun teshik teshigi joriy element bilan qoplanmasligi kerak.
                // Ko'chirish uchun nusxadan foydalanamiz va bu elementga boshqa tegmang.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Barcha buyumlar qayta ishlanadi.Buni LLVM tomonidan `set_len`-ga optimallashtirish mumkin.
        drop(g);
    }

    /// Xuddi shu tugmachani echadigan vector-ning ketma-ket birinchi elementlaridan boshqasini o'chiradi.
    ///
    ///
    /// Agar vector tartiblangan bo'lsa, bu barcha dublikatlarni olib tashlaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Berilgan tenglik munosabatini qondiradigan vector tarkibidagi ketma-ket birinchi elementlardan boshqasini olib tashlaydi.
    ///
    /// `same_bucket` funktsiyasi vector-dan ikkita elementga havolalar yuboriladi va elementlarning teng taqqoslanishini aniqlashi kerak.
    /// Elementlar tilimdagi tartibidan qarama-qarshi tartibda uzatiladi, shuning uchun `same_bucket(a, b)` `true` ni qaytarsa, `a` o'chiriladi.
    ///
    ///
    /// Agar vector tartiblangan bo'lsa, bu barcha dublikatlarni olib tashlaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// To'plamning orqa qismiga element qo'shadi.
    ///
    /// # Panics
    ///
    /// Agar yangi quvvat `isize::MAX` baytdan oshsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Agar biz> isize::MAX bayt ajratadigan bo'lsak yoki nol o'lchovli turlar uchun uzunlik oshib ketadigan bo'lsa, bu panic yoki bekor qiladi.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// vector-dan so'nggi elementni olib tashlaydi va agar u bo'sh bo'lsa, [`None`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other`-ning barcha elementlarini `Self`-ga o'tkazadi va `other`-ni bo'sh qoldiradi.
    ///
    /// # Panics
    ///
    /// Agar vector elementlari soni `usize` dan oshib ketsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// `Self`-ga boshqa buferdan elementlarni qo'shadi.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// vector-da belgilangan oraliqni olib tashlaydigan va olib tashlangan narsalarni beradigan drenajlovchi iteratorni yaratadi.
    ///
    /// Takrorlovchi **tushirilganda**, oraliqdagi barcha elementlar vector dan o'chiriladi, hatto iterator to'liq iste'mol qilinmagan bo'lsa ham.
    /// Agar iterator **tushmasa**(masalan, [`mem::forget`] bilan), qancha element olib tashlanganligi aniqlanmagan.
    ///
    /// # Panics
    ///
    /// Agar boshlang'ich nuqtasi so'nggi nuqtadan katta bo'lsa yoki oxirgi nuqta vektor uzunligidan katta bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // To'liq diapazon vector-ni tozalaydi
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Xotira xavfsizligi
        //
        // Drain birinchi marta yaratilganida, agar Drain destruktori hech qachon ishga tushmasa, unda boshlanmagan yoki ko'chirilgan elementlarga umuman kirish mumkin emasligiga ishonch hosil qilish uchun vector manbasini qisqartiradi.
        //
        //
        // Drain olib tashlash uchun qiymatlarni ptr::read qiladi.
        // Tugatgandan so'ng, vecning qolgan quyruq qismi teshikni qoplash uchun ko'chiriladi va vector uzunligi yangi uzunlikka tiklanadi.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // self.vec uzunligini ishga tushiring, Drain chiqib ketganda xavfsiz bo'lsin
            self.set_len(start);
            // IterMut-dagi qarzni butun Drain iteratorining (&mut T kabi) xatti-harakatlarini ko'rsatish uchun foydalaning.
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Barcha qiymatlarni olib tashlagan holda vector-ni tozalaydi.
    ///
    /// Ushbu usul vector ning ajratilgan quvvatiga ta'sir qilmasligini unutmang.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// vector-dagi elementlarning sonini qaytaradi, shuningdek uning 'length' deb nomlanadi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Agar vector elementlari bo'lmasa, `true`-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// To'plamni berilgan indeks bo'yicha ikkiga bo'linadi.
    ///
    /// `[at, len)` diapazonidagi elementlarni o'z ichiga olgan yangi ajratilgan vector-ni qaytaradi.
    /// Qo'ng'iroqdan so'ng asl vector avvalgi quvvati o'zgarmagan holda `[0, at)` elementlarini o'z ichiga oladi.
    ///
    ///
    /// # Panics
    ///
    /// Agar `at > len` bo'lsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // yangi vector asl tamponni egallashi va nusxasini olishdan qochishi mumkin
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len`-ni xavfli va `other`-ga nusxa ko'chiring.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec` o'rnini o'zgartiradi, shunda `len` `new_len` ga teng bo'ladi.
    ///
    /// Agar `new_len` `len` dan katta bo'lsa, `Vec` farq bilan kengaytiriladi, har bir qo'shimcha uyasi `f` yopilishini chaqirish natijasi bilan to'ldiriladi.
    ///
    /// `f`-dan qaytish qiymatlari hosil bo'lgan tartibda `Vec`-da tugaydi.
    ///
    /// Agar `new_len` `len` dan kichik bo'lsa, `Vec` shunchaki qisqartiriladi.
    ///
    /// Ushbu usul har bir bosishda yangi qiymatlarni yaratish uchun yopilishdan foydalanadi.Agar siz [`Clone`] berilgan qiymatini xohlasangiz, [`Vec::resize`] dan foydalaning.
    /// Agar siz qiymatlarni yaratish uchun [`Default`] trait dan foydalanmoqchi bo'lsangiz, siz ikkinchi argument sifatida [`Default::default`] ni o'tkazishingiz mumkin.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` ni iste'mol qiladi va oqadi, tarkibidagi o'zgaruvchan ma'lumotni qaytaradi, `&'a mut [T]`.
    /// Shuni esda tutingki, `T` turi tanlangan umr ko'rish muddati `'a` dan oshishi kerak.
    /// Agar turda faqat statik ma'lumot mavjud bo'lsa yoki umuman yo'q bo'lsa, u holda `'static` sifatida tanlanishi mumkin.
    ///
    /// Ushbu funktsiya [`Box`]-dagi [`leak`][Box::leak] funktsiyasiga o'xshaydi, faqat sızdırılan xotirani tiklashning imkoni yo'q.
    ///
    ///
    /// Ushbu funktsiya asosan dastur umrining qolgan qismida ishlaydigan ma'lumotlar uchun foydalidir.
    /// Qaytgan ma'lumotnomani tashlash xotira sızıntısına olib keladi.
    ///
    /// # Examples
    ///
    /// Oddiy foydalanish:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector ning qolgan zaxira quvvatini `MaybeUninit<T>` bo'lagi sifatida qaytaradi.
    ///
    /// Qaytgan tilim vector-ni ma'lumotlar bilan to'ldirish uchun ishlatilishi mumkin (masalan,
    /// ma'lumotni [`set_len`] usuli yordamida boshlangan deb belgilashdan oldin).
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // 10 ta element uchun etarlicha katta vector-ni ajrating.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Dastlabki 3 elementni to'ldiring.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // vector ning dastlabki 3 ta elementini boshlang'ich sifatida belgilang.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Buferga ko'rsatgichlarni yaroqsizligini oldini olish uchun ushbu usul `split_at_spare_mut` bo'yicha qo'llanilmagan.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector tarkibini `T` bo'lagi sifatida, vector ning qolgan zaxira hajmi bilan `MaybeUninit<T>` bo'lagi sifatida qaytaradi.
    ///
    /// Qaytgan zaxira quvvati bo'limi ma'lumotni [`set_len`] usuli yordamida boshlang'ich sifatida belgilashdan oldin vector-ni ma'lumotlar bilan to'ldirish uchun ishlatilishi mumkin (masalan, faylni o'qish orqali).
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// E'tibor bering, bu past darajadagi API, uni optimallashtirish uchun ehtiyotkorlik bilan ishlatish kerak.
    /// Agar `Vec`-ga ma'lumot qo'shishingiz kerak bo'lsa, sizning aniq ehtiyojlaringizga qarab [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] yoki [`resize_with`] dan foydalanishingiz mumkin.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // 10 ta element uchun etarli bo'lgan qo'shimcha joyni zaxiralash.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Keyingi 4 elementni to'ldiring.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Boshlang'ich sifatida vector ning 4 ta elementini belgilang.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len e'tiborga olinmaydi va shuning uchun hech qachon o'zgartirilmaydi
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Xavfsizlik: qaytarilgan .2 (&mut usize) o'zgarishi `.set_len(_)` ga qo'ng'iroq qilish bilan bir xil hisoblanadi.
    ///
    /// Ushbu usul `extend_from_within`-da bir vaqtning o'zida barcha vec qismlariga noyob kirish huquqiga ega bo'lish uchun ishlatiladi.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` elementlari uchun amal qilishiga kafolat beriladi
        // - `spare_ptr` bir elementni buferdan o'tqazmoqda, shuning uchun u `initialized` bilan mos kelmaydi
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec` o'rnini o'zgartiradi, shunda `len` `new_len` ga teng bo'ladi.
    ///
    /// Agar `new_len` `len` dan katta bo'lsa, `Vec` farq bilan kengaytiriladi, har bir qo'shimcha uyasi `value` bilan to'ldiriladi.
    ///
    /// Agar `new_len` `len` dan kichik bo'lsa, `Vec` shunchaki qisqartiriladi.
    ///
    /// Ushbu usul o'tkazilgan qiymatni klonlash imkoniyatiga ega bo'lish uchun [`Clone`] ni amalga oshirishni talab qiladi.
    /// Agar sizga ko'proq moslashuvchanlik kerak bo'lsa (yoki [`Clone`] o'rniga [`Default`] ga ishonishni xohlasangiz), [`Vec::resize_with`] dan foydalaning.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Barcha elementlarni klonlaydi va tilimga `Vec` ga qo'shadi.
    ///
    /// `other` bo'lagi ustida takrorlanadi, har bir elementni klonlaydi va keyin uni shu `Vec` ga qo'shadi.
    /// `other` vector tartibda harakatlanadi.
    ///
    /// Ushbu funktsiya [`extend`] bilan bir xil ekanligini unutmang, faqat uning o'rniga tilim bilan ishlashga ixtisoslashgan.
    ///
    /// Agar va qachon Rust ixtisoslashsa, bu funktsiya eskirgan bo'lishi mumkin (lekin hali ham mavjud).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` elementlaridan vector oxirigacha nusxa ko'chiradi.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` berilgan diapazon o'zini indekslash uchun yaroqliligini kafolatlaydi
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Ushbu kod `extend_with_{element,default}`-ni umumlashtiradi.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Berilgan generator yordamida vector-ni `n` qiymatlari bo'yicha kengaytiring.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Kompilyator do'konni `ptr` orqali self.set_len() orqali amalga oshirmasligi mumkin bo'lgan xatolarni hal qilish uchun SetLenOnDrop-dan foydalaning.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Oxirgisidan tashqari barcha elementlarni yozing
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics holatida har bir qadamda uzunlikni oshiring
                local_len.increment_len(1);
            }

            if n > 0 {
                // Biz oxirgi elementni keraksiz klonlashsiz to'g'ridan-to'g'ri yozishimiz mumkin
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len qamrov qo'riqchisi tomonidan o'rnatildi
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait dasturiga muvofiq vector-da ketma-ket takrorlangan elementlarni olib tashlaydi.
    ///
    ///
    /// Agar vector tartiblangan bo'lsa, bu barcha dublikatlarni olib tashlaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ichki usullar va funktsiyalar
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` to'g'ri indeks bo'lishi kerak
    /// - `self.capacity() - self.len()` `>= src.len()` bo'lishi kerak
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len faqat elementlarni ishga tushirgandan so'ng oshiriladi
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - qo'ng'iroq qiluvchining src to'g'ri indeks ekanligi to'g'risida guvohlik beradi
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element faqat `MaybeUninit::write` bilan ishga tushirildi, shuning uchun len-ni oshirish yaxshi
            // - Oqishning oldini olish uchun har bir elementdan keyin len oshiriladi (#82533 soniga qarang)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - qo'ng'iroq qiluvchining `src` to'g'ri indeks ekanligini kafolatlaydi
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Ikkala ko'rsatgich ham noyob tilim havolalaridan ("&mut [_]") yaratilgan, shuning uchun ular amal qiladi va bir-birining ustiga chiqmaydi.
            //
            // - Elementlar quyidagilardir: Nusxalash, shuning uchun ularni asl qiymatlari bilan hech narsa qilmasdan nusxalash yaxshi bo'ladi
            // - `count` `source` leniga teng, shuning uchun `count` o'qish uchun manba amal qiladi
            // - `.reserve(count)` `spare.len() >= count`-ning zaxira nusxasi `count` yozuvlari uchun amal qilishiga kafolat beradi
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Elementlar `copy_nonoverlapping` tomonidan ishga tushirilgan
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vec uchun umumiy trait dasturlari
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) bilan ushbu usul ta'rifi uchun zarur bo'lgan o'ziga xos `[T]::to_vec` usuli mavjud emas.
    // Buning o'rniga faqat cfg(test) NB bilan ishlaydigan `slice::to_vec` funktsiyasidan foydalaning. Qo'shimcha ma'lumot olish uchun slice.rs-dagi slice::hack moduliga qarang
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // ustiga yozib bo'lmaydigan narsalarni tashlab qo'ying
        self.truncate(other.len());

        // self.len Yuqoridagi kesilganligi sababli <= other.len, shuning uchun bu erdagi bo'laklar har doim chegarada.
        //
        let (init, tail) = other.split_at(self.len());

        // allocations/resources qiymatlarini qayta ishlating.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Iste'mol qiluvchi iteratorni yaratadi, ya'ni har bir qiymatni vector-dan chiqaradigan (boshidan oxirigacha).
    /// Bunga qo'ng'iroq qilgandan keyin vector ishlatib bo'lmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // ning &String emas, balki String turi mavjud
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // turli xil SpecFrom/SpecExtend dasturlari optimallashtirishga hojat qolmasa, vakolat beradigan barg usuli
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Bu umumiy iterator uchun holat.
        //
        // Ushbu funktsiya quyidagilarning axloqiy ekvivalenti bo'lishi kerak.
        //
        //      iterator tarkibidagi element uchun {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB to'la olmaydi, chunki biz manzil maydonini ajratishimiz kerak edi
                self.set_len(len + 1);
            }
        }
    }

    /// vector-da ko'rsatilgan diapazonni berilgan `replace_with` iterator bilan almashtiradigan va olib tashlangan elementlarni beradigan qo'shish iteratorini yaratadi.
    ///
    /// `replace_with` uzunligi `range` bilan bir xil bo'lishi shart emas.
    ///
    /// `range` iterator oxirigacha iste'mol qilinmasa ham olib tashlanadi.
    ///
    /// Agar `Splice` qiymati chiqib ketgan bo'lsa, vector-dan qancha element chiqarilishi aniqlanmagan.
    ///
    /// `replace_with` kirish iteratori faqat `Splice` qiymati tushganda iste'mol qilinadi.
    ///
    /// Bu maqbul, agar:
    ///
    /// * Quyruq (`range` dan keyin vector dagi elementlar) bo'sh,
    /// * yoki `replace_with` "diapazon" uzunligidan kamroq yoki teng elementlarni beradi
    /// * yoki uning `size_hint()` ning pastki chegarasi aniq.
    ///
    /// Aks holda, vaqtinchalik vector ajratiladi va dum ikki marta siljiydi.
    ///
    /// # Panics
    ///
    /// Agar boshlang'ich nuqtasi so'nggi nuqtadan katta bo'lsa yoki oxirgi nuqta vektor uzunligidan katta bo'lsa, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Elementni olib tashlash kerakligini aniqlash uchun yopilishdan foydalanadigan iterator yaratadi.
    ///
    /// Agar yopilish to'g'ri bo'lsa, u holda element o'chiriladi va hosil bo'ladi.
    /// Agar yopilish noto'g'ri bo'lsa, element vector-da qoladi va takrorlovchi tomonidan berilmaydi.
    ///
    /// Ushbu usuldan foydalanish quyidagi kodga teng:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // sizning kodingiz bu erda
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Ammo `drain_filter`-dan foydalanish osonroq.
    /// `drain_filter` Bundan tashqari, u yanada samaraliroqdir, chunki u massiv elementlarini ommaviy ravishda o'zgartirishi mumkin.
    ///
    /// Shuni esda tutingki, `drain_filter` filtrni yopishdagi yoki olib tashlaganingizdan qat'i nazar, filtr yopilishidagi barcha elementlarni mutatsiyalashga imkon beradi.
    ///
    ///
    /// # Examples
    ///
    /// Dastlabki taqsimotni qayta ishlatib, massivni tenglik va koeffitsientlarga bo'lish.
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Bizni fosh bo'lishimizdan saqlang (qochqinni kuchaytirish)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Vec-ga surishdan oldin elementlarni havolalardan nusxa ko'chiradigan dasturni kengaytiring.
///
/// Ushbu dastur tilim iteratorlari uchun ixtisoslashgan bo'lib, u erda butun tilimni bir vaqtning o'zida qo'shish uchun [`copy_from_slice`] ishlatiladi.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors ni taqqoslashni amalga oshiradi, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors buyurtmalarini amalga oshiradi, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T] uchun tomchidan foydalanish vector elementlarini eng zaif zarurat deb atash uchun xom dilimdan foydalaning;
            //
            // ba'zi hollarda haqiqiyligi haqidagi savollardan qochishi mumkin
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec ajratishni boshqaradi
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Bo'sh `Vec<T>` yaratadi.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test bu erda xatolarni keltirib chiqaradigan libstd-ni tortadi
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test bu erda xatolarni keltirib chiqaradigan libstd-ni tortadi
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Agar uning hajmi so'ralgan qatorga to'liq mos keladigan bo'lsa, `Vec<T>` tarkibini butun qator sifatida oladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Agar uzunlik mos kelmasa, kirish `Err`-ga qaytadi:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Agar siz `Vec<T>` prefiksini olishni yaxshi bilsangiz, avval [`.truncate(N)`](Vec::truncate) raqamiga qo'ng'iroq qilishingiz mumkin.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // XAVFSIZLIK: `.set_len(0)` har doim yaxshi ishlaydi.
        unsafe { vec.set_len(0) };

        // XAVFSIZLIK: A "Vec" ko'rsatkichi har doim to'g'ri hizalanadi va
        // qator kerak bo'lgan hizalama elementlar bilan bir xil.
        // Bizda yetarlicha narsalar borligini oldinroq tekshirib ko'rdik.
        // Ob'ektlar ikki marta tushmaydi, chunki `set_len` `Vec`-ga ularni tashlamaslikni aytadi.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}