use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter uchun ishlatiladigan trait ixtisosligi
///
/// ## Delegatsiya grafigi:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Odatda vector-ga qayta yig'iladigan funktsiyaga o'tish vector.
        // Agar IntoIter umuman rivojlanmagan bo'lsa, biz buni qisqa tutashuvga olib kelishimiz mumkin.
        // U rivojlangan bo'lsa, biz xotirani qayta ishlatishimiz va ma'lumotlarni old tomonga ko'chirishimiz mumkin.
        // Ammo biz buni faqatgina Vec umumiy FromIterator dasturi orqali yaratishdan ko'ra ko'proq foydalanilmaydigan imkoniyatlarga ega bo'lmaganda amalga oshiramiz.
        //
        // Ushbu cheklash qat'iyan zarur emas, chunki Vec-ning ajratish harakati qasddan aniqlanmagan.
        // Ammo bu konservativ tanlovdir.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // spec_extend() ga vakolat berishi kerak, chunki extend() o'zi bo'sh Vecs uchun spec_from-ga vakolat beradi
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Bu `iterator.as_slice().to_vec()`-dan foydalanadi, chunki spec_extend yakuniy quvvati + uzunligi haqida mulohaza yuritish uchun ko'proq qadamlar qo'yishi va shu bilan ko'proq ish qilishi kerak.
// `to_vec()` to'g'ridan-to'g'ri to'g'ri miqdorni ajratadi va uni to'liq to'ldiradi.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) bilan ushbu usul ta'rifi uchun zarur bo'lgan o'ziga xos `[T]::to_vec` usuli mavjud emas.
    // Buning o'rniga faqat cfg(test) NB bilan ishlaydigan `slice::to_vec` funktsiyasidan foydalaning. Qo'shimcha ma'lumot olish uchun slice.rs-dagi slice::hack moduliga qarang
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}