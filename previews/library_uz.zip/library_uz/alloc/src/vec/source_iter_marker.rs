use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Manba ajratilishini qayta ishlatishda iterator quvurini Vec-ga yig'ish uchun ixtisoslashgan marker, ya'ni
/// quvur liniyasini joyida bajarish.
///
/// SourceIter ota-onasi trait ixtisoslashtirilgan funktsiya uchun qayta ishlatilishi kerak bo'lgan ajratishga kirish uchun zarurdir.
/// Ammo mutaxassislikning amal qilishi etarli emas.
/// Imllning qo'shimcha chegaralarini ko'ring.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-ichki SourceIter/InPlaceIterable traits faqat adapter zanjirlari tomonidan amalga oshiriladi. <Adapter<Adapter<IntoIter>>> (barchasi core/std-ga tegishli).
// Adapter dasturlarining qo'shimcha chegaralari (`impl<I: Trait> Trait for Adapter<I>` dan tashqari) faqat traits ixtisoslashuvi sifatida belgilangan boshqa traits-ga bog'liq (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. marker foydalanuvchi tomonidan taqdim etilgan turlarning umr ko'rish vaqtiga bog'liq emas.Bir nechta boshqa ixtisosliklar allaqachon bog'liq bo'lgan Nusxa ko'chirish moduli.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bounds orqali ifodalanmaydigan qo'shimcha talablar.Buning o'rniga const eval-ga ishonamiz:
        // a) ZST yo'q, chunki uni qayta ishlatish uchun ajratish bo'lmaydi va ko'rsatkich arifmetikasi panic b) o'lchamlari Alloc shartnomasi talabiga mos keladi; c) hizalamalar Alloc shartnomasi talablariga mos keladi
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // ko'proq umumiy dasturlarga qaytish
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // beri ishlatib ko'ring
        // - ba'zi iterator adapterlari uchun yaxshiroq vektorlashtiriladi
        // - aksariyat ichki takrorlash usullaridan farqli o'laroq, bu faqat &mut o'zini o'zi oladi
        // - bu bizga yozish ko'rsatkichini ichki tomonlari orqali o'tkazib, oxirida qaytarib olishimizga imkon beradi
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteratsiya muvaffaqiyatli bo'ldi, boshingizni tushirmang
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // SourceIter shartnomasi ogohlantiriladimi yoki yo'qligini tekshirib ko'ring: agar ular bo'lmasa, biz hattoki ushbu nuqtaga ham etib bormaymiz
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIterable shartnomasini tekshiring.Bu faqat iterator manba ko'rsatgichini umuman rivojlantirgan taqdirdagina mumkin.
        // Agar u TrustedRandomAccess orqali tekshirilmagan kirishni ishlatsa, manba ko'rsatgichi dastlabki holatida qoladi va biz uni mos yozuvlar sifatida ishlata olmaymiz
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // qolgan qiymatlarni manba dumiga tushiring, lekin agar IntoIter agar panics tushishi bo'lsa, u holda biz ham dst_buf-ga to'plangan har qanday elementni tashlaymiz.
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable shartnomasini bu erda aniq tekshirish mumkin emas, chunki try_fold manba ko'rsatgichiga eksklyuziv havolaga ega, biz qila oladigan narsa-bu uning hali ham mavjudligini tekshirish.
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}