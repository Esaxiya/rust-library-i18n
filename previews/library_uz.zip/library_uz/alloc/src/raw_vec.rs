#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Yangi xotira tarkibi initsializatsiya qilinmagan.
    Uninitialized,
    /// Yangi xotira nolga tenglashtirilishi kafolatlangan.
    Zeroed,
}

/// Xotira tamponini ergonomik ravishda ko'proq taqsimlash, qayta taqsimlash va yig'ish uchun ajratish uchun past darajadagi yordamchi dastur barcha tegishli ishlarni tashvishga solmasdan.
///
/// Ushbu turdagi Vec va VecDeque kabi ma'lumotlar tuzilmalarini yaratish uchun juda yaxshi.
/// Ayniqsa:
///
/// * N00 o'lchamdagi turdagi `Unique::dangling()` ishlab chiqaradi.
/// * Nol uzunlikdagi ajratmalar bo'yicha `Unique::dangling()` ishlab chiqaradi.
/// * `Unique::dangling()`-ni bo'shatishdan qochadi.
/// * Imkoniyatlarni hisoblashda barcha toshqinlarni ushlaydi (ularni "capacity overflow" panics darajasiga ko'taradi).
/// * isize::MAX baytdan ko'proq ajratadigan 32-bitli tizimlarga qarshi himoya.
/// * Sizning uzunligingizdan oshib ketishdan saqlovchi.
/// * Noto'g'ri ajratmalar uchun `handle_alloc_error`-ga qo'ng'iroq qiladi.
/// * `ptr::Unique`-ni o'z ichiga oladi va shu bilan foydalanuvchiga barcha tegishli imtiyozlarni beradi.
/// * Mavjud bo'lgan eng katta quvvatdan foydalanish uchun ajratuvchidan qaytarilgan ortiqcha narsadan foydalanadi.
///
/// Ushbu tur baribir o'zi boshqaradigan xotirani tekshirmaydi.Tushirilganda *uning* xotirasi bo'shaydi, lekin u *tarkibini tushirishga* urinmaydi.
/// `RawVec` ichida *saqlangan* haqiqiy narsalarni boshqarish `RawVec` foydalanuvchisiga bog'liq.
///
/// Shuni esda tutingki, nol o'lchovli turdagi ortiqcha har doim cheksizdir, shuning uchun `capacity()` har doim `usize::MAX` qaytaradi.
/// Bu shuni anglatadiki, ushbu turni `Box<[T]>` bilan o'chirishda ehtiyot bo'lishingiz kerak, chunki `capacity()` uzunlikni bermaydi.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Buning sababi shundaki, `#[unstable]` `const fn`s `min_const_fn` ga mos kelmasligi kerak va shuning uchun ularni"min_const_fn`s "da chaqirib bo'lmaydi.
    ///
    /// Agar siz `RawVec<T>::new` yoki bog'liqliklarni o'zgartirsangiz, iltimos, `min_const_fn` ni buzadigan narsalarni kiritmasligingizga e'tibor bering.
    ///
    /// NOTE: Biz ushbu buzg'unchilikdan qochishimiz va `min_const_fn` mosligini talab qiladigan ba'zi bir `#[rustc_force_min_const_fn]` atributlari bilan muvofiqligini tekshirib ko'rishimiz mumkin, lekin uni `stable(...) const fn`/foydalanuvchi kodida qo'ng'iroq qilishimiz shart emas, agar `#[rustc_const_unstable(feature = "foo", issue = "01234")]` mavjud bo'lsa, `foo` yoqilmaydi.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Mumkin bo'lgan eng katta `RawVec` ni (tizim uyumida) ajratmasdan yaratadi.
    /// Agar `T` ijobiy o'lchamga ega bo'lsa, u holda `0` hajmli `RawVec` bo'ladi.
    /// Agar `T` nolga teng bo'lsa, u `usize::MAX` hajmli `RawVec` qiladi.
    /// Kechiktirilgan ajratishni amalga oshirish uchun foydalidir.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` uchun to'liq quvvat va moslashtirish talablari bilan `RawVec` (tizim yig'indisida) yaratadi.
    /// Bu `capacity` `0` yoki `T` nolga teng bo'lganda `RawVec::new` chaqirishga teng.
    /// E'tibor bering, agar `T` nol o'lchovli bo'lsa, demak siz `RawVec` ni kerakli hajmga ega bo'lmaysiz.
    ///
    /// # Panics
    ///
    /// Agar so'ralgan hajm `isize::MAX` baytdan oshsa, Panics.
    ///
    /// # Aborts
    ///
    /// OOMda bekor qilinadi.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` singari, ammo bufer nolga tengligini kafolatlaydi.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// `RawVec`-ni ko'rsatkich va quvvatdan tiklaydi.
    ///
    /// # Safety
    ///
    /// `ptr` (tizim yig'indisida) va berilgan `capacity` bilan taqsimlanishi kerak.
    /// `capacity` o'lchamlari uchun `isize::MAX` dan oshmasligi kerak.(faqat 32 bitli tizimlarda tashvish).
    /// ZST vectors `usize::MAX` gacha bo'lgan quvvatga ega bo'lishi mumkin.
    /// Agar `ptr` va `capacity` `RawVec`-dan kelib chiqsa, unda bu kafolatlangan.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Kichkina Veclar soqov.O'tish:
    // - 8, agar elementning kattaligi 1 bo'lsa, chunki har qanday yig'uvchi ajratuvchi kamida 8 baytdan 8 baytgacha bo'lgan so'rovni yaxlitlashi mumkin.
    //
    // - 4 agar elementlar o'rtacha kattalikka ega bo'lsa (<=1 KiB).
    // - 1 aks holda, juda qisqa Veclar uchun juda ko'p joyni yo'qotmaslik uchun.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` singari, lekin qaytarilgan `RawVec` uchun ajratuvchi tanlovi bo'yicha parametrlangan.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" degan ma'noni anglatadi.nol o'lchamdagi turlarga e'tibor berilmaydi.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` singari, lekin qaytarilgan `RawVec` uchun ajratuvchi tanlovi bo'yicha parametrlangan.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` singari, lekin qaytarilgan `RawVec` uchun ajratuvchi tanlovi bo'yicha parametrlangan.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` ni `RawVec<T>` ga o'zgartiradi.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Belgilangan `len` bilan butun buferni `Box<[MaybeUninit<T>]>` ga o'zgartiradi.
    ///
    /// Shuni esda tutingki, bu amalga oshirilgan `cap` o'zgarishlarini to'g'ri tiklaydi.(Tafsilotlar uchun turdagi tavsifga qarang.)
    ///
    /// # Safety
    ///
    /// * `len` eng so'nggi so'ralgan quvvatdan katta yoki teng bo'lishi kerak va
    /// * `len` `self.capacity()` dan kam yoki unga teng bo'lishi kerak.
    ///
    /// Shuni esda tutingki, talab qilingan quvvat va `self.capacity()` har xil bo'lishi mumkin, chunki ajratuvchi haddan tashqari ajratishi va so'ralgandan kattaroq xotira blokini qaytarishi mumkin.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Xavfsizlik talablarining yarmini aql-idrok bilan tekshiring (ikkinchi yarmini tekshirolmaymiz).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Biz bu erda `unwrap_or_else` dan qochamiz, chunki u hosil bo'lgan LLVM IQ miqdorini shishiradi.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// `RawVec`-ni ko'rsatkich, quvvat va ajratgichdan tiklaydi.
    ///
    /// # Safety
    ///
    /// `ptr` ajratilishi kerak (berilgan `alloc` taqsimlovchisi orqali) va berilgan `capacity` bilan.
    /// `capacity` o'lchamlari uchun `isize::MAX` dan oshmasligi kerak.
    /// (faqat 32 bitli tizimlarda tashvish).
    /// ZST vectors `usize::MAX` gacha bo'lgan quvvatga ega bo'lishi mumkin.
    /// Agar `ptr` va `capacity` `alloc` orqali yaratilgan `RawVec` dan kelib chiqsa, unda bu kafolatlangan.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Ajratish boshlanishiga xom ko'rsatkichni oladi.
    /// Agar `capacity == 0` yoki `T` nol o'lchovli bo'lsa, bu `Unique::dangling()` ekanligini unutmang.
    /// Avvalgi holatda siz ehtiyot bo'lishingiz kerak.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Ajratish imkoniyatini oladi.
    ///
    /// `T` nolga teng bo'lsa, bu har doim `usize::MAX` bo'ladi.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Ushbu `RawVec`-ni qo'llab-quvvatlaydigan ajratuvchiga umumiy ma'lumotni qaytaradi.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Bizda ajratilgan xotira qismi mavjud, shuning uchun biz hozirgi tartibimizni olish uchun ish vaqtini tekshirishni chetlab o'tishimiz mumkin.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Buferda `len + additional` elementlarini saqlash uchun kamida bo'sh joy bo'lishini ta'minlaydi.
    /// Agar u allaqachon etarli imkoniyatga ega bo'lmasa, amortizatsiya qilingan *O*(1) xatti-harakatlarini bajarish uchun etarli joy va qulay bo'sh joyni qayta taqsimlaydi.
    ///
    /// Agar bu o'z-o'zidan panic ga olib kelsa, bu xatti-harakatni cheklaydi.
    ///
    /// Agar `len` `self.capacity()` dan oshsa, bu aslida so'ralgan joyni ajratib bermasligi mumkin.
    /// Bu haqiqatan ham xavfli emas, lekin ushbu funktsiya xulq-atvoriga bog'liq bo'lgan siz yozgan * xavfli kod buzilishi mumkin.
    ///
    /// Bu `extend` kabi ommaviy surish operatsiyasini amalga oshirish uchun juda mos keladi.
    ///
    /// # Panics
    ///
    /// Agar yangi quvvat `isize::MAX` baytdan oshsa, Panics.
    ///
    /// # Aborts
    ///
    /// OOMda bekor qilinadi.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // zveno len `isize::MAX` dan oshib ketgan bo'lsa bekor qilingan yoki vahimaga tushgan bo'lar edi, shuning uchun hozirda buni tekshirib bo'lmaydi.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` bilan bir xil, ammo vahima yoki abort qilish o'rniga xatolarni qaytaradi.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Buferda `len + additional` elementlarini saqlash uchun kamida bo'sh joy bo'lishini ta'minlaydi.
    /// Agar u allaqachon mavjud bo'lmasa, zarur bo'lgan minimal xotirani qayta taqsimlaydi.
    /// Odatda bu zarur bo'lgan xotira miqdori bo'ladi, lekin printsipial ravishda ajratuvchi biz so'raganidan ko'proq narsani qaytarib berishi mumkin.
    ///
    ///
    /// Agar `len` `self.capacity()` dan oshsa, bu aslida so'ralgan joyni ajratib bermasligi mumkin.
    /// Bu haqiqatan ham xavfli emas, lekin ushbu funktsiya xulq-atvoriga bog'liq bo'lgan siz yozgan * xavfli kod buzilishi mumkin.
    ///
    /// # Panics
    ///
    /// Agar yangi quvvat `isize::MAX` baytdan oshsa, Panics.
    ///
    /// # Aborts
    ///
    /// OOMda bekor qilinadi.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` bilan bir xil, ammo vahima yoki abort qilish o'rniga xatolarni qaytaradi.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Ajratishni belgilangan miqdorgacha qisqartiradi.
    /// Agar berilgan miqdor 0 bo'lsa, aslida butunlay taqsimlanadi.
    ///
    /// # Panics
    ///
    /// Agar berilgan miqdor joriy quvvatdan *kattaroq* bo'lsa, Panics.
    ///
    /// # Aborts
    ///
    /// OOMda bekor qilinadi.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Kerakli qo'shimcha quvvatni bajarish uchun bufer o'sishi kerak bo'lsa, qaytib keladi.
    /// `grow`-ni hisobga olmasdan turib zaxira qo'ng'iroqlarini amalga oshirish uchun asosan foydalaniladi.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ushbu usul odatda ko'p marta qo'zg'atilgan.Shunday qilib, biz iloji boricha kichikroq bo'lishini, kompilyatsiya vaqtlarini yaxshilashni xohlaymiz.
    // Shuningdek, biz tarkibidagi kodlarning tezroq ishlashini ta'minlash uchun tarkibidagi statik jihatdan iloji boricha ko'proq hisoblanishini istaymiz.
    // Shuning uchun, bu usul diqqat bilan yoziladi, shunda `T` ga bog'liq bo'lgan barcha kodlar uning ichida bo'ladi, `T` ga bog'liq bo'lmagan kodlarning ko'p qismi `T` dan umumiy bo'lmagan funktsiyalarda bo'ladi.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Bu chaqiruv kontekstlari bilan ta'minlanadi.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` bo'lganda biz `usize::MAX` hajmini qaytaramiz
            // 0, bu erga etib kelish, albatta, `RawVec` ning ortiqcha ekanligini anglatadi.
            return Err(CapacityOverflow);
        }

        // Afsuski, biz ushbu tekshiruvlar haqida hech narsa qila olmaymiz.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Bu eksponent o'sishni kafolatlaydi.
        // Ikki baravar ko'payib keta olmaydi, chunki `cap <= isize::MAX` va `cap` turi `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` dan umumiy bo'lmagan.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Ushbu usul bo'yicha cheklovlar `grow_amortized`-dagi kabi deyarli bir xil, ammo bu usul odatda kamroq qo'llaniladi, shuning uchun u juda muhim emas.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Biz `usize::MAX` hajmini qaytarganimizdan beri, uning o'lchamlari kattaligi
            // 0, bu erga etib kelish, albatta, `RawVec` ning ortiqcha ekanligini anglatadi.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` dan umumiy bo'lmagan.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ushbu funktsiya kompilyatsiya vaqtini minimallashtirish uchun `RawVec` tashqarisida.Tafsilotlar uchun yuqoridagi `RawVec::grow_amortized` izohiga qarang.
// (`A` parametri ahamiyatli emas, chunki amalda ko'rilgan turli xil `A` turlari soni `T` turlaridan ancha kichik).
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` hajmini kamaytirish uchun bu erda xatoni tekshiring.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Ajratuvchi tekislash tengligini tekshiradi
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*ga tegishli bo'lgan xotirani uning tarkibini tushirishga urinmasdan* bo'shatadi.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Zaxira xatolarini boshqarish uchun markaziy funktsiya.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Biz quyidagilarga kafolat berishimiz kerak:
// * Biz hech qachon `> isize::MAX` bayt hajmidagi moslamalarni ajratmaymiz.
// * Biz `usize::MAX` ni to'ldirmaymiz va aslida juda kam ajratamiz.
//
// 64-bitda biz shunchaki to'ldirilganligini tekshirishimiz kerak, chunki `> isize::MAX` baytlarni ajratishga urinish muvaffaqiyatsiz bo'ladi.
// 32-bitli va 16-bitli maydonlarda, masalan, PAE yoki x32 kabi barcha 4 Gb-lardan foydalanadigan platformada ishlayotgan bo'lsak, qo'shimcha qo'riqchi qo'shishimiz kerak.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Hisobot hajmi oshib ketishi uchun mas'ul bo'lgan bitta markaziy funktsiya.
// Bu ushbu panics bilan bog'liq kod ishlab chiqarishning minimal bo'lishini ta'minlaydi, chunki panics bitta modulda emas, balki butun modulda joylashgan.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}