//! "String`s" formatlash va chop etish uchun yordamchi dasturlar.
//!
//! Ushbu modul [`format!`] sintaksis kengaytmasi uchun ish vaqtini qo'llab-quvvatlashni o'z ichiga oladi.
//! Ushbu so'l kompilyatorda ushbu modulga qo'ng'iroqlarni tarqatish uchun ish vaqtidagi argumentlarni satrlarga formatlash uchun amalga oshiriladi.
//!
//! # Usage
//!
//! [`format!`] makrosi C ning `printf`/`fprintf` funktsiyalari yoki Python ning `str.format` funktsiyalari bilan tanish bo'lganlarga mo'ljallangan.
//!
//! [`format!`] kengaytmasining ba'zi bir misollari:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" etakchi nollar bilan
//! ```
//!
//! Ulardan birinchi argument format qatori ekanligini ko'rishingiz mumkin.Bu kompilyator tomonidan mag'lubiyat so'zi bo'lishi uchun talab qilinadi;u o'zgaruvchan bo'lishi mumkin emas (haqiqiyligini tekshirishni amalga oshirish uchun).
//! Keyin kompilyator format satrini tahlil qiladi va berilgan argumentlar ro'yxati ushbu format qatoriga o'tish uchun mos yoki yo'qligini aniqlaydi.
//!
//! Bitta qiymatni mag'lubiyatga aylantirish uchun [`to_string`] usulidan foydalaning.Bunda [`Display`] formatlash trait ishlatiladi.
//!
//! ## Pozitsion parametrlar
//!
//! Har bir formatlash argumentiga qaysi qiymat argumentiga murojaat qilishini belgilashga ruxsat beriladi va agar qoldirilgan bo'lsa, u "the next argument" deb hisoblanadi.
//! Masalan, `{} {} {}` format satri uchta parametrni oladi va ular berilgan tartibda formatlanadi.
//! Format qatori `{2} {1} {0}`, argumentlarni teskari tartibda formatlashi mumkin.
//!
//! Ikki turdagi pozitsion spetsifikatorlarni aralashtirishni boshlaganingizdan so'ng, narsalar biroz qiyinlashishi mumkin."next argument" spetsifikatorini argument ustida iterator deb hisoblash mumkin.
//! Har safar "next argument" spetsifikatori ko'rilganda, iterator rivojlanadi.Bu shunday xatti-harakatga olib keladi:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Birinchi `{}` ko'rilguncha argument bo'yicha ichki iterator rivojlanmagan, shuning uchun u birinchi argumentni chiqaradi.Keyin ikkinchi `{}` ga yetgandan so'ng, takrorlovchi ikkinchi argumentga o'tdi.
//! Aslida, ularning argumentlarini aniq nomlaydigan parametrlar pozitsion spetsifikatorlar nuqtai nazaridan argumentni nomlamaydigan parametrlarga ta'sir qilmaydi.
//!
//! Format mag'lubiyati uning barcha argumentlaridan foydalanish uchun talab qilinadi, aks holda bu kompilyatsiya vaqtidagi xato.Format qatorida bir xil dalillarga bir necha bor murojaat qilishingiz mumkin.
//!
//! ## Nomlangan parametrlar
//!
//! Rust-ning o'zida Python-ga o'xshash nomlangan parametrlarning funktsiyasiga teng keladigan ekvivalenti mavjud emas, ammo [`format!`] makrosi bu nomlangan parametrlardan foydalanish imkoniyatini beradigan sintaksis kengaytmasi.
//! Nomlangan parametrlar argumentlar ro'yxati oxirida keltirilgan va sintaksisga ega:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Masalan, quyidagi [`format!`] iboralarida nomlangan argument ishlatiladi:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Nomlari bo'lgan argumentlardan keyin pozitsion parametrlarni (ismsizlarni) qo'yish to'g'ri emas.Pozitsiyali parametrlar singari, format satrida ishlatilmaydigan nomlangan parametrlarni taqdim etish haqiqiy emas.
//!
//! # Formatlash parametrlari
//!
//! Formatlanayotgan har bir argumentni formatlashning bir qator parametrlari ([the syntax](#syntax)) da `format_spec` ga mos keladi) o'zgartirishi mumkin. Ushbu parametrlar formatlanayotgan narsalarning mag'lubiyatga ta'siriga ta'sir qiladi.
//!
//! ## Width
//!
//! ```
//! // Bularning barchasi "Hello x !"-ni bosib chiqaradi
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Bu format qabul qilishi kerak bo'lgan "minimum width" uchun parametr.
//! Agar qiymatning satri shu qadar ko'p belgini to'ldirmasa, u holda fill/alignment tomonidan belgilangan plomba kerakli joyni olish uchun ishlatiladi (pastga qarang).
//!
//! Kenglik uchun qiymat `$` postfiksini qo'shish orqali parametrlar ro'yxatida [`usize`] sifatida taqdim etilishi mumkin, bu ikkinchi argument kenglikni belgilaydigan [`usize`] ekanligini ko'rsatadi.
//!
//! Dollar sintaksisidagi argumentga murojaat qilish "next argument" hisoblagichiga ta'sir qilmaydi, shuning uchun odatda argumentlarga pozitsiyalar bo'yicha murojaat qilish yoki nomlangan argumentlardan foydalanish yaxshi bo'ladi.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Ixtiyoriy to'ldirish belgisi va tekislash odatda [`width`](#width) parametri bilan birgalikda ta'minlanadi.`width` dan oldin, `:` dan keyin aniqlanishi kerak.
//! Bu shuni ko'rsatadiki, formatlangan qiymat `width` dan kichik bo'lsa, uning atrofida ba'zi qo'shimcha belgilar bosilib chiqadi.
//! To'ldirish har xil hizalamalar uchun quyidagi variantlarda keltirilgan:
//!
//! * `[fill]<` - argument `width` ustunlarida chap tomonga yo'naltirilgan
//! * `[fill]^` - argument `width` ustunlarida markazlashtirilgan
//! * `[fill]>` - argument `width` ustunlarida o'ng tomonga to'g'ri keladi
//!
//! Raqamli bo'lmaganlar uchun standart [fill/alignment](#fillalignment) bo'sh joy va chapga tekislangan.Raqamli formatlashtiruvchilar uchun sukut ham bo'shliq belgisidir, lekin o'ng tomonga tekislanadi.
//! Agar raqamlar uchun `0` bayrog'i (pastga qarang) ko'rsatilgan bo'lsa, unda yopiq to'ldirish belgisi `0` bo'ladi.
//!
//! Hizalama ba'zi turlari tomonidan amalga oshirilmasligi mumkinligini unutmang.Xususan, odatda `Debug` trait uchun amalga oshirilmaydi.
//! To'ldirishni qo'llashni ta'minlashning yaxshi usuli-bu sizning kiritishingizni formatlash, keyin sizning natijangizni olish uchun ushbu satrni to'ldiring:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Salom Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Bularning barchasi formatlashtiruvchining ishini o'zgartiradigan bayroqlar.
//!
//! * `+` - Bu raqamli turlarga mo'ljallangan va belgi har doim bosib chiqarilishi kerakligini ko'rsatadi.Ijobiy belgilar hech qachon sukut bo'yicha bosilmaydi va salbiy belgi faqat `Signed` trait uchun sukut bo'yicha bosiladi.
//! Ushbu bayroq to'g'ri belgini (`+` yoki `-`) har doim bosib chiqarish kerakligini bildiradi.
//! * `-` - Hozirda foydalanilmayapti
//! * `#` - Ushbu bayroq "alternate" bosib chiqarish shaklidan foydalanish kerakligini bildiradi.Muqobil shakllar:
//!     * `#?` - [`Debug`] formatini chiroyli tarzda chop eting
//!     * `#x` - argumentdan oldin `0x`
//!     * `#X` - argumentdan oldin `0x`
//!     * `#b` - argumentdan oldin `0b`
//!     * `#o` - argumentdan oldin `0o`
//! * `0` - Bu tamsayı formatlar uchun `width`-ga to'ldirishni ikkala `0` belgisi bilan bajarish kerakligini va belgidan xabardor bo'lishini ko'rsatish uchun ishlatiladi.
//! `{:08}` kabi format `1` tamsayı uchun `00000001` beradi, xuddi shu format `-1` tamsayı uchun `-0000001` beradi.
//! E'tibor bering, salbiy versiyada ijobiy versiyaga qaraganda nolga teng.
//!         To'ldiradigan nollar har doim belgidan keyin (agar mavjud bo'lsa) va raqamlardan oldin qo'yilishini unutmang.`#` bayrog'i bilan birgalikda foydalanilganda, shunga o'xshash qoida qo'llaniladi: to'ldirish nollari prefiksdan keyin, lekin raqamlardan oldin qo'shiladi.
//!         Prefiks umumiy kenglikka kiritilgan.
//!
//! ## Precision
//!
//! Raqamli bo'lmagan turlari uchun buni "maximum width" deb hisoblash mumkin.
//! Agar natijada olingan satr shu kenglikdan uzunroq bo'lsa, u holda u shu qadar ko'p belgigacha qisqartiriladi va agar ushbu parametrlar o'rnatilgan bo'lsa, u kesilgan qiymat tegishli `fill`, `alignment` va `width` bilan chiqariladi.
//!
//! Integral turlar uchun bu e'tiborga olinmaydi.
//!
//! Suzuvchi nuqta turlari uchun bu kasrdan keyin qancha raqam bosilishi kerakligini bildiradi.
//!
//! Kerakli `precision`-ni ko'rsatishning uchta usuli mavjud:
//!
//! 1. Butun son `.N`:
//!
//!    butun `N` raqamining o'zi aniqlikdir.
//!
//! 2. Butun son yoki ism, keyin `.N$` dollar belgisi:
//!
//!    format sifatida *argument*`N` (`usize` bo'lishi kerak) aniqligi sifatida foydalaning.
//!
//! 3. `.*` yulduzcha:
//!
//!    `.*` bu `{...}` bitta emas, balki *ikkita* formatdagi yozuvlar bilan bog'liqligini anglatadi: birinchi kirish `usize` aniqligini, ikkinchisi esa chop etish uchun qiymatni ushlab turadi.
//!    E'tibor bering, bu holda, agar kimdir `{<arg>:<spec>.*}` format satridan foydalansa, u holda `<arg>` qismi chop etish uchun* qiymatga ishora qiladi va `precision` `<arg>` oldidagi kirishda bo'lishi kerak.
//!
//! Masalan, quyidagi qo'ng'iroqlar hammasi bir xil `Hello x is 0.01000`-ni bosib chiqaradi:
//!
//! ```
//! // Salom {arg 0 ("x")} bu {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Salom {arg 1 ("x")} bu {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Salom {arg 0 ("x")} bu {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Salom {next arg ("x")} bu {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Salom {next arg ("x")} bu {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Salom {next arg ("x")} bu {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Bular:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! uchta farqli narsalarni chop eting:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Ba'zi dasturlash tillarida satrlarni formatlash funktsiyalarining harakati operatsion tizimning mahalliy sozlamalariga bog'liq.
//! Rust standart kutubxonasi tomonidan taqdim etilgan formatlash funktsiyalari hech qanday mahalliy tushunchaga ega emas va foydalanuvchi konfiguratsiyasidan qat'i nazar barcha tizimlarda bir xil natijalarni beradi.
//!
//! Masalan, tizim kodi nuqtadan tashqari o'nlik ajratuvchidan foydalansa ham, quyidagi kod har doim `1.5` ni bosib chiqaradi.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! To'g'ridan-to'g'ri `{` va `}` belgilar bir xil belgilar bilan ularni oldiga qo'yish orqali qatorga kiritilishi mumkin.Masalan, `{` belgisi `{{` bilan, `}` belgisi `}}` bilan qochib ketadi.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Xulosa qilish uchun bu erda siz format satrlarining to'liq grammatikasini topishingiz mumkin.
//! Amaldagi formatlash tili uchun sintaksis boshqa tillardan olingan, shuning uchun u juda begona bo'lmasligi kerak.Argumentlar Python-ga o'xshash sintaksis bilan formatlangan, ya'ni argumentlar C-o'xshash `%` o'rniga `{}` bilan o'ralgan.
//! Formatlash sintaksisining haqiqiy grammatikasi:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Yuqoridagi grammatikada `text` tarkibida `'{'` yoki `'}'` belgilar bo'lmasligi mumkin.
//!
//! # traits formatlash
//!
//! Argumentni ma'lum bir tur bilan formatlashni talab qilganda, siz aslida argumentni ma'lum bir trait bilan bog'lashini talab qilasiz.
//! Bu bir nechta haqiqiy turlarni `{:x}` (masalan, [`i8`] va [`isize`] kabi) orqali formatlashga imkon beradi.traits turlarini joriy xaritalash quyidagicha:
//!
//! * *hech narsa* ⇒ [`Display`]
//! * `?` 00 [`Debug`]
//! * `x?` Lower [`Debug`] kichik kichik o'n oltinchi tamsayılar bilan
//! * `X?` ⇒ katta o'n oltinchi tamsayılar bilan [`Debug`]
//! * `o` 00 [`Octal`]
//! * `x` 00 [`LowerHex`]
//! * `X` 00 [`UpperHex`]
//! * `p` 00 [`Pointer`]
//! * `b` 00 [`Binary`]
//! * `e` 00 [`LowerExp`]
//! * `E` 00 [`UpperExp`]
//!
//! Buning ma'nosi shundaki, [`fmt::Binary`][`Binary`] trait-ni amalga oshiradigan har qanday argument turi keyinchalik `{:b}` bilan formatlanishi mumkin.Amaliyotlar ushbu traits uchun bir qator ibtidoiy turlar uchun standart kutubxona tomonidan taqdim etilgan.
//!
//! Agar format ko'rsatilmagan bo'lsa (`{}` yoki `{:6}` da bo'lgani kabi), unda trait formati [`Display`] trait ishlatiladi.
//!
//! O'zingizning turingiz uchun trait formatini amalga oshirishda siz imzo usulini qo'llashingiz kerak bo'ladi:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // bizning maxsus turimiz
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Sizning turingiz `self` ma'lumotnomasi sifatida qabul qilinadi va keyin funktsiya `f.buf` oqimiga chiqishi kerak.So'ralgan formatlash parametrlariga to'g'ri rioya qilish har bir trait formatini amalga oshirishi mumkin.
//! Ushbu parametrlarning qiymatlari [`Formatter`] strukturasining maydonlarida keltirilgan.Bunga yordam berish uchun [`Formatter`] struct yordamchi usullarni ham taqdim etadi.
//!
//! Bundan tashqari, ushbu funktsiyani qaytarish qiymati [`fmt::Result`] bo'lib, u ["Natija"] "<()," [`std: : fmt::Xato`]">".
//! Amalga oshirishni amalga oshirishda ular [`Formatter`]-dan (masalan, [`write!`]-ga qo'ng'iroq qilishda) xatolar tarqalishini ta'minlashi kerak.
//! Biroq, ular hech qachon xatolarni soxta qaytarmasliklari kerak.
//! Ya'ni, formatlashni amalga oshirish, agar kiritilgan [`Formatter`] xatoni qaytargan bo'lsa, faqatgina xatolikni qaytarishi kerak va berishi mumkin.
//! Buning sababi, funktsiya imzosi taklif qilishi mumkin bo'lgan narsadan farqli o'laroq, mag'lubiyatni formatlash xatosiz operatsiya.
//! Ushbu funktsiya faqat natija beradi, chunki asosiy oqimga yozish muvaffaqiyatsiz bo'lishi mumkin va u xato yuz berganligi haqidagi ma'lumotni tarqatish usulini taqdim etishi kerak.
//!
//! traits formatlashni amalga oshirish misoli quyidagicha ko'rinadi:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` qiymati `Write` trait ni amalga oshiradi, bu nima yozish kerak!so'l kutmoqda.
//!         // Ushbu formatlash satrlarni formatlash uchun berilgan turli xil bayroqchalarni e'tiborsiz qoldirishini unutmang.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Turli xil traits har xil turdagi chiqishga imkon beradi.
//! // Ushbu formatning ma'nosi vector kattaligini bosib chiqarishdir.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Formatter ob'ektida `pad_integral` yordamchi usuli yordamida formatlash bayroqlarini hurmat qiling.
//!         // Tafsilotlar uchun uslubiy hujjatlarni ko'ring va `pad` funktsiyasi satrlarni to'ldirish uchun ishlatilishi mumkin.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` va boshqalar `fmt::Debug`
//!
//! Ushbu ikkita formatlash traits aniq maqsadlarga ega:
//!
//! - [`fmt::Display`][`Display`] Amaliyotlar ushbu turdagi har doim UTF-8 qatori sifatida ishonchli tarzda namoyish etilishi mumkinligini ta'kidlamoqda.Barcha turdagi [`Display`] trait ni amalga oshirishi ** kutilmaydi.
//! - [`fmt::Debug`][`Debug`] dasturlar **barcha** ommaviy turlari uchun amalga oshirilishi kerak.
//!   Chiqish odatda ichki holatni iloji boricha ishonchli tarzda namoyish etadi.
//!   [`Debug`] trait-ning maqsadi Rust kodini disk raskadrovka qilishni osonlashtirishdir.Ko'pgina hollarda, `#[derive(Debug)]` dan foydalanish etarli va tavsiya etiladi.
//!
//! Ikkala traits-dan chiqadigan ba'zi bir misollar:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Tegishli makrolar
//!
//! [`format!`] oilasida bir qator tegishli makroslar mavjud.Hozirgi kunda amalga oshirilayotganlar:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Bu va [`writeln!`] formatlangan qatorni belgilangan oqimga chiqarish uchun ishlatiladigan ikkita makrosdir.Bu format satrlarini oraliq ajratilishini oldini olish va natijani to'g'ridan-to'g'ri yozish uchun ishlatiladi.
//! Kaput ostida bu funktsiya aslida [`std::io::Write`] trait-da aniqlangan [`write_fmt`] funktsiyasini bajaradi.
//! Masalan foydalanish:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Bu va [`println!`] o'z mahsulotlarini stdout-ga chiqaradi.[`write!`] makrosi singari, ushbu makrolarning maqsadi ham chiqishni bosib chiqarishda oraliq ajratmalarning oldini olishdir.Masalan foydalanish:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] va [`eprintln!`] makrolari mos ravishda [`print!`] va [`println!`] bilan bir xil, faqat ular o'zlarining chiqishlarini stderr-ga chiqaradilar.
//!
//! ### `format_args!`
//!
//! Bu format satrini tavsiflovchi shaffof bo'lmagan ob'ekt atrofida xavfsiz o'tish uchun ishlatiladigan qiziq makros.Ushbu ob'ekt yaratish uchun har qanday ajratma ajratishni talab qilmaydi va u faqat stekdagi ma'lumotlarga murojaat qiladi.
//! Kaput ostida barcha tegishli makroslar shu nuqtai nazardan amalga oshiriladi.
//! Birinchidan, ba'zi bir misollardan foydalanish:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! [`format_args!`] so'lining natijasi [`fmt::Arguments`] tipidagi qiymatdir.
//! Ushbu strukturani keyinchalik format satrini qayta ishlash uchun ushbu modul ichidagi [`write`] va [`format`] funktsiyalariga o'tkazish mumkin.
//! Ushbu so'lning maqsadi formatlash satrlari bilan ishlashda oraliq ajratmalarning oldini olishdir.
//!
//! Masalan, ro'yxatga olish kutubxonasi standart formatlash sintaksisidan foydalanishi mumkin, ammo u chiqishning qaerga ketishi kerakligi aniqlanmaguncha, ushbu tuzilmaning ichki qismida o'tadi.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// `format` funktsiyasi [`Arguments`] strukturasini oladi va natijada formatlangan satrni qaytaradi.
///
///
/// [`Arguments`] misoli [`format_args!`] so'l yordamida yaratilishi mumkin.
///
/// # Examples
///
/// Asosiy foydalanish:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Iltimos, [`format!`] dan foydalanish afzalroq bo'lishi mumkinligini unutmang.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}