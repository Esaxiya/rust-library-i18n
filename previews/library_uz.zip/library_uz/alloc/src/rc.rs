//! Bitta ipli mos yozuvlarni hisoblash ko'rsatkichlari.'Rc' "Ma'lumotnoma" degan ma'noni anglatadi
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] turi uyumda ajratilgan `T` tipidagi qiymatga birgalikda egalik qilishni ta'minlaydi.
//! [`clone`][clone]-ni [`Rc`]-ga chaqirish, uyumdagi bir xil taqsimotga yangi ko'rsatkichni keltirib chiqaradi.
//! Berilgan ajratmaga so'nggi [`Rc`] ko'rsatkichi yo'q qilinganda, ushbu ajratmada saqlanadigan qiymat (ko'pincha "inner value" deb ataladi) ham tushadi.
//!
//! Rust-dagi umumiy havolalar mutatsiyani sukut bo'yicha taqiqlaydi va [`Rc`] istisno emas: odatda [`Rc`] ichidagi narsaga o'zgaruvchan ma'lumot olish mumkin emas.
//! Agar sizga o'zgaruvchanlik kerak bo'lsa, [`Rc`] ichiga [`Cell`] yoki [`RefCell`] qo'ying;[an example of mutability inside an `Rc`][mutability] ga qarang.
//!
//! [`Rc`] atom bo'lmagan mos yozuvlarni hisoblashdan foydalanadi.
//! Bu shuni anglatadiki, qo'shimcha xarajatlar juda past, ammo [`Rc`]-ni iplar orasiga yuborib bo'lmaydi va natijada [`Rc`] [`Send`][send]-ni qo'llamaydi.
//! Natijada, Rust kompilyatori *kompilyatsiya vaqtida* sizning iplar orasiga [`Rc`] s yubormasligingizni tekshiradi.
//! Agar sizga ko'p tishli, atomik ma'lumotni hisoblash kerak bo'lsa, [`sync::Arc`][arc] dan foydalaning.
//!
//! [`downgrade`][downgrade] usuli egasi bo'lmagan [`Weak`] ko'rsatkichini yaratish uchun ishlatilishi mumkin.
//! [`Weak`] ko'rsatkichi [`Rc`] ga [`upgrade '][upgrade] d bo'lishi mumkin, lekin bu ajratishda saqlangan qiymat allaqachon tushib ketgan bo'lsa, [`None`] ni qaytaradi.
//! Boshqacha qilib aytganda, `Weak` ko'rsatkichlari ajratish ichidagi qiymatni saqlab turmaydi;ammo, ular ajratishni (ichki qiymatni qo'llab-quvvatlovchi do'kon) jonli saqlashadi.
//!
//! [`Rc`] ko'rsatkichlari orasidagi tsikl hech qachon taqsimlanmaydi.
//! Shu sababli, [`Weak`] tsikllarni sindirish uchun ishlatiladi.
//! Masalan, daraxtda ota-ona tugunlaridan bolalarga kuchli [`Rc`] ko'rsatkichlari va bolalardan ota-onalariga qaytib kelgan [`Weak`] ko'rsatkichlari bo'lishi mumkin.
//!
//! `Rc<T>` avtomatik ravishda `T`-ga havola qilinadi ([`Deref`] trait orqali), shuning uchun siz [`Rc<T>`][`Rc`] turidagi qiymat bo'yicha "T" usullarini chaqirishingiz mumkin.
//! "T" usullari bilan nomlarning to'qnashuviga yo'l qo'ymaslik uchun [`Rc<T>`][`Rc`] usullari o'zaro bog'liq funktsiyalar bo'lib, [fully qualified syntax] yordamida chaqiriladi:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! "Rc<T>`Clone` kabi traits dasturlarini to'liq malakali sintaksis yordamida ham chaqirish mumkin.
//! Ba'zi odamlar to'liq malakali sintaksisdan foydalanishni afzal ko'rishadi, boshqalari esa metod-chaqiruv sintaksisidan foydalanishni afzal ko'rishadi.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Qo'ng'iroq sintaksisining usuli
//! let rc2 = rc.clone();
//! // To'liq malakali sintaksis
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T`-ga avtomatik ravishda murojaat qilmaydi, chunki ichki qiymat allaqachon tushib ketgan bo'lishi mumkin.
//!
//! # Ma'lumotnomalarni klonlash
//!
//! Mavjud mos yozuvlar hisoblangan ko'rsatgich bilan bir xil taqsimotga yangi havolani yaratish [`Rc<T>`][`Rc`] va [`Weak<T>`][`Weak`] uchun amalga oshirilgan `Clone` trait yordamida amalga oshiriladi.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Quyidagi ikkita sintaksis tengdir.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a va b ikkalasi ham foo bilan bir xil xotira joyiga ishora qiladi.
//! ```
//!
//! `Rc::clone(&from)` sintaksisi eng idiomatik hisoblanadi, chunki u kodning ma'nosini aniqroq bayon qiladi.
//! Yuqoridagi misolda ushbu sintaksis ushbu kodning foo tarkibini to'liq nusxalash o'rniga yangi havola yaratayotganini ko'rishni osonlashtiradi.
//!
//! # Examples
//!
//! "Gadget" to'plami berilgan `Owner`-ga tegishli bo'lgan stsenariyni ko'rib chiqing.
//! Gadjetlarimiz ularning `Owner`-ga ishora qilmoqchi.Biz buni noyob egalik bilan qila olmaymiz, chunki bitta `Owner`-ga bir nechta gadjet tegishli bo'lishi mumkin.
//! [`Rc`] bizga `Owner`-ni bir nechta "Gadget" lar o'rtasida bo'lishishga imkon beradi va `Owner` har qanday `Gadget` nuqtalari mavjud bo'lganda ajratilgan bo'lib qoladi.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... boshqa maydonlar
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... boshqa maydonlar
//! }
//!
//! fn main() {
//!     // Malumot bo'yicha hisoblangan `Owner` yarating.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner`-ga tegishli "gadjet" yarating.
//!     // `Rc<Owner>`-ni klonlash bizni xuddi shu `Owner` taqsimotiga yangi ko'rsatkichni beradi va bu jarayonda mos yozuvlar sonini oshiradi.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Bizning mahalliy o'zgaruvchimiz `gadget_owner` ni yo'q qiling.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner`-ni tashlaganimizga qaramay, biz "Gadget" ning `Owner` nomini chop eta olamiz.
//!     // Buning sababi shundaki, biz faqatgina bitta `Rc<Owner>` ni tashladik, u ko'rsatadigan `Owner` emas.
//!     // Xuddi shu `Owner` ajratilishini ko'rsatadigan boshqa `Rc<Owner>` mavjud ekan, u jonli bo'lib qoladi.
//!     // `gadget1.owner.name` maydon proektsiyasi ishlaydi, chunki `Rc<Owner>` avtomatik ravishda `Owner` ga murojaat qiladi.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Funktsiya oxirida `gadget1` va `gadget2` yo'q qilinadi va ular bilan bizning `Owner`-ga so'nggi hisoblangan havolalar.
//!     // Gadget Man endi yo'q qilinadi.
//!     //
//! }
//! ```
//!
//! Agar bizning talablarimiz o'zgarib qolsa va biz ham `Owner` dan `Gadget` gacha o'tib ketishimiz kerak bo'lsa, biz muammolarga duch kelamiz.
//! `Owner` dan `Gadget` gacha bo'lgan [`Rc`] ko'rsatkichi tsiklni taqdim etadi.
//! Bu shuni anglatadiki, ularning ma'lumotlari hech qachon 0 ga yetmaydi va ajratish hech qachon yo'q qilinmaydi:
//! xotira oqishi.Buni aylanib o'tish uchun biz [`Weak`] ko'rsatkichlaridan foydalanishimiz mumkin.
//!
//! Rust aslida ushbu tsiklni birinchi navbatda ishlab chiqarishni biroz qiyinlashtiradi.Bir-biriga ishora qiluvchi ikkita qiymat bilan yakunlash uchun ulardan biri o'zgaruvchan bo'lishi kerak.
//! Bu juda qiyin, chunki [`Rc`] xotira xavfsizligini faqat o'rash qiymatiga umumiy havolalar berish orqali amalga oshiradi va bu to'g'ridan-to'g'ri mutatsiyaga yo'l qo'ymaydi.
//! Mutatsiyani istagan qiymatning bir qismini [`RefCell`]-ga o'rashimiz kerak, bu esa *ichki o'zgaruvchanlikni* ta'minlaydi: umumiy ma'lumot orqali o'zgaruvchanlikka erishish usuli.
//! [`RefCell`] ish vaqtida Rust-ning qarz olish qoidalarini bajaradi.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... boshqa maydonlar
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... boshqa maydonlar
//! }
//!
//! fn main() {
//!     // Malumot bo'yicha hisoblangan `Owner` yarating.
//!     // Shunisi e'tiborga loyiqki, biz "Gadget" ning vector egasini `RefCell` ichiga joylashtirdik, shunda biz uni umumiy ma'lumot orqali mutatsiyalashimiz mumkin.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Avvalgi kabi `gadget_owner`-ga tegishli "gadjet" yarating.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Gadget-ni `Owner`-ga qo'shing.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dinamik qarz shu erda tugaydi.
//!     }
//!
//!     // Bizning gadjetlarimizni takrorlang, ularning tafsilotlarini chop eting.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` bu `Weak<Gadget>`.
//!         // `Weak` ko'rsatkichlari ajratishni hali ham kafolatlay olmasligi sababli, biz `Option<Rc<Gadget>>`-ni qaytaradigan `upgrade`-ga qo'ng'iroq qilishimiz kerak.
//!         //
//!         //
//!         // Bunday holda biz ajratish hali ham mavjudligini bilamiz, shuning uchun biz `unwrap` `Option`.
//!         // Keyinchalik murakkab dasturda sizga `None` natijasi uchun xushmuomalalik bilan ishlov berish kerak bo'lishi mumkin.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Funktsiya oxirida `gadget_owner`, `gadget1` va `gadget2` yo'q qilinadi.
//!     // Hozirda gadjetlarga kuchli (`Rc`) ko'rsatkichlari yo'q, shuning uchun ular yo'q qilinadi.
//!     // Bu Gadget Man-ga mos yozuvlar sonini nolga tenglashtiradi, shuning uchun u ham yo'q bo'lib ketadi.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Bu repr(C)-dan future-ga mumkin bo'lgan maydonni qayta tartiblashdan himoya qiladi, bu esa o'zgaruvchan ichki turdagi [into|from]_raw()-ga xalaqit beradi.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Bitta ipli mos yozuvlarni hisoblash ko'rsatkichi.'Rc' "Ma'lumotnoma" degan ma'noni anglatadi
/// Counted'.
///
/// Qo'shimcha ma'lumot uchun [module-level documentation](./index.html)-ga qarang.
///
/// `Rc` ning ajralmas usullari bu barcha bog'liq funktsiyalardir, ya'ni siz ularni `value.get_mut()` o'rniga [`Rc::get_mut(&mut value)`][get_mut] deb chaqirishingiz kerak.
/// Bu ichki `T` tipidagi usullar bilan to'qnashuvlarning oldini oladi.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Xavfsizlik yaxshi, chunki Rc tirik bo'lganida biz ichki ko'rsatgichning haqiqiyligiga kafolat beramiz.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Yangi `Rc<T>` quradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Barcha kuchli ko'rsatgichlarga tegishli bo'lgan aniq zaif ko'rsatkich mavjud, bu zaif destruktor kuchli destruktor ichida saqlangan bo'lsa ham, kuchli destruktor ishlayotgan paytda ajratishni hech qachon bo'shatmasligini ta'minlaydi.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// O'ziga nisbatan zaif ma'lumotdan foydalangan holda yangi `Rc<T>` ni yaratadi.
    /// Ushbu funktsiya qaytmasidan oldin zaif ma'lumotnomani yangilashga urinish `None` qiymatiga olib keladi.
    ///
    /// Shu bilan birga, zaif ma'lumotnomani erkin klonlash va undan keyin foydalanish uchun saqlash mumkin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... ko'proq maydonlar
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Ichki qismni "uninitialized" holatida bitta zaif mos yozuvlar bilan yarating.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Zaif ko'rsatkichga egalik huquqidan voz kechmasligimiz muhim, aks holda `data_fn` qaytguncha xotirani bo'shatish mumkin.
        // Agar biz haqiqatan ham egalik huquqidan o'tishni xohlasak, o'zimiz uchun qo'shimcha zaif ko'rsatgichni yaratishimiz mumkin edi, ammo bu zaif ma'lumotnomalar soniga qo'shimcha yangilanishlarni keltirib chiqaradi, aks holda bu kerak emas.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Kuchli ma'lumotnomalar birgalikda umumiy zaif ma'lumotlarga egalik qilishi kerak, shuning uchun eski zaif ma'lumotnomamiz uchun destruktorni ishlatmang.
        //
        mem::forget(weak);
        strong
    }

    /// Boshlanmagan tarkibga ega yangi `Rc` ni yaratadi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `0` bayt bilan to'ldirilgan, boshlanmagan tarkibga ega yangi `Rc` ni yaratadi.
    ///
    ///
    /// Ushbu usuldan to'g'ri va noto'g'ri foydalanish misollari uchun [`MaybeUninit::zeroed`][zeroed]-ga qarang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yangi `Rc<T>`-ni quradi, agar ajratish amalga oshmasa, xatoni qaytaradi
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Barcha kuchli ko'rsatgichlarga tegishli bo'lgan aniq zaif ko'rsatkich mavjud, bu zaif destruktor kuchli destruktor ichida saqlangan bo'lsa ham, kuchli destruktor ishlayotgan paytda ajratishni hech qachon bo'shatmasligini ta'minlaydi.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Boshlanmagan tarkibga ega yangi `Rc`-ni quradi, agar ajratish amalga oshmasa, xatolikni qaytaradi
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Boshlanmagan tarkibga ega bo'lgan yangi `Rc`-ni quradi, agar xotira `0` bayt bilan to'ldirilsa, ajratish amalga oshmasa xato qaytaradi.
    ///
    ///
    /// Ushbu usuldan to'g'ri va noto'g'ri foydalanish misollari uchun [`MaybeUninit::zeroed`][zeroed]-ga qarang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Yangi `Pin<Rc<T>>` quradi.
    /// Agar `T` `Unpin`-ni amalga oshirmasa, u holda `value` xotirada saqlanadi va uni ko'chirish mumkin emas.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Ichki qiymatni qaytaradi, agar `Rc` aniq bitta kuchli ma'lumotga ega bo'lsa.
    ///
    /// Aks holda, [`Err`] yuborilgan xuddi shu `Rc` bilan qaytariladi.
    ///
    ///
    /// Agar zaif zaif ma'lumotnomalar mavjud bo'lsa ham, bu muvaffaqiyatli bo'ladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // tarkibidagi ob'ektni nusxalash

                // Zaiflarga ularni kuchli sonni kamaytirish orqali ko'tarilish mumkin emasligini ko'rsating va keyin yashirin "strong weak" ko'rsatkichini olib tashlang, shuningdek, faqat soxta zaiflarni ishlab chiqish orqali tushish mantig'ini ko'rib chiqing.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Initsializatsiya qilinmagan tarkibga ega bo'lgan yangi mos yozuvlar hisoblangan bo'lakni quradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Xotira `0` bayt bilan to'ldirilgan, boshlanmagan tarkibga ega bo'lgan yangi mos yozuvlar bilan hisoblangan bo'lakni quradi.
    ///
    ///
    /// Ushbu usuldan to'g'ri va noto'g'ri foydalanish misollari uchun [`MaybeUninit::zeroed`][zeroed]-ga qarang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` ga o'zgartiradi.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-da bo'lgani kabi, ichki qiymat haqiqatan ham boshlang'ich holatida bo'lishiga kafolat beruvchiga murojaat qilish kerak.
    ///
    /// Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish darhol aniqlanmagan xatti-harakatlarni keltirib chiqaradi.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` ga o'zgartiradi.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-da bo'lgani kabi, ichki qiymat haqiqatan ham boshlang'ich holatida bo'lishiga kafolat beruvchiga murojaat qilish kerak.
    ///
    /// Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish darhol aniqlanmagan xatti-harakatlarni keltirib chiqaradi.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// O'ralgan ko'rsatgichni qaytarib, `Rc` ni sarflaydi.
    ///
    /// Xotiradan qochib qutulmaslik uchun ko'rsatgichni [`Rc::from_raw`][from_raw] yordamida `Rc` ga qaytarish kerak.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Ma'lumotlarga xom ko'rsatkichni taqdim etadi.
    ///
    /// Hisob-kitoblarga hech qanday ta'sir ko'rsatilmaydi va `Rc` iste'mol qilinmaydi.
    /// Ko'rsatkich `Rc`-da kuchli hisoblar mavjud bo'lgan vaqtgacha amal qiladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // XAVFSIZLIK: Deref::deref yoki Rc::inner orqali o'tib bo'lmaydi, chunki
        // masalan, raw/mut tajribasini saqlab qolish uchun talab qilinadi
        // `get_mut` Rc `from_raw` orqali tiklangandan keyin ko'rsatgich orqali yozishi mumkin.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// `Rc<T>` ni xom ko'rsatgichdan tuzadi.
    ///
    /// Xom ko'rsatgich ilgari [`Rc<U>::into_raw`][into_raw] raqamiga qo'ng'iroq bilan qaytarilgan bo'lishi kerak, bu erda `U` `T` bilan bir xil o'lchamga va tekislikka ega bo'lishi kerak.
    /// Agar `U` `T` bo'lsa, bu juda ahamiyatli emas.
    /// E'tibor bering, agar `U` `T` bo'lmasa, lekin o'lchamlari va hizalanishi bir xil bo'lsa, bu asosan har xil turdagi mos yozuvlar transmutingiga o'xshaydi.
    /// Ushbu holatda qanday cheklovlar qo'llanilishi haqida ko'proq ma'lumot olish uchun [`mem::transmute`][transmute]-ga qarang.
    ///
    /// `from_raw` foydalanuvchisi `T` qiymatining atigi bir marta tushishiga ishonch hosil qilishi kerak.
    ///
    /// Ushbu funktsiya xavfli emas, chunki noto'g'ri ishlatilganligi, hatto qaytarilgan `Rc<T>`-ga hech qachon ulanmasa ham xotiraning xavfsizligini keltirib chiqarishi mumkin.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Oqishning oldini olish uchun `Rc`-ga qayting.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)`-ga qo'shimcha qo'ng'iroqlar xotirada xavfli bo'ladi.
    /// }
    ///
    /// // `x` yuqoridagi doiradan chiqib ketganda xotira bo'shatildi, shuning uchun `x_ptr` endi osilib qoldi!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Asl RcBoxni topish uchun ofsetni teskari yo'naltiring.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Ushbu ajratishga yangi [`Weak`] ko'rsatkichini yaratadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Biz osilgan zaifni yaratmasligimizga ishonch hosil qiling
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Ushbu taqsimotga [`Weak`] ko'rsatkichlari sonini oladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Ushbu ajratishga kuchli (`Rc`) ko'rsatkichlari sonini oladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Ushbu ajratishga boshqa `Rc` yoki [`Weak`] ko'rsatkichlari bo'lmasa, `true`-ni qaytaradi.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Agar bir xil ajratishga boshqa `Rc` yoki [`Weak`] ko'rsatkichlari bo'lmasa, berilgan `Rc` ga o'zgaruvchan ma'lumotni qaytaradi.
    ///
    ///
    /// [`None`]-ni qaytaradi, aks holda umumiy qiymatni mutatsiyalash xavfsiz emas.
    ///
    /// Boshqa ko'rsatkichlar mavjud bo'lganda ichki qiymatni [`clone`][clone] qiladigan [`make_mut`][make_mut]-ga ham qarang.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// H00X-ga o'zgartirilishi mumkin bo'lgan ma'lumotnomani hech qanday tekshiruvsiz qaytaradi.
    ///
    /// [`get_mut`]-ga qarang, u xavfsiz va tegishli tekshiruvlarni amalga oshiradi.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Xuddi shu taqsimotga tegishli har qanday boshqa `Rc` yoki [`Weak`] ko'rsatkichlari qaytarilgan qarz muddati davomida ajratilmasligi kerak.
    ///
    /// Agar bunday ko'rsatgichlar mavjud bo'lmasa, masalan, `Rc::new` dan keyin darhol ahamiyatsiz bo'ladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Biz "count" maydonlarini o'z ichiga olgan ma'lumotnomani yaratmasligimizdan * ehtiyot bo'lamiz, chunki bu mos yozuvlar soniga kirishga zid bo'lishi mumkin (masalan.)
        // `Weak` tomonidan).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Ikkala Rc bir xil ajratishga ishora qilsa ([`ptr::eq`] ga o'xshash tomirda) `true`-ni qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Berilgan `Rc` ga o'zgaruvchan mos yozuvlar qiladi.
    ///
    /// Agar bir xil taqsimotga boshqa `Rc` ko'rsatkichlari mavjud bo'lsa, unda `make_mut` noyob egalikni ta'minlash uchun ichki qiymatni yangi ajratishga [`clone`] qiladi.
    /// Bu, shuningdek, klon yozish deb nomlanadi.
    ///
    /// Agar ushbu taqsimotga boshqa `Rc` ko'rsatgichlari bo'lmasa, u holda [`Weak`] ko'rsatgichlari ajratiladi.
    ///
    /// Klonlash o'rniga ishlamaydigan [`get_mut`]-ga qarang.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Hech narsa klonlanmaydi
    /// let mut other_data = Rc::clone(&data);    // Ichki ma'lumotlar klonlanmaydi
    /// *Rc::make_mut(&mut data) += 1;        // Ichki ma'lumotlarni klonlaydi
    /// *Rc::make_mut(&mut data) += 1;        // Hech narsa klonlanmaydi
    /// *Rc::make_mut(&mut other_data) *= 2;  // Hech narsa klonlanmaydi
    ///
    /// // Endi `data` va `other_data` turli xil ajratmalarga ishora qilmoqda.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] ko'rsatgichlar ajratiladi:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Ma'lumotlarni klonlash kerak, boshqa Rcs ham bor.
            // Klonlangan qiymatni to'g'ridan-to'g'ri yozish uchun xotirani oldindan ajratib oling.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Faqatgina ma'lumotlarni o'g'irlashi mumkin, faqat zaiflar qoladi
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Yashirin kuchli va zaif refni olib tashlang (bu erda soxta zaiflarni ishlab chiqarishning hojati yo'q-biz boshqa zaiflar bizni tozalashi mumkinligini bilamiz)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Bu xavfli emas, chunki biz qaytarilgan ko'rsatgich T ga qaytariladigan *only* ko'rsatkichi ekanligiga kafolat beramiz.
        // Bizning ma'lumotnomamiz ushbu nuqtada 1 bo'lishi kafolatlanadi va biz `Rc<T>` ning o'zi `mut` bo'lishini talab qildik, shuning uchun biz ajratish uchun mumkin bo'lgan yagona ma'lumotni qaytaramiz.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>`-ni beton turiga tushirishga urinish.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `RcBox<T>`-ni ichki o'lcham uchun etarlicha bo'sh joyga ajratadi, bu erda qiymat taqdim etilgan tartibga ega.
    ///
    /// `mem_to_rcbox` funktsiyasi ma'lumotlar ko'rsatgichi bilan chaqiriladi va `RcBox<T>` uchun (potentsial yog ') ko'rsatkichini qaytarishi kerak.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Berilgan qiymat maketidan foydalanib tartibni hisoblang.
        // Ilgari, tartib `&*(ptr as* const RcBox<T>)` ifodasida hisoblangan, ammo bu noto'g'ri mos yozuvlar yaratgan (#54908 ga qarang).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// `RcBox<T>`-ni ajratib bo'lmaydigan ichki qiymat uchun etarli joy bilan ajratadi, bu erda qiymat joylashtirilgan bo'lsa, ajratish amalga oshmasa xato bo'ladi.
    ///
    ///
    /// `mem_to_rcbox` funktsiyasi ma'lumotlar ko'rsatgichi bilan chaqiriladi va `RcBox<T>` uchun (potentsial yog ') ko'rsatkichini qaytarishi kerak.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Berilgan qiymat maketidan foydalanib tartibni hisoblang.
        // Ilgari, tartib `&*(ptr as* const RcBox<T>)` ifodasida hisoblangan, ammo bu noto'g'ri mos yozuvlar yaratgan (#54908 ga qarang).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Joylashtirish uchun ajratish.
        let ptr = allocate(layout)?;

        // RcBox-ni ishga tushiring
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// `RcBox<T>` o'lchamsiz ichki qiymat uchun etarli bo'sh joy ajratadi
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Berilgan qiymatdan foydalanib, `RcBox<T>` uchun ajrating.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Qiymatni bayt sifatida nusxalash
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Tarkibni tushirmasdan ajratishni bepul qiling
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Berilgan uzunlikdagi `RcBox<[T]>`-ni ajratadi.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Elementlarni tilimdan yangi ajratilgan Rc <\[T\]> ga nusxalash
    ///
    /// Xavfli emas, chunki qo'ng'iroq qiluvchi egalik huquqini olishi yoki `T: Copy`-ni bog'lashi kerak
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// `Rc<[T]>` ni ma'lum o'lchamdagi iteratordan tuzadi.
    ///
    /// Hajmi noto'g'ri bo'lsa, o'zini tutishi aniqlanmagan.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // T elementlarini klonlash paytida Panic qo'riqchisi.
        // Agar panic bo'lsa, yangi RcBox-ga yozilgan elementlar tushiriladi, so'ngra xotira bo'shaydi.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Birinchi elementga ishora
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Hammasi aniq.Yangi RcBox-ni bo'shatmasligi uchun qo'riqchini unuting.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` uchun ishlatiladigan trait ixtisosligi.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` ni tashlaydi.
    ///
    /// Bu kuchli ma'lumotlarning sonini kamaytiradi.
    /// Agar kuchli ma'lumotlarning soni nolga etadigan bo'lsa, unda boshqa havolalar (agar mavjud bo'lsa) [`Weak`], shuning uchun biz ichki qiymatni `drop` qilamiz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Hech narsa chop etmaydi
    /// drop(foo2);   // "dropped!"-ni bosib chiqaradi
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // tarkibidagi ob'ektni yo'q qilish
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // tarkibini yo'q qilganimizdan so'ng, yashirin "strong weak" ko'rsatgichini olib tashlang.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` ko'rsatkichining klonini yaratadi.
    ///
    /// Bu xuddi shu taqsimotga yana bir ko'rsatkichni yaratadi va kuchli mos yozuvlar sonini oshiradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` uchun `Default` qiymatiga ega bo'lgan yangi `Rc<T>` yaratadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` uslubiga ega bo'lishiga qaramay, `Eq`-da ixtisoslashishga ruxsat berish uchun hack.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Biz bu erda ixtisoslashuvni `&T`-da umumiy optimallashtirish sifatida emas, balki amalga oshirmoqdamiz, chunki bu aks holda barcha tenglik tekshiruvlariga xarajatlarni qo'shadi.
/// Bizning fikrimizcha, "Rc`s" klonlashda sekin, ammo tenglikni tekshirish uchun og'ir bo'lgan katta qiymatlarni saqlash uchun ishlatiladi, bu xarajatlarni osonroq qoplaydi.
///
/// Ikkita X va X ga o'xshash ikkita `Rc` klonlari bo'lishi mumkin, ular bir xil qiymatga ishora qiladilar.
///
/// Biz buni faqat `T: Eq`, `PartialEq` sifatida ataylab qaytarilmasligi mumkin bo'lganda qila olamiz.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Ikki Rc uchun tenglik.
    ///
    /// Ikkala Rc`, agar ularning ichki qiymatlari teng bo'lsa, hatto ular har xil taqsimotda saqlansa ham teng.
    ///
    /// Agar `T` `Eq` ni ham amalga oshirsa (tenglikning refleksivligini bildiradi), bir xil taqsimotga ishora qiluvchi ikkita "Rc" har doim teng bo'ladi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ikki Rc uchun tengsizlik.
    ///
    /// Ikkala Rc` teng emas, agar ularning ichki qiymatlari teng bo'lmasa.
    ///
    /// Agar `T` `Eq` ni ham amalga oshirsa (tenglikning refleksivligini bildiradi), bir xil taqsimotga ishora qiluvchi ikkita "Rc" hech qachon teng bo'lmaydi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Ikki Rc uchun qisman taqqoslash.
    ///
    /// Ikkalasi ichki qiymatlari bo'yicha `partial_cmp()`-ni chaqirish orqali taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ikkala Rc uchun taqqoslashdan kamroq.
    ///
    /// Ikkalasi ichki qiymatlari bo'yicha `<`-ni chaqirish orqali taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Ikki "Rc`" uchun "kamroq yoki teng" taqqoslash.
    ///
    /// Ikkalasi ichki qiymatlari bo'yicha `<=`-ni chaqirish orqali taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Ikkala Rc uchun taqqoslashdan kattaroq.
    ///
    /// Ikkalasi ichki qiymatlari bo'yicha `>`-ni chaqirish orqali taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Ikki "Rc" uchun "kattaroq yoki teng" taqqoslash.
    ///
    /// Ikkalasi ichki qiymatlari bo'yicha `>=`-ni chaqirish orqali taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Ikki Rc uchun taqqoslash.
    ///
    /// Ikkalasi ichki qiymatlari bo'yicha `cmp()`-ni chaqirish orqali taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Ma'lumotlar bo'yicha hisoblangan tilimni ajratib oling va "v" elementlarini klonlash orqali to'ldiring.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Yo'naltiruvchi hisoblangan qatorli bo'lakni ajrating va unga `v` nusxasini oling.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Yo'naltiruvchi hisoblangan qatorli bo'lakni ajrating va unga `v` nusxasini oling.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Qutidagi ob'ektni yangi, mos yozuvlar hisoblangan, ajratilgan joyga ko'chiring.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Yo'naltiruvchi hisoblangan bo'lakni ajrating va unga "v" elementlarini ko'chiring.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec-ga xotirasini bo'shatishga ruxsat bering, lekin uning tarkibini yo'q qilmang
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` dagi har bir elementni oladi va `Rc<[T]>` ga yig'adi.
    ///
    /// # Ishlash xususiyatlari
    ///
    /// ## Umumiy ish
    ///
    /// Umumiy holda, `Rc<[T]>`-ga yig'ish birinchi navbatda `Vec<T>`-ga yig'ish orqali amalga oshiriladi.Ya'ni, quyidagilarni yozishda:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// bu biz yozgandek o'zini tutadi:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Birinchi ajratmalar to'plami bu erda sodir bo'ladi.
    ///     .into(); // `Rc<[T]>` uchun ikkinchi ajratish bu erda sodir bo'ladi.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Bu `Vec<T>` ni qurish uchun qancha kerak bo'lsa, shuncha marta ajratadi va `Vec<T>` ni `Rc<[T]>` ga aylantirish uchun bir marta ajratadi.
    ///
    ///
    /// ## Uzunligi ma'lum bo'lgan takrorlovchilar
    ///
    /// Sizning `Iterator` `TrustedLen`-ni amalga oshirganda va aniq o'lchamda bo'lsa, `Rc<[T]>` uchun bitta ajratish amalga oshiriladi.Masalan:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Bu erda faqat bitta ajratish sodir bo'ladi.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>`-ga yig'ish uchun ishlatiladigan trait ixtisosligi.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Bu `TrustedLen` iteratoriga tegishli.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // XAVFSIZLIK: Biz iteratorning aniq uzunligiga va bizda bo'lishiga ishonch hosil qilishimiz kerak.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Oddiy dasturga qaytish.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` boshqariladigan ajratmalarga egalik qilmaydigan ma'lumotlarga ega bo'lgan [`Rc`] versiyasidir.Ajratishga `Weak` ko'rsatgichida [`upgrade`] raqamiga qo'ng'iroq qilish orqali erishiladi, u [`Variant`]`<`[`Rc`] '<T>> ".
///
/// `Weak` ma'lumotnomasi egalik hisoblanmagani uchun, bu ajratmada saqlanadigan qiymatning pasayishiga to'sqinlik qilmaydi va `Weak` o'zi hali ham mavjud qiymatga kafolat bermaydi.
/// Shunday qilib, u ["yangilash"] d-da [`None`]-ni qaytarishi mumkin.
/// Shunga qaramay, `Weak` ma'lumotnomasi * ajratishni o'zi (orqa do'kon) ajratilishini oldini oladi.
///
/// `Weak` ko'rsatkichi [`Rc`] tomonidan boshqariladigan taqsimotga vaqtinchalik havolani saqlab qolish uchun foydalidir, uning ichki qiymati tushishiga yo'l qo'ymaydi.
/// Bundan tashqari, [`Rc`] ko'rsatkichlari orasidagi dumaloq havolalarni oldini olish uchun foydalaniladi, chunki o'zaro egalik qilish ma'lumotlari hech qachon [`Rc`] ning tushishiga yo'l qo'ymaydi.
/// Masalan, daraxtda ota-ona tugunlaridan bolalarga kuchli [`Rc`] ko'rsatkichlari va bolalardan ota-onalariga qaytib kelgan `Weak` ko'rsatkichlari bo'lishi mumkin.
///
/// `Weak` ko'rsatkichini olishning odatiy usuli bu [`Rc::downgrade`] ga qo'ng'iroq qilishdir.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Bu enumlarda ushbu turdagi o'lchamlarni optimallashtirishga imkon beradigan `NonNull`, ammo bu albatta to'g'ri ko'rsatgich emas.
    //
    // `Weak::new` uyumda joy ajratmaslik uchun uni `usize::MAX`-ga o'rnatadi.
    // Bu haqiqiy ko'rsatkich hech qachon ega bo'ladigan qiymat emas, chunki RcBox kamida 2 ga mos keladi.
    // Bu faqat `T: Sized` bo'lganda mumkin;o'lchamsiz `T` hech qachon chayqalmaydi.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Hech qanday xotira ajratmasdan, yangi `Weak<T>` ni yaratadi.
    /// Qaytish qiymati bo'yicha [`upgrade`]-ga qo'ng'iroq qilish har doim [`None`]-ni beradi.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Ma'lumotlar maydoni haqida hech qanday tasdiqlashsiz ma'lumotnomalar soniga kirishga ruxsat beruvchi yordamchi yozing.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Ushbu `Weak<T>` tomonidan ko'rsatilgan `T` ob'ektiga xom ko'rsatkichni qaytaradi.
    ///
    /// Ko'rsatkich ba'zi bir kuchli ma'lumotlarga ega bo'lgan taqdirdagina amal qiladi.
    /// Ko'rsatkich osilgan, hizalanmamış yoki hatto [`null`] bo'lishi mumkin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Ikkalasi ham bitta ob'ektga ishora qilmoqda
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Bu erda kuchli narsa uni tirik ushlab turadi, shuning uchun biz ob'ektga hali ham kirishimiz mumkin.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ammo endi yo'q.
    /// // Biz weak.as_ptr() qila olamiz, ammo ko'rsatgichga kirish aniqlanmagan xatti-harakatga olib keladi.
    /// // assert_eq! ("salom", xavfli {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Agar ko'rsatgich osilgan bo'lsa, biz qo'riqchini to'g'ridan-to'g'ri qaytaramiz.
            // Bu foydali yuk manzili bo'lishi mumkin emas, chunki foydali yuk kamida RcBox (usize) bilan tenglashtirilgan.
            ptr as *const T
        } else {
            // XAVFSIZLIK: agar is_dangling noto'g'ri qiymatini qaytarsa, u holda ko'rsatgich ajratilishi mumkin.
            // Ushbu vaqtda foydali yuk tushishi mumkin va biz sinovni saqlab qolishimiz kerak, shuning uchun xom ko'rsatgich manipulyatsiyasidan foydalaning.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` ni iste'mol qiladi va uni xom ko'rsatkichga aylantiradi.
    ///
    /// Bu zaif ko'rsatgichni xom ko'rsatkichga aylantiradi, shu bilan birga bitta zaif ma'lumotnomaga egalik huquqini saqlab qoladi (zaif hisoblash ushbu operatsiya bilan o'zgartirilmaydi).
    /// Uni [`from_raw`] bilan `Weak<T>` ga qaytarish mumkin.
    ///
    /// [`as_ptr`] bilan ko'rsatgichning maqsadiga kirishda bir xil cheklovlar qo'llaniladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Oldindan [`into_raw`] tomonidan yaratilgan xom ko'rsatkichni `Weak<T>` ga o'zgartiradi.
    ///
    /// Bu kuchli ma'lumotnomani xavfsiz olish uchun (keyinroq [`upgrade`] raqamiga qo'ng'iroq qilish orqali) yoki `Weak<T>`-ni tashlab zaif sonni ajratish uchun ishlatilishi mumkin.
    ///
    /// Bu bitta zaif ma'lumotnomaga egalik qiladi ([`new`] tomonidan yaratilgan ko'rsatgichlar bundan mustasno, chunki ular hech narsaga ega emas; usul hali ham ularda ishlaydi).
    ///
    /// # Safety
    ///
    /// Ko'rsatkich [`into_raw`] dan kelib chiqqan bo'lishi kerak va hali ham uning potentsial zaif ma'lumotnomasiga ega bo'lishi kerak.
    ///
    /// Bunga qo'ng'iroq qilish paytida kuchli son 0 ga teng bo'lishi mumkin.
    /// Shunga qaramay, bu hozirda xom ko'rsatgich sifatida ko'rsatilgan bitta zaif ma'lumotnomaga egalik qiladi (kuchsiz son ushbu operatsiya bilan o'zgartirilmaydi) va shuning uchun uni [`into_raw`] oldingi chaqiruvi bilan bog'lash kerak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Oxirgi zaif sonni kamaytiring.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Kirish ko'rsatkichining qanday olinishi haqida kontekstni Weak::as_ptr-ga qarang.

        let ptr = if is_dangling(ptr as *mut T) {
            // Bu osilgan zaif.
            ptr as *mut RcBox<T>
        } else {
            // Aks holda, biz ko'rsatgichni so'zma-so'z zaif tomonlardan kelib chiqqaniga kafolat beramiz.
            // XAVFSIZLIK: data_offset qo'ng'iroq qilish xavfsizdir, chunki ptr haqiqiy (potentsial tushib ketgan) T ga ishora qiladi.
            let offset = unsafe { data_offset(ptr) };
            // Shunday qilib, biz butun RcBoxni olish uchun ofsetni teskari yo'naltiramiz.
            // XAVFSIZLIK: ko'rsatkich zaif tomonlardan kelib chiqqan, shuning uchun bu ofset xavfsizdir.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // XAVFSIZLIK: biz asl zaif ko'rsatgichni tikladik, shuning uchun zaiflarni yaratamiz.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` ko'rsatkichini [`Rc`] darajasiga ko'tarishga urinishlar, agar muvaffaqiyatli bo'lsa, ichki qiymatni tushirish kechiktiriladi.
    ///
    ///
    /// Ichki qiymat o'chirilgan bo'lsa, [`None`]-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Barcha kuchli ko'rsatkichlarni yo'q qiling.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Ushbu ajratishga ishora qiluvchi kuchli (`Rc`) ko'rsatkichlari sonini oladi.
    ///
    /// Agar `self` [`Weak::new`] yordamida yaratilgan bo'lsa, bu 0 ga qaytadi.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Ushbu ajratishga ishora qiluvchi `Weak` ko'rsatkichlari sonini oladi.
    ///
    /// Agar kuchli ko'rsatkichlar qolmasa, bu nolga teng bo'ladi.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // yashirin zaif ptrni olib tashlang
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Ko'rsatkich osilib turganda va ajratilgan `RcBox` bo'lmaganida (ya'ni, bu `Weak` `Weak::new` tomonidan yaratilganida) `None` ni qaytaradi.
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Biz "data" maydonini o'z ichiga olgan ma'lumotnomani yaratmasligimizdan ehtiyot bo'lamiz *, chunki maydon bir vaqtning o'zida mutatsiyaga uchragan bo'lishi mumkin (masalan, oxirgi `Rc` tushirilsa, ma'lumotlar maydoni o'z joyiga tushib ketadi).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Ikkala Zaiflar bir xil ajratishga ishora qilsalar ([`ptr::eq`] ga o'xshash) yoki ikkalasi ham biron bir ajratishga ishora qilmasa (chunki ular `Weak::new()`) bilan yaratilgan), `true` ni qaytaradi.
    ///
    ///
    /// # Notes
    ///
    /// Bu ko'rsatkichlarni taqqoslaganligi sababli, bu `Weak::new()` har qanday ajratishga ishora qilmasa ham, bir-biriga teng bo'lishini anglatadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new`-ni taqqoslash.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` ko'rsatkichini tashlaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Hech narsa chop etmaydi
    /// drop(foo);        // "dropped!"-ni bosib chiqaradi
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // zaif hisoblash 1dan boshlanadi va barcha kuchli ko'rsatkichlar yo'qolgan taqdirdagina nolga tenglashadi.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Xuddi shu ajratishga ishora qiluvchi `Weak` ko'rsatkichining klonini yaratadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// `T` uchun xotirani uni ishga tushirmasdan ajratib, yangi `Weak<T>` ni yaratadi.
    /// Qaytish qiymati bo'yicha [`upgrade`]-ga qo'ng'iroq qilish har doim [`None`]-ni beradi.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: mem::forget bilan xavfsiz ishlash uchun biz bu erga_taddi.Ayniqsa
// agar siz mem::forget Rcs (yoki zaif) bo'lsa, ref-count oshib ketishi mumkin va siz ajratilgan Rcs (yoki zaif) mavjud bo'lganda ajratishni bo'shatishingiz mumkin.
//
// Biz abort qilamiz, chunki bu shunday degeneratsiya ssenariysi, biz nima bo'lishidan qat'iy nazar-hech bir haqiqiy dastur buni boshdan kechirmasligi kerak.
//
// Buning ahamiyati yo'q bo'lishi kerak, chunki Rust-da egalik va move-semantika tufayli bu qadar klonlashning hojati yo'q.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Qiymatni tushirish o'rniga toshib ketishni bekor qilmoqchimiz.
        // Bu chaqirilganda mos yozuvlar soni hech qachon nolga teng bo'lmaydi;
        // Shunga qaramay, biz bu erda LLVMni aks holda o'tkazib yuborilgan optimallashtirishga ishora qilish uchun abort qilamiz.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Qiymatni tushirish o'rniga toshib ketishni bekor qilmoqchimiz.
        // Bu chaqirilganda mos yozuvlar soni hech qachon nolga teng bo'lmaydi;
        // Shunga qaramay, biz bu erda LLVMni aks holda o'tkazib yuborilgan optimallashtirishga ishora qilish uchun abort qilamiz.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Ko'rsatkich orqasidagi foydali yuk uchun `RcBox` ichida ofsetni oling.
///
/// # Safety
///
/// Ko'rsatkich ilgari amal qilgan T misoliga ishora qilishi kerak (va ular uchun tegishli metadatlarga ega bo'lishi kerak), ammo T ning tushirilishiga yo'l qo'yiladi.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Tasdiqlanmagan qiymatni RcBox oxiriga tekislang.
    // RcBox repr(C) bo'lgani uchun u doimo xotiradagi so'nggi maydon bo'lib qoladi.
    // XAVFSIZLIK: mumkin bo'lmagan o'lchamlarga ega bo'lgan yagona tilim, trait moslamalari,
    // va tashqi turlar, kirish xavfsizligi talabi hozirda align_of_val_raw talablarini qondirish uchun etarli;bu std tashqarisida ishonib bo'lmaydigan tilni amalga oshirish tafsiloti.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}