#![stable(feature = "rust1", since = "1.0.0")]

//! Iplarni xavfsiz hisoblash moslamalari.
//!
//! Qo'shimcha ma'lumot uchun [`Arc<T>`][Arc] hujjatlariga qarang.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc`-ga murojaat etilishi mumkin bo'lgan ma'lumotlarning yumshoq chegarasi.
///
/// Ushbu chegaradan oshib ketish, _exactly_ `MAX_REFCOUNT + 1` ma'lumotnomalarida sizning dasturingizni bekor qiladi (shart emas).
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer xotira to'siqlarini qo'llab-quvvatlamaydi.
// Arc/Weak dasturida noto'g'ri ijobiy hisobotlardan qochish uchun uning o'rniga sinxronizatsiya uchun atomik yuklardan foydalaning.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Ip uchun xavfsiz mos yozuvlarni hisoblash ko'rsatkichi.'Arc' "Atomically Reference Counted" degan ma'noni anglatadi.
///
/// `Arc<T>` turi uyumda ajratilgan `T` tipidagi qiymatga egalik huquqini beradi.[`clone`][clone]-ni `Arc`-ga chaqirish, yangi `Arc` nusxasini hosil qiladi, bu `Arc` manbai bilan uyumda bir xil taqsimotga ishora qiladi va shu bilan mos yozuvlar sonini oshiradi.
/// Berilgan ajratmaga so'nggi `Arc` ko'rsatkichi yo'q qilinganda, ushbu ajratmada saqlanadigan qiymat (ko'pincha "inner value" deb ataladi) ham tushadi.
///
/// Rust-dagi umumiy havolalar mutatsiyani sukut bo'yicha taqiqlaydi va `Arc` istisno emas: odatda `Arc` ichidagi narsaga o'zgaruvchan ma'lumot olish mumkin emas.Agar siz `Arc` orqali mutatsiyaga muhtoj bo'lsangiz, [`Mutex`][mutex], [`RwLock`][rwlock] yoki [`Atomic`][atomic] turlaridan birini ishlating.
///
/// ## Ipning xavfsizligi
///
/// [`Rc<T>`] dan farqli o'laroq, `Arc<T>` mos yozuvlarni hisoblash uchun atom operatsiyalaridan foydalanadi.Bu shuni anglatadiki, u ipdan xavfsizdir.Kamchilik shundaki, oddiy operatsion xotiraga qaraganda atomik operatsiyalar qimmatroq.Agar siz mos yozuvlar hisoblangan ajratmalarni iplar o'rtasida baham ko'rmasangiz, [`Rc<T>`] dan pastroq xarajatlar uchun foydalaning.
/// [`Rc<T>`] xavfsiz sukut bo'yicha, chunki kompilyator [`Rc<T>`]-ni iplar orasiga yuborish uchun har qanday urinishni qo'lga kiritadi.
/// Biroq, kutubxona iste'molchilariga ko'proq moslashuvchanlikni ta'minlash uchun kutubxona `Arc<T>` ni tanlashi mumkin.
///
/// `Arc<T>` `T` [`Send`] va [`Sync`] ni amalga oshirgan ekan, [`Send`] va [`Sync`] ni amalga oshiradi.
/// Nega `T`-ga ip uchun xavfsiz bo'lmagan `T` turini qo'yishingiz mumkin emas?Avvaliga bu biroz teskari intuitiv bo'lishi mumkin: axir, `Arc<T>` ipining xavfsizligi emasmi?Kalit shu: `Arc<T>` bir xil ma'lumotlarga bir nechta egalik qilishni xavfsizligini ta'minlaydi, ammo u ma'lumotlariga xavfsizlik xavfsizligini qo'shmaydi.
///
/// "Arc <" [`RefCell<T>"]">".
/// [`RefCell<T>`] [`Sync`] emas va agar `Arc<T>` har doim [`Send`] bo'lsa, "Arc <" [`RefCell<T>"]">"ham bo'lar edi.
/// Ammo keyin bizda muammo bo'ladi:
/// [`RefCell<T>`] ip xavfsiz emas;u atom bo'lmagan operatsiyalar yordamida qarzlar sonini hisobga oladi.
///
/// Oxir oqibat, bu sizga `Arc<T>`-ni ba'zi bir [`std::sync`] tiplari bilan, odatda [`Mutex<T>`][mutex] bilan bog'lashingiz kerak bo'lishi mumkinligini anglatadi.
///
/// ## `Weak` bilan tsikllarni buzish
///
/// [`downgrade`][downgrade] usuli egasi bo'lmagan [`Weak`] ko'rsatkichini yaratish uchun ishlatilishi mumkin.[`Weak`] ko'rsatkichi `Arc` ga [`upgrade '][upgrade] d bo'lishi mumkin, ammo bu [`None`]-ni ajratishda saqlangan qiymat allaqachon tushirilgan bo'lsa qaytaradi.
/// Boshqacha qilib aytganda, `Weak` ko'rsatkichlari ajratish ichidagi qiymatni saqlab turmaydi;ammo, ular ajratishni (qiymatni qo'llab-quvvatlash do'konini) jonli saqlashadi.
///
/// `Arc` ko'rsatkichlari orasidagi tsikl hech qachon taqsimlanmaydi.
/// Shu sababli, [`Weak`] tsikllarni sindirish uchun ishlatiladi.Masalan, daraxtda ota-ona tugunlaridan bolalarga kuchli `Arc` ko'rsatkichlari va bolalardan ota-onalariga qaytadigan [`Weak`] ko'rsatkichlari bo'lishi mumkin.
///
/// # Ma'lumotnomalarni klonlash
///
/// Mavjud mos yozuvlar hisoblangan ko'rsatgichdan yangi ma'lumotnoma yaratish [`Arc<T>`][Arc] va [`Weak<T>`][Weak] uchun amalga oshirilgan `Clone` trait yordamida amalga oshiriladi.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Quyidagi ikkita sintaksis tengdir.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b va foo-barchasi bir xil xotira joylashgan joyni ko'rsatadigan yoylar
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` avtomatik ravishda `T`-ga ([`Deref`][deref] trait orqali) murojaat qiladi, shuning uchun siz `Arc<T>` tipidagi qiymat bo'yicha "T" usullarini chaqirishingiz mumkin."T" usullari bilan nomlarning to'qnashuviga yo'l qo'ymaslik uchun `Arc<T>` usullari o'zaro bog'liq funktsiyalar bo'lib, [fully qualified syntax] yordamida chaqiriladi:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// Ark<T>`Clone` kabi traits dasturlarini to'liq malakali sintaksis yordamida ham chaqirish mumkin.
/// Ba'zi odamlar to'liq malakali sintaksisdan foydalanishni afzal ko'rishadi, boshqalari esa metod-chaqiruv sintaksisidan foydalanishni afzal ko'rishadi.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Qo'ng'iroq sintaksisining usuli
/// let arc2 = arc.clone();
/// // To'liq malakali sintaksis
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T`-ga avtomatik ravishda murojaat qilmaydi, chunki ichki qiymat allaqachon tushib ketgan bo'lishi mumkin.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Mavzular o'rtasida bir nechta o'zgarmas ma'lumotlarni almashish:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Shuni esda tutingki, biz ushbu testlarni bu erda ** o'tkazmaymiz.
// Agar ip asosiy ipdan uzoqroq bo'lsa va keyin bir vaqtning o'zida chiqsa (biron narsa yopiq bo'lsa), windows ishlab chiqaruvchilari juda baxtsiz bo'ladilar, shuning uchun biz ushbu sinovlarni o'tkazmasdan butunlay bundan qochamiz.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// O'zgaruvchan [`AtomicUsize`] bilan bo'lishish:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Umuman ma'lumotni hisoblashning ko'proq misollari uchun [`rc` documentation][rc_examples]-ga qarang.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` boshqariladigan ajratmalarga egalik qilmaydigan ma'lumotlarga ega bo'lgan [`Arc`] versiyasidir.
/// X001 raqamiga qo'ng'iroq qilish orqali ajratishga `Weak` ko'rsatkichi orqali erishiladi, u [`Variant`]`<`[`Arc`] '<T>> ".
///
/// `Weak` ma'lumotnomasi egalik hisoblanmagani uchun, bu ajratmada saqlanadigan qiymatning pasayishiga to'sqinlik qilmaydi va `Weak` o'zi hali ham mavjud qiymatga kafolat bermaydi.
///
/// Shunday qilib, u ["yangilash"] d-da [`None`]-ni qaytarishi mumkin.
/// Shunga qaramay, `Weak` ma'lumotnomasi * ajratishni o'zi (orqa do'kon) ajratilishini oldini oladi.
///
/// `Weak` ko'rsatkichi [`Arc`] tomonidan boshqariladigan taqsimotga vaqtinchalik havolani saqlab qolish uchun foydalidir, uning ichki qiymati tushishiga yo'l qo'ymaydi.
/// Bundan tashqari, [`Arc`] ko'rsatkichlari orasidagi dumaloq havolalarni oldini olish uchun foydalaniladi, chunki o'zaro egalik qilish ma'lumotlari hech qachon [`Arc`] ning tushishiga yo'l qo'ymaydi.
/// Masalan, daraxtda ota-ona tugunlaridan bolalarga kuchli [`Arc`] ko'rsatkichlari va bolalardan ota-onalariga qaytib kelgan `Weak` ko'rsatkichlari bo'lishi mumkin.
///
/// `Weak` ko'rsatkichini olishning odatiy usuli bu [`Arc::downgrade`] ga qo'ng'iroq qilishdir.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Bu enumlarda ushbu turdagi o'lchamlarni optimallashtirishga imkon beradigan `NonNull`, ammo bu albatta to'g'ri ko'rsatgich emas.
    //
    // `Weak::new` uyumda joy ajratmaslik uchun uni `usize::MAX`-ga o'rnatadi.
    // Bu haqiqiy ko'rsatkich hech qachon ega bo'ladigan qiymat emas, chunki RcBox kamida 2 ga mos keladi.
    // Bu faqat `T: Sized` bo'lganda mumkin;o'lchamsiz `T` hech qachon chayqalmaydi.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Bu repr(C)-dan future-ga mumkin bo'lgan maydonni qayta tartiblashdan himoya qiladi, bu esa o'zgaruvchan ichki turdagi [into|from]_raw()-ga xalaqit beradi.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX qiymati vaqtincha "locking" zaif ko'rsatkichlarni yangilash yoki kuchli ko'rsatkichlarni pasaytirish qobiliyati uchun qo'riqchi vazifasini bajaradi;bu `make_mut` va `get_mut`-da musobaqalardan qochish uchun ishlatiladi.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Yangi `Arc<T>` quradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Zaif ko'rsatkichni 1 sifatida boshlang, ya'ni (kinda) kuchli ko'rsatgichlari ushlab turadigan zaif ko'rsatkich, qo'shimcha ma'lumot uchun std/rc.rs ga qarang.
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// O'ziga nisbatan zaif ma'lumotdan foydalangan holda yangi `Arc<T>` ni yaratadi.
    /// Ushbu funktsiya qaytmasidan oldin zaif ma'lumotnomani yangilashga urinish `None` qiymatiga olib keladi.
    /// Shu bilan birga, zaif ma'lumotnomani erkin klonlash va undan keyin foydalanish uchun saqlash mumkin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Ichki qismni "uninitialized" holatida bitta zaif mos yozuvlar bilan yarating.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Zaif ko'rsatkichga egalik huquqidan voz kechmasligimiz muhim, aks holda `data_fn` qaytguncha xotirani bo'shatish mumkin.
        // Agar biz haqiqatan ham egalik huquqidan o'tishni xohlasak, o'zimiz uchun qo'shimcha zaif ko'rsatgichni yaratishimiz mumkin edi, ammo bu zaif ma'lumotnomalar soniga qo'shimcha yangilanishlarni keltirib chiqaradi, aks holda bu kerak emas.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Endi biz ichki qiymatni to'g'ri boshlashimiz va zaif ma'lumotnomamizni kuchli ma'lumotnomaga aylantirishimiz mumkin.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ma'lumotlar maydoniga yuqoridagi yozuv nolga teng bo'lmagan kuchli hisoblashni kuzatadigan har qanday oqim uchun ko'rinishi kerak.
            // Shuning uchun `Weak::upgrade` da `compare_exchange_weak` bilan sinxronlash uchun bizga kamida "Release" buyurtma kerak.
            //
            // "Acquire" buyurtma talab qilinmaydi.
            // `data_fn`-ning mumkin bo'lgan xatti-harakatlarini ko'rib chiqayotganda, biz faqatgina yangilanib bo'lmaydigan `Weak`-ga murojaat qilish bilan nima qilishi mumkinligini ko'rib chiqishimiz kerak:
            //
            // - U zaif ma'lumotnomalarni ko'paytirib, `Weak` ni *klonlashi* mumkin.
            // - U kuchsiz mos yozuvlar sonini kamaytirib, ushbu klonlarni tushirishi mumkin (lekin hech qachon nolga teng emas).
            //
            // Ushbu nojo'ya ta'sirlar bizga hech qanday ta'sir qilmaydi va faqatgina xavfsiz kod bilan boshqa nojo'ya ta'sirlar mumkin emas.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Kuchli ma'lumotnomalar birgalikda umumiy zaif ma'lumotlarga egalik qilishi kerak, shuning uchun eski zaif ma'lumotnomamiz uchun destruktorni ishlatmang.
        //
        mem::forget(weak);
        strong
    }

    /// Boshlanmagan tarkibga ega yangi `Arc` ni yaratadi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `0` bayt bilan to'ldirilgan, boshlanmagan tarkibga ega yangi `Arc` ni yaratadi.
    ///
    ///
    /// Ushbu usuldan to'g'ri va noto'g'ri foydalanish misollari uchun [`MaybeUninit::zeroed`][zeroed]-ga qarang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yangi `Pin<Arc<T>>` quradi.
    /// Agar `T` `Unpin`-ni amalga oshirmasa, u holda `data` xotirada saqlanadi va uni ko'chirish mumkin emas.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Yangi `Arc<T>`-ni quradi, agar ajratish amalga oshmasa, xatoni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Zaif ko'rsatkichni 1 sifatida boshlang, ya'ni (kinda) kuchli ko'rsatgichlari ushlab turadigan zaif ko'rsatkich, qo'shimcha ma'lumot uchun std/rc.rs ga qarang.
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Boshlanmagan tarkibga ega yangi `Arc`-ni quradi, agar ajratish amalga oshmasa, xatolikni qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Boshlanmagan tarkibga ega bo'lgan yangi `Arc`-ni quradi, xotira `0` bayt bilan to'ldirilib, ajratish amalga oshmasa, xatolikni qaytaradi.
    ///
    ///
    /// Ushbu usuldan to'g'ri va noto'g'ri foydalanish misollari uchun [`MaybeUninit::zeroed`][zeroed]-ga qarang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Ichki qiymatni qaytaradi, agar `Arc` aniq bitta kuchli ma'lumotga ega bo'lsa.
    ///
    /// Aks holda, [`Err`] yuborilgan xuddi shu `Arc` bilan qaytariladi.
    ///
    ///
    /// Agar zaif zaif ma'lumotnomalar mavjud bo'lsa ham, bu muvaffaqiyatli bo'ladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Yashirin kuchli va zaif ma'lumotnomani tozalash uchun zaif ko'rsatkichni yarating
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Boshlanmagan tarkibga ega bo'lgan yangi atomik mos yozuvlar bilan hisoblangan bo'lakni quradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Xotira `0` bayt bilan to'ldirilgan, boshlanmagan tarkibga ega yangi atomik mos yozuvlar bilan hisoblangan tilimni quradi.
    ///
    ///
    /// Ushbu usuldan to'g'ri va noto'g'ri foydalanish misollari uchun [`MaybeUninit::zeroed`][zeroed]-ga qarang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` ga o'zgartiradi.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-da bo'lgani kabi, ichki qiymat haqiqatan ham boshlang'ich holatida bo'lishiga kafolat beruvchiga murojaat qilish kerak.
    ///
    /// Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish darhol aniqlanmagan xatti-harakatlarni keltirib chiqaradi.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` ga o'zgartiradi.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-da bo'lgani kabi, ichki qiymat haqiqatan ham boshlang'ich holatida bo'lishiga kafolat beruvchiga murojaat qilish kerak.
    ///
    /// Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish darhol aniqlanmagan xatti-harakatlarni keltirib chiqaradi.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// O'ralgan ko'rsatgichni qaytarib, `Arc` ni sarflaydi.
    ///
    /// Xotiradan qochib qutulmaslik uchun ko'rsatgichni [`Arc::from_raw`] yordamida `Arc` ga qaytarish kerak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Ma'lumotlarga xom ko'rsatkichni taqdim etadi.
    ///
    /// Hisob-kitoblarga hech qanday ta'sir ko'rsatilmaydi va `Arc` iste'mol qilinmaydi.
    /// Ko'rsatkich `Arc`-da kuchli hisoblar mavjud bo'lgan vaqtgacha amal qiladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // XAVFSIZLIK: Deref::deref yoki RcBoxPtr::inner orqali o'tib bo'lmaydi, chunki
        // masalan, raw/mut tajribasini saqlab qolish uchun talab qilinadi
        // `get_mut` Rc `from_raw` orqali tiklangandan keyin ko'rsatgich orqali yozishi mumkin.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// `Arc<T>` ni xom ko'rsatgichdan tuzadi.
    ///
    /// Xom ko'rsatgich ilgari [`Arc<U>::into_raw`][into_raw] raqamiga qo'ng'iroq bilan qaytarilgan bo'lishi kerak, bu erda `U` `T` bilan bir xil o'lchamga va tekislikka ega bo'lishi kerak.
    /// Agar `U` `T` bo'lsa, bu juda ahamiyatli emas.
    /// E'tibor bering, agar `U` `T` bo'lmasa, lekin o'lchamlari va hizalanishi bir xil bo'lsa, bu asosan har xil turdagi mos yozuvlar transmutingiga o'xshaydi.
    /// Ushbu holatda qanday cheklovlar qo'llanilishi haqida ko'proq ma'lumot olish uchun [`mem::transmute`][transmute]-ga qarang.
    ///
    /// `from_raw` foydalanuvchisi `T` qiymatining atigi bir marta tushishiga ishonch hosil qilishi kerak.
    ///
    /// Ushbu funktsiya xavfli emas, chunki noto'g'ri ishlatilganligi, hatto qaytarilgan `Arc<T>`-ga hech qachon ulanmasa ham xotiraning xavfsizligini keltirib chiqarishi mumkin.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Oqishning oldini olish uchun `Arc`-ga qayting.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)`-ga qo'shimcha qo'ng'iroqlar xotirada xavfli bo'ladi.
    /// }
    ///
    /// // `x` yuqoridagi doiradan chiqib ketganda xotira bo'shatildi, shuning uchun `x_ptr` endi osilib qoldi!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Asl ArcInner-ni topish uchun ofsetni orqaga qaytaring.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Ushbu ajratishga yangi [`Weak`] ko'rsatkichini yaratadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Bu Relaxed yaxshi, chunki biz quyidagi CAS qiymatini tekshiramiz.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // zaif hisoblagich hozirda "locked" ekanligini tekshiring;agar shunday bo'lsa, aylantiring.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ushbu kod hozirgi vaqtda toshib ketish imkoniyatini inobatga olmaydi
            // usize::MAX ichiga;umuman olganda, Rc va Arc ikkalasini ham to'ldirish uchun sozlash kerak.
            //

            // Clone()-dan farqli o'laroq, biz buni `is_unique`-dan keladigan yozuv bilan sinxronlashtirish uchun Acquire o'qishimiz kerak, shunda yozishdan oldingi voqealar ushbu o'qishdan oldin sodir bo'ladi.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Biz osilgan zaifni yaratmasligimizga ishonch hosil qiling
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Ushbu taqsimotga [`Weak`] ko'rsatkichlari sonini oladi.
    ///
    /// # Safety
    ///
    /// Ushbu usul o'zi xavfsizdir, ammo uni to'g'ri ishlatish qo'shimcha ehtiyotkorlikni talab qiladi.
    /// Boshqa bir ip har qanday vaqtda zaif sonni o'zgartirishi mumkin, shu jumladan potentsial ravishda ushbu usulni chaqirish va natijaga qarab harakat qilish.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ushbu tasdiq deterministik, chunki biz `Arc` yoki `Weak`-ni ish zarrachalari o'rtasida taqsimlamadik.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Agar hozirda zaif hisoblash bloklangan bo'lsa, hisoblash qiymati qulfni olishdan oldin 0 ga teng edi.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Ushbu ajratishga kuchli (`Arc`) ko'rsatkichlari sonini oladi.
    ///
    /// # Safety
    ///
    /// Ushbu usul o'zi xavfsizdir, ammo uni to'g'ri ishlatish qo'shimcha ehtiyotkorlikni talab qiladi.
    /// Boshqa bir ip har qanday vaqtda kuchli sonni o'zgartirishi mumkin, shu jumladan ushbu usulni chaqirish va natijaga qarab harakat qilish o'rtasida.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ushbu tasdiq deterministik, chunki biz `Arc`-ni ish zarrachalari o'rtasida bo'lishmaganmiz.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Taqdim etilgan ko'rsatgich bilan bog'liq bo'lgan `Arc<T>` bo'yicha aniq ma'lumotlarning sonini birma-bir oshiradi.
    ///
    /// # Safety
    ///
    /// Ko'rsatkich `Arc::into_raw` orqali olingan bo'lishi kerak va bog'liq bo'lgan `Arc` misoli haqiqiy bo'lishi kerak (ya'ni
    /// kuchli hisoblash ushbu usul davomiyligi uchun kamida 1) bo'lishi kerak.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ushbu tasdiq deterministik, chunki biz `Arc`-ni ish zarrachalari o'rtasida bo'lishmaganmiz.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Arc-ni ushlab turing, lekin ManualDrop-ga o'ralgan holda qayta sanashga tegmang
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Endi qayta hisoblashni oshiring, ammo yangi qayta hisoblashni ham tashlamang
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Berilgan ko'rsatgich bilan bog'liq bo'lgan `Arc<T>`-ga kuchli mos yozuvlar sonini birma-bir kamaytiradi.
    ///
    /// # Safety
    ///
    /// Ko'rsatkich `Arc::into_raw` orqali olingan bo'lishi kerak va bog'liq bo'lgan `Arc` misoli haqiqiy bo'lishi kerak (ya'ni
    /// ushbu usulni qo'llashda kuchli hisoblash kamida 1) bo'lishi kerak.
    /// Ushbu usul oxirgi `Arc` va zaxira omborini chiqarish uchun ishlatilishi mumkin, ammo **so'nggi `Arc` chiqarilgandan keyin** chaqirilmasligi kerak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ushbu tasdiqlar deterministikdir, chunki biz `Arc`-ni ish zarralari o'rtasida bo'lishmaganmiz.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Xavfsizlik yaxshi, chunki bu kamon tirik bo'lganida, biz ichki ko'rsatgichning haqiqiyligiga kafolat beramiz.
        // Bundan tashqari, biz `ArcInner` tuzilishining o'zi `Sync` ekanligini bilamiz, chunki ichki ma'lumotlar `Sync`, shuning uchun biz ushbu tarkibga o'zgarmas ko'rsatgichni taqdim etamiz.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` ning chiziqsiz qismi.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Ma'lumotlarni hozircha yo'q qiling, garchi biz qutini ajratishni o'zi ozod qilmasak ham (atrofida hali ham zaif ko'rsatkichlar yotishi mumkin).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Barcha kuchli ma'lumotlarga ega bo'lgan zaif refni tushiring
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Ikkala Arc bir xil ajratishga ishora qilsa ([`ptr::eq`] ga o'xshash tomirda) `true`-ni qaytaradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// `ArcInner<T>`-ni ichki o'lcham uchun etarlicha bo'sh joyga ajratadi, bu erda qiymat taqdim etilgan tartibga ega.
    ///
    /// `mem_to_arcinner` funktsiyasi ma'lumotlar ko'rsatgichi bilan chaqiriladi va `ArcInner<T>` uchun (potentsial yog ') ko'rsatkichini qaytarishi kerak.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Berilgan qiymat maketidan foydalanib tartibni hisoblang.
        // Ilgari, tartib `&*(ptr as* const ArcInner<T>)` ifodasida hisoblangan, ammo bu noto'g'ri mos yozuvlar yaratgan (#54908 ga qarang).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// `ArcInner<T>`-ni ajratib bo'lmaydigan ichki qiymat uchun etarli joy bilan ajratadi, bu erda qiymat joylashtirilgan bo'lsa, ajratish amalga oshmasa xato bo'ladi.
    ///
    ///
    /// `mem_to_arcinner` funktsiyasi ma'lumotlar ko'rsatgichi bilan chaqiriladi va `ArcInner<T>` uchun (potentsial yog ') ko'rsatkichini qaytarishi kerak.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Berilgan qiymat maketidan foydalanib tartibni hisoblang.
        // Ilgari, tartib `&*(ptr as* const ArcInner<T>)` ifodasida hisoblangan, ammo bu noto'g'ri mos yozuvlar yaratgan (#54908 ga qarang).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner-ni ishga tushiring
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// `ArcInner<T>` o'lchamsiz ichki qiymat uchun etarli joy ajratadi.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Berilgan qiymatdan foydalanib, `ArcInner<T>` uchun ajrating.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Qiymatni bayt sifatida nusxalash
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Tarkibni tushirmasdan ajratishni bepul qiling
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Berilgan uzunlikdagi `ArcInner<[T]>`-ni ajratadi.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Elementlarni tilimdan yangi ajratilgan Arc <\[T\]> ga nusxalash
    ///
    /// Xavfli emas, chunki qo'ng'iroq qiluvchi egalik huquqini olishi yoki `T: Copy`-ni bog'lashi kerak.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// `Arc<[T]>` ni ma'lum o'lchamdagi iteratordan tuzadi.
    ///
    /// Hajmi noto'g'ri bo'lsa, o'zini tutishi aniqlanmagan.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // T elementlarini klonlash paytida Panic qo'riqchisi.
        // Agar panic bo'lsa, yangi ArcInner-ga yozilgan elementlar tushiriladi, so'ngra xotira bo'shaydi.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Birinchi elementga ishora
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Hammasi aniq.Yangi ArcInner-ni bo'shatmasligi uchun qo'riqchini unuting.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` uchun ishlatiladigan trait ixtisosligi.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` ko'rsatkichining klonini yaratadi.
    ///
    /// Bu xuddi shu taqsimotga yana bir ko'rsatkichni yaratadi va kuchli mos yozuvlar sonini oshiradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Bu erda qulay buyurtma berish yaxshi, chunki asl ma'lumotni bilish boshqa iplarni ob'ektni noto'g'ri o'chirishga imkon bermaydi.
        //
        // [Boost documentation][1] da aytib o'tilganidek, mos yozuvlar hisoblagichini ko'paytirishni har doim memory_order_relaxed yordamida amalga oshirish mumkin: Ob'ektga yangi havolalar faqat mavjud bo'lgan ma'lumotnomadan shakllanishi mumkin va mavjud ma'lumotnomani bitta ipdan ikkinchisiga o'tkazish allaqachon kerakli sinxronizatsiyani ta'minlashi kerak.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Ammo kimdir Armsni "mem: : unutib qo'ygan" bo'lsa, biz uni katta miqdordagi qayta hisoblashdan saqlanishimiz kerak.
        // Agar biz buni qilmasak, hisob ko'payib ketishi mumkin va foydalanuvchilar bepul foydalanish imkoniyatidan foydalanadilar.
        // Bir vaqtning o'zida mos yozuvlar sonini ko'paytiradigan ~2 milliard iplar mavjud emas deb taxmin qilib, biz `isize::MAX`-ga juda to'yinganmiz.
        //
        // Ushbu branch hech qachon biron bir real dasturda olinmaydi.
        //
        // Biz abort qilamiz, chunki bunday dastur nihoyatda tanazzulga uchragan va biz uni qo'llab-quvvatlashimizga ahamiyat bermaymiz.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Berilgan `Arc` ga o'zgaruvchan mos yozuvlar qiladi.
    ///
    /// Agar bir xil taqsimotga tegishli boshqa `Arc` yoki [`Weak`] ko'rsatkichlari mavjud bo'lsa, unda `make_mut` yangi ajratishni yaratadi va noyob egalikni ta'minlash uchun ichki qiymatda [`clone`][clone] ni chaqiradi.
    /// Bu, shuningdek, klon yozish deb nomlanadi.
    ///
    /// Shuni yodda tutingki, bu qolgan `Weak` ko'rsatkichlarini ajratib turadigan [`Rc::make_mut`] xatti-harakatlaridan farq qiladi.
    ///
    /// Klonlash o'rniga ishlamaydigan [`get_mut`][get_mut]-ga qarang.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Hech narsa klonlanmaydi
    /// let mut other_data = Arc::clone(&data); // Ichki ma'lumotlar klonlanmaydi
    /// *Arc::make_mut(&mut data) += 1;         // Ichki ma'lumotlarni klonlaydi
    /// *Arc::make_mut(&mut data) += 1;         // Hech narsa klonlanmaydi
    /// *Arc::make_mut(&mut other_data) *= 2;   // Hech narsa klonlanmaydi
    ///
    /// // Endi `data` va `other_data` turli xil ajratmalarga ishora qilmoqda.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // E'tibor bering, biz kuchli ma'lumotni ham, zaif ma'lumotnomani ham qo'llaymiz.
        // Shunday qilib, bizning kuchli ma'lumotnomamizni chiqarish, o'z-o'zidan xotirani ajratishga olib kelmaydi.
        //
        // X001 ga yozilishlar (ya'ni pasayishlar) chiqarilishidan oldin sodir bo'ladigan `weak` ga yozishni ko'rishimiz uchun Acquire-dan foydalaning.
        // Biz zaif hisobni ushlab turganimiz sababli, ArcInner-ning o'zi taqsimlanishi mumkin emas.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Boshqa kuchli ko'rsatkich mavjud, shuning uchun biz klonlashimiz kerak.
            // Klonlangan qiymatni to'g'ridan-to'g'ri yozish uchun xotirani oldindan ajratib oling.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Yuqorida aytib o'tilganlar bilan xotirjam bo'lish kifoya, chunki bu asosan optimallashtirishdir: biz doimo zaif ko'rsatkichlarni tashlab, poyga qilamiz.
            // Eng yomoni, biz keraksiz ravishda yangi Arc ajratamiz.
            //

            // Biz oxirgi kuchli refni olib tashladik, ammo qo'shimcha zaif reflar qolgan.
            // Tarkibni yangi yoyga o'tkazamiz va boshqa kuchsiz reflarni bekor qilamiz.
            //

            // Shuni yodda tutingki, `weak` o'qishida usize::MAX (ya'ni qulflangan) hosil bo'lishi mumkin emas, chunki zaif sonni faqat kuchli mos yozuvlar bilan ip qulflashi mumkin.
            //
            //

            // ArcInner-ni kerak bo'lganda tozalashi uchun o'zimizning aniq zaif ko'rsatkichimizni moddiylashtiring.
            //
            let _weak = Weak { ptr: this.ptr };

            // Faqatgina ma'lumotlarni o'g'irlashi mumkin, faqat zaiflar qoladi
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Biz har qanday turdagi yagona ma'lumotnoma edik;orqaga qaytarish kuchli ref hisoblash.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()`-da bo'lgani kabi, havfsizlik yaxshi, chunki bizning ma'lumotnomamiz noyob bo'lgan yoki tarkibni klonlash bilan birlashtirilgan.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Agar bir xil ajratishga boshqa `Arc` yoki [`Weak`] ko'rsatkichlari bo'lmasa, berilgan `Arc` ga o'zgaruvchan ma'lumotni qaytaradi.
    ///
    ///
    /// [`None`]-ni qaytaradi, aks holda umumiy qiymatni mutatsiyalash xavfsiz emas.
    ///
    /// Boshqa ko'rsatkichlar mavjud bo'lganda ichki qiymatni [`clone`][clone] qiladigan [`make_mut`][make_mut]-ga ham qarang.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Bu xavfli emas, chunki biz qaytarilgan ko'rsatgich T ga qaytariladigan *only* ko'rsatkichi ekanligiga kafolat beramiz.
            // Bizning ma'lumotnomamiz ushbu nuqtada 1 bo'lishi kafolatlanadi va biz Arkning o'zi `mut` bo'lishini talab qildik, shuning uchun ichki ma'lumotlarga mumkin bo'lgan yagona ma'lumotni qaytaramiz.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// H00X-ga o'zgartirilishi mumkin bo'lgan ma'lumotnomani hech qanday tekshiruvsiz qaytaradi.
    ///
    /// [`get_mut`]-ga qarang, u xavfsiz va tegishli tekshiruvlarni amalga oshiradi.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Xuddi shu taqsimotga tegishli har qanday boshqa `Arc` yoki [`Weak`] ko'rsatkichlari qaytarilgan qarz muddati davomida ajratilmasligi kerak.
    ///
    /// Agar bunday ko'rsatgichlar mavjud bo'lmasa, masalan, `Arc::new` dan keyin darhol ahamiyatsiz bo'ladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Biz "count" maydonlarini qamrab oladigan ma'lumotnoma yaratmasligimizdan * ehtiyot bo'lamiz, chunki bu mos yozuvlar soniga bir vaqtning o'zida kirish bilan taxallusni keltirib chiqaradi (masalan
        // `Weak` tomonidan).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Bu asosiy ma'lumotlarga noyob ma'lumotnoma (shu jumladan zaif referlar) ekanligini aniqlang.
    ///
    ///
    /// Shuni esda tutingki, bu zaif ref hisobini bloklashni talab qiladi.
    fn is_unique(&mut self) -> bool {
        // biz zaif ko'rsatgich egasi bo'lib ko'rinadigan bo'lsak, zaif ko'rsatkichlar sonini bloklang.
        //
        // Bu erda sotib olish yorlig'i `weak` sonini kamaytirishdan oldin (xususan `Weak::upgrade` da) `strong`-ga (masalan, `Weak::upgrade`-ga) har qanday yozuvlar bilan aloqani ta'minlaydi.
        // Agar yangilangan zaif ref hech qachon tashlanmagan bo'lsa, bu erda CAS ishlamay qoladi, shuning uchun biz sinxronlashtirishga ahamiyat bermaymiz.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // `drop` hisoblagichining pasayishi bilan sinxronlash uchun `drop` bo'lishi kerak `drop`-bu faqat oxirgi ma'lumotdan boshqa har qanday narsa o'chirilganda sodir bo'ladigan yagona kirish.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Bu erda yozish `downgrade`-da o'qish bilan sinxronizatsiya qiladi va `strong`-ning yuqoridagi o'qishini yozishdan keyin sodir bo'lishining oldini oladi.
            //
            //
            self.inner().weak.store(1, Release); // qulfni qo'yib yuboring
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` ni tashlaydi.
    ///
    /// Bu kuchli ma'lumotlarning sonini kamaytiradi.
    /// Agar kuchli ma'lumotlarning soni nolga etadigan bo'lsa, unda boshqa havolalar (agar mavjud bo'lsa) [`Weak`], shuning uchun biz ichki qiymatni `drop` qilamiz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Hech narsa chop etmaydi
    /// drop(foo2);   // "dropped!"-ni bosib chiqaradi
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` allaqachon atomik bo'lganligi sababli, biz ob'ektni o'chirmoqchi bo'lsak, boshqa iplar bilan sinxronlashimiz shart emas.
        // Xuddi shu mantiq quyidagi `fetch_sub` uchun `weak` soniga tegishli.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Ushbu to'siq ma'lumotlardan foydalanish tartibini o'zgartirish va ma'lumotlarning yo'q qilinishini oldini olish uchun kerak.
        // `Release` bilan belgilanganligi sababli, mos yozuvlar sonining kamayishi ushbu `Acquire` panjara bilan sinxronlashtiriladi.
        // Bu shuni anglatadiki, ma'lumotlardan foydalanish mos yozuvlar sonini kamaytirishdan oldin sodir bo'ladi, bu to'siqdan oldin sodir bo'ladi, bu ma'lumotlar o'chirilishidan oldin sodir bo'ladi.
        //
        // [Boost documentation][1] da tushuntirilganidek,
        //
        // > Ob'ektga mumkin bo'lgan har qanday kirish huquqini bittasida amalga oshirish muhimdir
        // > o'chirishdan oldin * sodir bo'lishi uchun (mavjud ma'lumotnoma orqali)
        // > ob'ekt boshqa ipda.Bunga "release" orqali erishiladi
        // > ma'lumotnomani tashlaganidan keyin operatsiya (ob'ektga har qanday kirish
        // > ushbu havola orqali oldin sodir bo'lishi kerak) va an
        // > "acquire" ob'ektni o'chirishdan oldin ishlash.
        //
        // Xususan, Arc-ning tarkibi odatda o'zgarmas bo'lsa-da, Mutex-ga o'xshash ichki yozuvlarga ega bo'lish mumkin.<T>.
        // Mutex o'chirilgandan so'ng uni sotib olinmagani uchun, biz uni V satrida ishlaydigan destruktorga ko'rinadigan qilib A satriga yozishni amalga oshirish uchun uning sinxronizatsiya mantig'iga tayanolmaymiz.
        //
        //
        // Shuni ham unutmangki, bu erda sotib olish panjarasi, ehtimol, juda og'ir vaziyatlarda ishlashni yaxshilashi mumkin bo'lgan yuk bilan almashtirilishi mumkin.[2]-ga qarang.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>`-ni beton turiga tushirishga urinish.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Hech qanday xotira ajratmasdan, yangi `Weak<T>` ni yaratadi.
    /// Qaytish qiymati bo'yicha [`upgrade`]-ga qo'ng'iroq qilish har doim [`None`]-ni beradi.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Ma'lumotlar maydoni haqida hech qanday tasdiqlashsiz ma'lumotnomalar soniga kirishga ruxsat beruvchi yordamchi yozing.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Ushbu `Weak<T>` tomonidan ko'rsatilgan `T` ob'ektiga xom ko'rsatkichni qaytaradi.
    ///
    /// Ko'rsatkich ba'zi bir kuchli ma'lumotlarga ega bo'lgan taqdirdagina amal qiladi.
    /// Ko'rsatkich osilgan, hizalanmamış yoki hatto [`null`] bo'lishi mumkin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Ikkalasi ham bitta ob'ektga ishora qilmoqda
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Bu erda kuchli narsa uni tirik ushlab turadi, shuning uchun biz ob'ektga hali ham kirishimiz mumkin.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ammo endi yo'q.
    /// // Biz weak.as_ptr() qila olamiz, ammo ko'rsatgichga kirish aniqlanmagan xatti-harakatga olib keladi.
    /// // assert_eq! ("salom", xavfli {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Agar ko'rsatgich osilgan bo'lsa, biz qo'riqchini to'g'ridan-to'g'ri qaytaramiz.
            // Bu foydali yuk manzili bo'lishi mumkin emas, chunki foydali yuk kamida ArcInner (usize) bilan hizalanadi.
            ptr as *const T
        } else {
            // XAVFSIZLIK: agar is_dangling noto'g'ri qiymatini qaytarsa, u holda ko'rsatgich ajratilishi mumkin.
            // Ushbu vaqtda foydali yuk tushishi mumkin va biz sinovni saqlab qolishimiz kerak, shuning uchun xom ko'rsatgich manipulyatsiyasidan foydalaning.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` ni iste'mol qiladi va uni xom ko'rsatkichga aylantiradi.
    ///
    /// Bu zaif ko'rsatgichni xom ko'rsatkichga aylantiradi, shu bilan birga bitta zaif ma'lumotnomaga egalik huquqini saqlab qoladi (zaif hisoblash ushbu operatsiya bilan o'zgartirilmaydi).
    /// Uni [`from_raw`] bilan `Weak<T>` ga qaytarish mumkin.
    ///
    /// [`as_ptr`] bilan ko'rsatgichning maqsadiga kirishda bir xil cheklovlar qo'llaniladi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Oldindan [`into_raw`] tomonidan yaratilgan xom ko'rsatkichni `Weak<T>` ga o'zgartiradi.
    ///
    /// Bu kuchli ma'lumotnomani xavfsiz olish uchun (keyinroq [`upgrade`] raqamiga qo'ng'iroq qilish orqali) yoki `Weak<T>`-ni tashlab zaif sonni ajratish uchun ishlatilishi mumkin.
    ///
    /// Bu bitta zaif ma'lumotnomaga egalik qiladi ([`new`] tomonidan yaratilgan ko'rsatgichlar bundan mustasno, chunki ular hech narsaga ega emas; usul hali ham ularda ishlaydi).
    ///
    /// # Safety
    ///
    /// Ko'rsatkich [`into_raw`] dan kelib chiqqan bo'lishi kerak va hali ham uning potentsial zaif ma'lumotnomasiga ega bo'lishi kerak.
    ///
    /// Bunga qo'ng'iroq qilish paytida kuchli son 0 ga teng bo'lishi mumkin.
    /// Shunga qaramay, bu hozirda xom ko'rsatgich sifatida ko'rsatilgan bitta zaif ma'lumotnomaga egalik qiladi (kuchsiz son ushbu operatsiya bilan o'zgartirilmaydi) va shuning uchun uni [`into_raw`] oldingi chaqiruvi bilan bog'lash kerak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Oxirgi zaif sonni kamaytiring.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Kirish ko'rsatkichining qanday olinishi haqida kontekstni Weak::as_ptr-ga qarang.

        let ptr = if is_dangling(ptr as *mut T) {
            // Bu osilgan zaif.
            ptr as *mut ArcInner<T>
        } else {
            // Aks holda, biz ko'rsatgichni so'zma-so'z zaif tomonlardan kelib chiqqaniga kafolat beramiz.
            // XAVFSIZLIK: data_offset qo'ng'iroq qilish xavfsizdir, chunki ptr haqiqiy (potentsial tushib ketgan) T ga ishora qiladi.
            let offset = unsafe { data_offset(ptr) };
            // Shunday qilib, biz butun RcBoxni olish uchun ofsetni teskari yo'naltiramiz.
            // XAVFSIZLIK: ko'rsatkich zaif tomonlardan kelib chiqqan, shuning uchun bu ofset xavfsizdir.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // XAVFSIZLIK: biz asl zaif ko'rsatgichni tikladik, shuning uchun zaiflarni yaratamiz.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` ko'rsatkichini [`Arc`] darajasiga ko'tarishga urinishlar, agar muvaffaqiyatli bo'lsa, ichki qiymatni tushirish kechiktiriladi.
    ///
    ///
    /// Ichki qiymat o'chirilgan bo'lsa, [`None`]-ni qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Barcha kuchli ko'rsatkichlarni yo'q qiling.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Biz fetch_add o'rniga kuchli sonni oshirish uchun CAS tsiklidan foydalanamiz, chunki bu funktsiya hech qachon mos yozuvlar sonini noldan biriga o'tkazmasligi kerak.
        //
        //
        let inner = self.inner()?;

        // Ruxsat etilgan yuk, chunki biz kuzatadigan har qanday 0 yozuvi maydonni doimiy nol holatida qoldiradi (shuning uchun 0 ning "stale" ko'rsatkichi yaxshi) va boshqa har qanday qiymat quyidagi CAS orqali tasdiqlanadi.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Buni nima uchun qilishimiz uchun `Arc::clone`-dagi izohlarni ko'ring (`mem::forget` uchun).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed muvaffaqiyatsizlikka uchraganligi uchun juda yaxshi, chunki biz yangi holat haqida hech qanday umidvor emasmiz.
            // Ichki qiymatni `Weak` ma'lumotnomalari yaratilgandan so'ng ishga tushirish mumkin bo'lganida, muvaffaqiyatli ish `Arc::new_cyclic` bilan sinxronlash uchun kerak bo'ladi.
            // Bunday holda, biz to'liq boshlang'ich qiymatini kuzatishni kutmoqdamiz.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null yuqorida tekshirilgan
                Err(old) => n = old,
            }
        }
    }

    /// Ushbu ajratishga ishora qiluvchi kuchli (`Arc`) ko'rsatkichlari sonini oladi.
    ///
    /// Agar `self` [`Weak::new`] yordamida yaratilgan bo'lsa, bu 0 ga qaytadi.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Ushbu ajratishga ishora qiluvchi `Weak` ko'rsatkichlari sonining taxminiy qiymatini oladi.
    ///
    /// Agar `self` [`Weak::new`] yordamida yaratilgan bo'lsa yoki qolgan kuchli ko'rsatkichlar bo'lmasa, bu 0 ga qaytadi.
    ///
    /// # Accuracy
    ///
    /// Amalga oshirish tafsilotlari tufayli, boshqa satrlar har qanday "Arc`s"yoki"Weak`s" bir xil taqsimotga ishora qilganda, qaytarilgan qiymat har ikki yo'nalishda ham o'chirilishi mumkin.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Zaif sonni o'qiganimizdan so'ng, kamida bitta kuchli ko'rsatkich mavjudligini kuzatganimiz sababli, biz zaif sonni kuzatganimizda yashirin zaif ma'lumot (har qanday kuchli ma'lumot mavjud bo'lsa) mavjud bo'lganligini bilamiz va shuning uchun uni xavfsiz olib tashlashimiz mumkin.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Ko'rsatkich osilib turganda va ajratilgan `ArcInner` bo'lmaganida (ya'ni, bu `Weak` `Weak::new` tomonidan yaratilganida) `None` ni qaytaradi.
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Biz "data" maydonini o'z ichiga olgan ma'lumotnomani yaratmasligimizdan ehtiyot bo'lamiz *, chunki maydon bir vaqtning o'zida mutatsiyaga uchragan bo'lishi mumkin (masalan, oxirgi `Arc` tushirilsa, ma'lumotlar maydoni o'z joyiga tushib ketadi).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Ikkala Zaiflar bir xil ajratishga ishora qilsalar ([`ptr::eq`] ga o'xshash) yoki ikkalasi ham biron bir ajratishga ishora qilmasa (chunki ular `Weak::new()`) bilan yaratilgan), `true` ni qaytaradi.
    ///
    ///
    /// # Notes
    ///
    /// Bu ko'rsatkichlarni taqqoslaganligi sababli, bu `Weak::new()` har qanday ajratishga ishora qilmasa ham, bir-biriga teng bo'lishini anglatadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new`-ni taqqoslash.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Xuddi shu ajratishga ishora qiluvchi `Weak` ko'rsatkichining klonini yaratadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Nima uchun bu bo'shashganligi haqida Arc::clone()-dagi izohlarni ko'ring.
        // Buning uchun fetch_add ishlatilishi mumkin (qulfni e'tiborsiz qoldirish), chunki zaif son faqatgina mavjud bo'lgan *boshqa* zaif ko'rsatkichlar mavjud bo'lgan joyda qulflanadi.
        //
        // (Demak, bu holda biz ushbu kodni ishlata olmaymiz).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Buni nima uchun qilishimiz uchun Arc::clone()-dagi izohlarni ko'ring (mem::forget uchun).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Xotirani ajratmasdan yangi `Weak<T>` ni yaratadi.
    /// Qaytish qiymati bo'yicha [`upgrade`]-ga qo'ng'iroq qilish har doim [`None`]-ni beradi.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` ko'rsatkichini tashlaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Hech narsa chop etmaydi
    /// drop(foo);        // "dropped!"-ni bosib chiqaradi
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Agar biz so'nggi zaif ko'rsatgich ekanligimizni bilib olsak, unda ma'lumotlarni butunlay taqsimlash vaqti keldi.Arc::drop()-da xotira buyurtmalari haqida munozarani ko'ring
        //
        // Bu erda qulflangan holatni tekshirishning hojati yo'q, chunki zaif sonni faqat bitta zaif ref mavjud bo'lganda qulflash mumkin, ya'ni tomchi keyinchalik faqatgina ushbu qolgan zaif refni yoqishi mumkin, bu faqat qulf qo'yilgandan keyin sodir bo'lishi mumkin.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Biz bu erda ixtisoslashuvni `&T`-da umumiy optimallashtirish sifatida emas, balki amalga oshirmoqdamiz, chunki bu aks holda barcha tenglik tekshiruvlariga xarajatlarni qo'shadi.
/// Bizning fikrimizcha, "Arc`s" klonlashda sekin, ammo tenglikni tekshirish uchun og'ir bo'lgan katta qiymatlarni saqlash uchun ishlatiladi, bu xarajatlarni osonroq qoplaydi.
///
/// Ikkita X va X ga o'xshash ikkita `Arc` klonlari bo'lishi mumkin, ular bir xil qiymatga ishora qiladilar.
///
/// Biz buni faqat `T: Eq`, `PartialEq` sifatida ataylab qaytarilmasligi mumkin bo'lganda qila olamiz.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Ikki Arc uchun tenglik.
    ///
    /// Ikki "Arc" teng, agar ularning ichki qiymatlari teng bo'lsa, hatto ular har xil ajratishda saqlansa ham.
    ///
    /// Agar `T` `Eq` ni ham amalga oshirsa (tenglikning refleksivligini bildiradi), bir xil taqsimotga ishora qiluvchi ikkita "Arc" har doim teng bo'ladi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ikki Arc uchun tengsizlik.
    ///
    /// Ikki "Arc" teng emas, agar ularning ichki qiymatlari teng bo'lmasa.
    ///
    /// Agar `T` `Eq` ni ham amalga oshirsa (tenglikning refleksivligini bildiradi), bir xil qiymatga ishora qiluvchi ikkita "Arc`" hech qachon teng bo'lmaydi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Ikki Arc uchun qisman taqqoslash.
    ///
    /// Ikkalasi ichki qiymatlari bo'yicha `partial_cmp()`-ni chaqirish orqali taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ikki Arc uchun taqqoslashdan kamroq.
    ///
    /// Ikkalasi ichki qiymatlari bo'yicha `<`-ni chaqirish orqali taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Ikki Arc uchun "kamroq yoki teng" taqqoslash.
    ///
    /// Ikkalasi ichki qiymatlari bo'yicha `<=`-ni chaqirish orqali taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Ikki Arc uchun taqqoslashdan kattaroq.
    ///
    /// Ikkalasi ichki qiymatlari bo'yicha `>`-ni chaqirish orqali taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Ikki Arc uchun "kattaroq yoki teng" taqqoslash.
    ///
    /// Ikkalasi ichki qiymatlari bo'yicha `>=`-ni chaqirish orqali taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Ikki Arc uchun taqqoslash.
    ///
    /// Ikkalasi ichki qiymatlari bo'yicha `cmp()`-ni chaqirish orqali taqqoslanadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` uchun `Default` qiymatiga ega bo'lgan yangi `Arc<T>` yaratadi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Ma'lumotlar bo'yicha hisoblangan tilimni ajratib oling va "v" elementlarini klonlash orqali to'ldiring.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// `str` mos yozuvlar sonini ajratib oling va unga `v` nusxasini oling.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// `str` mos yozuvlar sonini ajratib oling va unga `v` nusxasini oling.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Qutidagi ob'ektni mos yozuvlar hisoblangan yangi ajratishga o'tkazing.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Yo'naltiruvchi hisoblangan bo'lakni ajrating va unga "v" elementlarini ko'chiring.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec-ga xotirasini bo'shatishga ruxsat bering, lekin uning tarkibini yo'q qilmang
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator` dagi har bir elementni oladi va `Arc<[T]>` ga yig'adi.
    ///
    /// # Ishlash xususiyatlari
    ///
    /// ## Umumiy ish
    ///
    /// Umumiy holda, `Arc<[T]>`-ga yig'ish birinchi navbatda `Vec<T>`-ga yig'ish orqali amalga oshiriladi.Ya'ni, quyidagilarni yozishda:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// bu biz yozgandek o'zini tutadi:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Birinchi ajratmalar to'plami bu erda sodir bo'ladi.
    ///     .into(); // `Arc<[T]>` uchun ikkinchi ajratish bu erda sodir bo'ladi.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Bu `Vec<T>` ni qurish uchun qancha kerak bo'lsa, shuncha marta ajratadi va `Vec<T>` ni `Arc<[T]>` ga aylantirish uchun bir marta ajratadi.
    ///
    ///
    /// ## Uzunligi ma'lum bo'lgan takrorlovchilar
    ///
    /// Sizning `Iterator` `TrustedLen`-ni amalga oshirganda va aniq o'lchamda bo'lsa, `Arc<[T]>` uchun bitta ajratish amalga oshiriladi.Masalan:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Bu erda faqat bitta ajratish sodir bo'ladi.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>`-ga yig'ish uchun ishlatiladigan trait ixtisosligi.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Bu `TrustedLen` iteratoriga tegishli.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // XAVFSIZLIK: Biz iteratorning aniq uzunligiga va bizda bo'lishiga ishonch hosil qilishimiz kerak.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Oddiy dasturga qaytish.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Ko'rsatkich orqasidagi foydali yuk uchun `ArcInner` ichida ofsetni oling.
///
/// # Safety
///
/// Ko'rsatkich ilgari amal qilgan T misoliga ishora qilishi kerak (va ular uchun tegishli metadatlarga ega bo'lishi kerak), ammo T ning tushirilishiga yo'l qo'yiladi.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Tasdiqlanmagan qiymatni ArcInner oxiriga tekislang.
    // RcBox repr(C) bo'lgani uchun u doimo xotiradagi so'nggi maydon bo'lib qoladi.
    // XAVFSIZLIK: mumkin bo'lmagan o'lchamlarga ega bo'lgan yagona tilim, trait moslamalari,
    // va tashqi turlar, kirish xavfsizligi talabi hozirda align_of_val_raw talablarini qondirish uchun etarli;bu std tashqarisida ishonib bo'lmaydigan tilni amalga oshirish tafsiloti.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}