//! Xotirani ajratish API-lari

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Bu global ajratuvchini chaqirish uchun sehrli belgilar.rustc ularni `__rg_alloc` va hokazolarni chaqirish uchun ishlab chiqaradi.
    // agar `#[global_allocator]` atributi bo'lsa (ushbu atributni kengaytiradigan kod ushbu funktsiyalarni yaratadi) yoki libstd (`__rdl_alloc` va boshqalar) da standart dasturlarni chaqirish uchun.
    //
    // aks holda.
    // LLVM ning rustc fork-da, ushbu funktsiya nomlari ularni mos ravishda `malloc`, `realloc` va `free` kabi optimallashtirish uchun maxsus holatlar mavjud.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Umumjahon xotira ajratuvchisi.
///
/// Ushbu turdagi [`Allocator`] trait mavjud bo'lsa, `#[global_allocator]` atributida ro'yxatdan o'tgan ajratuvchiga qo'ng'iroqlarni yo'naltirish yoki `std` crate sukut bo'yicha amalga oshiriladi.
///
///
/// Note: ushbu tur beqaror bo'lsa-da, u taqdim etadigan funksionallikka [free functions in `alloc`](self#functions) orqali kirish mumkin.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Xotirani global ajratuvchi bilan ajrating.
///
/// Agar bu funktsiya mavjud bo'lsa yoki `std` crate standart bo'lsa, `#[global_allocator]` atributida ro'yxatdan o'tgan ajratgichning [`GlobalAlloc::alloc`] usuliga qo'ng'iroqlarni yo'naltiradi.
///
///
/// Ushbu funktsiya [`Global`] tipidagi `alloc` usuli foydasiga eskirishi kutilmoqda, u va [`Allocator`] trait barqaror bo'lganda.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`]-ga qarang.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Xotirani global ajratuvchi bilan taqsimlash.
///
/// Agar bu funktsiya mavjud bo'lsa yoki `std` crate standart bo'lsa, `#[global_allocator]` atributida ro'yxatdan o'tgan ajratgichning [`GlobalAlloc::dealloc`] usuliga qo'ng'iroqlarni yo'naltiradi.
///
///
/// Ushbu funktsiya [`Global`] tipidagi `dealloc` usuli foydasiga eskirishi kutilmoqda, u va [`Allocator`] trait barqaror bo'lganda.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`]-ga qarang.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Xotirani global ajratuvchi bilan qayta taqsimlash.
///
/// Agar bu funktsiya mavjud bo'lsa yoki `std` crate standart bo'lsa, `#[global_allocator]` atributida ro'yxatdan o'tgan ajratgichning [`GlobalAlloc::realloc`] usuliga qo'ng'iroqlarni yo'naltiradi.
///
///
/// Ushbu funktsiya [`Global`] tipidagi `realloc` usuli foydasiga eskirishi kutilmoqda, u va [`Allocator`] trait barqaror bo'lganda.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`]-ga qarang.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Global ajratuvchi bilan nol-boshlangan xotirani ajrating.
///
/// Agar bu funktsiya mavjud bo'lsa yoki `std` crate standart bo'lsa, `#[global_allocator]` atributida ro'yxatdan o'tgan ajratgichning [`GlobalAlloc::alloc_zeroed`] usuliga qo'ng'iroqlarni yo'naltiradi.
///
///
/// Ushbu funktsiya [`Global`] tipidagi `alloc_zeroed` usuli foydasiga eskirishi kutilmoqda, u va [`Allocator`] trait barqaror bo'lganda.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`]-ga qarang.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // XAVFSIZLIK: `layout` nolga teng emas,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // XAVFSIZLIK: `Allocator::grow` bilan bir xil
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // XAVFSIZLIK: `new_size` nolga teng emas, chunki `old_size` `new_size` dan katta yoki unga teng
            // xavfsizlik shartlari talab qilganda.Qo'ng'iroq qiluvchi tomonidan boshqa shartlar bajarilishi kerak
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` ehtimol `new_size >= old_layout.size()` yoki shunga o'xshash narsalarni tekshiradi.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // XAVFSIZLIK: chunki `new_layout.size()` `old_size` dan katta yoki unga teng bo'lishi kerak,
            // eski va yangi xotira ajratish `old_size` bayt uchun o'qish va yozish uchun amal qiladi.
            // Bundan tashqari, eski ajratish hali taqsimlanmaganligi sababli, u `new_ptr` bilan qoplanishi mumkin emas.
            // Shunday qilib, `copy_nonoverlapping`-ga qo'ng'iroq xavfsizdir.
            // `dealloc` uchun xavfsizlik shartnomasini chaqiruvchi qo'llab-quvvatlashi kerak.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // XAVFSIZLIK: `layout` nolga teng emas,
            // boshqa shartlar qo'ng'iroq qiluvchi tomonidan bajarilishi kerak
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi tomonidan barcha shartlar bajarilishi kerak
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // XAVFSIZLIK: qo'ng'iroq qiluvchi tomonidan barcha shartlar bajarilishi kerak
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // XAVFSIZLIK: qo'ng'iroq qiluvchi tomonidan shartlar bajarilishi kerak
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // XAVFSIZLIK: `new_size` nolga teng emas.Qo'ng'iroq qiluvchi tomonidan boshqa shartlar bajarilishi kerak
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` ehtimol `new_size <= old_layout.size()` yoki shunga o'xshash narsalarni tekshiradi.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // XAVFSIZLIK: chunki `new_size` `old_layout.size()` dan kichik yoki unga teng bo'lishi kerak,
            // eski va yangi xotira ajratish `new_size` bayt uchun o'qish va yozish uchun amal qiladi.
            // Bundan tashqari, eski ajratish hali taqsimlanmaganligi sababli, u `new_ptr` bilan qoplanishi mumkin emas.
            // Shunday qilib, `copy_nonoverlapping`-ga qo'ng'iroq xavfsizdir.
            // `dealloc` uchun xavfsizlik shartnomasini chaqiruvchi qo'llab-quvvatlashi kerak.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Noyob ko'rsatkichlar uchun ajratuvchi.
// Ushbu funktsiya bo'shashmasligi kerak.Agar shunday bo'lsa, MIR codegen ishlamay qoladi.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Ushbu imzo `Box` bilan bir xil bo'lishi kerak, aks holda ICE bo'ladi.
// `Box` ga qo'shimcha parametr qo'shilganda (masalan, `A: Allocator`), bu erda ham qo'shilishi kerak.
// Masalan, `Box` `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` ga o'zgartirilsa, bu funktsiyani `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` ga o'zgartirish kerak.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Ajratish bilan bog'liq xatolarni ko'rib chiquvchi

extern "Rust" {
    // Bu global ajratish xatolarini ishlov beruvchisini chaqirish uchun sehrli belgidir.
    // rustc, agar `#[alloc_error_handler]` bo'lsa, `__rg_oom` ga qo'ng'iroq qilish yoki aks holda (`__rdl_oom`) ostidagi standart dasturlarni chaqirish uchun uni yaratadi.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Xotirani ajratishda xato yoki xato yuz berganda bekor qiling.
///
/// Xotirani ajratish API-lari qo'ng'iroq qiluvchilarni ajratish xatosiga javoban hisoblashni bekor qilishni istaganlar, to'g'ridan-to'g'ri `panic!` yoki shunga o'xshashlarni chaqirish o'rniga ushbu funktsiyani chaqirishlari tavsiya etiladi.
///
///
/// Ushbu funktsiyaning odatiy xatti-harakatlari standart xatolarga xabarni chop etish va jarayonni to'xtatishdir.
/// Uni [`set_alloc_error_hook`] va [`take_alloc_error_hook`] bilan almashtirish mumkin.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Ajratish uchun `std::alloc::handle_alloc_error` to'g'ridan-to'g'ri ishlatilishi mumkin.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // ishlab chiqarilgan `__rust_alloc_error_handler` orqali chaqiriladi

    // agar `#[alloc_error_handler]` bo'lmasa
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // agar `#[alloc_error_handler]` bo'lsa
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Klonlarni oldindan ajratilgan, boshlanmagan xotiraga ixtisoslashtiring.
/// `Box::clone` va `Rc`/`Arc::make_mut` tomonidan ishlatiladi.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *Birinchi* ajratish optimizatorga klonlangan qiymatni o'rnida yaratishga, lokalni o'tkazib yuborishga va harakat qilishga imkon berishi mumkin.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Biz har doim mahalliy qiymatni jalb qilmasdan, o'z o'rnimizdan nusxa olishimiz mumkin.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}