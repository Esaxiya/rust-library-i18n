//! Ajratish Prelude
//!
//! Ushbu modulning maqsadi globus importini modullarning yuqori qismiga qo'shish orqali `alloc` crate-ning tez-tez ishlatiladigan buyumlari importini engillashtirishdir:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;