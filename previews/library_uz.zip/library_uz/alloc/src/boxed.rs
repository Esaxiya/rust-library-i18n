//! To'pni ajratish uchun ko'rsatgich turi.
//!
//! [`Box<T>`], tasodifan 'box' deb ataladi, Rust-da uyumlarni ajratishning eng oddiy shaklini beradi.Qutilar ushbu ajratish uchun egalik huquqini beradi va ular doirasidan tashqariga chiqqandan keyin ularning tarkibini tashlaydi.Qutilari, ular hech qachon `isize::MAX` baytdan ko'proq ajratmasligini ta'minlaydi.
//!
//! # Examples
//!
//! [`Box`] yaratish orqali qadoqni yig'indiga ko'chiring:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! [`Box`]-dan qiymatni [dereferencing]-ga stakka qaytaring:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Ma'lumotlarning rekursiv tuzilishini yaratish:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Bu "Cons (1, Cons(2, Nil))`.
//!
//! Rekursiv tuzilmalar qutiga solinishi kerak, chunki agar `Cons` ta'rifi shunday ko'rinishga ega bo'lsa:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Bu ishlamaydi.Buning sababi shundaki, `List` hajmi ro'yxatdagi qancha elementga bog'liq va shuning uchun biz `Cons` uchun qancha xotira ajratishni bilmaymiz.Belgilangan o'lchamga ega bo'lgan [`Box<T>`] ni taqdim etish orqali biz `Cons` qanchalik katta bo'lishi kerakligini bilamiz.
//!
//! # Xotira tartibi
//!
//! Nolga teng bo'lmagan qiymatlar uchun [`Box`] [`Global`] ajratuvchisini ajratish uchun ishlatadi.[`Box`] va [`Global`] taqsimlovchisi bilan ajratilgan xom ko'rsatgich o'rtasida har ikkala usulni almashtirish to'g'ri bo'ladi, chunki ajratuvchi bilan ishlatilgan [`Layout`] turga to'g'ri keladi.
//!
//! Aniqrog'i, `Layout::for_value(&*value)` bilan [`Global`] ajratuvchisi bilan ajratilgan `value:* mut T`, [`Box::<T>::from_raw(value)`] yordamida qutiga aylantirilishi mumkin.
//! Aksincha, [`Box::<T>::into_raw`]-dan olingan `value:*mut T`-ni qo'llab-quvvatlaydigan xotira [`Layout::for_value(&* value)`] bilan [`Global`] ajratuvchisi yordamida taqsimlanishi mumkin.
//!
//! Nol o'lchovli qiymatlar uchun `Box` ko'rsatkichi o'qish va yozish uchun hali ham [valid] bo'lishi va etarlicha hizalanishi kerak.
//! Xususan, har qanday hizalanmış nolga teng bo'lmagan butun sonni xom ko'rsatgichga tashlash haqiqiy ko'rsatgich hosil qiladi, ammo bo'shatilganidan beri ajratilgan xotiraga ishora qiluvchi kuch haqiqiy emas.
//! Agar `Box::new` ishlatib bo'lmaydigan bo'lsa, ZST-ga qutichani qurishning tavsiya etilgan usuli [`ptr::NonNull::dangling`]-dan foydalanishdir.
//!
//! `T: Sized` ekan, `Box<T>` bitta ko'rsatgich sifatida namoyish etilishi kafolatlanadi va u ABI-ga mos keladi (ya'ni C turi `T*`).
//! Agar sizda C dan chaqiriladigan extern "C" Rust funktsiyalari bo'lsa, siz `Box<T>` turlaridan foydalangan holda Rust funktsiyalarini belgilashingiz va X tomonida tegishli tur sifatida `T*` dan foydalanishingiz mumkin degan ma'noni anglatadi.
//! Masalan, ba'zi bir `Foo` qiymatlarini yaratadigan va yo'q qiladigan funktsiyalarni e'lon qiladigan ushbu C sarlavhasini ko'rib chiqing:
//!
//! ```c
//! /* C sarlavhasi */
//!
//! /* Qo'ng'iroq qiluvchiga egalik huquqini qaytaradi */
//! struct Foo* foo_new(void);
//!
//! /* Qo'ng'iroq qiluvchidan mulk huquqini oladi;NULL bilan chaqirilganda no-op */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Ushbu ikkita funktsiya Rust-da quyidagi tarzda amalga oshirilishi mumkin.Bu erda C dan `struct Foo*` turi egalik cheklovlarini ushlab turadigan `Box<Foo>` ga tarjima qilingan.
//! `foo_delete` uchun bekor qilinadigan argument Rust da `Option<Box<Foo>>` sifatida ifodalanganligini ham unutmang, chunki `Box<Foo>` nolga teng bo'lmaydi.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Garchi `Box<T>` C ko'rsatkichi bilan bir xil vakolatxonaga va C ABIga ega bo'lsa ham, bu siz o'zboshimchalik bilan `T*` ni `Box<T>` ga o'zgartirishingiz va ishlarning ishlashini kutishingiz mumkin degani emas.
//! `Box<T>` qiymatlar har doim to'liq moslashtirilgan, nolga teng bo'lmagan ko'rsatkichlar.Bundan tashqari, `Box<T>` uchun destruktor global ajratuvchi bilan qiymatni bo'shatishga harakat qiladi.Umuman olganda, eng yaxshi amaliyot shundan iboratki, global ajratuvchidan kelib chiqqan ko'rsatkichlar uchun faqat `Box<T>` ishlatiladi.
//!
//! **Muhim.** Hech bo'lmaganda hozirgi vaqtda siz C-da aniqlangan, ammo Rust-dan chaqirilgan funktsiyalar uchun `Box<T>` turlarini ishlatishdan qochishingiz kerak.Bunday hollarda siz to'g'ridan-to'g'ri C turlarini iloji boricha yaqinroq aks ettirishingiz kerak.
//! C ta'rifi `T*` dan foydalanadigan `Box<T>` kabi turlardan foydalanish, [rust-lang/unsafe-code-guidelines#198][ucg#198] da tasvirlanganidek, noaniq xatti-harakatlarga olib kelishi mumkin.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// To'pni ajratish uchun ko'rsatgich turi.
///
/// Qo'shimcha ma'lumot uchun [module-level documentation](../../std/boxed/index.html)-ga qarang.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Uyumdagi xotirani ajratadi va keyin unga `x` joylashtiradi.
    ///
    /// Agar `T` nolga teng bo'lsa, bu aslida ajratilmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Boshlanmagan tarkibga ega yangi quti quradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// `0` bayt bilan to'ldirilgan, boshlanmagan tarkibga ega yangi `Box` ni yaratadi.
    ///
    ///
    /// Ushbu usuldan to'g'ri va noto'g'ri foydalanish misollari uchun [`MaybeUninit::zeroed`][zeroed]-ga qarang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Yangi `Pin<Box<T>>` quradi.
    /// Agar `T` `Unpin`-ni amalga oshirmasa, u holda `x` xotirada saqlanadi va uni ko'chirish mumkin emas.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Uydagi xotirani ajratadi, so'ngra `x`-ni joylashtiradi, agar ajratish amalga oshmasa, xato bo'ladi
    ///
    ///
    /// Agar `T` nolga teng bo'lsa, bu aslida ajratilmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Uyingizda boshlanmagan tarkibga ega bo'lgan yangi qutini quradi, agar ajratish amalga oshmasa, xatoni qaytaradi
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Boshlanmagan tarkibga ega bo'lgan yangi `Box`-ni quradi, xotirasi yig'indisida `0` bayt bilan to'ldiriladi
    ///
    ///
    /// Ushbu usuldan to'g'ri va noto'g'ri foydalanish misollari uchun [`MaybeUninit::zeroed`][zeroed]-ga qarang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Berilgan ajratuvchida xotirani ajratadi, so'ngra unga `x` joylashtiradi.
    ///
    /// Agar `T` nolga teng bo'lsa, bu aslida ajratilmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Berilgan ajratuvchida xotirani ajratadi, so'ngra `x`-ni joylashtiradi, agar ajratish amalga oshmasa xatoga yo'l qo'yadi
    ///
    ///
    /// Agar `T` nolga teng bo'lsa, bu aslida ajratilmaydi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Taqdim etilgan ajratgichda boshlanmagan tarkibga ega bo'lgan yangi qutini quradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: O'yinni unwrap_or_else-dan afzal qiling, chunki yopilish ba'zan inline bo'lmaydi.
        // Bu kod hajmini kattalashtiradi.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Taqdim etilgan ajratgichda boshlanmagan tarkibga ega bo'lgan yangi qutini quradi, agar ajratish amalga oshmasa, xatoni qaytaradi
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Taqdim etilgan ajratuvchida xotira `0` bayt bilan to'ldirilgan holda, boshlanmagan tarkibga ega yangi `Box` ni yaratadi.
    ///
    ///
    /// Ushbu usuldan to'g'ri va noto'g'ri foydalanish misollari uchun [`MaybeUninit::zeroed`][zeroed]-ga qarang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: O'yinni unwrap_or_else-dan afzal qiling, chunki yopilish ba'zan inline bo'lmaydi.
        // Bu kod hajmini kattalashtiradi.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Yangi `Box`-ni boshlanmagan tarkib bilan quradi, shu bilan ajratilgan ajratuvchida xotira `0` bayt bilan to'ldiriladi va agar ajratish amalga oshmasa xatolikni qaytaradi,
    ///
    ///
    /// Ushbu usuldan to'g'ri va noto'g'ri foydalanish misollari uchun [`MaybeUninit::zeroed`][zeroed]-ga qarang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Yangi `Pin<Box<T, A>>` quradi.
    /// Agar `T` `Unpin`-ni amalga oshirmasa, u holda `x` xotirada saqlanadi va uni ko'chirish mumkin emas.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>` ni `Box<[T]>` ga o'zgartiradi
    ///
    /// Ushbu konvertatsiya yig'indiga ajratilmaydi va o'z joyida sodir bo'ladi.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// O'ralgan qiymatni qaytarib, `Box` iste'mol qiladi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Boshlanmagan tarkibga ega bo'lgan yangi quti tilimini quradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Xotira `0` bayt bilan to'ldirilgan, boshlanmagan tarkibga ega bo'lgan yangi quti bo'lakni quradi.
    ///
    ///
    /// Ushbu usuldan to'g'ri va noto'g'ri foydalanish misollari uchun [`MaybeUninit::zeroed`][zeroed]-ga qarang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Taqdim etilgan ajratgichda boshlanmagan tarkibga ega bo'lgan yangi quti tilimini quradi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Xotira `0` bayt bilan to'ldirilgan holda, taqdim etilgan ajratgichda boshlanmagan tarkibga ega bo'lgan yangi quti bo'lakni quradi.
    ///
    ///
    /// Ushbu usuldan to'g'ri va noto'g'ri foydalanish misollari uchun [`MaybeUninit::zeroed`][zeroed]-ga qarang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// `Box<T, A>` ga o'zgartiradi.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-da bo'lgani kabi, bu raqam haqiqatan ham boshlang'ich holatida bo'lishiga kafolat beruvchiga bog'liq.
    ///
    /// Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish darhol aniqlanmagan xatti-harakatlarni keltirib chiqaradi.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// `Box<[T], A>` ga o'zgartiradi.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`]-da bo'lgani kabi, raqamlar haqiqatan ham boshlang'ich holatida bo'lishiga kafolat beruvchiga bog'liq.
    ///
    /// Tarkib hali to'liq ishga tushirilmagan bo'lsa, buni chaqirish darhol aniqlanmagan xatti-harakatlarni keltirib chiqaradi.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kechiktirilgan ishga tushirish:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Xom ko'rsatgichdan quti quradi.
    ///
    /// Ushbu funktsiyani chaqirgandan so'ng, xom ko'rsatgich hosil bo'lgan `Box`-ga tegishli.
    /// Xususan, `Box` destruktori `T` destruktorini chaqiradi va ajratilgan xotirani bo'shatadi.
    /// Xavfsiz bo'lishi uchun `Box` tomonidan ishlatiladigan [memory layout] ga muvofiq xotira ajratilgan bo'lishi kerak.
    ///
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya xavfli emas, chunki noto'g'ri ishlatish xotirada muammolarga olib kelishi mumkin.
    /// Masalan, funktsiya bir xil xom ko'rsatgichda ikki marta chaqirilsa, er-xotin paydo bo'lishi mumkin.
    ///
    /// [memory layout] qismida xavfsizlik shartlari tasvirlangan.
    ///
    /// # Examples
    ///
    /// Oldindan [`Box::into_raw`] yordamida xom ko'rsatgichga aylantirilgan `Box`-ni yarating:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Global ajratuvchidan foydalanib, `Box`-ni noldan qo'lda yarating:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Umuman olganda .write `ptr` ning oldingi tarkibidagi (uninitialized) ni yo'q qilishga urinishdan qochish uchun talab qilinadi, ammo bu oddiy misol uchun `*ptr = 5` ham ishlagan bo'lar edi.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Berilgan ajratgichda xom ko'rsatkichdan quti quradi.
    ///
    /// Ushbu funktsiyani chaqirgandan so'ng, xom ko'rsatgich hosil bo'lgan `Box`-ga tegishli.
    /// Xususan, `Box` destruktori `T` destruktorini chaqiradi va ajratilgan xotirani bo'shatadi.
    /// Xavfsiz bo'lishi uchun `Box` tomonidan ishlatiladigan [memory layout] ga muvofiq xotira ajratilgan bo'lishi kerak.
    ///
    ///
    /// # Safety
    ///
    /// Ushbu funktsiya xavfli emas, chunki noto'g'ri ishlatish xotirada muammolarga olib kelishi mumkin.
    /// Masalan, funktsiya bir xil xom ko'rsatgichda ikki marta chaqirilsa, er-xotin paydo bo'lishi mumkin.
    ///
    /// # Examples
    ///
    /// Oldindan [`Box::into_raw_with_allocator`] yordamida xom ko'rsatgichga aylantirilgan `Box`-ni yarating:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Tizim ajratuvchisi yordamida noldan `Box`-ni qo'lda yarating:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Umuman olganda .write `ptr` ning oldingi tarkibidagi (uninitialized) ni yo'q qilishga urinishdan qochish uchun talab qilinadi, ammo bu oddiy misol uchun `*ptr = 5` ham ishlagan bo'lar edi.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// `Box` ni sarflaydi, o'ralgan xom ko'rsatkichni qaytaradi.
    ///
    /// Ko'rsatkich to'g'ri hizalanadi va nolga teng bo'lmaydi.
    ///
    /// Ushbu funktsiyani chaqirgandan so'ng, qo'ng'iroq qiluvchi avval `Box` tomonidan boshqariladigan xotira uchun javobgardir.
    /// Xususan, qo'ng'iroq qiluvchi `T`-ni to'g'ri ravishda yo'q qilishi va `Box` tomonidan ishlatiladigan [memory layout] ni hisobga olgan holda xotirani bo'shatishi kerak.
    /// Buning eng oson usuli-bu `Box` destruktoriga tozalashni amalga oshirishga imkon beradigan [`Box::from_raw`] funktsiyasi bilan xom ko'rsatgichni `Box` ga qaytarishdir.
    ///
    ///
    /// Note: bu bog'liq funktsiya, demak siz uni `b.into_raw()` o'rniga `Box::into_raw(b)` deb chaqirishingiz kerak.
    /// Bu ichki tipdagi usul bilan ziddiyat bo'lmasligi uchun.
    ///
    /// # Examples
    /// Avtomatik tozalash uchun xom ko'rsatkichni `Box`-ga [`Box::from_raw`]-ga qaytarish:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Destruktorni aniq ishga tushirish va xotirani ajratish orqali qo'lda tozalash:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// `Box` ni iste'mol qiladi, o'ralgan xom ko'rsatkichni va ajratuvchini qaytaradi.
    ///
    /// Ko'rsatkich to'g'ri hizalanadi va nolga teng bo'lmaydi.
    ///
    /// Ushbu funktsiyani chaqirgandan so'ng, qo'ng'iroq qiluvchi avval `Box` tomonidan boshqariladigan xotira uchun javobgardir.
    /// Xususan, qo'ng'iroq qiluvchi `T`-ni to'g'ri ravishda yo'q qilishi va `Box` tomonidan ishlatiladigan [memory layout] ni hisobga olgan holda xotirani bo'shatishi kerak.
    /// Buning eng oson usuli-bu `Box` destruktoriga tozalashni amalga oshirishga imkon beradigan [`Box::from_raw_in`] funktsiyasi bilan xom ko'rsatgichni `Box` ga qaytarishdir.
    ///
    ///
    /// Note: bu bog'liq funktsiya, demak siz uni `b.into_raw_with_allocator()` o'rniga `Box::into_raw_with_allocator(b)` deb chaqirishingiz kerak.
    /// Bu ichki tipdagi usul bilan ziddiyat bo'lmasligi uchun.
    ///
    /// # Examples
    /// Avtomatik tozalash uchun xom ko'rsatkichni `Box`-ga [`Box::from_raw_in`]-ga qaytarish:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Destruktorni aniq ishga tushirish va xotirani ajratish orqali qo'lda tozalash:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Box Stacked Borrows tomonidan "unique pointer" sifatida tan olingan, ammo ichki qism bu tip tizim uchun xom ko'rsatkichdir.
        // Uni to'g'ridan-to'g'ri xom ko'rsatgichga aylantirish, "releasing" taxallusli xom kirishga ruxsat beruvchi noyob ko'rsatgich deb tan olinmaydi, shuning uchun barcha xom ko'rsatgich usullari `Box::leak` orqali o'tishi kerak.
        //
        // *That* ni xom ko'rsatkichga aylantirish to'g'ri ishlaydi.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Asosiy ajratuvchiga havolani qaytaradi.
    ///
    /// Note: bu bog'liq funktsiya, demak siz uni `b.allocator()` o'rniga `Box::allocator(&b)` deb chaqirishingiz kerak.
    /// Bu ichki tipdagi usul bilan ziddiyat bo'lmasligi uchun.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// O'zgarishi mumkin bo'lgan ma'lumotnomani qaytarib, `Box` ni iste'mol qiladi va oqadi. `&'a mut T`.
    /// Shuni esda tutingki, `T` turi tanlangan umr ko'rish muddati `'a` dan oshishi kerak.
    /// Agar turda faqat statik ma'lumot mavjud bo'lsa yoki umuman yo'q bo'lsa, u holda `'static` sifatida tanlanishi mumkin.
    ///
    /// Ushbu funktsiya asosan dastur umrining qolgan qismida ishlaydigan ma'lumotlar uchun foydalidir.
    /// Qaytgan ma'lumotnomani tashlash xotira sızıntısına olib keladi.
    /// Agar bu qabul qilinmasa, ma'lumotni avval `Box` ishlab chiqaradigan [`Box::from_raw`] funktsiyasi bilan o'rash kerak.
    ///
    /// Keyinchalik, bu `Box` tushishi mumkin, bu `T` ni to'g'ri yo'q qiladi va ajratilgan xotirani bo'shatadi.
    ///
    /// Note: bu bog'liq funktsiya, demak siz uni `b.leak()` o'rniga `Box::leak(b)` deb chaqirishingiz kerak.
    /// Bu ichki tipdagi usul bilan ziddiyat bo'lmasligi uchun.
    ///
    /// # Examples
    ///
    /// Oddiy foydalanish:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Hajmi bo'lmagan ma'lumotlar:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>` ni `Pin<Box<T>>` ga o'zgartiradi
    ///
    /// Ushbu konvertatsiya yig'indiga ajratilmaydi va o'z joyida sodir bo'ladi.
    ///
    /// Bu [`From`] orqali ham mavjud.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // `T: !Unpin` paytida `Pin<Box<T>>` ichki qismini ko'chirish yoki almashtirish mumkin emas, shuning uchun uni qo'shimcha talablarsiz to'g'ridan-to'g'ri mahkamlash xavfsizdir.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Hech narsa qilmang, tushirish hozirda kompilyator tomonidan amalga oshiriladi.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// T uchun `Default` qiymatiga ega bo'lgan `Box<T>` hosil qiladi.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Ushbu qutidagi `clone()` tarkibidagi yangi qutini qaytaradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Qiymat bir xil
    /// assert_eq!(x, y);
    ///
    /// // Ammo ular noyob narsalardir
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Klonlangan qiymatni to'g'ridan-to'g'ri yozish uchun xotirani oldindan ajratib oling.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// "Manba" ning tarkibini yangi ajratma yaratmasdan `self` ga ko'chiradi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Qiymat bir xil
    /// assert_eq!(x, y);
    ///
    /// // Va hech qanday ajratish sodir bo'lmadi
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // bu ma'lumotlarning nusxasini yaratadi
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Umumiy `T` turini `Box<T>` ga o'zgartiradi
    ///
    /// Konvertatsiya yig'indiga ajratiladi va `t` ni stekdan unga o'tkazadi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>` ni `Pin<Box<T>>` ga o'zgartiradi
    ///
    /// Ushbu konvertatsiya yig'indiga ajratilmaydi va o'z joyida sodir bo'ladi.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]` ni `Box<[T]>` ga o'zgartiradi
    ///
    /// Ushbu konvertatsiya yig'indiga ajratiladi va `slice` nusxasini bajaradi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // &[u8] yarating, u <[u8]> qutisini yaratishda ishlatiladi
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str` ni `Box<str>` ga o'zgartiradi
    ///
    /// Ushbu konvertatsiya yig'indiga ajratiladi va `s` nusxasini bajaradi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>` ni `Box<[u8]>` ga o'zgartiradi
    /// Ushbu konvertatsiya yig'indiga ajratilmaydi va o'z joyida sodir bo'ladi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // quti yarating<str>undan Box [[u8]> yaratish uchun foydalaniladi
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // &[u8] yarating, u <[u8]> qutisini yaratishda ishlatiladi
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]` ni `Box<[T]>` ga o'zgartiradi
    /// Ushbu konversiya massivni yangi yig'ilgan xotiraga ko'chiradi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Qutini beton turiga tushirishga urinish.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Qutini beton turiga tushirishga urinish.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Qutini beton turiga tushirishga urinish.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ichki Uniqni to'g'ridan-to'g'ri Box-dan chiqarib olishning iloji yo'q, aksincha biz uni Uni-ni taxallus qiladigan * constga tashlaymiz
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Sukut bo'yicha emas, balki `last()`-ning bajarilishini ishlatadigan o'lchamdagi "I" lar uchun ixtisoslashuv.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}