//! # Rust yadrosi va to'plamlari kutubxonasi
//!
//! Ushbu kutubxona yig'ilgan qiymatlarni boshqarish uchun aqlli ko'rsatgichlar va to'plamlarni taqdim etadi.
//!
//! Ushbu kutubxona, libcore kabi, odatda to'g'ridan-to'g'ri foydalanishga hojat yo'q, chunki uning tarkibi [`std` crate](../std/index.html)-da qayta eksport qilinadi.
//! `#![no_std]` atributidan foydalanadigan Crates, odatda `std` ga bog'liq bo'lmaydi, shuning uchun ular bu crate o'rniga foydalanadilar.
//!
//! ## Qutlangan qiymatlar
//!
//! [`Box`] turi aqlli ko'rsatgich turi.[`Box`]-ning faqat bitta egasi bo'lishi mumkin va egasi uyumda yashaydigan tarkibni mutatsiyalashga qaror qilishi mumkin.
//!
//! Ushbu turni `Box` qiymatining kattaligi ko'rsatkich bilan bir xil bo'lganligi sababli samarali iplar orasiga yuborilishi mumkin.
//! Daraxtga o'xshash ma'lumotlar tuzilmalari ko'pincha qutilar bilan quriladi, chunki har bir tugunda ko'pincha bitta ota-ona egasi bo'ladi.
//!
//! ## Yo'naltiruvchi hisoblagichlar
//!
//! [`Rc`] turi-bu ish zarrachalari uchun xavfsiz bo'lmagan havola hisoblangan ko'rsatgich turi.
//! [`Rc`] ko'rsatkichi `T` turini o'rab oladi va faqat `&T`-ga kirish uchun ruxsat beradi, umumiy ma'lumot.
//!
//! Ushbu tur, meros qilib olingan o'zgaruvchanlik (masalan, [`Box`] dan foydalanish) dastur uchun juda cheklovli bo'lganda foydalidir va ko'pincha mutatsiyaga ruxsat berish uchun [`Cell`] yoki [`RefCell`] turlari bilan bog'lanadi.
//!
//!
//! ## Atomik ravishda hisoblangan ko'rsatkichlar
//!
//! [`Arc`] turi-bu [`Rc`] turiga mos keladigan zararli xavfsizlik.Bu [`Rc`]-ning bir xil funktsiyalarini ta'minlaydi, faqat `T` turini birgalikda bo'lishini talab qiladi.
//! Bundan tashqari, [`Arc<T>`][`Arc`] o'zi yuborilishi mumkin, [`Rc<T>`][`Rc`] esa yo'q.
//!
//! Ushbu tur mavjud bo'lgan ma'lumotlarga birgalikda kirishga imkon beradi va ko'pincha birgalikda resurslarning mutatsiyasiga imkon berish uchun mutekslar kabi sinxronizatsiya ibtidoiylari bilan bog'lanadi.
//!
//! ## Collections
//!
//! Ushbu kutubxonada eng keng tarqalgan umumiy ma'lumotlar tuzilmalarining bajarilishi aniqlangan.Ular [standard collections library](../std/collections/index.html) orqali qayta eksport qilinadi.
//!
//! ## Uyma interfeyslar
//!
//! [`alloc`](alloc/index.html) moduli past darajadagi interfeysni standart global ajratuvchiga belgilaydi.Bu libc distributor API bilan mos kelmaydi.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Texnik jihatdan, bu rustdoc-dagi xato: rustdoc `#[lang = slice_alloc]` bloklaridagi hujjatlarni `&[T]` uchun ko'radi, u ham `core`-da ushbu xususiyatdan foydalangan holda hujjatlarga ega va funktsiya eshigi yoqilmaganidan g'azablanmoqda.
// Ideal holda, u boshqa crates hujjatlari uchun xususiyatlar eshigini tekshirib ko'rmaydi, ammo bu faqat lang elementlari uchun ko'rinishi mumkinligi sababli, tuzatishga arzimaydi.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Ushbu kutubxonani sinovdan o'tkazishga ruxsat bering

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Boshqa modullar tomonidan ishlatiladigan ichki makrolar bilan modul (boshqa modullardan oldin kiritilishi kerak).
#[macro_use]
mod macros;

// To'plar past darajadagi ajratish strategiyasini ta'minladilar

pub mod alloc;

// Yuqoridagi uyumlardan foydalangan holda ibtidoiy turlar

// Test cfg-da qurilish paytida lang-elementlarning takrorlanishiga yo'l qo'ymaslik uchun `boxed.rs`-dan modni shartli ravishda aniqlash kerak;shuningdek, kodga `use boxed::Box;` deklaratsiyasiga ega bo'lishiga ruxsat berish kerak.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}