//! Ibratli mualliflarni yangi makrolarni aniqlashda qo'llab-quvvatlash kutubxonasi.
//!
//! Standart tarqatish bilan ta'minlangan ushbu kutubxona `#[proc_macro]` funktsiyaga o'xshash makroslar, `#[proc_macro_attribute]` so'l atributlari va xususiy derivativ atributlari kabi protsessual ravishda aniqlangan so'l ta'riflar interfeysida iste'mol qilinadigan turlarni taqdim etadi##proc_macro_derive].
//!
//!
//! Qo'shimcha ma'lumot olish uchun [the book]-ga qarang.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Proc_macro-ning hozirda ishlayotgan dasturga kirish imkoniyatini berganligini aniqlaydi.
///
/// Proc_macro crate faqat protsessual makrolarni amalga oshirishda foydalanish uchun mo'ljallangan.Ushbu crate panic-dagi barcha funktsiyalar protsessual so'l tashqarisidan chaqirilsa, masalan, qurilish skriptidan yoki birlik sinovidan yoki oddiy Rust ikkilikidan.
///
/// Ibratli va makrosiz bo'lmagan holatlarni qo'llab-quvvatlashga mo'ljallangan Rust kutubxonalarini hisobga olgan holda, `proc_macro::is_available()` proc_macro API-sidan foydalanish uchun zarur bo'lgan infratuzilma hozirda mavjudligini aniqlash uchun vahima qo'zg'amaydigan usulni taqdim etadi.
/// Agar protsessual so'l ichidan chaqirilsa true, boshqa ikkilikdan chaqirilsa false qiymatini qaytaradi.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Ushbu crate tomonidan taqdim etilgan asosiy tur, bu tokens ning mavhum oqimini yoki aniqrog'i token daraxtlarining ketma-ketligini ifodalaydi.
/// Ushbu tur token daraxtlari bo'ylab takrorlanish uchun interfeyslarni ta'minlaydi va aksincha, bir qator token daraxtlarini bitta oqimga yig'adi.
///
///
/// Bu `#[proc_macro]`, `#[proc_macro_attribute]` va `#[proc_macro_derive]` ta'riflarining kirish va chiqishi.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str`-dan xato qaytdi.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token daraxtlari bo'lmagan bo'sh `TokenStream`-ni qaytaradi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Ushbu `TokenStream` bo'shligini tekshiradi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Ipni tokens-ga uzish va tokens-ni token oqimiga ajratishga urinishlar.
/// Bir qator sabablarga ko'ra ishlamay qolishi mumkin, masalan, agar satrda muvozanatsiz ajratuvchilar yoki tilda mavjud bo'lmagan belgilar bo'lsa.
///
/// Ajratilgan oqimdagi barcha tokens `Span::call_site()` oralig'ini oladi.
///
/// NOTE: ba'zi bir xatolar `LexError`-ni qaytarish o'rniga panics-ni keltirib chiqarishi mumkin.Ushbu xatolarni keyinchalik "LexError" ga o'zgartirish huquqini o'zida saqlab qolamiz.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, ko'prik faqat `to_string`-ni taqdim etadi, unga asoslangan `fmt::Display`-ni amalga oshiradi (ikkalasi o'rtasidagi odatiy munosabatlarning teskarisi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token oqimini zararsiz konvertatsiya qilinishi kerak bo'lgan mag'lubiyatga qaytarib yana bir xil token oqimiga (modul oralig'ida) bosib chiqaradi, ehtimol `Delimiter::None` ajratuvchi va salbiy raqamli harflar bilan "TokenTree: : Group`s" bundan mustasno.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// token-ni disk raskadrovka uchun qulay shaklda chop etadi.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Bitta token daraxtini o'z ichiga olgan token oqimini yaratadi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Bir qator token daraxtlarini bitta oqimga yig'adi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token oqimlarida "flattening" ishlashi token daraxtlarini bir nechta token oqimlaridan bitta oqimga yig'adi.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Mumkin bo'lgan optimallashtirilgan if/when dasturidan foydalaning.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// `TokenStream` turi uchun ochiq dastur tafsilotlari, masalan, iteratorlar.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// "TokenStream" ning "TokenTree" laridan iterator.
    /// Takrorlash "shallow", masalan, takrorlovchi ajratilgan guruhlarga qaytmaydi va butun guruhlarni token daraxtlari sifatida qaytaradi.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` o'zboshimchalik bilan tokens ni qabul qiladi va kirishni tavsiflovchi `TokenStream` ga kengayadi.
/// Masalan, `quote!(a + b)`, baholanganda, `TokenStream` `[Ident("a"), Punct('+', Alone), ni yaratadigan ifoda hosil qiladi. Ident("b")]`.
///
///
/// Tekshirish `$` bilan amalga oshiriladi va bitta identifikatorni kotirovka qilinmagan atama sifatida olish orqali ishlaydi.
/// `$`-ning o'ziga taklif qilish uchun `$$`-dan foydalaning.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Ibratli kengayish ma'lumotlari bilan bir qatorda manba kodi mintaqasi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// `self` oralig'ida berilgan `message` bilan yangi `Diagnostic` hosil qiladi.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Ibratli ta'riflar saytida aniqlanadigan masofa.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Amaldagi protsessual so'lni chaqirish muddati.
    /// Ushbu vaqt oralig'ida yaratilgan identifikatorlar to'g'ridan-to'g'ri so'l qo'ng'iroqlar joyida (qo'ng'iroq-sayt gigienasi) yozilgandek hal qilinadi va so'l qo'ng'iroqlar saytidagi boshqa kodlar ham ularga murojaat qilishi mumkin.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` gigienasini ifodalovchi va ba'zida so'l aniqlanadigan joyda (mahalliy o'zgaruvchilar, yorliqlar, `$crate`) va ba'zida so'l qo'ng'iroqlar saytida (qolgan hamma narsa) aniqlanadigan vaqt.
    ///
    /// Qaerda joylashgan joy qo'ng'iroq qilish saytidan olingan.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Ushbu vaqt oralig'ini ko'rsatadigan asl manba fayli.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Agar mavjud bo'lsa, `self` hosil bo'lgan oldingi so'l kengayishdagi tokens uchun `Span`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` ishlab chiqarilgan manba kodi oralig'i.
    /// Agar bu `Span` boshqa so'l kengayishlaridan yaratilmagan bo'lsa, qaytish qiymati `*self` bilan bir xil bo'ladi.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Ushbu vaqt uchun manba faylida boshlang'ich line/column-ni oladi.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Ushbu vaqt uchun line/column tugashini manba faylida oladi.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` va `other`-ni o'z ichiga olgan yangi oraliqni yaratadi.
    ///
    /// Agar `self` va `other` har xil fayllardan bo'lsa, `None`-ni qaytaradi.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` ma'lumotlari bilan bir xil line/column ma'lumotlariga ega bo'lgan yangi oraliqni yaratadi, ammo bu `other`-da bo'lgani kabi belgilarni hal qiladi.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` bilan bir xil nomdagi rezolyutsiya xatti-harakatlariga ega, ammo `other` ma'lumotlari bilan line/column yangi masofani yaratadi.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Ularning tengligini ko'rish uchun oraliqlarga taqqoslang.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Dastlabki matnni bir vaqt oralig'ida qaytaradi.
    /// Bu bo'sh joy va sharhlarni o'z ichiga olgan asl manba kodini saqlaydi.
    /// Bu oraliq haqiqiy manba kodiga mos keladigan bo'lsa, faqat natijani beradi.
    ///
    /// Note: Makrosning kuzatiladigan natijasi faqat tokens ga tayanishi kerak, bu manba matniga emas.
    ///
    /// Ushbu funktsiya natijasi faqat diagnostika uchun ishlatilishi mumkin bo'lgan eng yaxshi harakatdir.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Vaqtni disk raskadrovka uchun qulay shaklda chop etadi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// `Span` boshi yoki oxirini ifodalovchi chiziqli ustunli juftlik.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// (inclusive) boshlanadigan yoki tugaydigan manba faylidagi 1 indekslangan qator.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// (inclusive) boshlanadigan yoki tugaydigan manba faylidagi 0-indekslangan ustun (UTF-8 belgilarida).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Berilgan `Span`-ning manba fayli.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Ushbu manba faylga yo'l oladi.
    ///
    /// ### Note
    /// Agar ushbu `SourceFile` bilan bog'langan kod oralig'i tashqi makro, bu so'l tomonidan yaratilgan bo'lsa, bu fayl tizimidagi haqiqiy yo'l bo'lmasligi mumkin.
    /// Tekshirish uchun [`is_real`] dan foydalaning.
    ///
    /// Shuni ham yodda tutingki, `is_real` `true` ni qaytargan taqdirda ham, `--remap-path-prefix` buyruq satrida uzatilgan bo'lsa, berilgan yo'l aslida haqiqiy bo'lmasligi mumkin.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Agar ushbu manba fayli haqiqiy manba fayli bo'lsa va tashqi makrosning kengayishi natijasida hosil bo'lmasa, `true`-ni qaytaradi.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Bu interaktiv intervalgacha amalga oshirilgunga qadar buzilishdir va biz tashqi makrolarda yaratilgan intervallarni uchun haqiqiy manba fayllariga ega bo'lishimiz mumkin.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Bitta token yoki token daraxtlarining ajratilgan ketma-ketligi (masalan, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Qavslar ajratuvchilari bilan o'ralgan token oqimi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Identifikator.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Bitta tinish belgisi ("+", `,`, `$` va boshqalar).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// (`'a'`) so'zma-so'z belgisi, (`"hello"`) qatori, (`2.3`) raqami va boshqalar.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// O'z ichiga olgan token yoki ajratilgan oqimning `span` usuliga topshirib, ushbu daraxtning uzunligini qaytaradi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *Faqat shu token* oralig'ini sozlaydi.
    ///
    /// Shuni esda tutingki, agar bu token `Group` bo'lsa, u holda bu usul har bir ichki tokens oralig'ini sozlamaydi, bu shunchaki har bir variantning `set_span` usuliga vakolat beradi.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// token daraxtini disk raskadrovka uchun qulay shaklda bosib chiqaradi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ularning har biri olingan tuzatishda struct turidagi ismga ega, shuning uchun qo'shimcha bilvosita qatlam bilan bezovta qilmang
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, ko'prik faqat `to_string`-ni taqdim etadi, unga asoslangan `fmt::Display`-ni amalga oshiradi (ikkalasi o'rtasidagi odatiy munosabatlarning teskarisi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token daraxtini zararsiz konvertatsiya qilinishi kerak bo'lgan mag'lubiyatga qaytarib yana bir xil token daraxtiga (modul oralig'ida) bosib chiqaradi, ehtimol `Delimiter::None` chegaralari va salbiy raqamli harflari bilan "TokenTree: : Group`s" bundan mustasno.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Ajratilgan token oqimi.
///
/// `Group` ichki qismida "Ajratuvchi" bilan o'rab olingan `TokenStream` mavjud.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token daraxtlari ketma-ketligi qanday ajratilganligini tasvirlaydi.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Masalan, tokens atrofida "macro variable" `$var` dan kelib chiqishi mumkin bo'lgan yopiq ajratuvchi.
    /// `$var * 3` kabi holatlarda operatorning ustuvorligini saqlab qolish muhimdir, bu erda `$var` `1 + 2` bo'ladi.
    /// Yashirin ajratuvchilar token oqimining magistral orqali aylanib o'tishida omon qolmasligi mumkin.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Berilgan ajratuvchi va token oqimi bilan yangi `Group` yaratadi.
    ///
    /// Ushbu konstruktor ushbu guruh uchun `Span::call_site()` oralig'ini o'rnatadi.
    /// Vaqt oralig'ini o'zgartirish uchun quyidagi `set_span` usulidan foydalanishingiz mumkin.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Ushbu `Group` ajratuvchisini qaytaradi
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Ushbu `Group` da chegaralangan tokens ning `TokenStream`-ni qaytaradi.
    ///
    /// Qaytgan token oqimiga yuqorida qaytarilgan ajratuvchi kiritilmaganligini unutmang.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Ushbu token oqimining ajratuvchisi uchun butun `Group` oralig'ini qaytaradi.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ushbu guruhning ochilish chegarasini ko'rsatgan oraliqni qaytaradi.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Ushbu guruhning yakuniy ajratuvchisini ko'rsatgan oraliqni qaytaradi.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Ushbu "Guruh" ning ajratuvchisi uchun oraliqni sozlaydi, lekin uning ichki tokens emas.
    ///
    /// Ushbu usul ushbu guruh tomonidan kiritilgan barcha ichki tokens oralig'ini o'rnatmaydi **, aksincha u faqat ajratuvchi tokens oralig'ini `Group` darajasida o'rnatadi.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, ko'prik faqat `to_string`-ni taqdim etadi, unga asoslangan `fmt::Display`-ni amalga oshiradi (ikkalasi o'rtasidagi odatiy munosabatlarning teskarisi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// `Delimiter::None` ajratgichli "TokenTree: : Group`s" dan tashqari, guruhni yo'qotishsiz aynan shu guruhga (modul oralig'iga) aylantirilishi kerak bo'lgan mag'lubiyat sifatida chiqaradi.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct`-bu `+`, `-` yoki `#` kabi bitta tinish belgisi.
///
/// `+=` kabi ko'p belgili operatorlar `Punct` ning ikkita nusxasi sifatida qaytariladi, ular `Spacing` ning har xil shakllari qaytarilgan.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// `Punct` ni darhol boshqa `Punct` yoki undan keyin boshqa token yoki bo'sh joyni kuzatib boradimi.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// Masalan, `+`-`+ =`, `+ident` yoki `+()` da `Alone`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// Masalan, `+`-`+=` yoki `'#` da `Joint`.
    /// Bundan tashqari, bitta tirnoq `'` identifikatorlar bilan qo'shilib, `'ident` umr ko'rish vaqtini hosil qilishi mumkin.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Berilgan belgidan va intervaldan yangi `Punct` hosil qiladi.
    /// `ch` argumenti til tomonidan ruxsat berilgan to'g'ri tinish belgisi bo'lishi kerak, aks holda funktsiya panic bo'ladi.
    ///
    /// Qaytgan `Punct` standart `Span::call_site()` oralig'iga ega bo'lib, uni quyidagi `set_span` usuli bilan sozlash mumkin.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Ushbu tinish belgilarining qiymatini `char` sifatida qaytaradi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Ushbu tinish belgilarining oralig'ini qaytaradi, bu token oqimida zudlik bilan boshqa `Punct` tomonidan ta'qib qilinishini, shuning uchun ularni potentsial ravishda (`Joint`) ko'p belgilarli operatorga birlashtirilishi yoki undan keyin boshqa token yoki bo'sh joy (`Alone`) bilan bajarilishini ko'rsatadi, shuning uchun operator albatta tugadi.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Ushbu tinish belgisi uchun oraliqni qaytaradi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ushbu tinish belgisi uchun oraliqni sozlang.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ko'prik faqat `to_string`-ni taqdim etadi, unga asoslangan `fmt::Display`-ni amalga oshiradi (ikkalasi o'rtasidagi odatiy munosabatlarning teskarisi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tinish belgisini xuddi shu belgiga qaytarib, kayıpsız konvertatsiya qilinishi kerak bo'lgan satr sifatida chiqaradi.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// (`ident`) identifikatori.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Berilgan `string` va ko'rsatilgan `span` bilan yangi `Ident` yaratadi.
    /// `string` argumenti til tomonidan ruxsat berilgan aniq identifikator bo'lishi kerak (shu jumladan kalit so'zlar, masalan, `self` yoki `fn`).Aks holda, funktsiya panic bo'ladi.
    ///
    /// `span`, hozirda rustc-da, ushbu identifikator uchun gigiena ma'lumotlarini sozlaydi.
    ///
    /// Shu vaqtdan boshlab `Span::call_site()` aniq "call-site" gigienasini tanlaydi, ya'ni ushbu vaqt oralig'ida yaratilgan identifikatorlar to'g'ridan-to'g'ri so'l qo'ng'iroq joyida yozilgandek hal qilinadi va so'l qo'ng'iroq saytidagi boshqa kodlarga murojaat qilish mumkin bo'ladi. ularni ham.
    ///
    ///
    /// Keyinchalik `Span::def_site()` kabi oraliqlar "definition-site" gigienasiga qo'shilishga imkon beradi, ya'ni ushbu vaqt oralig'ida yaratilgan identifikatorlar so'l ta'rifi joylashgan joyda hal qilinadi va so'l qo'ng'iroqlar saytidagi boshqa kodlar ularga murojaat qila olmaydi.
    ///
    /// Gigienaning dolzarbligi sababli ushbu konstruktor, boshqa tokens dan farqli o'laroq, qurilishda `Span` ni ko'rsatishni talab qiladi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` bilan bir xil, ammo (`r#ident`) xom identifikatorini yaratadi.
    /// `string` argumenti til tomonidan ruxsat berilgan aniq identifikator bo'lishi mumkin (shu jumladan kalit so'zlar, masalan, `fn`).
    /// Yo'l segmentlarida ishlatilishi mumkin bo'lgan kalit so'zlar (masalan:
    /// `self`, "super`) qo'llab-quvvatlanmaydi va panic ga olib keladi.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// [`to_string`](Self::to_string) tomonidan qaytarilgan barcha qatorni o'z ichiga olgan ushbu `Ident` oralig'ini qaytaradi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ushbu `Ident` oralig'ini sozlaydi, ehtimol uning gigiena sharoitlarini o'zgartiradi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ko'prik faqat `to_string`-ni taqdim etadi, unga asoslangan `fmt::Display`-ni amalga oshiradi (ikkalasi o'rtasidagi odatiy munosabatlarning teskarisi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Identifikatorni xuddi shu identifikatorga qaytarib, kayıpsız konvertatsiya qilinishi kerak bo'lgan satr sifatida bosib chiqaradi.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// (`"hello"`) so'zma-so'z mag'lubiyati, (`b"hello"`) baytli satr, (`'a'`) belgi, (`b'a'`) baytli belgi, qo'shimchali yoki bo'lmasdan (`1`, `1u8`, `2.3`, `2.3f32`) butun son yoki suzuvchi nuqta raqami.
///
/// `true` va `false` kabi mantiqiy adabiyotlar bu erga tegishli emas, ular "Ident`s".
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Belgilangan qiymat bilan yangi qo'shimchali butun sonni yaratadi.
        ///
        /// Ushbu funktsiya `1u32` kabi butun sonni yaratadi, bu erda ko'rsatilgan tamsayı qiymati token ning birinchi qismidir va integral ham oxirida qo'shiladi.
        /// Salbiy sonlardan hosil bo'lgan literallar `TokenStream` yoki iplar bo'ylab aylanib o'tishda omon qolmasligi va ikkita tokens (`-` va musbat literal) ga bo'linishi mumkin.
        ///
        ///
        /// Ushbu usul orqali yaratilgan literallar sukut bo'yicha `Span::call_site()` oralig'iga ega, ularni quyidagi `set_span` usuli bilan sozlash mumkin.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Belgilangan qiymat bilan yangi qo'shilmagan butun sonni yaratadi.
        ///
        /// Ushbu funktsiya `1` kabi butun sonni yaratadi, bu erda ko'rsatilgan tamsayı token ning birinchi qismi hisoblanadi.
        /// Ushbu token-da hech qanday qo'shimchalar ko'rsatilmagan, ya'ni `Literal::i8_unsuffixed(1)` kabi chaqiriqlar `Literal::u32_unsuffixed(1)` ga teng.
        /// Salbiy sonlardan hosil bo'lgan literallar `TokenStream` yoki satrlar orqali o'tish paytida omon qolmasligi va ikkita tokens (`-` va musbat literal) ga bo'linishi mumkin.
        ///
        ///
        /// Ushbu usul orqali yaratilgan literallar sukut bo'yicha `Span::call_site()` oralig'iga ega, ularni quyidagi `set_span` usuli bilan sozlash mumkin.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Yangi qo'shimchasiz suzuvchi nuqta harfini yaratadi.
    ///
    /// Ushbu konstruktor `Literal::i8_unsuffixed` ga o'xshaydi, bu erda float qiymati to'g'ridan-to'g'ri token-ga chiqadi, lekin hech qanday qo'shimchalar ishlatilmaydi, shuning uchun keyinchalik kompilyatorda `f64` bo'lishi mumkin.
    ///
    /// Salbiy sonlardan hosil bo'lgan literallar `TokenStream` yoki satrlar orqali o'tish paytida omon qolmasligi va ikkita tokens (`-` va musbat literal) ga bo'linishi mumkin.
    ///
    /// # Panics
    ///
    /// Ushbu funktsiya belgilangan float sonli bo'lishini talab qiladi, masalan, agar u cheksiz bo'lsa yoki NaN bo'lsa, bu funktsiya panic bo'ladi.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Yangi qo'shimchali suzuvchi nuqta harfini yaratadi.
    ///
    /// Ushbu konstruktor `1.0f32` kabi so'zma-so'z so'zlarni yaratadi, bu erda ko'rsatilgan qiymat token ning oldingi qismi va `f32` token qo'shimchasidir.
    /// Ushbu token har doim kompilyatorda `f32` bo'lishi mumkin.
    /// Salbiy sonlardan hosil bo'lgan literallar `TokenStream` yoki satrlar orqali o'tish paytida omon qolmasligi va ikkita tokens (`-` va musbat literal) ga bo'linishi mumkin.
    ///
    ///
    /// # Panics
    ///
    /// Ushbu funktsiya belgilangan float sonli bo'lishini talab qiladi, masalan, agar u cheksiz bo'lsa yoki NaN bo'lsa, bu funktsiya panic bo'ladi.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Yangi qo'shimchasiz suzuvchi nuqta harfini yaratadi.
    ///
    /// Ushbu konstruktor `Literal::i8_unsuffixed` ga o'xshaydi, bu erda float qiymati to'g'ridan-to'g'ri token-ga chiqadi, lekin hech qanday qo'shimchalar ishlatilmaydi, shuning uchun keyinchalik kompilyatorda `f64` bo'lishi mumkin.
    ///
    /// Salbiy sonlardan hosil bo'lgan literallar `TokenStream` yoki satrlar orqali o'tish paytida omon qolmasligi va ikkita tokens (`-` va musbat literal) ga bo'linishi mumkin.
    ///
    /// # Panics
    ///
    /// Ushbu funktsiya belgilangan float sonli bo'lishini talab qiladi, masalan, agar u cheksiz bo'lsa yoki NaN bo'lsa, bu funktsiya panic bo'ladi.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Yangi qo'shimchali suzuvchi nuqta harfini yaratadi.
    ///
    /// Ushbu konstruktor `1.0f64` kabi so'zma-so'z so'zlarni yaratadi, bu erda ko'rsatilgan qiymat token ning oldingi qismi va `f64` token qo'shimchasidir.
    /// Ushbu token har doim kompilyatorda `f64` bo'lishi mumkin.
    /// Salbiy sonlardan hosil bo'lgan literallar `TokenStream` yoki satrlar orqali o'tish paytida omon qolmasligi va ikkita tokens (`-` va musbat literal) ga bo'linishi mumkin.
    ///
    ///
    /// # Panics
    ///
    /// Ushbu funktsiya belgilangan float sonli bo'lishini talab qiladi, masalan, agar u cheksiz bo'lsa yoki NaN bo'lsa, bu funktsiya panic bo'ladi.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String so'zma-so'z.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Belgilar to'g'ridan-to'g'ri.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Bayt qatori so'zma-so'z.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Ushbu so'zma-so'z o'z ichiga olgan vaqtni qaytaradi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ushbu so'zma-so'z bilan bog'liq bo'lgan vaqtni sozlaydi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `range` oralig'idagi faqat manba baytlarini o'z ichiga olgan `self.span()` ning kichik to'plami bo'lgan `Span` ni qaytaradi.
    /// Agar qisqartirilgan vaqt `self` chegaralaridan tashqarida bo'lsa, `None`-ni qaytaradi.
    ///
    // FIXME(SergioBenitez): bayt diapazoni manbaning UTF-8 chegarasida boshlanib tugashini tekshiring.
    // aks holda, asosiy matn chop etilganda panic boshqa joyda paydo bo'lishi mumkin.
    // FIXME(SergioBenitez): foydalanuvchi uchun `self.span()` aslida nimaga mos kelishini bilishning imkoni yo'q, shuning uchun bu usulni hozirda faqat ko'r-ko'rona chaqirish mumkin.
    // Masalan, 'c' belgisi uchun `to_string()`, "'\u{63}'" ni qaytaradi;foydalanuvchi uchun asl matn 'c' ekanligini yoki '\u{63}' ekanligini bilishning imkoni yo'q.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` ga o'xshash narsa, lekin `Bound<&T>` uchun.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, ko'prik faqat `to_string`-ni taqdim etadi, unga asoslangan `fmt::Display`-ni amalga oshiradi (ikkalasi o'rtasidagi odatiy munosabatlarning teskarisi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// To'g'ridan-to'g'ri harfni yo'qotishsiz aylantirilishi kerak bo'lgan mag'lubiyatga aylantiradi (suzuvchi nuqta harflari uchun yaxlitlash bundan mustasno).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Atrof-muhit o'zgaruvchilariga kirishning kuzatilishi.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Atrof-muhit o'zgaruvchisini oling va uni bog'liqlik ma'lumotlarini yaratish uchun qo'shing.
    /// Kompilyatorni bajaradigan tizim tizim o'zgaruvchiga kompilyatsiya paytida kirilganligini biladi va ushbu o'zgaruvchining qiymati o'zgarganda tuzilmani qayta ishga tushiradi.
    ///
    /// Bundan tashqari, qaramlikni kuzatish uchun ushbu funktsiya standart kutubxonadan `env::var` ga teng bo'lishi kerak, faqat argument UTF-8 bo'lishi kerak.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}