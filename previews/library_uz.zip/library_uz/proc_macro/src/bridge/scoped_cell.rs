//! `Cell` (scoped) ekzistensial umr ko'rish uchun variant.

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// Lambda dasturini yozing, umr bo'yi.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// Lambadaning umr bo'yi yozilishini yozing, ya'ni `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) newtype FIXME(#52812) bilan `&'a mut <T as ApplyL<'b>>::Out` o'rniga proyeksiya cheklovlari atrofida ishlash
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// Eski qiymatni mutanosib ravishda qabul qiladigan `f` ishlayotganda `self`-ni `replacement`-ga o'rnatadi.
    /// Eski qiymat `f` chiqqandan keyin, hatto panic tomonidan tiklanadi, shu jumladan unga `f` tomonidan kiritilgan o'zgartirishlar.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// H00X vahimaga tushgan bo'lsa ham, hujayraning har doim to'ldirilishini ta'minlaydigan o'ram (asl holati bilan, ixtiyoriy ravishda `f` tomonidan o'zgartiriladi).
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// `f`-ni ishlatishda `self`-dan `value`-ga qiymatni o'rnatadi.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}