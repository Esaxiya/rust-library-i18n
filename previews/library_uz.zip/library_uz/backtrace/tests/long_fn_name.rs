use backtrace::Backtrace;

// 50 ta belgidan iborat modul nomi
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50 ta belgidan iborat struktura nomi
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Uzoq funktsiya nomlari (MAX_SYM_NAME, 1) belgigacha qisqartirilishi kerak.
// Ushbu testni faqat msvc uchun ishlating, chunki gnu barcha kadrlar uchun "<no info>" ni chiqaradi.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // Struktura nomining 10 ta takrorlanishi, shuning uchun to'liq malakali funktsiya nomi kamida 10 *(50 + 50)* 2=2000 ta belgidan iborat.
    //
    // `::`, `<>` va joriy modul nomini o'z ichiga olganligi sababli, bu aslida uzoqroq
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}