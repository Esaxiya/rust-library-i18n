#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Backtraces uchun formatlashtiruvchi.
///
/// Ushbu turdagi orqaga qaytish izining o'zi qayerdan kelib chiqqanligidan qat'i nazar, orqa nushani chop etish uchun ishlatilishi mumkin.
/// Agar sizda `Backtrace` turi bo'lsa, unda uning `Debug` dasturi ushbu bosib chiqarish formatidan allaqachon foydalanadi.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Biz bosib chiqarishimiz mumkin bo'lgan bosib chiqarish uslublari
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Ideal holda faqat tegishli ma'lumotlarni o'z ichiga oladigan teskari yo'nalishni bosib chiqaradi
    Short,
    /// Barcha mumkin bo'lgan ma'lumotlarni o'z ichiga olgan backtrace-ni nashr etadi
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Berilgan `fmt`-ga chiqishni yozadigan yangi `BacktraceFmt` yarating.
    ///
    /// `format` argumenti orqaga qaytish bosilgan uslubni boshqaradi va `print_path` argumenti `BytesOrWideString` fayl nomlarini chop etish uchun ishlatiladi.
    /// Ushbu turdagi fayl nomlarini bosib chiqarishni amalga oshirmaydi, ammo buning uchun qayta qo'ng'iroq qilish kerak.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Bosib chiqarilishi kerak bo'lgan backtrace uchun preambulani bosib chiqaradi.
    ///
    /// Backtraces keyinchalik to'liq ramziy ma'noga ega bo'lishi uchun bu ba'zi platformalarda talab qilinadi va aks holda bu `BacktraceFmt` yaratgandan keyin qo'ng'iroq qiladigan birinchi usul bo'lishi kerak.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Orqaga qarab chiqish uchun freym qo'shadi.
    ///
    /// Ushbu majburiyat aslida ramkani chop etish uchun ishlatilishi mumkin bo'lgan `BacktraceFrameFmt` ning RAII nusxasini qaytaradi va yo'q qilishda u ramka hisoblagichini oshiradi.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Orqaga qarab chiqishni yakunlaydi.
    ///
    /// Hozirda bu no-op, ammo future-ning orqaga qaytish formatlari bilan mosligi uchun qo'shilgan.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Hozirda future qo'shimchalariga ruxsat berish uchun ushbu hook-ni bekor qilish.
        Ok(())
    }
}

/// Orqaga qaytishning faqat bitta ramkasi uchun formatlashtiruvchi.
///
/// Ushbu turdagi `BacktraceFmt::frame` funktsiyasi tomonidan yaratilgan.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Ushbu ramka formatlashtiruvchisi yordamida `BacktraceFrame`-ni bosib chiqaradi.
    ///
    /// Bu `BacktraceFrame` ichidagi barcha `BacktraceSymbol` nusxalarini rekursiv ravishda bosib chiqaradi.
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceSymbol`-ni `BacktraceFrame` ichida bosib chiqaradi.
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: biz hech narsani bosib chiqarmasligimiz juda yaxshi emas
            // utf8 bo'lmagan fayl nomlari bilan.
            // Yaxshiyamki, deyarli barchasi utf8, shuning uchun bu juda yomon bo'lmasligi kerak.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// `Frame` va `Symbol` xom izlarini, odatda ushbu crate ning qayta qo'ng'iroqlari ichida bosib chiqaradi.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Orqaga qarab chiqish uchun xom ramkani qo'shadi.
    ///
    /// Ushbu usul, avvalgisidan farqli o'laroq, turli xil manbalardan kelib chiqqan holda, dastlabki dalillarni oladi.
    /// Shuni esda tutingki, bu bitta ramka uchun bir necha marta chaqirilishi mumkin.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Dastlabki ma'lumotni o'z ichiga olgan orqa chiziqli chiqishga xom kadr qo'shiladi.
    ///
    /// Ushbu usul, avvalgi kabi, turli xil manbalardan kelib chiqqan holda, dastlabki dalillarni oladi.
    /// Shuni esda tutingki, bu bitta ramka uchun bir necha marta chaqirilishi mumkin.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuşya jarayon davomida ramziy ma'noga ega emas, shuning uchun keyinchalik uni ramziy qilish uchun ishlatilishi mumkin bo'lgan maxsus format mavjud.
        // O'zingizning formatdagi manzillarni chop etish o'rniga, bu erda chop eting.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" freymlarini chop etishning hojati yo'q, bu asosan tizim orqaga chekinishi juda uzoqqa borishni istaganligini anglatadi.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx anklavida TCB hajmini kamaytirish uchun biz simvollarni aniqlashtirish funktsiyasini amalga oshirishni xohlamaymiz.
        // Aksincha, biz manzilning ofsetini bu erda chop etishimiz mumkin, keyinroq bu funktsiyani to'g'rilash uchun xaritalash mumkin.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Kadrning indeksini, shuningdek freymning ixtiyoriy ko'rsatma ko'rsatgichini chop eting.
        // Agar biz ushbu ramkaning birinchi belgisidan tashqarida bo'lsak ham, biz bo'sh joyni bosib chiqaramiz.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Agar biz to'liq orqaga qaytsak, qo'shimcha ma'lumot olish uchun muqobil formatlash yordamida simvol nomini yozing.
        // Bu erda biz ismga ega bo'lmagan belgilar bilan ishlaymiz,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Va agar mavjud bo'lsa, filename/line raqamini chop eting.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line satrlarda belgi nomi ostida bosilgan, shuning uchun o'zimizga to'g'ri tekislash uchun bo'sh joyni bosib chiqaramiz.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Fayl nomini chop etish uchun ichki qo'ng'iroqni amalga oshiring va keyin qator raqamini chiqaring.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Agar mavjud bo'lsa, ustun raqamini qo'shing.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Biz faqat ramkaning birinchi belgisi haqida qayg'uramiz
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}