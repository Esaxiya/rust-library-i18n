use core::ffi::c_void;
use core::fmt;

/// Stak izini hisoblash uchun taqdim etilgan yopilishga barcha faol freymlarni o'tkazib, joriy chaqiruv stekini tekshiradi.
///
/// Ushbu funktsiya dastur uchun stek izlarini hisoblashda ushbu kutubxonaning ishchi otidir.Ushbu yopilish `cb` stakadagi ushbu qo'ng'iroq doirasi haqida ma'lumotni ko'rsatadigan `Frame` misollarini keltirib chiqaradi.
/// O'chirish ramkalari yuqoridan pastga qarab beriladi (so'nggi funktsiyalar birinchi navbatda).
///
/// Yopilishning qaytish qiymati bu orqaga qaytishni davom ettirish kerakligidan dalolat beradi.Qaytish qiymati `false` orqaga qaytishni to'xtatadi va darhol qaytadi.
///
/// `Frame` sotib olingandan so'ng, ehtimol siz `ip` (ko'rsatma ko'rsatgichi) yoki belgi manzilini `Symbol` ga ism va/yoki fayl nomi/satr raqamini bilib olish uchun aylantirish uchun `backtrace::resolve` ga qo'ng'iroq qilishni xohlaysiz.
///
///
/// Shuni esda tutingki, bu nisbatan past darajadagi funktsiya va agar siz, masalan, keyinroq tekshirilishi kerak bo'lgan orqaga qaytishni olishni istasangiz, unda `Backtrace` turi ko'proq mos kelishi mumkin.
///
/// # Kerakli xususiyatlar
///
/// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
///
/// # Panics
///
/// Ushbu funktsiya hech qachon panic-ga intilmaydi, lekin agar `cb` panics-ni taqdim qilsa, u holda ba'zi platformalar bu jarayonni bekor qilishga panic-ni ikki baravar majbur qiladi.
/// Ba'zi platformalar C kutubxonasidan foydalanadi, u qo'ng'iroqlarni qaytarib bo'lmaydigan tarzda ishlatadi, shuning uchun `cb` dan vahima tushishi jarayonni to'xtatishi mumkin.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // orqaga qaytishni davom eting
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` bilan bir xil, faqat sinxronlashtirilmaganligi sababli xavfli.
///
/// Ushbu funktsiya sinxronizatsiya kafolatiga ega emas, lekin ushbu crate ning `std` xususiyati to'planmaganida mavjud bo'ladi.
/// Qo'shimcha hujjatlar va misollar uchun `trace` funktsiyasini ko'ring.
///
/// # Panics
///
/// `cb` panikasida ogohlantirishlar haqida `trace` ma'lumotlarini ko'ring.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Orqaga qaytishning bir ramkasini ifodalovchi trait ushbu crate ning `trace` funktsiyasiga olib keldi.
///
/// Kuzatuv funktsiyasining yopilishi freymlardan olinadi va ramka deyarli yuboriladi, chunki uning bajarilishi har doim ham ish vaqtigacha ma'lum bo'lmaydi.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Ushbu ramkaning joriy ko'rsatma ko'rsatgichini qaytaradi.
    ///
    /// Odatda bu freymda bajariladigan navbatdagi ko'rsatma, ammo hamma dasturlarda ham buni 100% aniqlik bilan sanab bo'lmaydi (lekin umuman olganda bu juda yaqin).
    ///
    ///
    /// Belgilar nomiga aylantirish uchun ushbu qiymatni `backtrace::resolve` ga o'tkazish tavsiya etiladi.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Ushbu ramkaning joriy stek ko'rsatkichini qaytaradi.
    ///
    /// Agar backend ushbu ramka uchun stek ko'rsatkichini tiklay olmasa, nol ko'rsatkich qaytariladi.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Ushbu funktsiya ramkasining boshlang'ich belgisi manzilini qaytaradi.
    ///
    /// Bu `ip` tomonidan qaytarilgan ko'rsatma funktsiyasini funktsiya boshlanishiga qaytarib, ushbu qiymatni qaytarishga harakat qiladi.
    ///
    /// Biroq, ba'zi hollarda, orqa funktsiyalar `ip`-ni ushbu funktsiyadan qaytaradi.
    ///
    /// Qaytgan qiymat ba'zan `backtrace::resolve` yuqorida keltirilgan `ip` da ishlamay qolsa ishlatilishi mumkin.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Kadr tegishli bo'lgan modulning asosiy manzilini qaytaradi.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Bunga birinchi navbatda Miri mezbon platformadan ustunlik berishini ta'minlash kerak
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // faqat dbghelp ramzida ishlatiladi
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}