//! Windows dbghelp ulanishlarini boshqarishda yordam beradigan modul
//!
//! Windows-dagi backtraces (hech bo'lmaganda MSVC uchun) asosan `dbghelp.dll` va u tarkibidagi turli funktsiyalar orqali quvvatlanadi.
//! Ushbu funktsiyalar hozirda `dbghelp.dll`-ga statik ulanish o'rniga *dinamik ravishda* yuklanmoqda.
//! Bu hozirda standart kutubxona tomonidan amalga oshiriladi (va nazariy jihatdan u erda talab qilinadi), lekin kutubxonaning statik DLL bog'liqligini kamaytirishga yordam berish uchun harakat, chunki backtraces odatda juda ixtiyoriydir.
//!
//! Aytish kerakki, `dbghelp.dll` deyarli har doim Windows-ga muvaffaqiyatli yuklaydi.
//!
//! Shuni esda tutingki, biz ushbu qo'llab-quvvatlashning barchasini dinamik ravishda yuklayotgan bo'lsak, biz `winapi`-da xom ta'riflardan foydalana olmaymiz, aksincha biz funktsiya ko'rsatgich turlarini o'zimiz belgilashimiz va undan foydalanishimiz kerak.
//! Biz, albatta, winapi-ni nusxalash bilan shug'ullanishni xohlamaymiz, shuning uchun bizda Cargo xususiyati `verify-winapi` mavjud bo'lib, u barcha bog'lovchilar winapi-ga mos keladi va bu xususiyat CI-da yoqilgan.
//!
//! Va nihoyat, siz bu erda `dbghelp.dll` uchun DLL hech qachon tushirilmasligini va hozirda qasddan ekanligini ta'kidlaysiz.
//! Fikrlash shundaki, biz uni global miqyosda keshlashimiz va API-ga qo'ng'iroqlar paytida foydalanishimiz mumkin, bu esa qimmat loads/unloads-dan qochishdir.
//! Agar bu qochqinlarni aniqlash uchun muammo bo'lsa yoki shunga o'xshash narsalar bo'lsa, biz u erga etib borganimizda ko'prikdan o'tib ketamiz.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Winapi-da mavjud bo'lmagan `SymGetOptions` va `SymSetOptions` atrofida ishlang.
// Aks holda, bu faqat winapi-ga qarshi turlarni qayta tekshirishda foydalaniladi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Winapi-da hali aniqlanmagan
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Bu winapi-da aniqlangan, ammo bu noto'g'ri (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Winapi-da hali aniqlanmagan
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Ushbu so'l, biz yuklashimiz mumkin bo'lgan barcha funktsiyalar ko'rsatkichlarini o'z ichiga olgan `Dbghelp` tuzilishini aniqlash uchun ishlatiladi.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` uchun yuklangan DLL
            dll: HMODULE,

            // Biz foydalanishingiz mumkin bo'lgan har bir funktsiya uchun har bir funktsiya ko'rsatgichi
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Dastlab biz DLL-ni yuklamadik
            dll: 0 as *mut _,
            // Initiall barcha funktsiyalar dinamik ravishda yuklanishi kerakligini aytish uchun nolga o'rnatiladi.
            //
            $($name: 0,)*
        };

        // Har bir funktsiya turi uchun qulaylik typedef.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll`-ni ochishga urinishlar.
            /// Agar u ishlamasa yoki `LoadLibraryW` ishlamay qolsa xatoga yo'l qo'yadi.
            ///
            /// Kutubxona allaqachon yuklangan bo'lsa, Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Biz foydalanmoqchi bo'lgan har bir usul uchun funktsiya.
            // Qachon chaqirilsa, u keshlangan funktsiya ko'rsatgichini o'qiydi yoki uni yuklaydi va yuklangan qiymatni qaytaradi.
            // Yuklar muvaffaqiyatli bo'lishiga ishonishadi.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp funktsiyalariga havola qilish uchun tozalash qulflaridan foydalanish uchun qulay proksi-server.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Ushbu crate-dan `dbghelp` API funktsiyalariga kirish uchun zarur bo'lgan barcha yordamlarni ishga tushiring.
///
///
/// Shuni esda tutingki, bu funktsiya **xavfsiz**, uning ichki sinxronizatsiyasi mavjud.
/// Shuni ham unutmangki, ushbu funktsiyani bir necha marta rekursiv ravishda chaqirish xavfsizdir.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Bizga kerak bo'lgan birinchi narsa-bu funktsiyani sinxronlashtirish.Buni boshqa iplardan bir vaqtning o'zida yoki bitta ip ichida rekursiv ravishda chaqirish mumkin.
        // E'tibor bering, bundan ham hiyla-nayrang bor, chunki biz `dbghelp`,*shuningdek* bu jarayonda `dbghelp`-ga boshqa barcha qo'ng'iroqchilar bilan sinxronlashtirilishi kerak.
        //
        // Odatda, xuddi shu jarayonda `dbghelp`-ga juda ko'p qo'ng'iroqlar mavjud emas va ehtimol biz faqatgina unga kirayapmiz deb taxmin qilishimiz mumkin.
        // Shu bilan birga, biz xavotirga tushadigan yana bir asosiy foydalanuvchi bor, bu biz uchun g'alati, ammo standart kutubxonada.
        // Orqa yo'nalishni qo'llab-quvvatlash uchun Rust standart kutubxonasi ushbu crate ga bog'liq va bu crate crates.io da ham mavjud.
        // Bu shuni anglatadiki, agar standart kutubxona panic backtrace-ni bosib chiqarayotgan bo'lsa, u crates.io-dan kelib chiqadigan ushbu crate bilan poyga qilishi mumkin va bu segfaultlarni keltirib chiqaradi.
        //
        // Ushbu sinxronizatsiya muammosini hal qilishga yordam berish uchun biz bu erda Windows-ga xos bir hiyla ishlatamiz (bu, oxir-oqibat, sinxronizatsiya uchun Windows-ga xos cheklov).
        // Ushbu qo'ng'iroqni himoya qilish uchun *sessiya-mahalliy* nomli mutex yaratamiz.
        // Bu erda niyat shuki, standart kutubxona va crate bu erda sinxronlash uchun Rust darajasidagi API-larni baham ko'rishlari shart emas, aksincha ular bir-biri bilan sinxronlashayotganiga ishonch hosil qilish uchun sahna ortida ishlashlari mumkin.
        //
        // Shunday qilib, ushbu funktsiya standart kutubxona yoki crates.io orqali chaqirilganda, xuddi shu muteks sotib olinganligiga amin bo'lishimiz mumkin.
        //
        // Demak, bularning barchasi bu erda biz X001 da nomlangan muteks bo'lgan `HANDLE` ni atomik ravishda yaratishimizdir.
        // Biz ushbu funktsiyani alohida almashadigan boshqa mavzular bilan biroz sinxronlashtiramiz va ushbu funktsiya nusxasi uchun faqat bitta tutqich yaratilishini ta'minlaymiz.
        // Shuni esda tutingki, global tizimda saqlangandan so'ng dastak hech qachon yopilmaydi.
        //
        // Biz aslida qulfni bosib o'tgandan so'ng, biz uni sotib olamiz va biz tarqatadigan `Init` tutqichimiz oxir-oqibat uni tashlab yuborish uchun javobgar bo'ladi.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Xo'sh, jiyan!Endi barchamiz xavfsiz sinxronlashtirilgandan so'ng, aslida hamma narsani qayta ishlashni boshlaymiz.
        // Birinchidan, biz ushbu jarayonda `dbghelp.dll` haqiqatan ham yuklanganligini ta'minlashimiz kerak.
        // Statik qaramlikdan saqlanish uchun biz buni dinamik ravishda qilamiz.
        // Bu tarixiy ravishda g'alati bog'lanish muammolari ustida ishlash uchun qilingan va ikkiliklarni biroz ko'chirishga qaratilgan, chunki bu asosan disk raskadrovka dasturi.
        //
        //
        // `dbghelp.dll`-ni ochganimizdan so'ng, unda ba'zi bir boshlang'ich funktsiyalarini chaqirishimiz kerak va bu quyida batafsilroq.
        // Biroq, biz buni faqat bir marta qilamiz, shuning uchun biz hali ham tugagan yoki qilmaganligimizni ko'rsatadigan global mantiqiy ma'lumotga egamiz.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` bayrog'i o'rnatilganligiga ishonch hosil qiling, chunki bu haqda MSVC-ning shaxsiy hujjatlari bo'yicha: "This is the fastest, most efficient way to use the symbol handler.", shunday qilaylik!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // MSVC bilan aslida ramzlarni ishga tushiring.E'tibor bering, bu muvaffaqiyatsiz bo'lishi mumkin, ammo biz buni e'tiborsiz qoldiramiz.
        // Buning uchun avvalgi texnikaning bir tonnasi yo'q, lekin LLVM ichki sifatida bu erda qaytarish qiymatini e'tiborsiz qoldiradi va LLVM-dagi sanitarizatsiya kutubxonalaridan biri bu muvaffaqiyatsiz bo'lsa, qo'rqinchli ogohlantirishni bosib chiqaradi, lekin asosan uni uzoq muddatda e'tiborsiz qoldiradi.
        //
        //
        // Bitta narsa, bu Rust uchun juda katta ahamiyatga ega, bu standart kutubxona va crates.io-dagi ushbu crate ikkalasi ham `SymInitializeW` uchun raqobatlashmoqchi.
        // Standart kutubxona tarixiy jihatdan ko'pincha tozalashni boshlashni xohlagan edi, ammo endi bu crate dan foydalangan holda demak, kimdir birinchi bo'lib ishga tushirishga kirishadi, ikkinchisi esa ushbu ishga tushirishni oladi.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}