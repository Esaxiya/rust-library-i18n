use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr qayta qo'ng'iroqni qabul qiladi, bu jarayonga bog'langan har bir DSO uchun dl_phdr_info ko'rsatgichini oladi.
    // dl_iterate_phdr shuningdek, dinamik bog'lovchining takrorlanish boshidan oxirigacha bloklanishini ta'minlaydi.
    // Agar qayta qo'ng'iroq nolga teng bo'lmagan qiymatni qaytarsa, takrorlash erta tugaydi.
    // 'data' har bir qo'ng'iroqdagi qayta qo'ng'iroqning uchinchi argumenti sifatida qabul qilinadi.
    // 'size' dl_phdr_info hajmini beradi.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Qurilish identifikatorini va ba'zi bir dasturning asosiy sarlavhalari ma'lumotlarini tahlil qilishimiz kerak, bu bizga ELF spetsifikatsiyasidan ham ozgina narsalar kerakligini anglatadi.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Endi biz fuchsiyaning hozirgi dinamik bog'lovchisi foydalanadigan dl_phdr_info turidagi tuzilmani bitdan bitgacha takrorlashimiz kerak.
// Chromium-da ABI chegarasi, shuningdek, qulflangan panel mavjud.
// Oxir oqibat biz ushbu holatlarni elf-search-dan foydalanish uchun ko'chirmoqchimiz, lekin buni SDK-da taqdim etishimiz kerak va bu hali bajarilmagan.
//
// Shunday qilib, biz (va ular) fuchsi libc bilan qattiq bog'lanishni keltirib chiqaradigan ushbu usuldan foydalanishimiz kerak.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Bizda e_phoff va e_phnum haqiqiyligini tekshirishni bilishning imkoni yo'q.
    // libc biz uchun buni ta'minlashi kerak, ammo bu erda tilim hosil qilish xavfsizdir.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr maqsadli me'morchilikning to'liqligi uchun 64-bitli ELF dastur sarlavhasini aks ettiradi.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr tegishli ELF dastur sarlavhasini va uning tarkibini aks ettiradi.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Bizda p_addr yoki p_memsz haqiqiyligini tekshirish imkoniyati yo'q.
    // Fuchsia libc birinchi navbatda notalarni tahlil qiladi, ammo bu erda bo'lish uchun bu sarlavhalar haqiqiy bo'lishi kerak.
    //
    // NoteIter asosiy ma'lumotlarning haqiqiyligini talab qilmaydi, lekin chegaralarning haqiqiyligini talab qiladi.
    // Biz libc bu erda biz uchun shunday bo'lishini ta'minlaganiga ishonamiz.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Qurilish identifikatorlari uchun eslatma turi.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr maqsadning endiannessida ELF nota sarlavhasini aks ettiradi.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Eslatma ELF notasini bildiradi (sarlavha + tarkibi).
// Ism u8 bo'lagi sifatida qoldirilgan, chunki u har doim ham bekor qilinmaydi va rust baytlarning baribir mos kelishini tekshirishni osonlashtiradi.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter sizga notalar segmentida xavfsiz tarzda takrorlash imkonini beradi.
// Xatolik yuz berishi yoki boshqa eslatmalar yo'qligi bilanoq u tugaydi.
// Agar siz yaroqsiz ma'lumotlar ustida takrorlansangiz, u hech qanday eslatma topilmaganday ishlaydi.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Belgilangan ko'rsatkich va o'lchamlarning barchasi o'qilishi mumkin bo'lgan baytlarning to'g'ri doirasini bildirishi funktsiya o'zgarmasligidir.
    // Ushbu baytlarning mazmuni har qanday narsadan iborat bo'lishi mumkin, ammo uning xavfsiz bo'lishi uchun diapazon haqiqiy bo'lishi kerak.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to, 'to' 2 ga teng deb faraz qilgan holda, 'x'-ni 'to'-baytgacha tenglashtirishga to'g'ri keladi.
// Bu C (C ++) va -to ishlatilgan C/C ++ ELF tahlil kodidagi standart naqshga amal qiladi.
// Rust sizga foydalanishni bekor qilishga imkon bermaydi, shuning uchun men foydalanaman
// Buni qayta yaratish uchun 2-ni to'ldiruvchi konversiya.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 tilimdan olingan baytlarni sarflaydi (agar mavjud bo'lsa) va qo'shimcha ravishda oxirgi tilimning to'g'ri hizalanishini ta'minlaydi.
// Agar so'ralgan baytlar soni juda katta bo'lsa yoki keyinchalik etarli miqdordagi bayt mavjud bo'lmagani uchun uni qayta tuzib bo'lmaydigan bo'lsa, Hech narsa qaytarilmaydi va tilim o'zgartirilmaydi.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ushbu funktsiya qo'ng'iroq qiluvchining qo'llab-quvvatlashi kerak bo'lgan haqiqiy invariantlarga ega emas, ehtimol 'bytes' ishlashi uchun moslashtirilishi kerak (va ba'zi arxitekturalar to'g'riligida).
// Elf_Nhdr maydonlaridagi qiymatlar bema'nilik bo'lishi mumkin, ammo bu funktsiya bunday bo'lmasligini ta'minlaydi.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Joy etarli bo'lsa, bu xavfsizdir va biz yuqoridagi if bayonotida bu xavfli bo'lmasligi kerakligini tasdiqladik.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Sice_of: : ga e'tibor bering<Elf_Nhdr>() har doim 4 bayt hizalanadi.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Biz oxiriga etganligimizni tekshiring.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Biz nhdr-ni o'zgartiramiz, ammo natijada olingan strukturani diqqat bilan ko'rib chiqamiz.
        // Biz namesz yoki descsz-ga ishonmaymiz va turiga qarab hech qanday xavfli qaror qabul qilmaymiz.
        //
        // Shunday qilib, biz to'liq axlatdan chiqsak ham, xavfsiz bo'lishimiz kerak.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Segmentning bajarilishini bildiradi.
const PERM_X: u32 = 0b00000001;
/// Segmentning yozilishi mumkinligini bildiradi.
const PERM_W: u32 = 0b00000010;
/// Segmentning o'qilishi mumkinligini bildiradi.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Ish paytida ELF segmentini ifodalaydi.
struct Segment {
    /// Ushbu segment tarkibidagi ish vaqti virtual manzilini beradi.
    addr: usize,
    /// Ushbu segment tarkibidagi xotira hajmini beradi.
    size: usize,
    /// ELF fayli bilan ushbu segmentning modul virtual manzilini beradi.
    mod_rel_addr: usize,
    /// ELF faylida mavjud bo'lgan ruxsatlarni beradi.
    /// Ushbu ruxsatnomalar, albatta, ish vaqtida mavjud bo'lgan ruxsatnomalar emas.
    flags: Perm,
}

/// DSO segmentlari bo'yicha bir marta takrorlashga imkon beradi.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO (Dynamic Shared Object) vakili.
/// Ushbu turdagi nusxa ko'chirish o'rniga haqiqiy DSO-da saqlangan ma'lumotlarga murojaat qilinadi.
struct Dso<'a> {
    /// Dinamik bog'lovchi har doim bizga nom beradi, hatto nom bo'sh bo'lsa ham.
    /// Asosiy bajariladigan dasturda bu nom bo'sh bo'ladi.
    /// Umumiy ob'ektda u soname bo'ladi (qarang DT_SONAME).
    name: &'a str,
    /// Fuchsiyada deyarli barcha ikkilik qurilmalarda shaxsiy identifikatorlar mavjud, ammo bu qat'iy talab emas.
    /// Agar build_id bo'lmasa, DSO ma'lumotlarini haqiqiy ELF fayli bilan moslashtirishning iloji yo'q, shuning uchun har bir DSO bu erda bittasini talab qiladi.
    ///
    /// Build_id bo'lmagan DSO'lar e'tiborga olinmaydi.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Ushbu DSO segmentlari bo'yicha iteratorni qaytaradi.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Ushbu xatolar har bir DSO haqida ma'lumotni tahlil qilishda yuzaga keladigan muammolarni kodlaydi.
///
enum Error {
    /// NameError, C uslubidagi satrni rust qatoriga aylantirish paytida xatolik yuz berganligini anglatadi.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError degani, biz qurilish identifikatorini topmadik.
    /// Buning sababi DSO-da qurilish identifikatori yo'qligi yoki tuzilish identifikatorini o'z ichiga olgan segment noto'g'ri tuzilganligi bo'lishi mumkin.
    ///
    BuildIDError,
}

/// Jarayonga dinamik bog'lovchi tomonidan bog'langan har bir DSO uchun 'dso' yoki 'error' qo'ng'iroqlari.
///
///
/// # Arguments
///
/// * `visitor` - Foreach DSO deb nomlangan ovqatlanish usullaridan biriga ega bo'lgan DsoPrinter.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr, info.name to'g'ri manzilni ko'rsatishini ta'minlaydi.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ushbu funktsiya DSO tarkibidagi barcha ma'lumotlar uchun Fuchsia simvolizer belgisini bosib chiqaradi.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}