use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// O'ziga tegishli va o'ziga xos bo'lgan orqaga qaytishning namoyishi.
///
/// Ushbu tuzilma dasturning turli nuqtalarida orqaga qaytishni ta'qib qilish uchun ishlatilishi mumkin va keyinchalik o'sha davrdagi orqaga qarab nima bo'lganligini tekshirish uchun ishlatilishi mumkin.
///
///
/// `Backtrace` `Debug` dasturini amalga oshirish orqali backtraces-ning chiroyli bosib chiqarilishini qo'llab-quvvatlaydi.
///
/// # Kerakli xususiyatlar
///
/// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Bu erda ramkalar to'plamning yuqoridan pastgacha ro'yxatida keltirilgan
    frames: Vec<BacktraceFrame>,
    // `Backtrace::new` va `backtrace::trace` kabi kadrlarni tashlab, orqaga qarab ketishning haqiqiy boshlanishiga ishonamiz.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Orqaga qaytishdagi kadrning olingan versiyasi.
///
/// Ushbu tur `Backtrace::frames`-dan ro'yxat sifatida qaytariladi va olingan stsenariyda bitta to'plam ramkasini aks ettiradi.
///
/// # Kerakli xususiyatlar
///
/// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Orqaga qaytishda belgining olingan nusxasi.
///
/// Ushbu tur `BacktraceFrame::symbols`-dan ro'yxat sifatida qaytariladi va orqaga qaytishdagi belgining meta-ma'lumotlarini aks ettiradi.
///
/// # Kerakli xususiyatlar
///
/// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Ushbu funktsiya chaqirilgan joyida orqaga qaytish suratini oladi va tegishli vakolatxonani qaytaradi.
    ///
    /// Ushbu funktsiya orqaga qaytishni Rust-da ob'ekt sifatida ko'rsatish uchun foydalidir.Ushbu qaytarilgan qiymat iplar bo'ylab yuborilishi va boshqa joylarda chop etilishi mumkin va bu qiymatning maqsadi butunlay o'z ichiga olishdir.
    ///
    /// E'tibor bering, ba'zi platformalarda to'liq orqaga qaytish va uni hal qilish juda qimmatga tushishi mumkin.
    /// Agar sizning arizangiz uchun xarajat juda ko'p bo'lsa, buning o'rniga `Backtrace::new_unresolved()`-dan foydalanish tavsiya etiladi, bu belgini aniqlash bosqichidan qochadi (bu odatda eng uzoq davom etadi) va uni keyinga qoldirishga imkon beradi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // olib tashlash uchun bu erda ramka mavjudligiga ishonch hosil qilishni xohlaysiz
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new`-ga o'xshash, faqat biron bir belgini hal qila olmaydi, bu shunchaki orqaga qaytishni manzillar ro'yxati sifatida oladi.
    ///
    /// Keyinchalik, `resolve` funktsiyasini chaqirish mumkin, bu orqaga qaytish belgilarini o'qiladigan nomlarga hal qilish.
    /// Ushbu funktsiya mavjud, chunki rezolyutsiya jarayoni ba'zida juda ko'p vaqt talab qilishi mumkin, ammo orqaga qaytish faqat kamdan-kam hollarda chop etilishi mumkin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // ramz nomlari yo'q
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // ramz nomlari hozir mavjud
    /// ```
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    ///
    ///
    #[inline(never)] // olib tashlash uchun bu erda ramka mavjudligiga ishonch hosil qilishni xohlaysiz
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Ushbu orqaga qaytish olingan vaqtdagi kadrlarni qaytaradi.
    ///
    /// Ushbu tilimning birinchi kiritilishi, ehtimol `Backtrace::new` funktsiyasi bo'lishi mumkin, va oxirgi ramka, ehtimol bu ish zarrachasi yoki asosiy funktsiya qanday boshlanganligi bilan bog'liq.
    ///
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Agar bu backtrace `new_unresolved`-dan yaratilgan bo'lsa, unda bu funktsiya orqadagi barcha manzillarni o'zlarining ramziy nomlariga qarab hal qiladi.
    ///
    ///
    /// Agar bu orqaga qaytish ilgari hal qilingan yoki `new` orqali yaratilgan bo'lsa, bu funktsiya hech narsa qilmaydi.
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` bilan bir xil
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` bilan bir xil
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` bilan bir xil
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Ushbu ramka mos keladigan belgilar ro'yxatini qaytaradi.
    ///
    /// Odatda har bir ramkada bitta belgi bo'ladi, lekin ba'zida bir qator funktsiyalar bitta ramkaga kiritilgan bo'lsa, unda bir nechta belgilar qaytariladi.
    /// Ro'yxatda keltirilgan birinchi belgi "innermost function", oxirgi belgisi esa tashqi (oxirgi qo'ng'iroq qiluvchi).
    ///
    /// Shuni esda tutingki, agar ushbu ramka hal qilinmagan orqaga qaytishdan kelib chiqsa, u holda bo'sh ro'yxat qaytadi.
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` bilan bir xil
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` bilan bir xil
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` bilan bir xil
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` bilan bir xil
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` bilan bir xil
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Yo'llarni bosib chiqarishda, agar mavjud bo'lsa, biz cwd-ni echishga harakat qilamiz, aks holda biz yo'lni boricha bosib chiqaramiz.
        // E'tibor bering, biz buni faqat qisqa format uchun qilamiz, chunki agar u to'la bo'lsa, biz hamma narsani chop etishni xohlaymiz.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}