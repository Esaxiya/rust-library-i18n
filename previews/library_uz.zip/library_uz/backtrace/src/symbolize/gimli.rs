//! crates.io-da `gimli` crate yordamida ramziy belgilarni qo'llab-quvvatlash
//!
//! Bu Rust uchun standart belgini amalga oshirish.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // "Statik hayot-bu o'z-o'ziga murojaat qiladigan tuzilmalarni qo'llab-quvvatlamaslik uchun buzish uchun yolg'ondir.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // "Statik hayotga aylantiring, chunki ramzlar faqat `map` va `stash` qarzlarini olishlari kerak va biz ularni quyida saqlaymiz.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows-ga mahalliy kutubxonalarni yuklash uchun rust-lang/rust#71060-da turli xil strategiyalar uchun ba'zi munozaralarni ko'ring.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Hozirda MinGW kutubxonalari ASLR (rust-lang/rust#16514)-ni qo'llab-quvvatlamaydi, ammo DLL-lar hali ham manzil maydoniga ko'chirilishi mumkin.
            // Ko'rinib turibdiki, disk raskadrovka ma'lumotidagi manzillar, xuddi shu kutubxona uning COFF fayl sarlavhasidagi maydon bo'lgan "image base"-ga yuklangan bo'lsa.
            // Debuginfo ro'yxatiga o'xshash narsa bo'lgani uchun biz ramzlar jadvalini tahlil qilamiz va manzillarni kutubxona "image base" da yuklangan kabi saqlaymiz.
            //
            // Ammo kutubxonani "image base" da yuklash mumkin emas.
            // (ehtimol u erda yana bir narsa yuklanishi mumkinmi?) Bu erda `bias` maydoni o'ynaydi va biz bu erda `bias` qiymatini aniqlashimiz kerak.Afsuski, bu yuklangan moduldan qanday qilib olinishi aniq emas.
            // Ammo bizda haqiqiy yuk manzili (`modBaseAddr`).
            //
            // Hozircha biz bir oz to'xtab qolamiz, biz faylni mmap qilamiz, fayl sarlavhasi haqidagi ma'lumotlarni o'qiymiz, keyin mmapni tashlaymiz.Bu behuda, chunki biz mmapni keyinroq qayta ochamiz, ammo hozircha bu yaxshi ishlashi kerak.
            //
            // Bizda `image_base` (kerakli yuklanish joyi) va `base_addr` (haqiqiy yuk joylashuvi) mavjud bo'lganda, biz `bias` ni to'ldiramiz (haqiqiy va kerakli o'rtasidagi farq), keyin har bir segmentning ko'rsatilgan manzili `image_base` bo'ladi, chunki fayl shunday deydi.
            //
            //
            // Hozircha, ELF/MachO-dan farqli o'laroq, biz `modBaseSize`-dan butun hajmda foydalanib, bitta kutubxonada bitta segmentni bajarishimiz mumkin.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS Mach-O fayl formatidan foydalanadi va dasturning bir qismi bo'lgan mahalliy kutubxonalar ro'yxatini yuklash uchun DYLD-ga xos API-lardan foydalanadi.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Ushbu kutubxonaning nomini, uni yuklash joyiga mos keladigan tarzda oling.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Ushbu kutubxonaning rasm sarlavhasini yuklang va barcha yuk buyruqlarini tahlil qilish uchun `object`-ga topshiring, shunda biz bu erda ishtirok etgan barcha segmentlarni aniqlaymiz.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Segmentlar bo'yicha takrorlang va biz topgan segmentlar uchun ma'lum mintaqalarni ro'yxatdan o'tkazing.
            // Keyinchalik ishlov berish uchun matnli segmentlarni yozib oling, quyidagi sharhlarga qarang.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Ushbu kutubxona uchun "slide"-ni aniqlang, natijada biz xotira moslamalari qaerga yuklanganligini aniqlash uchun foydalanamiz.
            // Bu biroz g'alati hisoblash bo'lsa-da, tabiatda bir nechta narsalarni sinab ko'rish va nima yopishishini ko'rish natijasidir.
            //
            // Umumiy g'oya shundaki, `bias` va segmentning `stated_virtual_memory_address` haqiqiy manzil maydonida segment joylashgan joyda bo'ladi.
            // Biz ishonadigan yana bir narsa, bu `bias` minus haqiqiy manzil-bu ramzlar jadvalida va debuginfo-da qidirish uchun indeks.
            //
            // Tizimga yuklangan kutubxonalar uchun bu hisob-kitoblar noto'g'ri ekanligi ma'lum bo'ldi.Ammo mahalliy bajariladigan fayllar uchun bu to'g'ri ko'rinadi.
            // LLDB manbasidan mantiqni olib tashlash, 0 ofsetidan nolga teng bo'lmagan hajmda yuklangan birinchi `__TEXT` bo'limi uchun maxsus kassaga ega.
            // Bu mavjud bo'lgan har qanday sababga ko'ra ramzlar jadvali kutubxona uchun faqat vmaddr slaydiga nisbatan degan ma'noni anglatadi.
            // Agar u *yo'q* bo'lsa, unda belgilar jadvali vmaddr slaydiga va segmentning ko'rsatilgan manziliga nisbatan.
            //
            // Ushbu vaziyatni hal qilish uchun, agar biz nolga tenglashtirilgan fayl qismida matnli bo'limni topmasak, biz birinchi matn bo'limlari ko'rsatilgan manzilga tarafkashlikni oshiramiz va barcha ko'rsatilgan manzillarni ham shu miqdorga kamaytiramiz.
            //
            // Shunday qilib, ramzlar jadvali har doim kutubxonaning noaniq miqdoriga nisbatan paydo bo'ladi.
            // Bu ramzlar jadvali orqali ramziylashtirish uchun to'g'ri natijalarga ega ekan.
            //
            // Rostini aytsam, bu to'g'ri ekanligiga yoki buni qanday qilishni ko'rsatadigan boshqa biron narsaga ishonchim komil emas.
            // Hozircha bu (?) etarlicha ishlayotgani ko'rinib turibdi va agar kerak bo'lsa, biz uni vaqt o'tishi bilan har doim o'zgartira olamiz.
            //
            // Qo'shimcha ma'lumot uchun #318-ga qarang
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Boshqa Unix (masalan
        // Linux) platformalari ELF-dan ob'ekt fayli formati sifatida foydalanadi va odatda mahalliy kutubxonalarni yuklash uchun `dl_iterate_phdr` deb nomlangan API-ni amalga oshiradi.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` to'g'ri ko'rsatgich bo'lishi kerak.
        // `vec` `std::Vec` uchun to'g'ri ko'rsatgich bo'lishi kerak.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 aslida disk raskadrovka ma'lumotlarini qo'llab-quvvatlamaydi, lekin tuzish tizimi disk raskadrovka ma'lumotlarini `romfs:/debug_info.elf` yo'lida joylashtiradi.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Hammasi ELF-dan foydalanishi kerak, ammo mahalliy kutubxonalarni qanday yuklashni bilmaydi.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Yuklangan barcha ma'lum bo'lgan umumiy kutubxonalar.
    libraries: Vec<Library>,

    /// Xaritalar keshni ajratib turadi, bu erda biz mitti ma'lumotlarni tahlil qilamiz.
    ///
    /// Ushbu ro'yxat butun ko'tarilish vaqti uchun doimiy quvvatga ega va u hech qachon ko'paymaydi.
    /// Har bir juftlikning `usize` elementi yuqoridagi `libraries` indeksidir, bu erda `usize::max_value()` joriy bajariladigan faylni aks ettiradi.
    ///
    /// `Mapping` mos keluvchi mitti ma'lumotdir.
    ///
    /// Shuni esda tutingki, bu asosan LRU keshidir va biz manzillarni ramziy ma'noda atrofimizdagi narsalarni o'zgartiramiz.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Ushbu kutubxonaning segmentlari xotiraga yuklanadi va ular qaerda yuklanadi.
    segments: Vec<LibrarySegment>,
    /// Ushbu kutubxonaning "bias", odatda u xotiraga yuklangan joyda.
    /// Ushbu qiymat segmentga yuklangan haqiqiy virtual xotira manzilini olish uchun har bir segmentning ko'rsatilgan manziliga qo'shiladi.
    /// Bundan tashqari, bu xatolik haqiqiy virtual xotira manzillaridan debuginfo va belgilar jadvaliga indekslash uchun olib tashlanadi.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Ob'ekt faylidagi ushbu segmentning ko'rsatilgan manzili.
    /// Bu aslida segment yuklangan joyda emas, aksincha bu manzil va kutubxonaning `bias`-ni o'z ichiga oladi.
    ///
    stated_virtual_memory_address: usize,
    /// Xotiradagi th segmentining hajmi.
    len: usize,
}

// xavfli, chunki bu tashqi tomondan sinxronlashtirilishi kerak
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // xavfli, chunki bu tashqi tomondan sinxronlashtirilishi kerak
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Axborotni xaritalashni tuzatish uchun juda kichik, juda oddiy LRU kesh.
        //
        // Xit darajasi juda yuqori bo'lishi kerak, chunki odatiy to'plam ko'plab umumiy kutubxonalar o'rtasida o'tmaydi.
        //
        // `addr2line::Context` tuzilmalarini yaratish juda qimmat.
        // Keyingi `locate` so'rovlari bilan uning qiymati amortizatsiya qilinishi kutilmoqda, bu esa "addr2line: : Context`s" ni qurish paytida tuzilgan tuzilmalarni yaxshi tezlashtirishga imkon beradi.
        //
        // Agar bizda bu kesh bo'lmasa edi, bu amortizatsiya hech qachon yuz bermaydi va orqaga qaytishni ramziy ma'noda ssssllllooooowwww bo'lar edi.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Birinchidan, ushbu `lib`-da `addr` (ishlov berish joyini o'zgartirish) o'z ichiga olgan har qanday segment mavjudligini tekshirib ko'ring.Agar ushbu tekshiruv o'tgan bo'lsa, biz quyida davom etamiz va manzilni tarjima qilishimiz mumkin.
                //
                // Haddan tashqari tekshirilmaslik uchun biz bu erda `wrapping_add` dan foydalanamiz.Yovvoyi tabiatda SVMA + bias hisoblashi to'lib toshganligi ko'rinib turibdi.
                // Bu juda g'alati bo'lib tuyuladi, ammo biz bu segmentlarni e'tiborsiz qoldirishdan tashqari, bu borada juda ko'p narsa qila olmaymiz, chunki ular ehtimol kosmosga yo'naltirilgan.
                //
                // Bu dastlab rust-lang/backtrace-rs#329 da paydo bo'lgan.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Endi biz `lib` tarkibida `addr` mavjudligini bilamiz, biz ko'rsatilgan virusli xotira manzilini topish uchun xolislik bilan almashtirishimiz mumkin.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // O'zgarmas: bu shartli erta qaytmasdan bajariladi
        // xatolik tufayli ushbu yo'l uchun kesh yozuvi 0 indeksida.

        if let Some(idx) = idx {
            // Xaritalash allaqachon keshda bo'lsa, uni old tomonga o'tkazing.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Xaritalash keshda bo'lmaganida, yangi xaritani yarating, uni keshning old qismiga qo'ying va agar kerak bo'lsa, eng qadimgi kesh yozuvini chiqarib tashlang.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` umrini sızdırmayın, faqat o'zimizga tegishli ekanligiga ishonch hosil qiling
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // `sym`-ning ishlash muddatini `'static`-ga uzaytiring, chunki biz afsuski bu erda talab qilmoqdamiz, ammo bu doimo mos yozuvlar sifatida chiqadi, shuning uchun unga hech qanday ishora ushbu ramkadan tashqarida qolmasligi kerak.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Nihoyat, ushbu fayl uchun keshlangan xaritani oling yoki yangi xaritani yarating va ushbu manzil uchun file/line/name ni topish uchun DWARF ma'lumotlarini baholang.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Biz ushbu belgi uchun ramka ma'lumotlarini topa oldik va "addr2line" ramkasi ichki qismda barcha nozik detallarga ega.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Nosozliklarni tuzatuvchi ma'lumot topilmadi, lekin biz uni elf dasturining belgilar jadvalidan topdik.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}