// faqat hozirda Linux-da ishlatiladi, shuning uchun o'lik kodni boshqa joylarga ruxsat bering
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Bayt buferlari uchun oddiy arenani ajratuvchi.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Belgilangan hajmdagi buferni ajratadi va unga o'zgaruvchan mos yozuvlarni qaytaradi.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // XAVFSIZLIK: bu o'zgaruvchan qurilmani yaratadigan yagona funktsiya
        // `self.buffers`-ga havola.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // XAVFSIZLIK: biz hech qachon `self.buffers`-dan elementlarni olib tashlamaymiz, shuning uchun ma'lumotnoma
        // har qanday bufer ichidagi ma'lumotlarga `self` yashaguncha yashaydi.
        &mut buffers[i]
    }
}