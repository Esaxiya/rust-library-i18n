//! Libbacktrace-da DWARF-ajralish kodidan foydalangan holda simvollash strategiyasi.
//!
//! Odatda gcc bilan tarqatiladigan libbacktrace C kutubxonasi nafaqat orqaga qaytishni yaratishni qo'llab-quvvatlaydi (biz aslida foydalanmaymiz), shuningdek, orqaga qaytishni ramziy ma'noga ega va chizilgan ramkalar va boshqa narsalar kabi mitti disk raskadrovka ma'lumotlari bilan ishlash.
//!
//!
//! Bu erda juda ko'p turli xil muammolar tufayli nisbatan murakkab, ammo asosiy g'oya:
//!
//! * Avval biz `backtrace_syminfo` raqamiga qo'ng'iroq qilamiz.Imkoniyat bo'lsa, bu belgi haqida ma'lumotni dinamik belgilar jadvalidan oladi.
//! * Keyin biz `backtrace_pcinfo` raqamiga qo'ng'iroq qilamiz.Agar bu mavjud bo'lsa, disk raskadrovka jadvallarini tahlil qiladi va ichki freymlar, fayl nomlari, satr raqamlari va boshqalar haqida ma'lumotni tiklashga imkon beradi.
//!
//! Mittilar jadvallarini libbacktrace-ga jalb qilishda ko'plab hiyla-nayranglar mavjud, ammo umid qilamanki, bu dunyoning oxiri emas va quyida o'qiyotganda etarlicha aniq.
//!
//! Bu MSVC bo'lmagan va OSX bo'lmagan platformalar uchun standart ramziy strategiya.Libstd da, bu OSX uchun standart strategiya.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Iloji bo'lsa, debuginfo-dan kelib chiqadigan va masalan, ichki freymlar uchun aniqroq bo'lishi mumkin bo'lgan `function` nomini afzal ko'rsating.
                // Agar u mavjud bo'lmasa, `symname`-da ko'rsatilgan jadvallar jadvalining nomiga qaytib boring.
                //
                // Shuni esda tutingki, ba'zida `function` biroz kamroq aniqlikni sezishi mumkin, masalan, `std::panicking::try::do_call` ning `try<i32,closure>` o'rniga kiritilmagan.
                //
                // Nima uchun bu aniq emas, lekin umuman `function` nomi aniqroq ko'rinadi.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // hozircha hech narsa qilmang
}

/// `syminfo_cb` ga o'tgan `data` ko'rsatkichining turi
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Ushbu qayta qo'ng'iroq `backtrace_syminfo`-dan biz hal qilishni boshlaganimizda chaqirilgandan so'ng, biz `backtrace_pcinfo`-ga qo'ng'iroq qilish uchun boramiz.
    // `backtrace_pcinfo` funktsiyasi disk raskadrovka ma'lumotlarini ko'rib chiqadi va file/line ma'lumotlarini tiklash bilan bir qatorda chizilgan ramkalar bilan shug'ullanishga harakat qiladi.
    // Shuni esda tutingki, disk raskadrovka haqida ma'lumot bo'lmasa, `backtrace_pcinfo` ishlamay qolishi mumkin yoki juda ko'p ish qila olmaydi, shuning uchun agar biz shunday bo'lsa, biz qayta qo'ng'iroqni `syminfo_cb` dan kamida bitta belgi bilan chaqiramiz.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `pcinfo_cb` ga o'tgan `data` ko'rsatkichining turi
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API holat yaratishni qo'llab-quvvatlaydi, lekin holatni yo'q qilishni qo'llab-quvvatlamaydi.
// Men shaxsan buni davlatni yaratish va keyin abadiy yashash uchun mo'ljallangan degan ma'noni anglatadi.
//
// Ushbu holatni tozalaydigan at_exit() ishlov beruvchisini ro'yxatdan o'tkazishni juda xohlardim, lekin libbacktrace buni amalga oshirishga imkon bermaydi.
//
// Ushbu cheklovlar bilan ushbu funktsiya birinchi marta so'ralganda hisoblanadigan statik keshlangan holatga ega.
//
// Backtracing hammasi ketma-ket sodir bo'lishini unutmang (bitta global qulf).
//
// E'tibor bering, bu erda sinxronizatsiya etishmasligi `resolve` tashqi sinxronlashtirilishi talabidan kelib chiqadi.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Libbacktrace-ning threadsafe imkoniyatlaridan foydalanmang, chunki biz uni doimo sinxronlashtirilgan tarzda chaqiramiz.
        //
        0,
        error_cb,
        ptr::null_mut(), // qo'shimcha ma'lumot yo'q
    );

    return STATE;

    // Libbacktrace umuman ishlashi uchun joriy bajariladigan dastur uchun DWARF disk raskadrovka ma'lumotlarini topishi kerakligini unutmang.Odatda buni bir qator mexanizmlar orqali amalga oshiriladi, lekin quyidagilar bilan cheklanmasdan:
    //
    // * /proc/self/exe qo'llab-quvvatlanadigan platformalarda
    // * Vaziyatni yaratishda fayl nomi aniq berilgan
    //
    // Libbacktrace kutubxonasi-bu C kodining katta to'plami.Bu, albatta, xotira xavfsizligi zaifliklarini anglatadi, ayniqsa noto'g'ri tuzatilgan debuginfo bilan ishlashda.
    // Libstd tarixiy jihatdan bularning ko'pchiligiga duch keldi.
    //
    // Agar /proc/self/exe ishlatilsa, biz odatda bularni e'tiborsiz qoldirishimiz mumkin, chunki biz libbacktrace "mostly correct" deb hisoblaymiz va aks holda "attempted to be correct" mitti disk raskadrovka ma'lumotlari bilan g'alati ishlarni qilmaydi.
    //
    //
    // Agar biz fayl nomiga o'tsak, zararli aktyor o'sha joyga o'zboshimchalik bilan fayl joylashishiga olib kelishi mumkin bo'lgan ba'zi platformalarda (masalan, BSD-larda) mumkin.
    // Bu shuni anglatadiki, agar biz libbacktrace-ga fayl nomi haqida gapiradigan bo'lsak, u o'zboshimchalik bilan fayldan foydalanishi mumkin, ehtimol segfaults sabab bo'lishi mumkin.
    // Agar biz libbacktrace-ga hech narsa demasak, u holda /proc/self/exe kabi yo'llarni qo'llab-quvvatlamaydigan platformalarda hech narsa bo'lmaydi!
    //
    // Fayl nomiga o'tmaslik uchun * iloji boricha ko'proq harakat qilayotganimizni hisobga olsak ham, /proc/self/exe ni umuman qo'llab-quvvatlamaydigan platformalarda bo'lishimiz kerak.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Shuni yodda tutingki, biz ideal ravishda `std::env::current_exe` dan foydalanamiz, ammo bu erda `std` talab qilinmaydi.
            //
            // Joriy bajariladigan yo'lni statik maydonga yuklash uchun `_NSGetExecutablePath`-dan foydalaning (agar u juda kichik bo'lsa, shunchaki voz keching).
            //
            //
            // Shuni esda tutingki, biz bu erda libbacktrace-ga buzilgan bajariladigan fayllarda o'lmaslik uchun jiddiy ishonamiz, ammo bu albatta ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows fayllarni ochish rejimiga ega, u ochilgandan so'ng uni o'chirib bo'lmaydi.
            // Umuman olganda biz bu erda nimani xohlaymiz, chunki biz o'zboshimchalik bilan ma'lumotlarni libbacktrace-ga o'tkazish qobiliyatini kamaytirgan holda libbacktrace-ga topshirgandan so'ng bizning bajariladigan dasturimiz ostimizdan o'zgarmasligini ta'minlashni xohlaymiz (bu noto'g'ri ishlatilishi mumkin).
            //
            //
            // Biz o'z imijimizga qandaydir qulf tushirish uchun bu erda bir oz raqsga tushganimizni hisobga olsak:
            //
            // * Joriy jarayon bilan tanishib chiqing, uning fayl nomini yuklang.
            // * Faylni ushbu fayl nomiga o'ng bayroqlar bilan oching.
            // * Amaldagi jarayonning fayl nomini qayta yuklang, uning bir xil ekanligiga ishonch hosil qiling
            //
            // Agar bularning barchasi amalga oshirilsa, biz nazariy jihatdan bizning jarayonimiz faylini ochganmiz va u o'zgarmasligiga kafolat beramiz.FWIW bularning bir qismi tarixiy ravishda libstd-dan ko'chirilgan, shuning uchun bu nima bo'layotganini mening eng yaxshi talqin qilishim.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Bu statik xotirada yashaydi, shuning uchun uni qaytarishimiz mumkin ..
                static mut BUF: [i8; N] = [0; N];
                // ... va bu vaqtincha bo'lgani uchun stackda yashaydi
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // bu erda qasddan `handle`-ni chiqarib yuboradi, chunki u ochiq bo'lsa, ushbu fayl nomidagi qulfimiz saqlanib qoladi.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Biz bekor qilingan bo'lakni qaytarishni istaymiz, shuning uchun agar hamma to'ldirilgan bo'lsa va u umumiy uzunlikka teng bo'lsa, uni muvaffaqiyatsizlikka tenglashtiramiz.
                //
                //
                // Aks holda muvaffaqiyatni qaytarishda nul baytning tilimga kiritilganligiga ishonch hosil qiling.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace xatolar hozirda gilam ostida supurilgan
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API-ga qo'ng'iroq qiling (kodni o'qishdan boshlab) `syminfo_cb`-ni to'liq bir marta chaqirishi kerak (yoki xato bilan ishlamay qolishi mumkin).
    // Keyinchalik biz `syminfo_cb` ichida ko'proq ishlaymiz.
    //
    // Shuni esda tutingki, `syminfo` ikkilikda disk raskadrovka ma'lumotlari bo'lmasa ham, belgilar nomlarini topib, ramzlar jadvaliga murojaat qiladi.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}