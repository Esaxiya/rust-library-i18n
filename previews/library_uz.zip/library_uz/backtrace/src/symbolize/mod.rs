use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Belgini belgilangan yopilishga o'tkazib, manzilni belgiga hal qiling.
///
/// Ushbu funktsiya hosil bo'ladigan belgilarni topish uchun ushbu manzilni mahalliy belgilar jadvali, dinamik belgilar jadvali yoki DWARF disk raskadrovka ma'lumotlari (faollashtirilgan dasturga qarab) kabi joylarda qidiradi.
///
///
/// Agar rezolyutsiya bajarilmasa, yopilish chaqirilmasligi mumkin, shuningdek, chizilgan funktsiyalarda bir necha marta chaqirilishi mumkin.
///
/// Olingan ramzlar belgilangan `addr`-da bajarilishini anglatadi va ushbu manzil uchun file/line juftlarini qaytaradi (agar mavjud bo'lsa).
///
/// Agar sizda `Frame` bo'lsa, u holda `resolve_frame` funktsiyasidan foydalanish tavsiya etiladi.
///
/// # Kerakli xususiyatlar
///
/// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
///
/// # Panics
///
/// Ushbu funktsiya hech qachon panic-ga intilmaydi, lekin agar `cb` panics-ni taqdim qilsa, u holda ba'zi platformalar bu jarayonni bekor qilishga panic-ni ikki baravar majbur qiladi.
/// Ba'zi platformalar C kutubxonasidan foydalanadi, u qo'ng'iroqlarni qaytarib bo'lmaydigan tarzda ishlatadi, shuning uchun `cb` dan vahima tushishi jarayonni to'xtatishi mumkin.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // faqat yuqori ramkaga qarang
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Belgilangan yopilishga qadar belgini uzatib, ilgari suratga olish ramkasini belgilang.
///
/// Ushbu funktsiya `resolve` bilan bir xil funktsiyani bajaradi, faqat manzil o'rniga argument sifatida `Frame` oladi.
/// Bu backtracing-ning ba'zi platformaviy dasturlarida, masalan, ramzlar haqida aniqroq ma'lumot yoki ichki ramkalar haqida ma'lumot berishga imkon beradi.
///
/// Imkoningiz bo'lsa, undan foydalanish tavsiya etiladi.
///
/// # Kerakli xususiyatlar
///
/// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
///
/// # Panics
///
/// Ushbu funktsiya hech qachon panic-ga intilmaydi, lekin agar `cb` panics-ni taqdim qilsa, u holda ba'zi platformalar bu jarayonni bekor qilishga panic-ni ikki baravar majbur qiladi.
/// Ba'zi platformalar C kutubxonasidan foydalanadi, u qo'ng'iroqlarni qaytarib bo'lmaydigan tarzda ishlatadi, shuning uchun `cb` dan vahima tushishi jarayonni to'xtatishi mumkin.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // faqat yuqori ramkaga qarang
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Stek ramkalaridagi IP-qiymatlar, odatda, bu stack haqiqiy izi bo'lgan qo'ng'iroqdan keyin *buyrug'i*(always?).
// Buni ramzlash filename/line raqamini oldinda bo'lishiga olib keladi va ehtimol funktsiya tugashiga yaqin bo'lsa.
//
// Bu asosan har doim ham barcha platformalarda bo'lishi mumkin, shuning uchun biz qaytarilgan buyruq o'rniga oldingi qo'ng'iroq ko'rsatmasiga hal qilish uchun har doim echilgan ipdan birini chiqaramiz.
//
//
// Ideal holda biz buni qilmas edik.
// Ideal holda biz `resolve` API-laridan qo'ng'iroq qiluvchilardan -1-ni qo'lda bajarishni talab qilamiz va ular joriy emas, balki *oldingi* buyrug'i uchun joylashuv ma'lumotlarini xohlashlarini hisobga olamiz.
// Ideal holda, agar biz haqiqatan ham keyingi ko'rsatmaning manzili yoki joriy bo'lsa, biz `Frame`-ga ta'sir qilamiz.
//
// Hozircha bu juda yaxshi joy tashvishi bo'lsa-da, shuning uchun biz faqat ichki sifatida har doim uni olib tashlaymiz.
// Iste'molchilar ishlashda davom etishi va juda yaxshi natijalarga erishishlari kerak, shuning uchun biz etarlicha yaxshi bo'lishimiz kerak.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` bilan bir xil, faqat sinxronlashtirilmaganligi sababli xavfli.
///
/// Ushbu funktsiya sinxronizatsiya kafolatiga ega emas, lekin ushbu crate ning `std` xususiyati to'planmaganida mavjud bo'ladi.
/// Qo'shimcha hujjatlar va misollar uchun `resolve` funktsiyasini ko'ring.
///
/// # Panics
///
/// `cb` panikasida ogohlantirishlar haqida `resolve` ma'lumotlarini ko'ring.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` bilan bir xil, faqat sinxronlashtirilmaganligi sababli xavfli.
///
/// Ushbu funktsiya sinxronizatsiya kafolatiga ega emas, lekin ushbu crate ning `std` xususiyati to'planmaganida mavjud bo'ladi.
/// Qo'shimcha hujjatlar va misollar uchun `resolve_frame` funktsiyasini ko'ring.
///
/// # Panics
///
/// `cb` panikasida ogohlantirishlar haqida `resolve_frame` ma'lumotlarini ko'ring.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Faylda belgining o'lchamlarini ifodalovchi trait.
///
/// Ushbu trait trait ob'ekti sifatida `backtrace::resolve` funktsiyasining yopilishiga olib keladi va deyarli amalga oshiriladi, chunki uning orqasida qaysi dastur turganligi noma'lum.
///
///
/// Belgida funktsiya haqida kontekstli ma'lumot bo'lishi mumkin, masalan, ism, fayl nomi, satr raqami, aniq manzil va hk.
/// Barcha ma'lumotlar har doim ham belgida mavjud emas, shuning uchun barcha usullar `Option`-ni qaytaradi.
///
///
pub struct Symbol {
    // TODO: bu umr bo'yi `Symbol`-ga qadar davom etishi kerak,
    // ammo bu hozirda keskin o'zgarish.
    // Hozircha bu xavfsizdir, chunki `Symbol` faqat ma'lumotnomada tarqatiladi va klonlash mumkin emas.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Ushbu funktsiya nomini qaytaradi.
    ///
    /// Qaytgan strukturadan ramz nomi haqida turli xil xususiyatlarni so'rash uchun foydalanish mumkin:
    ///
    ///
    /// * `Display` dasturi buzilgan belgini chop etadi.
    /// * Belgining xom `str` qiymatiga kirish mumkin (agar u yaroqli utf-8 bo'lsa).
    /// * Belgilar nomi uchun xom baytlarga kirish mumkin.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Ushbu funktsiyaning boshlang'ich manzilini qaytaradi.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Fayl nomini tilim sifatida qaytaradi.
    /// Bu asosan `no_std` muhitlari uchun foydalidir.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Ushbu belgi hozirda bajarilayotgan joy uchun ustun raqamini qaytaradi.
    ///
    /// Faqatgina gimli hozirda bu erda qiymatni beradi va hatto `filename` `Some` ni qaytargan taqdirda ham, shunga o'xshash ogohlantirishlarga bo'ysunadi.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Ushbu belgi hozirda bajarilayotgan satr raqamini qaytaradi.
    ///
    /// Ushbu qaytarish qiymati odatda `filename`, agar `filename` `Some` ni qaytarsa va shunga o'xshash ogohlantirishlarga bo'ysunadi.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Ushbu funktsiya aniqlangan fayl nomini qaytaradi.
    ///
    /// Bu hozirda faqat libbacktrace yoki gimli ishlatilganda mavjud (masalan,
    /// unix boshqa platformalar) va ikkilik debuginfo bilan tuzilganda.
    /// Agar ushbu shartlarning hech biri bajarilmasa, u holda `None` qaytadi.
    ///
    /// # Kerakli xususiyatlar
    ///
    /// Ushbu funktsiya `backtrace` crate ning `std` xususiyatini yoqishni talab qiladi va `std` xususiyati sukut bo'yicha yoqilgan.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Ehtimol, ajratilgan C++ belgisi, agar manfur belgini Rust sifatida tahlil qilish muvaffaqiyatsiz tugagan bo'lsa.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // `cpp_demangle` xususiyati o'chirilganda hech qanday xarajat qilmasligi uchun, bu nol o'lchamdagi o'lchamlarga ega ekanligiga ishonch hosil qiling.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Belgilar nomiga o'ralgan o'rash, demanglangan ismga, xom baytlarga, xom qatorga va boshqalarga ergonomik kiruvchi vositalarni taqdim etadi.
///
// `cpp_demangle` xususiyati yoqilmagan bo'lsa, o'lik kodga ruxsat bering.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Xom asosiy baytlardan yangi belgi nomini yaratadi.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// X001 haqiqiy qiymati bo'lsa, (mangled) belgisi nomini `str` sifatida qaytaradi.
    ///
    /// Agar siz demangled versiyasini xohlasangiz, `Display` dasturidan foydalaning.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Xom simvol nomini baytlar ro'yxati sifatida qaytaradi
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Agar buzilgan belgi aslida yaroqsiz bo'lsa, bu chop etilishi mumkin, shuning uchun bu erda xatoni tashqi tomonga yoyib yubormang.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Manzillarni ramzlash uchun ishlatiladigan keshlangan xotirani qaytarib olishga urinish.
///
/// Ushbu usul, aks holda butun dunyo bo'ylab keshlangan yoki odatda ajratilgan DWARF ma'lumotlarini yoki shunga o'xshashlarni ifodalaydigan barcha global ma'lumotlar tuzilmalarini chiqarishga harakat qiladi.
///
///
/// # Caveats
///
/// Ushbu funktsiya doimo mavjud bo'lsa-da, aksariyat dasturlarda hech narsa qilmaydi.
/// Dbghelp yoki libbacktrace kabi kutubxonalar holatni taqsimlash va ajratilgan xotirani boshqarish uchun imkoniyat yaratmaydi.
/// Hozircha ushbu crate-ning `gimli-symbolize` xususiyati bu funktsiya har qanday ta'sir ko'rsatadigan yagona xususiyatdir.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}