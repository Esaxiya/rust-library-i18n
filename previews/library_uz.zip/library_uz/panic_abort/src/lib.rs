//! Jarayonni bekor qilish orqali Rust panics dasturini amalga oshirish
//!
//! Ochilish orqali amalga oshirish bilan taqqoslaganda, bu crate *juda* oddiyroq!Aytish joizki, bu unchalik ko'p qirrali emas, lekin mana shu narsa!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" ushbu platformadagi tegishli abortga foydali yuk va shim.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal raqamiga qo'ng'iroq qiling
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows-da, protsessorga xos __fastfail mexanizmidan foydalaning.Windows 8 va undan keyingi versiyalarida, bu jarayonni hech qanday istisno ishlovchilarini ishlatmasdan darhol to'xtatadi.
            // Windows-ning oldingi versiyalarida ushbu ko'rsatmalar ketma-ketligi kirishni buzish sifatida ko'rib chiqiladi, bu jarayonni to'xtatadi, lekin barcha istisno ishlovchilarini chetlab o'tmasdan.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: bu libstd ning `abort_internal`-dagi kabi bir xil dastur
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Bu ... biroz g'alati.Tl; dr;bu to'g'ri bog'lanish uchun talab qilinadi, uzoqroq tushuntirish quyida keltirilgan.
//
// Hozir biz yuboradigan libcore/libstd ikkilik fayllari barchasi `-C panic=unwind` bilan tuzilgan.Bu ikkilik fayllarni iloji boricha ko'proq holatlarga maksimal darajada mos kelishini ta'minlash uchun qilingan.
// Biroq, kompilyator `-C panic=unwind` bilan tuzilgan barcha funktsiyalar uchun "personality function" talab qiladi.Ushbu shaxsiy funktsiya `rust_eh_personality` belgisiga qattiq kodlangan va `eh_personality` til elementi bilan belgilanadi.
//
// So...
// nima uchun bu erda faqat ushbu lang elementini aniqlamaysiz?Yaxshi savol!panic ish vaqtlarini bog'lash usuli, aslida "sort of" kompilyatorning crate do'konidagi "sort of" ekanligi bilan bog'liq, ammo agar aslida boshqasi bog'lanmagan bo'lsa, aslida bog'langan.
//
// Buning ma'nosi shuki, crate ham, panic_unwind crate ham kompilyatorning crate do'konida paydo bo'lishi mumkin va agar ikkalasi ham `eh_personality` lang elementini aniqlasa, u holda xato bo'ladi.
//
// Ushbu kompilyatorni boshqarish uchun faqat 0panic ish vaqti ulanadigan ish vaqti bo'lsa, `eh_personality` aniqlanadi, aks holda uni aniqlash talab qilinmaydi (haqli ravishda).
// Ammo bu holda, ushbu kutubxona ushbu belgini belgilaydi, shuning uchun biror joyda hech bo'lmaganda ba'zi bir shaxslar mavjud.
//
// Aslida ushbu belgi faqat libcore/libstd ikkilikka ulanish uchun aniqlangan, ammo biz uni hech qachon chaqirmasligimiz kerak, chunki biz bo'shashgan ish vaqti bilan bog'lanmaymiz.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // X86_64-pc-windows-gnu-da biz `ExceptionContinueSearch`-ni qaytarishimiz kerak bo'lgan shaxsiy funktsiyamizdan foydalanamiz, chunki biz barcha ramkalarni uzatmoqdamiz.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Yuqoridagi kabi, bu hozirda faqat Emscripten-da ishlatiladigan `eh_catch_typeinfo` lang elementiga mos keladi.
    //
    // panics istisnolarni yaratmagani uchun va chet el istisnolari hozirda -C panic=bekor qilish bilan UB (garchi bu o'zgarishi mumkin bo'lsa ham), har qanday catch_unwind qo'ng'iroqlari hech qachon ushbu turdagi ma'lumotlardan foydalanmaydi.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Ushbu ikkitasini i686-pc-windows-gnu-dagi boshlang'ich ob'ektlarimiz chaqiradi, lekin ular hech narsa qilishlari shart emas, shuning uchun tanalar nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}