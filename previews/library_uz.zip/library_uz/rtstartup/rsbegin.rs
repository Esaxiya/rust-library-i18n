// rsbegin.o va rsend.o "compiler runtime startup objects" deb ataladi.
// Ular tarkibida kompilyator ish vaqtini to'g'ri boshlash uchun zarur bo'lgan kod mavjud.
//
// Bajariladigan yoki dylib rasm bog'langanida, barcha foydalanuvchi kodlari va kutubxonalari ushbu ikkita ob'ekt fayli o'rtasida "sandwiched" bo'ladi, shuning uchun kod yoki rsbegin.o ma'lumotlari rasmning tegishli qismlarida birinchi bo'lib, kod va rsend.o ma'lumotlari esa oxirgisi bo'ladi.
// Ushbu effekt qismning boshida yoki oxirida belgilarni joylashtirish uchun, shuningdek, kerakli sarlavhalar yoki altbilgilarni kiritish uchun ishlatilishi mumkin.
//
// Shuni esda tutingki, modulning haqiqiy kirish nuqtasi C ish vaqti boshlanishida joylashgan (odatda `crtX.o` deb nomlanadi), u keyinchalik boshqa ish vaqti komponentlarini ishga tushirish chaqiruvlarini chaqiradi (yana bir maxsus rasm bo'limi orqali ro'yxatdan o'tgan).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Stek ramkasining ochilishi haqida ma'lumot qismining boshlanishi
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Kiruvchilarning ichki buxgalteriya hisobini yuritish uchun bo'sh joy.
    // Bu $ GCC/unwind-dw2-fde.h da `struct object` sifatida aniqlanadi.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // registration/deregistration tartiblarini oching.
    // Libpanic_unwind hujjatlariga qarang.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // modulni ishga tushirish to'g'risida ochilgan ma'lumotni ro'yxatdan o'tkazing
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // o'chirish paytida ro'yxatdan o'tishni bekor qilish
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-ga xos init/uninit muntazam ro'yxatdan o'tish
    pub mod mingw_init {
        // MinGW-ning boshlang'ich ob'ektlari (crt0.o/dllcrt0.o) .ctors va .dtors bo'limlarida global konstruktorlarni ishga tushirish va chiqishda chaqiradi.
        // DLL-larda bu DLL yuklanganda va tushirilganda amalga oshiriladi.
        //
        // Bog'lovchi bo'limlarni saralaydi, bu bizning qo'ng'iroqlarimiz ro'yxatning oxirida joylashganligini ta'minlaydi.
        // Konstruktorlar teskari tartibda ishga tushirilganligi sababli, bu bizning qayta qo'ng'iroqlarimiz birinchi va oxirgi bajarilishini ta'minlaydi.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: S boshlashni qayta chaqirish
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C tugatish bilan qayta qo'ng'iroqlar
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}