use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Sui o le umiaina ma le oe lava i tua.
///
/// O lenei fausaga mafai ona faʻaaogaina e puʻeina ai le tua i itu eseese i se polokalama ma mulimuli ane faʻaaoga e asiasia le mea sa i tua i lena taimi.
///
///
/// `Backtrace` lagolagoina aulelei-lolomiga o backtraces ala i lona `Debug` faʻatinoina.
///
/// # Manaʻomia foliga vaaia
///
/// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // O fausaga iinei e lisiina mai luga-i-lalo o le faaputuga
    frames: Vec<BacktraceFrame>,
    // Le faasino upu tatou te talitonu o le amataga moni o le backtrace, aveesea o le faavaa e pei `Backtrace::new` ma `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Faʻamatalaga puʻeina o se faʻavaʻa i tua i tua.
///
/// O lenei ituaiga ua toe faʻafoʻi mai o se lisi mai `Backtrace::frames` ma fai ma sui o le tasi faʻatulaga faʻavaʻa i totonu o se puʻeina tua.
///
/// # Manaʻomia foliga vaaia
///
/// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Faatoʻilaloina lomiga o se faatusa i se backtrace.
///
/// Lenei ituaiga ua toe faʻafoʻi mai o se lisi mai `BacktraceFrame::symbols` ma fai ma sui o metadata mo se faʻailoga i tua o le tua.
///
/// # Manaʻomia foliga vaaia
///
/// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Maua se tua i tua i le callsite o lenei galuega, faʻafoʻi mai e ona sui.
    ///
    /// O lenei gaioiga e aoga mo le fai ma sui o tua i tua o se mea i le Rust.Lenei toe faʻafoi taua mafai ona lafoina i luga o filo ma lolomiina i se isi mea, ma o le mafuaʻaga o lenei taua o le na o ia lava atoa.
    ///
    /// Manatua o luga o nisi tulaga faʻatutuina mauaina se atoa backtrace ma foʻia ai e mafai ona sili ona taugata.
    /// Afai o le tau e tele naua mo lau talosaga ua fautuaina ia faʻaoga `Backtrace::new_unresolved()` e aloese ai mai le faʻaiuga faʻasolosolo sitepu (lea e masani ona umi se taimi) ma faʻatagaina le tolopoina o lena i se taimi mulimuli ane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // manaʻo ia mautinoa o loʻo i ai se faʻavaʻa iinei e aveʻese
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Tutusa i le `new` seʻi vagana o lenei e le fofoina ni faʻailoga, e na o le puʻeina o le backtrace o se lisi o tuatusi.
    ///
    /// I se taimi mulimuli ane o le `resolve` gaioiga mafai ona valaʻauina e foʻia lenei backtrace's faʻailoga i faitauga igoa.
    /// O lenei gaioiga e i ai ona o le iugafono gaioiga mafai i nisi taimi ona tele se aofaʻi o taimi ae o soʻo se backtrace mafai ona seasea lomia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // leai ni igoa faʻailoga
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // igoa igoa i le taimi nei
    /// ```
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    ///
    ///
    #[inline(never)] // manaʻo ia mautinoa o loʻo i ai se faʻavaʻa iinei e aveʻese
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Faʻafoʻi ia faʻavaʻa mai le taimi na puʻeina ai lenei backtrace.
    ///
    /// Le ulufale muamua o lenei fasi e ono o le galuega tauave `Backtrace::new`, ma o le tino e gata ai o se mea e ono e uiga i le auala e amata lenei filo po o le galuega tauave autu.
    ///
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Afai o lenei backtrace na faia mai `new_unresolved` o lenei galuega o le a foia uma tuatusi i le tua i tua io latou igoa faʻatusa.
    ///
    ///
    /// Afai o lenei backtrace na maeʻa muamua pe na faia e ala i `new`, o lenei gaioiga e leai se mea.
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Tutusa ma `Frame::ip`
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Tutusa ma `Frame::symbol_address`
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Tutusa ma `Frame::module_base_address`
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Faʻafoʻi mai le lisi o faʻailoga o loʻo faʻatatau i ai le faʻavaʻa lea.
    ///
    /// Masani na o le tasi le faʻailoga i le faʻavaʻa, ae o nisi taimi pe a fai o se numera o galuega e oʻo atu i totonu o le tasi faʻavae ona tele faʻailoga o le a toe faʻafoʻi mai.
    /// O le muamua faʻailoga lisiina o le "innermost function", ae o le mulimuli faʻailoga o le pito i fafo (mulimuli valaʻau).
    ///
    /// Manatua afai o lenei faʻavaʻa na sau mai i tua le faʻavasegaina tua ona o lenei o le a toe faafoi mai se avanoa avanoa.
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Tutusa ma `Symbol::name`
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Tutusa ma `Symbol::addr`
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Tutusa ma `Symbol::filename`
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Tutusa ma `Symbol::lineno`
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Tutusa ma `Symbol::colno`
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // A lolomiina auala matou te taumafai e toso ese le cwd peʻa iai, a leai e na ona matou lolomiina o le auala pei ona i ai.
        // Manatua matou te faia foi lenei mo le puʻupuʻu foliga, aua afai e tumu matou ono manaʻo e lolomi mea uma.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}