use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr aveina se callback o le a mauaina se dl_phdr_info faʻasino faasino mo DSO uma na fesoʻotaʻi atu i le gaioiga.
    // dl_iterate_phdr mautinoa foʻi o loʻo lokaina le soʻotaga fesoʻotaʻi mai le amataga e oʻo i le faʻaiuga o le faʻamatalaga.
    // A faʻapea o le callback faʻafoʻi mai le leai-zero aoga o le faʻavasegaina e vave faamutaina.
    // 'data' o le a pasia o le lona tolu finauga i le callback i valaʻau taʻitasi.
    // 'size' aumaia le tele o le dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Matou te manaʻomia le faʻamavaeina o le fausiaina ID ma ni faʻavae autu o faʻamatalaga o ulutala o lona uiga tatou te manaʻomia foʻi ni mea mai le ELF spec.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Lenei ua tatau ona tatou toe faʻataʻitaʻi, siʻi mo sina mea, le fausaga o le dl_phdr_info ituaiga na faʻaaogaina e le fuchsia o loʻo iai nei fesoʻotaʻiga malosi.
// Chromium o loʻo iai foʻi le tuaoi o le ABI faʻapea foi ma le crashpad.
// E iai taimi matou te manaʻo ai e faʻaseʻe ia mataupu e faʻaaoga ai le elf-search ae e manaʻomia ona tuʻuina atu i le SDK ma e leʻi maeʻa.
//
// O lea matou (ma latou) o loʻo pipii i le faʻaaogaina o lenei metotia lea e mafua ai se fusi fesoʻotaʻi ma le fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // E leai se matou auala e iloa ai le siakiina pe o e_phoff ma e_phnum e aoga.
    // E tatau ona faʻamautinoa mai e le libc lenei mea mo i tatou peitaʻi o lea e sefe ai se fasi mea ii.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// O le Elf_Phdr o loʻo fai ma sui o le polokalame o le ELF e 64-bit i le faʻaiuga o le tusiata fale.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// faatusa Phdr a aloaia polokalame ELF header ma ona anotusi.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // E leai se matou auala e siaki ai pe aoga ia p_addr poʻo p_memsz.
    // O le libc a Fuchsia o loʻo faʻamauina muamua ia faʻamaumauga, peitaʻi o le mea lea o le iai iinei o nei ulutala e tatau ona aoga.
    //
    // E le manaʻomia e le NoteIter le faʻavae o faʻamatalaga ia aoga ae e manaʻomia le saʻo o tuaoi.
    // Matou te talitonu o le libc ua faamautinoaina o le tulaga lea mo matou iinei.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// O le ituaiga tusi mo le fausiaina o ID.
const NT_GNU_BUILD_ID: u32 = 3;

// faatusa Elf_Nhdr se header faamatalaga ELF i le endianness o le sini.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// O le faʻailoga e fai ma sui o le ELF note (header + mea).
// O le igoa e tuʻu o se u8 fasi ona e le masani ona faʻamutaina ma rust e faʻafaigofie lava e siaki pe faʻafetaui ia paita.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter faatagaina oe ma le saogalemu iterate i luga o se vaega e tusi.
// E faʻamutaina i le taimi lava e tupu ai se mea sese pe leai foi ni isi tusi.
// Afai e te iterate luga le saʻo faʻamaumauga o le a galue e pei o leai ni faʻamatalaga na maua.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // O se invariant o gaioiga o le faʻasino tusi ma le tele na tuʻuina mai faʻailoa mai se lelei tele o bytes e mafai ona faitauina uma.
    // O mea o loʻo iai i totonu bytes e mafai ona avea ma se mea, ae o le lautele e tatau ona aoga mo lenei mea ina ia sefe.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligns 'x' e 'to'-byte gatasi le faalialiavale 'to' o se mana o le 2.
// E mulimuli lea ile faʻavae masani ile C/C ++ ELF parsing code lea (x + to, 1)&-to e faʻaaogaina.
// E le faʻatagaina oe e le Rust ona faʻataʻitaʻia le faʻaaogaina o le mea lea ou te faʻaaogaina ai
// 2's-faʻafouina liuaina e toe faia lena.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// ave_bytes_align4 faʻaumatia num bytes mai le fasi (pe a fai o iai) ma faʻaopopo faʻamautinoa o le faʻasologa mulimuli e fetaui lelei.
// Afai o le a le o le numera o bytes talosagaina tele tele pe o le fasi e le mafai ona toefaʻailogaina mulimuli ane ona o le le lava totoe bytes o loʻo i ai, E leai se mea e toe faʻafoi mai ma le fasi e le toe faʻaleleia.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Lenei gaioiga e leai ni moni invariants le telefoni mai tatau ona lagolagoina isi nai lo le atonu o le 'bytes' tatau ona faʻatulagaina mo le faʻatinoina (ma luga o nisi tusiata fale saʻo).
// O le taua i le fanua Elf_Nhdr atonu e leai se aoga ae o lenei gaioiga mautinoa leai se mea faapena.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // E sefe le mea lea pe a lava e lava le avanoa ma e na ona matou faʻamautinoaina i le pe a fai o le faʻamatalaga luga o lea e le tatau ona le saogalemu.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Manatua le sice_of: :<Elf_Nhdr>() e faʻatulagaina i taimi uma le 4-byte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Siaki pe ua tatou oʻo i le iʻuga.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Tatou transmute mai se nhdr ae tatou mafaufau ma le faaeteete le fausia mafua.
        // Matou te le faʻatuatuaina le namesz poʻo le descsz ma matou te le faia se filifiliga le faʻavae e fuafua i le ituaiga.
        //
        // O lea la, e tusa lava pe tatou te maua mai lapisi atoatoa e tatau ona tatou saogalemu pea.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Faʻailoa o se vaega e mafai ona faʻaaogaina.
const PERM_X: u32 = 0b00000001;
/// Faʻailoa o se vaega e mafai ona tusitusi.
const PERM_W: u32 = 0b00000010;
/// Faʻailoa o se vaega e mafai ona faitauina.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Faʻaalia se vaega o le ELF i taimi e alu ai.
struct Segment {
    /// Tuʻuina atu i le taimi nei le tuatusi tuatusi o mea a lenei vaega.
    addr: usize,
    /// Mauaina le tele manatuaina o lenei vaega mea.
    size: usize,
    /// Tuʻuina mai le vaega tuatusi tuatusi o lenei vaega ma le faila ELF.
    mod_rel_addr: usize,
    /// Faʻatagaina faʻatagaina i le faila a le ELF.
    /// O nei faʻatagaina e le o faʻatagaina ia o loʻo iai i le taimi e alu ai.
    flags: Perm,
}

/// Faʻatagaina se tasi iterate luga Vaega mai le DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// E fai ma sui o le ELF DSO (Dynamic Shared Object).
/// Lenei ituaiga faʻasino faʻamaumauga teuina i le moni DSO nai lo le faia o lana lava kopi.
struct Dso<'a> {
    /// O le sooga fesoʻotaʻi e masani lava ona aumaia ia i matou se igoa, tusa lava pe leai se igoa.
    /// I le tulaga o le executable autu o le a gaogao lenei igoa.
    /// I le tulaga o se mea faʻasoa o le a avea ma soname (vaʻai DT_SONAME).
    name: &'a str,
    /// I Fuchsia toetoe lava o binaries uma fausia IDs ae le o se faigata aʻiaʻi.
    /// E leai se auala e faʻafetaui ai faʻamatalaga DSO ma se faila ELF moni pe a maeʻa pe a fai e leai se build_id o lea matou te manaʻomia ai o DSO uma maua tasi iinei.
    ///
    /// le amanaiaina o le e aunoa ma se build_id DSO.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Faʻafoʻi mai se faʻamatalaga i luga o Vaega i lenei DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// O nei mea sese suʻesuʻeina mataupu e tulaʻi mai a o faʻataʻoto faʻamatalaga e uiga i DSO taʻitasi.
///
enum Error {
    /// Igoa ole igoa sese o lona uiga na tupu se mea sese a o liliuina se C style string i le rust manoa.
    ///
    NameError(core::str::Utf8Error),
    /// o lona uiga o BuildIDError na matou le maua ai se ID fausia.
    /// mafai a le o lenei ona sa le DSO leai fausia ID pe ona sa malformed le vaega o lo o aofia ai le ID fausia.
    ///
    BuildIDError,
}

/// Valaʻau a le 'dso' poʻo le 'error' mo DSO taʻitasi fesoʻotaʻi i le gaioiga e ala i le soʻotaga soʻosoʻo.
///
///
/// # Arguments
///
/// * `visitor` - O le DsoPrinter o le ai ai se tasi o 'ai' metotia faʻaigoa o le DSO muamua.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr mautinoa o info.name o le a faʻasino i se nofoaga talafeagai.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// O lenei galuega tauave tutui le Fuchsia symbolizer markup mo faamatalaga uma o loo i se DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}