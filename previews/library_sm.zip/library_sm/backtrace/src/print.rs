#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// A formatter mo backtraces.
///
/// O lenei ituaiga e mafai ona faʻaaogaina e lolomi ai se tua i tua tusa lava poʻo fea e o mai ai le backtrace lava ia.
/// Afai ei ai se ua uma ona faaaoga e ituaiga `Backtrace` lea o lona faatinoina `Debug` lenei faatulagaga lomitusi.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// O le ituaiga o lomiga o le a tatou mafai ona e lolomiina
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Lolomiina se backer pito i tua e fetaui lelei na o aofia ai faʻamatalaga talafeagai
    Short,
    /// Lolomiina se tua i tua o loʻo iai uma faʻamatalaga talafeagai
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Fai se `BacktraceFmt` fou lea o le a tusi o galuega faatino i le `fmt` tuuina atu.
    ///
    /// O le `format` le a pulea finauga le faiga lea e lolomi le backtrace, ma o le a faaaogaina finauga `print_path` e lolomi ai le tulaga `BytesOrWideString` o filenames.
    /// O lenei ituaiga lava ia e le faia ni lolomiga o igoa faila, ae o lenei toe valaʻauina e manaʻomia e faia ai.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Lolomiina faʻatomuaga mo le backtrace e uiga i le lolomiina.
    ///
    /// Lenei e manaʻomia luga o nisi tulaga mo backtraces ia faʻatusa atoa mulimuli ane, ma a leai o lenei e tatau ona naʻo le muamua auala e te valaʻau pe a maeʻa ona faia le `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Faʻaopopo se faʻavaʻa i le backtrace galuega faatino.
    ///
    /// O lenei faia o tupe maua se RAII se faataitaiga o se `BacktraceFrameFmt` lea e mafai ona faaaoga e lolomi ai i se tino, ma o le faafanoga o le a increment le fata faavaa.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Maea maeʻa galuega faatino i tua.
    ///
    /// Lenei o le taimi nei o se leai-op ae ua faʻaopopo mo future ogatasi ma backtrace fomu.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // I le taimi nei o le leai-op-- aofia ai lenei hook e faʻatagaina ai future faʻaopoopoga.
        Ok(())
    }
}

/// O se faʻatulaga mo naʻo le tasi faʻavaʻa o le tua.
///
/// Lenei ituaiga na faia e le `BacktraceFmt::frame` gaioiga.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Tutui a `BacktraceFrame` ma lenei formatter faavaa.
    ///
    /// Lenei o le a recursively lolomi uma `BacktraceSymbol` taimi i totonu o le `BacktraceFrame`.
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Lolomiina se `BacktraceSymbol` i totonu ole `BacktraceFrame`.
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: e le lelei tele lenei tatou te le iʻu lolomiga se mea
            // ma filename le-utf8.
            // E faafetai ai e toetoe lava o mea uma lea e tatau ai lenei utf8 o le a le leaga tele foi.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Lolomiina se `Frame` ma `Symbol` masani na maua, masani mai totonu o le telefoni callbacks o lenei crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Faʻaopopo se faʻavaʻa mata i le backtrace galuega faatino.
    ///
    /// O lenei metotia, e le pei o le muamua, aveina le finauga mataʻupu pe a fai latou o faʻavae mai nofoaga 'eseʻese.
    /// Manatua e mafai ona taʻua o lenei taimi o le tele o le tasi i le faavaa.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Faʻaopopo se faʻavaʻa mata i le backtrace galuega faatino, aofia ai faʻamatalaga koluma.
    ///
    /// O lenei metotia, pei o le muamua, aveina le finauga mataʻupu neʻi latou o faʻavae mai nofoaga 'eseʻese.
    /// Manatua e mafai ona taʻua o lenei taimi o le tele o le tasi i le faavaa.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia e le mafai ona faʻailoga i totonu o se gaioiga o loʻo i ai se faʻapitoa faʻapitoa e mafai ona faʻaaogaina e faʻailoga mulimuli ai.
        // Lolomi lena nai lo le lolomiina tuatusi i la matou lava faatulagaga iinei.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Le manaomia e lolomi faavaa "null", e aupito na o lona uiga o le faiga backtrace sa fai si naunau e lolomi i tua maoae mamao.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Ina ia faʻaititia le tele TCB i le Sgx enclave, matou te le mananaʻo e faʻatino le faʻataʻitaʻiga o galuega.
        // Nai lo lea, e mafai ona tatou lolomiina le faʻapalenia o le tuatusi iinei, lea e mafai ona mulimuli ane faʻafanua e faʻasaʻo galuega.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Lolomi ai le faasino upu o le tino faapea foi ma le faʻasino faatonuga tuu i le faitalia o le faavaa.
        // Afai tatou te i tala atu o le muamua faʻailoga o lenei faʻavaʻa e ui lava tatou na lolomi talafeagai paʻepaʻe.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Sosoo ai ma tusi le igoa faʻailoga, faʻaaoga le isi faʻavasegaina mo nisi faʻamatalaga pe a fai o matou o se atoʻaga tua.
        // Lenei matou te tagofiaina foi faʻailoga e leai se igoa,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Ma mulimuli i luga, lolomi le filename/line numera pe a latou avanoa.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line o loʻo lolomiina i laina i lalo ole igoa faʻailoga, o lea ia lolomi ni avanoa paepae talafeagai e faʻatulagaina saʻo ai matou.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Avefeʻau i la matou valaʻauga i totonu e lolomi le igoa faila ona lolomi ai lea o le numera laina.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Faaopoopo numera koluma, pe afai e maua.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // E naʻo le uluaʻi faʻailoga o le faavaa matou te popole ai
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}