use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Fofo se tuatusi i se faʻailoga, pasi le faʻailoga i le tapunia faʻamaonia.
///
/// Lenei gaioiga o le a vaʻai i luga o le tuatusi na tuʻuina atu i vaega e pei o le lotoifale faʻailoga laulau, malosi faʻailoga laulau, poʻo DWARF debug info (faʻamoemoe i le faʻagaoioia faʻagaioiga) e suʻe faʻailoga e maua ai.
///
///
/// E le mafai ona valaʻau le tapunia pe a fai e le mafai ona faia se iugafono, ma e mafai foi ona sili atu ma le tasi le taimi e valaauina ai i le tulaga o galuega tuʻufaʻatasia.
///
/// Faʻailoga na maua e fai ma sui o le faʻataunuʻuina ile `addr` faʻapitoa, toe faafoi mai file/line paga mo lena tuatusi (pe a fai e avanoa).
///
/// Manatua afai e i ai sau `Frame` ona fautuaina lea e faʻaaoga le `resolve_frame` galuega nai lo le tasi lea.
///
/// # Manaʻomia foliga vaaia
///
/// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
///
/// # Panics
///
/// O lenei galuega tauave taumafai e lava panic, ae afai o le a faamalosia `cb` tuuina lea panics nisi fausaga opea a faaluaina panic e abort le faagasologa.
/// O nisi fausaga opea faaaoga a C faletusi lea e faaaoga mai totonu callbacks e le mafai ona unwound ala, ina panicking mai `cb` e mafai ona faaosofia ai le abort faagasologa.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // naʻo le vaai atu i le pito i luga o le faavaa
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Faʻamautu se muamua puʻeina faʻavaʻa i se faʻailoga, pasi le faʻailoga i le faʻamaʻotiina tapunia.
///
/// O lenei functionin na te faʻatinoina le tutusa gaioiga ma le `resolve` seʻi vagana o le `Frame` e avea ma finauga ae le o se tuatusi.
/// Lenei mafai faʻatagaina nisi faʻavae faʻavaeina o backtracing e maua ai sili atu faʻailoga faʻailoga faʻamatalaga poʻo faʻamatalaga e uiga i laina laina mo se faʻataʻitaʻiga.
///
/// E fautuaina e faʻaaoga lenei pe a e mafaia.
///
/// # Manaʻomia foliga vaaia
///
/// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
///
/// # Panics
///
/// O lenei galuega tauave taumafai e lava panic, ae afai o le a faamalosia `cb` tuuina lea panics nisi fausaga opea a faaluaina panic e abort le faagasologa.
/// O nisi fausaga opea faaaoga a C faletusi lea e faaaoga mai totonu callbacks e le mafai ona unwound ala, ina panicking mai `cb` e mafai ona faaosofia ai le abort faagasologa.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // naʻo le vaai atu i le pito i luga o le faavaa
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP taua mai faʻaputuga faʻavaʻa e masani ona (always?) faʻatonuga *pe a maeʻa* o le valaʻau o le faʻatulagaina tonu lea o faʻailoga.
// Faʻailogaina lenei mea mafua ai le numera filename/line ia tasi i luma ma ono i totonu o le gaogao pe a fai e latalata i le iʻuga o le gaioiga.
//
// O lenei e foliga mai e avea aupito pea le tulaga i uma fausaga opea, o lea e le aunoa toese se tasi mai le a foia IP e foia i le faatonuga valaau talu ai ae le o le faatonuga ua toe foi atu.
//
//
// Tulaga e tatau ai tatou te le faia lenei mea.
// Tulaga e tatau ai o le a tatou manaomia callers o le APIs `resolve` iinei e manually faia le -1 ma tala latou te mananao nofoaga faamatalaga mo le *muamua faatonuga*, e le o le taimi nei.
// O le mea sili tatou te faʻaalia foʻi i le `Frame` pe afai o tatou moni o le tuatusi o le isi faʻatonuga poʻo le taimi nei.
//
// Mo le taimi nei e ui lava o lenei o se matua manaia atamamai o lea tatou na o totonu lava taimi uma toʻesea se tasi.
// Tagata faʻatau e tatau ona galulue pea ma maua aulelei faʻaiuga lelei, o lea e tatau ai ona tatou lava lelei.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Tutusa lava ma `resolve`, naʻo le le saogalemu ona e leʻo faʻatasia.
///
/// Lenei gaioiga e leai ni faʻamaoniga faʻamaonia ae e avanoa pe a le o le `std` vaega o lenei crate e le tuʻufaʻatasia i totonu.
/// Vaʻai le gaioiga `resolve` mo nisi faʻamaumauga ma faʻataʻitaʻiga.
///
/// # Panics
///
/// Vaʻai faʻamatalaga i luga o le `resolve` mo lapataiga i luga o le `cb` gaioiga.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Tutusa lava ma `resolve_frame`, naʻo le le saogalemu ona e leʻo faʻatasia.
///
/// Lenei gaioiga e leai ni faʻamaoniga faʻamaonia ae e avanoa pe a le o le `std` vaega o lenei crate e le tuʻufaʻatasia i totonu.
/// Vaʻai le gaioiga `resolve_frame` mo nisi faʻamaumauga ma faʻataʻitaʻiga.
///
/// # Panics
///
/// Vaʻai faʻamatalaga i luga o le `resolve_frame` mo lapataiga i luga o le `cb` gaioiga.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// O le trait o loʻo fai ma sui o le iʻuga o se faʻailoga i se faila.
///
/// O lenei trait ua gauai atu o se mea trait i le tapunia tuuina atu i le galuega tauave `backtrace::resolve`, ma ua toetoe lava aauina e pei ona o le iloa lea o le faatinoga o tua i ai.
///
///
/// O se faʻailoga mafai ona tuʻuina mai faʻamatalaga faʻavae e uiga i se gaioiga, mo se faʻataʻitaʻiga le igoa, igoa igoa, igoa laina, tulaga tonu tuatusi, ma isi.
/// E leʻo taimi uma e maua ai faʻamatalaga i se faʻailoga, peitaʻi, o metotia uma lava e faʻafoʻi mai ai le `Option`.
///
///
pub struct Symbol {
    // TODO: o lenei olaga atoa noatia e tatau ona faʻaauau pea i le `Symbol`,
    // ae o le taimi nei o se soliga suiga.
    // Mo le taimi nei o lenei e saogalemu talu mai `Symbol` ua na o taimi uma tufaina atu e ala i le faʻasino ma e le mafai ona faʻavasega.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Toe afio mai le igoa o lenei galuega tauave.
    ///
    /// E le mafai ona faaaogaina fausaga toe foi atu i fesili meatotino eseese e uiga i le igoa faailoga:
    ///
    ///
    /// * le a lolomi atu le faatinoga `Display` le faailoga demangled.
    /// * O le aoga `str` taua o le faʻailoga e mafai ona mauaina (pe a fai e aoga utf-8).
    /// * O le bytes mata mo le igoa igoa mafai ona mauaina.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Faʻafoʻi le tuatusi amata o lenei galuega.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Toe afio mai le filename mata o se fasi.
    /// E aoga tele lea mo siosiomaga `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Faʻafoʻi mai le numera numera mo le mea o loʻo faʻatautaia ai nei lenei faʻailoga.
    ///
    /// Naʻo gimli o loʻo maua nei se tau iinei ma e faʻapea foi pe a toe maua e `filename` le `Some`, ma o le mea lea e mulimuli ane faʻatatau i faʻataʻitaʻiga tutusa.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Faʻafoʻi mai le numera laina mo le mea o loʻo faʻatautaia ai nei lenei faʻailoga.
    ///
    /// O lenei toe faafoi taua e masani lava `Some` pe a fai `filename` toe faafoi `Some`, ma e mulimuli ane i lalo o le tali tutusa.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Faʻafoʻi le igoa faila ile mea na faʻamatalaina ai lenei galuega.
    ///
    /// E faʻatoa avanoa lea ile taimi nei pe a faʻaaoga le libbacktrace poʻo le gimli (faʻataʻitaʻiga
    /// unix fausaga opea isi) ma pe a tuufaatasia a binary ma debuginfo.
    /// A le faʻamalieina se tasi o nei tulaga ona ono toe foʻi lea o `None`.
    ///
    /// # Manaʻomia foliga vaaia
    ///
    /// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Masalo o le parsed C++ faʻailoga, pe a fai o le faʻamamaina o le maʻi faʻailoga e pei o le Rust ua le manuia.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Ia mautinoa e teu le zero-tele, ina ia leai se tau o le `cpp_demangle` foliga pe a le atoatoa.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Se afifi faataamilo i se igoa igoa e maua ai ergonomic accessors i le leiloa igoa, o le mata paita, le mata mata, ma isi
///
// Faʻatagaina le oti tulafono mo pe a le `cpp_demangle` vaega e le mafai.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Fausia se igoa fou faʻailoga mai le mata i lalo bytes.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Faʻafoʻi mai le igoa (mangled) faʻailoga o `str` pe a fai o le faʻailoga e utf-8.
    ///
    /// Faʻaaoga le `Display` faʻatinoga pe a fai e te manaʻomia le faʻaletonu foliga.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Faʻafoʻi mai le igoa igoa igoa o se lisi o paita
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // E mafai ona lolomi pe a fai e le aoga le faʻailoga ua suia, o lea ia alofagia ma le agalelei le mea sese ii le le faʻasalalauina i fafo.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Taumafai e toe maua mai le cache manatua na faʻaaoga e faʻatusa ai tuatusi.
///
/// Lenei auala o le a taumafai e faʻasaʻoloto soʻo se lalolagi faʻamatalaga fausaga na i se isi itu cache i le lalolagi atoa poʻo le filo e masani lava faʻatusalia parsed DWARF faʻamatalaga pe tutusa.
///
///
/// # Caveats
///
/// E ui o lenei gaioiga e avanoa i taimi uma e le mafai ona faia se mea i le tele o faʻatinoga.
/// Faletusi e pei o le dbghelp poʻo le libbacktrace e le maua ai ni fale e faʻataʻitaʻi ai setete ma faʻatonutonu le tuʻufaʻatasiga o mea e manatua.
/// Mo le taimi nei o le `gimli-symbolize` foliga o lenei crate na o le pau lea o le mea e faʻaalia ai lenei aoga.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}