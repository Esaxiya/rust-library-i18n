//! Faʻataʻitaʻiga faʻailoga e faʻaaogaina ai le DWARF-parsing code i le libbacktrace.
//!
//! O le libbacktrace faletusi C, e masani tufatufaina ma gcc, lagolago e le gata faatupuina a backtrace (lea tatou te le moni faaaogaina) ae faapea foi symbolicating le backtrace ma le taulimaina o faamatalaga debug dwarf e uiga i mea e pei o inlined faavaa ma whatnot.
//!
//!
//! E fai lava si faigata ona o le tele o atugaluga eseese ii, ae ole manatu autu ole:
//!
//! * Muamua matou valaʻau `backtrace_syminfo`.maua faamatalaga faatusa lenei mai le laulau faailoga maoae pe afai tatou te mafaia.
//! * Le isi valaʻau lea ole `backtrace_pcinfo`.O le a parse debuginfo laulau pe afai latou te maua ma mafai ai ona tatou toe maua faamatalaga e uiga i faavaa o inline, filenames, numera o le laina, ma isi
//!
//! E i ai le tele togafiti e uiga i le aumaia o le dwarf laulau i le libbacktrace, ae talosia e le o le iʻuga o le lalolagi ma e manino lava pe a faitau i lalo.
//!
//! Lenei o le le faʻailoga faʻailoga taʻiala mo le le MSVC ma le OSX tulaga.I le libstd e ui lava o le le tumau lea o fuafuaga mo OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Afai e talafeagai, manaʻomia le igoa `function` e sau mai le debuginfo ma e masani ona sili atu le saʻo mo laina laina mo se faʻataʻitaʻiga.
                // Afai e le o iai, ae paʻu i tua i le igoa laulau faʻailoga faʻamaoti i le `symname`.
                //
                // Manatua o nisi taimi `function` mafai ona lagona sina laʻititi saʻo, mo se faʻataʻitaʻiga lisiina o `try<i32,closure>` isntead o `std::panicking::try::do_call`.
                //
                // E leʻo mautinoa le mafuaaga, ae ole aotelega ole igoa `function` e foliga mai e sili atu le saʻo.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // aua le faia se mea i le taimi nei
}

/// Ituaiga o le `data` faʻasino pasi i `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // A maeʻa loa ona toe valaʻau lenei callback mai le `backtrace_syminfo` pe a amata ona tatou fofo ona tatou o lea e valaʻau i le `backtrace_pcinfo`.
    // O le `backtrace_pcinfo` gaioiga o le a faʻafesoʻotaʻia faʻamaumauga faʻamatalaga ma taumafai e faia ni mea e pei o le toe maua mai o file/line faʻamatalaga faʻapea foʻi ma laina tuʻufaʻatasia.
    // Manatua e ui lava o `backtrace_pcinfo` e mafai ona le manuia pe leai foi pe a fai e leai se debug info, o lea afai e tupu lena mea matou te mautinoa e valaʻau le callback ma le itiiti ifo i le tasi faʻailoga mai le `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Ituaiga o le `data` faʻasino pasi i `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// O le libbacktrace API lagolagoina le fausiaina o se setete, ae le lagolagoina le faʻaleagaina o se setete.
// O aʻu lava ia e faʻapea o le uiga o se setete e moomia ona foafoaina ona ola ai lea e faʻavavau.
//
// Ou te fiafia e lesitala le tagata vaʻaia at_exit() e faʻamamaina lenei setete, ae o le libbacktrace e leai se auala e faia ai.
//
// Faatasi ai ma nei tapulaa, o lenei gaioiga ei ai se statically cache tulaga na fuafuaina i le taimi muamua lenei na talosagaina.
//
// Manatua o tua i tua mea uma e tupu serally (tasi loka lalolagi).
//
// Manatua le le lava o le faʻasologa iinei e mafua mai i le manaʻoga o le `resolve` e faʻasolosolo i fafo.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Aua le faʻamalositino gafatia saogalemu o le libbacktrace talu ai matou te masani ona valaʻauina i se tuʻufaʻatasia foliga.
        //
        0,
        error_cb,
        ptr::null_mut(), // leai ni faʻamatalaga faʻaopoopo
    );

    return STATE;

    // Manatua o mo libbacktrace e faagaoioia i uma e manaomia e maua ai nisi faʻamatalaga debug DWARF mo le executable nei.E masani ona faia lena mea e ala ile tele o auala e aofia ai, ae le gata ile:
    //
    // * /proc/self/exe luga o lagolago tulaga
    // * O le igoa faila na pasi manino i le fausiaina o setete
    //
    // O le libbacktrace faletusi o se tele wad of C code.O lenei masani o lona uiga o maua vaivaiga saogalemu manatua ai a, aemaise lava pe a le taulimaina debuginfo malformed.
    // Libstd na tamoe i le tele o nei talaʻaga.
    //
    // Afai e faʻaaogaina le /proc/self/exe e mafai ona tatou le amanaʻiaina nei mea pe a tatou manatu o le libbacktrace o le "mostly correct" ae a le faia mea leaga i le "attempted to be correct" dwarf debug info.
    //
    //
    // Afai tatou te oo i se filename Ae peitai, e le mafai ona i nisi fausaga opea (e pei o BSDs) pe afai o se tagata autu e leaga e mafai ona mafua ai se faila soʻona faia ina ia tuu i lena nofoaga.
    // O lona uiga afai tatou te taʻuina i tua le avanoa e uiga i se igoa faila atonu o loʻo faʻaaogaina ai se faila faʻatapuaʻi, atonu e mafua ai ni faʻailoga.
    // Afai matou te le taʻuina libbacktrace se mea e ui lava ona o le a le faia se mea i luga o faʻavae e le lagolagoina ala pei o /proc/self/exe!
    //
    // Tuuina atu mea uma tatou te taumafai i le malosi e mafai ai i *le* mavae i se filename, ae e tatau ona tatou i fausaga opea le lagolagoina /proc/self/exe i uma.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Manatua o le mea sili tatou te faʻaaogaina `std::env::current_exe`, ae le mafai ona tatou manaʻomia `std` ii.
            //
            // Faʻaaoga `_NSGetExecutablePath` e utaina le taimi nei auala faʻaaogaina i totonu o se static eria (lea pe a fai e laʻititi na ona faʻavaivai).
            //
            //
            // Manatua o loʻo matou talitonuina ma le faʻatuatuaina le avanoa i tua atu iinei e le feoti ai i ni faiga piʻopiʻo, ae e mautinoa lava e ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ei ai le ituaiga o tatalaina faila pe a uma ona tatalaina e le mafai ona tapeina.
            // Lena a le i aoao o mea tatou te mananao i ai iinei ona tatou te mananao ina ia mautinoa ai lo tatou executable e le o suia mai lalo o tatou uma ona tatou tuu ai lea o ia i libbacktrace, faamoemoe mitigating le tomai e oo i faamatalaga soʻona faia i libbacktrace (lea e mafai ona mishandled).
            //
            //
            // Talu ai tatou te faia sina siva iinei e taumafai ai e maua se ituaiga loka i luga o la matou lava ata:
            //
            // * Maua se au i le taimi nei gaioiga, uta lona igoa faila.
            // * Tatala se faila i lena igoa igoa ma le fuʻa taumatau.
            // * Toe uta le igoa faila ole igoa, ia mautinoa e tutusa
            //
            // Afai o mea uma pasese tatou i le teori na tatalaina moni a matou gaioiga faila ma matou mautinoa e le suia.FWIW o se vaega o lenei mea na kopiina mai libstd faʻasolopito, o lea la o laʻu sili faauigaina o le mea na tupu.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Lenei ola i manatua static manatua tatou mafai ona toe faʻafoʻi ..
                static mut BUF: [i8; N] = [0; N];
                // ... ma o lenei e ola i luga o le faaputuga talu ai e le tumau
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // Ma le faʻamoemoe e faʻamama le `handle` iinei aua o le tatalaina e tatau ai ona faʻasao la matou loka i luga ole faila igoa lea.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Matou te mananaʻo e toe faʻafoʻi se fasi e leai se aoga, afai la na faʻatumuina mea uma ma e tutusa ma le umi atoa ona faʻatusatusa lea o le mea sa le aoga.
                //
                //
                // Leai pe a toe foi manuia Ia mautinoa ua aofia ai le byte nul i le fasi.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // mea sese i tua o loʻo tafiesea nei i lalo o le kapeta
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Valaʻau le `backtrace_syminfo` API lea (mai le faitauina o le numera) tatau ona valaʻau `syminfo_cb` faʻatasi taimi (pe faʻatoʻilaloina ma se mea masalo masalo).
    // Ona matou tagofiaina atili ai lea i totonu ole `syminfo_cb`.
    //
    // Manatua matou te faia lenei mea talu mai `syminfo` o le a faʻafesoʻotaʻia le laulau faʻailoga, saili igoa faʻailoga tusa lava pe leai se faʻamatalaga faʻaletonu i le binary.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}