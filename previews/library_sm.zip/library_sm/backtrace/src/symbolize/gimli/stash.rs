// naʻo le Linux na faʻaaogaina i le taimi nei, ia faʻataga la le code mate i seisi mea
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// O se faigofie arena tufatufaina mo byte buffers.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Tuʻuina atu se faʻavaʻa o le aofaʻi faʻatulagaina ma toe faʻafoʻi mai se faʻasino i ai.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: na o le pau lea o galuega e mafai ona fausia se suiga
        // faʻasino ile `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SAFETY: matou te le aveʻesea elemeni mai le `self.buffers`, o lea o se faʻasino
        // i faʻamaumauga i totonu o soʻo se buffer o le a ola pe a umi `self` e.
        &mut buffers[i]
    }
}