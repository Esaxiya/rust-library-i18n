//! O se vaega e fesoasoani i le puleaina o le dbghelp bindings ile Windows
//!
//! Backtraces i luga ole Windows (sili atu mo MSVC) e tele na faʻaolaina e ala i le `dbghelp.dll` ma le tele o gaioiga o loʻo iai.
//! O nei gaioiga o loʻo utaina nei *malosi* nai lo le fesoʻotaʻi atu i le `dbghelp.dll` faʻasolosolo.
//! Lenei o loʻo faia nei e le faletusi masani (ma o loʻo i ai i le teori manaʻomia iina), ae o se taumafaiga e fesoasoani faʻaititia le static dll faʻalagolagoina o se faletusi talu ai backtraces e masani lava a filifili.
//!
//! O le fai mai, `dbghelp.dll` toetoe lava o taimi uma manuia avega luga Windows.
//!
//! Manatua e ui lava ona matou utaina uma lenei lagolago malosi matou te le mafai moni ona faʻaaoga le faʻauiga uiga i le `winapi`, ae e tatau ona tatou faʻauigaina le faʻatulagaina o faʻatonuga ituaiga tatou lava ma faʻaoga lena.
//! Matou te le mananaʻo e avea i le pisinisi o le faʻaluaina winapi, o lea e i ai la matou Cargo foliga `verify-winapi` o loʻo faʻapea mai o fusifusia uma e tutusa ma latou i winapi ma o lenei foliga e mafai i luga o le CI.
//!
//! I le iuga, oe maitau iinei o le dll mo `dbghelp.dll` e le aveʻesea i lalo, ma o le taimi nei ua fuafuaina.
//! O le mafaufau o le mafai ona tatou cache i le lalolagi atoa ma faʻaaoga i le va o valaʻauga i le API, aloese mai le taugata loads/unloads.
//! Afai o se faʻafitauli lea mo tagata suʻesuʻe faʻasolo atu poʻo ni mea faʻapena e mafai ona matou sopoia le auala laupapa pe a matou oʻo atu iina.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Galulue faataamilo `SymGetOptions` ma `SymSetOptions` le auai i winapi lava ia.
// A leai o lea faʻatoa faʻaaogaina pe a matou faʻalua-siaki ituaiga e faasaga i winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Le faʻamatalaina i winapi ae
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Lenei o loʻo faʻamatalaina ile winapi, ae e le saʻo (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Le faʻamatalaina i winapi ae
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// O lenei macro o loʻo faʻaaogaina e faʻamatalaina ai le `Dbghelp` fausaga o loʻo i totonu o loʻo i ai vaega uma e mafai ona tatou utaina.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Le utaina DLL mo `dbghelp.dll`
            dll: HMODULE,

            // Taʻitasi galuega faʻatulagaina mo gaioiga uma tatou ono faʻaaogaina
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Muamua matou te leʻi utaina le DLL
            dll: 0 as *mut _,
            // Amataina uma gaioiga ua seti i le zero e fai mai latou te manaʻomia le vave aveina.
            //
            $($name: 0,)*
        };

        // typedef talafeagai mo ituaiga galuega tauave taitasi.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Taumafai e tatala `dbghelp.dll`.
            /// Faʻafoʻi le manuia pe a e galue pe sese pe a le `LoadLibraryW` ua le manuia.
            ///
            /// Panics pe a fai ua uma ona utaina le faletusi.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Galuega tauave o le tasi auala e tatou te fia faaaogaina.
            // A valaauina o le a faitau pe o le cache galuega faʻasino poʻo le uta i luga ma toe faʻafoʻi le utaina taua.
            // O loʻo faʻamaonia le manuia.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Le faafaigofieina sui e faaaoga le faamama loka e faasinomaga galuega tauave dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Faʻamuamua lagolago uma e manaʻomia e ulufale ai i le `dbghelp` API galuega mai lenei crate.
///
///
/// Manatua o lenei gaioiga e **saogalemu**, i totonu ei ai lana lava faʻasologa.
/// Ia maitau foi o le saogalemu e valaau lenei galuega tauave taimi tele recursively.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Muamua mea e tatau ona tatou faia o le faʻafesoʻotaʻia lenei gaioiga.Lenei mafai ona valaʻau faʻatasi mai isi filo pe toe faʻafetaui i totonu o le tasi filo.
        // Manatua e sili atu le faigata nai lo lena e ui lava ona o le mea o loʻo tatou faʻaaogaina iinei, `dbghelp`,*faʻapea foi* e manaʻomia faʻatasi ma isi valaʻau uma ile `dbghelp` i lenei faiga.
        //
        // E masani lava e le tele naʻua telefoni i le `dbghelp` i totonu o le gaioiga tutusa ma e mafai ona tatou manatu faʻapea o tatou e pau na o tagata o loʻo mauaina.
        // Peitai, e i ai le tasi muamua isi tagata faʻaaoga e tatau ona matou popole e uiga i le mea e uʻamea ia i matou lava, ae i le faletusi masani.
        // O le Rust standard faletusi faʻalagolago i lenei crate mo lagolago i tua, ma o lenei crate o loʻo i ai foi i crates.io.
        // O lona uiga afai e lolomiina e le faletusi masani le panic tua i tua e ono tamoʻe ma lenei crate sau mai crates.io, mafua ai segfaults.
        //
        // Ina ia fesoasoani e foia lenei faafitauli synchronization tatou faafaigaluega a togafiti Pupuni maoti iinei (e, mea uma, o se tapulaa Pupuni-patino e uiga i synchronization).
        // Matou te faia se *session-local* igoa mutex e puipuia ai lenei valaʻau.
        // O le mafuaʻaga iinei o le faletusi masani ma lenei crate e le tau faʻasoa Rust-tulaga API e faʻasolosolo iinei ae mafai ona galue i tua atu o vaaiga e mautinoa ai o latou faʻatasi tasi.
        //
        // O le auala lena pe a valaʻauina lenei gaioiga e ala i le faletusi masani poʻo le crates.io matou te mautinoa o loʻo maua le mutex lava e tasi.
        //
        // Ma o na mea uma o le fai mai o le mea muamua tatou te faia iinei o tatou atomically faia se `HANDLE` o se igoa igoa i luga o Windows.
        // Matou te faʻafesoʻotaia sina vaega ma isi filo o tuʻufaʻatasia lenei galuega faʻapitoa ma mautinoa e naʻo le tasi le 'au na faia i taimi taʻitasi o lenei galuega.
        // Manatua o le 'au e le mafai ona punitia pe a uma ona teuina i le lalolagi.
        //
        // Ina ua uma ona matou moni alu le loka tatou na maua ai, ma o tatou `Init` taulimaina tatou tuu atu le a nafa mo le pau o sa iu.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Lelei, phew!O lenei ua tatou uma faʻatasi fesoʻotaʻiga, ia tatou amata amata faʻagasologa mea uma.
        // Muamua lava tatou manaʻomia le mautinoa o `dbghelp.dll` o loʻo utaina i lenei gaioiga.
        // Matou te faia lenei mea faʻamalosia e aloese ai mai le tumau faʻalagolago.
        // O lenei ua le talafaasolopito ua faia i le galuega o loo siomia ai mataupu ese lava tuufaatasi ma ua faamoemoe i le faia o binaries se vaega sili atu feaveai talu mai lenei o le tele na o se aoga debugging.
        //
        //
        // O le taimi na tatou tatalaina `dbghelp.dll` tatou manaʻomia e valaʻau ni amataga galuega i totonu, ma o lena auiliiliga sili atu i lalo.
        // E naʻo le tasi taimi tatou te faia ai lenei, ae o lea e i ai le tatou lalolagi lautele faʻaalia pe ua maeʻa tatou faia pe leai.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Ia mautinoa ua seti le fuʻa `SYMOPT_DEFERRED_LOADS`, aua e tusa ai ma faʻamatalaga a le MSVC e uiga i lenei: "This is the fastest, most efficient way to use the symbol handler.", ia tatou faia la!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Moni faʻamalamalama faʻailoga ma MSVC.Manatua o lenei mafai ona le manuia, ae tatou le amanaʻiaina.
        // E leai se tone o muamua ata mo lenei per se, ae o le LLVM i totonu e foliga mai e le amanaʻiaina le toe faʻatauaina iinei ma o se tasi o faletusi faletusi i le LLVM lolomiina se lapataiga lapataiga pe a fai e le manuia lenei ae masani ona le amanaiaina i le taimi umi.
        //
        //
        // O se tasi tulaga lenei e oo mai ai se tele mo Rust e faapea o le potutusi o le tulaga ma lenei crate i crates.io uma e lua e te manao e tauva mo `SymInitializeW`.
        // O le faletusi masani faʻasolosolo manaʻo e amataina ona faʻamamaina tele o taimi, ae o lenei ua faʻaaogaina lenei crate o lona uiga o le a muamua sau se tasi i le muamua ae o le isi o le a pikiina lena amataga.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}