use core::ffi::c_void;
use core::fmt;

/// Asiasi le taimi nei call-stack, pasi uma faʻagaoioi faʻafanua i le tapunia saunia e fuafua se faaputuga suʻega.
///
/// Lenei gaioiga o le workhorse o lenei faletusi i le fuafuaina o le faʻamau faʻailoga mo se polokalama.O le tapunia `cb` o loʻo maua mai taimi o le `Frame` e fai ma sui o faʻamatalaga e uiga i lena valaʻau faʻavaʻa i luga o le faʻaputuga.
/// O le tapunia e maua ai faʻavaʻa i se pito i luga-lalo faiga (talu ai nei valaauina galuega muamua).
///
/// O le tapunia o le toe faafoi taua o se faʻailoga pe tatau ona faʻaauau le tua.O le toe faafoi taua o `false` o le a faamutaina le backtrace ma toe foi vave.
///
/// A maua loa le `Frame` e te ono manaʻo e valaʻau i le `backtrace::resolve` e faʻaliliu le `ip` (faʻatonuga faʻasino) poʻo le faʻailoga i le `Symbol` e mafai ai ona aʻoaʻoina le igoa ma/poʻo le igoa igoa/laina.
///
///
/// Manatua o lenei o se maualalo maualalo-tulaga gaioiga ma afai e te manaʻo e, mo se faʻataʻitaʻiga, puʻeina se backtrace e asiasia mulimuli ane, lona uiga o le `Backtrace` ituaiga atonu e sili talafeagai.
///
/// # Manaʻomia foliga vaaia
///
/// Lenei gaioiga manaʻomia le `std` foliga o le `backtrace` crate e mafai ai, ma le `std` foliga e mafai e ala i le le masani ai.
///
/// # Panics
///
/// O lenei galuega tauave taumafai e lava panic, ae afai o le a faamalosia `cb` tuuina lea panics nisi fausaga opea a faaluaina panic e abort le faagasologa.
/// O nisi fausaga opea faaaoga a C faletusi lea e faaaoga mai totonu callbacks e le mafai ona unwound ala, ina panicking mai `cb` e mafai ona faaosofia ai le abort faagasologa.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // faaauau le backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Tutusa lava ma `trace`, naʻo le le saogalemu ona e leʻo faʻatasia.
///
/// Lenei gaioiga e leai ni faʻamaoniga faʻamaonia ae e avanoa pe a le o le `std` vaega o lenei crate e le tuʻufaʻatasia i totonu.
/// Tagai i le galuega tauave `trace` mo nisi pepa ma faataitaiga.
///
/// # Panics
///
/// Vaʻai faʻamatalaga i luga o le `trace` mo lapataiga i luga o le `cb` gaioiga.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// O le trait o loʻo fai ma sui o le tasi faʻavaʻa o le tua, faʻatagaina i le `trace` gaioiga o lenei crate.
///
/// O le tapuniaina o le tapunia o le a maua ai ni faʻavaʻa, ma o le tino e toetoe lava a lafoina ona o le mafuaʻaga o faʻatinoga e le masani ona iloaina seʻia maeʻa taimi.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Faʻafoʻi mai le faʻatonuga faʻasino taimi nei o lenei faʻavaʻa.
    ///
    /// Lenei e masani lava o le isi faʻatonuga e faʻagaioia i le faʻavaʻa, ae le o faʻatinoina uma lisiina lenei ma 100% sao (ae e masani lava a latalata latalata).
    ///
    ///
    /// E fautuaina e pasi lenei tau i le `backtrace::resolve` e liliu ai i se igoa faʻailoga.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Toe afio mai le faasino faaputuga le taimi nei o lenei faavaa.
    ///
    /// I le tulaga e le mafai e se tua i tua ona toe maua mai le faʻailoga faʻailoga mo lenei faʻavaʻa, ua faʻafoʻi mai se faʻailoga leai.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Faʻafoʻi mai le tuatusi faʻailoga tuatusi o le faʻavaʻa o lenei galuega.
    ///
    /// Lenei o le a taumafai e toe faʻafoʻi le faʻatonuga faʻatonu na toe faafoi mai e `ip` i le amataga o le gaioiga, faʻafoʻi lena tau.
    ///
    /// I nisi tulaga, peitai, o le a toe foi lava backends `ip` mai lenei galuega tauave.
    ///
    /// mafai i nisi taimi ona faaaoga le taua toe foi pe afai `backtrace::resolve` lē mafai i luga o le `ip` tuuina atu i luga.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Faʻafoʻi le tuatusi faʻavae o le module lea e ana le fausaga.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Lenei manaʻomia e muamua, ia mautinoa o Miri e faʻamuamua nai lo le talimalo tulaga
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // naʻo le faʻaaogaina ile dbghelp faʻailoga
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}