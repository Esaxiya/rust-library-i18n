# backtrace-rs

[Documentation](https://docs.rs/backtrace)

A faletusi mo le mauaina o backtraces i runtime mo Rust.
O lenei faletusi e faʻamoemoe e faʻalauteleina le lagolago a le faletusi masani e ala i le tuʻuina atu o se polokalame e galulue faʻatasi ai, ae e mafai foi ona lagolagoina faigofie ona lolomiina le taimi nei i tua pei o le libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Naʻo le puʻeina o se backtrace ma tolopo feutanaʻi ma ia seʻia oʻo i se taimi mulimuli ane, oe mafai ona faʻaaoga le pito i luga tulaga `Backtrace`.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Afai, peitaʻi, e te manaʻomia se tele atu auala i le sailia tonu o gaioiga, oe mafai ona faʻaaoga saʻo le `trace` ma le `resolve` gaioiga.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Faʻamautu lenei faʻasino tusi i se igoa faʻailoga
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // alu pea i le isi faʻavaa
    });
}
```

# License

O lenei poloketi ua laiseneina i lalo o se tasi o

 * Apache Laisene, Faʻamatalaga 2.0, ([LICENSE-APACHE](LICENSE-APACHE) poʻo http://www.apache.org/licenses/LICENSE-2.0)
 * Laisene MIT ([LICENSE-MIT](LICENSE-MIT) poʻo http://opensource.org/licenses/MIT)

i lau filifiliga.

### Contribution

Sei vagana ua e manino tulaga e ese ai, so o se saofaga tuuina atu le loto i ai e faaaofia i totonu backtrace-Laasaga e outou, e pei ona faamatalaina i le Apache-2.0 laisene, e tatau ona lua ua laiseneina e pei ona taua i luga, e aunoa ma se faaopoopo tuutuuga po o aiaiga.







