#![feature(no_core)]
#![no_core]

// Tagai rustc-std-workspace-autu mo aisea e manaomia ai lenei crate.

// Rename le crate e aloese feteenai ma le module alloc i liballoc.
extern crate alloc as foo;

pub use foo::*;