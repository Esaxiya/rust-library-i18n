//! A faletusi lagolago mo tusitala macro pe a faamatalaina macros fou.
//!
//! O lenei faletusi, e tuuina atu e le tufatufaina tagavai, e maua ai le ituaiga susunuina i le interfaces o procedurally faamatalaina macro faamatalaga e pei o galuega tauave-e pei macros `#[proc_macro]`, uiga macro `#[proc_macro_attribute]` ma tu maua attributes`#[proc_macro_derive] '.
//!
//!
//! Vaʻai [the book] mo nisi mea.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// E iloa ai pe ua faia maua proc_macro i le polokalama o le tamoe i le taimi nei.
///
/// O le proc_macro crate ua na o le faamoemoe mo le faaaogaina i totonu o le faatinoga o macros taualumaga.O gaioiga uma i lenei crate panic pe a valaʻauina mai fafo atu o le taualumaga o faʻataʻitaʻiga, pei o le fausia tusitusiga poʻo iunite suʻega poʻo le masani Rust binary.
///
/// Ile iloiloga mo faletusi Rust o loʻo fuafuaina e lagolago uma ai le faʻaogaina o le macro ma le non-macro, o le `proc_macro::is_available()` e maua ai se auala e le faʻafaigata ona iloa ai pe o avanoa ni atinaʻe manaʻomia e faʻaaoga ai le API o le proc_macro o avanoa nei.
/// Faʻafoʻi faʻamaoni pe a fai na faʻaulu mai totonu o se taualumaga faʻatautaia, sese pe a valaʻauina mai seisi lava binary.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// O le ituaiga autu saunia e lenei crate, fai ma sui o se vaʻaia vaitafe o tokens, pe, sili faʻapitoa, se faʻasologa o token laau.
/// O le ituaiga tuuina interfaces mo iterating i luga oi latou laau token ma, itu, aoina se numera o laau token i se tasi vaitafe.
///
///
/// o faasalaga uma e lua le sao ma galuega faatino lenei o `#[proc_macro]`, faamatalaga `#[proc_macro_attribute]` ma `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Ua toe maua le mea sese mai le `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Faʻafoʻi mai se avanoa `TokenStream` leai ni token laʻau.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Siaki pe afai ua avanoa lenei `TokenStream`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Taumafai e soli le manoa i tokens ma parse latou tokens i se vaitafe token.
/// Atonu e le mafai mo le tele o mafuaʻaga, mo se faʻataʻitaʻiga, pe a fai o le manoa o loʻo iai ni faʻapaleni le tutusa poʻo ni mataitusi e leʻo iai i le gagana.
///
/// Uma tokens i le parsed vaitafe maua `Span::call_site()` spans.
///
/// NOTE: o ni mea sese e ono mafua ai le panics nai lo le toe faafoʻi `LexError`.Tatou faasaoina mo le aia tatau e suia ai nei mea sese i 'LexError`s mulimuli ane.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, o le alalaupapa naʻo faʻaavanoaina `to_string`, faʻatino `fmt::Display` faʻavae i luga (o le tua o le masani ai sootaga i le va o le lua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Tutui le vaitafe token o se manoa o loo faapea e losslessly toe faaliliuina i le tasi vaitafe token (modulo spans), ae vagana ai mo mafai 'TokenTree: : Group`s ma `Delimiter::None` delimiters ma literals numeric lelei.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Lolomi token i se pepa talafeagai mo debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Fausia se token vaitafe o loʻo i ai le tasi token laʻau.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Aoina ni numera o token laau i totonu o se vaitafe e tasi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// A "flattening" taotoga i vaitafe token, aoina token laau mai vaitafe tele token i se vaitafe e tasi.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Faʻaaoga se faʻapitoa faʻaaogaina if/when mafai.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Faʻamatalaga lautele a le lautele mo le `TokenStream` ituaiga, pei o iterators.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// O se iterator i '' TokenTree`s a TokenStream`.
    /// O le iteration o "shallow", eg, o le iterator e le recurse i ni vaega delimited, ma toe foi mai le vaega atoa o laau token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` talia le faʻatulafonoina tokens ma faʻalauteleina i totonu o le `TokenStream` faʻamatalaina le sao.
/// Mo se faʻataʻitaʻiga, `quote!(a + b)` o le a gaosia se faʻamatalaga, pe a iloiloina, fausia le `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting ua maeʻa ma `$`, ma e galue i le aveina o le tasi sosoo identi o le unquoted vaitaimi.
/// Ina ia sii `$` lava, faaaoga `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// O se itulagi o le tulafono autu, faʻatasi ai ma le faʻalauteleina o le faʻamatalaga o le toner.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Fausia se `Diagnostic` fou ma le `message` foaʻi i le lautele `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// O se aga e foia i le tulaga o le faauigaga o le tonone.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// O le umi o le faʻataʻitaʻi o le taimi nei taualumaga macro.
    /// Faʻailoaina na faia ma lenei vaʻa o le a foʻia e peiseai na tusia saʻo i le macro call location (call-site hygiene) ma isi code i le macro call site o le a mafai ona faʻasino ia latou foi.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// O se aga e fai ma sui o le tumama `macro_rules`, ma o nisi taimi e fofo ai i luga o le 'upega tafaʻilagi o faʻamatalaga (fesuiaʻiga o igoa, igoa, `$crate`) ma o nisi taimi i le telefoni o le telefoni (o isi mea uma).
    ///
    /// O le vaʻaiga nofoaga e aumai mai le telefoni-nofoaga.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// O le uluai faila faila lea e faasino i ai lenei lautele.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// O le `Span` mo le tokens i le faalauteleina macro talu mai lea na faatupulaia `self` mai, pe afai ei ai.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// O le vaitaimi mo le amataga mafuaʻaga code na faia `self` mai.
    /// Afai o lenei `Span` e le i fausiaina mai isi faʻalautelega oona o lona uiga o le toe faafoi taua e tutusa ma le `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Maua le amata line/column i le faila faila mo lenei vaitaimi.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Maua le line/column faaiuina i le faila punavai mo lenei aga.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Faatupu ai se aga fou atoatoa `self` ma `other`.
    ///
    /// Faʻafoʻi `None` pe a fai `self` ma `other` e eseese faila.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Fausia se vaʻa fou ma le tutusa line/column faʻamatalaga e pei o `self` ae o lena e fofoina faʻailoga e pei ona i ai i `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Faatupu ai se aga fou ma le amio faaiuga igoa lava e tasi e pei `self` ae o le faamatalaga line/column o `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Faʻatusatusa i vasa e vaʻai pe tutusa.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Faafoi le mau puna i tua o se aga.
    /// O lenei faʻasaoina le uluaʻi punaoa faʻailoga, aofia ai avanoa ma manatu.
    /// E na o le toe foi mai o se taunuuga pe afai e tutusa ma le aga e code moni lava le faapogai.
    ///
    /// Note: O le maitauina faʻaiuga o le tonone e tatau ona faʻalagolago i le tokens ae le o lenei faʻavae tusitusiga.
    ///
    /// O le taunuuga o lenei galuega o se taumafaiga sili ona lelei e tatau ona faaaogaina mo na o diagnostics.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Tutui se aga i se faiga talafeagai mo debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// A pea laina koluma fai ma sui o le amataga po o le faaiuga o se `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Le 1-faasinoupuina laina i le faila puna lea o le aga amataina po tuluiga (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Le koluma 0-faasinoupuina (i mataitusi UTF-8) i le faila puna lea o le aga amataina po tuluiga (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// O le faila o faila o le `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Maua le ala i lenei faila puna.
    ///
    /// ### Note
    /// Afai na faatupulaia le code aga fesootai ma lenei `SourceFile` e se macro fafo, o lenei macro, e le mafai ona avea o se ala moni lenei i luga o le filesystem.
    /// Faʻaaoga le [`is_real`] e siaki ai.
    ///
    /// Ia maitau foi e tusa lava pe toe faafoʻi e `is_real` le `true`, pe a pasia le `--remap-path-prefix` i luga o le laina laina, o le auala e pei ona taua atu atonu e le moni.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Faʻafoʻi `true` pe a fai o lenei faila faila o se faila autu moni, ae le faia e se faʻalautelega o le macro i fafo.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Ole mea lea e oʻo i le faʻataʻitaʻiga seʻi vagana ua faʻataʻitaʻia vaitau faʻapitoa ma e mafai ona tatou maua faʻamaumauga moni mo spans fausia i macros fafo.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// O se tasi token po o se delimited faasologa o laau token (eg, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// O le token vaitafe o loʻo faʻataʻamilomiloina e le au faʻamavae.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// O se mea e faailoa.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Le faʻailoga toʻatasi ("+`, `,`, `$`, ma isi).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// O se uiga moni (`'a'`), manoa (`"hello"`), numera (`2.3`), ma isi
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Toe foi le aga o le laau lenei, tuuina atu i le auala `span` o le token aofia ai po o se vaitafe delimited.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Configures le aga mo *na lenei token*.
    ///
    /// Manatua afai o lenei token o le `Group` o lona uiga o lenei metotia o le a le faʻatulagaina le umi o taʻitasi tokens i totonu, o lenei o le a na faʻamatuʻu atu i le `set_span` metotia o ituaiga eseese.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Lolomi token laau i se tulaga talafeagai mo debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // O nei mea taʻitasi o loʻo iai igoa i le vaega faʻavae i le faʻamaʻimauga na maua, o lea aua le faʻalavelave i se isi faʻaopoopoga o le manava
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, o le alalaupapa naʻo faʻaavanoaina `to_string`, faʻatino `fmt::Display` faʻavae i luga (o le tua o le masani ai sootaga i le va o le lua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Lolomiina le token laau o se manoa e manatu e le mafai ona toe fesuiaʻi i tua i le tutusa token laau (modulo spans), sei vagana ai ono 'TokenTree: : Vaega`s ma `Delimiter::None` delimiters ma le lelei numera numera.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// O se vaitafe token faʻagata.
///
/// o loo i ai mai totonu A `Group` a `TokenStream` ua siomia e 'Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// O loo faamatalaina ai le auala e delimited se faasologa o laau token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// O se delimiter atoatoa, e mafai ona e faapea, mo se faataitaiga, foliga mai o loo siomia tokens sau mai se "macro variable" `$var`.
    /// E taua le faʻasaoina o mea e faʻamuamua i tagata pei o `$var * 3` o `$var` o `1 + 2`.
    /// O tagata faʻatapulaʻa faʻatamaia latou te le mafai ona sao mai le ala faʻataʻamilomilo o le token alia ala atu i se manoa.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Fausia se `Group` fou ma le tufatufaina tuʻuina atu ma token vaitafe.
    ///
    /// O lenei fausiaina o le a setiina le umi mo lenei vaega i le `Span::call_site()`.
    /// Ina ia suia le aga e mafai ona e faaaoga le auala `set_span` lalo.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Faʻafoʻi le tagata tapulaʻa o lenei `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Faʻafoʻi mai le `TokenStream` o tokens e faʻagata i lenei `Group`.
    ///
    /// Manatua o le toe faʻafoʻi token vaitafe e le aofia ai le tapulaʻa faʻafoʻi mai i luga.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Faʻafoʻi le avanoa mo le aufaʻavae o lenei token vaitafe, lautele le `Group` atoa.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Faʻafoʻi le avanoa e faʻasino i le tatalaina faʻavae o lenei vaega.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Toe foi le aga e tasi e faasino i le delimiter faaiu o lenei vaega.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Faʻatulagaina le va mo lenei 'Vaega' o tagata faʻatapulaʻaina, ae leʻo lona tokens i totonu.
    ///
    /// a **le** faatulaga lenei metotia le aga uma folasia le tokens lotoifale i lenei vaega, ae o le a na faatuina e le aga o le delimiter tokens i le tulaga o le `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, o le alalaupapa naʻo faʻaavanoaina `to_string`, faʻatino `fmt::Display` faʻavae i luga (o le tua o le masani ai sootaga i le va o le lua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Lolomiina le kulupu o se manoa e tatau ona le mafai ona toe faʻafoʻi i le vaega lava e tasi (modulo spans), seʻi vagana ai atonu o le 'TokenTree: : Group`s ma `Delimiter::None` delimiters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// o se `Punct` se uiga faailoga e tasi e pei o `+`, `-` po `#`.
///
/// O tagata faʻataʻitaʻi e pei o le `+=` o loʻo fai ma sui o lua taimi o le `Punct` ma ituaiga eseese o le `Spacing` ua faʻafoʻi mai.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Pe o le `Punct` mulimuli mai vave e le isi `Punct` pe mulimuli mai le isi token poʻo le paepae.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// eg, `+` o `Alone` i `+ =`, `+ident` po `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// eg, `+` o `Joint` i `+=` poʻo `'#`.
    /// Gata i lea, upusii tasi `'` e mafai ona auai faatasi ma faailoa atu i ituaiga olaga atoa `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Faatupu ai se `Punct` fou mai le tuuina mai e uiga po o le faavavaina.
    /// O le `ch` finauga e tatau ona avea ma faʻamaufaʻailoga tusitusi faʻatagaina faʻatagaina e le gagana, a leai o le gaioiga o le a panic.
    ///
    /// O le `Punct` toe faʻafoi mai o le a i ai le tulaga le masani o `Span::call_site()` lea e mafai ona faʻateleina configured ma le `set_span` auala i lalo.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Faʻafoʻi mai le tau o lenei faʻailoga mataʻitusi i le `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// O tupe maua o le faavavaina o lenei uiga faailoga, e faailoa pe o loo sosoo tonu e se isi `Punct` i le vaitafe token, ina ia mafai ona ono ona tuufaatasi i latou i le a faagaoioia eseese uiga (`Joint`), po o ai o loo mulimuli i se isi token po whitespace (`Alone`) ina ua i ai le faagaoioia mautinoa ua uma
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Toe afio mai le aga mo lenei uiga faailoga.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Faʻasaʻo le va mo nei faʻailoga.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, o le alalaupapa naʻo faʻaavanoaina `to_string`, faʻatino `fmt::Display` faʻavae i luga (o le tua o le masani ai sootaga i le va o le lua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tutui le faailoga tagata e pei o se manoa e tatau ona losslessly toe faaliliuina i le uiga lava lea e tasi.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Se faʻailoga (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Faatupu ai se fou `Ident` ma le tuuina `string` faapea foi ma le `span` faamaotiina.
    /// O le `string` finauga e tatau ona avea ma faʻailoga faʻapitoa faʻatagaina faʻatagaina e le gagana (aofia ai ma upu autu, eg `self` poʻo `fn`).A leai, o le a le galuega tauave panic.
    ///
    /// Manatua o `span`, o loʻo i ai nei i le rustc, faʻatulagaina le faʻamamaina o faʻamatalaga mo lenei faʻailo.
    ///
    /// E pei o lenei taimi opts-i le manino `Span::call_site()` e uiga tumama "call-site" e faailoa foafoaina ai ma lenei o le a foia aga e faapei ai na tusia saʻo i le nofoaga o le valaau macro, ma isi code i le a mafai ona le nofoaga valaau macro e faasino i i latou foi.
    ///
    ///
    /// Mulimuli ane spans pei `Span::def_site()` le a mafai ai e le a le mafai opt-i i le tumama o lona uiga e "definition-site" faailoa foafoaina ai ma lenei aga o le a tonu i le nofoaga o le faamatalaina macro ma isi code i le nofoaga valaau macro e faasino ia i latou.
    ///
    /// Ona o le taua i le taimi nei o le tumama lenei constructor, e le pei o isi tokens, e manaomia ai se `Span` e ao ona faamaoti i le fausiaina.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Tutusa ma `Ident::new`, ae fausia ai se faʻailoga e iloa ai (`r#ident`).
    /// O le avea ma finauga `string` a e faailoa aloaia ua faatagaina e le gagana (e aofia ai ma uputatala, eg `fn`).
    /// Upu autu e mafai ona faʻaaogaina i ala vaega (eg
    /// `self`, `super`) e le lagolagoina, ma o le a mafua ai le panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Toe afio mai le aga o lenei `Ident`, aofia ai le manoa atoa toe foi e [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures le aga o lenei `Ident`, atonu suia lona tulaga tumama.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, o le alalaupapa naʻo faʻaavanoaina `to_string`, faʻatino `fmt::Display` faʻavae i luga (o le tua o le masani ai sootaga i le va o le lua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tutui le e faailoa o se manoa e tatau ona losslessly toe faaliliuina i le mea e faailoa lava e tasi.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// A manoa moni (`"hello"`), byte manoa (`b"hello"`), amio (`'a'`), byte uiga (`b'a'`), o se integer po o le numera tulaga opeopea ma po e aunoa ma se suffix ('1`, `1u8`, `2.3`, `2.3f32`).
///
/// O Boolean literals pei o `true` ma `false` e leʻo iai iinei, o latou na o 'Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Fausia se fuainumera faʻatumuina integer moni ma le faʻamaoniga taua.
        ///
        /// O lenei galuega o le a faia se integer pei `1u32` ai le taua integer faamaoti mai o le vaega muamua o le token ma le taua ua suffixed foi i le iuga.
        /// O tusitusiga na fatuina mai numera le lelei e ono le mafai ona ola i le taʻamilo-malaga e oʻo atu i le `TokenStream` poʻo manoa ma e ono vaevaeina i le lua tokens (`-` ma le moni moni).
        ///
        ///
        /// Literals foafoaina e ala i lenei auala e le aga `Span::call_site()` e faaletonu, lea e mafai ona configured ai ma le auala `set_span` lalo.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Faatupuina a moni integer fou unsuffixed ma le taua ua faamaotiina.
        ///
        /// O lenei galuega o le a faia se integer pei `1` ai le taua integer faamaoti mai o le vaega muamua o le token.
        /// E leai se faʻamatalaga faʻapitoa o faʻamatalaina i luga o lenei token, o lona uiga o tatalo faʻapipiʻi pei o `Literal::i8_unsuffixed(1)` e tutusa ma `Literal::u32_unsuffixed(1)`.
        /// Literals foafoaina mai numera o le lelei e mafai ona ola rountrips ala `TokenStream` po o le manoa ma e mafai ona lepetia i le lua tokens (`-` ma moni lelei).
        ///
        ///
        /// Literals foafoaina e ala i lenei auala e le aga `Span::call_site()` e faaletonu, lea e mafai ona configured ai ma le auala `set_span` lalo.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Fausia se fou unsuffixed opeopea-manatu moni.
    ///
    /// Lenei fausia e tutusa ma na pei o `Literal::i8_unsuffixed` o le float's taua o loʻo faʻasasaʻo tuʻuina atu i le token ae leai se faʻavasegaina e faʻaaogaina, o lea e ono manatu ai o se `f64` mulimuli ane i le faʻaputuga.
    ///
    /// Literals foafoaina mai numera o le lelei e mafai ona ola rountrips ala `TokenStream` po o le manoa ma e mafai ona lepetia i le lua tokens (`-` ma moni lelei).
    ///
    /// # Panics
    ///
    /// Lenei gaioiga manaʻomia le faʻamaoti folau e gata, mo se faʻataʻitaʻiga pe afai e le iʻu poʻo NaN o lenei gaioiga o le panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Fausia se fou faʻatulagaina opeopea-manatu moni.
    ///
    /// O lenei fausiaina o le a fausia se mea moni pei o `1.0f32` lea o le tau faʻamaotiina o le muamua vaega o le token ma `f32` o le faʻapipiʻi o le token.
    /// Lenei token o le a faʻaalia i taimi uma e avea ma `f32` i le tuʻufaʻatasia.
    /// Literals foafoaina mai numera o le lelei e mafai ona ola rountrips ala `TokenStream` po o le manoa ma e mafai ona lepetia i le lua tokens (`-` ma moni lelei).
    ///
    ///
    /// # Panics
    ///
    /// Lenei gaioiga manaʻomia le faʻamaoti folau e gata, mo se faʻataʻitaʻiga pe afai e le iʻu poʻo NaN o lenei gaioiga o le panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Fausia se fou unsuffixed opeopea-manatu moni.
    ///
    /// Lenei fausia e tutusa ma na pei o `Literal::i8_unsuffixed` o le float's taua o loʻo faʻasasaʻo tuʻuina atu i le token ae leai se faʻavasegaina e faʻaaogaina, o lea e ono manatu ai o se `f64` mulimuli ane i le faʻaputuga.
    ///
    /// Literals foafoaina mai numera o le lelei e mafai ona ola rountrips ala `TokenStream` po o le manoa ma e mafai ona lepetia i le lua tokens (`-` ma moni lelei).
    ///
    /// # Panics
    ///
    /// Lenei gaioiga manaʻomia le faʻamaoti folau e gata, mo se faʻataʻitaʻiga pe afai e le iʻu poʻo NaN o lenei gaioiga o le panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Fausia se fou faʻatulagaina opeopea-manatu moni.
    ///
    /// O lenei fausiaina o le a fausia se mea moni pei o `1.0f64` lea o le tau faʻamaotiina o le muamua vaega o le token ma `f64` o le faʻapipiʻi o le token.
    /// Lenei token o le a faʻaalia i taimi uma e avea ma `f64` i le tuʻufaʻatasia.
    /// Literals foafoaina mai numera o le lelei e mafai ona ola rountrips ala `TokenStream` po o le manoa ma e mafai ona lepetia i le lua tokens (`-` ma moni lelei).
    ///
    ///
    /// # Panics
    ///
    /// Lenei gaioiga manaʻomia le faʻamaoti folau e gata, mo se faʻataʻitaʻiga pe afai e le iʻu poʻo NaN o lenei gaioiga o le panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// moni manoa.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// moni amio.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte manoa faʻatulagaina.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Toe afio mai le aga atoatoa lenei moni.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Faʻatulagaina le va fesoʻotaʻi ma lenei mea moni.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Faʻafoʻi mai le `Span` o se vaega o le `self.span()` o loʻo iai naʻo le byte o le faʻavae i le laina `range`.
    /// Faʻafoʻi `None` pe a fai o le a teuteuina le umi i fafo atu o tuaoi o `self`.
    ///
    // FIXME(SergioBenitez): siaki pe amata le pito byte ma faʻaiʻu i le UTF-8 tuaoi o le mafuaʻaga.
    // ese, e le o foliga o le a tutupu a panic o se isi nofoaga pe a lolomiina le anotusi puna.
    // FIXME(SergioBenitez): e leai se auala mo le tagata faʻaaoga e iloa ai le `self.span()` moni faʻafanua i, o lea o lenei metotia mafai nei ona valaʻauina tauaso.
    // Mo se faataitaiga, `to_string()` mo le uiga toe foi 'c' "'\u{63}'";e leai se ala mo le tagata e faaaogāina ina ia iloa pe o le mau puna o 'c' pe sa '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) se mea pei o `Option::cloned`, ae mo `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, o le alalaupapa naʻo faʻaavanoaina `to_string`, faʻatino `fmt::Display` faʻavae i luga (o le tua o le masani ai sootaga i le va o le lua).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tutui le moni e pei o se manoa e tatau ona losslessly faaliliuina toe foi atu i le moni e tasi (ae vagana ai mo lapotopoto mafai opeopea literals manatu).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Maua faʻatonutonu avanoa i siosiomaga suiga.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Toe maua se ma liuliuina siosiomaga ma faaopoopo ai le fausia o nisi faʻamatalaga faalagolago.
    /// Fausia le faiga e faʻatino ai le tagata tuʻufaʻatasia o le a iloa o le fesuiaʻiga na faʻaaogaina i le taimi o le tuʻufaʻatasiga, ma o le a mafai ona toefausia le fausiaina pe a fai o le tau o lena fesuiaʻiga suiga.
    ///
    /// E le gata i le faʻalagolago ile faʻaogaina o lenei galuega e tatau ona tutusa ma `env::var` mai le faletusi masani, seʻi vagana ai ole finauga e tatau ona UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}