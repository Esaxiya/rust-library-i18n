/// Faʻaaogaina mo faʻavasegaina gaioiga (`container[index]`) i suiga le mafaamatalaina.
///
/// `container[index]` e moni syntactic suka mo `*container.index(index)`, ae na o le taimi e faʻaaogaina ai o se le suia soʻo se tau.
/// Afai o se mutable aoga e talosagaina, [`IndexMut`] ua faʻaaoga nai lo.
/// O lenei e mafai ai mea lelei e pei o `let value = v[index]` pe afai o le ituaiga o `value` faatino [`Copy`].
///
/// # Examples
///
/// O le faʻataʻitaʻiga lea e faʻaaogaina le `Index` i luga o le fagu faitau-naʻo le `NucleotideCount` container, e mafai ai ona maua mai le faitauga a le tagata lava ia i le index index.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Le ituaiga na toe faafoi mai ina ua uma le faasino igoa.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Faʻatautaia le faʻasino igoa (`container[index]`) gaioiga.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Faʻaaogaina mo faʻavasegaina gaioiga (`container[index]`) i suiga suia.
///
/// `container[index]` e moni syntactic suka mo `*container.index_mut(index)`, ae na o le taimi e faʻaaogaina ai o se fesuiaiga taua.
/// Afai e talosagaina se tau le suia, o le [`Index`] trait o loʻo faʻaaogaina.
/// O lenei faʻatagaina mea manaia e pei o `v[index] = value`.
///
/// # Examples
///
/// O se faʻafaigofieina faʻatinoina o le `Balance` faʻavae e i ai ona itu e lua, lea e mafai ai ona faʻavasega faʻasolosolo ma le suia.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // I lenei tulaga, `balance[Side::Right]` o suka mo `*balance.index(Side::Right)`, talu ai ua naʻo matou* faitau * `balance[Side::Right]`, le tusia.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Peitai, i lenei tulaga `balance[Side::Left]` o suka mo `*balance.index_mut(Side::Left)`, talu ai o loʻo matou tusia `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Faʻatautaia le gaioiga o faʻagaioiga (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}