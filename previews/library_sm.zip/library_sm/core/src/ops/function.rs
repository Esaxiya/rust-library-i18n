/// O le vaega o le telefoni faʻatonu e ave se le mafai ona suia.
///
/// Faʻamatalaga o `Fn` mafai ona valaʻauina soʻo e aunoa ma le suia o le setete.
///
/// *Lenei trait (`Fn`) e le tatau ona fenumiai ma [function pointers] (`fn`).*
///
/// `Fn` e faʻatino otometi lava e ala i tapunia lea e naʻo le le toe suia faʻasino i pueina fesuiaʻiga pe le puʻeina se mea uma, faʻapea foi ma (safe) [function pointers] (faʻatasi ai ma ni lapataiga, vaʻai a latou faʻamaumauga mo nisi faʻamatalaga).
///
/// E le gata i lea, mo soʻo se ituaiga `F` e faʻaaoga `Fn`, `&F` faʻaaoga `Fn` foi.
///
/// Talu ai o [`FnMut`] ma [`FnOnce`] o supertraits o `Fn`, soʻo se faʻataʻitaʻiga o le `Fn` e mafai ona faʻaaogaina o se parakalafa e faʻamoemoeina ai le [`FnMut`] poʻo le [`FnOnce`].
///
/// Faʻaaoga le `Fn` e pei o se noataga pe a e manaʻo e talia se faʻailoga o le ituaiga o faʻagaioiga ma e manaʻomia ona valaʻau pea ma aunoa ma le suia o tulaga (eg, pe a faʻaigoa faʻatasi).
/// Afai e te le manaʻomia ni aiaiga taua, faʻaaoga le [`FnMut`] poʻo le [`FnOnce`] o ni tuaoi.
///
/// Vaʻai le [chapter on closures in *The Rust Programming Language*][book] mo nisi faʻamatalaga e uiga i lenei mataupu.
///
/// Faʻapea foi ma le maitau o le faʻapitoa faʻamatalaga mo `Fn` traits (eg
/// `Fn(usize, bool) -> faʻaaoga`).O i latou e fiafia i faʻamatalaga faʻapitoa o lenei e mafai ona faʻasino i le [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Valaʻauina se tapunia
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Le faaaogaina o se parameter `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ina ia mafai regex mafai faʻalagolago lena `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Faia le taʻotoga o taʻavale.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// O le lomiga o le telefoni feaveaʻi e manaʻomia se fesuiaʻiga o masini.
///
/// Faʻamatalaga o `FnMut` mafai ona valaʻauina soʻo ma ono suia le setete.
///
/// `FnMut` e faʻaaogaina otometi lava e ala i tapunia e manaʻomia ai ni suiga i ituaiga fesuiaʻi, faʻapea foʻi ma ituaiga uma e faʻaaogaina le [`Fn`], faʻapea, (safe) [function pointers] (talu ai o le `FnMut` o se supertrait o le [`Fn`]).
/// E le gata i lea, mo soʻo se ituaiga `F` e faʻaaoga `FnMut`, `&mut F` faʻaaoga `FnMut` foi.
///
/// Talu ai [`FnOnce`] o se supertrait o `FnMut`, soʻo se faʻataʻitaʻiga o `FnMut` mafai ona faʻaaogaina i le mea o loʻo fuafuaina le [`FnOnce`], ma talu ai o [`Fn`] o se subtrait o `FnMut`, soʻo se faʻataʻitaʻiga o [`Fn`] e mafai ona faʻaaogaina i le mea o loʻo fuafuaina `FnMut`.
///
/// Faʻaaoga le `FnMut` o se noataga pe a e manaʻo e talia se faʻailoga o le ituaiga-pei o ituaiga ma manaʻomia ona valaʻau pea, ae faʻatagaina ia suia le setete.
/// Afai e te le manaʻomia le parakalafa e suia tulaga, faʻaaoga [`Fn`] o se noataga;pe afai e te le manaomia ona e valaau i ai pea lava pea, faaaoga [`FnOnce`].
///
/// Vaʻai le [chapter on closures in *The Rust Programming Language*][book] mo nisi faʻamatalaga e uiga i lenei mataupu.
///
/// Faʻapea foi ma le maitau o le faʻapitoa faʻamatalaga mo `Fn` traits (eg
/// `Fn(usize, bool) -> faʻaaoga`).O i latou e fiafia i faʻamatalaga faʻapitoa o lenei e mafai ona faʻasino i le [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Valaʻau se mutable puʻeina tapunia
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Faʻaaogaina o le `FnMut` parameter
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ina ia mafai regex mafai faʻalagolago lena `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Faia le taʻotoga o taʻavale.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// O le lomiga o le telefoni feaveaʻi e na te mauaina le aoga o le tagata e taliaina.
///
/// Faʻamatalaga o `FnOnce` mafai ona valaʻauina, ae ono le mafai ona valaʻauina i le tele o taimi.Ona o lenei, afai na o le pau le mea e iloa e uiga i se ituaiga o lona faʻaaogaina `FnOnce`, e mafai ona na o le tasi valaʻauina.
///
/// `FnOnce` e faʻatinoina otometi e ala i tapunia e ono faʻaumatia ai fesuiaʻiga fesuiaʻi, faʻapea foi ma ituaiga uma o loʻo faʻatinoina [`FnMut`], eg, (safe) [function pointers] (talu ai `FnOnce` o se supertrait o [`FnMut`]).
///
///
/// Talu ai o [`Fn`] ma [`FnMut`] o subtraits o `FnOnce`, soʻo se faʻataʻitaʻiga o [`Fn`] poʻo [`FnMut`] e mafai ona faʻaaogaina i le mea e faʻamoemoeina ai le `FnOnce`.
///
/// Faʻaaoga le `FnOnce` o se noataga pe a e manaʻo e talia se faʻailoga o le ituaiga-pei o ituaiga ma naʻo le manaʻomia e valaʻau tasi.
/// Afai e te manaʻo e valaʻau pea i le parameter, faʻaaoga le [`FnMut`] o se noataga;afai e te manaʻomia foi e aua le suia tulaga, faʻaaoga [`Fn`].
///
/// Vaʻai le [chapter on closures in *The Rust Programming Language*][book] mo nisi faʻamatalaga e uiga i lenei mataupu.
///
/// Faʻapea foi ma le maitau o le faʻapitoa faʻamatalaga mo `Fn` traits (eg
/// `Fn(usize, bool) -> faʻaaoga`).O i latou e fiafia i faʻamatalaga faʻapitoa o lenei e mafai ona faʻasino i le [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Faʻaaogaina o le `FnOnce` parameter
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` faʻaumatia ana puʻeina puʻeina, o lea e le mafai ai ona toe tamoʻe faʻatasi.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // O le taumafai e toe faʻaulu le `func()` o le a togiina se `use of moved value` mea sese mo `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` le mafai ona toe faʻaaogaina i lenei taimi
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ina ia mafai regex mafai faʻalagolago lena `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Le ituaiga toe foʻi mai pe a maeʻa ona faʻaaogaina le call operator.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Faia le taʻotoga o taʻavale.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}