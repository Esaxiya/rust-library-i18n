/// Faʻaaogaina mo le fesuiaʻiina gaioiga faʻagaioiga, pei o `*v`.
///
/// I le faʻaopopoga i le faʻaaogaina mo le manino faʻamalamalamaga faʻagaioiga ma le (unary) `*` tagata faʻagaioia i suiga le tumau, `Deref` o loʻo faʻaaoga faʻapitoa foi e le tagata tuʻufaʻatasia i le tele o tulaga.
/// O lenei masini e taʻua o le ['`Deref` coercion'][more].
/// I suiga suia, [`DerefMut`] e faʻaaogaina.
///
/// Faʻaaʻoga `Deref` mo atamai atamai faʻafaigofieina faʻaaogaina o faʻamatalaga i tua atu o latou faigofie, ma o le mafuaʻaga na latou faʻaogaina ai `Deref`.
/// I leisi itu, o tulafono e faʻatatau i le `Deref` ma le [`DerefMut`] na fuafuaina faapitoa lava e faʻafesoʻotaʻi atu ai faʻailoga atamai.
/// Ona o lenei,**'Deref` e tatau ona faʻatinoina mo atamamai tusi** e aloese ai mai le le mautonu.
///
/// Mo mafuaʻaga tutusa,**lenei trait e le tatau ona toilalo**.O le le mafai i le taimi o le dereferencing e mafai ona matua fenumiai lava pe a oʻo i le `Deref` e faʻaaoga faʻapitoa.
///
/// # Sili atu ile `Deref` faamalosia
///
/// Afai e faatino `T` `Deref<Target = U>`, ma `x` o se taua o ituaiga `T`, lea:
///
/// * I faʻavasegaga faʻavasega, `*x` (o le `T` e leʻo se faʻasino poʻo se faʻasino tusi) e tutusa ma `* Deref::deref(&x)`.
/// * Taua o le ituaiga `&T` o loʻo faʻamalosia i le taua o le ituaiga `&U`
/// * `T` faʻaoga faʻatino uma (immutable) metotia o le ituaiga `U`.
///
/// Mo nisi faʻamatalaga, asiasi i le [the chapter in *The Rust Programming Language*][book] faʻapea foʻi ma vaega o faʻamatalaga i luga o le [the dereference operator][ref-deref-op], [method resolution] ma le [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// O se faʻavae ma se fanua e tasi e mafai ona maua e ala i le faʻamamaina o le vaega.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// O le taunuuga o ituaiga ina ua uma dereferencing.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Faʻaleaogaina le tau.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Faʻaaogaina mo mutable dereferencing gaioiga, pei o `*v = 1;`.
///
/// I le faʻaopopoga i le faʻaaogaina mo le manino faʻamalamalamaga faʻagaioiga ma le (unary) `*` tagata faʻagaioia i suiga suiga, `DerefMut` o loʻo faʻaaoga faʻapitoa foi e le tagata tuʻufaʻatasia i le tele o tulaga.
/// O lenei masini e taʻua o le ['`Deref` coercion'][more].
/// I faʻavasegaga faʻavasega, [`Deref`] e faʻaaogaina.
///
/// Faʻaaʻoga `DerefMut` mo poto atamamai faia mutating le faʻamatalaga i tua atu o latou faigofie, o le mafuaʻaga na latou faʻatinoina `DerefMut`.
/// I leisi itu, o tulafono e faʻatatau i le [`Deref`] ma le `DerefMut` na fuafuaina faapitoa lava e faʻafesoʻotaʻi atu ai faʻailoga atamai.
/// Ona o lenei,**'DerefMut` e tatau ona faʻatinoina mo atamamai tusi** e aloese ai mai le le mautonu.
///
/// Mo mafuaʻaga tutusa,**lenei trait e le tatau ona toilalo**.O le le mafai i le taimi o le dereferencing e mafai ona matua fenumiai lava pe a oʻo i le `DerefMut` e faʻaaoga faʻapitoa.
///
/// # Sili atu ile `Deref` faamalosia
///
/// Afai `T` faʻaaogaina `DerefMut<Target = U>`, ma `x` o se taua o le ituaiga `T`, ona:
///
/// * I suiga suia, `*x` (o le `T` e leʻo se faʻasino poʻo se faʻasino tonu) e tutusa ma `* DerefMut::deref_mut(&mut x)`.
/// * Taua o le ituaiga `&mut T` o loʻo faʻamalosia i le taua o le ituaiga `&mut U`
/// * `T` faʻaoga faʻatino uma (mutable) metotia o le ituaiga `U`.
///
/// Mo nisi faʻamatalaga, asiasi i le [the chapter in *The Rust Programming Language*][book] faʻapea foʻi ma vaega o faʻamatalaga i luga o le [the dereference operator][ref-deref-op], [method resolution] ma le [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// O se faʻavae ma se fanua e tasi e mafai ona toe faʻaleleia e ala i le faʻamamaina o le vaega.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// E mafai ona suia le taua.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Faʻailoa o se faʻavae mafai ona faʻaaogaina o se metotia faʻataʻitaʻi, aunoa ma le `arbitrary_self_types` foliga.
///
/// Lenei o loʻo faʻatinoina e stdlib faʻasino ituaiga pei `Box<T>`, `Rc<T>`, `&T`, ma `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}