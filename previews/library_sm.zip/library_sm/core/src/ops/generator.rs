use crate::marker::Unpin;
use crate::pin::Pin;

/// O le iʻuga o le toe faʻaolaolaina o afi.
///
/// Lenei enum ua toe faʻafoʻi mai le `Generator::resume` metotia ma faʻailoa mai le ono toe faʻafoi taua o se afi.
/// I le taimi nei e faʻatatau lenei i le tasi le taofiofi (`Yielded`) poʻo le faʻamutaina (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// O le afi afi na faʻamalolo ma se tau.
    ///
    /// Lenei setete faʻailoa mai o le afi afi ua faʻamalolo, ma masani ona tutusa ma le `yield` faʻamatalaga.
    /// O le tau aoga i lenei eseʻesega e tutusa ma le faʻaaliga pasia i le `yield` ma faʻatagaina ai afi eletise e tuʻuina atu se tau i taimi uma latou te maua ai.
    ///
    ///
    Yielded(Y),

    /// Na maeʻa le afi eletise ma le tau faʻafoi mai.
    ///
    /// Lenei setete faʻailoa mai o se afi ua maeʻa faʻatinoina ma le taua taua.
    /// O le taimi na toe faʻafoʻi mai ai e le generator le `Complete` ua manatu ai o se polokalame e sese le toe valaʻauina o le `resume`.
    ///
    Complete(R),
}

/// O le trait faʻatinoina e builtin afi ituaiga.
///
/// Generators, e masani foi ona taʻua o coroutines, o loʻo avea nei ma faʻataʻitaʻiga gagana vaega i le Rust.
/// Faʻaopopoina i [RFC 2033] afi eletise o loʻo faʻamoemoeina nei e tuʻuina mai se poloka fale mo async/await syntax ae o le a ono faʻalauteleina i le sauniaina o se ergonomic faʻauiga mo iterators ma isi muamua.
///
///
/// O le syntax ma semantics mo afi eletise e le mautonu ma o le a manaʻomia se isi RFC mo faʻamautuina.I lenei taimi, e ui i lea, o le syntax e tapunia-pei:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Tele faʻamaumauga o afi eletise e mafai ona maua i le tusi le mautonu.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Le ituaiga aoga e maua mai ai lenei afi.
    ///
    /// O lenei ituaiga fesoʻotaʻi e tutusa ma le faʻaaliga `yield` ma faʻatauaina ia e faʻatagaina ona toe faʻafoʻi i taimi uma e maua ai se afi eletise.
    ///
    /// Mo se faʻataʻitaʻiga o le iterator-as-a-generator e ono i ai lenei ituaiga o `T`, o le ituaiga ua faʻasolosolo faʻasolosolo.
    ///
    type Yield;

    /// Le ituaiga o taua e toe foi mai lenei afi.
    ///
    /// E tutusa lea ma le ituaiga na toe faʻafoʻi mai se generator a le o le `return` faʻamatalaga poʻo le faʻaalia o se faʻauiga mulimuli o le generator moni.
    /// Mo se faʻataʻitaʻiga o le futures o le a faʻaaogaina lenei e avea ma `Result<T, E>` ona o se sui o se maeʻa future.
    ///
    ///
    type Return;

    /// Toe faʻaauau le faʻatinoina o lenei afi eletise.
    ///
    /// le a faaauau lenei galuega tauave i le faatinoga o le afi po o le amata faatinoina pe afai ei ai le ua.
    /// O lenei valaʻau o le a toe foʻi mai i le generator's mulimuli faʻamalolo tumau, toe amata le faʻatinoina mai le lata mai `yield`.
    /// O le afi eletise o le a faʻaauau pea faʻagaioia seʻia oʻo ina fua pe toe faʻafoʻi mai, i le taimi lea o lenei galuega toe foʻi.
    ///
    /// # Toe faafoi taua
    ///
    /// O le `GeneratorState` enum na toe faʻafoʻi mai i lenei galuega, ua faʻailoa mai ai le tulaga o loʻo i ai le afi eletise pe a toe foʻi mai.
    /// Afai o le `Yielded` variant ua toe faʻafoʻi mai loa o le generator ua oʻo i se tulaga faʻamalolo ma ua maua se tau aoga.
    /// O afi eletise i lenei setete e avanoa mo le toe amataina i se taimi mulimuli ane.
    ///
    /// Afai ua toe foi `Complete` lea o le afi ua atoatoa uma i le taua ua tuuina atu.E le aoga mo le afi ona toe amataina.
    ///
    /// # Panics
    ///
    /// Lenei gaioiga ono panic pe a fai e valaʻau pe a maeʻa le `Complete` variant na toe faʻafoʻi mai muamua.
    /// E ui o le generator literals i le gagana e mautinoa i le panic pe a toe amataina peʻa maeʻa le `Complete`, e le o mautinoa lea mo faʻagaioiga uma o le `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}