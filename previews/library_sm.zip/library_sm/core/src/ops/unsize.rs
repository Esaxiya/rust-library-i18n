use crate::marker::Unsize;

/// Trait o loʻo faʻailoa mai ai ose faʻasino poʻo se mea afifi mo le tasi, e mafai ai ona faia le faʻamautuina i luga o le pointee.
///
/// Vaʻai le [DST coercion RFC][dst-coerce] ma le [the nomicon entry on coercion][nomicon-coerce] mo nisi faʻamatalaga.
///
/// Mo ituaiga faʻatulagaina o faʻailoga, o faʻasino i le `T` o le a faʻamalosia i faʻasino i le `U` pe a fai o le `T: Unsize<U>` e ala i le faʻaliliuina mai se mea manifinifi faʻasino i le gaʻo tusi.
///
/// Mo ituaiga masani, o le faʻamalosi iinei e galue e ala i le faʻamalosi `Foo<T>` i le `Foo<U>` maua ai le impl o `CoerceUnsized<Foo<U>> for Foo<T>` i ai.
/// O sea mea e faʻatoa mafai ona tusia pe a fai o `Foo<T>` e naʻo le tasi le non-phantomdata fanua e aʻafia ai `T`.
/// Afai o le ituaiga o lena fanua o `Bar<T>`, o le faʻatinoina o `CoerceUnsized<Bar<U>> for Bar<T>` tatau ona i ai.
/// O le faamalosia o le a galue e ala i le faamalosia o le `Bar<T>` fanua i `Bar<U>` ma faatumuina le toega o le fanua mai `Foo<T>` e fausia ai se `Foo<U>`.
/// Lenei o le a aoga vili i lalo i se faʻasino fanua ma faʻamalosi lena.
///
/// E masani lava, mo faʻasino poto e te faʻaaogaina le `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, ma le filifiliga `?Sized` fusifusia ia `T` lava ia.
/// Mo ituaiga afifi e tuʻu saʻo `T` pei `Cell<T>` ma `RefCell<T>`, oe mafai tuʻu faʻatino `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Lenei o le a faʻamalosia ai faʻamalosi o ituaiga pei o `Cell<Box<T>>` galue.
///
/// [`Unsize`][unsize] e faʻaaoga e maka ai ituaiga ia e mafai ona faʻamalosia i DST peʻa i tua atu o faʻasino.E faatinoina otometi lava e ala i le tuufaatasia.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * faavae U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* faʻavae U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// E faʻaaogaina lenei mea mo le saogalemu o mea, e siaki ai a le auala e talia ai le ituaiga e mafai ona lafoina i luga.
///
/// O se faʻataʻitaʻiga faʻatinoina o le trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* faʻavae U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}