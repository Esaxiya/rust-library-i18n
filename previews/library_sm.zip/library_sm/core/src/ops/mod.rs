//! e faagaoioia Overloadable.
//!
//! Faʻatinoina nei traits faʻatagaina oe e soʻona faʻatauaina nisi faʻagaioiga.
//!
//! O nisi o nei traits o loʻo aumai e le prelude, o lea e avanoa ai latou i polokalame uma a le Rust.Naʻo 'auʻaunaga lagolagoina e traits e mafai ona ova.
//! Mo se faʻataʻitaʻiga, o le faʻaopopoina (`+`) mafai ona ova i luga o le [`Add`] trait, ae talu ai o le tagata faʻatonu (`=`) e leai se lagolagosua trait, e leai se auala e soona soʻona ana semantics.
//! E le gata i lea, o lenei vaega e le maua ai se auala e fausia ai ni tagata fou.
//! A faʻapea e manaʻomia se soʻoga soʻoga poʻo ni tagata faʻataʻitaʻi, e tatau ona e vaʻai atu i macros poʻo plugins plugins e faʻalautele ai le syntax a le Rust.
//!
//! Faʻatinoga o le faʻagaioiga traits e tatau ona le faʻateʻia i a latou talaʻaga, ma ia manatua o latou uiga masani ma le [operator precedence].
//! Mo se faʻataʻitaʻiga, pe a faʻatinoina le [`Mul`], o le faʻagaioiga e tatau ona i ai ni foliga tutusa i le faʻateleina (ma fefaʻasoaaʻi meatotino fuafuaina e pei o vavalalata).
//!
//! Manatua o le `&&` ma le `||` faʻagaioia auala-puʻupuʻu, o lona uiga, latou na o le iloiloina o la latou operand lona lua pe a fai e fesoasoani i le iʻuga.Talu ai o lenei amio e le mafai ona faʻamalosia e traits, `&&` ma `||` e le lagolagoina o ni tagata soʻona faʻaaogaina.
//!
//! Tele o le au faʻagaioia latou te faʻaaogaina a latou taʻaloga i le tau.I faʻamanuiaga e le masani ai e aofia ai ituaiga fale, e masani lava e leʻo se faʻafitauli.
//! Ae ui i lea, o le faʻaaogaina o nei mea faʻataʻitaʻi i le tulafono lautele, e manaʻomia ai se faʻalogo pe a fai e tatau ona toe faʻaaoga tulaga taua nai lo le tuʻuina i le au faʻatonu e faʻaumatia latou.Tasi le filifiliga o le faʻaoga lea o le [`clone`].
//! O le isi filifiliga o le faʻalagolago i ituaiga e aofia ai le faʻaopopoina faʻaopoopoina o mea e faʻatinoina mo faʻatonuga.
//! Mo se faataitaiga, mo se tagata e faaaogāina-faamatalaina ituaiga `T` lea e tatau ona lagolago gata i lea, atonu o se manatu lelei le i ai uma `T` ma `&T` faatino ina traits [`Add<T>`][`Add`] ma [`Add<&T>`][`Add`] e mafai ona tusia code lautele e aunoa cloning manaomia.
//!
//!
//! # Examples
//!
//! Lenei faʻataʻitaʻiga fausiaina se `Point` faʻavae e faʻaaogaina [`Add`] ma [`Sub`], ona faʻaalia ai le faʻaopopoina ma toʻesea lua `Point '.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Vaʻai faʻamaumauga mo trait taʻitasi mo se faʻataʻitaʻiga faʻatinoina.
//!
//! O le [`Fn`], [`FnMut`], ma le [`FnOnce`] traits o loʻo faʻatinoina e ituaiga e mafai ona valaauina pei o galuega.Manatua o [`Fn`] ave `&self`, [`FnMut`] ave `&mut self` ma [`FnOnce`] ave `self`.
//! O nei e fesoʻotaʻi ma le tolu ituaiga o auala e mafai ona valaʻauina i luga o se faʻataʻitaʻiga: telefoni-i-le faʻasino, valaʻau-i-mutable-faʻasino, ma valaʻau-i-le taua.
//! O le faʻaaogaga masani o nei traits o le amio faʻatapulaʻaina i galuega maualuluga e faia galuega poʻo ni tapunia e avea o ni finauga.
//!
//! O le a [`Fn`] o se parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Aveina o le [`FnMut`] o se parakalafa:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Aveina o le [`FnOnce`] o se parakalafa:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` faʻaumatia ana puʻeina puʻeina, o lea e le mafai ai ona toe tamoʻe faʻatasi
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // O le taumafai e toe faʻaulu le `func()` o le a togiina se `use of moved value` mea sese mo `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` le mafai ona toe faʻaaogaina i lenei taimi
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;