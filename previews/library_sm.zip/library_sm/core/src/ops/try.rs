/// A trait mo aganuu amioga a le `?` tagata faʻagaioia.
///
/// O le ituaiga faʻaaogaina `Try` o se tasi e i ai se kanonical auala e vaʻai ai i tulaga o le success/failure dichotomy.
/// Lenei trait faʻatagaina uma toʻesea mai na manuia poʻo le faʻatauaina taua mai se taimi nei faʻataʻitaʻiga ma le fausiaina o se fou faʻataʻitaʻiga mai se manuia poʻo se faʻamanuiaga aoga.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Le ituaiga o lenei taua pe a vaʻaia ua alualu i luma.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// O le ituaiga o lenei aoga pe a vaʻaia ua le manuia.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Faʻaoga le "?" operator.O le toe foʻi mai o le `Ok(t)` o lona uiga o le faʻataunuʻuina e tatau ona faʻaauauina masani, ma o le iʻuga o le `?` o le taua `t`.
    /// O le toe foʻi mai o le `Err(e)` o lona uiga o le faʻatinoga tatau branch i le pito i totonu o le `catch`, pe toe foʻi mai le gaioiga.
    ///
    /// Afai o le `Err(e)` iʻuga ua toe faʻafoʻi mai, o le tau `e` o le a avea "wrapped" i le toe foʻi ituaiga o le tapunia tulaga (lea e tatau ona ia faʻatinoina `Try`).
    ///
    /// Faapitoa, o le taua e toe foi `X::from_error(From::from(e))`, lea `X` o le toe foi mai ituaiga o le galuega tauave enclosing.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Afifi se mea sese aoga e fausia ai le tuʻufaʻatasiga taunuʻuga.
    /// Mo se faʻataʻitaʻiga, `Result::Err(x)` ma `Result::from_error(x)` e tutusa.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Afifi se tau lelei OK e fausia le tuʻufaʻatasiga iʻuga.
    /// Mo se faʻataʻitaʻiga, `Result::Ok(x)` ma `Result::from_ok(x)` e tutusa.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}