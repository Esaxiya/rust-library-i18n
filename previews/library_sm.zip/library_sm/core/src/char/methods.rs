//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Le numera sao aoga maualuga a `char` mafai ona maua.
    ///
    /// A `char` o se [Unicode Scalar Value], o lona uiga o se [Code Point], ae nao i latou i totonu o se vaega faapitoa.
    /// `MAX` o le pito sili ona aoga numera numera o le [Unicode Scalar Value] aoga.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () o loʻo faʻaaogaina i le Unicode e fai ma sui o se decoding sese.
    ///
    /// E mafai ona tupu, mo se faʻataʻitaʻiga, pe a tuʻuina atu UTF-8 bytes leaga i [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Le faʻamatalaga ole [Unicode](http://www.unicode.org/) o loʻo faʻavae i luga ole Unicode vaega ole `char` ma le `str`.
    ///
    /// Fou lomiga o Unicode e faʻasaolotoina masani ma mulimuli ane uma metotia i le tulaga potutusi faʻalagolago i le Unicode ua faʻafouina.
    /// O le mea lea o amioga a nisi `char` ma `str` metotia ma le aoga o lenei faifai pea suiga ile taimi.
    /// Lenei *e le* manatu o se solia suiga.
    ///
    /// O le numera numera numera polokalame o loʻo faʻamatalaina ile [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Fausia se iterator i luga o le UTF-16 encoded code togi i le `iter`, faʻafoʻi le faʻaluaina sui o 'Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// e mafai ona maua se decoder lossy i le suia taunuuga `Err` ma le uiga o le suia:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Faʻaliliu se `u32` i le `char`.
    ///
    /// Manatua e aoga uma 'char`s [' u32`] s, ma e mafai ona tuli e le tasi i le
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// E ui i lea, e le saʻo le tua: e le aoga uma [`u32`] s e aoga i le 'char`s.
    /// `from_u32()` o le a toe faafoi `None` pe a fai o le sao e le o se aoga aoga mo le `char`.
    ///
    /// Mo se lomiga saogalemu o lenei galuega tauave lea e amanaia nei siaki, tagai [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Toe foi `None` pe le sao e le o se aoga `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Faʻaliliua se `u32` i le `char`, le amanaʻiaina le aoga.
    ///
    /// Manatua e aoga uma 'char`s [' u32`] s, ma e mafai ona tuli e le tasi i le
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// E ui i lea, e le saʻo le tua: e le aoga uma [`u32`] s e aoga i le 'char`s.
    /// `from_u32_unchecked()` o le a le amanaʻiaina lenei, ma faʻafefe lafoina i le `char`, atonu fausiaina se le atoatoa.
    ///
    ///
    /// # Safety
    ///
    /// O lenei galuega o le saogalemu, e pei ona fausia faatauaina faalēaogāina `char`.
    ///
    /// Mo se saogalemu faʻamaumauga o lenei gaioiga, vaʻai i le [`from_u32`] gaioiga.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SAOGALEMU: e tatau ona lagolagoina le konekarate le saogalemu e ala i le telefoni.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Faʻaliliuga se numera i le leata fesoʻotaʻi i le `char`.
    ///
    /// O le 'radix' iinei e taʻua foi o le 'base'.
    /// A radix o lua e faailoa ai le numera binary, o se radix o sefulu, decimal, ma a radix o le sefulu ma le ono, hexadecimal, e tuuina atu nisi o tulaga faatauaina e tutusa ai.
    ///
    /// O loʻo lagolagoina radices faʻapitoa.
    ///
    /// `from_digit()` o le a toe faafoi `None` pe a fai o le sao e le o se numera i le leitio tuuina atu.
    ///
    /// # Panics
    ///
    /// Panics pe a fai e maua le radix sili atu ile 36.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimal 11 o se digit tasi i faavae 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Faʻafoʻi `None` pe a fai o le sao e le o se numera:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Tufaina a radix tele, na mafua ai se panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Siaki pe a fai o le `char` o se numera i le leitio tuuina atu.
    ///
    /// O le 'radix' iinei e taʻua foi o le 'base'.
    /// A radix o lua e faailoa ai le numera binary, o se radix o sefulu, decimal, ma a radix o le sefulu ma le ono, hexadecimal, e tuuina atu nisi o tulaga faatauaina e tutusa ai.
    ///
    /// O loʻo lagolagoina radices faʻapitoa.
    ///
    /// Faʻatusatusa i le [`is_numeric()`], o lenei gaioiga e naʻo le iloa o mataitusi `0-9`, `a-z` ma le `A-Z`.
    ///
    /// 'Digit' ua faʻamatalaina naʻo mataʻitusi nei:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Mo se malamalamaaga atili o le 'digit', vaʻai [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics pe a fai e maua le radix sili atu ile 36.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Tufaina a radix tele, na mafua ai se panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Faʻaliliuina le `char` i le numera i le leitio faʻaali.
    ///
    /// O le 'radix' iinei e taʻua foi o le 'base'.
    /// A radix o lua e faailoa ai le numera binary, o se radix o sefulu, decimal, ma a radix o le sefulu ma le ono, hexadecimal, e tuuina atu nisi o tulaga faatauaina e tutusa ai.
    ///
    /// O loʻo lagolagoina radices faʻapitoa.
    ///
    /// 'Digit' ua faʻamatalaina naʻo mataʻitusi nei:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Faʻafoʻi `None` pe a fai o le `char` e le faʻasino i se numera i le leitio ua tuʻuina atu.
    ///
    /// # Panics
    ///
    /// Panics pe a fai e maua le radix sili atu ile 36.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Tufaina o se le-numera iʻuga i le le manuia:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Tufaina a radix tele, na mafua ai se panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // le code ua vaeluaina i luga nei e faaleleia ai le faatinoga saosaoa mo tulaga pe afai e faifai pea le `radix` ma le 10 po o le laiti
        //
        let val = if likely(radix <= 10) {
            // Afai e le o se numera, o le numera sili atu nai lo le radix o le a fausiaina.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Toe foi se iterator e aumaia ai le sola ese hexadecimal Unicode o se uiga e pei 'char`s.
    ///
    /// Lenei o le a sosola ese faʻailoga ma le Rust syntax o le fomu `\u{NNNNNN}` i le `NNNNNN` o se faʻaopopo hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// I le avea ai ma se faʻaiuga:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Faʻaaoga saʻo `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// e tutusa uma e lua:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Faʻaaogaina `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // po o le ¯ 1 mautinoa ai mo c==0 le code computes e tatau ona lomia digit tasi ma le (o le tasi) aloese le (31, 32) underflow
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // le faasino upu o le digit hex taua sili ona
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// O se faʻalautelega o le `escape_debug` o loʻo faʻatagaina ona sola ese mai Extap Grapheme codepoints.
    /// Lenei e faʻatagaina ai matou ona faʻatulaga lelei mataitusi e pei o le le faʻaaogaina o faʻailoga pe a latou i le amataga o se manoa.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Faʻafoʻi mai se faʻamaufaʻailoga e maua ai le sao tonu o le amio o se amio pei o le 'char`s.
    ///
    /// Lenei o le a sosola ese mai mataitusi e tutusa ma le `Debug` faʻatinoina o `str` poʻo `char`.
    ///
    ///
    /// # Examples
    ///
    /// I le avea ai ma se faʻaiuga:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Faʻaaoga saʻo `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// e tutusa uma e lua:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Faʻaaogaina `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Faʻafoʻi mai se faʻamaufaʻailoga e maua ai le sao tonu o le amio o se amio pei o le 'char`s.
    ///
    /// O le faaletonu e filifilia ma le faʻaituau i le gaosiaina o tusitusi o loʻo faʻatulafonoina i gagana eseese, e aofia ai le C++ 11 ma isi gagana C-aiga.
    /// O tulafono tonu lava o:
    ///
    /// * Tab ua sola ese o le `\t`.
    /// * Ua toe sola le toe foʻi ile taʻavale e pei o le `\r`.
    /// * O laina laina ua sola ese mai o le `\n`.
    /// * Nofofua upusii ua sola ese o le `\'`.
    /// * Faʻalua le upusii ua sola ese o le `\"`.
    /// * Backslash ua sola ese o le `\\`.
    /// * Soʻo se amio i le 'lolomiina ASCII' laina `0x20` .. `0x7e` aofia ai e le sola ese.
    /// * O isi mataitusi uma e ave iai le hexadecimal Unicode sosola ese;vaʻai [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// I le avea ai ma se faʻaiuga:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Faʻaaoga saʻo `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// e tutusa uma e lua:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Faʻaaogaina `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Faʻafoʻi mai le numera o bytes e manaʻomia e lenei `char` pe a fai o faʻailoga i le UTF-8.
    ///
    /// O lena numera o bytes e masani ona i le va o le 1 ma le 4, aofia ai.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// O le `&str` faamaonia ituaiga e UTF-8 ai i totonu, ma o lea e mafai ona tatou faatusaina o le umi o le a faia pe afai e sui tulaga code taitasi o se `char` vs i le `&str` lava:
    ///
    ///
    /// ```
    /// // e pei chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // e mafai uma ona fai ma sui o le tolu paita
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // o se &str, nei e lua o loo encoded i UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // e mafai ona tatou vaʻai atu latou te aveina le ono bytes aofaʻi ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... e pei lava o le &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Faʻafoʻi mai le numera o 16-bit code unit o loʻo manaʻomia e lenei `char` peʻa faʻamauina i le UTF-16.
    ///
    ///
    /// Tagai i le pepa mo [`len_utf8()`] mo nisi faamatalaga o lenei mataupu.
    /// Lenei galuega tauave o se faʻata, ae mo UTF-16 nai lo UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Encodes lenei uiga e pei UTF-8 i le buffer byte tuuina atu, ma toe foi mai le subslice o le buffer o loo i ai le amio encoded.
    ///
    ///
    /// # Panics
    ///
    /// Panics pe afai o le buffer le lava tele.
    /// O se faʻamau o le umi fa e lava tele e faʻamau ai soʻo se `char`.
    ///
    /// # Examples
    ///
    /// I nei faʻataʻitaʻiga uma e lua, 'ß' e lua kuata e faʻavasega ai.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// A buffer e le itiiti foi:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SAOGALEMU: `char` e le o se surrogate, ina lenei e aloaia UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Faʻailogaina lenei amio o le UTF-16 i totonu o le faʻamau `u16` faʻaavanoa, ona toe faʻafoʻi mai lea o le pito i lalo o le buffer o loʻo i ai le ituaiga o faʻailoga.
    ///
    ///
    /// # Panics
    ///
    /// Panics pe afai o le buffer le lava tele.
    /// O se faʻamau o le umi 2 e lava tele e faʻanofo ai soʻo se `char`.
    ///
    /// # Examples
    ///
    /// I nei faʻataʻitaʻiga uma e lua, '𝕊' ave lua 'u16`s e faʻamau.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// A buffer e le itiiti foi:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Faamatalaga o tupe maua pe afai `true` lenei `char` ei ai le meatotino `Alphabetic`.
    ///
    /// `Alphabetic` o loo faamatalaina i le Mataupu e 4 (Amio Meatotino) o le [Unicode Standard] ma faamaoti mai i le [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // o le alofa e tele mea, ae le faʻataʻitusi
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Faʻafoʻi `true` pe a fai o lenei `char` ei ai le `Lowercase` meatotino.
    ///
    /// `Lowercase` o loo faamatalaina i le Mataupu e 4 (Amio Meatotino) o le [Unicode Standard] ma faamaoti mai i le [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // O le scripts Saina eseese ma faailoga te le mataupu, ma o lea:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Faʻafoʻi `true` pe a fai o lenei `char` ei ai le `Uppercase` meatotino.
    ///
    /// `Uppercase` o loo faamatalaina i le Mataupu e 4 (Amio Meatotino) o le [Unicode Standard] ma faamaoti mai i le [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // O le scripts Saina eseese ma faailoga te le mataupu, ma o lea:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Faʻafoʻi `true` pe a fai o lenei `char` ei ai le `White_Space` meatotino.
    ///
    /// `White_Space` ua faʻamaʻoti mai i le [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // o se avanoa le malepe
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Faʻafoʻi `true` pe a fai o lenei `char` faʻamalieina a le [`is_alphabetic()`] poʻo le [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Faamatalaga o tupe maua pe afai `true` lenei `char` ei ai le vaega aoao mo tulafono laiti pulea.
    ///
    /// Tulafono faʻatonutonu (numera togi ma le vaega lautele o le `Cc`) o loʻo faʻamatalaina i le Mataupu 4 (Character Properties) o le [Unicode Standard] ma faʻamaoti mai i le [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // U + 009C, TERMINATOR manoa
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Faʻafoʻi `true` pe a fai o lenei `char` ei ai le `Grapheme_Extend` meatotino.
    ///
    /// `Grapheme_Extend` o loo faamatalaina i [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ma faamaoti mai i le [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Faʻafoʻi `true` pe a fai o lenei `char` ei ai se tasi o vaega lautele mo numera.
    ///
    /// O le vaega aoao mo numera (`Nd` mo decimal digits, `Nl` mo tusi-e pei o tagata numeric, ma `No` mo isi tagata numeric) ua faamaoti mai i le [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Toe foi se iterator e gauai le lowercase faafanua o lenei `char` o se tasi po o le sili
    /// `char`s.
    ///
    /// Afai o lenei `char` e leai se faʻamaufaʻailoga laʻititi, e maua e le iterator le `char` lava e tasi.
    ///
    /// Afai o lenei `char` ei ai le tasi-i le tasi faʻataʻotoga tamaʻi mataʻitusi na tuʻuina mai e le [Unicode Character Database][ucd] [`UnicodeData.txt`], o le iterator e maua ai lena `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Afai o lenei `char` manaʻomia faʻapitoa mafaufauga (eg faʻatele `char`s) o le iterator maua mai le`char` (s) na foaʻi mai e [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// O lenei faʻagaioiga e faʻatautaia ai se faʻafanua e leai se faʻavae e aunoa ma le suʻiina.O lona uiga, o le liua e tutoatasi mai le tulaga ma le gagana.
    ///
    /// I le [Unicode Standard], Mataupu 4 (Character Properties) o loʻo talanoaina ai le faʻafanua o tulaga i se tulaga lautele ma le Mataupu 3 (Conformance) e talanoaina ai le le faia o algorithm mo le liliuina o mataupu.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// I le avea ai ma se faʻaiuga:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Faʻaaoga saʻo `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// e tutusa uma e lua:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Faʻaaogaina `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // O nisi taimi e sili atu le taunuuga nai lo le tasi uiga:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Tagata e le o iai uma mataitusi tetele ma tamaitusi laiti ia latou lava.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Faʻafoʻi mai se faʻailoga e maua ai le faʻamaufaʻailoga pito i luga o lenei `char` o se tasi pe sili atu
    /// `char`s.
    ///
    /// Afai o lenei `char` e leai se faʻamaufaʻailoga pito i luga, e aumaia e le iterator le `char` lava e tasi.
    ///
    /// Afai o lenei `char` ei ai le tasi-i le tasi faʻamaufaʻavaega pito i luga saunia e le [Unicode Character Database][ucd] [`UnicodeData.txt`], o le iterator maua lena `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Afai o lenei `char` manaʻomia faʻapitoa mafaufauga (eg faʻatele `char`s) o le iterator maua mai le`char` (s) na foaʻi mai e [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// O lenei faʻagaioiga e faʻatautaia ai se faʻafanua e leai se faʻavae e aunoa ma le suʻiina.O lona uiga, o le liua e tutoatasi mai le tulaga ma le gagana.
    ///
    /// I le [Unicode Standard], Mataupu 4 (Character Properties) o loʻo talanoaina ai le faʻafanua o tulaga i se tulaga lautele ma le Mataupu 3 (Conformance) e talanoaina ai le le faia o algorithm mo le liliuina o mataupu.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// I le avea ai ma se faʻaiuga:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Faʻaaoga saʻo `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// e tutusa uma e lua:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Faʻaaogaina `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // O nisi taimi e sili atu le taunuuga nai lo le tasi uiga:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Tagata e le o iai uma mataitusi tetele ma tamaitusi laiti ia latou lava.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Faʻaliga i le nofoaga
    ///
    /// I le Take, o le tutusa o le 'i' i le Latina e lima ituaiga ae le o le lua:
    ///
    /// * 'Dotless': I/ı, o nisi taimi e tusia ï
    /// * 'Dotted': I/i
    ///
    /// Manatua o tamaʻi mataitusi o le 'i' e tutusa ma le Latina.O le mea lea:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// O le taua o le `upper_i` iinei e faʻamoemoe i luga o le gagana o le tusitusiga: afai o tatou i le `en-US`, e tatau ona `"I"`, ae afai tatou te i le `tr_TR`, e tatau ona `"İ"`.
    /// `to_uppercase()` e le ave lenei i tala, ma isi:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// taofiofia gagana.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Siaki pe o le tau i totonu o le ASCII tulaga.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Faia se kopi o le taua i lona ASCII tutusa tulaga pito i luga.
    ///
    /// ASCII tusi 'a' e 'z' ua faailogaina e 'A' e 'Z', ae tusi lē ASCII ua suia.
    ///
    /// Ina ia faʻamaualuga le tau ile tulaga, faʻaaoga le [`make_ascii_uppercase()`].
    ///
    /// I mataʻitusi tetele ASCII e faʻaopoopo i le ASCII mataitusi, faʻaaoga le [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Faia se kopi o le tau i lona ASCII maualalo tulaga tutusa.
    ///
    /// O mataitusi ASCII 'A' i le 'Z' e faʻafanua i le 'a' i le 'z', ae o mataitusi e leʻo ASCII e le suia.
    ///
    /// Ina ia lowercase le taua i totonu o le nofoaga, faaaoga [`make_ascii_lowercase()`].
    ///
    /// I lalo ifo o mataitusi ASCII i le faʻaopopo i le ASCII mataitusi, faʻaaoga le [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Siaki e lua aoga taua o le ASCII tulaga-le malamalama taʻaloga.
    ///
    /// Tutusa `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Faʻaliliuga lenei ituaiga i le ASCII pito i luga mataupu tutusa i le nofoaga.
    ///
    /// ASCII tusi 'a' e 'z' ua faailogaina e 'A' e 'Z', ae tusi lē ASCII ua suia.
    ///
    /// Ina ia toe faʻafoʻi mai se tau aofaʻi fou e aunoa ma le toe fesuiaʻi o se tasi, faʻaaoga le [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Tagata Liliu lenei ituaiga i lona ASCII tutusa tulaga i lalo i totonu o le nofoaga.
    ///
    /// O mataitusi ASCII 'A' i le 'Z' e faʻafanua i le 'a' i le 'z', ae o mataitusi e leʻo ASCII e le suia.
    ///
    /// Ina ia toe faʻafoʻi mai se tau maualalo maualalo e aunoa ma le toe fesuiaʻi o se tasi o loʻo i ai, faʻaaoga [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Siaki pe o le tau o se ASCII faʻasologa mataʻitusi:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', pe
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Siaki pe afai o le tau aogā o se ASCII uppercase uiga:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Siaki pe o le tau o se ASCII tamaʻi mataitusi:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Siaki pe o le tau o se ASCII alphanumeric amio:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', pe
    /// - U + 0061 'a' ..=U + 007A 'z', pe
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Siaki pe o le tau aoga o le ASCII decimal digit:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Siaki pe afai o le tau aogā o se digit hexadecimal ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', pe
    /// - U + 0041 'A' ..=U + 0046 'F', pe
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Siaki pe o le tau o se faʻailoga tusitusi ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, poʻo
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, poʻo
    /// - U + 005B ..=U + 0060 '' [\] ^ _ ``, po o
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Siaki pe o le tau o se ASCII kalafi amio:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Siaki pe afai o le tau aogā o se uiga whitespace ASCII:
    /// U + 0020 AVANOA, U + 0009 faalava TAB, U + 000A LEA MATAUPU Fafaga, U + 000C Fafaga PEPA, po o U + 000D taavale TOE FOI.
    ///
    /// Rust faʻaaogaina le WhatWG Infra Standard's [definition of ASCII whitespace][infra-aw].E tele isi faʻauiga i le lautele faʻaaogaina.
    /// Mo se faʻataʻitaʻiga, [the POSIX locale][pct] aofia ai U + 000B VERTICAL TAB faʻapea foʻi ma mataʻitusi uma o loʻo i luga, ae - mai le lava faʻamatalaga lava e tasi- [o le tulafono masani mo "field splitting" i le Bourne shell][bfs] manatu *na o* SPACE, HORIZONTAL TAB, ma fafaga LEA MATAUPU pei whitespace.
    ///
    ///
    /// Afai o loo e tusiaina o se polokalame o le a faagaoioia se faatulagaga faila o lo oi ai, siaki le mea faamatalaga o lena faatulagaga o whitespace ua i luma o le faaaogaina o lenei galuega tauave.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Siaki pe o le tau o se ASCII pulea amio:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, poʻo U + 007F TUPE.
    /// Manatua o le tele ASCII whitespace tagata e amio pulea, ae AVANOA e leai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Faʻailogaina le taua u32 taua e pei o UTF-8 i totonu o le faʻaavanoa byte buffer, ona toe faʻafoʻi mai lea o le subslice o le buffer o loʻo i ai le encode amio.
///
///
/// E le pei o le `char::encode_utf8`, o lenei metotia e faʻatautaia foi codepoints i le nofoaga e sui ai.
/// (Fatuina o se `char` i le tele surrogate o UB.) O le taunuuga e aloaia [generalized UTF-8] ae le aoga UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics pe afai o le buffer le lava tele.
/// O se faʻamau o le umi fa e lava tele e faʻamau ai soʻo se `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Encodes a mata taua u32 pei UTF-16 i le tuuina `u16` buffer, ona toe foi mai le subslice o le buffer o loo i ai le amio encoded.
///
///
/// E le pei o le `char::encode_utf16`, o lenei metotia e faʻatautaia foi codepoints i le nofoaga e sui ai.
/// (Fatuina o se `char` i le tele surrogate o UB.)
///
/// # Panics
///
/// Panics pe afai o le buffer le lava tele.
/// O se faʻamau o le umi 2 e lava tele e faʻanofo ai soʻo se `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SAOGALEMU: siaki lima taitasi pe o loo i ai lava le faagutu e tusi i
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Pau le BMP
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // vaalele Faaopoopo solia i surrogates.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}