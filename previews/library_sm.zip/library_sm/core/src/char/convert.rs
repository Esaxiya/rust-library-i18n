//! Liua amio.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Faʻaliliu se `u32` i le `char`.
///
/// Manatua o uma [`char`] s e aoga [`u32`] s, ma mafai ona lafo i le tasi ma
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Peitai, e le saʻo le tua: e le aoga uma [`u32`] s e aoga i le [`char`] s.
/// `from_u32()` o le a toe faafoi `None` pe a fai o le sao e le o se aoga aoga mo le [`char`].
///
/// Mo se lomiga saogalemu o lenei galuega tauave lea e amanaia nei siaki, tagai [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Faʻafoʻi `None` peʻa o le sao e le o se [`char`] faʻamaonia:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Faʻaliliua se `u32` i le `char`, le amanaʻiaina le aoga.
///
/// Manatua o uma [`char`] s e aoga [`u32`] s, ma mafai ona lafo i le tasi ma
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Peitai, e le saʻo le tua: e le aoga uma [`u32`] s e aoga i le [`char`] s.
/// `from_u32_unchecked()` le a le amanaiaina lenei, ma tauaso lafo i [`char`], atonu fatuina o se tasi mamaʻi.
///
///
/// # Safety
///
/// O lenei galuega o le saogalemu, e pei ona fausia faatauaina faalēaogāina `char`.
///
/// Mo se saogalemu faʻamaumauga o lenei gaioiga, vaʻai i le [`from_u32`] gaioiga.
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SAFETY: o le tagata e valaʻau tatau ona mautinoa o `i` o se aoga char aoga.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Liliu a [`char`] i se [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Liliu a [`char`] i se [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // O le char e lafo i le tau o le numera point, ona zero-faʻalauteleina i le 64 sina.
        // Tagai [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Faʻaliliua se [`char`] i totonu o le [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // O le char ua lafo i le taua o le code point, ona zero-faʻalauteleina i le 128 sina.
        // Tagai [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Maps a byte i 0x00 ..=0xFF i se `char` lona code tulaga ei ai le taua lava lea e tasi, i U + 0000 ..=U + 00FF.
///
/// Unicode ua fuafuaina e faʻapea o lenei lelei decodes bytes ma le amio faʻailoga na faʻaigoa e IANA ISO-8859-1.
/// O lenei encoding o gatasi ma ASCII.
///
/// Manatua e ese lenei mai ISO/IEC 8859-1 aka
/// ISO 8859-1 (ma le tasi le faʻaliliuga laititi), lea e tuua ai ni "blanks", byte taua e le tofiaina i soʻo se amio.
/// ISO-8859-1 (le IANA tasi) tofia i latou i le C0 ma C1 tulafono faʻatonutonu.
///
/// Manatua o lenei foi *e ese* ese mai Windows-1252 aka
/// numera itulau 1252, o le superset ISO/IEC 8859-1 o loʻo atofaina ai nisi (e leʻo uma!) Avanoa i faʻailoga ma mataʻitusi Latina eseese.
///
/// Ina ia fenumiai isi mea, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, ma `windows-1252` o igoa uma mo le superset o Windows-1252 o loʻo faʻatumuina avanoa o loʻo totoe ma tutusa C0 ma C1 tulafono faʻatonutonu.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Faʻaliliua se [`u8`] i totonu o le [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Se mea sese e mafai ona toe foi pe a parsing a SIA.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SAFETY: siakiina o se tulafono unicode aoga
            Ok(unsafe { transmute(i) })
        }
    }
}

/// toe foi i le ituaiga mea sese pe a liua mai u32 e SIA ua lē mafai.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Faʻaliliuga se numera i le leata fesoʻotaʻi i le `char`.
///
/// O le 'radix' iinei e taʻua foi o le 'base'.
/// A radix o lua e faailoa ai le numera binary, o se radix o sefulu, decimal, ma a radix o le sefulu ma le ono, hexadecimal, e tuuina atu nisi o tulaga faatauaina e tutusa ai.
///
/// O loʻo lagolagoina radices faʻapitoa.
///
/// `from_digit()` o le a toe faafoi `None` pe a fai o le sao e le o se numera i le leitio tuuina atu.
///
/// # Panics
///
/// Panics pe a fai e maua le radix sili atu ile 36.
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Decimal 11 o se digit tasi i faavae 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Faʻafoʻi `None` pe a fai o le sao e le o se numera:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Tufaina a radix tele, na mafua ai se panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}