use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// O lenei trait maua avanoa transitive e puna-tulaga i se pipeline interator-mea faʻatatau i lalo o le tulaga o le
/// * o le iterator punavai `S` lava ia na faʻaaogaina `SourceIter<Source = S>`
/// * o loo i ai a le tuuina atu o le faatinoga o lenei trait mo mea faʻatatau taitasi i le pipeline le va o le puna ma le tagata faatau pipeline.
///
/// A o le puna o se umia iterator fausia (e masani ona taʻua o `IntoIter`) lea o lenei e mafai ona aoga mo faapitoa [`FromIterator`] implementations po o le toe faaleleia o le elemene o totoe ina ua uma ona vaivai vaega se iterator.
///
///
/// Manatua o faʻatinoga e le tau manaʻomia e maua ai le ulufale i totonu-sili puna o se paipa.A stateful mea faʻatatau vailauga mafai naunautai iloiloina se vaega o le pipeline ma faaaliali lona teuina i totonu o punavai.
///
/// O le trait o le saogalemu ona e tatau ona lagolagoina implementers meatotino faaopoopo saogalemu.
/// Vaʻai [`as_inner`] mo auiliiliga.
///
/// # Examples
///
/// Mauaina mai o se vaega faʻavaea mafuaʻaga:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// O se mafuaʻaga tulaga i totonu o se laina paipa faʻaseʻe.
    type Source: Iterator;

    /// Le toe aumaia o le puna o se pipeline iterator.
    ///
    /// # Safety
    ///
    /// Faʻatinoga o tatau tatau ona toe faafoi le tutusa suia suia mo o latou olaga, sei vagana ua suia e se telefoni.
    /// Tagata na valaʻau faʻatoa mafai ona suia le faʻasino pe a latou taofi le faʻasolosolo ma paʻu le laina paipa faʻasolosolo pe a uma ona aveʻese mai le mafuaʻaga.
    ///
    /// O lenei auala iterator adapters e mafai ona faalagolago i le suia o le puna i le taimi o iteration ae le mafai ona latou faalagolago i ai io latou implementations Mataua.
    ///
    /// Faʻataʻitaʻia lenei metotia uiga o adapters faʻamatuʻuina tumaʻoti-naʻo le faʻaaogaina o a latou punavai ma e mafai ona faʻalagolago i faʻamaoniga faia faʻavae luga o metotia ituaiga faʻataʻitaʻi.
    /// O le leai o faasaina avanoa e manaomia ai foi e tatau ona adapters lagolagoina le API lautele a le puna e oo lava pe a latou maua avanoa i lona internals.
    ///
    /// Tagata valaʻau i le tasi itu e tatau ona faʻamoemoe o le punaoa ia i ai i soʻo se setete e ogatusa ma lona lautele API talu ai adapters nofo i le va o ia ma le punaoa maua tutusa avanoa.
    /// Ae maise lava o se mea faapipii atonu na faʻaumatia sili atu elemene nai lo matua tatau.
    ///
    /// O le sini aoao o nei tulaga manaomia o le tuu atu le tagata faatau o le a faaaogaina pipeline
    /// * soo se toega i le puna ina ua uma iteration ua taofia
    /// * le manatua na avea ma le le faʻaaogaina e ala i le alualu i luma o se faʻaaogaina iterator
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// O se iterator mea faʻatatau e maua galuega faatino e pei o le umi o le faavae iterator maua ai tulaga faatauaina `Result::Ok`.
///
///
/// Afai e fetaiai se mea sese, o le iterator taofia ma le mea sese ua teuina.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Faʻagasologa le mea na tuʻuina atu e pei na maua ai le `T` nai lo le `Result<T, _>`.
/// So o se mea sese o le a taofia le iterator totonu ma o le a se mea sese le taunuuga atoa.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}