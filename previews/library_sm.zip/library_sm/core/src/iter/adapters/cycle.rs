use crate::{iter::FusedIterator, ops::Try};

/// O se iterator e toe gata.
///
/// O lenei `struct` ua faia e le auala [`cycle`] i [`Iterator`].
/// Vaʻai ana faʻamaumauga mo sili atu.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // ole taʻamilosaga taʻamilo e leai se mea pe leai foi
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // iterate atoatoa le iterator nei.
        // e talafeagai lenei mea ona e mafai ona sasaa `self.iter` e tusa lava pe e le o `self.orig`
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // faamaea ai i le taamilosaga atoa, tausia ala o le pe o le cycled iterator o avanoa pe leai.
        // tatou te manaomia e toe foi vave i le tulaga o se iterator avanoa e taofia ai se matasele e le iu
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Leai `fold` faʻaleaogaina, aua `fold` e leai se uiga tele mo `Cycle`, ma e le mafai ona tatou faia se mea sili atu nai lo le masani ai.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}