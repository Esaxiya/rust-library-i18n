//! Faʻatulagaina mai fafo.
//!
//! Afai ua e mauaina oe lava i se tuufaatasiga o se ituaiga, ma e manaomia e faatino se taotoga i luga o le elemene o le aoina fai mai, o le ae vave taufetuli i 'iterators'.
//! Iterators ua mamafa faaaogaina i code idiomatic Rust, o lea o le taua o le avea ma masani ma i latou.
//!
//! Ae le i faʻamatalaina atili, tatou talanoa pe faʻafefea ona fausia lenei module:
//!
//! # Organization
//!
//! O lenei module ua faatulagaina tele i ituaiga:
//!
//! * [Traits] o le vaega autu: faamatalaina nei traits le mea oi ai ituaiga o iterators ma mea e mafai ona faia ma i latou.O metotia o nei traits e aoga le tuʻuina i ai o ni taimi faʻaopopo faʻasili i totonu.
//! * [Functions] saunia ni auala aoga e fausia ai ni autu faʻavasega.
//! * [Structs] e masani lava ona le toe foi mai ituaiga o metotia eseese i luga o le traits lenei module.Ae e masani lava e te manao e vaai i le auala e faatupuina ai le `struct`, nai lo le `struct` lava ia.
//! Mo nisi faamatalaga auiliili e uiga i le mafuaaga, tagai '[faatinoina Iterator](#faatinoina-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! O lena lava!oso o ia i iterators.
//!
//! # Iterator
//!
//! O le fatu ma le agaga o lenei vaega o le [`Iterator`] trait.O le autu o [`Iterator`] foliga e pei o lenei:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! O le iterator e iai lona auala, [`next`], pe a valaʻauina, e toe faʻafoʻi mai le ['Option`]'<Item>'.
//! [`next`] le a toe foi [`Some(Item)`] le umi lava o loo i ai elemene, ma pe a latou sa e vaivai uma, o le a toe foi `None` e faailoa e iteration Ua taunuu.
//! E mafai e tagata taʻitasi ona filifili e toe amata le faʻamatalaga, ma o lea e toe valaʻau ai i le [`next`] atonu pe toe amata foʻi ona toe faʻafoʻi mai le [`Some(Item)`] i ni taimi (mo se faʻataʻitaʻiga, vaʻai [`TryIter`]).
//!
//!
//! ['Iterator`]' s faamatalaga atoatoa e aofia ai le tele o isi auala e pei ona lelei, ae oi latou o ni metotia faaletonu, na fausia i luga o [`next`], ma ina ia maua i latou mo saoloto.
//!
//! Iterators e mafai foi ona tuʻufaʻatasia, ma e masani ona faʻavasega faʻatasi i latou e faia ni faʻalavelave laʻitiiti o le faʻagaioiga.Tagai i le vaega [Adapters](#adapters) lalo mo nisi faamatalaga.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Le tolu ituaiga o faʻasologa
//!
//! E tolu auala lautele lea e mafai ona faia iterators mai se tuufaatasiga:
//!
//! * `iter()`, lea iterates i `&T`.
//! * `iter_mut()`, lea iterates i `&mut T`.
//! * `into_iter()`, lea iterates i `T`.
//!
//! Eseese mea i le potutusi tulaga masani mafai faʻaogaina se tasi pe sili atu o le tolu, pe a talafeagai ai.
//!
//! # le faatinoina o Iterator
//!
//! Faia o se iterator o lou lava e aofia ai ni laasaga se lua: o le fatuina o se `struct` e umia le tulaga o le le iterator, ma le faatinoina o [`Iterator`] mo lena `struct`.
//! O le mafuaaga lea o loo i ai le tele o 'struct`s i lenei module: o loo i ai se tasi mo iterator taitasi ma iterator mea faʻatatau.
//!
//! Sei o tatou faia se iterator igoa `Counter` lea taulia mai `1` e `5`:
//!
//! ```
//! // Muamua, o le fausia:
//!
//! /// O se iterator lea faitauga mai le tasi i le lima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // matou te mananaʻo ia amata le matou faitauga ile tasi, ia o lea faʻaopopo le new() auala e fesoasoani ai.
//! // e le matua e tatau ai lenei mea, ae e faigofie.
//! // Manatua tatou amata `count` i le leai, o le a tatou vaʻai pe aisea i le `next()`'s faʻatinoina i lalo.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ona tatou faatino `Iterator` mo lo tatou `Counter`:
//!
//! impl Iterator for Counter {
//!     // o le a tatou faitauina ma usize
//!     type Item = usize;
//!
//!     // next() na o le pau lea o le metotia manaʻomia
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Faʻateleina la matou faitauga.O le mafuaaga lenei tatou amata i o.
//!         self.count += 1;
//!
//!         // Siaki e vaai pe tatou ua maeʻa le faitauina pe leai.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Ma o lenei e mafai ona tatou faʻaaogaina!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Valaʻau [`next`] i lenei auala avea toe fai.O le Rust ei ai lona fausia e mafai ai ona valaʻau [`next`] i luga o lau mea faʻasolosolo, seʻia oʻo i le `None`.Seʻi tatou o atu i le isi mataupu.
//!
//! Manatua foi o `Iterator` o loʻo faʻaalia ai le le faʻaogaina o metotia e pei o `nth` ma `fold` o loʻo valaʻauina ai le `next` i totonu.
//! Ae peitai, e mafai foi e tusi se faatinoga masani o metotia e pei o `nth` ma `fold` pe afai o se iterator mafai compute i latou e sili atu lelei e aunoa ma le valaau atu `next`.
//!
//! # `for` matasele ma `IntoIterator`
//!
//! O le Rust's `for` loop syntax o le mea moni suka mo iterators.O iinei se faataitaiga faavae o `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! O le a lolomi le tasi fuainumera e ala i le lima, taitasi i luga o latou lava laina.Ae o le ae iloa ai se mea iinei: tatou te taʻua o se mea i lo tatou vector ina ia maua se iterator.O le a le mea e foaʻi?
//!
//! E i ai le trait i le faletusi masani mo le faʻaliliuina o se mea i se iterator: [`IntoIterator`].
//! ei ai se metotia se tasi lenei trait, [`into_iter`], lea e liua ai le mea faatinoina [`IntoIterator`] i se iterator.
//! Sei o tatou vaʻavaʻai lava i lena `for` matasele toe, ma le mea a le tuʻufaʻatasia liua i totonu:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sugars i lenei:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Muamua, matou te valaʻau `into_iter()` ile tau.Ma, matou te faʻafetaui le iterator e toe foʻi mai, valaʻau pea i le [`next`] seʻia oʻo ina tatou vaʻaia se `None`.
//! I lena tulaga, tatou `break` mai le matasele, ma tatou te iterating uma.
//!
//! O loo i ai se tasi si le iloa tele iinei: o le potutusi o le tulaga faatonuina o loo i ai se faatinoga fiafia o [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! I se isi faaupuga, o mea uma ['Iterator`] s faatino [`IntoIterator`], e ala i le na o le toe foi i latou lava.O lona uiga o mea e lua:
//!
//! 1. Afai o loʻo e tusia le [`Iterator`], e mafai ona e faʻaaogaina i le `for` matasele.
//! 2. Afai o loo e faia ai se aoina, faatinoina [`IntoIterator`] mo le o le a mafai ai e lou aoina ia faaaoga ma le matasele `for`.
//!
//! # Faʻamatalaina ile faʻasino
//!
//! Talu ai e [`into_iter()`] `self` e aoga, e faaaoga ai se matasele `for` e iterate i se tuufaatasiga alu uma e aoina.E masani lava, atonu e te manao e iterate i se tuufaatasiga e aunoa ma alu ai.
//! E toatele aoina ofoina metotia e tuuina iterators i mau faasino, conventionally taʻua `iter()` ma `iter_mut()` faasologa:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` o loʻo umiaina pea e lenei galuega.
//! ```
//!
//! Afai o se aoina ituaiga maua `C` `iter()`, e masani foi faatino `IntoIterator` mo `&C`, ma se faatinoga e pei lava valaau `iter()`.
//! E faapena foi, a aoina `C` faatino masani e tuuina `iter_mut()` `IntoIterator` mo `&mut C` e tuuina atu i `iter_mut()`.O lenei e mafai ai ona a shorthand talafeagai:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // tutusa ma `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // tutusa ma `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! E ui o le tele o faʻaputugaaga ofoina `iter()`, le uma ofa `iter_mut()`.
//! Mo se faʻataʻitaʻiga, o le suia o ki o le [`HashSet<T>`] poʻo le [`HashMap<K, V>`] e mafai ona tuʻuina ai le aoina i se tulaga le tutusa pe a sui le ki o le hashes, o lona uiga o nei aoina e naʻo le `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! ua masani ona taʻua o Galuega tauave lea e faia se [`Iterator`] ma toe foi isi [`Iterator`] 'adapters iterator', e pei ona latou te a ituaiga o 'mea faʻatatau
//! pattern'.
//!
//! E masani ona faʻaaogaina le iterator adapters [`map`], [`take`], ma [`filter`].
//! Mo nisi, tagai i le latou pepa.
//!
//! Afai o se iterator mea faʻatatau panics, o le a i se faasinoa tulaga taitasi le iterator (ae saogalemu manatua) setete.
//! O lenei tulaga e le o mautinoa foi e tumau o ia lava i le salafa o lomiga o Rust, o lea e tatau ona e aloese mai le faalagolago i le tulaga faatauaina tonu toe foi e se iterator lea popole.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (ma iterator [adapters](#adapters)) e *paie*. O lona uiga e le na o le faia o se iterator e le _do_ tele atoa. E leai se mea na tupu moni lava seia oo ina e valaau [`next`].
//! o nisi taimi o se puna lea o le le mautonu ina ua faia o se iterator faapitoa mo ona aafiaga itu.
//! Mo se faataitaiga, o le valaau auala [`map`] a tapunia i ai elemene taitasi iterates i:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! O le a lē lolomi o so o se tulaga faatauaina, ao tatou na foafoaina se iterator, nai lo le faaaogaina ai.O le tuufaatasia o le a lapataia i tatou e uiga i lenei ituaiga o amioga:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! O le idiomatic auala e tusi se [`map`] mo ona aafiaga itu o le faaaogaina se matasele `for` pe valaau le auala [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! O le isi auala masani e iloilo ai se mea faʻapipiʻi o le faʻaaogaina lea o le [`collect`] auala e maua ai se faʻaputuga fou.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterators e le tatau ona gata.O se faataitaiga, o se ituaiga tatala-faaiuina o se iterator iu:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! E taatele le faʻaaogaina o le [`take`] iterator adapter e faʻaliliu ai le iterator le iʻu i se gataʻaga:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Lenei o le a lolomiina numera `0` e ala i `4`, taʻitasi i luga o la latou lava laina.
//!
//! Ia tuuina atu i le mafaufau o le auala i le iterators le iʻu, e oo lava i lea o se taunuuga e mafai ona fuafuaina mathematically i taimi gata, e le mafai ona faamuta.
//! Faʻapitoa, metotia e pei o [`min`], lea i le tulaga lautele manaʻomia le sopoʻia o elemeni uma i le iterator, e foliga mai e le toe foʻi manuia mo soʻo se faʻavavau iterators.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oi leai!Se matasele le iu!
//! // `ones.min()` mafua ai le leai se gataʻaga matasele, o lea tatou te le oʻo ai i lenei tulaga!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;