use crate::iter::{FusedIterator, TrustedLen};

/// Fausia se fou faʻasolosolo e toe faia elemeni o le ituaiga `A` e le gata i le faʻaogaina o le avanoa tapunia, le toe fai, `F: FnMut() -> A`.
///
/// O le galuega tauave `repeat_with()` taʻua i le repeater pea lava pea.
///
/// Iʻu iterators pei `repeat_with()` e masani ona faaaogaina ma le adapters pei [`Iterator::take()`], ina ia faia i latou e gata.
///
/// Afai o le elemene ituaiga o le iterator te manaomia meafaigaluega [`Clone`], ma e le afaina le tausia o le elemene puna i le manatua, e tatau ona faaaogaina nai lo le galuega tauave [`repeat()`].
///
///
/// O se iterator gaosia e `repeat_with()` e le o se [`DoubleEndedIterator`].
/// Afai e te manaomia `repeat_with()` e toe foi a [`DoubleEndedIterator`], faamolemole tatala se mataupu GitHub faamatala lou tulaga faaaogaina.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::iter;
///
/// // sei o tatou manatu ua tatou maua nisi taua o se ituaiga e le o `Clone` po o lea e te le manao e maua i manatuaina lava ae ona e taugata:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // a taua faapitoa e faavavau:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Faaaogaina mutation ma alu gata:
///
/// ```rust
/// use std::iter;
///
/// // Mai le zeroth i le lona tolu mana o lua:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ma o loo tatou i le taimi nei faia
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// O se mea faʻasolosolo e toe faia elemeni o le ituaiga `A` e le gata i le faʻaogaina o le tapunia `F: FnMut() -> A`.
///
///
/// O lenei `struct` ua faia e le o se galuega tauave [`repeat_with()`].
/// Vaʻai ana faʻamaumauga mo sili atu.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}