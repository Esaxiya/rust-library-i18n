use crate::iter::{FusedIterator, TrustedLen};

/// Faatupuina ai se iterator e lazily faatupuina se taua faʻatasi tonu e le aumaia ai le tapunia tuuina atu.
///
/// ua masani ona faaaogaina lenei e fetuunai a afi taua e tasi i se [`chain()`] o isi ituaiga o iteration.
/// Atonu e te maua se iterator o faavaa e toetoe lava o mea uma, ae e manaomia ai se tulaga faapitoa faaopoopo.
/// Atonu ua e maua se galuega tauave lea e galue i iterators, ae e na o le manaomia e faagaoioia se tasi taua.
///
/// E le pei o [`once()`], o le a faatupuina ai lazily lenei galuega tauave o le tau aogā i luga o talosaga.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::iter;
///
/// // le tasi o le numera loneliest
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // na o le tasi, e le uma tatou te maua
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining faatasi ma le isi iterator.
/// Seʻi tatou fai atu matou te mananaʻo e faʻasolosolo faila taʻitasi o le `.foo` faʻasino, ae faʻapena foʻi ma se faila faʻatulagaina,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // e tatau ona tatou liliu mai se iterator o DirEntry-s i se iterator o PathBufs, o lea tatou te faaaogaina faafanua
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // i le taimi nei, o lo tatou iterator mo na o lo tatou faila config
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // filifili faatasi le iterators lua i se tasi iterator tele
/// let files = dirs.chain(config);
///
/// // Lenei o le a aumaia ia i tatou uma faila i .foo faʻapea foi ma .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// O se iterator e gauai o se elemene e tasi o ituaiga `A` ala i le faaaogaina o le tapunia tuuina `F: FnOnce() -> A`.
///
///
/// O lenei `struct` ua faia e le o se galuega tauave [`once_with()`].
/// Vaʻai ana faʻamaumauga mo sili atu.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}