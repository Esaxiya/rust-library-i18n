use crate::fmt;

/// Faatupu ai se iterator fou lea sa taʻu ai iteration taitasi le tuuina tapunia `F: FnMut() -> Option<T>`.
///
/// O lenei faʻatagaina le fausiaina o se tu masani agavaʻa ma soʻo se amio e aunoa ma le faʻaaogaina o le sili atu verosa syntax o le fausiaina o se tuʻufaʻatasia ituaiga ma faʻaogaina le [`Iterator`] trait mo ia.
///
/// Manatua o le `FromFn` iterator e le faia ni masalosaloga e uiga i amioga o le tapunia, ma o le mea lea e le mafai ai ona faʻaogaina le [`FusedIterator`], pe ova le [`Iterator::size_hint()`] mai lona `(0, None)` masani.
///
///
/// Le tapunia mafai ona e faaaogaina valiina ma ona siosiomaga le faasologa o tulaga i le isi itu iterations.E faalagolago i le auala e faaaogaina le iterator, e mafai ona manaomia lenei e faamaotiina ai le upu autu [`move`] i le tapunia.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Sei o tatou toe faʻaogaina le counter iterator mai [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Faʻateleina la matou faitauga.O le mafuaaga lenei tatou amata i o.
///     count += 1;
///
///     // Siaki e vaai pe tatou ua maeʻa le faitauina pe leai.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// O se iterator lea sa taʻu ai iteration taitasi le tuuina tapunia `F: FnMut() -> Option<T>`.
///
/// O lenei `struct` ua faia e le o se galuega tauave [`iter::from_fn()`].
/// Vaʻai ana faʻamaumauga mo sili atu.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}