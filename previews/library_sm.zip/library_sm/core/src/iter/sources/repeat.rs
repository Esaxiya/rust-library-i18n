use crate::iter::{FusedIterator, TrustedLen};

/// Fausia se fou faʻasolosolo e faʻavavau toe fai se tasi elemeni.
///
/// O le `repeat()` gaioiga toe faia le tasi le aoga faʻatele.
///
/// Iʻu iterators pei `repeat()` e masani ona faaaogaina ma le adapters pei [`Iterator::take()`], ina ia faia i latou e gata.
///
/// Afai o le elemeni ituaiga o le iterator oe manaʻomia le faʻaaogaina `Clone`, pe afai e te le manaʻo e teu le toe fai elemeni i le manatuaina, oe mafai ona faʻaaoga le [`repeat_with()`] gaioiga.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::iter;
///
/// // le numera 4ever fa:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, pea fa
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Alu faʻaiʻu ma [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // o le faʻataʻitaʻiga mulimuli na sili atu i le fa.Tau na o le fa fa.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ma o loo tatou i le taimi nei faia
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// O se faʻasolosolo e toe faia se elemeni tumau.
///
/// O lenei `struct` ua faia e le o se galuega tauave [`repeat()`].Tagai i ana pepa aloaia mo le sili.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}