use crate::iter::{FusedIterator, TrustedLen};

/// Faatupuina ai se iterator e aumaia ai se elemene faʻatasi tonu.
///
/// Lenei e masani ona faʻaaogaina e fetuʻunaʻi ai le tasi tau aoga i le [`chain()`] o isi ituaiga faʻasolosolo.
/// Atonu e te maua se iterator o faavaa e toetoe lava o mea uma, ae e manaomia ai se tulaga faapitoa faaopoopo.
/// Atonu ua e maua se galuega tauave lea e galue i iterators, ae e na o le manaomia e faagaoioia se tasi taua.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::iter;
///
/// // le tasi o le numera loneliest
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // na o le tasi, e le uma tatou te maua
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining faatasi ma le isi iterator.
/// Seʻi tatou fai atu matou te mananaʻo e faʻasolosolo faila taʻitasi o le `.foo` faʻasino, ae faʻapena foʻi ma se faila faʻatulagaina,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // e tatau ona tatou liliu mai se iterator o DirEntry-s i se iterator o PathBufs, o lea tatou te faaaogaina faafanua
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // i le taimi nei, o lo tatou iterator mo na o lo tatou faila config
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // filifili faatasi le iterators lua i se tasi iterator tele
/// let files = dirs.chain(config);
///
/// // Lenei o le a aumaia ia i tatou uma faila i .foo faʻapea foi ma .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// O se faʻasolosolo e maua ai le elemeni i le taimi e tasi.
///
/// O lenei `struct` ua faia e le o se galuega tauave [`once()`].Tagai i ana pepa aloaia mo le sili.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}