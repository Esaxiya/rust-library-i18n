/// O se faʻasolosolo e masani ona faʻaauau ona maua `None` pe a lelava.
///
/// Valaʻau mai i luga o le fuse iterator ua toe faʻafoʻi mai le `None` tasi taimi e mautinoa e toe faʻafoʻi mai le [`None`].
/// e tatau ona faatinoina lenei trait e uma iterators e amio lenei auala ona faatagaina optimizing [`Iterator::fuse()`].
///
///
/// Note: I se tulaga lautele, oe le tatau ona faʻaaogaina `FusedIterator` i lautele tuaʻoi pe a fai e te manaʻomia se fuse iterator.
/// Nai lo lena, e tatau ona na o le valaau [`Iterator::fuse()`] i le iterator.
/// Afai ua uma ona fused le iterator, o le faaopoopo afifi [`Fuse`] o le a a leai-op ma leai se faasalaga faatinoga.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// O se faʻataʻitaʻiga e lipotia se umi saʻo faʻaaogaina le size_hint.
///
/// O le iterator lipoti a faaiteite tele lea e le o tonu (maualalo noatia e tutusa i le pito i luga noatia), po o le pito i luga noatia o [`None`].
///
/// E tatau i le noatia i luga na o [`None`] pe afai o le umi iterator moni e tele atu nai lo [`usize::MAX`].
/// I lena tulaga, o le maualalo noatia tatau ona [`usize::MAX`], e mafua i se [`Iterator::size_hint()`] o `(usize::MAX, None)`.
///
/// E tatau ona faʻatupuina e le iterator le aofaʻi tonu o elemeni na lipotia pe faʻavaivaia foʻi a o leʻi oʻo i le iʻuga.
///
/// # Safety
///
/// Lenei trait e tatau ona faʻatoa faʻaaogaina peʻa lagolagoina le konekalate.
/// Tagata faatau o lenei e tatau ona trait asiasia luga noatia [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// O se mea faʻasolosolo pe a maua se aitema o le a aveina le sili atu ma le tasi elemene mai lona autu [`SourceIter`].
///
/// Valaau atu i so o se auala e sii le iterator, eg
/// [`next()`] poʻo le [`try_fold()`], faʻamaonia mai mo laʻasaga taʻitasi ia le itiiti ifo ma le tasi le aoga o le autu o le autu o le iterator ua aveʻese mai ma o le iʻuga o le iterator chain e mafai ona tuʻuina i lona tulaga, ma le faʻatapulaʻaina o faʻatapulaʻaina o le mafuaʻaga faʻatagaina se faʻaofiina.
///
/// I se isi faaupuga e faailoa lenei trait e mafai ona aoina se pipeline iterator i nofoaga.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}