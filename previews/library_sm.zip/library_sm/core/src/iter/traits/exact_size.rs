/// O se faʻasolosolo e iloa lona umi tonu.
///
/// Tele ['Iterator`] latou te le iloa pe faʻafia ona latou faʻataʻitaʻia, ae o nisi e leai.
/// Afai o se iterator te silafia le ala tele o taimi e mafai ona iterate, tuuina atu le avanoa i lena faamatalaga e mafai ona aoga.
/// Mo se faataitaiga, afai e te manao e iterate tua, o le iloa se amataga lelei lea i le iuga o.
///
/// Ina ua le faatinoina o se `ExactSizeIterator`, e tatau foi ona faatino [`Iterator`].
/// Pe a faia faapea, o le faatinoina o [`Iterator::size_hint`]*ao* toe foi le tele tonu o le iterator.
///
/// O le auala [`len`] se faatinoga faaletonu, o lea e masani lava ona le tatau ona faatino ai.
/// Ae peitaʻi, e ono mafai ona e tuʻuina atu se faʻatinoga sili atu nai lo le le masani ai, o lona uiga o le soʻona faʻaaogaina i lenei tulaga e talafeagai.
///
///
/// Faamatalaga o lenei trait o se saogalemu trait ma o lea e *le* ma *le mafai ona* faamaoniga e saʻo le umi foi mai.
/// O lenei auala e `unsafe` code **le tatau ona** faalagolago i le sao atoatoa o [`Iterator::size_hint`].
/// O le le mautonu ma le le saogalemu [`TrustedLen`](super::marker::TrustedLen) trait o loʻo maua ai le isi faʻamaoniga.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// // silafia lelei le auala a ituaiga gata le tele o taimi o le a iterate
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// I le [module-level docs], ua tatou faatinoina se [`Iterator`], `Counter`.
/// Sei o tatou faatino `ExactSizeIterator` i ai e pei foi:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // E faigofie ona tatou fuafua o totoe numera o iterations.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Ma o lenei e mafai ona tatou faʻaaogaina!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Faafoi le umi tonu o le iterator.
    ///
    /// Le faatinoina e mautinoa ai le iterator le a toe foi tonu `len()` sili taimi a taua [`Some(T)`], ao lei toe foi [`None`].
    ///
    /// O lenei auala ua i ai se faatinoga faaletonu, o lea e masani lava ona le tatau ona faatino saʻo.
    /// Ae peitai, afai e mafai ona e tuuina atu ai se faatinoga e sili atu ona lelei, e mafai ona e faia faapea.
    /// Tagai i le docs [trait-level] mo se faataitaiga.
    ///
    /// Lenei gaioiga ei ai le tutusa saogalemu faʻamaoniga pei o le [`Iterator::size_hint`] gaioiga.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // silafia lelei le auala a ituaiga gata le tele o taimi o le a iterate
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: O lenei folafolaga o le soona puipui, ae siaki le invariant
        // faamaonia e le trait.
        // Afai lenei trait rust-lotoifale, e mafai ona tatou faaaogaina debug_assert !;assert_eq!le a siaki foi implementations faaaogāina Rust uma.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Faamatalaga o tupe maua pe afai o le `true` iterator o gaogao.
    ///
    /// O lenei metotia e i ai le le faʻaaogaina faʻaoga [`ExactSizeIterator::len()`], o lea e te le manaʻomia e faʻatinoina oe lava.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}