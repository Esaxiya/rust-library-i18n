/// Faʻaliliuga mai le [`Iterator`].
///
/// E ala i le faatinoina o `FromIterator` mo se ituaiga, e faauigaina le auala o le a faia mai se iterator.
/// e masani lenei mo ituaiga lea faamatalaina o se tuufaatasiga o se ituaiga.
///
/// [`FromIterator::from_iter()`] e seasea valaʻauina manino, ma nai lo le faʻaaogaina e ala ile [`Iterator::collect()`] auala.
///
/// Vaʻai [`Iterator::collect()`]'s faʻamaumauga mo nisi faʻataʻitaʻiga.
///
/// Tagaʻi foʻi: [`IntoIterator`].
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Faʻaaogaina [`Iterator::collect()`] e faʻaaoga manino le `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Faʻaaogaina `FromIterator` mo lau ituaiga:
///
/// ```
/// use std::iter::FromIterator;
///
/// // A aoina faataitaiga, e na o se afifi i Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Sei o tatou tuuina atu nisi o auala lea e mafai ona tatou faia le tasi ma faaopoopo mea i ai.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ma o le a tatou faatino FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nei e mafai ona tatou faia se fou faʻasolosolo ...
/// let iter = (0..5).into_iter();
///
/// // ... ma faia se MyCollection mai ai
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // aoina foi galuega!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Fausia se taua mai se iterator.
    ///
    /// Vaʻai le [module-level documentation] mo nisi mea.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Liua i se [`Iterator`].
///
/// I le faʻatinoina `IntoIterator` mo se ituaiga, oe faʻamatalaina pe faʻafefea ona liua i se iterator.
/// e masani lenei mo ituaiga lea faamatalaina o se tuufaatasiga o se ituaiga.
///
/// Tasi le aoga o le faʻaogaina o `IntoIterator` o lou ituaiga o le a [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Tagaʻi foʻi: [`FromIterator`].
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Le faatinoina o `IntoIterator` mo lou ituaiga:
///
/// ```
/// // A aoina faataitaiga, e na o se afifi i Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Sei o tatou tuuina atu nisi o auala lea e mafai ona tatou faia le tasi ma faaopoopo mea i ai.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ma o le a tatou faatino IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // O lenei e mafai ona tatou faia o se tuufaatasiga fou ...
/// let mut c = MyCollection::new();
///
/// // ... faʻaopopo ni mea i ai ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ona liliu lea i se Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// E masani ona faaaogaina `IntoIterator` o se trait bound.Lenei faʻatagaina le faʻauluina o tuʻufaʻatasiga ituaiga e suia, pe a fai o le a avea pea ma iterator.
/// e mafai ona faamaoti mai tuaoi Faaopoopo e faatapulaaina i luga o
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// O le ituaiga o le elemene le iterated luga.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// O le fea ituaiga o iterator o loʻo tatou liliuina i lenei?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Faatupuina ai se iterator mai se taua.
    ///
    /// Vaʻai le [module-level documentation] mo nisi mea.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Tuuina atu se aoina ma le anotusi o se iterator.
///
/// Iterators tuuina atu se faasologa o tulaga faatauaina, ma aoina e mafai foi ona mafaufau e pei o se faasologa o tulaga faatauaina.
/// O le `Extend` trait faʻapipiʻi lenei avanoa, faʻatagaina oe e faʻalautele se aoina e ala i le faʻaofiaina o mea o iai i totonu.
/// A tuuina atu se tuufaatasiga ma se ki uma ona o lo oi ai, ua toe faafou o le ulufale po o, i le tulaga o le aoina o le faatagaina faamaumauga tele ma ki tutusa, e ulufale ua faaofiina.
///
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// // E mafai ona e tuuina atu se manoa ma nisi chars:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Le faatinoina o `Extend`:
///
/// ```
/// // A aoina faataitaiga, e na o se afifi i Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Sei o tatou tuuina atu nisi o auala lea e mafai ona tatou faia le tasi ma faaopoopo mea i ai.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // talu MyCollection ei ai se lisi o i32s, tatou te faatino Faalautele mo i32
/// impl Extend<i32> for MyCollection {
///
///     // o se vaega itiiti faigofie lenei mea ma le saini ituaiga sima: e mafai ona tatou valaau faalautele atu i so o se mea lea e mafai ona liliu atu i se Iterator lea e tuuina i tatou i32s.
///     // Talu ai ona tatou te manaomia i32s e tuu i MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Le faatinoga e matua tuusaʻo: matasele e ala i le iterator, ma add() elemene taitasi ia i tatou lava.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // sei o tatou faalauteleina o tatou aoina ma fuainumera sili atu le tolu
/// c.extend(vec![1, 2, 3]);
///
/// // ua tatou faaopoopo nei elemene i luga o le iuga
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Tuuina atu se aoina ma le anotusi o se iterator.
    ///
    /// E pei o le auala na manaomia lenei mo lenei trait, e aofia ai auiliiliga sili atu le docs [trait-level].
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // E mafai ona e tuuina atu se manoa ma nisi chars:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Faʻalauteleina se aoina ma le tasi lava le elemeni.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Vaega eleele faasao o tulaga i se tuufaatasiga mo le tuuina mai le tele o elemene faaopoopo.
    ///
    /// Le faatinoga lē mafai e se mea.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}