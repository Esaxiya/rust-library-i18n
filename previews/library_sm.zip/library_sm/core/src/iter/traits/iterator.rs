// amanaiaina-mama-filelength lenei faila e toetoe lava atoatoa e aofia ai le faamatalaga o le `Iterator`.
// E le mafai ona tatou vaeluaina i ni faila se tele.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Se Ofisa mo le tagofiaina o iterators.
///
/// o le autu iterator lenei trait.
/// Mo nisi masani e uiga i le mataupu o le iterators, faamolemole tagai i le [module-level documentation].
/// A faʻapitoa lava, atonu e te manaʻo e iloa pe faʻafefea X00.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// O le ituaiga o le elemene le iterated luga.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Sii le iterator ma toe foi le isi taua.
    ///
    /// Faafoi [`None`] pe iteration Ua taunuu.
    /// e mafai ona filifili implementations tagata iterator faaauau iteration, ma valaau toe `next()` mafai pe le mafai e le iu lava ina amata ona toe foi [`Some(Item)`] i se taimi.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // O se valaau ia next() toe faafoi le isi taua ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ma i luga o lea leai se taimi e tasi e.
    /// assert_eq!(None, iter.next());
    ///
    /// // Sili atu valaauga e mafai pe le mafai ona toe foi `None`.Iinei, o le a latou i taimi uma.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Toe foi le tuaoi i le umi o totoe o le iterator.
    ///
    /// Faʻapitoa lava, `size_hint()` faʻafoʻi mai se tuple o le mea muamua elemeni o le pito i lalo o le laina, ma le lona lua elemeni o le pito i luga fusia.
    ///
    /// O le afa lona lua o le tuple ua toe foi o se ['Option`]' <'[' usize`] '>'.
    /// O le [`None`] iinei o lona uiga a leai e leai se iloa i luga pito i luga, pe o le pito i luga o le lapoʻa e lapoʻa nai lo [`usize`].
    ///
    /// # faatinoga faamatalaga
    ///
    /// E le faʻamalosia e se faʻatulafonoina faʻatinoina maua mai le folafolaina numera o elemene.O se taavale solofanua iterator mafai gauai itiiti ifo i le pito i lalo noatia po o le sili atu nai lo le pito i luga noatia o elemene.
    ///
    /// `size_hint()` e faʻamoemoe lava e faʻaaoga mo faʻamautuina pei o le faʻasao o le avanoa mo elemene o le faʻasolosolo, ae le tatau ona faʻatuatuaina e faʻapea, aveʻesea tuaoi siaki i le le saogalemu code.
    /// O se faatinoga le saʻo o `size_hint()` le tatau ona taitai atu ai i le solia manatua le saogalemu.
    ///
    /// Na faapea mai, o le faatinoina e tatau ona tuuina atu se faatatau saʻo, ona e ese o le a avea o se solia o le Maliega Faafeagaiga a le trait.
    ///
    /// Toe foi mai le faatinoga faaletonu '(0,' ['None`]') 'ua saʻo mo so o se iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// O se faataitaiga sili atu ona faigata:
    ///
    /// ```
    /// // O le numera o mai lava o le sefulu.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // E mafai ona tatou iterate mai o le sefulu taimi.
    /// // O le iloaina o le lima tonu tonu e le mafai e aunoa ma le faʻataunuʻuina o le filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Sei o tatou faaopoopo lima sili fuainumera i chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // o lea ua faʻateleina uma tuaoi e lima
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Toe foi `None` mo se noatia pito i luga:
    ///
    /// ```
    /// // o le faʻavasegaina faʻavavau e leai se pito i luga faʻatapulaʻaina ma le tapulaʻa maualuga mafai pito i lalo
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Faʻaumaina le faʻasolosolo, faitauina le numera o faʻasolitulafono ma toe faʻafoʻi mai.
    ///
    /// O lenei auala o le a valaau atu pea [`next`] seia fetaiai [`None`], toe foi le aofai o taimi e vaaia ai [`Some`].
    /// Manatua o [`next`] e tatau ona valaʻau ia le itiiti ifo ma le tasi faʻatasi tusa lava pe o le iterator e leai ni elemene.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Loloto amioga
    ///
    /// O le metotia e leai se puipuiga faasaga i masuasua, o lea o le faitauina o elemene o le iterator ma sili atu i le [`usize::MAX`] elemene a le maua ai le sese taunuʻuga poʻo panics.
    ///
    /// A faʻapea o faʻamatalaga faʻailo e mafai ai, o le panic e mautinoa.
    ///
    /// # Panics
    ///
    /// Lenei gaioiga ono panic pe a fai o le iterator e sili atu nai lo [`usize::MAX`] elemene.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Alu uma le iterator, toe foi le vaega e gata ai.
    ///
    /// Lenei metotia o le a iloiloina le iterator seia toe foi [`None`].
    /// A o faia lena mea, na te siakiina le elemeni o loʻo i ai nei.
    /// Ina ua mavae ua toe foi [`None`], o le a lea `last()` toe foi le vaega mulimuli o le vaai i ai.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Faʻalauteleina le faʻasolosolo e `n` elemene.
    ///
    /// O lenei metotia o le a faʻamalieina ai `n` elemeni e ala i le valaʻau i le [`next`] e oʻo atu i le `n` taimi seʻia maua le [`None`].
    ///
    /// `advance_by(n)` le a toe foi [`Ok(())`][Ok] pe sii le manuia le iterator e elemene `n`, po [`Err(k)`][Err] pe afai e fetaiaʻi [`None`], lea `k` o le aofai o elemene iterator o le alualu i luma e ala i luma o le tamoe i fafo o elemene (ie
    /// le umi o le iterator).
    /// Manatua o `k` e masani ona laʻititi ifo i le `n`.
    ///
    /// Valaau `advance_by(0)` e le faaumatia o so o se elemene ma toe foi mai lava [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // naʻo le `&4` na faʻamavae
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Toe foi le 'elemene n`th o le iterator.
    ///
    /// Pei o le tele o gaoioiga o le faasino igoa, o le faitauga amata mai o, ina ua toe foi `nth(0)` le uluai taua, `nth(1)` le lona lua, ma faapena ai lava.
    ///
    /// Manatua e elemene muamua uma, e pei foi o le elemene toe foi, o le a faaumatia mai le iterator.
    /// O lena auala o le a tiai nei elemene muamua, ma ina ia valaau `nth(0)` taimi tele i luga o le iterator lava lea e tasi o le a toe foi elemene eseese.
    ///
    ///
    /// `nth()` le a toe foi [`None`] pe afai e sili `n` nai lo pe tutusa ma le umi o le iterator.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Valaau `nth()` taimi tele e le solomuli le iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Faʻafoʻi `None` pe a fai e laititi ifo i le `n + 1` elemeni:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Faatupuina ai se iterator amata i le taimi lava e tasi, ae o le laa e ala i le aofaiga o tupe na tuuina atu i iteration taitasi.
    ///
    /// Faʻaliga 1: O le muamua elemeni o le faʻasolosolo o le a toe faʻafoʻi mai i taimi uma, tusa lava poʻo le a le laʻasaga ua tuʻuina atu
    ///
    /// Faaaliga 2: O le taimi lea o lo o toso elemene le amanaiaina e le tumau.
    /// `StepBy` amio e pei o le faasologa `next(), nth(step-1), nth(step-1),…`, ae o le saoloto e amio foi e pei o le faasologa
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// O le fea auala e faʻaaogaina e ono suia mo nisi iterators mo faʻatinoina mafuaʻaga.
    /// O le auala lona lua o le a alualu ai i luma le iterator muamua ma ono faʻaumatia tele aitema.
    ///
    /// `advance_n_and_return_first` e tutusa ma le:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// O le auala a panic pe afai o le tuuina mai laasaga o le `0`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Aveina iterators lua ma fausia ai se fou faʻasolosolo luga uma uma i le faʻasologa.
    ///
    /// `chain()` a toe foi mai a iterator fou lea o le a muamua iterate i luga o tulaga faatauaina mai le muamua iterator ma i luga o tulaga faatauaina mai le iterator lona lua.
    ///
    /// I se isi faaupuga, e fesootai faatasi ai le toalua iterators, i se filifili.🔗
    ///
    /// [`once`] e masani ona faʻaaogaina e fetuʻunaʻi ai le tasi tau aoga i se filifili o isi ituaiga faʻasolosolo.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Talu ai e faaaoga e le finauga e `chain()` [`IntoIterator`], e mafai ona tatou oo i se mea e mafai ona faaliliuina i se [`Iterator`], e le na o se [`Iterator`] lava ia.
    /// Mo se faataitaiga, fasi (`&[T]`) faatino [`IntoIterator`], ma ina ia mafai ona pasia e `chain()` saʻo:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Afai e te galue ma API Windows, atonu e te manao e faaliliu [`OsStr`] e `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips aʻe' lua iterators i se iterator tasi o taitoalua.
    ///
    /// `zip()` faʻafoʻi mai se faʻavae fou o le a faʻataʻamilomiloina i luga o isi iterator lua, faʻafoʻi mai se tuple o le mea muamua elemene e sau mai le muamua faʻamau, ma le lona lua elemene sau mai le lona lua iterator.
    ///
    ///
    /// I se isi faaupuga, e zips faatasi ai le toalua iterators, i se tasi e tasi.
    ///
    /// A faʻapea e toe faafoi mai le [`None`], [`next`] mai le zipped iterator o le a toe foʻi mai [`None`].
    /// Afai e le toe foi muamua iterator [`None`], `zip` a o le a le taʻua puupuu-matagaluega ma `next` i le iterator lona lua.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Talu ai o le finauga i le `zip()` faʻaaogaina le [`IntoIterator`], e mafai ona tatou pasia se mea e mafai ona liua i totonu o le [`Iterator`], ae le naʻo le [`Iterator`] lava ia.
    /// Mo se faʻataʻitaʻiga, fasi (`&[T]`) faʻaoga [`IntoIterator`], ma e mafai ona pasi tuusaʻo i le `zip()`.
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` e masani ona faaaoga e ZIP se iterator le iʻu i se tasi gata.
    /// O lenei galuega ona o le gata o le a iu iterator toe foi [`None`], faaiuina le sipi.mafai ona e vaai Zipping ma `(0..)` tele e pei o [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Faatupu ai se iterator fou lea e tuu ai se ata o `separator` i le va o mea e sosoo o le uluai iterator.
    ///
    /// I le tulaga `separator` e le faʻaogaina [`Clone`] pe manaʻomia foi ona fuafuaina i taimi uma, faʻaaoga [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // O le elemene muamua mai `a`.
    /// assert_eq!(a.next(), Some(&100)); // O le tuueseese
    /// assert_eq!(a.next(), Some(&1));   // O le elemene sosoo mai `a`.
    /// assert_eq!(a.next(), Some(&100)); // O le tuueseese
    /// assert_eq!(a.next(), Some(&2));   // Le elemene mulimuli mai `a`.
    /// assert_eq!(a.next(), None);       // Ua uma le faalua.
    /// ```
    ///
    /// `intersperse` mafai ona aoga tele e auai i le iterator aitema faʻaaogaina se masani elemeni:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Faatupu ai se iterator fou lea e tuu se mea e faia e `separator` i le va o mea e sosoo o le uluai iterator.
    ///
    /// Le tapunia o le a valaauina tonu le taimi e tasi i taimi taitasi ua tuuina se mea i le va o mea e sosoo e lua mai le iterator faavae;
    /// faapitoa, o le tapunia o le valaauina pe afai o le gauai faavae iterator itiiti ifo nai lo mea e lua ma ina ua mavae le mea e gata ai ua gauai atu.
    ///
    ///
    /// Afai meafaigaluega o le aitema o le iterator [`Clone`], atonu e faigofie e faaaoga [`intersperse`].
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // O le elemene muamua mai `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // O le tuueseese
    /// assert_eq!(it.next(), Some(NotClone(1)));  // O le isi elemeni mai `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // O le tuueseese
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Le elemene mulimuli mai mai `v`.
    /// assert_eq!(it.next(), None);               // Ua uma le faalua.
    /// ```
    ///
    /// `intersperse_with` e mafai ona faaaoga i tulaga e tatau ona fuafuaina le tuueseeseina:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // mutably borrows lona tulaga o le tapunia e faatupuina ai se mea.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Manaomia le a tapunia ma faatupuina ai se iterator lea valaau e tapunia i elemene taitasi.
    ///
    /// `map()` liua se tasi iterator atu i se isi, e ala i ana finauga:
    /// se mea e faʻaaogaina [`FnMut`].E tuuina atu e se iterator fou lea valaau lenei tapunia i elemene taitasi o le uluai iterator.
    ///
    /// Afai e te lelei i le mafaufau i ituaiga, oe mafai ona mafaufau i le `map()` faʻapea:
    /// Afai e te maua se iterator ua e maua ai elemene o nisi ituaiga `A`, ma e te manao i se iterator o se isi ituaiga `B`, e mafai ona e faaaogaina `map()`, e pasi a tapunia e avea ai se `A` ma toe foi mai a `B`.
    ///
    ///
    /// `map()` o conceptually faapena i se matasele [`for`].Peitaʻi, ona o le `map()` e paie, e sili ona faʻaaoga pe a fai o lea ua e galue faʻatasi ma isi auala.
    /// Afai o loo e faia se ituaiga o looping mo se aafiaga itu, o loo manatu sili idiomatic e faaaoga [`for`] nai lo `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Afai o loʻo e faia ni ituaiga o itu, filifili [`for`] i le `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // aua le faia le mea lea:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // o le a le oo lava faaoo, e pei ona o le paie.a lapataia outou Rust e uiga i lenei mea.
    ///
    /// // Nai lo lena, faaaoga mo:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Taʻu a tapunia i vaega taitasi o se iterator.
    ///
    /// e tutusa lenei e faaaoga ai se matasele [`for`] i le iterator, e ui lava e le mafai `break` ma `continue` mai a tapunia.
    /// E masani lava ona sili idiomatic e faaaoga se matasele `for`, ae e mafai ona sili atu ona manino lelei `for_each` pe ona iloilo mea i le faaiuga o filifili toe iterator.
    ///
    /// I nisi tulaga `for_each` atonu foi e sili atu le saoasaoa nai lo le matasele, aua o le a faʻaaogaina faʻasolosolo i totonu i luga o adapters pei o `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Mo se faʻataʻitaʻiga laʻititi, o le `for` matasele atonu e sili atu le mama, ae o le `for_each` atonu e sili ai le teuina o se gaioiga masani ma umi faʻasolosolo:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Faatupuina ai se iterator lea faaaoga a tapunia e iloilo ai pe tatau ona tuu atu se elemene.
    ///
    /// Tuuina mai se elemene tatau ona toe foi le tapunia `true` po `false`.O le faʻafoʻi faʻafoʻi o le a maua naʻo elemene o le tapunia toe foʻi moni.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Talu ai o le tapunia pasi i `filter()` aveina se faʻasino, ma tele iterators faʻasolosolo luga faʻasino, lea e tau atu ai i se ono fenumiai tulaga, lea o le ituaiga o le tapunia o se faʻalua faʻasinoga:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // manaʻomia lua * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// E le masani ai ae faaaoga destructuring i luga o le finauga e aveesea ese se tasi:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // uma&ma *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// poʻo mea uma e lua:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // lua &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// o nei faaputuga.
    ///
    /// Manatua o `iter.filter(f).next()` e tutusa `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Faatupuina ai se iterator faapea o faamama ma faafanua.
    ///
    /// O le toe foi gauai iterator na o le 'value`s mo lea toe afio mai le tapunia tuuina `Some(value)`.
    ///
    /// `filter_map` mafai ona faaaogaina e faia filifili o [`filter`] ma [`map`] sili puupuu.
    /// O le faʻataʻitaʻiga o loʻo i lalo e faʻaalia ai le `map().filter().map()` mafai ona faʻapuʻupuʻuina i le tasi valaʻau i le `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Lenei le tutusa faʻataʻitaʻiga, ae ma [`filter`] ma [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Fausia se iterator lea e maua ai le faʻavasega taimi nei faitauga faʻapea foi ma le isi taua.
    ///
    /// O le iterator taitoalua gauai toe foi `(i, val)`, lea `i` o le faasino upu i le taimi nei o iteration ma `val` o le tau toe foi e le iterator.
    ///
    ///
    /// `enumerate()` tausia lona faitauga o se [`usize`].
    /// Afai e te manaʻo e faitau i se fuainumera tele fuainumera, o le [`zip`] gaioiga faʻaopoopoina tutusa faʻatinoga.
    ///
    /// # Loloto amioga
    ///
    /// E leai se leoleo le auala e faasaga i taumasuasua, o lea enumerating sili atu nai lo elemene [`usize::MAX`] pe maua ai le taunuuga sese pe panics.
    /// A faʻapea o faʻamatalaga faʻailo e mafai ai, o le panic e mautinoa.
    ///
    /// # Panics
    ///
    /// toe foi mai le iterator mafai panic pe afai o le e-ona-toe foi faasino upu a pa i tua a [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Faatupuina ai se iterator e mafai ona e faaaogaina [`peek`] e vaai i le vaega e sosoo ai o le iterator aunoa ma alu ai.
    ///
    /// Faaopoopo ai se metotia [`peek`] i se iterator.Tagai i ana pepa aloaia mo nisi faamatalaga.
    ///
    /// Faaaliga o le faavae iterator ua agai pea ina ua taʻua [`peek`] mo le taimi muamua: I ina ia toe maua le vaega e sosoo ai, ua taʻua o [`next`] i luga o le faavae iterator, o le mea lea so o se aafiaga itu (ie
    ///
    /// e iai seisi mea e ese mai i le fetosina mai o le isi tau) o le [`next`] auala o le a tupu.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() tuʻu mai tatou e vaʻai i totonu o le future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // e mafai ona tatou peek() tele taimi, o le faʻasolosolo o le a le alualu i luma
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // a maeʻa le faʻailo, e faʻapena foi peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Fausia se mea faʻasolosolo e [`lele '' s elemeni faʻavae i luga o se predicate.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` e a tapunia o se finauga.O le a valaʻau lenei tapunia i luga o elemeni taʻitasi o le iterator, ma le amanaʻia elemeni seʻia oʻo i le toe faʻafoʻi `false`.
    ///
    /// Ina ua mavae ua toe foi `false`, `skip_while()`'s galuega o luga, ma o le vaega o totoe o le ua gauai elemene.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Talu ai o le e tapunia pasia e `skip_while()` se faasinomaga, ma iterators tele iterate i mau, o lenei taitaia i se tulaga fenumiai mafai, pe afai o le ituaiga o le tapunia finauga o se faasinomaga e lua:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // manaʻomia lua * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Taofi pe a uma se `false` uluai:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ae o lenei semanu e sese, talu ai ua uma ona tatou maua se sese, skip_while() e le toe faʻaaogaina
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Faatupuina ai se iterator o elemene gauai faavae i luga o se predicate.
    ///
    /// `take_while()` e a tapunia o se finauga.O le a valaauina lenei tapunia i elemene taitasi o le iterator, ma gauai elemene ao toe foi `true`.
    ///
    /// Ina ua mavae ua toe foi `false`, `take_while()`'s galuega o luga, ma le le amanaiaina o totoe o le elemene.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Talu ai o le e tapunia pasia e `take_while()` se faasinomaga, ma iterators tele iterate i mau, o lenei taitaia i se tulaga fenumiai mafai, pe afai o le ituaiga o le tapunia o se faasinomaga e lua:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // manaʻomia lua * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Taofi pe a uma se `false` uluai:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Ua ia i tatou le sili atu elemene e itiiti ifo nai lo o, ae talu ai ua uma ona tatou maua se pepelo, e le o faaaogaina ai se isi take_while()
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ona manaomia `take_while()` e vaai i le taua ina ia vaai pe e tatau ona aofia ai pe leai, taumafaina iterators le a iloa ai ua aveesea:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// O le `3` le o toe i ai, ona sa faaumatia ai ina ia iloa ai pe iteration tatau ona taofi, ae sa le tuuina i totonu o le iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Faatupuina ai se iterator e gauai uma elemene e faavae i luga o se predicate ma faafanua.
    ///
    /// `map_while()` e a tapunia o se finauga.
    /// O le a valaauina lenei tapunia i elemene taitasi o le iterator, ma gauai elemene ao toe foi [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Lenei le tutusa faʻataʻitaʻiga, ae ma [`take_while`] ma [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Taofi pe a uma se [`None`] uluai:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Ua ia i tatou le sili atu elemene lea e mafai ona ofi i u32 (4, 5), ae toe foi `map_while` `None` mo `-3` (e pei o le toe foi `predicate` `None`) ma taofia `collect` i fetaiai muamua `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Talu ai `map_while()` manaʻomia le tilotilo i le tau ina ia iloa ai pe tatau ona aofia ai pe leai, faʻaumatia iterators o le a vaʻaia ua aveʻesea:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// O le `-3` le o toe i ai, ona sa faaumatia ai ina ia iloa ai pe iteration tatau ona taofi, ae sa le tuuina i totonu o le iterator.
    ///
    /// Manatua e le pei o [`take_while`] lenei iterator o **le** fused.
    /// E foi le faamaoti le mea lenei tupe iterator tuanai ai o le muamua ua toe [`None`].
    /// Afai e te manaʻomia fuse iterator, faʻaaoga [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Faatupuina ai se iterator e misi e le muamua elemene `n`.
    ///
    /// Pe a uma ona faaumatia, e gauai atu i le malologa o le elemene.
    /// Nai lo le soloia saʻo o lenei metotia, ae sui le auala `nth`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Faatupuina ai se iterator e aumaia ai lona uluai elemene `n`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` e masani ona faʻaaogaina ile faʻavasega e le gata, e faʻamaeʻa ai:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Afai e maua e itiiti ifo nai lo elemene `n`, o le a faatapulaaina lava `take` i le tele o le iterator faavae:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// O se iterator mea faʻatatau tutusa [`fold`] o lo o umia tulaga i totonu, ma tuuina atu e se iterator fou.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` e lua finauga: o le amataga aoga o le fatu fatu o le tulaga i totonu, ma le tapunia ma lua finauga, o le muamua o se suia suia i le tulaga i totonu ma le lona lua o le eletise elemene elemeni.
    ///
    /// O le tapunia mafai ona tofia i le lotoifale setete e fefaʻasoaaʻi setete i le va o faʻavaga.
    ///
    /// I luga o le faʻamaufaʻailogaina, o le tapunia o le a faʻaaogaina i elemeni taʻitasi o le iterator ma le toe faʻafoi taua mai le tapunia, o le [`Option`], e maua mai e le iterator.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // taitasi iteration, o le a tatou faateleina le tulaga e le elemene
    ///     *state = *state * x;
    ///
    ///     // lea, o le a tatou gauai le negation o le tulaga
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Faatupuina ai se iterator e galue e pei o faafanua, ae flattens fausaga faatietie leisi.
    ///
    /// O le [`map`] adapter e sili ona aoga, ae naʻo le tapunia o finauga e maua ai taua.
    /// Afai e maua se iterator nai lo lena, o loo i ai se vaega faaopoopo o indirection.
    /// `flat_map()` le a aveesea ai lenei vaega faaopoopo i luga o ana lava.
    ///
    /// E mafai ona e mafaufau ile `flat_map(f)` pei o le semantic tutusa o le [`map`] ping, ona sosoʻo ai lea ma le (`flatten`] pei o le `map(f).flatten()`.
    ///
    /// O le isi auala o le mafaufau e uiga i `flat_map()`: ['map`]' s tupe tapunia aitema se tasi mo vaega taitasi, ma `flat_map()`'s tupe tapunia se iterator mo elemene taitasi.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() faʻafoʻi mai le faʻailo
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Faatupuina ai se iterator e flattens fausaga faatietie leisi.
    ///
    /// e aoga lenei mea pe a ia te oe se iterator o iterators po o se iterator o mea e mafai ona liliu atu i iterators ma e te manao e aveese le tasi le tulaga o le indirection.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Faʻafanua ma faʻapaʻepaʻeina:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() faʻafoʻi mai le faʻailo
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// E mafai foi ona toe tusi lenei i le tulaga o [`flat_map()`], lea e sili i lenei tulaga talu ai e faaalia ai le sili atu le manatu manino:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() faʻafoʻi mai le faʻailo
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening na aveesea ai se tasi tulaga o le nesting i se taimi:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// O iinei ua tatou iloa ai e le faia `flatten()` a papa "deep".
    /// Nai lo lena, na o le tasi le tulaga o le nesting ua aveesea.O le, pe afai e te `flatten()` se autau e faatafa-tolu, o le taunuuga o le a lua e faatafa-ma e leai se tasi e faatafa-.
    /// Ina ia maua se fausaga faatafa-o le tasi, e tatau ona toe `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Fausia se iterator lea e muta pe a maeʻa le muamua [`None`].
    ///
    /// Ina ua mavae le toe foi mai se iterator [`None`], future valaauga e mafai pe le mafai ona gauai toe [`Some(T)`].
    /// `fuse()` fetuʻunaʻi se faʻasolosolo, mautinoa a maeʻa le [`None`], o le a toe foʻi mai [`None`] e faʻavavau.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// // se iterator lea e sui tulaga i le va o nisi ma leai se tasi e
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // pe afai e le lava lea, Some(i32), leai se isi mea
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // e mafai ona tatou vaʻai i le tatou taʻitaʻiga alu i luma ma tua
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ae ui i lea, o le taimi tatou te fuse ai ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // o le a toe foi atu i taimi uma `None` ina ua mavae le taimi muamua.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Pe o se mea ma vaega taitasi o se iterator, le tufaina o le taua i luga.
    ///
    /// A faaaoga iterators, o le ae masani ona filifili nisi o latou faatasi.
    /// A o e galue i luga o na tulafono laiti, oe ono manaʻo e siaki le mea o loʻo tupu i vaega eseese i le paipa.Ina ia faia lena mea, faaofi se valaauga e `inspect()`.
    ///
    /// E taatele mo `inspect()` ona faʻaaogaina o se meafaigaluega debugging nai lo le i ai i lau mulimuli code, ae o talosaga ono maua ai le aoga i nisi tulaga pe a o mea sese e manaʻomia e logged i luma o le tiaʻi.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // lenei iterator faasologa o lavelave.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ia a faaopoopo nisi valaauga inspect() e sailiili i le mea ua tupu
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Lenei o le a lolomiina:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Laʻau sese ae leʻi tiaʻiina:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Lenei o le a lolomiina:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Borrows se iterator, nai lo le alu i ai.
    ///
    /// e aoga lenei e tuu le faaaogaina o iterator adapters ao faatumauina pea le umia o le uluai iterator.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // pe afai tatou te taumafai e toe faaaoga iter, o le a le galue.
    /// // O le laina mulimuli tuuina "sese: faaaogaina o taua siitia: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // sei o tatou toe taumafai e
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // nai lo lena, matou te faʻaopopoina i le .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // o lea ua lelei mea uma:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Liua se iterator i se tuufaatasiga.
    ///
    /// `collect()` mafai ona ave soʻo se mea, ma liliuina i se talafeagai aoina.
    /// Lenei o se tasi o sili atu mamana metotia i le tulaga potutusi faletusi, faʻaaogaina i le eseesega o tala.
    ///
    /// Sili ona mamanu faavae lea e faaaogaina ai `collect()` o le liliu atu aoina le tasi i le isi.
    /// Oe ave se faʻaputuga, valaʻau i ai X00 luga, faia se vaega o fesuiaʻiga, ma ona `collect()` i le faaiuga.
    ///
    /// `collect()` mafai foi fausia ni tulaga o ituaiga e le masani ai aoina.
    /// Mo se faataitaiga, o se e mafai ona fausia [`String`] mai ['char`] s, ma se iterator o [`Result<T, E>`][`Result`] mea e mafai ona aoina i `Result<Collection<T>, E>`.
    ///
    /// Tagai i le faataitaiga o loo i lalo mo le sili.
    ///
    /// Ona e aoao `collect()`, e mafai ona mafua ai faafitauli i le faaiuga ituaiga.
    /// Ona o lea, `collect()` o se tasi o ni nai taimi o le ae vaai i le syntax alofa e taʻua o le 'turbofish': `::<>`.
    /// E fesoasoani lea i le inferensi algorithm malamalama faʻapitoa i le faʻaputuga o loʻo e taumafai e ao mai.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Manatua o le a tatou manaomia le `: Vec<i32>` i le itu tauagavale.o lenei mea ona e mafai ona tatou aoina mai i totonu, mo se faataitaiga, o se [`VecDeque<T>`] ae:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Le faaaogaina o le 'turbofish' nai lo le annotating `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Aua e na o manatu mamafa `collect()` e uiga i mea o loo aoina i totonu, e mafai lava ona faaaogaina se faaiteite ituaiga vaega, `_`, faatasi ai ma le turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Faaaogaina `collect()` e faia se [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// A iai sau lisi o le [`Iʻuga<T, E>`][` Iʻuga '] s, oe mafai ona faʻaaoga `collect()` e vaʻai pe i ai se tasi o latou ua le manuia:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // aumaia ia i tatou le sese muamua
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // tatou te maua ai le lisi o tali
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Faʻamamaina se mea faʻapipiʻi, faia ni faaputuga lua mai ai.
    ///
    /// E mafai ona toe foi predicate pasia e `partition()` `true`, po `false`.
    /// `partition()` toe foi se pea, o le elemene uma mo lea toe foi `true`, ma elemene uma mo lea toe foi `false`.
    ///
    ///
    /// Vaʻai foi [`is_partitioned()`] ma [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders le elemene o lenei iterator *i-nofoaga* e tusa ma le predicate tuuina mai, e pei o loo muamua atu i latou uma e toe foi `true` latou uma e toe foi `false`.
    ///
    /// Faʻafoʻi mai le numera o `true` elemeni maua.
    ///
    /// Le faatulagaga o le aiga o mea partitioned e le o tausia.
    ///
    /// Tagai foi [`is_partitioned()`] ma [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Vasega i totonu o le nofoaga i le va o evens ma soo se tulaga faigata
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: e tatau ona tatou popole e uiga i le sosolo masuasua faitauga?Pau lava le auala e maua ai sili atu nai lo
        // `usize::MAX` mutable mau faatasi ai ma ZSTs, lea e le aoga i vasega ...

        // ai nei tapunia galuega tauave "factory" e aloese genericity i `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Fia maua le uluai `false` ma Faafesuiaiga ai ma le `true` mulimuli.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Siaki pe a fai o vaevaega o lenei iterator e vaeluaina e tusa ai ma le predicate ua tuʻuina atu, e pei o na mea uma e toe faʻafoʻi `true` muamua i latou uma na toe faʻafoʻi `false`.
    ///
    ///
    /// Tagai foi [`partition()`] ma [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // A tofotofoina mea uma `true`, po o le fuaiupu muamua taofia i `false` ma tatou siaki e leai ni sili atu mea `true` ina ua maeʻa.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// O se iterator metotia e faaaogā i se galuega tauave e pei o le umi e pei ona toe foi mai ma le manuia, tuuina atu o se tasi, le taua mulimuli.
    ///
    /// `try_fold()` e finauga e lua: o se taua muamua, ma a tapunia ai ma finauga e lua: o se 'accumulator', ma se elemene.
    /// Le tapunia pe toe foi mai ma le manuia, ma le taua o le tatau ona i ai accumulator mo le isi iteration, pe toe toilalo, ma o se mea sese taua ua propagated toe foi atu i le Tagata telefoni vave (short-circuiting).
    ///
    ///
    /// O le taua muamua o le taua o le a maua le accumulator i le valaauga muamua.Afai o le faʻaogaina o le tapunia na faʻamanuiaina i vaega uma o le iterator, `try_fold()` faʻafoʻi mai le mulimuli accumulator o le manuia.
    ///
    /// e aoga gaugauina i soo se taimi e te maua ai se tuufaatasiga o se mea, ma e te manao e tuuina atu se taua e tasi mai ai.
    ///
    /// # Faʻamatalaga i Tagata Faʻatino
    ///
    /// O nisi o le isi metotia (forward) maua implementations faaletonu i le tulaga o lenei, o lea e taumafai e faatino ai lenei manino pe afai e mafai ona e faia se mea sili atu nai lo le faatinoina matasele faaletonu `for`.
    ///
    /// Aemaise, taumafai e maua lenei valaauga `try_fold()` i luga o le vaega i le lotoifale lea e aofia ai lenei iterator.
    /// Afai e manaomia valaauga e tele, e mafai ona faigofie le faagaoioia `?` mo chaining le taua accumulator faatasi, ae ia faaeteete i soo se invariants e manaomia ona lagolagoina i luma o latou toe foi mai le amataga.
    /// o se auala `&mut self` lenei, ina iteration manaomia e avea resumable ina ua uma ona taia o se mea sese iinei.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // le aofaʻi siaki o uma elemene o le faʻasologa
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // O lenei aofaiga taumasuasua pe a faaopoopo le 100 elemene
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Ona puupuu-circuited ai, o loo maua pea elemene totoe e ala i le iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// O se auala faʻasolosolo e faʻaogaina se mea e mafai ona paʻu i mea taʻitasi i le iterator, taofi i le muamua mea sese ma toe faʻafoʻi mai lena mea sese.
    ///
    ///
    /// e mafai foi ona manatu i lenei mea o le a lava le ituaiga fallible o [`for_each()`] po o le aloaia sona atunuu lomiga o [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // E puupuu-circuited, o lea le mea o totoe ua i ai pea i le iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Gauga elemene uma i se accumulator ala i le faaaogaina o se taotoga, toe foi le taunuuga mulimuli.
    ///
    /// `fold()` e finauga e lua: o se taua muamua, ma a tapunia ai ma finauga e lua: o se 'accumulator', ma se elemene.
    /// Le tapunia toe foi mai le taua e tatau ona maua le accumulator mo le isi iteration.
    ///
    /// O le taua muamua o le taua o le a maua le accumulator i le valaauga muamua.
    ///
    /// Ina ua mavae le faaaogaina o lenei tapunia i elemene uma o le iterator, Ua toe foi `fold()` le accumulator.
    ///
    /// Lenei taotoga i nisi taimi e taʻua 'reduce' po 'inject'.
    ///
    /// e aoga gaugauina i soo se taimi e te maua ai se tuufaatasiga o se mea, ma e te manao e tuuina atu se taua e tasi mai ai.
    ///
    /// Note: `fold()`, ma metotia faapena e laasia le iterator atoa, e le mafai ona faamutaina mo iterators le iʻu, i traits lea o fuafua i se taunuuga i le taimi gata.
    ///
    /// Note: e mafai ona faaaoga [`reduce()`] e faaaoga le elemene muamua o le taua muamua, pe afai e tutusa lava le ituaiga ituaiga ma mea accumulator.
    ///
    /// # Faʻamatalaga i Tagata Faʻatino
    ///
    /// O nisi o le isi metotia (forward) maua implementations faaletonu i le tulaga o lenei, o lea e taumafai e faatino ai lenei manino pe afai e mafai ona e faia se mea sili atu nai lo le faatinoina matasele faaletonu `for`.
    ///
    ///
    /// A e maise, taumafai ia i ai lenei valaʻau `fold()` i totonu o vaega o loʻo i totonu lea e faʻavae ai lenei iterator.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // le aofaiga o elemene uma o le autau
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// o le savali ia e ala i laasaga taitasi o le iteration iinei:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Ma o lea, o lo tatou taunuuga faaiu, `6`.
    ///
    /// E le tutusa mo tagata oe ua le faaaogaina iterators tele e faaaoga se matasele `for` ma se lisi o mea e fausia se taunuuga.O i latou e mafai ona liliu atu i `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // mo matasele:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // latou te le lava lea e tasi
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Faʻaititia elemene i le tasi tasi, e ala i le faʻaauau ona faʻaogaina se faʻaititia o le taotoga.
    ///
    /// Afai e avanoa le iterator, Ua toe foi [`None`];ese, Ua toe foi le taunuuga o le faaitiitia.
    ///
    /// Mo iterators ma le itiiti ifo i le tasi vaega, o le tasi lenei o [`fold()`] ma le elemene muamua o le iterator e pei o le taua muamua, gaugauina uma elemene mulimuli ane i ai.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Saili le taua aupito maualuga:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Suʻega peʻa taʻitasi elemeni o le faʻafetauiina fetaui ma se predicate.
    ///
    /// `all()` e a tapunia e toe foi `true` po `false`.E faatatau lenei tapunia e elemene taitasi o le iterator, ma afai latou toe foi uma `true`, ona faapena `all()`.
    /// Afai o so o se latou toe foi `false`, e toe foi `false`.
    ///
    /// `all()` e puʻupuʻu-taʻamilo;i ni isi upu, o le a taofia ona iloilo i se taimi vave e pei ona maua e se `false`, na tuuina mai e tusa lava po oa isi mea e tupu, o le a foi le taunuuga `false`.
    ///
    ///
    /// toe foi se iterator gaogao `true`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Taofi i le muamua `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // mafai lava ona tatou faaaogaina `iter`, e pei ua sili elemene.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Tofotofoga pe afai e fetaui ma soo se vaega o le iterator a predicate.
    ///
    /// `any()` e a tapunia e toe foi `true` po `false`.E faatatau lenei tapunia e elemene taitasi o le iterator, ma afai o so o se latou toe foi `true`, ona faapena `any()`.
    /// Afai latou toe foi uma `false`, e toe foi `false`.
    ///
    /// `any()` ua puupuu-circuiting;i ni isi upu, o le a taofia ona iloilo i se taimi vave e pei ona maua e se `true`, na tuuina mai e tusa lava po oa isi mea e tupu, o le a foi le taunuuga `true`.
    ///
    ///
    /// O le faʻaoga avanoa e toe faʻafoʻi mai le `false`.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Taofi i le muamua `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // mafai lava ona tatou faaaogaina `iter`, e pei ua sili elemene.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Sailiga mo se elemene o se iterator e faamalieina a predicate.
    ///
    /// `find()` faia se tapunia e toe faafoi `true` poʻo `false`.
    /// E faatatau lenei tapunia e elemene taitasi o le iterator, ma afai o so o se latou toe foi `true`, ona toe foi `find()` [`Some(element)`].
    /// Afai latou toe foi uma `false`, e toe foi [`None`].
    ///
    /// `find()` ua puupuu-circuiting;i ni isi upu, o le a taofia ona iloilo i se taimi vave e pei o le tapunia toe foi `true`.
    ///
    /// Ona e `find()` se faasinomaga, ma e toatele iterators iterate i mau, o lenei taitaia e a mafai fenumiai tulaga pe afai o le finauga o se faasinomaga lua.
    ///
    /// E mafai ona e vaai i lenei aafiaga i le faataitaiga o loo i lalo, faatasi ai ma `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Taofi i le muamua `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // mafai lava ona tatou faaaogaina `iter`, e pei ua sili elemene.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Manatua o `iter.find(f)` e tutusa `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Faaaogaina o galuega tauave e le elemene o iterator ma toe foi mai le muamua taunuuga lē e leai se tasi.
    ///
    ///
    /// `iter.find_map(f)` e tutusa `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Faaaogaina o galuega tauave e le elemene o iterator ma toe foi mai le muamua taunuuga moni po o le sese muamua.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Sailiga mo se elemene i se iterator, toe foi lona faasino upu.
    ///
    /// `position()` faia se tapunia e toe faafoi `true` poʻo `false`.
    /// E faatatau lenei tapunia e elemene taitasi o le iterator, ma afai o se tasi o latou toe foi `true`, ona toe foi `position()` [`Some(index)`].
    /// Afai o latou uma toe foʻi mai `false`, e toe faʻafoi [`None`].
    ///
    /// `position()` ua puupuu-circuiting;i ni isi upu, o le a taofia ona iloilo i se taimi vave e pei ona maua e se `true`.
    ///
    /// # Loloto amioga
    ///
    /// O le metotia e leai se puipuiga faasaga i le ova, pe afai e sili atu nai lo [`usize::MAX`] elemeni tutusa, a le maua ai le sese taunuʻuga poʻo panics.
    ///
    /// A faʻapea o faʻamatalaga faʻailo e mafai ai, o le panic e mautinoa.
    ///
    /// # Panics
    ///
    /// O lenei galuega atoa panic afai e sili atu le iterator nai lo `usize::MAX` elemene e le fetaui i ai.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Taofi i le muamua `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // mafai lava ona tatou faaaogaina `iter`, e pei ua sili elemene.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Le faasino upu toe foi e faalagolago i iterator tulaga
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Sailiga mo se elemene i se iterator mai le itu taumatau, ua toe foi mai lona faasino upu.
    ///
    /// `rposition()` faia se tapunia e toe faafoi `true` poʻo `false`.
    /// E faatatau lenei tapunia e elemene taitasi o le iterator, e amata mai le iuga, ma pe afai o se tasi o latou toe foi `true`, ona toe foi `rposition()` [`Some(index)`].
    ///
    /// Afai o latou uma toe foʻi mai `false`, e toe faʻafoi [`None`].
    ///
    /// `rposition()` ua puupuu-circuiting;i ni isi upu, o le a taofia ona iloilo i se taimi vave e pei ona maua e se `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Taofi i le muamua `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // mafai lava ona tatou faaaogaina `iter`, e pei ua sili elemene.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // E leai se manaomia o se faatumulia siaki iinei, ona e faatatau `ExactSizeIterator` o le aofai o elemene fetaui i se `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Toe afio mai le elemene aupito maualuga o se iterator.
    ///
    /// Afai e tutusa le maualuga tele o elemene, ua toe foi le vaega e gata ai.
    /// Afai e avanoa le iterator, ua toe foi [`None`].
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Toe afio mai le elemene aupito i maualalo o se iterator.
    ///
    /// Afai e tutusa lava le maualalo tele o elemene, o le elemene muamua o le toe foi mai.
    /// Afai e avanoa le iterator, ua toe foi [`None`].
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Toe foi le elemene e tuuina mai e le taua aupito maualuga mai le galuega tauave ua faamaotiina.
    ///
    ///
    /// Afai e tutusa le maualuga tele o elemene, ua toe foi le vaega e gata ai.
    /// Afai e avanoa le iterator, ua toe foi [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Toe foi le elemene e tuuina mai e le taua aupito maualuga e tusa ai o le galuega tauave faatusatusaga maoti.
    ///
    ///
    /// Afai e tutusa le maualuga tele o elemene, ua toe foi le vaega e gata ai.
    /// Afai e avanoa le iterator, ua toe foi [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Faʻafoʻi mai le elemene e maua ai le tau maualalo mai le faʻatulagaina gaioiga.
    ///
    ///
    /// Afai e tutusa lava le maualalo tele o elemene, o le elemene muamua o le toe foi mai.
    /// Afai e avanoa le iterator, ua toe foi [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Toe foi le elemene e tuuina mai e le taua aupito maualalo e tusa ai o le galuega tauave faatusatusaga maoti.
    ///
    ///
    /// Afai e tutusa lava le maualalo tele o elemene, o le elemene muamua o le toe foi mai.
    /// Afai e avanoa le iterator, ua toe foi [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Tulaga tuufaafeagai le taitaiga a se iterator.
    ///
    /// E masani lava, iterators iterate mai le tauagavale i le taumatau.
    /// A maeʻa ona faʻaaoga le `rev()`, o le a faʻaauau ona faʻasolosolo malie mai le taumatau i le agavale.
    ///
    /// ua na mafai lenei pe afai o le iterator ei ai se iuga, o lea na galue `rev()` i ['DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Tagata liliu mai se iterator o taitoalua i se pea pusa.
    ///
    /// `unzip()` alu uma se iterator atoa o taitoalua, fua lua aoina: o le tasi mai le elemene tauagavale o le paga, ma le tasi mai le vaega sao.
    ///
    ///
    /// O lenei galuega o, i nisi tulaga, o le faafeagai o [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Faatupuina ai se iterator lea kopi uma o ona elemene.
    ///
    /// e aoga lenei mea pe a ia te oe se iterator i `&T`, ae e manaomia se iterator i `T`.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // e tutusa lava kopiina pei .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Fausia se iterator lea [`clone`] uma o ona elemene.
    ///
    /// e aoga lenei mea pe a ia te oe se iterator i `&T`, ae e manaomia se iterator i `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned e tutusa ma .map(|&x| x), mo integers
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Toe fai se faʻavavau.
    ///
    /// Nai lo le taofi i le [`None`], o le mea faʻasolosolo o le a toe amata, mai le amataga.A maeʻa ona toe fai, e toe amata foʻi ile amataga.Ma faʻapea foi.
    /// Ma faʻapea foi.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Aofaʻi elemene o le faʻasolosolo.
    ///
    /// E taitasi le elemene, ua faaopoopo mai faatasi i latou, ma toe foi mai le taunuuga.
    ///
    /// O se gaogao toe foi iterator le taua o le ituaiga.
    ///
    /// # Panics
    ///
    /// Ina ua valaau `sum()` ma se ituaiga integer anamua ua toe foi, o le a panic pe afai e mafai ai e le faatatauina taumasuasua ma assertions debug lenei metotia.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates i le iterator atoa, faateleina elemene uma
    ///
    /// O se gaogao toe foi iterator le tasi le taua o le ituaiga.
    ///
    /// # Panics
    ///
    /// A toe valaʻau le `product()` ma le primitive integer type ua toe faʻafoʻi mai, metotia o le a panic pe a fai o le faʻatusatusaina o vai ma faʻamaʻaina faʻamatalaga e mafai ai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) faatusatusa ai le elemene o lenei [`Iterator`] faatasi ma i latou o le isi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) faatusatusa ai le elemene o lenei [`Iterator`] faatasi ma i latou o le isi e tusa ai o le galuega tauave faatusatusaga maoti.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) faatusatusa ai le elemene o lenei [`Iterator`] faatasi ma i latou o le isi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) faatusatusa ai le elemene o lenei [`Iterator`] faatasi ma i latou o le isi e tusa ai o le galuega tauave faatusatusaga maoti.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Fuafuaina pe afai o le elemene o lenei [`Iterator`] e tutusa i latou o le isi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Fuafuaina pe afai o le elemene o lenei [`Iterator`] e tutusa i latou o le isi e tusa ai o le galuega tauave tutusa maoti.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Fuafuaina pe afai o le elemene o lenei [`Iterator`] e le tutusa i latou o le isi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Fuafua pe o elemene o lenei [`Iterator`] e [lexicographically](Ord#lexicographical-comparison) laititi atu nai lo isi o le isi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Fuafuaina pe afai o le elemene o lenei [`Iterator`] e [lexicographically](Ord#lexicographical-comparison) itiiti po o le tutusa i latou o le isi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Fuafua pe o elemene o lenei [`Iterator`] e [lexicographically](Ord#lexicographical-comparison) sili atu nai lo isi o le isi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Fuafuaina pe afai o le elemene o lenei [`Iterator`] e sili atu nai lo [lexicographically](Ord#lexicographical-comparison) po o tutusa ma ia i latou o le isi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Siaki pe afai o le o loo faavasega elemene o lenei iterator.
    ///
    /// O lona uiga, mo elemene taitasi `a` ma ona elemene nei `b`, e tatau ona `a <= b` umia.Afai o le iterator gauai tonu o po o se tasi elemene, ua toe foi `true`.
    ///
    /// Manatua afai `Self::Item` ua na `PartialOrd`, ae le `Ord`, o le faamatalaga i luga aʻe o lona uiga e toe foi lenei galuega tauave `false` pe afai o so o se mea e sosoo e lua e le tutusa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Siaki pe afai o le o loo faavasega elemene o lenei iterator le faaaogaina o le galuega tauave comparator tuuina mai.
    ///
    /// Nai lo le faʻaaogaina o le `PartialOrd::partial_cmp`, o lenei gaioiga e faʻaaogaina ai le `compare` galuega e tuʻuina atu e fuafua ai le okaina o elemeni e lua.
    /// E ese mai lena, e le tutusa ma [`is_sorted`];iloa atu ona pepa mo nisi faamatalaga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Siaki pe afai o le elemene o lenei ua faavasega iterator le faaaogaina o le galuega tauave aveesea mai ki tuuina mai.
    ///
    /// Nai lo o le faatusatusaina o elemene o le iterator saʻo, faatusatusa lenei galuega tauave o le ki o le elemene, pei ona fuafuaina e `f`.
    /// E ese mai lena, e le tutusa ma [`is_sorted`];iloa atu ona pepa mo nisi faamatalaga.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Tagai [TrustedRandomAccess]
    // O le igoa e le masani ai o le aloese collisions igoa i faaiuga auala vaai #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}