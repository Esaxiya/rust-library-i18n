use crate::ops::{ControlFlow, Try};

/// O se iterator mafai ona elemene fua mai uma tuluiga.
///
/// Se mea e meafaigaluega `DoubleEndedIterator` ei ai se tasi tulaga gafatia faaopoopo i luga o se mea e meafaigaluega [`Iterator`]: le tomai e ave 'Item`s mai tua, faapea foi ma le pito i luma.
///
///
/// E taua le faamatalaga o le galuega uma i tua ma luma i luga o le vaega lava e tasi, ma faia le satauro: iteration o luga pe a latou feiloai i le ogatotonu.
///
/// I se faiga e tutusa ma le maliega faafeagaiga [`Iterator`], o le taimi a toe foi `DoubleEndedIterator` [`None`] mai se [`next_back()`], valaau toe mafai pe le mafai foi lava toe foi [`Some`].
/// [`next()`] ma [`next_back()`] e fesuiaʻi mo lenei faʻamoemoe.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Aveʻese ma toe faʻafoʻi mai se elemeni mai le faʻaiuga o le iterator.
    ///
    /// Faafoi `None` pe a leai ni elemene.
    ///
    /// O le [trait-level] docs o loʻo iai isi faʻamatalaga.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// O elemene na maua mai i auala o le 'DoubleEndedIterator`'s auala e ono' eseʻese mai le mea na tuʻuina mai e ['Iterator`]' metotia:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Sii le iterator mai tua e elemene `n`.
    ///
    /// `advance_back_by` o le lomiga faafeagai o [`advance_by`].a faamisi le naunautai lenei metotia elemene `n` amata mai i tua i le valaauina [`next_back`] oo atu i le taimi `n` seia fetaiai [`None`].
    ///
    /// `advance_back_by(n)` o le a toe faafoi [`Ok(())`] pe a fai o le iterator alualu i luma manuia e `n` elemene, pe [`Err(k)`] pe a fai o [`None`] o loʻo fetaiaʻi, i le `k` o le numera o elemene o le iterator e alualu i luma i luma o le leai o ni elemeni (ie
    /// le umi o le iterator).
    /// Manatua o `k` e masani ona laʻititi ifo i le `n`.
    ///
    /// Valaau `advance_back_by(0)` e le faaumatia o so o se elemene ma toe foi mai lava [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // le gata ina sa misi `&3`
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Toe foi le 'elemene n`th mai le faaiuga o le iterator.
    ///
    /// e moni le lomiga toe suia lenei o [`Iterator::nth()`].
    /// E ui lava ina pei o le tele o gaoioiga o le faasino igoa, e amata ai le faitauga mai o, ina ua toe foi `nth_back(0)` le uluai taua mai le iuga, `nth_back(1)` le lona lua, ma faapena ai lava.
    ///
    ///
    /// Manatua o le a faaumatia i elemene uma i le va o le faaiuga ma le elemene toe foi mai, e aofia ai le elemene toe foi mai.
    /// O lenei foi o lona uiga o le valaauina o taimi tele `nth_back(0)` i le iterator lava lea e tasi o le a toe foi elemene eseese.
    ///
    /// `nth_back()` le a toe foi [`None`] pe afai e sili `n` nai lo pe tutusa ma le umi o le iterator.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Valaau `nth_back()` taimi tele e le solomuli le iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Faʻafoʻi `None` pe a fai e laititi ifo i le `n + 1` elemeni:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// o le lomiga faafeagai lenei o [`Iterator::try_fold()`]: e manaomia elemene amata mai le tua o le iterator.
    ///
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Ona puupuu-circuited ai, o loo maua pea elemene totoe e ala i le iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// O se auala iterator e faaitiitia ai elemene o le iterator i se tasi, e taua mulimuli, e amata mai i le pito i tua.
    ///
    /// O le toe teuteuga lea o le [`Iterator::fold()`]: e manaʻomia elemeni amata mai le pito i tua o le iterator.
    ///
    /// `rfold()` e finauga e lua: o se taua muamua, ma a tapunia ai ma finauga e lua: o se 'accumulator', ma se elemene.
    /// Le tapunia toe foi mai le taua e tatau ona maua le accumulator mo le isi iteration.
    ///
    /// O le taua muamua o le taua o le a maua le accumulator i le valaauga muamua.
    ///
    /// A maeʻa ona faʻaaogaina lenei tapunia i elemene uma o le iterator, `rfold()` faʻafoʻi mai le tagata faʻaputu.
    ///
    /// Lenei taotoga i nisi taimi e taʻua 'reduce' po 'inject'.
    ///
    /// e aoga gaugauina i soo se taimi e te maua ai se tuufaatasiga o se mea, ma e te manao e tuuina atu se taua e tasi mai ai.
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // le aofaʻi o elemene uma o le a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// O lenei faataitaiga fausia ai se manoa, e amata i se taua muamua ma le faaauau pea ma elemene taitasi mai le pito i tua seia oo i le pito i luma:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Sailiga mo se elemene o se iterator mai le pito i tua o le faamalieina a predicate.
    ///
    /// `rfind()` faia se tapunia e toe faafoi `true` poʻo `false`.
    /// E faatatau lenei tapunia e elemene taitasi o le iterator, e amata i le faaiuga, ma afai o so o se latou toe foi `true`, ona toe foi `rfind()` [`Some(element)`].
    /// Afai latou toe foi uma `false`, e toe foi [`None`].
    ///
    /// `rfind()` ua puupuu-circuiting;i ni isi upu, o le a taofia ona iloilo i se taimi vave e pei o le tapunia toe foi `true`.
    ///
    /// Talu ai `rfind()` aveina se faʻasino, ma tele iterators faʻasolosolo luga faʻasino, o lenei mea e mafua ai i se ono fenumiai tulaga pe a fai o le finauga o se faʻamatalaga faʻalua.
    ///
    /// E mafai ona e vaai i lenei aafiaga i le faataitaiga o loo i lalo, faatasi ai ma `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Faʻaaoga faʻavae:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Taofi i le muamua `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // mafai lava ona tatou faaaogaina `iter`, e pei ua sili elemene.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}