//! O lenei module meafaigaluega le `Any` trait, lea e mafai ai ona taina maoae o so o se ituaiga `'static` e ala i manatunatuga runtime.
//!
//! `Any` lava ia mafai ona faʻaaogaina e maua ai se `TypeId`, ma e tele ona foliga pe a faʻaaogaina o se trait mea.
//! I le avea ai `&dyn Any` (o se nonogatupe trait mea), o loʻo i ai `is` ma `downcast_ref` metotia, e faʻataʻitaʻi ai pe afai o loʻo i ai le tau o se ituaiga foaʻi, ma ia maua se faʻasino i le tau i totonu o se ituaiga.
//! A o `&mut dyn Any`, o loo i ai foi le auala `downcast_mut`, mo le mauaina o se faasinomaga mutable i le taua i totonu.
//! `Box<dyn Any>` faaopoopo le auala `downcast`, lea ua taumafai e liliu mai i se `Box<T>`.
//! Tagai i le pepa [`Box`] mo le faamatalaga atoa.
//!
//! Manatua ua faatapulaaina `&dyn Any` e tofotofoina pe a taua ai o se ituaiga sima faamaoti mai, ma e le mafai ona faaaogaina e le suega pe o se meafaigaluega ituaiga a trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Faʻailoaina atamai ma `dyn Any`
//!
//! O se tasi o amioga e te mafaufau i ai pe a faʻaaoga `Any` o se trait mea, aemaise lava ma ituaiga e pei o `Box<dyn Any>` poʻo `Arc<dyn Any>`, o le na ona valaʻau `.type_id()` i luga o le tau o le a maua ai le `TypeId` o le *container*, ae le o le autu trait mea.
//!
//! Lenei e mafai ona 'alofia e ala i le faʻaliliuina o le atamai faʻasino i le `&dyn Any` nai lo, lea o le a toe faʻafoʻi mai le `TypeId` mea.
//! Faataitaiga:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Oe sili atu ai ona manao lenei:
//! let actual_id = (&*boxed).type_id();
//! // ... nai lo lenei:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Mafaufau i se tulaga tatou te manaʻo ai e faʻamalo ese se taua pasia i se gaioiga.
//! Matou te iloa le aoga o loʻo matou faʻatinoina Debug, ae matou te le iloa lona sima ituaiga.Tatou te mananao e tuuina atu ai togafitiga faapitoa i nisi ituaiga: i le tulaga lenei lolomiina mai le umi o le faatauaina manoa ao lumanai ai lo latou taua.
//! Tatou te le iloa le sima ituaiga o la tatou taua i le tuʻufaʻatasia taimi, o lea tatou manaʻomia ai ona faʻaaoga runtime mafaufauga nai lo.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger function mo soʻo se ituaiga e faʻaogaina ai le Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Taumafai e faʻaliliu la matou taua i le `String`.
//!     // A faʻamanuiaina, matou te mananaʻo e faʻaoʻo mai le umi a le String` faʻapea foʻi ma lona tau.
//!     // A leai, o se eseʻese ituaiga: na lolomi le aunoa teuteuina.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Lenei galuega tauave manaʻo e ogalaau lona parameter mai i luma o le faia galuega ma ia.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... fai nisi galuega
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Soʻo se trait
///////////////////////////////////////////////////////////////////////////////

/// A trait e faʻataʻitaʻi faʻamaʻaina lolomomoina.
///
/// Tele o ituaiga faʻaaogaina `Any`.Ae ui i lea, soʻo se ituaiga e aofia ai le le-`'static` faʻasino faʻamatalaga e leai.
/// Vaʻai le [module-level documentation][mod] mo nisi faʻamatalaga.
///
/// [mod]: crate::any
// Lenei trait e le sefe, e ui lava matou te faʻamoemoe i mea faʻapitoa o le na o le impl X1X gaioiga i le le saogalemu code (eg, `downcast`).Masani lava, o le a avea e faapea o se faafitauli, ae ona o le pau impl o `Any` o se faatinoga palanikeke, e leai se isi tulafono e mafai ona faatino `Any`.
//
// E mafai ona tatou faia plausibly saogalemu lenei trait-o le a le mafuaaga breakage, talu tatou pulea implementations uma-ae ua tatou filifili e le pei uma e lua o le mea lena e matuai talafeagai ma e mafai ona fenumiai ai tagata e faaaogaina e uiga i le eseesega o le saogalemu traits ma metotia saogalemu (ie, `type_id` e tumau pea le saogalemu e valaʻau, ae matou te ono manaʻo e faʻailoa mai faʻapea i faʻamaumauga).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Maua le `TypeId` o `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Faaopoopoina metotia mo So o se mea faitino trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Mautinoa o le iʻuga o faʻataʻitaʻiga, auai i se filo mafai ona lolomiina ma o lea faʻaaoga ai ma `unwrap`.
// Me iʻu lava le toe manaʻomia pe a lafoina galuega ma upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Faafoi `true` pe afai o le ituaiga boxed e tutusa ma `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Maua le `TypeId` o le ituaiga o lenei gaioiga e faʻamaonia ma.
        let t = TypeId::of::<T>();

        // Maua le `TypeId` o le ituaiga i le trait mea (`self`).
        let concrete = self.type_id();

        // Faatusatusa uma 'TypeId`s i le tulaga tutusa.
        t == concrete
    }

    /// Toe foi mai nisi o faasinomaga i le boxed taua pe afai e o ituaiga `T`, po `None` pe afai e leai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SAFETI: na o le siakiina pe o matou tusiina le ituaiga saʻo, ma e mafai ona matou faʻamoemoe i ai
            // lena siaki mo le saogalemu manatuaina aua ua tatou faʻatinoina Soʻo se mo ituaiga uma;e le mafai ona i ai isi impls ao latou o le a feteenai ma o tatou impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Faafoi nisi mutable faasinomaga i le boxed taua pe afai e o ituaiga `T`, po `None` pe afai e leai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SAFETI: na o le siakiina pe o matou tusiina le ituaiga saʻo, ma e mafai ona matou faʻamoemoe i ai
            // lena siaki mo le saogalemu manatuaina aua ua tatou faʻatinoina Soʻo se mo ituaiga uma;e le mafai ona i ai isi impls ao latou o le a feteenai ma o tatou impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Faʻaauau i le auala faʻamatalaina luga o le ituaiga `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Faʻaauau i le auala faʻamatalaina luga o le ituaiga `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Faʻaauau i le auala faʻamatalaina luga o le ituaiga `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Faʻaauau i le auala faʻamatalaina luga o le ituaiga `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Faʻaauau i le auala faʻamatalaina luga o le ituaiga `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Faʻaauau i le auala faʻamatalaina luga o le ituaiga `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ma ona metotia
///////////////////////////////////////////////////////////////////////////////

/// faatusa A `TypeId` a e faailoa tulaga ese aafia ai le lalolagi mo se ituaiga.
///
/// Taʻitasi `TypeId` o se opaque mea e le faʻatagaina le asiasia o mea i totonu ae faʻatagaina faʻavae faʻagaioiga pei o le faʻamalamalamaina, faʻatusatusaga, lolomiina, ma faʻaali.
///
///
/// O le `TypeId` o loʻo avanoa nei mo ituaiga o loʻo faʻapea o le `'static`, peitaʻi o lenei tapulaʻa e mafai ona aveʻesea i le future.
///
/// A o `TypeId` faʻaaoga `Hash`, `PartialOrd`, ma `Ord`, e taua le maitauina o le hashes ma le okaina o le a eseese i le va o Rust faʻamalolo.
/// Faʻaeteete i le faʻamoemoe ia latou i totonu o lau code!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Faʻafoʻi mai le `TypeId` o le ituaiga o lenei gaioiga lautele na amataina i le.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Faʻafoʻi mai le igoa o se ituaiga o se fasi manoa.
///
/// # Note
///
/// ua faamoemoe lenei mo le faaaogaina diagnostic.
/// O mea saʻo ma faʻatulagaina o le manoa na faʻafoʻi mai e leʻo faʻamaonia mai, e ese mai i le avea ma se taumafaiga sili ona lelei faʻamatalaina o le ituaiga.
/// Mo se faʻataʻitaʻiga, i totonu o manoa atonu e toe foʻi mai `type_name::<Option<String>>()` o `"Option<String>"` ma `"std::option::Option<std::string::String>"`.
///
///
/// O le manoa faʻafoʻi e le tatau ona manatu o se tulaga ese faʻailoaina o se ituaiga o le tele o ituaiga ono faʻafanua i le tutusa ituaiga igoa.
/// E faʻapena foi, e leai se mautinoa o vaega uma o se ituaiga o le a aliali mai i le manoa faʻafoʻi: mo se faʻataʻitaʻiga, olaga specifiers e le o aofia ai i le taimi nei.
/// I se faʻaopopoga, o le galuega faʻatino mafai ona suia i le va o lomiga o le compiler.
///
/// O le faʻatinoga o loʻo iai nei e faʻaaoga tutusa meafaigaluega pei ole faʻavasegaina o faʻamaumauga ma debuginfo, ae le mautinoa lea.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Faʻafoʻi mai le igoa o le ituaiga o le faʻailoga-i le taua o se fasi manoa.
/// E tutusa lava ma `type_name::<T>()`, ae mafai ona faʻaaoga i le mea e le faigofie ai ona maua le ituaiga o fesuiaʻiga.
///
/// # Note
///
/// O lenei mea e faʻamoemoeina mo le faʻaogaina o faʻamaoniga.O mea saʻo ma faʻatulagaina o le manoa e leʻo faʻamaoti maia, e ese mai i le avea ma se taumafaiga sili ona lelei faʻamatalaina o le ituaiga.
/// Mo se faʻataʻitaʻiga, `type_name_of_val::<Option<String>>(None)` mafai ona toe faafoʻi `"Option<String>"` poʻo `"std::option::Option<std::string::String>"`, ae le o `"foobar"`.
///
/// I se faʻaopopoga, o le galuega faʻatino mafai ona suia i le va o lomiga o le compiler.
///
/// O lenei gaioiga e le fofoina trait mea, o lona uiga o `type_name_of_val(&7u32 as &dyn Debug)` ono toe faafoi `"dyn Debug"`, ae le o `"u32"`.
///
/// O le ituaiga igoa e le tatau ona manatu o se tulaga ese faʻailoaina o se ituaiga;
/// le tele o ituaiga e mafai ona faasoa atu ai le igoa o le ituaiga e tasi.
///
/// O le faʻatinoga o loʻo iai nei e faʻaaoga tutusa meafaigaluega pei ole faʻavasegaina o faʻamaumauga ma debuginfo, ae le mautinoa lea.
///
/// # Examples
///
/// Lolomiina le le aofaʻi o fuainumera fuainumera ma opeopea ituaiga.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}