#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Faalautele e se tasi `$crate::panic::panic_2015` po `$crate::panic::panic_2021` faalagolago i le lomiga o le Tagata telefoni.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Faʻailoa e lua faʻauiga tutusa e tutusa uma (faʻaaoga [`PartialEq`]).
///
/// I panic, o lenei macro a le lolomiina o le tulaga faatauaina o le faaupuga ma o latou faamatalaga debug.
///
///
/// E pei [`assert!`], o lenei macro ei ai se ituaiga lona lua, lea e mafai ona tuuina atu savali panic a tu.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // O le reborrows lalo o taumafaiga.
                    // A aunoa ma latou, o le faaputuga slot mo le nonoina o loʻo faʻatonutonu e oo lava i luma o le faʻatusatusaga o tau, e tau atu ai i se maitauina lemu lemu.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // O le reborrows lalo o taumafaiga.
                    // A aunoa ma latou, o le faaputuga slot mo le nonoina o loʻo faʻatonutonu e oo lava i luma o le faʻatusatusaga o tau, e tau atu ai i se maitauina lemu lemu.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Ua faamautuina ai e le tutusa faaupuga e lua o le tasi i le isi (e faaaoga [`PartialEq`]).
///
/// I panic, o lenei macro a le lolomiina o le tulaga faatauaina o le faaupuga ma o latou faamatalaga debug.
///
///
/// E pei [`assert!`], o lenei macro ei ai se ituaiga lona lua, lea e mafai ona tuuina atu savali panic a tu.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // O le reborrows lalo o taumafaiga.
                    // A aunoa ma latou, o le faaputuga slot mo le nonoina o loʻo faʻatonutonu e oo lava i luma o le faʻatusatusaga o tau, e tau atu ai i se maitauina lemu lemu.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // O le reborrows lalo o taumafaiga.
                    // A aunoa ma latou, o le faaputuga slot mo le nonoina o loʻo faʻatonutonu e oo lava i luma o le faʻatusatusaga o tau, e tau atu ai i se maitauina lemu lemu.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Ua tautino mai ai se faaupuga boolean o `true` i runtime.
///
/// Lenei o le a talosagaina le [`panic!`] macro pe a fai o le faʻamatalaga saunia e le mafai ona iloiloina i le `true` i le taimi o le aoga.
///
/// Pei ole [`assert!`], o lenei macro o loʻo iai foʻi lonaisi faʻamatalaga lona lua, lea e mafai ai ona tuʻuina atu ai se feʻau masani a le panic.
///
/// # Uses
///
/// E le pei o [`assert!`], ua na o na mafai ai faamatalaga `debug_assert!` i lē optimized fausia e faaletonu.
/// o le a le faaoo se fausia optimized faamatalaga `debug_assert!` seia vagana ua mavae `-C debug-assertions` i le tuufaatasia.
/// O lenei tulaga e aoga `debug_assert!` mo siaki e taugata tele ina ia auai i le a fausia le tatalaina i tua ae mafai ona fesoasoani tele i le taimi o atinae.
/// O le iʻuga o le faʻalauteleina o le `debug_assert!` e masani ona siaki siaki.
///
/// Se lē siakiina folafolaga e mafai ai se polokalama i se tulaga le ogatasi e tausia tamoe, e ono i ai ni taunuuga e leʻi mafaufauina ae e le faailoa atu unsafety i le umi e na o le pau le mea e tupu i code saogalemu.
///
/// O le faʻatinoga o tau o faʻamatalaga, e ui i lea, e le mafai ona fuatia i se tulaga lautele.
/// Suiga [`assert!`] ma `debug_assert!` ua naʻo le faʻamalosia pe a maeʻa maeʻa faʻamaumauga, ma sili atu ona taua, naʻo le saogalemu code!
///
/// # Examples
///
/// ```
/// // le savali panic mo nei faamatalaga o le tau stringified o le faaupuga tuuina mai.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // o se faigofie tele galuega
/// debug_assert!(some_expensive_computation());
///
/// // folafola ma se savali tu
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Ua tautino mai ai e tutusa faaupuga e lua o le tasi i le isi.
///
/// I panic, o lenei macro a le lolomiina o le tulaga faatauaina o le faaupuga ma o latou faamatalaga debug.
///
/// E le pei o [`assert_eq!`], ua na o na mafai ai faamatalaga `debug_assert_eq!` i lē optimized fausia e faaletonu.
/// O le fausiaina optimized o le a le faʻataunuʻuina `debug_assert_eq!` faʻamatalaga seʻi vagana `-C debug-assertions` ua pasi atu i le tuʻufaʻatasia.
/// O lenei tulaga e aoga `debug_assert_eq!` mo siaki e taugata tele ina ia auai i le a fausia le tatalaina i tua ae mafai ona fesoasoani tele i le taimi o atinae.
///
/// ua ituaiga siaki pea le taunuuga o le faalauteleina `debug_assert_eq!`.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Ua faamautuina ai e le tutusa faaupuga e lua o le tasi i le isi.
///
/// I panic, o lenei macro a le lolomiina o le tulaga faatauaina o le faaupuga ma o latou faamatalaga debug.
///
/// E le pei o [`assert_ne!`], ua na o na mafai ai faamatalaga `debug_assert_ne!` i lē optimized fausia e faaletonu.
/// o le a le faaoo se fausia optimized faamatalaga `debug_assert_ne!` seia vagana ua mavae `-C debug-assertions` i le tuufaatasia.
/// O lenei tulaga e aoga `debug_assert_ne!` mo siaki e taugata tele ina ia auai i le a fausia le tatalaina i tua ae mafai ona fesoasoani tele i le taimi o atinae.
///
/// ua ituaiga siaki pea le taunuuga o le faalauteleina `debug_assert_ne!`.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Faamatalaga o tupe maua pe o le tuuina faaupuga fetaui lelei o so o se mamanu na tuuina mai.
///
/// E pei o i se faaupuga `match`, o le mamanu e mafai ona optionally mulimuli e `if` ma se faaupuga leoleo o loo i ai le avanoa i igoa e noatia i le mamanu.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Unwraps se taunuuga po o propagates ana mea sese.
///
/// na faaopoopo ai le faagaoioia `?` e sui `try!` ma e tatau ona faaaogaina nai lo.
/// Gata i lea, `try` o se upu teuina i Rust 2018, o lea afai e tatau ona e faaaogaina, o le a manaomia ona e faaaogaina le [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` fetaui ma le [`Result`] tuuina mai.I le tulaga o le variant `Ok`, o le faaupuga ua i ai le taua o le taua afifi.
///
/// I le tulaga o le variant `Err`, e retrieves le mea sese i totonu.`try!` ona faʻatinoina lea o le liuaina faʻaaoga `From`.
/// O lenei e maua ai le liua otometi le va faapitoa sese ma sili atu tagata aoao.
/// o lea toe foi vave atu i le sese e mafua.
///
/// Talu ai ona o le toe foi mai le amataga, e mafai ona na ona faaaogaina `try!` i galuega tauave o le toe foi [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // O le auala e fiafia o Sese toe foi vave
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // O le auala muamua o Sese toe foi vave
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // e tutusa lenei:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Tusia faamatalaga formatted i se buffer.
///
/// O lenei macro talia a 'writer', o se faatulagaga manoa, ma se lisi o finauga.
/// a formatted e tusa ma le faamaoti le faatulagaga o le a mavae manoa ma o le taunuuga finauga i le tusitala.
/// O le tusitala e ono aoga ma le `write_fmt` metotia;masani ona oo mai lenei mea mai se faatinoga a le o le [`fmt::Write`] po o le [`io::Write`] trait.
/// E toe faʻafoʻi mai e le macro soʻo se mea e toe faʻafoʻi mai e le `write_fmt` auala;masani a [`fmt::Result`], po o se [`io::Result`].
///
/// Vaʻai [`std::fmt`] mo nisi faʻamatalaga i luga o le faʻavasega laina laina.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// A module mafai ona faaulufale uma `std::fmt::Write` ma `std::io::Write` ma valaau `write!` i luga o mea le faatinoina o se tasi, e pei ona e le masani mea faatino uma e lua.
///
/// Ae peitai, agavaa e tatau ona faaulufale module le traits ina faia le latou igoa feteenaiga:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // faaaoga fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // faʻaaoga le io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: O lenei macro mafai ona faaaoga i setups `no_std` foi.
/// I le `no_std` seti o oe e nafa ma le faʻatinoina auiliiliga o vaega.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Tusi formatted faamatalaga i se buffer, ma se newline faapipiiina.
///
/// I fausaga opea uma, o le newline o le LEA MATAUPU Fafaga uiga na (`\n`/`U+000A`) (nu TOE FOI taavale faaopoopo (`\r`/`U+000D`).
///
/// Mo nisi faamatalaga, tagai i [`write!`].Mo faʻamatalaga i luga ole faʻavasega laina laina, tagaʻi ile [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// A module mafai ona faaulufale uma `std::fmt::Write` ma `std::io::Write` ma valaau `write!` i luga o mea le faatinoina o se tasi, e pei ona e le masani mea faatino uma e lua.
/// Ae peitai, agavaa e tatau ona faaulufale module le traits ina faia le latou igoa feteenaiga:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // faaaoga fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // faʻaaoga le io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Faailoa code unreachable.
///
/// E aoga lenei i soʻo se taimi e le mafai ai e le tuʻufaʻatasiga ona fuafuaina o nisi tulafono e le oʻo atu.Faataitaiga:
///
/// * Faafetaui lima ma tuutuuga leoleo.
/// * Loops e faamuta dynamically.
/// * Iterators e faamuta dynamically.
///
/// Afai o le faʻaiuga o le numera e le oʻo atu faʻamaonia le saʻo, o le polokalama vave faʻamutaina ma le [`panic!`].
///
/// O le faaluaina le saogalemu o lenei macro o le galuega tauave [`unreachable_unchecked`], lea o le a mafua ai amioga undefined pe afai e oo atu i le code.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// O lenei finagalo [`panic!`] taimi uma.
///
/// # Examples
///
/// Faʻafetaui lima:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // tuufaatasia mea sese pe afai e saunoa mai
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // o se tasi o le implementations matitiva o x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Faailoa code unimplemented e panicking i se savali o "not implemented".
///
/// O lenei e mafai ai e lou code i ituaiga-siaki, lea e aoga pe afai o loo e prototyping po o le faatinoina o se trait e manaomia ai le tele o auala lea e te le fuafuaga o le faaaogaina uma.
///
/// O le eseʻesega i le va o le `unimplemented!` ma le [`todo!`] o le `todo!` o loʻo faʻaalia ai le faʻamoemoe e faʻatinoina galuega i se taimi o i luma ma o le feau o le "not yet implemented", e leai lava ni tagi a le `unimplemented!`.
/// Lana savali o "not implemented".
/// Faʻapea foi ma nisi IDEs o le a makaina le 'todo!' S.
///
/// # Panics
///
/// O lenei finagalo [`panic!`] pea ona `unimplemented!` ua na o se shorthand mo `panic!` ma a tumau, e savali patino.
///
/// E pei `panic!`, o lenei macro ei ai se ituaiga lona lua mo le faaalia o tulaga faatauaina masani ai.
///
/// # Examples
///
/// Fai mai o loʻo ia matou le trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Matou te mananaʻo e faʻaoga `Foo` mo 'MyStruct', ae mo ni mafuaʻaga e talafeagai ai le faʻatinoina o le `bar()` galuega.
/// `baz()` ma o le a manaomia pea `qux()` ona faamatalaina i totonu o lo tatou faatinoina o `Foo`, ae e mafai ona tatou faaaogaina `unimplemented!` i latou faamatalaga e faatagaina o tatou code e tuufaatasia.
///
/// Matou te mananao pea lava i ai o tatou polokalama taofia tamoʻe pe afai e oo atu i le auala unimplemented.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // E leai se lagona e `baz` a `MyStruct`, o lea e leai se mafuaaga iinei i uma.
/////
///         // le a faaalia lenei "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // E i ai nisi mafuaaga iinei, E mafai ona tatou faaopoopo i ai se savali e unimplemented!e faaalia ai lo tatou faia.
///         // Lenei o le a faʻaalia: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Faailoa code o maea.
///
/// e mafai ona aoga lenei mea pe afai o loo e prototyping ma ua na ona vaavaai i ai o sau code typecheck.
///
/// O le eseʻesega i le va o le [`unimplemented!`] ma le `todo!` o le `todo!` o loʻo faʻaalia ai le faʻamoemoe e faʻatinoina galuega i se taimi o i luma ma o le feau o le "not yet implemented", e leai lava ni tagi a le `unimplemented!`.
/// Lana savali o "not implemented".
/// Faʻapea foi ma nisi IDEs o le a makaina le 'todo!' S.
///
/// # Panics
///
/// O lenei finagalo [`panic!`] taimi uma.
///
/// # Examples
///
/// O iinei se faataitaiga o nisi i totonu o le alualu i luma code.I tatou se trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Tatou te mananao e faatino `Foo` i se tasi o lo tatou ituaiga, ae e te manao foi i le galuega i le na muamua `bar()`.Ina mo lo tatou code e tuufaatasia, e tatau ona tatou faatino `baz()`, ina ia mafai ona tatou faaaogaina `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // faatinoga alu iinei
///     }
///
///     fn baz(&self) {
///         // aua neʻi o tatou popole e faʻatino le baz() mo le taimi nei
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // matou te le o faʻaaogaina foi baz(), o lea la e lelei lenei.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Faamatalaga o fausia-i macros.
///
/// Tele o meatotino a le au maketi (mautu, vaʻaia, ma isi) o loʻo aumai mai le tulafono autu iinei, sei vagana ai le faʻalauteleina o galuega faʻagaioiga e suia ai mea faʻauluola i mea e maua mai ai, o galuega na e saunia e le tagata tuʻufaʻatasia.
///
///
pub(crate) mod builtin {

    /// Mafuaaga tuufaatasiga ina ia toilalo i le savali sese tuuina mai pe a fetaiai.
    ///
    /// O lenei macro e tatau ona faaaogaina pe a faaaoga a crate a fuafuaga tuufaatasiga tuutuuga e tuuina atu e sili atu savali sese mo tulaga sese.
    ///
    /// O le ituaiga tulaga-tuufaatasia [`panic!`], ae faamatuu mai o se mea sese i le taimi o *tuufaatasiga* nai lo *runtime*.
    ///
    /// # Examples
    ///
    /// E lua e pei o faataitaiga o macros ma siosiomaga `#[cfg]`.
    ///
    /// Emit sili tuufaatasia mea sese pe afai e pasia se macro faatauaina mamaʻi.
    /// E aunoa ma le branch mulimuli, o le a emit pea le tuufaatasia o se mea sese, ae o le a le taʻua le savali a sese i tulaga faatauaina aloaia lua.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// mea sese na tuufaatasia Emit pe afai o se tasi o le tele o vaega e le o maua.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Fausia tapulaʻa mo isi macros-formatting macros.
    ///
    /// O lenei macro galuega tauave i le faia o se manoa formatting moni o loo i ai `{}` mo finauga faaopoopo taitasi mavae.
    /// `format_args!` saunia le faʻaopoopo faʻapitoa e mautinoa ai o le gaioiga mafai ona faʻamatalaina o se manoa ma canonicalizes le finauga i se tasi ituaiga.
    /// Soʻo se tau aoga o loʻo faʻaaogaina le [`Display`] trait e mafai ona pasi atu i le `format_args!`, e pei foi ona mafai ona pasi se faʻatinoga [`Debug`] i le `{:?}` i totonu o le faʻavasega manoa.
    ///
    ///
    /// O lenei macro maua a taua o ituaiga [`fmt::Arguments`].e mafai ona pasia lenei taua i le macros totonu [`std::fmt`] mo le faatinoina o redirection aoga.
    /// O isi uma macros formatting (['faatulagaga!'], [`write!`], [`println!`], etc) ua proxied ala lenei e tasi.
    /// `format_args!`, pei ona macros maua, aloese faupuega le faasoasoaina.
    ///
    /// E mafai ona e faaaogaina e taua [`fmt::Arguments`] toe foi `format_args!` i totonu lava `Debug` ma `Display` e pei ona vaaia i lalo.
    /// O le faaalia foi faataitaiga faatulagaga `Debug` ma `Display` i le mea lava e tasi: o le manoa faatulagaga interpolated i `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Mo nisi faamatalaga, tagai i le pepa i [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// E tutusa ma `format_args`, ae faʻaopopo se laina fou i le iʻuga.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspects se ma liuliuina siosiomaga i le taimi e tuufaatasia.
    ///
    /// O lenei macro le a faalautele atu i le taua o le ma liuliuina siosiomaga e igoa i le taimi e tuufaatasia, tuuina atu o se faailoga o le ituaiga `&'static str`.
    ///
    ///
    /// Afai e le o faamatalaina le ma liuliuina siosiomaga, lea o le a emitted sese se tuufaatasiga.
    /// Ina ia le emit se mea sese e tuufaatasia, faaaoga nai lo le macro [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Oe mafai faʻapitoa le mea sese savali i le pasiina o se manoa o le lona lua parameter:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Afai e le o faamatalaina le ma liuliuina siosiomaga `documentation`, o le ae maua ai le mea sese nei:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Filifili faʻapitoa asiasia se siʻosiʻomaga fesuiaʻiga i le tuufaatasia taimi.
    ///
    /// A faʻapea o loʻo i ai le fesuiaʻiga siʻosiʻomaga igoa i le tuʻufaʻatasi taimi, lenei o le a faʻalauteleina i se faʻaaliga o le ituaiga `Option<&'static str>` o lona taua o `Some` o le tau o le siʻosiʻomaga fesuiaʻi.
    /// Afai e le o auai le ma liuliuina siosiomaga, ona o lenei le a faalauteleina e `None`.
    /// Tagai [`Option<T>`][Option] mo nisi faamatalaga i lenei ituaiga.
    ///
    /// A tuufaatasia taimi mea sese ua lava emitted pe a faaaogaina lenei macro tusa lava pe o le ma liuliuina siosiomaga o le taimi nei pe leai.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates faailoa i se tasi e faailoa.
    ///
    /// O lenei macro e so o se aofaiga o koma-tuueseeseina faailoa, ma concatenates i latou i se tasi uma, tuuina atu o se faailoga o se mea e faailoa fou.
    /// Manatua o le tumama e faia ai e pei e le mafai ona pueina lenei macro fesuiaiga i le lotoifale.
    /// Foi, o se tulafono aoao, ua na faatagaina macros i meataitasi, faamatalaga po o se tulaga faaalia.
    /// O lena auala ao e mafai ona e faaaogaina lenei macro mo faasino atu oi ai nei fesuiaiga, galuega tauave po o modules isi, e le mafai ona faamatalaina o se fou i ai.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_ident! (fou, malie, igoa) { }//le faʻaaogaina i lenei auala!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates literals i se fasi manoa static.
    ///
    /// O lenei macro e so o se aofaiga o koma-tuueseeseina literals, tuuina atu o se faailoga o le ituaiga `&'static str` lea faatusa concatenated tuua-e taumatau le literals uma.
    ///
    ///
    /// ua stringified literals integer ma faasino opeopea i le poloaiga ina ia concatenated.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Faʻalauteleina i le numera laina na ia faʻaaogaina.
    ///
    /// Faatasi ai ma le [`column!`] ma [`file!`], o nei macros tuuina debugging faamatalaga mo developers e uiga i le nofoaga i totonu o le auala.
    ///
    /// O le faalauteleina faaupuga ua ituaiga `u32` ma e 1-faavae, e faapea o le laina muamua i iloilo faila taitasi e 1, o le lona lua i le 2, ma isi
    /// E o gatasi ma feau sese e masani ona tuʻufaʻatasia poʻo tagata lauiloa faʻatonutonu.
    /// Ole laina toe faafoi mai *e leʻo tatau* le laina ole `line!` tatalo lava ia, ae o le muamua talosaga muamua e oʻo atu i le valaʻaulia o le `line!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Faalautele i le koluma numera i lea na faamaoniaina.
    ///
    /// Faʻatasi ai ma [`line!`] ma [`file!`], o nei macros o loʻo tuʻuina atu faʻamatalaga o faʻamatalaga mo tagata atiaʻe e uiga i le nofoaga i totonu o le faʻavae.
    ///
    /// O le faalauteleina faaupuga ua ituaiga `u32` ma e 1-faavae, e faapena le koluma muamua i iloilo laina taitasi e 1, o le lona lua i le 2, ma isi
    /// E o gatasi ma feau sese e masani ona tuʻufaʻatasia poʻo tagata lauiloa faʻatonutonu.
    /// O le toe foi koluma o *le o* le laina o le talosaga `column!` lava ia, ae o le tatalo amata macro muamua e oo atu i le tatalo amata o le macro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Faalautele i le faila igoa i lea na faamaoniaina.
    ///
    /// Faatasi ai ma le [`line!`] ma [`column!`], o nei macros tuuina debugging faamatalaga mo developers e uiga i le nofoaga i totonu o le auala.
    ///
    /// O le ua i ai ituaiga faaupuga faalauteleina `&'static str`, ma le toe foi faila e le o le talosaga o le macro `file!` lava ia, ae o le tatalo amata macro muamua e oo atu i le tatalo amata o le macro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifies ana finauga.
    ///
    /// O lenei macro le a aumaia se faailoaga o le ituaiga `&'static str` ua mavae le stringification uma le tokens i le macro.
    /// E leai se tapulaa o loo tuuina i le syntax o le talosaga macro lava ia.
    ///
    /// Manatua o le faalauteleina o taunuuga o le mafai ona suia sao tokens i le future.E tatau ona e faaeteete pe afai e te faalagolago i le galuega faatino.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// E aofia ai se faila encoded UTF-8 o se manoa.
    ///
    /// O le faila o loo tu e faatatau i le faila i le taimi nei (faapena foi i le auala o loo maua modules).
    /// O le auala saunia ua faʻamatalaina i se tulaga faʻavae-faʻapitoa auala i le tuʻufaʻatasia taimi.
    /// O lea, mo se faataitaiga, o se tatalo amata ma se Windows ala o loo backslashes le a le tuufaatasia `\` saʻo i Unix.
    ///
    ///
    /// Lenei macro o le a maua mai se faʻaaliga o le ituaiga `&'static str` o mea o loʻo i totonu o le faila.
    ///
    /// # Examples
    ///
    /// Manatu o loo i faila e lua i le tomatauga lava lea e tasi i le mataupu nei:
    ///
    /// Faatoai 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Faatoai 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Tuufaatasia 'main.rs' ma tamoe o le taunuuga o binary a lolomi "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// E aofia ai se faila e avea o se faasinomaga i se autau byte.
    ///
    /// O le faila o loo tu e faatatau i le faila i le taimi nei (faapena foi i le auala o loo maua modules).
    /// O le auala saunia ua faʻamatalaina i se tulaga faʻavae-faʻapitoa auala i le tuʻufaʻatasia taimi.
    /// O lea, mo se faataitaiga, o se tatalo amata ma se Windows ala o loo backslashes le a le tuufaatasia `\` saʻo i Unix.
    ///
    ///
    /// O lenei macro le a aumaia se faailoaga o le ituaiga `&'static [u8; N]` o le anotusi o le faila.
    ///
    /// # Examples
    ///
    /// Manatu o loo i faila e lua i le tomatauga lava lea e tasi i le mataupu nei:
    ///
    /// Faatoai 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Faatoai 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Tuufaatasia 'main.rs' ma tamoe o le taunuuga o binary a lolomi "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Faalautele i se manoa e faatusa i ai le ala module nei.
    ///
    /// O le taimi nei auala auala mafai ona manatu i ai o le faʻatulagaga o modules e toe foʻi atu i luga i le crate root.
    /// O le vaega muamua o le auala toe foʻi mai o le igoa o le crate o loʻo tuʻufaʻatasia.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Iloilo boolean tuʻufaʻatasia o faʻavaʻa fuʻa i le tuʻufaʻatasi-taimi.
    ///
    /// I le faaopoopo atu i le uiga `#[cfg]`, o loo maua lenei macro e faatagaina iloiloga faaupuga boolean o fuʻa configuration.
    /// Lenei masani lava ona taitai atu i le laʻititi faʻalua kopi.
    ///
    /// O le faʻamatalaga tuʻufaʻatasia na tuʻuina atu i lenei macro o le tutusa syntax ma le [`cfg`] uiga.
    ///
    /// `cfg!`, pei `#[cfg]`, e le aveesea o so o se tulafono ma e na iloilo e moni pe sese.
    /// Mo se faataitaiga, poloka uma i se manaoga faaupuga if/else ina ia aoga pe a faaaoga `cfg!` mo le tulaga, e tusa lava po o le mea o loo iloiloina `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Faʻamamaina se faila o se faʻaaliga poʻo se aitema e tusa ai ma le tulaga.
    ///
    /// O le faila o loo tu e faatatau i le faila i le taimi nei (faapena foi i le auala o loo maua modules).ua faamatalaina o le ala e tuuina atu i se auala tulaga maoti i le taimi e tuufaatasia.
    /// O lea, mo se faataitaiga, o se tatalo amata ma se Windows ala o loo backslashes le a le tuufaatasia `\` saʻo i Unix.
    ///
    /// O le faaaogaina o lenei macro e masani lava o se manatu leaga, aua afai ua iloiloina le faila e pei o se faaaliga, o ai o le a tuuina i le tulafono o loo siomia unhygienically.
    /// O lenei mea e ono mafua ai fesuiaʻiga poʻo gaioiga e ese mai le mea e faʻamoemoeina e le faila pe a fai e i ai ni fesuiaʻiga poʻo ni galuega e tutusa igoa i le faila o loʻo i ai.
    ///
    ///
    /// # Examples
    ///
    /// Manatu o loo i faila e lua i le tomatauga lava lea e tasi i le mataupu nei:
    ///
    /// Faatoai 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Faatoai 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Tuufaatasia 'main.rs' ma tamoe o le taunuuga o binary a lolomi "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ua tautino mai ai se faaupuga boolean o `true` i runtime.
    ///
    /// Lenei o le a talosagaina le [`panic!`] macro pe a fai o le faʻamatalaga saunia e le mafai ona iloiloina i le `true` i le taimi o le aoga.
    ///
    /// # Uses
    ///
    /// O faʻamatalaga e masani ona siaki uma i le debug ma faʻamatuʻu fauga, ma e le mafai ona faʻaleaogaina.
    /// Tagai [`debug_assert!`] mo assertions e le mafai ai i le tatalaina i tua e fausia e ala i le faaletonu.
    ///
    /// e mafai ona faalagolago code saogalemu i `assert!` e faamalosia invariants taufetuli-taimi e faapea, afai solia mafai ona taitai atu ai i unsafety.
    ///
    /// Isi faaaogaina-o tulaga o `assert!` e aofia ai suesuega ma le faamalosia o invariants taufetuli-taimi i code saogalemu (o lona solia e le mafai ona taunuu ai i unsafety).
    ///
    ///
    /// # Feau faʻapitoa
    ///
    /// O lenei macro ei ai se ituaiga lona lua, lea e mafai ona tuuina atu savali panic a tu ma po e aunoa ma finauga mo formatting.
    /// Vaʻai [`std::fmt`] mo faʻamatalaga mo lenei pepa.
    /// o le a na ona iloiloina o faaupuga ua faaaogāina e pei finauga faatulagaga pe afai e lē mafai e le folafolaga.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // le savali panic mo nei faamatalaga o le tau stringified o le faaupuga tuuina mai.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // o se faigofie tele galuega
    ///
    /// assert!(some_computation());
    ///
    /// // folafola ma se savali tu
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline faapotopotoga.
    ///
    /// Faitau le [unstable book] mo le faʻaaogaina.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-faiga inline faʻapotopotoga.
    ///
    /// Faitau le [unstable book] mo le faʻaaogaina.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Module-tulaga inline faapotopotoga.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Lolomi pasi tokens i le tulaga faʻatulagaina galuega.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// E mafai ai ona po disables functionality tulimatai faaaoga mo debugging isi macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// faaaogaina macro uiga e faaaoga macros maua.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// faaaogaina macro uiga i se galuega tauave e liliu ai i se tofotofoga iunite.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// faaaogaina macro uiga i se galuega tauave e liliu ai i se tofotofoga tagavai.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// O se faʻatinoga auiliili o le `#[test]` ma `#[bench]` macros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// faaaogaina macro uiga i se static ina ia faamauina e avea o se allocator lalolagi.
    ///
    /// Tagai foi [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Tausia e le mea o loo faaaogaina i pe afai e faaaoga le ala mavae atu, ma aveesea isi faiga e ese ai.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Faalautele ai uiga uma `#[cfg]` ma `#[cfg_attr]` i le code momoimea o loo faatatau i ai.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// auiliili faatinoga mautu o le tuufaatasia `rustc`, aua le faaaogaina.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// auiliili faatinoga mautu o le tuufaatasia `rustc`, aua le faaaogaina.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}