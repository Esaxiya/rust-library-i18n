Panics le filo i le taimi nei.

faatagaina se polokalama lenei e faamuta vave ma tuuina atu manatu faaalia i le telefoni o le polokalama.
`panic!` e tatau ona faaaoga pe a oo atu se polokalama o se tulaga unrecoverable.

O lenei macro o le auala sili ona lelei e faʻamautu ai tulaga i faʻataʻitaʻiga code ma i suʻega.
`panic!` ua vavalalata ai ma le auala `unwrap` uma [`Option`][ounwrap] ma [`Result`][runwrap] enums.
valaau implementations uma `panic!` pe a latou ua faatulaga e variants [`None`] po [`Err`].

A faaaoga `panic!()` e mafai ona faamaoti se payload manoa, ua fausia i le faaaogaina o syntax [`format!`].
O lena payload e faaaoga pe a tuiina le panic i le valaau filo Rust, na mafua ai atoa le filo e panic.

O le amioga a le faaletonu `std` hook, o lona uiga
le code e tamoʻe saʻo ina ua uma ona faamaoniaina le panic, o le lolomiina o le savali payload e `stderr` faatasi ai ma faamatalaga file/line/column le o le valaau `panic!()`.

E mafai ona e faaleaogaina le panic hook faaaogaina [`std::panic::set_hook()`].
Totonu o le hook a panic mafai ona mauaina o se `&dyn Any + Send`, lea e aofia ai a `&str` poʻo `String` mo masani `panic!()` invocation.
Ina ia panic faatasi ma se aofaiga o se isi isi ituaiga, e mafai ona faaaoga [`panic_any`].

[`Result`] masani lava enum se tali sili ona lelei mo malosi mai mea sese nai lo le faaaogaina o le macro `panic!`.
O lenei macro e tatau ona faaaogaina e aloese ai mai taualumaga e faaaoga ai tulaga faatauaina o le saʻo, e pei o mai punaoa mai fafo.
O auiliiliga faʻamatalaga e uiga i le faʻamamaina o mea sese o loʻo maua i le [book].

Tagai foi i le macro [`compile_error!`], mo le tausiga o mea sese i le taimi o le tuufaatasiga.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Faʻatinoina nei

Afai o le filo autu panics o le a faamuta lou filo ma faaiu lau polokalama ma code `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





