//! Faʻatonuga faʻasolosolo e le mafaʻatasi.
//!
//! Afai o le futures o ni aoga taua, o lona uiga o vaitafe e faʻasolosolo ona faʻasolosolo.
//! Afai na e mauaina oe lava ma se asynchronous aoina o se ituaiga, ma manaʻomia e faia se taotoga i luga o elemene o le taua faʻaputuina, o le a vave ona e taufetuli i le 'streams'.
//! ua mamafa faaaogaina vaitafe i idiomatic asynchronous code Rust, o lea o le taua o le avea ma masani ma i latou.
//!
//! Ae le i faʻamatalaina atili, tatou talanoa pe faʻafefea ona fausia lenei module:
//!
//! # Organization
//!
//! O lenei module ua faatulagaina tele i ituaiga:
//!
//! * [Traits] o le vaega autu: faamatalaina nei traits le mea oi ai ituaiga o vaitafe ma mea e mafai ona faia ma i latou.O metotia o nei traits e aoga le tuʻuina i ai o ni taimi faʻaopopo faʻasili i totonu.
//! * O galuega e maua ai ni auala aoga e fausia ai ni vaitafe masani.
//! * Structs e masani lava ona le toe foi mai ituaiga o metotia eseese i luga o le traits lenei module.Ae e masani lava e te manao e vaai i le auala e faatupuina ai le `struct`, nai lo le `struct` lava ia.
//! Mo nisi faʻamatalaga e uiga i le mafuaʻaga, vaʻai i le '[Implementing Stream](#implementing-stream)'.
//!
//! [Traits]: #traits
//!
//! O lena lava!oso o ia i le vaitafe.
//!
//! # Stream
//!
//! O le fatu ma le agaga o lenei vaega o le [`Stream`] trait.O le autu o [`Stream`] foliga faʻapea:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! E le pei o `Iterator`, `Stream` faia se eseʻesega i le va o le [`poll_next`] auala lea e faʻaaogaina pe a faʻatinoina se `Stream`, ma le (to-be-implemented) `next` auala e faʻaaogaina pe a faʻaumatia se vaitafe.
//!
//! Tagata faʻatau o `Stream` naʻo latou e manaʻomia le mafaufau i le `next`, lea a valaʻauina, toe faʻafoʻi mai le future e maua ai le `Option<Stream::Item>`.
//!
//! O le future na toe faafoi mai e `next` o le a maua `Some(Item)` pe a iai ni elemeni, ma a maeʻa uma i latou, o le a maua le `None` e faʻailoa ai ua maeʻa le faʻataʻitaʻiga.
//! Afai o loʻo tatou faʻatali i se mea le tutusa e faʻaleleia, ole a faʻatali le future seʻi sauni le vaitafe e toe faʻatupu.
//!
//! E mafai e tagata taʻi tasi ona filifili e toe amata le faʻamatalaga, ma toe valaʻau ai i le `next` atonu pe iʻu ina toe maua mai le `Some(Item)` i se taimi.
//!
//! O le faʻamatalaga atoa a le "Stream`] e aofia ai ma le tele o isi metotia, peitaʻi o ni auala le aoga, fausia i luga ole [`poll_next`], ma e maua fua ai fua.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # le faatinoina o Tafe
//!
//! Fausia se oe lava vaitafe aofia ai ni laʻasaga se lua: fausiaina o le `struct` e taofia ai le vaitafe o le setete, ona faʻaogaina ai lea o le [`Stream`] mo lena `struct`.
//!
//! Sei o tatou faia se vaitafe e igoa `Counter` lea taulia mai `1` e `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Muamua, o le fausia:
//!
//! /// O se vaitafe e faitau mai le tasi i le lima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // matou te mananaʻo ia amata le matou faitauga ile tasi, ia o lea faʻaopopo le new() auala e fesoasoani ai.
//! // e le matua e tatau ai lenei mea, ae e faigofie.
//! // Manatua tatou amata `count` i le leai, o le a tatou vaʻai pe aisea i le `poll_next()`'s faʻatinoina i lalo.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ma, matou te faʻaaogaina `Stream` mo la matou `Counter`:
//!
//! impl Stream for Counter {
//!     // o le a tatou faitauina ma usize
//!     type Item = usize;
//!
//!     // poll_next() na o le pau lea o le metotia manaʻomia
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Faʻateleina la matou faitauga.O le mafuaaga lenei tatou amata i o.
//!         self.count += 1;
//!
//!         // Siaki e vaai pe tatou ua maeʻa le faitauina pe leai.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Vaitafe o *paie*.O lona uiga o le na o le fausiaina o se vaitafe e le _do_ tele atoa.E leai se mea na tupu moni lava seia oo ina e valaau `next`.
//! o nisi taimi o se puna lea o le le mautonu pe a le faia o se vaitafe faapitoa mo ona aafiaga itu.
//! O le tuʻufaʻatasia o le a lapatai mai ia i tatou e uiga i lenei ituaiga o amioga:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;