use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// O se fesoʻotaʻiga mo le faʻafesoʻotaʻiina o aserotasi.
///
/// Lenei le vaitafe autu trait.
/// Mo nisi e uiga i le mataupu o le vaitafe masani, faamolemole tagai i le [module-level documentation].
/// A faʻapitoa lava, atonu e te manaʻo e iloa pe faʻafefea X00.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Le ituaiga o aitema maua e le vaitafe.
    type Item;

    /// Taumafai e toso ese le isi taua o lenei vaitafe, lesitalaina o le taimi nei galuega mo fafagu pe afai o le aoga e leʻi maua, ma toe faʻafoʻi `None` pe a fai o le vaitafe ua uma.
    ///
    /// # Toe faafoi taua
    ///
    /// E tele ni tulaga faatauaina toe foi e mafai ai, e faailoa taitasi se tulaga vaitafe eseese:
    ///
    /// - `Poll::Pending` o lona uiga o lenei vaitafe le isi taua e leʻi sauni.Implementations le a mautinoa o le a logoina le galuega i le taimi nei ina ua mafai ona ia saunia le isi taua.
    ///
    /// - `Poll::Ready(Some(val))` o lona uiga ua faʻamanuiaina lelei e le vaitafe se tau, `val`, ma ono mafai ona maua ai isi faʻatauaina i isi `poll_next` telefoni.
    ///
    /// - `Poll::Ready(None)` o lona uiga ua faamutaina le vaitafe, ma e le tatau ona toe faaaogaina ia `poll_next`.
    ///
    /// # Panics
    ///
    /// O le taimi lava e maeʻa ai se vaitafe (faʻafoʻi `Ready(None)` from `poll_next`), valaʻau lona `poll_next` metotia toe mafai panic, poloka faʻavavau, pe mafua ai isi ituaiga o faʻafitauli; le `Stream` trait leai ni manaʻoga i luga o aʻafiaga o sea valaauga.
    ///
    /// Ae ui i lea, talu ai o le `poll_next` metotia e le o faʻailogaina `unsafe`, o tulafono masani a le Rust e faʻaaogaina: e le tatau ona mafua ai ni amioga le faʻamatalaina (manatuaina o mea piʻopiʻo, le faʻaaogaina sese o `unsafe` gaioiga, poʻo ni mea faʻapena), tusa lava poʻo le a le tulaga o le vaitafe.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Toe foi le tuaoi i le umi o totoe o le alia.
    ///
    /// Faʻapitoa lava, `size_hint()` faʻafoʻi mai se tuple o le mea muamua elemeni o le pito i lalo o le laina, ma le lona lua elemeni o le pito i luga fusia.
    ///
    /// O le afa lona lua o le tuple ua toe foi o se ['Option`]' <'[' usize`] '>'.
    /// O le [`None`] iinei o lona uiga a leai e leai se iloa i luga pito i luga, pe o le pito i luga o le lapoʻa e lapoʻa nai lo [`usize`].
    ///
    /// # faatinoga faamatalaga
    ///
    /// E le faamalosia o se vaitafe faʻatinoga maua ai le folafolaina numera o elemene.O se taavale solofanua vaitafe e mafai ona gauai itiiti ifo i le pito i lalo noatia po o le sili atu nai lo le pito i luga noatia o elemene.
    ///
    /// `size_hint()` e faʻamoemoe lava e faʻaaoga mo faʻamautuina pei o le faʻasao o avanoa mo elemeni o le vaitafe, ae le tatau ona faʻatuatuaina e faʻataʻitaʻiga, aveʻesea tuaoi siaki i le le saogalemu code.
    /// O se faatinoga le saʻo o `size_hint()` le tatau ona taitai atu ai i le solia manatua le saogalemu.
    ///
    /// Na faapea mai, o le faatinoina e tatau ona tuuina atu se faatatau saʻo, ona e ese o le a avea o se solia o le Maliega Faafeagaiga a le trait.
    ///
    /// Toe foi mai le faatinoga faaletonu '(0,' ['None`]') 'ua saʻo mo so o se vaitafe.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}