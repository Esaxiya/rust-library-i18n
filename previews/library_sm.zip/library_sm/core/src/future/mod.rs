#![stable(feature = "futures_api", since = "1.36.0")]

//! Fua faʻatusatusa tulaga taua.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// O lenei ituaiga e manaʻomia aua:
///
/// a) le mafai ona faatino eletise `for<'a, 'b> Generator<&'a mut Context<'b>>`, o lea e tatau ona tatou oo a faʻasino mata (tagai <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Faʻailoga mata ma `NonNull` e le `Send` poʻo `Sync`, o lea e mafai ai ona faia uma uma future non-Send/Sync, ma matou te le manaʻo i lena.
///
/// E foi simplifies le tuuina i lalo HIR o `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Afifi se afi eletise i le future.
///
/// O lenei gaioiga e toe faʻafoʻi mai le `GenFuture` i lalo, ae nanaina i le `impl Trait` e maua ai ni feau sese sili atu (`impl Future` nai lo le `GenFuture<[closure.....]>`).
///
// o `const` lenei e aloese mai mea sese faaopoopo uma ona tatou toe faaleleia mai `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Tatou te faalagolago i le mea moni e le mafaagaeetia async/await futures ina ia faatupuina ai le tagata lava ia-referential borrows i le afi faavae.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SAFETI: Saogalelei aua o tatou !Unpin + !Drop, ma o lenei ua naʻo se faʻataʻatiaga o fanua.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Toe faaauau ai le afi, liliu le `&mut Context` i se faasino mata `NonNull`.
            // O le `.await` tuʻuina i lalo o le a saogalemu lafoina lena i tua i le `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SAFETY: e tatau i le tagata telefoni ona faʻamautinoa o le `cx.0` o se faʻasino tonu
    // e faʻamalieina uma manaʻoga mo se mutable faʻasino.
    unsafe { &mut *cx.0.as_ptr().cast() }
}