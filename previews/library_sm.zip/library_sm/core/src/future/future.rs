#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// faatusa A future se fuafuaina asynchronous.
///
/// A future o se taua e mafai e le uma le fuafuaina ae.
/// O lenei ituaiga o "asynchronous value" e mafai ai e se filo e faaauau pea le faia o galuega aoga ao faatalitali mo le taua e avea ai ma maua.
///
///
/// # Le `poll` metotia
///
/// O le autu metotia o future, `poll`,*taumafaiga* e fofo le future i se mulimuli taua.
/// e le taofia lenei auala pe afai e le o saunia i le taua.
/// Nai lo lena, ua faatulagaina le galuega i le taimi nei ina ia woken pe a e le mafai ona avea le alualu i luma isi e 'toe poll`ing.
/// mavae le `context` i le auala `poll` e mafai ona tuuina atu se [`Waker`], o se 'au mo le nofo i luga i le galuega i le taimi nei.
///
/// A e faʻaaogaina le future, e masani ona e le taʻua saʻo le `poll`, ae nai lo le `.await` le tau.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Le ituaiga o tau aoga gaosia i le maeʻa.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Taumafai e fofo le future i se tau mulimuli, resitaraina o le taimi nei galuega mo fafagu pe a fai o le aoga e leʻi maua.
    ///
    /// # Toe faafoi taua
    ///
    /// Lenei galuega tauave toe foi:
    ///
    /// - [`Poll::Pending`] afai o le future e leʻi sauni
    /// - [`Poll::Ready(val)`] ma le iʻuga `val` o lenei future pe a maeʻa ma le manuia.
    ///
    /// A maeʻa loa le future, e le tatau i tagata ona toe faʻaaoga le `poll`.
    ///
    /// A o le future e leʻi sauni, `poll` toe faafoi `Poll::Pending` ma teuina se faʻailoga o le [`Waker`] kopi mai le [`Context`] o loʻo i ai nei.
    /// Lenei [`Waker`] e fafagu loa le future mafai ona alualu i luma.
    /// Mo se faataitaiga, o se future faatalitali mo se mataʻomo e avea ma faitauina le a valaau `.clone()` i le [`Waker`] ma teu ai.
    /// A se faailo taunuu o se isi nofoaga e faailoa mai o ma faitauina le mataʻomo, [`Waker::wake`] ua valaauina ma le mataʻomo galuega a future ua awoken.
    /// O le taimi lava e ala ai i luga se galuega, e tatau ona toe taumafai e `poll` le future toe, lea e mafai pe le mafai ona maua ai se mulimuli taua.
    ///
    /// Faaaliga e faapea i le valaauga tele i `poll`, na o le [`Waker`] mai le mavae [`Context`] i le tatau ona faatulagaina e sili ona valaau talu ai nei e maua ai se wakeup.
    ///
    /// # uiga Runtime
    ///
    /// Naʻo le Futures e *inert*;e tatau ona latou *faʻamalosi*`palotaina 'ina ia agaʻi i luma, o lona uiga o taimi uma e ala ai le galuega o loʻo i ai i le taimi nei, e tatau ona toe toʻagaʻo' poloka` e faʻatali futures o loʻo iai pea lona fiafia i ai.
    ///
    /// O le `poll` gaioiga e le valaʻauina soʻo i se fusi mau-nai lo lena, e tatau ona valaʻau pe a fai o le future faʻailoa mai ua sauni e alualu i luma (i le valaʻau `wake()`).
    /// Afai e te masani i le `poll(2)` po `select(2)` syscalls i Unix ai a aoga ia iloa o futures faia masani *le* mafatia i le faafitauli lava lea e tasi o "all wakeups must poll all events";latou e sili atu e pei o `epoll(4)`.
    ///
    /// O le faʻatinoina o le `poll` e tatau ona taumafai e toe foʻi vave mai, ma e le tatau ona poloka.O le toe foʻi faʻavave ona puipuia le le manaʻomia o le ufiufiina o filo poʻo ni faʻasologa o mea tutupu.
    /// Afai e iloa muamua o le taimi o le valaʻau i le `poll` ono iʻu i sina taimi puʻupuʻu, o le galuega e tatau ona tuʻufaʻatasia i se filo vai (poʻo se mea faʻapena) ia mautinoa o `poll` mafai ona toe foʻi vave mai.
    ///
    /// # Panics
    ///
    /// A maeʻa loa le future (faʻafoʻi le `Ready` mai le `poll`), toe valaʻau foʻi i lana auala `poll` atonu panic, poloka faʻavavau, pe mafua ai isi ituaiga o faʻafitauli;tuu le `Future` trait leai se tulaga manaomia i luga o le aafiaga o le valaau a faapena.
    /// Ae peitai, e le faailogaina ai le auala `poll` `unsafe`, faaaogā i ai tulafono masani a Rust: valaauga le tatau lava ona faia amioga undefined (manatua pala, faaaogaina sese o galuega tauave `unsafe`, po o le e pei o), e tusa lava po o le tulaga o le future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}