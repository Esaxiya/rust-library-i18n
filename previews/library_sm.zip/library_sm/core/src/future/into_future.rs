use crate::future::Future;

/// Faʻaliliuga i totonu o le `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// O le galuega faatino o le future o le a gaosia i le maeʻa.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// O lea ituaiga o future ua tatou liliu lenei i?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Fausia se future mai se tau.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}