//! Faʻapitoa tuʻufaʻatasia i le `f32` tasi-le faʻataʻitaʻiga itu manatu vaega.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Fuainumera taua numera o loʻo saunia i le `consts` sub-module.
//!
//! Mo le auiliiliina faʻamalamalamaina tuʻusaʻo i lenei module (e ese mai i latou faʻamatalaina i le `consts` sub-module), fou tulafono e tatau ai nai lo le faʻaaogaina o fesoʻotaʻiga tumau faʻamatalaina tuʻusaʻo luga o le `f32` ituaiga.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// O le radix poʻo le faʻavae o le sui i totonu o le `f32`.
/// Faʻaaoga le [`f32::RADIX`] nai lo.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // auala fuafuaina
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Aofaʻi o numera taua ile faʻavae 2.
/// Faʻaaoga le [`f32::MANTISSA_DIGITS`] nai lo.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // auala fuafuaina
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Fua faʻatatau o numera taua ile base 10.
/// Faʻaaoga le [`f32::DIGITS`] nai lo.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // auala fuafuaina
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] aoga mo `f32`
/// Faʻaaoga le [`f32::EPSILON`] nai lo.
///
/// Ole 'eseʻesega lea ile va ole `1.0` male isi numera e sili atu ona sui.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // auala fuafuaina
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Laʻititi maualalo `f32` aoga.
/// Faʻaaoga le [`f32::MIN`] nai lo.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // auala fuafuaina
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Laʻititi lelei lelei masani `f32` taua.
/// Faʻaaoga le [`f32::MIN_POSITIVE`] nai lo.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // auala fuafuaina
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Sili lapoʻa `f32` taua.
/// Faʻaaoga le [`f32::MAX`] nai lo.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // auala fuafuaina
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Tasi sili atu nai lo le maualalo mafai masani mana o le 2 exponent.
/// Faaaoga [`f32::MIN_EXP`] ae.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // auala fuafuaina
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Tapulaa maualuga mafai mana o le 2 exponent.
/// Faʻaaoga le [`f32::MAX_EXP`] nai lo.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // auala fuafuaina
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Maualalo mafai mana masani o le 10 exponent.
/// Faʻaaoga le [`f32::MIN_10_EXP`] nai lo.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // auala fuafuaina
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Tapulaa maualuga mafai mana o le 10 exponent.
/// Faʻaaoga le [`f32::MAX_10_EXP`] nai lo.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // auala fuafuaina
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Leai se numera (NaN).
/// Faʻaaoga le [`f32::NAN`] nai lo.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // auala fuafuaina
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Le iʻu ole (∞).
/// Faʻaaoga le [`f32::INFINITY`] nai lo.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // auala fuafuaina
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Le lelei le uma (−∞).
/// Faʻaaoga le [`f32::NEG_INFINITY`] nai lo.
///
/// # Examples
///
/// ```rust
/// // auala le aoga
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // auala fuafuaina
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Faavae numera masani.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: sui i le matematika tumau mai cmath.

    /// Archimedes 'tumau (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// O le liʻo atoa tumau (τ)
    ///
    /// Tutusa i le 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Numera a le Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// O le radix poʻo le faʻavae o le sui i totonu o le `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Aofaʻi o numera taua ile faʻavae 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Fua faʻatatau o numera taua ile base 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] aoga mo `f32`
    ///
    /// Ole 'eseʻesega lea ile va ole `1.0` male isi numera e sili atu ona sui.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Laʻititi maualalo `f32` aoga.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Laʻititi lelei lelei masani `f32` taua.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Sili lapoʻa `f32` taua.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Tasi sili atu nai lo le maualalo mafai masani mana o le 2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Tapulaa maualuga mafai mana o le 2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Maualalo mafai mana masani o le 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Tapulaa maualuga mafai mana o le 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Leai se numera (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Le iʻu ole (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Le lelei le uma (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Faʻafoʻi `true` pe a fai o lenei tau e `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` e le maua i le lautele i le libcore ona o atugaluga e uiga i le feaveaʻi, o lea o lenei faʻatatauga e mo tumaoti faʻaaogaina totonu.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Faʻafoʻi `true` pe a fai o lenei tau e lelei le faʻavavau pe faʻaletonu leaga, ma `false` i se isi itu.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Faʻafoʻi `true` pe a fai o lenei numera e le gata pe `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // E leai se mea e manaʻomia e faʻagaioia eseese ai NaN: afai o ia lava o NaN, e le moni le faʻatusatusaga, pei ona manaʻomia.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Faʻafoʻi `true` pe a fai o le numera [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Taua i le va `0` ma `min` e Subnormal.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Faʻafoʻi `true` pe a fai o le numera e leai, leai se gataaga, [subnormal], poʻo le `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Taua i le va `0` ma `min` e Subnormal.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Faʻafoʻi mai le vaega faʻavasega numera o le numera.
    /// Afai e naʻo le tasi le meatotino o le a faʻataʻitaʻia, e masani lava ona televave le faʻaaogaina o le faʻamaoniga faapitoa nai lo.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Faʻafoʻi `true` pe a fai o `self` o loʻo iai se faʻailoga lelei, e aofia ai le `+0.0`, `NaN`s ma le faʻailoga lelei ma le faʻamaoni lelei.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Faʻafoʻi `true` peʻa iai se faʻailoga le lelei ole `self`, e aofia ai le `-0.0`, `NaN`s ma le faʻailoga le lelei ma le le faʻamaoni.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 fai mai: isSignMinus(x) e moni pe a fai ma pe a fai x ei ai faʻailoga le lelei.
        // faatatau isSignMinus e zeros ma NaNs faapea.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Ave le (inverse) faʻasolosolo ole numera, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Liua radians i tikeri.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Faʻaaoga se tumau mo sili atu le saʻo.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Liua tikeri i radians.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Faʻafoʻi mai le maualuga o numera e lua.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Afai o se tasi o finauga o NaN, o lona uiga o leisi finauga ua toe faʻafoʻi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Faʻafoʻi mai le maualalo o numera e lua.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Afai o se tasi o finauga o NaN, o lona uiga o leisi finauga ua toe faʻafoʻi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// E faʻataʻamilomilo agai i le zero ma liua i soʻo se ituaiga numera muamua o fuainumera, faʻapea o le taua e gata ma fetaui i lena ituaiga.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// O le tau tatau ona:
    ///
    /// * Aua le `NaN`
    /// * Aua le iʻu
    /// * Avea ma sui i le ituaiga toe faafoi `Int`, pe a maeʻa ona tipi ese lona vaevaega vaega
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Faʻaliliuina mata i le `u32`.
    ///
    /// Lenei e tutusa nei ma `transmute::<f32, u32>(self)` luga uma faʻavae.
    ///
    /// Vaʻai `from_bits` mo nisi talanoaga o le gafatia o lenei faʻagaioiga (e toeititi lava leai ni faʻafitauli).
    ///
    /// Manatua o lenei gaioiga e ese mai le `as` lafo, lea e taumafai e faʻasao le numera *numera*, ae leʻo le tau faʻatauvaʻa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() e le lafo!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // SAFETY: `u32` o se faigofie tuai datatype ina ia mafai ai ona tatou faʻasalalau atu i ai
        unsafe { mem::transmute(self) }
    }

    /// Faʻalauiloa mata mai le `u32`.
    ///
    /// Lenei e tutusa nei ma `transmute::<u32, f32>(v)` luga uma faʻavae.
    /// E foliga mai o lenei e matua faigata ona feaveaʻi, mo lua mafuaʻaga:
    ///
    /// * Floats ma Ints e i ai le tutusa tutusa i luga o lagolago uma tulaga.
    /// * IEEE-754 faʻapitoa lava faʻamaoti mai le laʻititi faʻatulagaina o opeopea.
    ///
    /// E ui i lea e tasi le lapataiga: ae le i oʻo i le 2008 version o le IEEE-754, faʻafefea ona faʻauiga le NaN signaling bit e leʻi faʻamaoti mai.
    /// O le tele o fausaga opea (e maise le x86 ma le ARM) filifilia le faʻauigaina na faʻamamaluina i le 2008, ae o nisi e leʻi (taʻua MIPS).
    /// O lona iʻuga, o NaNs uma e saini i le MIPS e filemu naNN i le x86, ma le isi itu.
    ///
    /// Nai lo le taumafai e faʻasao-faʻailo-ness koluse-tulaga, o lenei faʻatinoina fiafia i le faʻasaoina o le tonu fasi.
    /// O lona uiga o soʻo se uta utaina i NaNs o le a faʻasaoina tusa lava pe o le iʻuga o lenei metotia na lafoina i luga o le upega tafaʻilagi mai le x86 masini i le MIPS tasi.
    ///
    ///
    /// Afai o faʻaiuga o lenei metotia e naʻo le faʻataʻitaʻia e le ata lava e tasi na gaosia ai, e leai la se mea e ono popole ai.
    ///
    /// Afai o le sao e le o NaN, ona leai lea o se popolevale feaveaʻi.
    ///
    /// Afai e te le popole e uiga i signalingness (ono), ona leai lea o se popolevale feaveaʻi.
    ///
    /// Manatua o lenei gaioiga e ese mai le `as` lafo, lea e taumafai e faʻasao le numera *numera*, ae leʻo le tau faʻatauvaʻa.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // SAFETY: `u32` o se faigofie tuai datatype ina ia mafai ai ona tatou faʻasalalau ese mai ai
        // Ua aliali mai o le saogalemu mataupu ma sNaN na soona pupula!Talofa!
        unsafe { mem::transmute(v) }
    }

    /// Faʻafoʻi le faʻamanatuga o lenei numera opeopea numera o se byte array i le tele-endian (network) byte oka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Faʻafoʻi le faʻamanatuga o lenei numera opeopea numera o se byte array i si faʻaiʻuga faʻa byte-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Toe foi le manatu faatusa o lenei numera tulaga opeopea o se byte autau ina moni byte.
    ///
    /// A o faʻaaogaina le faʻavae tulaga moni endianness, feaveaʻi tulafono laiti tatau ona faʻaaoga [`to_be_bytes`] poʻo [`to_le_bytes`], pe a talafeagai ai, nai lo.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Toe foi le manatu faatusa o lenei numera tulaga opeopea o se byte autau ina moni byte.
    ///
    ///
    /// [`to_ne_bytes`] tatau ona sili atu i lenei mea pe a mafai.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // SAFETY: `f32` o se faigofie tuai datatype ina ia mafai ai ona tatou faʻasalalau atu i ai
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Fausia se opeopea manatu taua mai lona sui o se byte faʻatulagaina i tele endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Fausia se opeopea manatu taua mai lona sui o se byte faʻataʻitaʻi i laʻititi endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Fausia se opeopea manatu taua mai lona sui o se byte faʻaopoopo i tagatanuu endian.
    ///
    /// Aʻo faʻaaogaina le faʻavae tulaga moni endianness, feaveaʻi tulafono laiti ono manaʻo e faʻaaoga [`from_be_bytes`] poʻo [`from_le_bytes`], pe a talafeagai ai.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Faʻafoʻi mai se oka i le va o oe lava ma isi faʻatauaina.
    /// E le pei o le faatusatusaga vaega o tulaga faatonuina i le va o opeopea numera o taimi, lenei faatusatusaga e maua i taimi uma se okaina e tusa i le predicate totalOrder pei ona faamatalaina i IEEE 754 (2008 toe iloiloga) tulaga manatu opeopea.
    /// O mea taua e okaina i le faʻatonuga lenei:
    /// - Le lelei filemu NaN
    /// - Le lelei faailo NaN
    /// - Le lelei le uma
    /// - Numera leaga
    /// - Le lelei numera numera
    /// - Leaga lelei
    /// - Lelei leai
    /// - Numera masani lelei
    /// - Numera lelei
    /// - Lelei le iʻu
    /// - Nan signaling lelei
    /// - Lelei filemu NaN
    ///
    /// Manatua o lenei gaioiga e le o taimi uma e tutusa ma [`PartialOrd`] ma [`PartialEq`] faʻatinoina o `f32`.Ae maise lava, latou manatu i le leaga ma lelei zero e tutusa, ae `total_cmp` leai.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // I tulaga o mea le lelei, flip uma bits seʻi vagana ai le faʻailoga e ausia ai se tutusa faʻatulagaina e pei o lua 'aufaʻatasi fuainumera
        //
        // Aisea e aoga ai lenei mea?IEEE 754 opeopea aofia ai tolu fanua:
        // Saini laititi, faʻalauiloa ma mantissa.O le seti o exponent ma mantissa fanua atoa o loʻo i ai le meatotino o la latou faʻatonutonuga laititi e tutusa ma le numera tele le mea o loʻo faʻamatalaina ai le maualuga.
        // O le lapoʻa e le masani ona faʻamatalaina i luga ole tauaNN, ae o le IEEE 754 aofaʻiOrder o loʻo faʻamatalaina ai le taua o le NaN e mulimuli ai foʻi i le faʻasologa tatau.O lenei mea e tau atu ai i le oka faʻamatalaina i le pepa faʻamatalaga.
        // Ae ui i lea, o le faʻaalia o le maualuga e tutusa mo numera le lelei ma lelei-naʻo le faʻailoga laititi e ese.
        // Ina ia faʻatusatusa faigofie le fola e pei o ni fuainumera ua sainia, tatou manaʻomia le see ese o le exponent ma mantissa fasi i le tulaga o le lelei numera.
        // Matou faʻalelei le faʻailoaina o numera ile "two's complement" form.
        //
        // Ina ia faia le flipping, tatou fausia se matapulepule ma XOR faasaga i ai.
        // Matou te le fuafuaina fuafua le "all-ones except for the sign bit" mask mai faʻaletonu-saini tulaga taua: saʻo fesuiaʻiga saini-faʻalautele le numera, o lea matou "fill" le mask ma faʻailoga, ona faʻaliliu lea i le saini e tuleia le tasi sili zero.
        //
        // I luga o aoga taua, o le ufimata e uma zeros, o lea o le leai-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Faʻatapulaʻa se tau i se vaitaimi vagana o le NaN.
    ///
    /// Faʻafoʻi `max` pe a fai o `self` e sili atu nai lo `max`, ma `min` peʻa `self` e laititi atu i le `min`.
    /// A leai o lenei toe faafoi `self`.
    ///
    /// Manatua o lenei gaioiga toe faafoi NaN pe afai o le muamua aoga NaN foi.
    ///
    /// # Panics
    ///
    /// Panics pe a fai o `min > max`, `min` o NaN, pe o `max` o NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}