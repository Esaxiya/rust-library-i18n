macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// O le aoga itiiti e mafai ona faatusa i lenei ituaiga integer.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Ole tau pito i tele e mafai ona faʻatusalia e lenei ituaiga fuainumera.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// O le tele o lenei fuainumera integer ituaiga i fasi.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Faʻaliliuina se fasi fasi manoa i totonu o se faʻavae tuʻufaʻatasia i se fuainumera.
        ///
        /// Ole manoa e faʻamoemoe e avea ma filifiliga `+` filifiliga mulimuli ai numera.
        ///
        /// O le taʻitaʻi ma le faʻataʻitaʻiina o le paʻepaʻe e fai ma sui o se mea sese.
        /// Digits o se subset o nei tagata, e faalagolago i `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Lenei gaioiga panics pe a fai o `radix` e le o iai mai le 2 i le 36.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Faʻafoʻi mai le numera o mea i le binary representation o `self`.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Faʻafoʻi mai le numera o zero i le binary representation o `self`.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Faʻafoʻi mai le numera o taʻitaʻi zero i le binary representation o `self`.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Faʻafoʻi mai le numera o laina faʻasolosolo i le binary faʻaaliga o le `self`.
        ///
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Faʻafoʻi mai le numera o taʻimua i le faʻaaliga binary o `self`.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Faʻafoʻi mai le numera o auala savali i le faʻaaliga binary o le `self`.
        ///
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Sueina fagota i le agavale e se aofaʻi faʻapitoa, `n`, afifiina o tipi faʻapipiʻiina i le iʻuga o le fuainumera fuainumera.
        ///
        ///
        /// Faʻamolemole ia manatua e le tutusa le gaioiga ma le `<<` sifi faʻagaioiga!
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Sueina fagota i le taumatau i se aofaʻi faʻapitoa, `n`, afifiina o tipi faʻapipiʻiina i le amataga o le fuainumera fuainumera.
        ///
        ///
        /// Faʻamolemole ia manatua e le tutusa le gaioiga ma le `>>` sifi faʻagaioiga!
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Suia le byte oka o le fuainumera.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// tuʻu m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Faʻaaoga le faʻasologa o faʻi i le numera.
        /// O le mea laʻititi taua e avea ma mea sili ona taua, lona lua laʻititi-aoga laʻititi avea ma lona lua sili ona taua, ma isi.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// tuʻu m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Faʻaliliuina le fuainumera mai le tele pito i le taunuʻuga o le iuga.
        ///
        /// I luga o endian tele o lenei o le leai-op.
        /// I tamaʻi faʻaiuga ua fesuiaʻi byte.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// pe a faʻapea, (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } isi {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Faʻaliliuina se fuainumera amata mai laʻititi endian i le iʻuga o le sini.
        ///
        /// I le endian laitiiti o lenei o le leai-op.
        /// I luga o endian tetele o bytes ua fesuiaʻi.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// pe a faʻapea, (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } isi {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Faʻaliliuga `self` i le lapoʻa mulimuli mai le faʻaiuga o le iuga.
        ///
        /// I luga o endian tele o lenei o le leai-op.
        /// I tamaʻi faʻaiuga ua fesuiaʻi byte.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// pe a faʻapea, (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } isi { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // pe leai foi?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Faʻaliliuina `self` i siʻusiʻuga mulimuli mai le faʻatutuina o le iuga.
        ///
        /// I le endian laitiiti o lenei o le leai-op.
        /// I luga o endian tetele o bytes ua fesuiaʻi.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// pe a faʻapea, (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } isi { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Siaki integer faʻaopopo.
        /// Faʻatusatusa `self + rhs`, faʻafoʻi `None` pe a fai o le ova na tupu.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Faʻaopopo integer faʻaopopo.Faʻatusatusaina `self + rhs`, faʻapea o le lolovaʻa e le mafai ona tupu.
        /// E mafua ai amioga le faʻamatalaina pe a
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Siaki toese numera.
        /// Faʻatusatusa `self - rhs`, faʻafoʻi `None` pe a fai o le ova na tupu.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Toese le aofaʻi o fuainumera fuainumera.Faʻatusatusaina `self - rhs`, faʻapea o le lolovaʻa e le mafai ona tupu.
        /// E mafua ai amioga le faʻamatalaina pe a
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Siaki numera faʻatele.
        /// Computes `self * rhs`, toe foi `None` pe afai e tupu tele foʻi.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Faʻateleina integerFaʻatusatusa `self * rhs`, manatu faʻapea e le mafai ona tupu se faʻalavelave.
        /// E mafua ai amioga le faʻamatalaina pe a
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SAFETY: o le tagata telefoni e tatau ona lagolagoina le saogalemu konekarate mo `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Siaki le aofaʻiga o numera.
        /// Faʻatusatusa `self / rhs`, faʻafoʻi `None` peʻa `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAFETY: div e zero ua uma ona siaki i luga ma unsigned saini leai seisi
                // toilalo auala mo vaevaega
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Siaki le Euclidean vaevaega.
        /// Faʻatusatusa `self.div_euclid(rhs)`, faʻafoʻi `None` peʻa `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// O totoe o numera o numera.
        /// Faʻatusatusa `self % rhs`, faʻafoʻi `None` peʻa `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAFETY: div e zero ua uma ona siaki i luga ma unsigned saini leai seisi
                // toilalo auala mo vaevaega
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Siaki le Euclidean modulo.
        /// Faʻatusatusa `self.rem_euclid(rhs)`, faʻafoʻi `None` peʻa `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Siaki le faʻatagaina.Faʻatusatusa `-self`, faʻafoʻi `None` seʻi vagana 'lava==
        /// 0`.
        ///
        /// Manatua o le teenaina o soʻo se fuainumera lelei o le a lolovaia.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Siaki le agavale agavale.
        /// Faʻatusatusa `self << rhs`, faʻafoʻi `None` pe a fai o `rhs` e lapoʻa nai lo pe tutusa ma le numera o fasi i `self`.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Siaki le taumatau sifi.
        /// Faʻatusatusa `self >> rhs`, faʻafoʻi `None` pe a fai o `rhs` e lapoʻa nai lo pe tutusa ma le numera o fasi i `self`.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Siakiina exponentiation.
        /// Faʻatusatusa `self.pow(exp)`, faʻafoʻi `None` pe a fai o le ova na tupu.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // talu exp!=0, mulimuli ane o le exp tatau ona 1.
            // Faʻafesoʻotaʻiga le vaega mulimuli o le exponent, talu ai o le sikueina o le faʻavae mulimuli ane e le talafeagai ma ono mafua ai le leai se aoga ova.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Saturating integer faaopoopo.
        /// Faʻatusatusa `self + rhs`, faʻamalieina i numera numera nai lo le ova.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Toese integer toesea.
        /// Faʻatusatusa `self - rhs`, faʻamalieina i numera numera nai lo le ova.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Fuafua integer faʻateleina.
        /// Faʻatusatusa `self * rhs`, faʻamalieina i numera numera nai lo le ova.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Faʻaopopoina o fuainumera integer exponentiation.
        /// Faʻatusatusa `self.pow(exp)`, faʻamalieina i numera numera nai lo le ova.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Afifiina (modular) faʻaopoopoga.
        /// Faʻatusatusa `self + rhs`, afifi faataamilo i le tuaoi o le ituaiga.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Afifiina (modular) toese.
        /// Faʻatusatusa `self - rhs`, afifi faataamilo i le tuaoi o le ituaiga.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Afifiina (modular) faʻateleina.
        /// Faʻatusatusa `self * rhs`, afifi faataamilo i le tuaoi o le ituaiga.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// Faʻamolemole vaʻai o lenei faʻataʻitaʻiga e tufatufaina i le va o numera o fuainumera.
        /// Lea e faʻamatala ai le mafuaʻaga ua faʻaaogaina ai `u8` ii.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Afifiina (modular) vaevaega.Faʻatusatusa `self / rhs`.
        /// Vaeluaina fevaevaeaʻi i luga o ituaiga le saini e na o le vaevaega masani
        /// E leai se auala afifi mafai ona tupu.
        /// O lenei gaioiga o loʻo i ai, ina ia o gaioiga uma e teuina i le afifiina o gaioiga.
        ///
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Afifi vaega Euclidean.Faʻatusatusa `self.div_euclid(rhs)`.
        /// Vaeluaina fevaevaeaʻi i luga o ituaiga le saini e na o le vaevaega masani
        /// E leai se auala afifi mafai ona tupu.
        /// O lenei gaioiga o loʻo i ai, ina ia o gaioiga uma e teuina i le afifiina o gaioiga.
        /// Talu ai, mo fuainumera lelei, o faʻauiga masani uma o le vaevaega e tutusa, o lenei e tutusa tutusa ma `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Afifi (modular) toega.Faʻatusatusa `self % rhs`.
        /// O mea totoe ua afifi i luga o ituaiga e leʻo saini e naʻo le taimi e totoe o le fuafuaina.
        ///
        /// E leai se auala afifi mafai ona tupu.
        /// O lenei gaioiga o loʻo i ai, ina ia o gaioiga uma e teuina i le afifiina o gaioiga.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Afifi modulo Euclidean.Faʻatusatusa `self.rem_euclid(rhs)`.
        /// Afifi modulo fuafuaina i luga o unsigned ituaiga na o le masani totoe fuafuaina.
        /// E leai se auala afifi mafai ona tupu.
        /// O lenei gaioiga o loʻo i ai, ina ia o gaioiga uma e teuina i le afifiina o gaioiga.
        /// Talu ai, mo fuainumera lelei, o faʻauiga masani uma o le vaevaega e tutusa, o lenei e tutusa tutusa ma `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Afifiina (modular) lafoga.
        /// Faʻatusatusa `-self`, afifi faataamilo i le tuaoi o le ituaiga.
        ///
        /// Talu ai o ituaiga e le saini e leai ni faʻaletonu tutusa, o le a afifi uma faʻaoga o lenei galuega (seʻi vagana le `-0`).
        /// Mo tau laʻititi nai lo le tutusa saini saini ituaiga o le faʻaiuga e tutusa ma le lafoina o le tutusa saini aofaʻi.
        ///
        /// Soʻo se lapoʻa taua e tutusa ma `MAX + 1 - (val - MAX - 1)` o `MAX` o le tutusa sainiina ituaiga o le maualuga.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// Faʻamolemole vaʻai o lenei faʻataʻitaʻiga e tufatufaina i le va o numera o fuainumera.
        /// Lea e faʻamatala ai le mafuaʻaga ua faʻaaogaina ai `i8` ii.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-leai se totogi fesuiaʻi-agavale;
        /// faʻatupuina `self << mask(rhs)`, lea `mask` aveʻesea soʻo se maualuga-faʻatulagaina fasi o `rhs` e ono mafua ai le sifi e sili atu i le bitwidth o le ituaiga.
        ///
        /// Manatua o lenei e *le* tutusa ma le faʻasolo-agavale;o le RHS o se afifi fesuiaʻi-agavale e faʻatapulaaina i le lautele o le ituaiga, nai lo le fasi suia mai le LHS ua toe faʻafoʻi atu i le isi pito.
        /// O le primitive integer ituaiga uma faʻatinoina se [`rotate_left`](Self::rotate_left) gaioiga, atonu o le mea lena e te manaʻo ai.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SAFETY: o le masking i le bitsize o le ituaiga mautinoa le tatou le sifi
            // i fafo atu o tuaoi
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-leai se totogi fesuiaʻi-taumatau;
        /// faʻatupuina `self >> mask(rhs)`, lea `mask` aveʻesea soʻo se maualuga-faʻatulagaina fasi o `rhs` e ono mafua ai le sifi e sili atu i le bitwidth o le ituaiga.
        ///
        /// Manatua o lenei e *le* tutusa ma le faʻasolo-taumatau;o le RHS o se afifi fesuiaʻi-taumatau e faʻatapulaʻaina i le lautele o le ituaiga, nai lo le fasi suia mai le LHS ua toe faʻafoʻi atu i le isi pito.
        /// faatino uma le ituaiga integer anamua se galuega tauave [`rotate_right`](Self::rotate_right), lea e mafai ona avea ma mea e te manao nai lo.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SAFETY: o le masking i le bitsize o le ituaiga mautinoa le tatou le sifi
            // i fafo atu o tuaoi
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Afifiina (modular) exponentiation.
        /// Faʻatusatusa `self.pow(exp)`, afifi faataamilo i le tuaoi o le ituaiga.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // talu exp!=0, mulimuli ane o le exp tatau ona 1.
            // Faʻafesoʻotaʻiga le vaega mulimuli o le exponent, talu ai o le sikueina o le faʻavae mulimuli ane e le talafeagai ma ono mafua ai le leai se aoga ova.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Fuafua `self` + `rhs`
        ///
        /// Faʻafoʻi mai se tuple o le faʻaopopoga faʻatasi ai ma le boolean e faʻailoa mai ai pe o le a tupu se arithmetic overflow.
        /// Afai o se ova o le a tupu ono tupu lea o le afifi taua ua toe faafoi.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Fuafua `self`, `rhs`
        ///
        /// Faʻafoʻi mai se tuple o le toʻese faʻatasi ma le boolean e faʻailoaina mai ai pe o le a tupu se faʻasolitulafono arithmetic.
        /// Afai o se ova o le a tupu ono tupu lea o le afifi taua ua toe faafoi.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Fuafuaina le faʻatele o `self` ma `rhs`.
        ///
        /// Faʻafoi mai se tuple o le faʻateleina faʻatasi ma le boolean e faʻailoa mai ai pe o le a tupu se arithmetic overflow.
        /// Afai o se ova o le a tupu ono tupu lea o le afifi taua ua toe faafoi.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// Faʻamolemole vaʻai o lenei faʻataʻitaʻiga e tufatufaina i le va o numera o fuainumera.
        /// Lea e faʻamatala ai le mafuaʻaga ua faʻaaogaina ai `u32` ii.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Fuafua le divis pe a `self` e vaevaeina e `rhs`.
        ///
        /// Faʻafoʻi mai se tuple o le vaeluaina ma se boolean e faʻailoa mai ai pe o le a tupu se arithmetic ova.
        /// Manatua mo le unsigned integers overflow e leai se mea e tupu, o lona uiga la o lona lua o aoga e masani ona `false`.
        ///
        /// # Panics
        ///
        /// Lenei gaioiga o le a panic pe a fai o `rhs` o 0.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Fuafua le aofaʻi o le Euclidean vaevaega `self.div_euclid(rhs)`.
        ///
        /// Faʻafoʻi mai se tuple o le vaeluaina ma se boolean e faʻailoa mai ai pe o le a tupu se arithmetic ova.
        /// Manatua mo le unsigned integers overflow e leai se mea e tupu, o lona uiga la o lona lua o aoga e masani ona `false`.
        /// Talu ai, mo fuainumera lelei, o faʻauiga masani uma o le vaevaega e tutusa, o lenei e tutusa tutusa ma `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Lenei gaioiga o le a panic pe a fai o `rhs` o 0.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Fuafua le mea o totoe pe a vaevaeina `self` e `rhs`.
        ///
        /// Faʻafoʻi mai se tuple o mea o totoe ina ua uma ona vaeluaina ma se boolean e faʻailoa ai pe o le a tupu se arithmetic ova.
        /// Manatua mo le unsigned integers overflow e leai se mea e tupu, o lona uiga la o lona lua o aoga e masani ona `false`.
        ///
        /// # Panics
        ///
        /// Lenei gaioiga o le a panic pe a fai o `rhs` o 0.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Fuafua le toega `self.rem_euclid(rhs)` pei peiseai ile Euclidean vaevaega.
        ///
        /// Faʻafoʻi mai se tuple o le modulo pe a uma ona vaeluaina ma se boolean e faʻailoa mai ai o le a tupu se arithmetic overflow.
        /// Manatua mo le unsigned integers overflow e leai se mea e tupu, o lona uiga la o lona lua o aoga e masani ona `false`.
        /// Talu ai, mo fuainumera lelei, o faʻauiga masani uma o le vaevaega e tutusa, o lenei faʻagaioiga e tutusa lelei ma `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Lenei gaioiga o le a panic pe a fai o `rhs` o 0.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Le faʻatauaina o ia lava i se faiga soʻona faʻatupuina.
        ///
        /// Faʻafoʻi `!self + 1` faʻaaogaina afifi faʻagaioiga e toe faʻafoʻi le tau e fai ma sui o le le taliaina o lenei le sainia tau.
        /// Manatua mo le lelei unsigned tulaga faʻafuaseʻi ova o taimi uma tupu, ae faʻateʻaina 0 e le ova.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Sifi oe lava tuua e `rhs` faagutu.
        ///
        /// Faʻafoʻi mai se tuple o le suiga o oe lava faʻatasi ai ma le boolean e faʻailoa mai ai pe o le suiga o le tau na tele atu pe tutusa i le aofaʻi o fasi.
        /// A faʻapea e telē tele le suiga, ona faʻapipiʻi lea o le (N-1) i le N o le aofaʻi o fasi, ona faʻaaogaina ai lea o le tau e faʻatino ai le sifi.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Sueina saʻo ia lava e `rhs` faagutu.
        ///
        /// Faʻafoʻi mai se tuple o le suiga o oe lava faʻatasi ai ma le boolean e faʻailoa mai ai pe o le suiga o le tau na tele atu pe tutusa i le aofaʻi o fasi.
        /// A faʻapea e telē tele le suiga, ona faʻapipiʻi lea o le (N-1) i le N o le aofaʻi o fasi, ona faʻaaogaina ai lea o le tau e faʻatino ai le sifi.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Siitia oe lava i le malosiaga o `exp`, faʻaaogaina le exponentiation e ala i le sikuea.
        ///
        /// Faʻafoʻi mai se tuple o le exponentiation faʻatasi ai ma le bool o loʻo faʻailoa mai ai pe na tupu se mea ova.
        ///
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, moni));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Faʻalautele avanoa mo le teuina o iʻuga o le ova_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // talu exp!=0, mulimuli ane o le exp tatau ona 1.
            // Faʻafesoʻotaʻiga le vaega mulimuli o le exponent, talu ai o le sikueina o le faʻavae mulimuli ane e le talafeagai ma ono mafua ai le leai se aoga ova.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Siitia oe lava i le malosiaga o `exp`, faʻaaogaina le exponentiation e ala i le sikuea.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // talu exp!=0, mulimuli ane o le exp tatau ona 1.
            // Faʻafesoʻotaʻiga le vaega mulimuli o le exponent, talu ai o le sikueina o le faʻavae mulimuli ane e le talafeagai ma ono mafua ai le leai se aoga ova.
            //
            //
            acc * base
        }

        /// Faia Euclidean vaevaega.
        ///
        /// Talu ai, mo fuainumera lelei, o faʻauiga masani uma o le vaevaega e tutusa, o lenei e tutusa tutusa ma `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Lenei gaioiga o le a panic pe a fai o `rhs` o 0.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Fuafuaina le toeititi laititi o `self (mod rhs)`.
        ///
        /// Talu ai, mo fuainumera lelei, o faʻauiga masani uma o le vaevaega e tutusa, o lenei e tutusa tutusa ma `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Lenei gaioiga o le a panic pe a fai o `rhs` o 0.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Faʻafoʻi `true` pe a na o `self == 2^k` mo sina `k`.
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Faʻafoʻi mai le tasi laʻititi ifo i le isi paoa o le lua
        // (Mo le 8u8 o le isi malosiʻaga o le lua o le 8u8 ma le mo le 6u8 o le 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // O lenei metotia e le mafai ona ova, pei o `next_power_of_two` ova mataupu o loʻo iʻu lava ina toe faafoʻi le aofaʻi maualuga o le ituaiga, ma mafai ona faʻafoʻi 0 mo 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SAFETY: Ona o `p > 0`, e le mafai ona aofia atoa ai taʻimua iva.
            // O lona uiga o le sifi e masani ona i totonu o tuaʻoi, ma o nisi gaosi (pei o intel muamua-haswell) e sili atu le aoga o tagata i totonu o le laina pe a fai o le finauga e leai-zero.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Faʻafoʻi mai le laʻititi mana o le lua sili atu pe tutusa i le `self`.
        ///
        /// A oʻo faʻafuaseʻi le tau faʻafuaseʻi (ie, `self > (1 << (N-1))` mo ituaiga `uN`), o le panics i le debug mode ma le return return e afifi i le 0 i le mode tatala (naʻo le tulaga e mafai ai e le auala ona toe faʻafoʻi 0).
        ///
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Toe foi mai i le mana aupito itiiti o le sili atu nai lo le lua po o le tutusa i `n`.
        /// Afai o le isi malosiʻaga o le lua e sili atu nai lo le aofaʻi maualuga aofaʻi, `None` ua toe faʻafoʻi mai, a le o lea o le malosiaga o le lua o loʻo afifiina i le `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Toe foi mai i le mana aupito itiiti o le sili atu nai lo le lua po o le tutusa i `n`.
        /// Afai o le isi malosiʻaga o le lua e sili atu nai lo le aofaʻi maualuga aofaʻi, o le toe faʻafoʻi aoga ua afifi i le `0`.
        ///
        ///
        /// # Examples
        ///
        /// Faʻaaoga faʻavae:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Faʻafoʻi le faʻamanatuga o lenei fuainumera o se byte array i le tele-endian (network) byte oka.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Faʻafoʻi le faʻamanatuga o lenei fuainumera o se byte array i si faʻaiʻuga byte-endian byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Faʻafoʻi le manatua manatuaina o lenei fuainumera o se byte vasega i le faʻatonuga byte.
        ///
        /// A o faʻaaogaina le faʻavae tulaga moni endianness, feaveaʻi tulafono laiti tatau ona faʻaaoga [`to_be_bytes`] poʻo [`to_le_bytes`], pe a talafeagai ai, nai lo.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, pe a fai o le CFG! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } isi {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: Const leo aua o integers o ni datatypes tuai tuai ina ia mafai ai ona tatou masani
        // lafo i latou i faʻavasega o bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SAFETY: fuainumera o faigofie tuai datatypes ina ia mafai ai ona tatou faʻasalalauina i latou i
            // faʻasologa o bytes
            unsafe { mem::transmute(self) }
        }

        /// Faʻafoʻi le manatua manatuaina o lenei fuainumera o se byte vasega i le faʻatonuga byte.
        ///
        ///
        /// [`to_ne_bytes`] tatau ona sili atu i lenei mea pe a mafai.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// tuʻu bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, pe a fai o le CFG! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } isi {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SAFETY: fuainumera o faigofie tuai datatypes ina ia mafai ai ona tatou faʻasalalauina i latou i
            // faʻasologa o bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Fausia se tagatanuʻu endian integer taua mai lona sui o se byte array i le tele endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// faʻaaoga std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * sao=malologa;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Fausia se tagatanuu endeg integer taua mai lona sui o se byte array i siaki laiti.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// faʻaaoga std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * sao=malologa;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Fausia se tagatanuʻu endian integer taua mai lona faʻamanatuga sui o se byte faʻatulagaina i tagatanuu endianness.
        ///
        /// Aʻo faʻaaogaina le faʻavae tulaga moni endianness, feaveaʻi tulafono laiti ono manaʻo e faʻaaoga [`from_be_bytes`] poʻo [`from_le_bytes`], pe a talafeagai ai.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } isi {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// faʻaaoga std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * sao=malologa;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: Const leo aua o integers o ni datatypes tuai tuai ina ia mafai ai ona tatou masani
        // lafo atu ia i latou
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SAFETY: fuainumera o faigofie tuai datatypes ina ia mafai ai ona tatou faʻasalalau atu ia latou
            unsafe { mem::transmute(bytes) }
        }

        /// Fou code tatau ona manaʻo e faʻaaoga
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Faʻafoʻi mai le tau laʻititi e mafai ona faʻatusalia e lenei ituaiga fuainumera.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Fou code tatau ona manaʻo e faʻaaoga
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Faʻafoʻi mai le tau lapoʻa e mafai ona faʻatusalia e lenei ituaiga fuainumera.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}