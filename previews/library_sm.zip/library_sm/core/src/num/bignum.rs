//! Tuʻufaʻatasia le faʻamalieina-saʻo numera (bignum) faʻatinoina.
//!
//! Ua fuafuaina lenei e aloese mai le faʻaputuga vaeluaina ma le tau o le faaputuga manatuaina.
//! O le ituaiga faʻaaogaina e sili ona faʻaaogaina, `Big32x40`, e faʻatapulaʻaina e 32 × 40=1,280 fagota ma o le a faʻaaluina le 160 bytes o faʻamanatuga o faʻaputuga.
//! E sili atu lea nai lo le lapoʻa-o le tuʻuina i lalo o gaioiga uma e mafai ona faʻamutaina `f64`.
//!
//! I mataupu faʻavae e mafai ona i ai le tele o ituaiga bignum mo eseese sao, ae tatou te le faia e aloese ai mai le code bloat.
//!
//! O siaki taʻitasi o loʻo suʻesuʻeina pea mo le faʻaaogaina moni, o lea e le afaina ai.
//!

// Lenei module e mo na o dec2flt ma flt2dec, ma naʻo tagata lautele ona o coretests.
// E le fuafuaina e faʻamautuina.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Galue faʻapitoa manaʻomia e bignums.
pub trait FullOps: Sized {
    /// Faʻafoʻi `(carry', v')` faʻapena `carry' * 2^W + v' = self + other + carry`, lea `W` o le numera o fasi i `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Faʻafoʻi `(carry', v')` faʻapena `carry'*2^W + v' = self* other + carry`, lea `W` o le numera o fasi i `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Faʻafoʻi `(carry', v')` faʻapena `carry'*2^W + v' = self* other + other2 + carry`, lea `W` o le numera o fasi i `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Faʻafoʻi `(quo, rem)` faapena `borrow *2^W + self = quo* other + rem` ma `0 <= rem < other`, lea e `W` o le numera o fasi i `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // E le mafai ona tupu lenei mea;o le galuega faatino o loʻo i le va o `0` ma `2 * 2^nbits - 1`.
                    // FIXME: e LLVM faʻaleleia lenei mea i le ADC pe tutusa?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // E le mafai ona tupu lenei mea;
                    // o le galuega faatino o loʻo i le va o `0` ma `2^nbits * (2^nbits - 1)`.
                    // FIXME: e LLVM faʻaleleia lenei mea i le ADC pe tutusa?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // E le mafai ona tupu lenei mea;
                    // o le galuega faatino o loʻo i le va o `0` ma `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // E le mafai ona tupu lenei mea;o le galuega faatino o loʻo i le va o `0` ma `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Vaʻai RFC #521 mo faʻatagaina lenei.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Lisi o malosiaga o le 5 sui i fuainumera.Faʻapitoa lava, o le sili ona tele {u8, u16, u32} taua o le malosiʻaga o le lima, faʻatasi ai ma le tutusa faʻamatalaga.
/// Faʻaaogaina i le `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Faʻavae-vaevaeina faʻatasi-faʻatulagaina (e oʻo atu i nisi tapulaʻa) numera.
        ///
        /// Lenei e lagolagoina e se laina faʻatulagaina-lapoʻa o tuʻuina atu ("digit") ituaiga.
        /// E ui e le lapoʻa tele le faʻasologa (masani ai selau paita), ae o le kopi faʻataʻitaʻi e ono iʻu ai i le faʻatinoga o galuega.
        ///
        /// Ma o lenei e le o le `Copy`.
        ///
        /// O gaioiga uma e avanoa i bignums panic i le tulaga o le ova.
        /// O le tagata e valaʻau e nafa ma le faʻaaogaina o lapoʻa lava ituaiga bignum.
        pub struct $name {
            /// Tasi faaopoopo le offset i le maualuga "digit" o loʻo faʻaaogaina.
            /// Lenei e le faʻaititia, o lea ia nofouta i le faʻatulagaina poloaʻiga.
            /// `base[size..]` tatau ona leai.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` fai ma sui `a + b *2^W + c* 2^(2W) + ...` le mea `W` o le numera o fasi i le numera ituaiga.
            base: [$ty; $n],
        }

        impl $name {
            /// Faia se bignum mai le tasi numera.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Faia se bignum mai `u64` taua.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Faʻafoʻi mai numera i totonu o se fasi `[a, b, c, ...]` faʻapea o le numera numera o le `a + b *2^W + c* 2^(2W) + ...` o le `W` o le numera o fasi i le numera ituaiga.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Faʻafoʻi mai le 'i`-th bit i le mea 0 e sili ona taua.
            /// I se isi faʻaupuga, o le laʻititi ma le mamafa `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Faʻafoʻi `true` pe a fai o le bignum e leai.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Faʻafoʻi mai le numera o fasi mea talafeagai e fai ma sui o lenei tau.
            /// Manatua o le leai o le a manatu e manaʻomia 0 fagota.
            pub fn bit_length(&self) -> usize {
                // Faapasi i luga numera sili ona taua ia e leai.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // E leai ni numera leai, leai, ole numera e leai.
                    return 0;
                }
                // Lenei mafai ona faʻaleleia faʻapitoa i le leading_zeros() ma siʻi siʻi, ae atonu e le aoga le faʻalavelave.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Faʻaopopo le `other` ia te ia lava ma faʻafoʻi mai lana ia lava faʻavasegaga faʻasino.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Aveese `other` mai ia lava ma faʻafoʻi mai lana ia lava faʻavasegaga faʻasino.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Faʻateleina ia ia lava e le numera-tele `other` ma faʻafoʻi mai lana ia lava faʻavasegaga faʻasino.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Faʻateleina ia lava e le `2^bits` ma faʻafoʻi mai lana ia lava faʻavasegaga faʻasino.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // fesuiaʻi e `digits * digitbits` faagutu
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // fesuiaʻi e `bits` faagutu
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. digit] e leai, leai se mea e sui ai
                }

                self.size = sz;
                self
            }

            /// Faʻateleina ia lava e le `5^e` ma faʻafoʻi mai lana ia lava faʻavasegaga faʻasino.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // E i ai tonu n trailing zeros i luga o le 2 ^ n, ma naʻo le pau lava le numera faʻapitoa e sosoʻo malosiaga o le lua, o lea e fetaui lelei faʻasino upu mo le laulau.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Faʻateleina ma le sili ona tele tasi-numera malosiaga i le umi e mafai ai ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... ona uma lea o totoe.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Faʻateleina ia lava e le numera faʻamatalaina e `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (o le `W` o le numera o fasi i le numera ituaiga) ma faʻafoʻi mai lana ia lava faʻavasega suiga.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // le masani i totonu.sili ona aoga pe a aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Vaeluaina ia ia i le numera-tele `other` ma faʻafoʻi mai lana ia lava fesuiaiga faʻasino *ma* le toega.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Vavaeina oe lava i se isi bignum, ova le `q` ma le mea taua ma le `r` ma le mea o totoe.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Valevale telegese base-2 umi umi vaevaega mai
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME faʻaaoga se sili atu ($ty) faʻavae mo le umi vaevaega.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Seti sina `i` o le q i le 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Le ituaiga numera mo `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// lenei tasi e faʻaaogaina mo naʻo suʻega.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}