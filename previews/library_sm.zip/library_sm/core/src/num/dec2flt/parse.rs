//! Faʻamaonia ma faʻamamaina se numera decimal o le pepa faatumu:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! I se isi faʻaupuga, masani syntax fua-opeopea, ma tuʻusaunoa lua: Leai se faʻailoga, ma leai tagofiaina o "inf" ma "NaN".O nei e faʻatautaia e le avetaavale galuega (super::dec2flt).
//!
//! E ui lava o le amanaʻia o sao talafeagai e faigofie lava, o lenei faiga e tatau foʻi ona teʻena le anoanoaʻi o fesuiaʻiga le talafeagai, aua lava le panic, ma faʻatinoina le tele o siaki e faʻamoemoe i ai isi modules ae le o le panic (pe ova foʻi) i taimi.
//!
//! O le mea e sili ai ona leaga, o mea uma e tutupu i le tasi pasi i luga o le mea na tuʻuina atu.
//! Ia, faʻaeteete a o fesuiaʻi se mea, ma faʻalua-siaki ma isi modules.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// O le manaia vaega o se manoa decimal.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Le decimal exponent, mautinoa ia i lalo ifo o le 18 decimal digit.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Siaki pe a fai o le sao saʻo o se numera opeopea talafeagai ma afai o lea, suʻe le vaega tuʻufaʻatasia, le vaega vaevaeina, ma le faʻailoa i totonu.
/// E le tagofiaina faʻailoga.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Leai ni numera i luma ole 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Matou te manaʻomia ia le itiiti ifo i le tasi le numera muamua pe o le maeʻa o le manatu.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Pusa faʻasolosolo pe a maeʻa vaega
            }
        }
        _ => Invalid, // Pusa mulimuli i le maea o le numera muamua
    }
}

/// Vaelua ese numera numera e oʻo i le muamua numera numera.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Aveese mai fafo ma le siakiina o mea sese.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Pusa mulimuli i tua ina ua maeʻa le faʻamatalaga
    }
    if number.is_empty() {
        return Invalid; // Faʻamatalaga gaogao
    }
    // Ile taimi nei, e mautinoa lava e iai a matou numera numera.Atonu e fai si umi tele ona tuʻu i totonu o le `i64`, ae afai e telē tele, o le mea e faʻaalu ai e mautinoa o le leai poʻo le gataaga.
    // Talu ai o sone taʻitasi i le numera numera e naʻo le fetuʻunaʻi o le faʻataʻitaʻiga e le//-1, i le exp=10 ^ 18 o le sao e tatau ona 17 exabyte (!) o zeros e latalata lava i le faʻamaeʻaina.
    //
    // E leʻo se faʻaoga tonu lea e tatau ona tatou faʻamalieina.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}