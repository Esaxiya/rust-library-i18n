//! Bit fiddling luga lelei IEEE 754 opeopea.O numera leaga e le ma e le manaʻomia ona taulimaina.
//! O numera masani e faʻa opeopea o loʻo iai le faʻailoga o le (frac, exp) faʻapea o le tau e 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) o N o le numera o fasi.
//!
//! Subnormals e fai si eseʻese ma eseʻese, ae o le tutusa mataupu faʻatatau e faʻaaogaina.
//!
//! Ae ui i lea, matou te fai ma sui o latou e pei (sig, k) ma le mea lelei, e pei o le taua o le f *
//! 2 <sup>u</sup> .E le gata i le faia o le "hidden bit" manino, o lenei suia le exponent e le mea e taʻua o le mantissa shift.
//!
//! Tuʻu se isi auala, e masani lava o faʻauʻuga e tusia o le (1) ae o mea ia e tusia o le (2).
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Matou te valaʻau (1) o le **vaevae sui** ma (2) le **tuʻufaʻatasia sui**.
//!
//! Tele gaioiga i lenei module naʻo le vaʻaia numera masani.O le dec2flt masani masani faʻasolosolo uia le lautele-saʻo lemu ala (Algorithm M) mo laiti ma tele tele numera.
//! O lena algorithm manaʻomia na o next_float() o loʻo faʻatautaia subnormals ma zeros.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// O se fesoasoani trait e aloese mai le toe faʻapipiʻiina uma o le liua code mo `f32` ma `f64`.
///
/// Vaʻai le matua module's doc manatu mo le mafuaʻaga e tatau ai lenei.
///
/// Tatau **aua lava** faʻagaioia mo isi ituaiga pe faʻaaogaina i fafo atu o le dec2flt module.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Ituaiga faʻaaogaina e `to_bits` ma `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Faia se masani transmutation i se fuainumera.
    fn to_bits(self) -> Self::Bits;

    /// Faia se transmutation mata mai fuainumera.
    fn from_bits(v: Self::Bits) -> Self;

    /// Faʻafoʻi mai le vaega o loʻo iai le numera lea.
    fn classify(self) -> FpCategory;

    /// Faʻafoʻi mai le mantissa, exponent ma saini o numera.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Faatonutonu le folau
    fn unpack(self) -> Unpacked;

    /// Casts mai se laititi numera e mafai ona avea ma sui tonu.
    /// Panic pe a fai o le fuainumera le mafai ona faʻatusalia, o le isi numera i lenei module mautinoa ia aua neʻi tuʻuina na tupu.
    fn from_int(x: u64) -> Self;

    /// Maua le tau 10 <sup>e</sup> mai se laulau muamua-faitauga.
    /// Panics mo `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Le tala a le igoa.
    /// E faigofie atu i le faigata code nai lo juggling intrinsics ma faʻamoemoe LLVM masani gaugau ia.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // O se conservative fusia i luga o le numera numera o mea faʻaulufaleina e le mafai ona gaosia le ova pe ova poʻo
    /// subnormals.Masalo o le decimal exponent o le maualuga masani tau, o lea le igoa.
    const MAX_NORMAL_DIGITS: usize;

    /// Afai o le numera numera sili ona taua ei ai le taua taua nofoaga nai lo lenei, o le numera e mautinoa liʻo i le iʻuga.
    ///
    const INF_CUTOFF: i64;

    /// A faʻapea o le numera numera sili ona taua e i ai le taua o le nofoaga nai lo lenei, o le numera e mautinoa le faʻataʻamilomilo i le zero.
    ///
    const ZERO_CUTOFF: i64;

    /// O le numera o fasi i le faʻalauiloa.
    const EXP_BITS: u8;

    /// O le aofaʻi o fasi i totonu o le hatafa, * e aofia ai ma le mea natia.
    const SIG_BITS: u8;

    /// Le aofai o faagutu i le hatafa,*le aofia ai* le nana natia.
    const EXPLICIT_SIG_BITS: u8;

    /// Le maualuga faʻatulafonoina sui i vaevaega sui.
    const MAX_EXP: i16;

    /// Le maualalo tulafono faʻalauteleina i vaevaega sui, le aofia ai subnormals.
    const MIN_EXP: i16;

    /// `MAX_EXP` mo sui tuʻufaʻatasia, ie, ma le sifi faʻaaogaina.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` faʻailoga (ie, ma le faʻapalepale faʻapalepale)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` mo sui tuʻufaʻatasia, ie, ma le sifi faʻaaogaina.
    const MIN_EXP_INT: i16;

    /// Le maualuga faʻatulagaina taua i le tuʻufaʻatasia o sui.
    const MAX_SIG: u64;

    /// Le laʻititi faʻatulagaina aloaʻia i le tuʻufaʻatasia o sui.
    const MIN_SIG: u64;
}

// Tele o se fofo mo #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Faʻafoʻi mai le mantissa, exponent ma saini o numera.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Faʻataʻitaʻiga faʻasolitulafono + mantissa suiga
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe e le o mautinoa pe o `as` faʻataʻamilomilo saʻo luga uma tulaga.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Faʻafoʻi mai le mantissa, exponent ma saini o numera.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Faʻataʻitaʻiga faʻasolitulafono + mantissa suiga
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe e le o mautinoa pe o `as` faʻataʻamilomilo saʻo luga uma tulaga.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Faʻaliliua se `Fp` i le ituaiga masini opeopea latalata.
/// E le faʻatautaia ia faʻaiuga masani.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f o 64 sina, o lea la ua i ai le suia suia mantissa o le 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Faʻataʻamilomilo le 64-bit significanceand i le T::SIG_BITS fasimea ma le afa-ia-tutusa.
/// E le tagofiaina exponent lofituina.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Fetuutuunai sifi mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Faʻafeagai o le `RawFloat::unpack()` mo numera masani.
/// Panics pe a fai e le aoga le numera poʻo le faʻamatala mo numera masani.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Aveese le mea natia
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Fetuunai le faʻalauiloa mo le faʻaaliga faʻaituau ma le suia o le mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Tuʻu le saini i le 0 ("+"), e lelei uma a matou numera
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Fausia se subnormal.O le mantissa o le 0 ua faʻatagaina ma fausiaina leai.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // O le faʻailo o le 0, o le saini saʻo o le 0, o lea e tau na ona tatou toe faʻamatalaina mea.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Fuafua se faʻailoga i se Fp.Faʻataʻamilo i totonu ole 0.5 ULP ma le afa-ia-tutusa.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Na matou tipiina uma mea i luma o le faʻasino `start`, o lona uiga, matou te agaʻi-saʻo i le aofaʻi o le `start`, o le mea foʻi lea o le faʻamatalaga tatou te manaʻomia.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Round (half-to-even) faʻamoemoe i luga o le truncated fasi.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Na te mauaina le numera pito lauolaola pito tele lava laʻititi atu nai lo le finauga.
/// E le faʻatautaia subnormals, zero, poʻo exponent underflow.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Saili le numera laʻititi numera opeopea matua lapoʻa nai lo le finauga.
// O lenei faʻagaioiga e faʻatumuina, ie, next_float(inf) ==inf.
// E le pei o le tele o tulafono laiti i lenei vaega, o lenei gaioiga na te tagoina i luga, subnormals, ma infinities.
// Peitai, pei o isi tulafono uma iinei, e le feagai ma NaN ma numera le lelei.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // E foliga mai e lelei tele lea mea, ae e aoga.
        // 0.0 ua faʻailogaina o le atoa-zero upu.Subnormals e 0x000m ... m le mea o le mantissa.
        // Ae maise lava, o le laʻititi laititi masani o le 0x0 ... 01 ma o le sili ona tele o le 0x000F ... F.
        // O le numera masani laʻititi o le 0x0010 ... 0, o lea la e aoga foi lenei mataupu tulimanu.
        // Afai o le faʻaopoopoga ova ova i le mantissa, o le feaveaʻi faʻaopoopoina le tagata faʻamatala e pei ona tatou manaʻo ai, ma o le mantissa fasi avea ma 'auli.
        // Ona o le nanaina laititi tauaofiaga, o lenei foi o le mea tonu tatou te mananaʻo ai!
        // I le iuga, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}