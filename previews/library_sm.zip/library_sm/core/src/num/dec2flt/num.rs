//! Faʻaaoga aoga mo bignums e le tele se uiga e liliu ai i metotia.

// FIXME O lenei igoa o le igoa e fai sina faʻaletonu, talu ai o isi modules faʻaulufale mai foi `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Suʻesuʻe pe o le tipiina o mea uma e sili atu le taua nai lo le `ones_place` e faʻalauiloaina ai se mea sese e laʻititi ifo, tutusa, pe sili atu foi ile 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Afai o mea totoe o loʻo leai ni, o le= 0.5 ULP, a le o lea> 0.5 Afai e le o toe i ai ni fasi (afa_bit==0), o loʻo i lalo foi e toe faʻafoʻi tutusa.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Faʻaliliua se ASCII manoa e naʻo numera numera i le `u64`.
///
/// E le faia ni siaki mo le lolovaia pe le faʻamaonia mataitusi, o lea afai e le faʻaeteete le tagata telefoni, o le iʻuga e leaga ma mafai panic (e ui o le a le o le `unsafe`).
/// E le gata i lea, o manoa gaogao e togafitia o le leai.
/// O lenei gaioiga e i ai aua
///
/// 1. faʻaaogaina `FromStr` luga `&[u8]` manaʻomia `from_utf8_unchecked`, lea e leaga, ma
/// 2. o le tuʻufaʻatasia o iʻuga o le `integral.parse()` ma le `fractional.parse()` e sili atu ona faigata nai lo lenei galuega atoa.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Faʻaliliuina se manoa o numera ASCII i totonu o se faʻailoga.
///
/// Pei ole `from_str_unchecked`, ole faʻamoemoe lea e faʻamoemoe ile parser e vele ese le numera.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Tatala se bignum i totonu o le 64 bit integer.Panics pe a fai o le numera e telē tele.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Aveese se tele o fasi.

/// O le faʻasino Upu 0 e sili ona taua ma o le vaega e afa lona avanoa e pei ona masani ai.
/// Panics pe a fai atu e aveese sili atu fasi nai lo ofi i totonu o le ituaiga faʻafoʻi.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}