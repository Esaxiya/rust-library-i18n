//! Le eseese algorithms mai le pepa.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Aofaʻiga o faʻailoga taua i le Fp
const P: u32 = 64;

// E na ona matou teuina o le sili faʻatusatusaga mo *uma* faʻalauiloa, o lea o le fesuiaʻiga "h" ma tulaga fesoʻotaʻi mafai ona aveʻesea.
// Lenei fefaʻatauaiga faʻatinoga mo le ulugaliʻi kilobytes o le avanoa.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// I le tele o tusiata fale, o vaega opeopea faʻagaioiga e i ai se tulaga manino laʻititi, o le mea lea o le faʻatulagaina o le fuafuaina e fuafuaina i luga o le taʻi-faʻavae tulaga.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// I le x86, o le x87 FPU e faʻaaoga mo float faʻagaioiga pe a fai o le SSE/SSE2 faʻaopoopoga e le maua.
// O le x87 FPU e faʻagaioia ma le 80 fasimea o le saʻo e ala i le le masani ai, o lona uiga o gaioiga o le a faʻataʻamilomilo i le 80 fasi mafua ai le faʻataʻamilo taʻitasi e tupu pe a fai o le mulimuli ane avea ma sui.
//
// 32/64 tau opeopea taua.Ina ia foia lenei, le FPU pulea upu mafai ona setiina ina ia faia computations faia i le manaʻomia tonu.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// O se fausaga na faʻaaoga e faʻasao ai le uluaʻi taua o le FPU faʻatonutonu upu, ina ia mafai ona toe faʻaleleia pe a paʻu le fausaga.
    ///
    ///
    /// O le x87 FPU o le 16-bits resitara o ona fanua e faʻapea:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// O loʻo avanoa faʻamaumauga mo uma uma fanua ile IA-32 Architectures Software Developer's Manual (Volume 1).
    ///
    /// Pau lava le fanua e talafeagai mo le numera lea o le PC, Precision Control.
    /// Lenei fanua fuafuaina le tonu o le gaioiga faia e le FPU.
    /// E mafai ona seti i le:
    ///  - 0b00, tasi le faʻatauaina ie, 32-fagota
    ///  - 0b10, faʻalua faʻatulagaina ie, 64-fasi
    ///  - 0b11, faʻalua faʻalauteleina le faʻatulagaina ie, 80-fagota (setete tulaga) O le 0b01 aoga ua faʻasaoina ma e le tatau ona faʻaaogaina.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SAFETY: o le `fldcw` faʻatonuga ua uma ona suʻesuʻeina ina ia mafai ona galue saʻo ma
        // soʻo se `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: O loʻo matou faʻaaogaina le ATT syntax e lagolago ai LLVM 8 ma le LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Faʻatulagaina le tulaga saʻo o le FPU i le `T` ma faʻafoʻi mai le `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Fuafua le tau mo le Precision Control fanua e talafeagai mo `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 fasi
            8 => 0x0200, // 64 fasi
            _ => 0x0300, // faaletonu, 80 fasi
        };

        // Maua le aoga muamua o le faʻatonutonu upu e toe faʻaleleia mulimuli ane, pe a o le `FPUControlWord` fausaga ua pa'ū SAFETY: o le `fnstcw` faʻatonuga ua suʻesuʻeina ina ia mafai ona galue saʻo ma soʻo se `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: O loʻo matou faʻaaogaina le ATT syntax e lagolago ai LLVM 8 ma le LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Seti le faʻatonutonu upu i le manaʻomia saʻo.
        // E maua lea i le faʻamamaina o le mea saʻo tuai (fasimea 8 ma le 9, 0x300) ma suia i le fuʻa saʻo na tuʻuina i luga.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// O le vave auala o Bellerophon faʻaaogaina masini-tele fuainumera ma opeopea.
///
/// O lenei e toʻesea mai i se isi gaioiga ina ia mafai ona faʻataʻitaʻia i luma o le fausiaina o se bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Matou te faʻatusatusa le tau saʻo ile MAX_SIG latalata ile iʻuga, ua naʻo se vave, taugofie le teʻena (ma faʻasaʻolotoina foi le toega o le tulafono mai le popole i lalo o lalo).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // O le ala saoasaoa faalagolago i luga o le numera o loʻo faʻataʻamilomilo i le saʻo numera o fasi e aunoa ma se faʻatulagaina faʻatulagaina.
    // I le x86 (e aunoa ma le SSE poʻo le SSE2) o lenei mea e manaʻomia ai le sao o le x87 FPU faʻaputuga e suia ina ia faʻasolosolo ona taʻamilo i le 64/32 sina.
    // O le `set_precision` function e vaʻai lelei i le faʻatulagaina o le tulaga saʻo i luga o tusiata fale e manaʻomia ai le setiina e ala i le suia o le tulaga o le lalolagi (pei o le control word o le x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // O le mataupu e <0 e le mafai ona gaugau i le isi branch.
    // O malosiaga leaga e iʻu ai i le toe faia o vaega ninii o le binary, ia e faʻataʻamilomiloina, ma mafua ai mea moni (ma e fai lava si taua!) Mea sese i le iʻuga mulimuli.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// O le Algorithm Bellerophon e le taua tele le faʻamaoni e le le taua fuainumera numera.
///
/// E faʻataʻamilomilo le `` f '' i se opeopea ma le 64 bit signifikan ma faʻateleina e le latalata sili atu o le `10^e` (i le faʻataʻitaʻiga tonu lava o le faʻatulagaina).Lenei e masani lava ona lava e maua ai le saʻo faʻaiuga.
/// Ae peitaʻi, a o le taunuʻuga e latalata i le afa i le va o le lua felataʻi (ordinary) opeopea, o le lotoa lapisi faʻasolosolo mai le faʻateleina lua latalata o lona uiga o le iʻuga ono toʻesea e ni nai fasi.
/// A tupu lenei mea, o le faʻasolosolo Algorithm R faʻaleleia mea i luga.
///
/// O le lima-galu "close to halfway" e faia tonu i le numera numera i le pepa.
/// I upu a Clinger:
///
/// > Slop, faʻamatalaina i iunite o le laʻititi taua tele, o se aofia ai noataga mo le mea sese
/// > faʻaputuputu i le taimi o le fuafaʻatatau togi fuafuaina o le latalata i le f * 10 ^ e.(Slop o
/// > e le o se noatia mo le mea sese saʻo, ae e faʻatapulaʻa le eseʻesega i le va o le latalata i le z ma le
/// > le faʻatatauga sili ona lelei e faʻaaogaina ai p pits o significanceand.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // O mataupu abs(e) <log5(2^N) e i fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // E lava le telē o le faʻaseʻe e fai ai se eseʻesega pe a faʻataʻamilomilo i n fasi?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// O se algorithm faʻasolosolo e faʻaleleia atili ai se faʻatulagaina o le `f * 10^e`.
///
/// Taitasi iteration maua tasi iunite i le mulimuli nofoaga latalata, o le mea moni o le mea moni umi sili ona umi e liliu pe a fai o `z0` e oʻo lava i le agamalu.
/// O le mea e laki ai, pe a faʻaaogaina o le fallback mo Bellerophon, o le amata faʻatusatusaga ua toʻesea e le sili atu tasi ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Suʻesuʻe lelei fuainumera `x`, `y` faʻapea o le `x / y` o le `(f *10^e) / (m* 2^k)` tonu.
        // E le gata i le aloese mai le feagai ma faʻailoga o `e` ma `k`, matou te faʻateʻaina foʻi le paoa o le lua masani ile `10^e` ma le `2^k` e faʻatele ai numera.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Lenei ua tusia a si faʻaletonu ona o tatou bignums le lagolagoina le le lelei numera, o lea tatou faʻaaogaina ai le matua taua + saini faʻamatalaga.
        // O le faʻateleina ma m_digits e le mafai ona oʻo atu.
        // Afai e lava le lapoʻa ole `x` poʻo le `y` e manaʻomia ai ona tatou popole e uiga i le ova, ona faʻapea foi lea ona lapoʻa ua faʻaititia e le `make_ratio` le vaega i le mea o le 2 ^ 64 pe sili atu.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Aua neʻi manaʻomia x toe, sefe clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // E manaʻomia pea oe, fai sau kopi.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Tuuina `x = f` ma `y = m` i le `f` o loʻo fai ma sui numera decimal e pei ona masani ai ma `m` o le faʻatauaina o se opeopea manatu, faʻatulaga le `x / y` tutusa ma `(f *10^e) / (m* 2^k)`, ono faʻaititia e se malosiaga o lua uma e tutusa.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, seʻi vagana ua tatou faʻaititia le vaega i le malosi e lua.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Lenei e le mafai ona ova ona e manaʻomia le lelei `e` ma le leaga `k`, lea e naʻo mea e tupu mo mea taua latalata i le 1, o lona uiga o le `e` ma le `k` o le a faʻatusatusa laʻititi.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k O lenei e le mafai ona oʻo atu foi, vaʻai i luga.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), toe faʻaititia e le mana masani o le lua.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Faʻataʻitaʻiga, Algorithm M o le sili faigofie auala e faʻaliliu ai le decimal i le opeopea.
///
/// Matou te faia se fuataga e tutusa ma `f * 10^e`, ona togiina lea o le malosiʻaga o le lua seʻia oʻo ina avatua se float aoga taua.
/// O le binary exponent `k` o le numera o taimi na tatou faʻateleina ai le numera poʻo le denominator e le lua, o lona uiga, i taimi uma `f *10^e` tutusa ma `(u / v)* 2^k`.
/// A maua loa le taua, e tatau ona matou faʻataʻamilomilo e ala i le asiasia o totoe o le vaevaega, lea e faia i galuega fesoasoani i lalo atu.
///
///
/// O lenei algorithm e telegese lemu, e oʻo lava i le faʻamalamalamaga ua faʻamatalaina i le `quick_start()`.
/// Peitai, o le sili faigofie o algorithms e fetuʻunaʻi mo ova, lalo, ma subnormal iʻuga.
/// O lenei faʻatinoga e avea pe a fai o le Bellerophon ma le Algorithm R ua lofituina.
/// E faigofie le sailia o lalo ma lofia: O le fua faʻatusatusa e leʻo se totonu-telefaʻatutu, ae o le minimum/maximum exponent ua taunuʻu.
/// I le tulaga o le lolovaia, tatou na toe foʻi le iʻu.
///
/// Taulimaina lalo ma subnormals e trickier.
/// Tasi le tele faʻafitauli o le, ma le maualalo exponent, o le fua faʻatusatusa atonu o le a tele naua mo se signifikan.
/// Vaʻai underflow() mo auiliiliga.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME mafai faʻalelei: faʻatele ia big_to_fp ina ia mafai ona matou faia le tutusa o fp_to_float(big_to_fp(u)) iinei, naʻo le aunoa ma le faʻaluaina faʻataʻamilo.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // E tatau ona tatou tutu i le maualalo exponent, pe a tatou faʻatali seʻia `k < T::MIN_EXP_INT`, ona tatou o ese ai lea i le vaega o le lua.
            // Ae paga lea o lona uiga e tatau ona tatou faʻapitoa-numera masani numera ma le aupito maualalo exponent.
            // FIXME saili se sili atu matagofie foliga faʻavae, ae faʻatautaia le `tiny-pow10` suʻega ia mautinoa ai e moni saʻo!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Faaseʻe i luga ole tele ole Algorithm M faʻasolosolo ile siakiina ole la umi.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // O le umi umi o se faʻatusatusaga o le faʻavae lua logarithm, ma log(u / v) = log(u), log(v).
    // O le tala faʻatatau e toʻesea e le tele o le 1, ae o taimi uma o se tala faʻatatau i lalo, o lona uiga la o le mea sese i le log(u) ma le log(v) e tutusa a latou faʻailoga ma faʻaleaogaina (peʻa tetele uma).
    // O le mea lea o le mea sese mo log(u / v) o le sili atu tasi foi.
    // O le fua faʻatatau o le tasi mea u/v o loʻo i totonu o le-lautele hata.Ma o le matou faʻamutaina tuutuuga o log2(u / v) o le taua o mea, plus/minus tasi.
    // FIXME O le vaʻai i le vaega lona lua e mafai ona faʻaleleia ai le tala faʻatatau ma aloese mai nisi fevaevaeaʻiga.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Lalo i lalo poʻo subnormalTuʻu ile galuega autu.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // LafoaʻiTuʻu ile galuega autu.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Fua faʻatusatusa e le o se i totonu o laina faʻatulagaina ma le aupito maualalo exponent, o lea tatou manaʻomia ai ona faʻataʻamilomilo sili atu fasi ma fetuʻunaʻi le exponent talafeagai.
    // O le tau moni nei ua pei o lenei:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    tamaʻi tusi (sui e rem)
    //
    // O le mea lea, pe a fai o le lapotopoto-ese fasi e!= 0.5 ULP, latou te filifiliina le taʻamiloina ia latou lava.
    // A latou tutusa ma le toe o le leai-zero, o le tau aoga pea manaʻomia e faʻataʻamilomilo i luga.
    // Seʻi vagana ua lapoʻa ese 'aʻai o 1/2 ma o le mea o totoe e leai, tatou maua le afa-to-e tusa tulaga.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Masani faataamilo-i-e oo lava, obfuscated e ala i le faataamilo faavae i luga o le toe vaega o le vaevaega.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}