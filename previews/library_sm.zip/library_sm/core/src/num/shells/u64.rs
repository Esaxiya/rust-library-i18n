//! Tumau mo le 64-bit unsigned integer type.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! O le code fou e tatau ona faʻaaoga saʻo le fesoʻotaʻiga saʻo i luga o le ituaiga anamua.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }