//! Tumau mo le 16-bit unsigned integer type.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! O le code fou e tatau ona faʻaaoga saʻo le fesoʻotaʻiga saʻo i luga o le ituaiga anamua.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }