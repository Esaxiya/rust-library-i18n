//! Tumau mo le 8-bit sainia integer ituaiga.
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! O le code fou e tatau ona faʻaaoga saʻo le fesoʻotaʻiga saʻo i luga o le ituaiga anamua.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }