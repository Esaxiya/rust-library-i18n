//! Tumau mo le 32-bit sainia integer ituaiga.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! O le code fou e tatau ona faʻaaoga saʻo le fesoʻotaʻiga saʻo i luga o le ituaiga anamua.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }