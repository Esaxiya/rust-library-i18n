//! Faʻailogaina le taua-togi taua i vaega taʻitasi ma vaega sese.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Faʻaleaogaina le faʻailogaina faʻamutaina taua, e pei o le:
///
/// - O le uluaʻi aoga e tutusa ma `mant * 2^exp`.
///
/// - Soʻo se numera mai le `(mant - minus)*2^exp` i le `(mant + plus)* 2^exp` o le a faʻataʻamilomilo i le uluaʻi tau.
/// E naʻo le `inclusive` o le `true` e aofia ai.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Le mantissa fuaina.
    pub mant: u64,
    /// O le maualalo maualalo tulaga.
    pub minus: u64,
    /// O le pito i luga sese.
    pub plus: u64,
    /// Le fefaʻasoaaʻi faʻamatalaga i le tulaga 2.
    pub exp: i16,
    /// Moni pe a fai o le mea sese aofia ai.
    ///
    /// I le IEEE 754, e moni lenei mea pe a oʻo ile amataga ole mantissa.
    pub inclusive: bool,
}

/// Faʻaleaogaina le aoga.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, a le o le lelei pe leaga.
    Infinite,
    /// Leai, pe lelei pe le lelei.
    Zero,
    /// Faʻauʻu numera ma isi faʻavasegaga fanua.
    Finite(Decoded),
}

/// O se ituaiga opeopea ituaiga e mafai ona avea ma 'decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// O le tau maualalo masani faʻatulagaina.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Faʻafoʻi mai se faʻailoga (moni pe a le lelei) ma le `FullDecoded` aoga mai le faʻailoga numera opeopea.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // tuaoi: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode i taimi uma faʻasaoina le exponent, o lea o le mantissa e faʻateleina mo subnormals.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // tuaoi: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // o fea maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // tuaoi: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}