//! Toeititi tuʻusaʻo (ae faʻalelei teisi atu) Rust faʻaliliuga o le Ata 3 o le "Lolomiina Nofoaga Faʻafuʻa-Nofo Vave ma Saʻo" [^ 1].
//!
//!
//! [^1]: Burger, RG ma Dybvig, RK 1996. Lolomiina numera fua-opeopea
//!   vave ma sao.SIGPLAN Leai.31, 5 (Me. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// fuafua faʻatulagaina o `Digit`s mo le 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// naʻo le aoga pe a `x < 16 * scale`;`scaleN` tatau ona `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Le faʻapuʻupuʻu auala faʻatinoina mo Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // o le numera `v` e faʻatulaga e lauiloa o:
    // - tutusa i le `mant * 2^exp`;
    // - muamua i le `(mant - 2 *minus)* 2^exp` i le ituaiga faʻavae;ma
    // - sosoʻo ai ma le `(mant + 2 *plus)* 2^exp` i le ituaiga muamua.
    //
    // e manino lava, `minus` ma `plus` le mafai ona zero.(mo infinities, matou te faʻaaogaina le taua i fafo atu o tulaga.) matou te manatu foʻi a itiiti mai e tasi le fuainumera ua fausiaina, faʻapea, `mant` e le mafai foi ona leai.
    //
    // o lona uiga foi o soʻo se numera i le va `low = (mant - minus)*2^exp` ma `high = (mant + plus)* 2^exp` o le a faʻafanua i lenei tonu opeopea fuainumera numera, ma tuaoi aofia ai pe a o le uluaʻi mantissa sa (ie, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` o le `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // fuafua `k_0` mai uluaʻi faʻaulu mai faʻamalieina `10^(k_0-1) < high <= 10^(k_0+1)`.
    // le fusi fufusi `k` faʻamalieina `10^(k-1) < high <= 10^k` ua fuafuaina mulimuli ane.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // liliu `{mant, plus, minus} * 2^exp` i le vaevaega fomu ina ia:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // vaevae le `mant` ile `10^k`.nei `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // toe faʻaleleia pe a `mant + plus > scale` (poʻo `>=`).
    // matou te leʻo faʻaleleia le `scale`, talu ai e mafai ona matou faʻamamāina le amataga faʻatele.
    // nei `scale < mant + plus <= scale * 10` ma ua matou sauni e gaosia numera.
    //
    // ia maitau ole `d[0]`*mafai* ona leai, peʻa `scale - plus < mant < scale`.
    // i lenei tulaga faʻataʻamilo-luga tulaga (`up` lalo) o le a faʻaosoina vave.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // tutusa ma scaling `scale` ile 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` mo le augatupulaga numera.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants, lea `d[0..n-1]` o numera fausiaina mamao:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (lea `mant / scale < 10`) o le `d[i..j]` o se faʻapuʻupuʻu mo le 'd [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // faatupuina se tasi numera: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // o se faigofie faigofie faʻamatalaga lenei o le toe fesuiaʻi Dragon algorithm.
        // tele derivations vailauga ma finauga atoatoa ua lē mo le faafaigofieina.
        //
        // amata i sui faʻafetaui invariants, e pei ona tatou faʻafouina `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // manatu o `d[0..n-1]` o le sili ona puʻupu sui i le va o le `low` ma le `high`, ie, `d[0..n-1]` faʻamalieina uma nei ae o `d[0..n-2]` e le:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: numera faʻataʻamilomilo i le `v`);ma
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (o le numera mulimuli e saʻo)
        //
        // o le lona lua tulaga faʻafaigofieina i `2 * mant <= scale`.
        // foia invariants i le tulaga o `mant`, `low` ma `high` maua ai se sili faigofie faʻamatalaga o le muamua tulaga: `-plus < mant < minus`.
        // talu mai `-plus < 0 <= mant`, ua ia i tatou le sao sili ona puʻupuʻu sui pe a `mant < minus` ma `2 * mant <= scale`.
        // (o le muamua avea `mant <= minus` pe a fai o le muamua mantissa e tutusa.)
        //
        // a o le lona lua e le taofia (`2 * mant> fua`), tatou manaʻomia e faʻateleina le numera mulimuli.
        // ua lava lea mo le toefuataiina o lena tulaga: ua uma ona tatou iloa o le numera augatupulaga faamaonia `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // i le tulaga lenei, o le tulaga muamua avea `-plus < mant - scale < minus`.
        // talu mai `mant < scale` ina ua maeʻa le augatupulaga, ua i ai tatou `scale < mant + plus`.
        // (toe, o lenei avea `scale <= mant + plus` pe a fai o le muamua mantissa e tutusa.)
        //
        // i se faapuupuuga:
        // - taofi ma faʻataʻamilomilo `down` (taofi numera e pei o) a `mant < minus` (poʻo `<=`).
        // - taofi ma faʻataʻamilomilo `up` (faʻaopopo le numera mulimuli) pe a `scale < mant + plus` (pe `<=`).
        // - fai pea le faʻavae.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // e i ai le tatou puʻupuʻu sui, alu i le taʻamilosaga

        // toefuatai le au faʻaletonu.
        // o le mea lea e faʻamuta ai le algorithm i taimi uma: `minus` ma `plus` e faʻateleina i taimi uma, ae o `mant` e faʻapipiʻiina modulo `scale` ma `scale` e faʻamauina.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // o le faʻataʻamilomiloina e tupu pe a o i) naʻo le tuʻufaʻatasiga o tulaga na faʻaosoina, pe ii) o tulaga uma e lua na amataina ma fusifusia gagau e manaʻo faʻataʻamilo i luga.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // afai o le faʻataʻamilomiloina e suia ai le umi, e tatau foi ona sui le tagata faʻamatala.
        // e foliga mai o lenei tulaga e faigata tele ona faʻamalieina (ono le mafai), ae o loʻo tatou saogalemu ma tumau iinei.
        //
        // SAFETY: na matou amataina lena manatua luga.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SAFETY: na matou amataina lena manatua luga.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Le faʻatonuina ma le faʻatulagaina faiga faʻatinoina mo Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // fuafua `k_0` mai uluaʻi faʻaulu mai faʻamalieina `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // vaevae le `mant` ile `10^k`.nei `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // toe faʻaleleia pe a `mant + plus >= scale`, lea `plus / scale = 10^-buf.len() / 2`.
    // ina ia mafai ona taofia le faʻamautuina-tele bignum, matou te faʻaaogaina moni `mant + floor(plus) >= scale`.
    // matou te leʻo faʻaleleia le `scale`, talu ai e mafai ona matou faʻamamāina le amataga faʻatele.
    // toe ma le puʻupuʻu algorithm, `d[0]` mafai ona leai ae o le a mulimuli ane faʻataʻamilomilo i luga.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // tutusa ma scaling `scale` ile 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // afai o loʻo matou galulue ma le tapulaʻa mulimuli-numera, tatou manaʻomia faʻapuʻupuʻu le buffer i luma o le moni tuuina atu ina ia aloese mai faʻaluaina taʻamilosaga.
    //
    // matau e tatau ona tatou toe faʻalauteleina le faʻamau pe a faʻataʻamilomilo luga tupu!
    let mut len = if k < limit {
        // oi, e le mafai ona tatou gaosia se fuainumera e tasi.
        // E mafaia lenei mea pe a fai mai, o loʻo ia i tatou se mea pei ole 9.5 ma ua faʻasolosolo ile 10.
        // matou toe faʻafoʻi mai se apa avanoa, seʻi vagana ai le tulaga faʻataʻamilo mulimuli ane lea e tupu pe a `k == limit` ma e tatau ona maua tonu tasi le numera.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` mo le augatupulaga numera.
        // (o lenei e mafai ona taugata, o lea aua le fuafuaina latou pe a fai o le faʻamau e leai se mea.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // o fuainumera mulimuli uma zeroes, tatou taofi iinei aua *aua* taumafai e faʻataʻamilomilo!ae, faʻatumu numera o totoe.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SAFETY: na matou amataina lena manatua luga.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // Faʻataʻamilo pe a matou taofi i le ogatotonu o numera pe a fai o numera nei e saʻo ma le 5000 ..., siaki le numera muamua ma taumafai e faʻataʻamilomilo ia (faʻapea, aloese mai le faʻasolosolo a o tutusa le numera muamua).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SAFETY: `buf[len-1]` ua amataina.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // afai o le faʻataʻamilomiloina e suia ai le umi, e tatau foi ona sui le tagata faʻamatala.
        // ae ua talosagaina matou i se numera faʻatulagaina o numera, ia aua le suia le buffer ...
        // SAFETY: na matou amataina lena manatua luga.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // Seʻi vagana ua talosagaina matou i le mea saʻo.
            // e tatau foi ona tatou siaki, pe a fai o le muamua faʻamau na gaogao, o le faʻaopopo numera mafai faʻatoa mafai ona faʻaopopo pe a `k == limit` (edge tulaga).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SAFETY: na matou amataina lena manatua luga.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}