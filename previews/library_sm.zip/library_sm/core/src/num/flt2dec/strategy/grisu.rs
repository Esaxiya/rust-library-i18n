//! faamatalaina Rust fetuutuunai o le algorithm Grisu3 i le "Numera Point-opeopea Lomia Vave ma saʻo le ma Integers" [^ 1].
//! E faʻaaoga e uiga ile 1KB o faʻataʻitaʻiga muamua, ma i le isi itu, e vave tele mo le tele o sao.
//!
//! [^1]: Florian Loitsch.2010. Lolomiina fua-fua numera numera vave ma
//!   saʻo i fuainumera.SIGPLAN Leai.45, 6 (Iuni 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// vaʻai i le faʻamatalaga i le `format_shortest_opt` mo le mafuaaga tatau.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;u=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, u, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Tuuina `x > 0`, toe faafoi `(k, 10^k)` faapena `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Le faʻapuʻupuʻu auala faʻatinoina mo Grisu.
///
/// E toe faafoʻi `None` pe a toe faʻafoʻi mai se faʻamatalaga e leai se aoga i se isi tulaga.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // tatou manaʻomia le le itiiti ifo i le tolu fasimea o faʻaopoopoina saʻo

    // amata i le faʻatulagaina taua ma le fefaʻasoaaʻi exponent
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // saili soʻo se `cached = 10^minusk` e pei o lena `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // talu ona masani `plus`, o lona uiga o le `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // tuuina atu a tatou filifiliga o `ALPHA` ma `GAMMA`, o lenei tuu `plus * cached` i le `[4, 2^32)`.
    //
    // e mautinoa lava e manaʻomia e faʻateleina le `GAMMA - ALPHA`, ina ia tatou le manaʻomia le tele o le malosiʻaga o le cache o le 10, ae e iai lava iloiloga:
    //
    //
    // 1. matou te mananaʻo e tuʻu pea le `floor(plus * cached)` i totonu ole `u32` talu ai e manaʻomia se fevaevaeaʻiga taugata.
    //    (e le mafai ona 'alofia, o mea e totoe e manaʻomia mo le fua faʻatatau.)
    // 2.
    // o le toega o le `floor(plus * cached)` faʻateleina faʻateleina e le 10, ma e le tatau ona ova.
    //
    // o le muamua avatu ia `64 + GAMMA <= 32`, a o le lona lua e avatua le `10 * 2^-ALPHA <= 2^64`;
    // -60 ma -32 o le maualuga laina i lenei faʻatapulaʻaina, ma V8 faʻaaogaina foi latou.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // fua fps.ole mea lea e maua ai le sese tele ole 1 ulp (faʻamaonia mai le Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-laina saʻo o le toʻese
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // i luga atu o le `minus`, `v` ma le `plus` e faʻatulagaina * faʻatusatusaina (sese <1 ulp).
    // talu ai matou te le iloa le mea sese e lelei pe le lelei foi, matou te faʻaaogaina ni auala faʻataʻitaʻi e lua ma maua ai le sese sili ona maualuga o le 2 ulps.
    //
    // o le "unsafe region" o se taimi tuʻu fua na tatou muaʻi faia.
    // le "safe region" o se vaitau faʻaleoleo lea matou te taliaina.
    // matou amata i le saʻo repr i totonu o le saogalemu itulagi, ma taumafai e saili le latalata repr i `v` o loʻo i totonu foi o le saogalemu itulagi.
    // afai tatou te le mafaia, ua tatou fiu.
    //
    let plus1 = plus.f + 1;
    // tuʻu plus0 = plus.f, 1;//naʻo mo faʻamatalaga tuʻu le minus0 = minus.f + 1;//naʻo le faʻamatalaga
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // fefaʻasoaaʻi

    // vaevae le `plus1` i vaega tuʻufaʻatasia ma vaevaeina.
    // tuʻufaʻatasia vaega e mautinoa e ofi i le u32, talu ai o le mana faʻaaogaina mautinoa `plus < 2^32` ma masani `plus.f` e masani ona laʻititi ifo nai lo `2^64 - 2^4` ona o le saʻo manaʻoga.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // fuafua le sili ona tele `10^max_kappa` leai se sili atu `plus1` (faʻapea `plus1 < 10^(max_kappa+1)`).
    // o le pito i luga tapunia o `kappa` lalo.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Theorem 6.2: pe a fai o `k` o le sili integer st
    // `0 <= y mod 10^k <= y - x`,              ona `V = floor(y / 10^k) * 10^k` i `[x, y]` ma o se tasi o le puʻupuʻu faʻailoga (ma le laʻititi numera o taua numera) i lena tulaga.
    //
    //
    // saili le numera umi `kappa` i le va `(minus1, plus1)` pei o le Theorem 6.2.
    // Theorem 6.2 mafai ona vaʻaia e tuʻuʻese `x` e ala i le manaʻomia `y mod 10^k < y - x` nai lo.
    // (eg, `x` =32000, `y` =32777; `kappa` =2 talu mai le `y mod 10 ^ 3=777 <y, x=777`.) O le algorithm e faʻamoemoe i le vaega faʻamaonia mulimuli ane e tuʻu ese ai le `y`.
    //
    let delta1 = plus1 - minus1;
    // tuu delta1int=(delta1>> e) pei o le usize;//naʻo le faʻamatalaga
    let delta1frac = delta1 & ((1 << e) - 1);

    // tuʻufaʻatasia vaega taua, a o siakiina le saʻo i sitepu taʻitasi.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // numera ae lei tuuina atu
    loop {
        // e tasi lava le numera e tuʻuina mai, pei ole `plus1 >= 10^kappa` tagata faʻafeiloaʻi:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (e mulimuli i lena `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // vaevae le `remainder` ile `10^kappa`.uma e scaled e `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; ua matou mauaina le `kappa` saʻo.
            let ten_kappa = (ten_kappa as u64) << e; // fua le 10 ^ kappa i tua i le fetufaʻaiga faʻaaliga
            return round_and_weed(
                // SAFETY: na matou amataina lena manatua luga.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // gagau le matasele pe a fai na matou tuʻufaʻatasia uma numera taua.
        // Ole numera saʻo o numera ole `max_kappa + 1` ile `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // toefuatai invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // faia vaega vaevaeina, aʻo siakiina le saʻo i sitepu taʻitasi.
    // o le taimi lenei tatou te faʻamoemoe i le faʻateleina faʻateleina, ona o le vaevaega o le a leiloa le saʻo.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // o le isi numera e tatau ona taua a o tatou faʻataʻitaʻia lena ae leʻi motusia ni auvili, lea e `m = max_kappa + 1` (#o numera i le vaega taua):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // e le sosolo, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // vaevae le `remainder` ile `10^kappa`.
        // uma e scaled e `2^e / 10^kappa`, o lea la lona mulimuli e faʻaalia ii.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // fautua fesoasoani
            return round_and_weed(
                // SAFETY: na matou amataina lena manatua luga.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // toefuatai invariants
        kappa -= 1;
        remainder = r;
    }

    // ua matou fausia uma taua taua o `plus1`, ae le mautinoa pe o le sili ona lelei tasi.
    // mo se faʻataʻitaʻiga, afai o le `minus1` o le 3.14153 ... ma le `plus1` o le 3.14158 ..., e 5 eseʻese lava faʻamatalaga puʻupuʻu mai le 3.14154 i le 3.14158 ae naʻo le tasi lava le matou pito sili.
    // e tatau ona tatou faʻasolosolo tuʻufaʻatasi le numera mulimuli ma siaki pe o le sili sili ona lelei repr.
    // e toʻa 9 sui tauva (..1 i le ..9), o lona uiga la e vave tele.("rounding" vaega)
    //
    // le siakiina le gaioiga pe a fai o lenei "optimal" repr o loʻo i totonu o ulp ranges, ma e mafai foi, o le "second-to-optimal" repr mafai ona sili ona lelei ona o le lapoʻa sese.
    // i tulaga uma nei toe faafoi `None`.
    // ("weeding" vaega)
    //
    // o finauga uma ii e faʻateleina e le tau masani (ae faʻaalia) `k` taua, ina ia:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (faʻapea foi, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (faʻapea foi, `threshold > plus1v` mai le au faʻamili muamua)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // gaosia ni faʻatatau se lua i le `v` (o le mea moni `plus1 - v`) i totonu o 1.5 ulps.
        // o le iʻuga o le sui e tatau ona avea ma sili ona vavalalata sui i mea uma e lua.
        //
        // iinei `plus1 - v` o loʻo faʻaaogaina talu mai faia faʻatatau e tusa ma le `plus1` ina ia aloese ai mai overflow/underflow (o le mea lea o foliga mai na fesuiaʻi igoa).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // faʻaititia le numera mulimuli ma taofi i le latalata i le `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // matou te galulue ma faʻataʻitaʻiga numera `w(n)`, lea e tutusa tutusa ma `plus1 - plus1 % 10^kappa`.ina ua maeʻa tamoe le matasele tino `n` taimi, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // matou seti `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (faʻapenei `toega= plus1w(0)`) e faʻafaigofie ai siaki.
            // ia maitau ole `plus1w(n)` e faʻateleina i taimi uma.
            //
            // e tolu a matou aia e faʻamuta ai.soʻo se tasi o latou o le a faia le matasele le mafai ona faʻaauau, ae o loʻo ia tatou ia le itiiti ifo i le tasi le faʻailoga talafeagai iloa e latalata i le `v + 1 ulp`.
            // o le a matou faʻaalia i latou o TC1 e ala i TC3 mo faʻapuʻupuʻu.
            //
            // TC1: `w(n) <= v + 1 ulp`, faʻapea, o le mulimuli lea repr e mafai ona avea ma se tasi vavalalata.
            // e tutusa lea ma `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // tuʻufaʻatasia ma TC2 (lea e siaki pe a `w(n+1)` is valid), o lenei taofia le ono lolovaia i luga o le fuafuaina o `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, ie, o le isi repr mautinoa e le faʻataʻamilomilo i le `v`.
            // e tutusa lea ma `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // e mafai ona lolovaia le itu tauagavale, ae tatou te iloa `threshold > plus1v`, afai la e sese le TC1, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` ma e mafai ona tatou faʻataʻitaʻia saogalemu pe a fai o `threshold - plus1w(n) < 10^kappa` nai lo.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ie, o le isi repr o
            // leai se latalata i le `v + 1 ulp` nai lo le taimi nei repr.
            // tuuina `z(n) = plus1v_up - plus1w(n)`, avea lenei ma `abs(z(n)) <= abs(z(n+1))`.toe faʻapea foi e sese le TC1, ua iai la tatou `z(n) > 0`.e lua a matou mataupu e mafaufau ai:
            //
            // - a `z(n+1) >= 0`: TC3 avea `z(n) <= z(n+1)`.
            // a o faʻateleina le `plus1w(n)`, e tatau ona faʻaititia le `z(n)` ma e manino le sese.
            // - a `z(n+1) < 0`:
            //   - TC3a: ole faʻataʻitaʻiga ole `plus1v_up < plus1w(n) + 10^kappa`.manatu TC2 e sese, `threshold >= plus1w(n) + 10^kappa` o lea e le mafai ona ova.
            //   - TC3b: TC3 avea `z(n) <= -z(n+1)`, faʻapea, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   o le TC1 faʻatamaia e tuʻuina atu ia `plus1v_up > plus1w(n)`, o lea e le mafai ai ona oʻo atu pe oʻo i lalo peʻa tuʻufaʻatasia ma TC3a.
            //
            // ma le mea lea, tatou tatau ona taofi pe a `TC1 || TC2 || (TC3a && TC3b)`.e tutusa le taua i lalo i lona inverse, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // le repr puʻupuʻu le mafai ona faʻamutaina i le `0`
                plus1w += ten_kappa;
            }
        }

        // siaki pe afai o lenei sui o le latalata foʻi i le `v - 1 ulp`.
        //
        // e tutusa lava lenei ma le faʻamutaina aiaiga mo `v + 1 ulp`, ma `plus1v_up` uma suia e `plus1v_down` nai lo.
        // faʻamamafaina vaʻavaʻai tutusa tutusa taofiofia.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // o lea ua iai le tatou sui latalata ile `v` ile va ole `plus1` ma le `minus1`.
        // o lenei e matua saoloto, ae ui i lea, o lea tatou te teteʻe ai i soʻo se `w(n)` le i le va o `plus0` ma `minus0`, ie, `plus1 - plus1w(n) <= minus0` poʻo `plus1 - plus1w(n) >= plus0`.
        // matou te faʻaaogaina mea moni o `threshold = plus1 - minus1` ma `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Le faʻapuʻupuʻu auala faʻatinoina mo Grisu ma Dragon fallback.
///
/// Lenei tatau ona faʻaaogaina mo tele o mataupu.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SAFETI: O le siaki siaki e le lava le atamai e faʻatagaina ai matou e faʻaaoga `buf`
    // i le lona lua branch, o lea tatou te le gaoia le olaga atoa iinei.
    // Ae naʻo le `buf` na matou toe faʻaaogaina pe a toe faafoi e `format_shortest_opt` le `None` o lea ua lelei.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// O le saʻo ma le maopoopo auala faʻatinoina mo Grisu.
///
/// E toe faafoʻi `None` pe a toe faʻafoʻi mai se faʻamatalaga e leai se aoga i se isi tulaga.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // tatou manaʻomia le le itiiti ifo i le tolu fasimea o faʻaopoopoina saʻo
    assert!(!buf.is_empty());

    // normalize ma fua `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // vaevae le `v` i vaega tuʻufaʻatasia ma vaevaeina.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // uma `v` tuai ma fou `v` (scaled e `10^-k`) ei ai le sese o <1 ulp (Theorem 5.1).
    // talu ai matou te le iloa le mea sese e lelei pe le lelei foi, matou te faʻaaogaina ni auala faʻatatau se lua ma maua ai le sese sili ona maualuga o le 2 ulps (tutusa i le sili ona puʻupuʻu tulaga).
    //
    //
    // o le sini ia saili le faʻasologa lapoʻa o numera e masani ai uma i le `v - 1 ulp` ma le `v + 1 ulp`, ina ia matou mautinoa tele.
    // afai e le mafai lenei, matou te le iloa poʻo le fea o le sao saʻo mo `v`, o lea matou te fiu ai ma toe paʻu i tua.
    //
    // `err` ua faʻauigaina o le `1 ulp * 2^e` iinei (tutusa ma le ulp i le `vfrac`), ma o le a tatou fuaina i soo se taimi `v` maua fua.
    //
    //
    //
    let mut err = 1;

    // fuafua le sili ona tele `10^max_kappa` leai se sili atu `v` (faʻapea `v < 10^(max_kappa+1)`).
    // o le pito i luga tapunia o `kappa` lalo.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // afai o loʻo matou galulue ma le tapulaʻa mulimuli-numera, tatou manaʻomia faʻapuʻupuʻu le buffer i luma o le moni tuuina atu ina ia aloese mai faʻaluaina taʻamilosaga.
    //
    // matau e tatau ona tatou toe faʻalauteleina le faʻamau pe a faʻataʻamilomilo luga tupu!
    let len = if exp <= limit {
        // oi, e le mafai ona tatou gaosia se fuainumera e tasi.
        // E mafaia lenei mea pe a fai mai, o loʻo ia i tatou se mea pei ole 9.5 ma ua faʻasolosolo ile 10.
        //
        // I le mataupu faʻavae e mafai ona tatou vave valaʻau `possibly_round` ma se avanoa buffer, ae o le faʻaopoopoina `max_ten_kappa << e` e le 10 e ono iʻu ai i le lolovaia.
        //
        // ma o lea ua tatou sloppy iinei ma faʻalauteleina le sese tulaga i le itu o le 10.
        // o lenei mea o le a faʻateleina ai le sese le lelei, ae naʻo lava,*lava* laʻititi;
        // e mafai ona naʻo le taua vaʻaia pe a sili atu le mantissa nai lo le 60 fasi.
        //
        // SAFETY: `len=0`, o le mea lea o le tiute o le amataina o lenei manatua e le taua.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // tuuina vaega taua.
    // o le mea sese e matua vaelua, o lea tatou te le manaʻomia le siakiina i lenei vaega.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // numera ae lei tuuina atu
    loop {
        // e tasi lava le taimi matou te maua ai le tasi numera e tuʻuina atu ai ni tagata faʻaopoopo:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (e mulimuli i lena `remainder = vint % 10^(kappa+1)`)
        //
        //

        // vaevae le `remainder` ile `10^kappa`.uma e scaled e `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ua tumu le buffer?tamoʻe le pasi lapopoʻa ma le toe.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SAFETY: ua matou amataina `len` tele bytes.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // gagau le matasele pe a fai na matou tuʻufaʻatasia uma numera taua.
        // Ole numera saʻo o numera ole `max_kappa + 1` ile `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // toefuatai invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // tuuina vaevaevaevae.
    //
    // i mataupu faʻavae e mafai ona tatou faʻaauau i le numera avanoa mulimuli ma siaki mo le saʻo.
    // paga lea o loʻo matou galulue ma fuainumera fuaʻu aofaʻi, o lea matou te manaʻomia ai se faʻavae e iloa ai le lolovaia.
    // V8 faʻaaoga le `remainder > err`, lea e sese pe a eseese le muamua `i` taua numera o `v - 1 ulp` ma `v`.
    // peitaʻi o lenei mea ua teʻena le tele o isi itu taua tele.
    //
    // talu ai o le vaega mulimuli ane o loʻo i ai se faʻatonutonuina o loʻo vaʻaia, matou te faʻaaogaina lava le faʻamaoniga faigata:
    // matou faʻaauau pea `err` sili atu `10^kappa / 2`, o lea o le va i le va o le `v - 1 ulp` ma le `v + 1 ulp` e mautinoa lava e aofia ai le lua pe sili atu lapopoʻa sui.
    //
    // e tutusa lenei i le lua faʻatusatusaga muamua mai `possibly_round`, mo le faʻasino.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, lea `m = max_kappa + 1` (#o numera i le tuʻufaʻatasia vaega):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // e le sosolo, `2^e * 10 < 2^64`
        err *= 10; // e le sosolo, `err * 10 < 2^e * 5 < 2^64`

        // vaevae le `remainder` ile `10^kappa`.
        // uma e scaled e `2^e / 10^kappa`, o lea la lona mulimuli e faʻaalia ii.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ua tumu le buffer?tamoʻe le pasi lapopoʻa ma le toe.
        if i == len {
            // SAFETY: ua matou amataina `len` tele bytes.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // toefuatai invariants
        remainder = r;
    }

    // o isi faʻamatalaga e le aoga (`possibly_round` mautinoa ua le manuia), o lea tatou te fiu ai.
    return None;

    // ua matou fausia uma talosagaina numera o `v`, lea e tatau foi ona tutusa ma tutusa numera o `v - 1 ulp`.
    // nei matou siaki pe i ai se tulaga ese faʻaalia fefaʻasoaaʻi uma `v - 1 ulp` ma `v + 1 ulp`;o lenei e mafai ona tutusa pe faʻatupuina numera, poʻo le faʻataʻamilomilo-luga faʻamatalaga o na numera.
    //
    // afai o le laina aofia ai tele faʻailoga o le tutusa umi, tatou le mafai ona mautinoa ma tatau ona faʻafoʻi `None` nai lo.
    //
    // o finauga uma ii e faʻateleina e le tau masani (ae faʻaalia) `k` taua, ina ia:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SAFETY: o le muamua `len` bytes o `buf` tatau ona amataina.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (mo le faʻasino, o le togitogi laina faʻailoa mai le aofaʻi tonu mo talafeagai faʻailoga i le tuʻuina atu numera o numera.)
        //
        //
        // mea sese e tele naua o loʻo i ai le le itiiti ifo ma le tolu ono faʻailoga i le va o `v - 1 ulp` ma `v + 1 ulp`.
        // e le mafai ona tatou iloa poʻo le fea e saʻo.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // o le mea moni, 1/2 ulp ua lava e faʻalauiloa atu ai ono mafai sui.
        // (Manatua tatou te manaʻomia se tulaga tulaga ese mo le `v - 1 ulp` ma le 'v + 1 ulp`.) o lenei e le ova, pei o `ulp < ten_kappa` mai le muamua siaki.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // afai `v + 1 ulp` latalata i le lapo-lalo sui (lea ua uma ona i `buf`), ona mafai lea ona tatou toe foʻi saogalemu.
        // ia maitau ole `v - 1 ulp`*mafai* laʻititi atu nai lo le taimi nei sui, ae pei ole `1 ulp < 10^kappa / 2`, ua lava le tulaga lea:
        // ole mamao ile va ole `v - 1 ulp` male sui o loʻo iai nei e le mafai ona sili atu ile `10^kappa / 2`.
        //
        // o le tulaga e tutusa ma `remainder + ulp < 10^kappa / 2`.
        // talu ai o lenei e mafai ona faigofie ona lolovaia, muamua siaki pe o `remainder < 10^kappa / 2`.
        // ua uma ona tatou faʻamaonia o `ulp < 10^kappa / 2`, afai lava e `10^kappa` e leʻi oʻo i luga uma, o le lona lua siaki e lelei.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SAFETY: o le matou telefoni na amataina lena manatua.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------toega------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // i luga o isi lima, afai o le `v - 1 ulp` e latalata i le faʻataʻamilomilo-luga sui, e tatau ona tatou faʻataʻamilomilo ma toe foʻi.
        // mo le mafuaʻaga lava e tasi tatou te le manaʻomia siaki `v + 1 ulp`.
        //
        // o le tulaga e tutusa ma `remainder - ulp >= 10^kappa / 2`.
        // matou toe muamua siaki pe a `remainder > ulp` (ia maitau e le o le `remainder >= ulp`, aua o `10^kappa` e leʻo sola).
        //
        // ia maitau foi `remainder - ulp <= 10^kappa`, o lona uiga o le siaki lona lua e le ova.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SAOGALEMU: tatau ua initialized tatou Tagata telefoni e manatua.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // na ona faʻaopopo se numera faʻaopopo pe a talosagaina matou i le faʻamaumauga saʻo.
                // e tatau foi ona tatou siaki, pe a fai o le muamua faʻamau na gaogao, o le faʻaopopo numera mafai faʻatoa mafai ona faʻaopopo pe a `exp == limit` (edge tulaga).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SAFETI: matou ma le matou telefoni na amataina lena manatua.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // A leai, ua faʻatamaʻia tatou (faʻapea, o nisi taua i le va o `v - 1 ulp` ma `v + 1 ulp` o loʻo faʻasolosolo i lalo ma isi o loʻo faʻataʻamilomilo) ma lafoai.
        //
        None
    }
}

/// O le saʻo ma le maopoopo auala faʻatinoina mo Grisu ma Dragon fallback.
///
/// Lenei tatau ona faʻaaogaina mo tele o mataupu.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SAFETI: O le siaki siaki e le lava le atamai e faʻatagaina ai matou e faʻaaoga `buf`
    // i le lona lua branch, o lea tatou te le gaoia le olaga atoa iinei.
    // Ae naʻo le `buf` na matou toe faʻaaogaina pe a toe faafoi e `format_exact_opt` le `None` o lea ua lelei.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}