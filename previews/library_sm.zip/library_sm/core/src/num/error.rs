//! Sese ituaiga mo le liua i tuʻufaʻatasia ituaiga.

use crate::convert::Infallible;
use crate::fmt;

/// O le ituaiga sese na toe foʻi mai ina ua le mafai se suʻesuʻeina o tuʻufaʻatasia o ituaiga liliu.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Faʻafetaui nai lo le faʻamalosi ia mautinoa o le code pei o `From<Infallible> for TryFromIntError` i luga o le a faʻaauau pea ona galue pe a avea `Infallible` ma igoa faʻaigoa ia `!`.
        //
        //
        match never {}
    }
}

/// O se mea sese e mafai ona toe faʻafoʻi mai pe a faʻamauina se fuainumera.
///
/// Lenei sese ua faʻaaogaina o le sese ituaiga mo `from_str_radix()` gaioiga i luga o le primitive integer ituaiga, pei o [`i8::from_str_radix`].
///
/// # Mafuaʻaga mafuaʻaga
///
/// Faʻatasi ai ma isi mafuaʻaga, `ParseIntError` mafai ona togiina ona o le taʻitaʻia poʻo le faʻasolosolo o le paʻepaʻe i le manoa faʻapea, pe a maua mai i le masani sao.
///
/// Faʻaaogaina le [`str::trim()`] auala faʻamautinoa e leai se paʻepaʻe totoe i luma o parsing.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum e teu ai ituaiga 'eseʻese o mea sese e ono mafua ai le faʻauʻuina o le numera o fuainumera ina ia le manuia.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// E leai se aoga o le faʻavasegaina.
    ///
    /// Faatasi ai ma isi mafuaaga, o le a fausia lenei variant pe parsing se manoa gaogao.
    Empty,
    /// Aofia ai se numera le saʻo i lona tulaga.
    ///
    /// Faʻatasi ai ma isi mafuaʻaga, o lenei fesuiaʻiga o le a fausiaina pe a vaeluaina se manoa e aofia ai le non-ASCII char.
    ///
    /// O lenei fesuiaʻiga e fausiaina foi pe a fai o le `+` poʻo le `-` e leʻo ofi i totonu o le manoa a le o ia pe i le ogatotonu o se numera.
    ///
    ///
    InvalidDigit,
    /// Integer e telē tele e teu ai i totonu integer ituaiga.
    PosOverflow,
    /// Integer e laʻititi e faʻaputu i le integer type.
    NegOverflow,
    /// Taua na Zero
    ///
    /// O lenei fesuiaʻiga o le a lafoina pe a fai o le parsing string ei ai le tau o le zero, lea o le a faʻatulafonoina mo le leai-zero ituaiga.
    ///
    Zero,
}

impl ParseIntError {
    /// Faʻailoa atu le auiliiliga mafuaʻaga o le parsingina o le numera o fuainumera faʻatonuina.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}