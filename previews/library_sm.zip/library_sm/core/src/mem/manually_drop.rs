use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// O se afifi e taofi ai le tuʻufaʻatasia mai otometi valaʻauina o le "T''s destructor.
/// O lenei afifi o 0-tau.
///
/// `ManuallyDrop<T>` e noatia i le optimizations faatulagaga e tasi e pei `T`.
/// O lona iʻuga, e leai sona aʻafiaga * i manatu e faia e le tagata tuʻufaʻatasiga i mea o loʻo i totonu.
/// Mo se faʻataʻitaʻiga, amataina o le `ManuallyDrop<&mut T>` ma le [`mem::zeroed`] o ni amioga le faʻamatalaina.
/// Afai e tatau ona e taulimaina faamatalaga uninitialized, faaaoga nai lo [`MaybeUninit<T>`].
///
/// Manatua o le mauaina o le saogalemu o le taua i totonu o se `ManuallyDrop<T>`.
/// O lona uiga o le `ManuallyDrop<T>` o ana mea ua faʻapaʻu e le tatau ona faʻaalia e ala i se lautele saogalemu API.
/// Correspondingly, `ManuallyDrop::drop` o le saogalemu.
///
/// # `ManuallyDrop` ma faapau i poloaiga.
///
/// O le Rust o loʻo i ai le [drop order] faʻamatalaina lelei o tulaga taua.
/// Ina ia mautinoa o loo maligi fanua po o le lotoifale i se poloaiga patino, reorder le tautinoga e faapea o le poloaiga mataua atoatoa o le tasi saʻo.
///
/// E mafai ona faaaoga `ManuallyDrop` e pulea le poloaiga mataua, ae o lenei e manaomia code le saogalemu ma faigata ona fai saʻo i luma o le unwinding.
///
///
/// Mo se faataitaiga, afai e te manao ia mautinoa ua faapau se fanua faapitoa ina ua mavae le isi, e fai ai le fanua mulimuli o le a fausia:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` o le a paʻu pe a maeʻa `children`.
///     // faamaonia Rust ua maligi fanua i le faasologa o le tautinoga.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Afifi a taua e faapau manually.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // E le mafai ona faagaoioia le saogalemu ai pea i luga o le tulaga faatauaina
    /// assert_eq!(*x, "Hello");
    /// // Ae o le a le taufetuli `Drop` iinei
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Aveese le tau mai le `ManuallyDrop` container.
    ///
    /// O lenei e mafai ai e le taua i ona toe faapauina.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // E paʻu le `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Aveese le tau mai le `ManuallyDrop<T>` container fafo.
    ///
    /// O lenei auala ua faapitoa faamoemoe mo le o ese atu o tulaga faatauaina i mataua.
    /// Nai lo le faaaogaina [`ManuallyDrop::drop`] e pau manually le taua, e mafai ona e faaaogaina lenei auala e le taua ma faaaoga Peitai manaomia.
    ///
    /// Soo se taimi lava e mafai ai, e sili atu le faaaoga nai lo [`into_inner`][`ManuallyDrop::into_inner`], lea e taofia faia o ni kopi le aano o le `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// O lenei galuega tauave uunaʻia semantically atu le taua o loo i ai e aunoa ma le puipuia atili faaaogaina, ma tuua ai le tulaga o lenei pusa suia.
    /// O lou tiute le mautinoa o lenei `ManuallyDrop` e le toe faʻaaogaina.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SAOGALEMU: o loo tatou faitauina mai se faasinomaga, lea ua faamaonia
        // ina ia aoga mo le faitauina.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Faʻapaʻu lima le aofaʻi aofia ai.e tutusa lelei lava lenei e valaau [`ptr::drop_in_place`] ma se e faasino i le taua o loo i ai.
    /// Ona o lea, ae vagana ai o loo taua o se fausia teu, o le destructor le a valaauina i totonu o le nofoaga e aunoa ma le agai i le taua, ma ua faapea ona mafai ona faaaogaina e le saogalemu pau faamatalaga [pinned].
    ///
    /// Afai e ia te oe le anaina o le tau, oe mafai ona faʻaaoga [`ManuallyDrop::into_inner`] nai lo.
    ///
    /// # Safety
    ///
    /// O lenei galuega tauave tamoʻe le destructor o le taua o loo i ai.
    /// Isi nai lo suiga ua faia e le destructor lava ia, ua tuua suia le manatu, ma ina ia tusa ai o loo tumau pea le tuufaatasia se vaega itiiti-mamanu lea e aoga mo le ituaiga `T`.
    ///
    ///
    /// Peitai, o lenei "zombie" taua e le tatau ona aafia i code saogalemu, ma e le tatau ona valaauina i lenei galuega sili atu i le taimi e tasi.
    /// Ina ia faaaoga se tulaga faatauaina ua o loo ua pau, pe aveesea foi a taua taimi tele, e mafai ona mafua Amioga Undefined (e faalagolago i mea e faia e `drop`).
    /// E masani lava o lenei teena e ala i le faiga o ituaiga, ae e tatau ona lagolagoina i latou e faaaogāina `ManuallyDrop` na faamautinoaga e aunoa ma le fesoasoani mai le tuufaatasia.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SAFETY: o loʻo tatou toʻesea le tau faʻasino atu i se suiga suiga
        // lea e mautinoa e aoga mo tusitusiga.
        // I luga o le telefoni ina ia mautinoa e le o toe faapauina `slot`.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}