//! Galuega masani mo le feagai ma manatua.
//!
//! Lenei module aofia ai gaioiga mo le fesiligia o le tele ma gatasi o ituaiga, amataina ma faʻasolosolo manatua mea.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Avea le umiaina ma "forgets" e uiga i le taua **e aunoa ma le tamoe i lona destructor**.
///
/// So o se punaoa puleaina le taua, e pei o faupuega manatua po o se au faila, o le a nofo ai pea e faavavau i se tulaga unreachable.Ae peitai, e le mautinoa ai o le a tumau aloaia vae i lenei manatua.
///
/// * Afai e te fia mama manatua, tagai [`Box::leak`].
/// * A e manaʻo e maua se faʻasino i le mafaufau, tagaʻi i le [`Box::into_raw`].
/// * Afai e te manao e faamatuu ese o se taua lelei, tamoe lona destructor, tagai [`mem::drop`].
///
/// # Safety
///
/// `forget` e le faailogaina e pei `unsafe`, ona e le o aofia ai se faamaoniga o le a taufetuli i taimi uma destructors faamautinoa le saogalemu o Rust.
/// Mo se faataitaiga, o se polokalama e mafai ona faatupuina ai se taamilosaga faasinomaga faaaogaina [`Rc`][rc], pe valaau [`process::exit`][exit] e ulufafo aunoa tamoe destructors.
/// O lea la, e le suia ai le mea moni faatagaina `mem::forget` mai saogalemu code faamautinoa le saogalemu o Rust.
///
/// Na fai mai, o le gaosiaina o punaoa e pei o le manatuaina poʻo le I/O mea e masani ona le manaʻomia.
/// O le manaomia e oo mai i nisi o tulaga faapitoa faaaogaina mo FFI po code saogalemu, ae e oo lava i lea, e masani sili [`ManuallyDrop`].
///
/// Talu ai ona ua faatagaina galo a taua, so o se tulafono laitiiti e `unsafe` tusi e tatau ona faatagaina mo lenei avanoa.E le mafai ona toe foi se taua ma le faamoemoe o le a tatau taufetuli le Tagata telefoni a destructor le taua.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// O le faʻaaogaina saogalemu o le `mem::forget` o le alo ese mai ai i le taua o le faʻatamaʻia e le `Drop` trait.Mo se faataitaiga, o le a mama o lenei a `File`, o lona uiga
/// toe maua le avanoa ave e le fesuiaʻiga ae aua le tapunia le autu faʻavae punaoa:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// e aoga lenei mea pe a le umia o na siitia atu talu ai punaoa faavae i tulafono i fafo atu o Rust, mo se faataitaiga e ala i le auina atu o le descriptor faila mata e code C.
///
/// # Sootaga ma `ManuallyDrop`
///
/// E ui e mafai foi ona faʻaaogaina le `mem::forget` e faʻaliliu ai le *memory* o le umiaina, o le faia o lea mea e masani ona sese ai.
/// [`ManuallyDrop`] e tatau ona faaaogaina nai lo.Mafaufau, mo se faataitaiga, code lenei:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Fausia se `String` le faaaogaina o le mataupu o `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // mama `v` ona o nei pulea lona mafaufau e `s`
/// mem::forget(v);  // Sese, v ua le aloaia ma le tatau ona pasia i se galuega tauave
/// assert_eq!(s, "Az");
/// // `s` ua implicitly maligi ma deallocated lona mafaufau.
/// ```
///
/// O loo i ai mataupu e lua ma le faataitaiga i luga:
///
/// * Afai na faaopoopo sili code i le va o le fausiaina o `String` ma le taʻuina o `mem::forget()`, o se panic i totonu o le a mafua ai se saoloto faalua ona e taulimaina le manatu lava lea e tasi e le gata i `v` ma `s`.
/// * Ina ua uma ona valaau `v.as_mut_ptr()` ma le auina atu i le umia o le faamatalaga e `s`, o le taua `v` ua le aloaia.
/// E tusa lava pe ua na o le siitia atu i se taua e `mem::forget` (lea o le a le asiasia ai), ei ai nisi ituaiga manaoga atoatoa i latou tulaga faatauaina ia e fai ai i latou faalēaogāina pe dangling po o le toe umia.
/// Faʻaaogaina le taua aoga i soʻo se auala, aofia ai le pasiina ia latou pe toe faʻafoʻi ia latou mai gaioiga, e aofia ai amioga le mafaamatalaina ma ono mafai ona gagau masalosalo na faia e le na tuʻufaʻatasia.
///
/// O le fesuiaʻi i le `ManuallyDrop` e aloese ai mai faʻafitauli uma e lua:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Ae tatou te leʻi disassemble `v` i ona vaega mata, ia mautinoa e le ona pau!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Faʻavae nei `v`.O nei gaioiga e le mafai panic, o lea e le mafai ai ona i ai se faʻasologa.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // I le iuga, fausia se `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ua implicitly maligi ma deallocated lona mafaufau.
/// ```
///
/// `ManuallyDrop` matua puipuia puipuia faʻalua-leai se totogi ona tatou faʻamamaina le 'v' faʻaleagaina ae le i faia se isi lava mea.
/// `mem::forget()` E le faʻatagaina lenei mea aua e faʻaumatia lana finauga, faʻamalosia i matou e valaʻau pe a maeʻa ona toʻesea mai se mea matou te manaʻomia mai `v`.
/// Tusa lava pe na faʻalauiloaina le panic i le va o le fausiaina o `ManuallyDrop` ma le fausiaina o le manoa (e le mafai ona tupu i le code e pei ona faʻaalia), e iʻu lava i se faʻasologa ae le faʻalua faalua.
/// I nisi upu, `ManuallyDrop` sese i le itu o le mama nai lo le sese i le itu o (faalua-) pa'ū.
///
/// E le gata i lea, o le `ManuallyDrop` e taofia ai matou mai le oʻo atu i le "touch" `v` peʻa maeʻa ona faʻamatuʻu atu le pule i le `s`-o le laʻasaga mulimuli lava o le fegasoloaʻi ma le `v` e lafoai ai e aunoa ma le faʻatautaia o lona faʻaleagaina e matua le mafai lava.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Pei ole [`forget`], ae talia foi le taua faʻailoga.
///
/// O lenei gaioiga ua na o se shim faʻamoemoeina e aveʻese pe a faʻamalosia le `unsized_locals` foliga.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Faʻafoi mai le tele o se ituaiga i bytes.
///
/// Sili faʻapitoa, o lenei o le offset i bytes i le va o elemeni mulimuli i se faʻasologa ma lena aitema ituaiga e aofia ai laina tutusa.
///
/// Ma, mo soʻo se ituaiga `T` ma le umi `n`, `[T; n]` ei ai le tele o `n * size_of::<T>()`.
///
/// I se tulaga lautele, o le tele o se ituaiga e le mautu i soʻo se tuʻufaʻatasiga, ae o ni ituaiga ituaiga e pei o faʻamuamua o.
///
/// O le siata o loʻo mulimuli mai e avatua le tele mo faʻamuamua.
///
/// Ituaiga |tele_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Ma le isi, `usize` ma `isize` maua tutusa tutusa.
///
/// O ituaiga `*const T`, `&T`, `Box<T>`, `Option<&T>`, ma `Option<Box<T>>` e tutusa uma le tele.
/// A faʻapea e tele le `T`, o ituaiga uma na e tutusa le tele ma le `usize`.
///
/// O le fesuiaʻi o se faʻasino tusi e le suia lona tele.E pei o lea, `&T` ma `&mut T` maua le tutusa tutusa.
/// Faʻapena foi mo `*const T` ma `* mut T`.
///
/// # Tele o aitema `#[repr(C)]`
///
/// O le `C` sui mo aitema o loʻo i ai se faʻamatalaga faʻatulagaina.
/// Faʻatasi ai ma lenei faʻatulagaga, o le tele o aitema e mausali foi pe a fai o fanua uma ei ai se mautu tele.
///
/// ## Tele o Fausaga
///
/// Mo `structs`, o le tele e fuafuaina e le algorithm lea.
///
/// Mo fanua taʻitasi i le faʻatulagaina poloaʻi e ala i le faʻasilasilaga oka:
///
/// 1. Faʻaopopo le tele o le fanua.
/// 2. Faʻataʻamilomilo le lapoʻa o loʻo iai nei i le tele lata mai o le isi fanua's [alignment].
///
/// I le iuga, faʻataʻamilomilo le tele o le faʻavae i le tele lata mai o lona [alignment].
/// O le faʻavasegaina o le fausaga e masani lava o le sili ona tele gaioiga o ona fanua uma;lenei mafai ona suia ma le faʻaaogaina o `repr(align(N))`.
///
/// E le pei o le `C`, e leai ni lapoʻa e faʻataʻitaʻia e oʻo atu i le tasi le paita le tele.
///
/// ## Tele o Enum
///
/// Enums e le o iai ni faʻamatalaga e ese mai i le faʻailoga tagata e tutusa le tele ma le C fua i luga o le tulaga ua latou tuʻufaʻatasia ai.
///
/// ## Tele o Iuni
///
/// O le tele o le iuni o le tele o lona tele fanua.
///
/// E le pei o `C`, e leai se aofaʻi o Iuni e le faʻataʻamilomiloina i le tasi le paita le tele.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // O nisi primitives
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Nisi faʻasologa
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Faʻatupega tele tutusa
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Faʻaaogaina `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // O le tele o le fanua muamua o le 1, ina faaopoopo 1 i le tele.Tele o 1.
/// // O le aafia i lenei suiga o le fanua lona lua o le 2, faapea faaopoopo 1 i le tele mo padding.Tele o 2.
/// // O le tele o le fanua lona lua o le 2, faapea faaopoopo 2 i le tele.Tele o 4.
/// // O le aafia i lenei suiga o le fanua lona tolu o le 1, ina faaopoopo 0 i le tele mo padding.Tele o 4.
/// // O le tele o le fanua lona tolu o le 1, o lea ia faʻaopopo le 1 i le tele.Tele e 5.
/// // Mulimuli ane, o le aafia i lenei suiga o le fausia o le 2 (ona o le aafia i lenei suiga aupito tele i totonu o lona fanua e 2), ina ia faaopoopo le 1 i le tele mo padding.
/// // Tele e 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // mulimuli Tuple structs le tulafono lava lea e tasi.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Manatua o reordering le fanua e mafai ona tuutuu ifo i lalo le tele.
/// // E mafai ona tatou aveesea uma padding bytes ala i le tuuina `third` luma `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Ole tele ole iuni ole lapoʻa ole tele.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Faʻafoi mai le tele o le faʻasino-i le aoga i paita.
///
/// Lenei e masani lava tutusa ma `size_of::<T>()`.
/// Peitaʻi, a `T`*leai* leai se statically-iloa tele, eg, o le fasi [`[T]`][slice] poʻo le [trait object], ona mafai lea ona faʻaaoga `size_of_val` e maua ai le tele-lauiloa tele.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: `val` o se faʻasino, o lona uiga o se faʻatulagaina mata faʻatonu
    unsafe { intrinsics::size_of_val(val) }
}

/// Faʻafoi mai le tele o le faʻasino-i le aoga i paita.
///
/// Lenei e masani lava tutusa ma `size_of::<T>()`.Peitaʻi, a `T`*leai* leai se statically-lauiloa tele, faʻapea, o se fasi [`[T]`][slice] poʻo se [trait object], ona mafai lea ona faʻaaoga `size_of_val_raw` e maua ai le tele-lauiloa tele.
///
/// # Safety
///
/// O lenei gaioiga e naʻo le saogalemu e valaʻau ai pe a fai o tulaga nei taofi:
///
/// - Afai o `T` o `Sized`, o lenei gaioiga e saogalemu i taimi uma e valaʻau.
/// - Afai o le siʻusiʻu le `T` o le:
///     - a [slice], ona tatau ai lea ona avea le umi o le fasi maʻai o se fuainumera amataina, ma le tele o le *atoa taua*(malosi siʻusiʻu umi + statically tele faʻatulagaina) tatau ona ofi i `isize`.
///     - a [trait object], ona tatau lea ona vaʻai le vtable vaega o le faʻasino i le vtable aoga na mauaina e se faʻamalosi tino faʻamalosi, ma le tele o le *atoa taua*(malosi siʻusiʻu umi + statically tele faʻatulagaina) e tatau ona ofi i le `isize`.
///
///     - o le (unstable) [extern type], o lona uiga o lenei galuega e sefe lava i taimi uma pe a valaʻau, ae mafai panic pe faʻafoi mai le sese sese, ona e leʻo iloa le faʻatulagaina o le ituaiga i fafo.
///     O le amio lava lea e tasi pei o le [`size_of_val`] i luga o le faʻasino i se ituaiga ma le ituaiga i fafo o le siʻusiʻu.
///     - ese, ua conservatively le faatagaina e valaau lenei galuega tauave.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETI: o le tagata e valaʻau tatau ona tuʻuina mai se faʻatulagaina mata faʻatonu
    unsafe { intrinsics::size_of_val(val) }
}

/// Faʻafoʻi mai le [ABI]-e manaʻomia le faʻatulagaina laʻititi o se ituaiga.
///
/// Soʻo se faʻasino i le taua o le ituaiga `T` tatau ona tele o lenei numera.
///
/// Ole faʻafetaui lea e faʻaaogaina mo faʻavae fanua.Atonu e laʻititi nai lo le faʻatulagaina e manaʻomia.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Faʻafoʻi mai le [ABI]-e manaʻomia le faʻatulagaina laʻititi o le ituaiga o tau e faʻasino i ai le `val`.
///
/// Soʻo se faʻasino i le taua o le ituaiga `T` tatau ona tele o lenei numera.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val o se faʻasino, o lona uiga o se faʻatulagaina mata faʻatonu
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Faʻafoʻi mai le [ABI]-e manaʻomia le faʻatulagaina laʻititi o se ituaiga.
///
/// Soʻo se faʻasino i le taua o le ituaiga `T` tatau ona tele o lenei numera.
///
/// Ole faʻafetaui lea e faʻaaogaina mo faʻavae fanua.Atonu e laʻititi nai lo le faʻatulagaina e manaʻomia.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Faʻafoʻi mai le [ABI]-e manaʻomia le faʻatulagaina laʻititi o le ituaiga o tau e faʻasino i ai le `val`.
///
/// Soʻo se faʻasino i le taua o le ituaiga `T` tatau ona tele o lenei numera.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val o se faʻasino, o lona uiga o se faʻatulagaina mata faʻatonu
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Faʻafoʻi mai le [ABI]-e manaʻomia le faʻatulagaina laʻititi o le ituaiga o tau e faʻasino i ai le `val`.
///
/// Soʻo se faʻasino i le taua o le ituaiga `T` tatau ona tele o lenei numera.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// O lenei gaioiga e naʻo le saogalemu e valaʻau ai pe a fai o tulaga nei taofi:
///
/// - Afai o `T` o `Sized`, o lenei gaioiga e saogalemu i taimi uma e valaʻau.
/// - Afai o le siʻusiʻu le `T` o le:
///     - a [slice], ona tatau ai lea ona avea le umi o le fasi maʻai o se fuainumera amataina, ma le tele o le *atoa taua*(malosi siʻusiʻu umi + statically tele faʻatulagaina) tatau ona ofi i `isize`.
///     - a [trait object], ona tatau lea ona vaʻai le vtable vaega o le faʻasino i le vtable aoga na mauaina e se faʻamalosi tino faʻamalosi, ma le tele o le *atoa taua*(malosi siʻusiʻu umi + statically tele faʻatulagaina) e tatau ona ofi i le `isize`.
///
///     - o le (unstable) [extern type], o lona uiga o lenei galuega e sefe lava i taimi uma pe a valaʻau, ae mafai panic pe faʻafoi mai le sese sese, ona e leʻo iloa le faʻatulagaina o le ituaiga i fafo.
///     O le amio lava lea e tasi pei o le [`align_of_val`] i luga o le faʻasino i se ituaiga ma le ituaiga i fafo o le siʻusiʻu.
///     - ese, ua conservatively le faatagaina e valaau lenei galuega tauave.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETI: o le tagata e valaʻau tatau ona tuʻuina mai se faʻatulagaina mata faʻatonu
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Faʻafoʻi `true` pe a paʻu le aoga o ituaiga `T` mataupu.
///
/// E naʻo se faʻaaliga lelei, ma ono faʻaaogaina faʻapitoa.
/// e ono faʻafoʻi mai le `true` mo ituaiga e le manaʻomia le lafoina i lalo.
/// E pei o taimi uma toe foi `true` o le a aoga faʻatinoina o lenei galuega.Ae peitaʻi afai o lenei gaioiga moni toe faʻafoʻi `false`, ona mafai lea ona e mautinoa pa'ū `T` leai se itu aʻafiaga.
///
/// Maualalo tulaga faʻatinoina o mea e pei o aoina, lea e manaʻomia tuulima paʻu latou faʻamaumauga, tatau ona faʻaaogaina lenei gaioiga e aloese ai le le talafeagai le taumafai e faʻapaʻu uma a latou mea pe a latou faʻaumatia.
///
/// Atonu e le faia se eseesega i le tatalaina o fausiaina (pe a fai o se matasele e leai ni itu-aʻafiaga e faigofie ona iloa ma aveʻesea), ae o le tele o taimi o se manumalo tele mo debug fausiaina.
///
/// Manatua o [`drop_in_place`] ua maeʻa faia lenei siaki, o lea afai o lau galuega e mafai ona faʻaititia i sina laʻititi numera o [`drop_in_place`] telefoni, faʻaaogaina lenei e le manaʻomia.
/// Faʻapitoa tusi e mafai ona e [`drop_in_place`] se fasi, ma o le a faia ai le tasi manaoga_drop siaki mo uma taua.
///
/// Ituaiga pei o Vec o lea e naʻo le `drop_in_place(&mut self[..])` e aunoa ma le faʻaaogaina manino o le `needs_drop`.
/// O ituaiga e pei ole [`HashMap`], i leisi itu, e tatau ona paʻuu tasi le faʻatauaina ma e tatau ona faʻaaoga lenei API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Lenei o se faʻataʻitaʻiga pe faʻapefea ona faʻaaoga e se faʻaputuga `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // paʻu le faʻamatalaga
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Faʻafoʻi mai le tau o le ituaiga `T` faʻatusalia e le atoa-zero byte-pattern.
///
/// O lona uiga, mo se faʻataʻitaʻiga, o le paʻu byte i le `(u8, u16)` e le o faʻapea o le zero.
///
/// E leai se mautinoa o le atoa-zero byte-pattern faʻatusa ai le aoga taua o nisi ituaiga `T`.
/// Mo se faʻataʻitaʻiga, o le atoa-zero byte-pattern e le o se taua aoga mo faʻasino ituaiga (`&T`, `&mut T`) ma galuega faʻasino.
/// Faʻaaogaina `zeroed` i ia ituaiga mafuaʻaga [undefined behavior][ub] vave ona [the Rust compiler assumes][inv] o loʻo i ai i taimi uma se aoga aoga i se fesuiaʻiga e manatu na amataina.
///
///
/// E tutusa le aoga o le [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// E aoga mo FFI i nisi taimi, ae tatau ona masani ona 'alofia.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Faʻaoga saʻo o lenei galuega: amataina o fuainumera ma fuainumera.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Sese* faʻaaogaina o lenei galuega: amataina o se faʻasino ma le zero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Amio le mafaamatalaina!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ma toe!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SAFETY: o le tagata telefoni e tatau ona mautinoa o le aoga uma-zero aoga mo `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Bypasses Rust's masani manatua-amataina siaki e ala i le faʻafoliga e maua se taua o le ituaiga `T`, ae leai se mea.
///
/// **O lenei galuega ua faʻaleaogaina.** Faʻaaoga le [`MaybeUninit<T>`] nai lo lena.
///
/// O le mafuaʻaga mo le faʻaleaogaina o le gaioiga masani lava e le mafai ona faʻaaogaina saʻo: e tutusa lona aoga ma le [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// E pei ona faʻamatalaina e le [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] o faʻatauaina e amata lelei.
/// O lona iʻuga, valaʻau eg
/// `mem::uninitialized::<bool>()` mafuaʻaga vave amioga le faʻamatalaina mo le toe faʻafoʻiina o le `bool` e le o mautinoa `true` poʻo le `false`.
/// Sili ona leaga, moni uninitialized manatua e pei o le mea e toe foʻi mai iinei e faʻapitoa i le iloa ai e le tuʻufaʻatasia e leai sona tumau faʻatauaina.
/// O lenei mea e le mafai ai ona faʻamatalaina amio ia i ai uninitialized faʻamaumauga i se fesuiaiga tusa lava pe o lena fesuiaʻiga ei ai se fuainumera fuainumera.
/// (Faasilasilaga e le faamautuina pea o le tulafono o loo siomia integers uninitialized, ae seia oo ina latou, e fautuaina e aloese mai ai.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SAFETY: o le tagata e valaʻau tatau ona mautinoa o le vaega faʻatulagaina aoga e aoga mo `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Faʻafesuiaʻi tulaga taua i nofoaga e lua e mafai ona suia, e aunoa ma le faʻamamaina o se tasi.
///
/// * Afai e te manaʻo e faʻafesuiaʻi i se le aoga poʻo le aoga aoga dummy, vaʻai [`take`].
/// * Afai e te manaʻo e fesuiaʻi ma le pasia taua, faʻafoʻi mai le tuai aoga, vaʻai [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SAFETY: o le raw pointers na faia mai le saogalemu mutable faʻasino faʻamalieina uma
    // faʻafitauli i `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Suia le `dest` ma le aoga masani o le `T`, toe faafoi le muamua `dest` aoga.
///
/// * Afai e te manaʻo e sui tulaga faʻatauaina o lua fesuiaʻiga, vaʻai [`swap`].
/// * Afai e te manaʻo e sui i se pasia aoga nai lo le le pasi aoga, vaʻai [`replace`].
///
/// # Examples
///
/// O se faʻataʻitaʻiga faigofie:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` faʻatagaina le umiaina o se vaega fanua e ala i le suia i se "empty" tau.
/// A aunoa ma le `take` e mafai ona e tamoʻe i mataupu faʻapenei:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Manatua o `T` e le manaʻomia [`Clone`], o lea e le mafai ai ona faʻapipiʻi ma toe seti le `self.buf`.
/// Ae e mafai ona faʻaaogaina le `take` e faʻateʻa le uluaʻi taua o le `self.buf` mai le `self`, faʻatagaina e toe faʻafoʻi mai:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Siʻi `src` i le `dest` faʻasino, toe faafoi mai le `dest` muamua aoga.
///
/// E leai se aoga ua toʻesea.
///
/// * Afai e te manaʻo e sui tulaga faʻatauaina o lua fesuiaʻiga, vaʻai [`swap`].
/// * Afai e te manaʻo e sui i se le faʻatauaina aoga, vaai [`take`].
///
/// # Examples
///
/// O se faʻataʻitaʻiga faigofie:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` faʻatagaina le faʻaaogaina o se vaega fanua e ala i le suia i se isi tau.
/// A aunoa ma le `replace` e mafai ona e tamoʻe i mataupu faʻapenei:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Manatua o `T` e le manaʻomia [`Clone`], o lea e le mafai ai ona tatou faʻamauina `self.buf[i]` e aloese ai mai le gaioi.
/// Ae e mafai ona faʻaaoga le `replace` e faʻateʻa ai le uluaʻi taua i lena faasino igoa mai le `self`, faʻatagaina e toe faʻafoʻi mai:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SAFETY: Na matou faitau mai le `dest` ae tusi saʻo le `src` i totonu mulimuli ane,
    // faʻapea e le faʻaluaina le tau tuai.
    // E leai se mea e pa'ū ma leai se mea ii mafai panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Lafoaia o se tau.
///
/// E faia lea ile valaʻau o le finauga o le [`Drop`][drop].
///
/// E le aoga lenei mea mo ituaiga e faʻaaoga ai le `Copy`, faʻataʻitaʻiga
/// integers.
/// O ia taua e kopiina ma _then_ siitia i totonu o le gaioiga, o lea la e tumau ai pea le tau pe a maeʻa lenei gaioiga telefoni.
///
///
/// O lenei aoga e le o se faʻataulaitu;e faauigaina moni lava i le
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Talu ai `_x` ua siitia i totonu o le gaioiga, e otometi lava le paʻu i luma o le gaioiga toe foi.
///
/// [drop]: Drop
///
/// # Examples
///
/// Faʻaaoga faʻavae:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // manino pau le vector
/// ```
///
/// Talu ai [`RefCell`] faʻamalosia tulafono nono i taimi o faʻataʻamilosaga, `drop` mafai ona faʻamalolo se [`RefCell`] nono:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // tuʻuina le faanoi mutable i lenei slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// O fuainumera ma isi ituaiga faʻaogaina [`Copy`] e le afaina i le `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // ua siitia atu i se ata o `x` ma faapau
/// drop(y); // ua siitia atu i se ata o `y` ma faapau
///
/// println!("x: {}, y: {}", x, y.0); // o loo avanoa pea
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Faʻamatalaina `src` pei o le ituaiga `&U`, ona faitau lea o le `src` e aunoa ma le minoi o le aofai taua.
///
/// O lenei gaioiga o le a le mautinoa faʻapea o le pointer `src` e aoga mo [`size_of::<U>`][size_of] bytes i le faʻaliliuina o le `&T` i le `&U` ona faitau ai lea o le `&U` (seʻi vagana ai o lenei mea e faia i se auala e saʻo e tusa lava pe o loʻo faia e `&U` ni faʻasologa faigata nai lo `&T`).
/// O le a le saogalemu foi fausia se kopi o le aofia ai aoga nai lo le o ese mai `src`.
///
/// E leʻo se sese tuʻufaʻatasi taimi pe a fai o `T` ma `U` e eseese o latou tetele, ae e matua faʻamalosia lava e naʻo le faʻaaogaina o lenei gaioiga e tutusa le tele o le `T` ma le `U`.O lenei gaioiga faʻaosofia [undefined behavior][ub] pe a fai o `U` e lapoʻa nai lo `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopi le faamatalaga mai 'foo_array' ma le taulimaina o se 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Suia le faamatalaga kopiina
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // E le tatau ona suia le anotusi o le 'foo_array'
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Afai o U e iai se maualuga faʻatulagaina manaʻoga, src atonu e le fetaui talafeagai.
    if align_of::<U>() > align_of::<T>() {
        // SAFETY: `src` o se faʻasino lea e mautinoa e aoga mo faitau.
        // O le tagata e tatau ona faʻamautinoa mai o le transmutation moni e saogalemu.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SAFETY: `src` o se faʻasino lea e mautinoa e aoga mo faitau.
        // Na ona matou siakiina o `src as *const U` na faʻatulaga lelei.
        // O le tagata e tatau ona faʻamautinoa mai o le transmutation moni e saogalemu.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Opaque ituaiga fai ma sui o le faailoga tagata o le enum.
///
/// Vaʻai le [`discriminant`] function i lenei module mo nisi faʻamatalaga.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Nei trait faʻatinoina le mafai ona maua mai ona matou te le manaʻomia ni tuaoi ia T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Faʻafoʻi mai se taua faʻapitoa faʻailoaina le enum variant i le `v`.
///
/// Afai o le `T` e le o se enum, o le valaʻauina o lenei gaioiga o le a le iʻu ai i le le faʻamatalaina amio, ae o le toe faʻafoi taua e le mautinoa.
///
///
/// # Stability
///
/// E mafai ona suia le faʻailoga o le enum variant peʻa suia le faʻauiga o le enum.
/// O le faʻailoga tagata o se eseʻesega o le a le suia i le va o tuʻufaʻatasiga ma le tutusa tuʻufaʻatasiga.
///
/// # Examples
///
/// Lenei mafai ona faʻaaogaina e faʻatusatusa enums e ave faʻamatalaga, ae le amanaʻiaina le moni faʻamaumauga:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Faʻafoʻi mai le numera o fesuiaʻiga i le ituaiga enum `T`.
///
/// Afai o le `T` e le o se enum, o le valaʻauina o lenei gaioiga o le a le iʻu ai i le le faʻamatalaina amio, ae o le toe faʻafoi taua e le mautinoa.
/// Tutusa, afai `T` o se enum ma sili atu variants nai lo `usize::MAX` o le toe faafoi taua e le faʻamaotiina.
/// Ole a le faitauina numera eseʻese.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}